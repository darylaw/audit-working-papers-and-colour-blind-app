"""Package the dependency-free Worker when the Sites helper is unavailable."""
import json
import tarfile
from pathlib import Path
root = Path(__file__).resolve().parent.parent
assert json.loads((root / 'dist/.openai/hosting.json').read_text())['project_id'] == json.loads((root / '.openai/hosting.json').read_text())['project_id']
files = ['dist/server/index.js', 'dist/.openai/hosting.json']
with tarfile.open(root / 'site.tar.gz', 'w:gz') as archive:
    for name in files:
        archive.add(root / name, arcname=name)
with tarfile.open(root / 'site.tar.gz') as archive:
    assert archive.getnames() == files
print('Packaged Worker and hosting manifest only.')
