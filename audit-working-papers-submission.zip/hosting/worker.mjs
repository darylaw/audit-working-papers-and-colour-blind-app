// Sites dispatch authenticates visitors and owns the sign-in and callback routes.
export const policy = "default-src 'none'; script-src 'none'; script-src-attr 'none'; style-src 'unsafe-inline'; font-src data:; img-src data: blob:; connect-src 'none'; form-action 'none'; base-uri 'none'; object-src 'none'; frame-src 'none'; worker-src 'none'";

export function handler(html) {
  const csp = html.match(/<meta http-equiv="Content-Security-Policy" content="([^"]+)"/i)?.[1] || policy;
  return { async fetch(request) {
    const headers = new Headers({
      'Cache-Control': 'private, no-store',
      'Content-Security-Policy': csp + "; frame-ancestors 'self'",
      'Referrer-Policy': 'no-referrer',
      'X-Content-Type-Options': 'nosniff',
      'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
      'Cross-Origin-Opener-Policy': 'same-origin',
      'Cross-Origin-Resource-Policy': 'same-origin'
    });
    if (!['GET', 'HEAD'].includes(request.method)) {
      headers.set('Allow', 'GET, HEAD');
      return new Response(null, { status: 405, headers });
    }
    const url = new URL(request.url);
    if (!['/', '/app/audit-working-papers.html'].includes(url.pathname))
      return new Response(null, { status: 404, headers });
    const id = request.headers.get('oai-authenticated-user-id');
    const email = request.headers.get('oai-authenticated-user-email');
    if (!id || !email) {
      headers.set('Location', '/signin-with-chatgpt?return_to=%2F');
      return new Response(null, { status: 302, headers });
    }
    // Partition device-local preferences without inserting a name or email into the page.
    const hash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(id));
    const scope = [...new Uint8Array(hash)].map(x => x.toString(16).padStart(2, '0')).join('');
    headers.set('Content-Type', 'text/html; charset=utf-8');
    const page = html.replace('<head>', '<head><meta name="awp-storage-scope" content="' + scope + '">');
    return new Response(request.method === 'HEAD' ? null : page, { headers });
  } };
}
