/* ===========================================================================
   gen-samples.js  —  build-time generator for src/samples.js
   ---------------------------------------------------------------------------
   Every section of the app accepts an upload, so every section owes the auditor
   a worked example of what to ask the client for.  Rather than invent example
   data, this runs each module's own ingest pipeline over the synthetic PBC pack
   and keeps the cleaned, mapped result: figures that already cast and tie, in
   the shape the mapper recognises with high confidence.

   The emitted file is data only -- no logic -- so the app stays offline.

       node tools/gen-samples.js            (then python build.py)
   =========================================================================== */
'use strict';
const fs = require('fs');
const path = require('path');
const S = require('./../test/spec-lib.js');

const L = S.load(fs.readdirSync(path.join(__dirname, '..', 'src', 'modules')).filter(f => f.endsWith('.js')));
const { Core, Modules } = L;
const ROWS = 6;

/* Which PBC file speaks for each section, and any shape notes.
   `sheet` picks a worksheet other than the first; `headings:'source'` keeps the
   client's own column headings (the going concern forecast is months across, so
   "Month 1" would be a worse template than "Mar 25").                        */
const SOURCES = {
  PLAN:  { client:'client-a', file:'PBC-TB-01 Trial balance',                 as:'PBC-TB-01 Trial balance' },
  TB:    { client:'client-a', file:'PBC-TB-01 Trial balance' },
  PPE:   { client:'client-a', file:'PBC-PPE-01 Fixed asset register' },
  IMP:   { client:'client-a', file:'PBC-IMP-01 Impairment assessment FRS 36', sheet:/cgu/i },
  INV:   { client:'client-a', file:'PBC-INV-01 Inventory listing' },
  AR:    { client:'client-a', file:'PBC-AR-01 Trade receivables listing' },
  OR:    { client:'client-a', file:'PBC-PRE-01 Prepayments schedule' },
  CASH:  { client:'client-a', file:'PBC-BANK-01 Bank statement Operating account' },
  AP:    { client:'client-a', file:'PBC-AP-01 Trade payables listing' },
  ACCR:  { client:'client-a', file:'PBC-ACC-01 Accruals schedule' },
  PROV:  { client:'client-a', file:'PBC-PROV-01 Provisions and contingencies' },
  LOAN:  { client:'client-a', file:'PBC-LOAN-01 Loan schedule' },
  LEASE: { client:'client-a', file:'PBC-LSE-01 Lease schedule' },
  TAX:   { client:'client-a', file:'PBC-TB-01 Trial balance' },
  EQ:    { client:'client-a', file:'PBC-EQ-01 Share capital and reserves' },
  REV:   { client:'client-a', file:'PBC-REV-01 Sales listing' },
  EXP:   { client:'client-a', file:'PBC-EXP-01 Expense listing' },
  PAY:   { client:'client-a', file:'PBC-PAY-01 Payroll listing' },
  RP:    { client:'client-d', file:'PBC-RP-01 Related party movement' },
  GC:    { client:'client-a', file:'PBC-GC-01 Going concern assessment', headings:'source' },
};

/* Intangibles are tested against the fixed asset register -- the shapes are the
   same -- but a template full of motor vehicles would mislead, so this section
   gets a written example.  Amounts cast: cost b/f + additions - disposals.    */
const HAND = {
  IA: {
    as: 'PBC-IA-01 Intangible assets register',
    rows: [
      ['INT-001', 'Software',           'Accounting and consolidation system',  '2022-04-01', 5,  'Straight line', 180000, 0,     0, 108000, 36000, 0],
      ['INT-002', 'Software',           'Warehouse management system',          '2024-07-15', 5,  'Straight line', 0,      96000, 0, 0,      11200, 0],
      ['INT-003', 'Licences',           'Distribution licence - northern region','2021-01-05', 8,  'Straight line', 240000, 0,     0, 120000, 30000, 0],
      ['INT-004', 'Trademarks',         'Registered trademark portfolio',       '2020-09-30', 10, 'Straight line', 85000,  0,     0, 38250,  8500,  0],
      ['INT-005', 'Development costs',  'Capitalised development - order portal','2023-11-01', 4,  'Straight line', 132000, 24000, 0, 44000,  36000, 0],
      ['INT-006', 'Goodwill',           'Goodwill on acquisition of trade',     '2019-06-30', '', 'Not amortised', 460000, 0,     0, 0,      0,     0],
    ],
    keys: ['asset_id', 'category', 'description', 'acq_date', 'life', 'method',
           'cost_open', 'additions', 'disposals', 'accdep_open', 'dep_charge', 'accdep_disp'],
  },
};

/* -------------------------------------------------------------- pipeline */
function ingest(code, src) {
  const M = Modules.byCode[code];
  const dir = path.join(S.OUT, src.client);
  const match = fs.readdirSync(dir).find(f => f.startsWith(src.file) && /\.xlsx$/.test(f));
  if (!match) throw new Error(`${code}: no file starting "${src.file}" in ${src.client}`);
  const ye = (match.match(/(\d{4}-\d{2}-\d{2})/) || [])[1] || '2025-02-28';
  const eng = S.engagement(Core, ye, 145000);
  const buf = fs.readFileSync(path.join(dir, match));
  const wbData = Core.readWorkbook(buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength), match);
  const sheet = (src.sheet && wbData.sheets.find(s => src.sheet.test(s.name))) || wbData.sheets[0];
  const headerRow = Core.detectHeader(sheet.rows);
  const clean = Core.cleanTable(sheet.rows, headerRow);
  const mapping = Core.proposeMapping(clean.headers, M.fields, clean.rows.filter(r => r.__kind === 'data').slice(0, 40));
  const built = Core.buildRecords(clean, M.fields, mapping);
  return { M, eng, mapping, records: built.records, sheetName: sheet.name, fileName: match };
}

const isSet = v => !(v === null || v === undefined || v === '' || (typeof v === 'number' && isNaN(v)));
const round2 = n => Math.round(n * 100) / 100;
const cell = v => v instanceof Date ? Core.toISO(v) : typeof v === 'number' ? round2(v) : v == null ? '' : String(v);

/* Rows that show the section at its most legible: the ones with the most
   populated columns, in source order.                                        */
function pickRows(records, keys, n) {
  const scored = records.filter(r => !r.__excluded && !r.__orphan)
    .map(r => ({ r, filled: keys.filter(k => isSet(r[k])).length }));
  const best = Math.max(0, ...scored.map(s => s.filled));
  const good = scored.filter(s => s.filled >= Math.max(2, best - 2)).slice(0, n);
  return (good.length ? good : scored.slice(0, n)).map(s => keys.map(k => cell(s.r[k])));
}

function build(code) {
  const M = Modules.byCode[code];
  const hand = HAND[code];
  const src = SOURCES[code];
  const out = { code, name: M.name, group: M.group || 'Other' };

  if (hand) {
    out.file = hand.as + '.xlsx';
    out.columns = hand.keys.map(k => col(M.fields.find(f => f.key === k)));
    out.rows = hand.rows.map(r => r.map(cell));
    out.more = M.fields.filter(f => !hand.keys.includes(f.key)).map(col);
    out.basis = 'illustrative';
    return out;
  }

  const p = ingest(code, src);
  /* Columns worth putting in front of a client: everything required, plus every
     optional column this section actually found in a real schedule.           */
  const keys = M.fields.filter(f => f.required || p.mapping[f.key]).map(f => f.key);
  out.file = (src.as || src.file) + '.xlsx';
  out.sheet = p.sheetName;
  out.columns = keys.map(k => {
    const f = M.fields.find(x => x.key === k);
    const c = col(f);
    const m = p.mapping[k];
    if (src.headings === 'source' && m && m.heading) c.label = m.heading;
    return c;
  });
  out.rows = pickRows(p.records, keys, ROWS);
  out.more = M.fields.filter(f => !keys.includes(f.key)).map(col);
  out.basis = 'pipeline';
  return out;
}

/* A column as the template describes it: what we call it, whether we need it,
   and a few of the other headings the mapper already answers to -- so nobody
   renames a client's schedule for no reason.                                 */
function col(f) {
  if (!f) throw new Error('unknown field');
  const alts = (f.synonyms || []).filter(s => Core.lower(s) !== Core.lower(f.label) && !/[一-鿿]/.test(s)).slice(0, 4);
  const o = { key: f.key, label: f.label, type: f.type || 'text', alts };
  if (f.required) o.required = true;
  if (f.satisfiedByGroup) o.byGroup = true;
  if (f.block) o.block = f.block;
  return o;
}

/* ------------------------------------------------------------------ main */
const samples = {};
const report = [];
for (const M of Modules.ALL) {
  if (!SOURCES[M.code] && !HAND[M.code]) { report.push(`  ${M.code.padEnd(6)} skipped (no source mapped)`); continue; }
  try {
    const s = build(M.code);
    samples[M.code] = s;
    const req = s.columns.filter(c => c.required).length;
    report.push(`  ${M.code.padEnd(6)} ${String(s.columns.length).padStart(2)} cols (${req} required), ${s.rows.length} rows, ${s.basis.padEnd(12)} ${s.file}`);
  } catch (e) {
    report.push(`  ${M.code.padEnd(6)} FAILED  ${e.message}`);
    process.exitCode = 1;
  }
}

const banner = `/* ===========================================================================
   samples.js  —  GENERATED by tools/gen-samples.js.  Do not edit by hand.
   ---------------------------------------------------------------------------
   One worked example per section: the columns the mapper recognises, a handful
   of rows that cast and tie, and the other headings we already answer to.
   Figures and names are synthetic throughout.
   Regenerate with:  node tools/gen-samples.js && python build.py
   =========================================================================== */
`;
const body = 'const SAMPLES = ' + JSON.stringify(samples, null, 1) + ';\n';
fs.writeFileSync(path.join(__dirname, '..', 'src', 'samples.js'), banner + body, 'utf8');

console.log('\nsrc/samples.js written\n' + report.join('\n'));
console.log(`\n  ${Object.keys(samples).length} sections, ${(Buffer.byteLength(body) / 1024).toFixed(0)} KB\n`);
