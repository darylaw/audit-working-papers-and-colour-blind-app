"""One-off: wire spec.js into ui.js, xlsxfile.js, modules.js and build.py."""
import os, re
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.path.join(HERE, "src")
def rd(p): return open(p, encoding="utf-8").read()
def wr(p, s): open(p, "w", encoding="utf-8").write(s)
def must(s, old, new, label):
    if old not in s: raise SystemExit(f"anchor not found: {label}")
    return s.replace(old, new)

# ---------------------------------------------------------------- ui.js
p = os.path.join(SRC, "ui.js"); s = rd(p)
s = must(s, "function renderPage(M, st, page) {\n  switch (page.kind) {",
"""function specCtx(M, st) {
  const e = state.engagement;
  return { eng: e, cfg: st.config, d: st.derived, recs: st.records.filter(r => !r.__excluded), all: st.records,
    money, money0, pct, fmtDate: Core.fmtDate, r2, pm: e.materiality.pm || 0, trivial: e.materiality.trivial || 0, M };
}
function specHooks(M, st) {
  return { onChange: structural => recompute(M, st, structural), soft, render, trail: (ev, det) => trail(M.code, ev, det) };
}
function renderPage(M, st, page) {
  if (page.render) {
    let specs;
    try { specs = page.render(st, specCtx(M, st)); }
    catch (err) { console.error(err); specs = [{ type: 'note', tone: 'bad', html: '<b>This working paper could not be rendered:</b> ' + esc(err.message) }]; }
    return [wpFrame(M, st, page, SpecUI.render(specs, page.id, st, specHooks(M, st)))];
  }
  switch (page.kind) {""", "renderPage")
s = must(s, "  const d = st.derived;\n  const cols = M.STANDARD_COLUMNS;\n  const t = el('table', { class: 'std' });",
"""  const d = st.derived || {};
  const cols = M.STANDARD_COLUMNS || M.fields.filter(f => st.mapping[f.key]).map(f => ({ key: f.key, label: f.label, type: f.type === 'number' ? 'num' : f.type === 'date' ? 'date' : 'text', edit: f.type !== 'text' }));
  const t = el('table', { class: 'std' });""", "cleaned cols")
s = must(s, """        stat('Assets', st.records.filter(r => !r.__excluded).length),
        stat('Cost c/f', money0(d.totals.cost_close)), stat('Acc dep c/f', money0(d.totals.accdep_close)),
        stat('NBV c/f', money0(d.totals.nbv_close)),""",
"""        stat('Records', st.records.filter(r => !r.__excluded).length),
        ...(d.totals && d.totals.cost_close != null ? [stat('Cost c/f', money0(d.totals.cost_close)), stat('Acc dep c/f', money0(d.totals.accdep_close)), stat('NBV c/f', money0(d.totals.nbv_close))] : []),""", "cleaned stats")
s = must(s, "`${st.records.length} assets in the standard format · life read as ${d.lifeUnit} · click a number or date to correct it`",
"`${st.records.length} records in the standard format${d.lifeUnit ? ' · life read as ' + d.lifeUnit : ''} · click a number or date to correct it`", "cleaned sub")
s = must(s, """  if (p.id === 'lead' && d && d.lead.some(l => l.diffCost != null && Math.abs(l.diffCost) > 0.01)) return 'flag';
  if (p.id === 'depreciation' && d && Math.abs(d.totals.depDiff) > (state.engagement.materiality.trivial || 0)) return 'flag';
  if (p.id === 'impairment' && d && d.impairment.candidates.some(c => !(c.r.__imp?.status))) return 'flag';
  return '';""",
"""  if (p.flag && d) { try { return p.flag(st, d) ? 'flag' : ''; } catch (e) { return ''; } }
  if (p.id === 'lead' && d?.lead?.some?.(l => l.diffCost != null && Math.abs(l.diffCost) > 0.01)) return 'flag';
  if (p.id === 'depreciation' && d?.totals && Math.abs(d.totals.depDiff) > (state.engagement.materiality.trivial || 0)) return 'flag';
  if (p.id === 'impairment' && d?.impairment?.candidates?.some?.(c => !(c.r.__imp?.status))) return 'flag';
  return '';""", "pageStatus")
s = must(s, "el('span', { text: 'Overall conclusion on property, plant and equipment' })", "el('span', { text: 'Overall conclusion — ' + M.name })", "concl title")
s = must(s, "el('span', { text: 'Export the PPE file' })", "el('span', { text: 'Export the ' + M.code + ' file' })", "export title")
s = must(s, "'One sheet per working paper — E3, E3.1, E3.2, E3.3, E3.4, E3.5 — plus source data preserved verbatim, the cleaned listing, mapping, cleaning log, corrections, exceptions and the audit trail. Depreciation, casts and totals are live Excel formulas.'",
"'One sheet per working paper, plus source data preserved verbatim, the cleaned listing, mapping, cleaning log, corrections, exceptions and the audit trail. Totals and recalculations are live Excel formulas.'", "export blurb")
s = must(s, "function suggestConclusion(M, st) {\n  const d = st.derived, mat",
"""function suggestConclusion(M, st) {
  if (M.suggestConclusion) return M.suggestConclusion(st, specCtx(M, st));
  const d = st.derived, mat""", "suggest hook")
s = must(s, "  const dep = Math.abs(d.totals.depDiff) > state.engagement.materiality.trivial",
"""  if (!d?.totals || d.totals.depDiff == null) return `Based on the procedures performed, ${M.name.toLowerCase()} is fairly stated in all material respects${st.exceptions.length ? `, subject to clearance of ${st.exceptions.filter(x => x.disposition === 'open').length} open exception(s)` : ''}.`;
  const dep = Math.abs(d.totals.depDiff) > state.engagement.materiality.trivial""", "suggest generic")
s = must(s, "el('span', { class: 'v', text: 'PPE file' })", "el('span', { class: 'v', text: 'Audit file' })", "brand")
wr(p, s)

# ---------------------------------------------------------- xlsxfile.js
p = os.path.join(SRC, "xlsxfile.js"); s = rd(p)
s = must(s, "function build(state, moduleCode) {\n  const M = Modules.byCode[moduleCode];\n  const st = state.modules[moduleCode];",
"""function build(state, moduleCode) {
  const M = Modules.byCode[moduleCode];
  if (M.pages.some(p => p.render)) return buildSpecFile(state, moduleCode);
  const st = state.modules[moduleCode];""", "xlsxfile dispatch")
generic = rd(os.path.join(HERE, "tools", "buildSpecFile.js.txt"))
s = must(s, "\nreturn { build };\n})();\n", "\n" + generic + "\nreturn { build };\n})();\n", "xlsxfile tail")
wr(p, s)

# ------------------------------------------------------------ modules.js
p = os.path.join(SRC, "modules.js"); s = rd(p)
s = must(s, "const ALL = [TB, PPEModule, AR];\nreturn { ALL, byCode: Object.fromEntries(ALL.map(m => [m.code, m])), AR_BUCKETS };",
"""const ALL = [TB, PPEModule, AR];
const byCode = Object.fromEntries(ALL.map(m => [m.code, m]));
const register = m => { if (!byCode[m.code]) { ALL.push(m); byCode[m.code] = m; } };
return { ALL, byCode, AR_BUCKETS, register };""", "modules register")
wr(p, s)

# --------------------------------------------------------------- build.py
p = os.path.join(HERE, "build.py"); s = rd(p)
s = must(s, '    core = read("core.js")\n    ppe = read("ppe.js")',
'''    core = read("core.js")
    spec = read("spec.js")
    ppe = read("ppe.js")
    # declarative modules in src/modules/*.js, alphabetical, each self-registering
    mdir = os.path.join(SRC, "modules")
    extra = ""
    if os.path.isdir(mdir):
        for fn in sorted(os.listdir(mdir)):
            if fn.endswith(".js"):
                extra += f"\\n<script>/* module {fn} */\\n" + read("modules", fn) + "\\n</script>"''', "build reads")
s = must(s, "<script>/* core */\n{core}\n</script>", "<script>/* core */\n{core}\n</script>\n<script>/* spec */\n{spec}\n</script>", "build spec tag")
s = must(s, "<script>/* modules */\n{modules}\n</script>", "<script>/* modules */\n{modules}\n</script>{extra}", "build extra tag")
s = must(s, "len(css)+len(core)+len(ppe)", "len(css)+len(core)+len(spec)+len(ppe)+len(extra)", "build size")
wr(p, s)
os.makedirs(os.path.join(SRC, "modules"), exist_ok=True)
print("patched: ui.js, xlsxfile.js, modules.js, build.py; src/modules/ ready")
