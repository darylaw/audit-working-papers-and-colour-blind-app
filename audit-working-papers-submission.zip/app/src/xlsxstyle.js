/* ==========================================================================
   xlsxstyle.js -- a small .xlsx writer that keeps cell formatting.

   The vendored SheetJS community build throws every style away on write, so
   an exported working paper arrives in Excel with no bold headings, no rules
   under totals, no wrapped prose and no frozen header. This writes the OOXML
   package itself -- and the zip around it -- so the app can hand Excel bold,
   fills, borders, alignment, number formats, column widths, frozen panes and
   print titles.

   Takes the SheetJS-shaped workbook the app already builds:

     wb = { SheetNames: [...], Sheets: { name: ws } }
     ws = { 'A1': cell, ..., '!ref', '!cols', '!merges', '!rows',
            '!view', '!printSetup' }
     cell = { t:'s'|'n'|'b'|'d', v, f?:'SUM(B2:B9)', z?:'#,##0.00', s?:style }

   The style descriptor (cell.s) -- every key optional:

     bold, italic, underline, strike   true
     size                              points, default 11
     color                             '#152238'  (font colour)
     font                              'Calibri'
     fill                              '#c9a227'  (solid background)
     border                            'thin'                       full box
                                     | { top, bottom, left, right, all }
                                       each 'thin'|'medium'|'double'|'hair'
                                       or { style, color }
     align                             { h:'left'|'center'|'right'|'fill'
                                            |'justify'|'centerContinuous',
                                         v:'top'|'center'|'bottom',
                                         wrap:true, indent:2, rotate:90 }
     numFmt                            '#,##0.00'   (beats cell.z)

     ws['!view']       { freeze:{r,c}, gridlines:false, zoom:90 }
     ws['!printSetup'] { landscape:true, fitToWidth:1, fitToHeight:0,
                         repeatRows:[8,9], repeatCols:[0,0], paper:9 }

     StyledXLSX.write(wb)           -> Uint8Array
     StyledXLSX.writeFile(wb, name) -> browser download, or disk under Node
   ========================================================================== */

const StyledXLSX = (() => {

/* ---------------------------------------------------------------- bytes -- */

/* Our own UTF-8 encoder: TextEncoder is missing from some of the sandboxed
   contexts this file is loaded into (the headless test vm, older WebViews). */
const utf8 = str => {
  const s = String(str), out = [];
  for (let i = 0; i < s.length; i++) {
    let c = s.charCodeAt(i);
    if (c >= 0xd800 && c <= 0xdbff && i + 1 < s.length) {
      const d = s.charCodeAt(i + 1);
      if (d >= 0xdc00 && d <= 0xdfff) { c = 0x10000 + ((c - 0xd800) << 10) + (d - 0xdc00); i++; }
    }
    if (c < 0x80) out.push(c);
    else if (c < 0x800) out.push(0xc0 | (c >> 6), 0x80 | (c & 63));
    else if (c < 0x10000) out.push(0xe0 | (c >> 12), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
    else out.push(0xf0 | (c >> 18), 0x80 | ((c >> 12) & 63), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
  }
  return new Uint8Array(out);
};

const CRC_TABLE = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c; }
  return t;
})();

const crc32 = data => {
  const b = typeof data === 'string' ? utf8(data) : data;
  let c = -1;
  for (let i = 0; i < b.length; i++) c = CRC_TABLE[(c ^ b[i]) & 0xff] ^ (c >>> 8);
  return (c ^ -1) >>> 0;
};

/* ------------------------------------------------------------------ zip -- */

/* Stored (method 0) only. write() is synchronous, and the only deflate this
   file could reach -- CompressionStream -- is async and absent under Node
   here; a working paper that opens is worth more than one that is small. */
const dosStamp = d => ({
  time: ((d.getHours() & 31) << 11) | ((d.getMinutes() & 63) << 5) | ((d.getSeconds() / 2) & 31),
  date: (((d.getFullYear() - 1980) & 127) << 9) | (((d.getMonth() + 1) & 15) << 5) | (d.getDate() & 31)
});

function zip(files) {
  const { time, date } = dosStamp(new Date());
  const local = [], central = [];
  let offset = 0, cdSize = 0;
  for (const f of files) {
    const nb = utf8(f.name), n = f.data.length, crc = crc32(f.data);
    const lh = new Uint8Array(30 + nb.length), lv = new DataView(lh.buffer);
    lv.setUint32(0, 0x04034b50, true); lv.setUint16(4, 20, true); lv.setUint16(6, 0x0800, true);
    lv.setUint16(8, 0, true); lv.setUint16(10, time, true); lv.setUint16(12, date, true);
    lv.setUint32(14, crc, true); lv.setUint32(18, n, true); lv.setUint32(22, n, true);
    lv.setUint16(26, nb.length, true); lv.setUint16(28, 0, true);
    lh.set(nb, 30);
    local.push(lh, f.data);

    const cd = new Uint8Array(46 + nb.length), cv = new DataView(cd.buffer);
    cv.setUint32(0, 0x02014b50, true); cv.setUint16(4, 20, true); cv.setUint16(6, 20, true);
    cv.setUint16(8, 0x0800, true); cv.setUint16(10, 0, true);
    cv.setUint16(12, time, true); cv.setUint16(14, date, true);
    cv.setUint32(16, crc, true); cv.setUint32(20, n, true); cv.setUint32(24, n, true);
    cv.setUint16(28, nb.length, true); cv.setUint16(30, 0, true); cv.setUint16(32, 0, true);
    cv.setUint16(34, 0, true); cv.setUint16(36, 0, true); cv.setUint32(38, 0, true);
    cv.setUint32(42, offset, true);
    cd.set(nb, 46);
    central.push(cd);
    offset += lh.length + n; cdSize += cd.length;
  }
  const eocd = new Uint8Array(22), ev = new DataView(eocd.buffer);
  ev.setUint32(0, 0x06054b50, true); ev.setUint16(4, 0, true); ev.setUint16(6, 0, true);
  ev.setUint16(8, files.length, true); ev.setUint16(10, files.length, true);
  ev.setUint32(12, cdSize, true); ev.setUint32(16, offset, true); ev.setUint16(20, 0, true);

  const parts = local.concat(central, [eocd]);
  const total = parts.reduce((s, p) => s + p.length, 0);
  const out = new Uint8Array(total);
  let at = 0;
  for (const p of parts) { out.set(p, at); at += p.length; }
  return out;
}

/* ------------------------------------------------------------------ xml -- */

/* Control characters below 0x20 (bar tab/LF/CR) are illegal in XML 1.0 at any
   escaping, so they have to go rather than be encoded. */
const esc = v => String(v == null ? '' : v)
  .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '')
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;').replace(/'/g, '&apos;');

const DECL = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\r\n';
const MAXSTR = 32767;                                   // Excel's cell text limit
const clip = s => { const x = String(s); return x.length > MAXSTR ? x.slice(0, MAXSTR) : x; };

const colName = c => { let s = ''; for (let n = c + 1; n > 0;) { const r = (n - 1) % 26; s = String.fromCharCode(65 + r) + s; n = (n - r - 1) / 26; } return s; };
const addr = (c, r) => colName(c) + (r + 1);
const parseAddr = a => { const m = /^([A-Z]+)(\d+)$/.exec(a); if (!m) return null; let c = 0; for (let i = 0; i < m[1].length; i++) c = c * 26 + (m[1].charCodeAt(i) - 64); return { c: c - 1, r: +m[2] - 1 }; };

const num = n => Number.isFinite(n) ? String(n) : null;
const hex = c => { const h = String(c || '').replace('#', '').trim().toUpperCase(); return /^[0-9A-F]{6}$/.test(h) ? 'FF' + h : (/^[0-9A-F]{8}$/.test(h) ? h : null); };

/* ------------------------------------------------------------- date -> serial */

/* Matches SheetJS's datenum so a round-trip through XLSX.read returns the same
   Date: local-time based, epoch 30 Dec 1899, 1900 leap-year bug included. */
const BASE = new Date(1899, 11, 30, 0, 0, 0);
const datenum = d => {
  const dn = BASE.getTime() + (d.getTimezoneOffset() - BASE.getTimezoneOffset()) * 60000;
  return (d.getTime() - dn) / 86400000;
};

/* --------------------------------------------------------------- styles -- */

const DEFAULT_FONT = '<font><sz val="11"/><color rgb="FF000000"/><name val="Calibri"/><family val="2"/></font>';
const EDGES = ['left', 'right', 'top', 'bottom'];       // schema order inside <border>
const STYLES = { thin: 1, medium: 1, thick: 1, double: 1, hair: 1, dotted: 1, dashed: 1, dashDot: 1, mediumDashed: 1, slantDashDot: 1 };

const edgeOf = e => {
  if (!e) return null;
  if (typeof e === 'string') return STYLES[e] ? { style: e } : null;
  const st = e.style || e.s;
  return STYLES[st] ? { style: st, color: hex(e.color) } : null;
};

/* One canonical shape for a descriptor, so two spellings of the same style
   hash to the same cellXfs entry. */
function normal(s, z) {
  if (!s && !z) return null;
  s = s || {};
  const o = {};
  if (s.bold) o.b = 1;
  if (s.italic) o.i = 1;
  if (s.underline) o.u = s.underline === 'double' ? 'double' : 'single';
  if (s.strike) o.st = 1;
  if (s.size) o.sz = +s.size;
  const fc = hex(s.color); if (fc) o.fc = fc;
  if (s.font) o.fn = String(s.font);
  const fill = hex(typeof s.fill === 'object' && s.fill ? s.fill.color || s.fill.fg : s.fill);
  if (fill) o.fl = fill;

  const b = s.border;
  if (b) {
    const box = typeof b === 'string' ? b : b.all;
    const bo = {};
    for (const e of EDGES) { const d = edgeOf(b && typeof b === 'object' ? (b[e] || box) : box); if (d) bo[e] = d; }
    if (Object.keys(bo).length) o.bd = bo;
  }
  const a = s.align;
  if (a) {
    const al = {};
    if (a.h) al.h = a.h;
    if (a.v) al.v = a.v;
    if (a.wrap) al.w = 1;
    if (a.indent) al.ind = +a.indent;
    if (a.rotate) al.rot = +a.rotate;
    if (Object.keys(al).length) o.al = al;
  }
  const nf = s.numFmt || z;
  if (nf) o.nf = String(nf);
  return Object.keys(o).length ? o : null;
}

function styleTable() {
  const pool = (arr, map, xml) => { const i = map.get(xml); if (i !== undefined) return i; const j = arr.length; arr.push(xml); map.set(xml, j); return j; };
  const fonts = [], fills = [], borders = [], xfs = [], numFmts = [];
  const fontMap = new Map(), fillMap = new Map(), borderMap = new Map(), xfMap = new Map(), nfMap = new Map();

  pool(fonts, fontMap, DEFAULT_FONT);
  /* fills 0 and 1 are fixed by the format: Excel repairs the file otherwise. */
  pool(fills, fillMap, '<fill><patternFill patternType="none"/></fill>');
  pool(fills, fillMap, '<fill><patternFill patternType="gray125"/></fill>');
  pool(borders, borderMap, '<border><left/><right/><top/><bottom/><diagonal/></border>');
  xfs.push('<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>');
  xfMap.set('0|0|0|0|', 0);

  const numFmtId = code => {
    if (!code || code === 'General') return 0;
    let id = nfMap.get(code);
    if (id === undefined) { id = 164 + nfMap.size; nfMap.set(code, id); numFmts.push(`<numFmt numFmtId="${id}" formatCode="${esc(code)}"/>`); }
    return id;
  };

  const fontId = o => {
    if (!(o.b || o.i || o.u || o.st || o.sz || o.fc || o.fn)) return 0;
    const xml = '<font>' + (o.b ? '<b/>' : '') + (o.i ? '<i/>' : '') + (o.st ? '<strike/>' : '') +
      (o.u ? `<u${o.u === 'double' ? ' val="double"' : ''}/>` : '') +
      `<sz val="${o.sz || 11}"/><color rgb="${o.fc || 'FF000000'}"/><name val="${esc(o.fn || 'Calibri')}"/><family val="2"/></font>`;
    return pool(fonts, fontMap, xml);
  };
  const fillId = o => o.fl ? pool(fills, fillMap, `<fill><patternFill patternType="solid"><fgColor rgb="${o.fl}"/><bgColor indexed="64"/></patternFill></fill>`) : 0;
  const borderId = o => {
    if (!o.bd) return 0;
    let xml = '<border>';
    for (const e of EDGES) { const d = o.bd[e]; xml += d ? `<${e} style="${d.style}">${d.color ? `<color rgb="${d.color}"/>` : '<color indexed="64"/>'}</${e}>` : `<${e}/>`; }
    return pool(borders, borderMap, xml + '<diagonal/></border>');
  };
  const alignXml = o => {
    if (!o.al) return '';
    const a = o.al;
    return '<alignment' + (a.h ? ` horizontal="${a.h}"` : '') + (a.v ? ` vertical="${a.v}"` : '') +
      (a.w ? ' wrapText="1"' : '') + (a.ind ? ` indent="${a.ind}"` : '') + (a.rot ? ` textRotation="${a.rot}"` : '') + '/>';
  };

  return {
    /* the de-duplication that keeps a 350-row sheet down to a handful of xfs */
    id(s, z) {
      const o = normal(s, z);
      if (!o) return 0;
      const nf = numFmtId(o.nf), fo = fontId(o), fi = fillId(o), bo = borderId(o), al = alignXml(o);
      const key = `${nf}|${fo}|${fi}|${bo}|${al}`;
      let i = xfMap.get(key);
      if (i !== undefined) return i;
      i = xfs.length;
      xfs.push(`<xf numFmtId="${nf}" fontId="${fo}" fillId="${fi}" borderId="${bo}" xfId="0"` +
        (nf ? ' applyNumberFormat="1"' : '') + (fo ? ' applyFont="1"' : '') + (fi ? ' applyFill="1"' : '') +
        (bo ? ' applyBorder="1"' : '') + (al ? ' applyAlignment="1"' : '') +
        (al ? '>' + al + '</xf>' : '/>'));
      xfMap.set(key, i);
      return i;
    },
    xml() {
      return DECL + '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' +
        (numFmts.length ? `<numFmts count="${numFmts.length}">${numFmts.join('')}</numFmts>` : '') +
        `<fonts count="${fonts.length}">${fonts.join('')}</fonts>` +
        `<fills count="${fills.length}">${fills.join('')}</fills>` +
        `<borders count="${borders.length}">${borders.join('')}</borders>` +
        '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>' +
        `<cellXfs count="${xfs.length}">${xfs.join('')}</cellXfs>` +
        '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>' +
        '<dxfs count="0"/><tableStyles count="0" defaultTableStyle="TableStyleMedium2" defaultPivotStyle="PivotStyleLight16"/></styleSheet>';
    },
    counts: () => ({ fonts: fonts.length, fills: fills.length, borders: borders.length, xfs: xfs.length, numFmts: numFmts.length })
  };
}

/* ----------------------------------------------------------- sheet names -- */

const cleanName = n => {
  let s = String(n == null ? '' : n).replace(/[\[\]\*\?\/\\:]/g, '').replace(/^'+|'+$/g, '').slice(0, 31).trim();
  return s || 'Sheet';
};
function uniqueNames(names) {
  const seen = new Map(), out = [];
  for (const raw of names) {
    let n = cleanName(raw), k = n.toLowerCase();
    if (seen.has(k)) {
      for (let i = 2; ; i++) { const cand = n.slice(0, 31 - (' (' + i + ')').length) + ' (' + i + ')'; if (!seen.has(cand.toLowerCase())) { n = cand; k = cand.toLowerCase(); break; } }
    }
    seen.set(k, 1); out.push(n);
  }
  return out;
}
const quoteName = n => "'" + String(n).replace(/'/g, "''") + "'";

/* ---------------------------------------------------------------- cells -- */

const cellsOf = ws => {
  const list = [];
  for (const k in ws) {
    if (k.charCodeAt(0) === 33) continue;               // '!'
    const a = parseAddr(k);
    if (a && ws[k] != null) list.push({ a, k, c: ws[k] });
  }
  return list;
};

function refOf(ws, cells) {
  const r = ws['!ref'];
  if (r && /^[A-Z]+\d+(:[A-Z]+\d+)?$/.test(r)) {
    const p = r.split(':'), s = parseAddr(p[0]), e = parseAddr(p[1] || p[0]);
    if (s && e) {
      let ok = true;
      for (const { a } of cells) if (a.r < s.r || a.r > e.r || a.c < s.c || a.c > e.c) { ok = false; break; }
      if (ok) return r;                                  // honour it unless it is stale
    }
  }
  if (!cells.length) return 'A1';
  let r0 = Infinity, c0 = Infinity, r1 = 0, c1 = 0;
  for (const { a } of cells) { if (a.r < r0) r0 = a.r; if (a.c < c0) c0 = a.c; if (a.r > r1) r1 = a.r; if (a.c > c1) c1 = a.c; }
  return addr(c0, r0) + ':' + addr(c1, r1);
}

function cellXml(ref, cell, sst, table) {
  let { t, v, f, z, s } = cell;
  if (v instanceof Date) t = 'd';
  if (!t) t = typeof v === 'number' ? 'n' : typeof v === 'boolean' ? 'b' : v == null ? 'z' : 's';
  if (t === 'd' && !(v instanceof Date)) { const d = new Date(v); if (!isNaN(d)) v = d; else t = 's'; }

  const sid = table.id(s, t === 'd' ? ((s && s.numFmt) || z || 'dd/mm/yyyy') : z);
  const sa = sid ? ` s="${sid}"` : '';
  const fx = f ? `<f>${esc(String(f).replace(/^=/, ''))}</f>` : '';

  if (t === 'd') { const n = num(datenum(v)); return n == null ? `<c r="${ref}"${sa}/>` : `<c r="${ref}"${sa}>${fx}<v>${n}</v></c>`; }
  if (t === 'b') return `<c r="${ref}"${sa} t="b">${fx}<v>${v ? 1 : 0}</v></c>`;
  if (t === 'e') return `<c r="${ref}"${sa} t="e"><v>${esc(v == null ? '#VALUE!' : v)}</v></c>`;
  if (t === 'n') {
    const n = num(typeof v === 'number' ? v : parseFloat(v));
    /* a formula with no cached value is dropped by some readers; 0 plus
       fullCalcOnLoad in workbook.xml makes Excel fill it in on open */
    if (fx) return `<c r="${ref}"${sa}>${fx}<v>${n == null ? 0 : n}</v></c>`;
    return n == null ? `<c r="${ref}"${sa}/>` : `<c r="${ref}"${sa}><v>${n}</v></c>`;
  }
  if (t === 'z' || v == null) return fx ? `<c r="${ref}"${sa}>${fx}<v>0</v></c>` : (sid ? `<c r="${ref}"${sa}/>` : '');
  const str = clip(v);
  if (fx) return `<c r="${ref}"${sa} t="str">${fx}<v>${esc(str)}</v></c>`;
  return `<c r="${ref}"${sa} t="s"><v>${sst.id(str)}</v></c>`;
}

/* ------------------------------------------------------------ worksheet -- */

function sheetXml(ws, sst, table, first) {
  const cells = cellsOf(ws);
  const ref = refOf(ws, cells);
  const view = ws['!view'] || {}, ps = ws['!printSetup'] || null;

  const rows = new Map();
  for (const c of cells) { let r = rows.get(c.a.r); if (!r) rows.set(c.a.r, r = []); r.push(c); }
  const rowNums = [...rows.keys()].sort((a, b) => a - b);
  const rowMeta = ws['!rows'] || [];

  let data = '';
  for (const rn of rowNums) {
    const list = rows.get(rn).sort((a, b) => a.a.c - b.a.c);
    const m = rowMeta[rn] || {};
    const ht = m.hpt != null ? m.hpt : (m.hpx != null ? m.hpx * 0.75 : null);
    let inner = '';
    for (const { a, c } of list) inner += cellXml(addr(a.c, a.r), c, sst, table);
    if (!inner && !ht && !m.hidden) continue;
    data += `<row r="${rn + 1}"` + (ht ? ` ht="${ht}" customHeight="1"` : '') + (m.hidden ? ' hidden="1"' : '') + `>${inner}</row>`;
  }

  /* sheetPr, dimension, sheetViews, sheetFormatPr, cols, sheetData,
     mergeCells, pageMargins, pageSetup -- Excel repairs anything else. */
  let xml = DECL + '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">';
  if (ps && (ps.fitToWidth || ps.fitToHeight != null)) xml += '<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>';
  xml += `<dimension ref="${ref}"/>`;

  const fr = view.freeze, zoom = view.zoom ? ` zoomScale="${view.zoom}" zoomScaleNormal="${view.zoom}"` : '';
  let sv = `<sheetView${view.gridlines === false ? ' showGridLines="0"' : ''}${first ? ' tabSelected="1"' : ''}${zoom} workbookViewId="0">`;
  if (fr && ((fr.r | 0) > 0 || (fr.c | 0) > 0)) {
    const xs = fr.c | 0, ys = fr.r | 0, tl = addr(xs, ys);
    const pane = xs && ys ? 'bottomRight' : ys ? 'bottomLeft' : 'topRight';
    sv += `<pane${xs ? ` xSplit="${xs}"` : ''}${ys ? ` ySplit="${ys}"` : ''} topLeftCell="${tl}" activePane="${pane}" state="frozen"/>` +
      `<selection pane="${pane}" activeCell="${tl}" sqref="${tl}"/>`;
  }
  xml += `<sheetViews>${sv}</sheetView></sheetViews><sheetFormatPr defaultRowHeight="15"/>`;

  const cols = ws['!cols'];
  if (cols && cols.length) {
    let c = '';
    cols.forEach((col, i) => {
      if (!col) return;
      const wch = col.wch != null ? col.wch : (col.wpx != null ? col.wpx / 7 : col.width);
      if (wch == null && !col.hidden) return;
      const w = wch == null ? 8.43 : Math.round(((wch * 7 + 5) / 7) * 256) / 256;
      c += `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"${col.hidden ? ' hidden="1"' : ''}/>`;
    });
    if (c) xml += `<cols>${c}</cols>`;
  }
  xml += `<sheetData>${data}</sheetData>`;

  const merges = (ws['!merges'] || []).filter(m => m && m.s && m.e && (m.s.r !== m.e.r || m.s.c !== m.e.c));
  if (merges.length) xml += `<mergeCells count="${merges.length}">` +
    merges.map(m => `<mergeCell ref="${addr(m.s.c, m.s.r)}:${addr(m.e.c, m.e.r)}"/>`).join('') + '</mergeCells>';

  const mg = (ps && ps.margins) || {};
  xml += `<pageMargins left="${mg.left || 0.5}" right="${mg.right || 0.5}" top="${mg.top || 0.6}" bottom="${mg.bottom || 0.6}" header="${mg.header || 0.3}" footer="${mg.footer || 0.3}"/>`;
  if (ps) xml += '<pageSetup' + ` paperSize="${ps.paper || 9}"` + (ps.landscape ? ' orientation="landscape"' : ' orientation="portrait"') +
    (ps.fitToWidth ? ` fitToWidth="${ps.fitToWidth}"` : '') +
    (ps.fitToWidth || ps.fitToHeight != null ? ` fitToHeight="${ps.fitToHeight || 0}"` : '') +
    (ps.scale ? ` scale="${ps.scale}"` : '') + '/>';
  return xml + '</worksheet>';
}

/* ---------------------------------------------------------------- parts -- */

function sharedStrings() {
  const map = new Map(), list = [];
  let total = 0;
  return {
    id(s) { total++; let i = map.get(s); if (i === undefined) { i = list.length; list.push(s); map.set(s, i); } return i; },
    xml() {
      return DECL + `<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="${total}" uniqueCount="${list.length}">` +
        list.map(s => `<si><t xml:space="preserve">${esc(s)}</t></si>`).join('') + '</sst>';
    },
    count: () => list.length
  };
}

function parts(wb) {
  const names = uniqueNames(wb.SheetNames || Object.keys(wb.Sheets || {}));
  const sheets = names.map((n, i) => wb.Sheets[(wb.SheetNames || [])[i]] || wb.Sheets[n] || {});
  const sst = sharedStrings(), table = styleTable();
  const sheetXmls = sheets.map((ws, i) => sheetXml(ws || {}, sst, table, i === 0));

  const defNames = [];
  sheets.forEach((ws, i) => {
    const ps = ws && ws['!printSetup'];
    if (!ps) return;
    const bits = [];
    if (ps.repeatCols) bits.push(`${quoteName(names[i])}!$${colName(ps.repeatCols[0])}:$${colName(ps.repeatCols[1] != null ? ps.repeatCols[1] : ps.repeatCols[0])}`);
    if (ps.repeatRows) bits.push(`${quoteName(names[i])}!$${ps.repeatRows[0] + 1}:$${(ps.repeatRows[1] != null ? ps.repeatRows[1] : ps.repeatRows[0]) + 1}`);
    if (bits.length) defNames.push(`<definedName name="_xlnm.Print_Titles" localSheetId="${i}">${esc(bits.join(','))}</definedName>`);
  });

  const workbook = DECL +
    '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">' +
    '<bookViews><workbookView xWindow="0" yWindow="0" windowWidth="20000" windowHeight="12000"/></bookViews>' +
    '<sheets>' + names.map((n, i) => `<sheet name="${esc(n)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('') + '</sheets>' +
    (defNames.length ? `<definedNames>${defNames.join('')}</definedNames>` : '') +
    '<calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>';

  const n = names.length;
  const wbRels = DECL + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
    names.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('') +
    `<Relationship Id="rId${n + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>` +
    `<Relationship Id="rId${n + 2}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>` +
    '</Relationships>';

  const types = DECL + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
    '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
    '<Default Extension="xml" ContentType="application/xml"/>' +
    '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>' +
    names.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('') +
    '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' +
    '<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>' +
    '</Types>';

  const rels = DECL + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
    '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>' +
    '</Relationships>';

  /* styles.xml and sharedStrings.xml are serialised last: the sheets fill them. */
  const out = {
    '[Content_Types].xml': types,
    '_rels/.rels': rels,
    'xl/workbook.xml': workbook,
    'xl/_rels/workbook.xml.rels': wbRels,
    'xl/styles.xml': table.xml(),
    'xl/sharedStrings.xml': sst.xml()
  };
  sheetXmls.forEach((x, i) => { out[`xl/worksheets/sheet${i + 1}.xml`] = x; });
  return { files: out, names, styleCounts: table.counts(), stringCount: sst.count() };
}

/* --------------------------------------------------------------- public -- */

const ORDER = ['[Content_Types].xml', '_rels/.rels', 'xl/workbook.xml', 'xl/_rels/workbook.xml.rels', 'xl/styles.xml', 'xl/sharedStrings.xml'];

function write(wb) {
  if (!wb || !wb.Sheets) throw new Error('StyledXLSX.write: not a workbook');
  const p = parts(wb);
  const keys = ORDER.concat(Object.keys(p.files).filter(k => ORDER.indexOf(k) < 0));
  return zip(keys.map(name => ({ name, data: utf8(p.files[name]) })));
}

function writeFile(wb, name) {
  const bytes = write(wb);
  const fname = String(name || 'workbook.xlsx');
  if (typeof document !== 'undefined' && typeof Blob !== 'undefined' && typeof URL !== 'undefined' && URL.createObjectURL) {
    const url = URL.createObjectURL(new Blob([bytes], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }));
    const a = document.createElement('a');
    a.href = url; a.download = fname; document.body.appendChild(a); a.click();
    setTimeout(() => { document.body.removeChild(a); URL.revokeObjectURL(url); }, 0);
    return fname;
  }
  const req = typeof require === 'function' ? require : (typeof module !== 'undefined' && module && module.require ? module.require.bind(module) : null);
  if (req) { req('fs').writeFileSync(fname, bytes); return fname; }
  throw new Error('StyledXLSX.writeFile: no browser download and no fs');
}

return { write, writeFile, _parts: parts, _crc32: crc32, _utf8: utf8, _datenum: datenum, _colName: colName, _escape: esc };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = StyledXLSX;
