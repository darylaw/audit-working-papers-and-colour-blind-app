/* ==========================================================================
   spec.js -- declarative working-paper pages.

   A module page may provide  render(st, ctx) -> Spec[]  instead of a custom
   renderer. The shell turns specs into DOM (SpecUI) and into worksheets
   (SpecXL). Modules therefore never touch ui.js or xlsxfile.js.

   ctx = { eng, cfg, d (derived), recs (records not excluded), all (records),
           money, money0, pct, fmtDate, r2, pm, trivial }

   Spec types
     { type:'heading', text }
     { type:'note', html, tone:'info'|'warn'|'bad' }
     { type:'stats', items:[{ label, value, cls:'ok'|'warn'|'bad'|'' }] }
     { type:'controls', items:[{ key, label, kind:'number'|'text'|'date'|'select'|'check',
                                 options:[[value,label]], help }] }        // bound to st.config[key]
     { type:'checklist', store, items:[{ id, text, group }], answers:['Y','N','n/a'], categories?:[] }
                                              // cfg[store][id] = { answer, comment, categories }
     { type:'table', title, columns:[col], rows:[row], totals, footnote, maxHeight,
       emptyText }
         col = { key, label, type:'text'|'num'|'date'|'pct'|'int'|'chip', dp, emphasis,
                 sum,                     // include in totals row
                 input:'number'|'text'|'date'|'select', options:[..],   // auditor field
                 chipClass: v => 'ok'|'warn'|'bad'|'info'|'grey',
                 formula: (rowIndex1, colLetterOf) => 'excel formula'   // export only
               }
         row = { ...values, __rec }        // __rec: input columns store to __rec.__wp[pageId][key]
                                            // without __rec: input columns store to cfg[key + ':' + row.__key]
   ========================================================================== */

const SpecUI = (() => {
const el = (t, a = {}, kids = []) => {
  const n = document.createElement(t);
  if (t === 'input' || t === 'textarea') n.autocomplete = 'off';
  for (const [k, v] of Object.entries(a)) {
    if (k === 'class') n.className = v; else if (k === 'html') Core.richText(n, v); else if (k === 'text') n.textContent = v;
    else if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
    else if (v !== null && v !== undefined && v !== false) n.setAttribute(k, v);
  }
  (Array.isArray(kids) ? kids : [kids]).forEach(c => c && n.append(c));
  return n;
};
const money = n => n == null || n === '' || isNaN(n) ? '' : Number(n).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const numCls = v => 'num mono' + (typeof v === 'number' && v < 0 ? ' neg' : '');

function render(specs, pageId, st, hooks) {
  /* hooks: { onChange(structural:boolean), soft(), trail(event, detail) } */
  return specs.map(s => renderOne(s, pageId, st, hooks)).filter(Boolean);
}

function renderOne(s, pageId, st, H) {
  switch (s.type) {
    case 'heading': return el('h4', { style: 'margin:20px 0 8px', text: s.text });
    case 'note': return el('div', { class: 'note' + (s.tone && s.tone !== 'info' ? ' ' + s.tone : ''), html: s.html });
    case 'stats': return el('dl', { class: 'stats', style: 'margin:14px 0' }, s.items.map(i => el('div', {}, [el('dt', { text: i.label }), el('dd', { class: i.cls || '', text: i.value ?? '' })])));
    case 'controls': return el('div', { class: 'ctl' }, s.items.map(c => control(c, st, H)));
    case 'checklist': return checklist(s, st, H);
    case 'table': return table(s, pageId, st, H);
    case 'html': return s.node;
  }
  return null;
}

function control(c, st, H) {
  const cfg = st.config, k = 'ctl-' + c.key;
  let input;
  const commit = v => { cfg[c.key] = v; H.trail('Configuration changed', `${c.label} → ${v}`); H.onChange(false); };
  if (c.kind === 'select') input = el('select', { onchange: e => { commit(e.target.value); H.render(); } },
    (c.options || []).map(o => { const [v, l] = Array.isArray(o) ? o : [o, o]; return el('option', { value: v, selected: String(cfg[c.key]) === String(v) ? 'selected' : null }, el('span', { text: l })); }));
  else if (c.kind === 'check') input = el('div', {}, el('label', { class: 'small' }, [el('input', { type: 'checkbox', checked: cfg[c.key] ? 'checked' : null, onchange: e => { commit(e.target.checked); H.render(); } }), el('span', { text: cfg[c.key] ? 'Enabled' : 'Disabled' })]));
  else if (c.kind === 'number') input = Core.NumBox.make({ k, value: cfg[c.key], commit, refresh: H.soft });
  else input = el('input', { type: c.kind === 'date' ? 'date' : 'text', 'data-k': k, value: cfg[c.key] ?? '',
    oninput: e => { commit(e.target.value); H.soft(); } });
  return el('label', { class: 'fld' }, [el('span', { text: c.label }), input, c.help ? el('span', { class: 'help', text: c.help }) : null]);
}

function checklist(s, st, H) {
  const cfg = st.config; cfg[s.store] = cfg[s.store] || {};
  const answers = s.answers || ['Y', 'N', 'n/a'];
  const t = el('table', { class: 'sched' });
  t.append(el('thead', {}, el('tr', {}, ['Ref', 'Item', 'Answer', ...(s.categories ? ['Applies to'] : []), 'Response / evidence'].map(h => el('th', { text: h })))));
  t.append(el('tbody', {}, s.items.map(it => {
    const a = (cfg[s.store][it.id] = cfg[s.store][it.id] || { answer: '', comment: '', categories: [] });
    return el('tr', { class: a.answer === 'Y' ? 'yes' : '' }, [
      el('td', { class: 'mono', text: it.id }), el('td', { class: 'wrapcell', text: it.text }),
      el('td', { class: 'inp' }, el('select', { onchange: e => { a.answer = e.target.value; H.trail('Checklist', `${it.id} = ${a.answer}`); H.onChange(false); H.render(); } },
        ['', ...answers].map(o => el('option', { value: o, selected: a.answer === o ? 'selected' : null }, el('span', { text: o || '—' }))))),
      s.categories ? el('td', { class: 'inp' }, el('select', { multiple: 'multiple', size: Math.min(3, s.categories.length), disabled: a.answer !== 'Y' ? 'disabled' : null,
        onchange: e => { a.categories = [...e.target.selectedOptions].map(o => o.value); H.onChange(false); H.render(); } },
        s.categories.map(c => el('option', { value: c, selected: a.categories.includes(c) ? 'selected' : null }, el('span', { text: c }))))) : null,
      el('td', { class: 'inp wide' }, el('input', { type: 'text', 'data-k': 'chk-' + s.store + it.id, value: a.comment, oninput: e => { a.comment = e.target.value; } }))
    ]);
  })));
  return el('div', { class: 'tw', style: 'max-height:none' }, t);
}

function table(s, pageId, st, H) {
  const cols = s.columns;
  const t = el('table', { class: 'sched' });
  t.append(el('thead', {}, el('tr', {}, cols.map(c => el('th', { class: ['num', 'pct', 'int'].includes(c.type) ? 'num' : '', text: c.label })))));
  const rows = s.rows || [];
  if (!rows.length) return el('div', { class: 'note', html: s.emptyText || 'Nothing to show.' });
  const sums = {};
  t.append(el('tbody', {}, rows.map((row, ri) => el('tr', { class: row.__cls || '' }, cols.map(c => {
    const v = row[c.key];
    if (c.sum && typeof v === 'number') sums[c.key] = (sums[c.key] || 0) + v;
    if (c.input) return inputCell(c, row, pageId, st, H);
    if (c.type === 'num') return el('td', { class: numCls(v) + (c.emphasis ? ' em' : '') + (c.flag && c.flag(v, row) ? ' badc' : ''), text: v == null ? '' : (c.dp != null ? Number(v).toFixed(c.dp) : money(v)) });
    if (c.type === 'int') return el('td', { class: 'num mono', text: v == null ? '' : Math.round(v) });
    if (c.type === 'pct') return el('td', { class: 'num mono', text: v == null || isNaN(v) ? '' : (Number(v) * 100).toFixed(c.dp ?? 1) + '%' });
    if (c.type === 'date') return el('td', { text: v instanceof Date ? Core.fmtDate(v) : (v || '') });
    if (c.type === 'chip') return el('td', {}, v ? el('span', { class: 'chip ' + (c.chipClass ? c.chipClass(v, row) : 'grey'), text: v }) : null);
    return el('td', { class: (c.emphasis ? 'em ' : '') + (c.wrap ? 'wrapcell' : ''), text: v == null ? '' : String(v) });
  })))));
  if (s.totals !== false && cols.some(c => c.sum)) {
    t.append(el('tfoot', {}, el('tr', {}, cols.map((c, i) => c.sum ? el('td', { class: numCls(sums[c.key]) + ' em', text: money(sums[c.key] || 0) }) : el('td', { class: 'em', text: i === 0 ? 'TOTAL' : '' })))));
  }
  const wrap = el('div', {}, [s.title ? el('h4', { style: 'margin:18px 0 8px', text: s.title }) : null,
    el('div', { class: 'tw', style: `max-height:${s.maxHeight || 'none'}` }, t),
    s.footnote ? el('p', { class: 'small muted', style: 'margin-top:8px', text: s.footnote }) : null]);
  return wrap;
}

function inputCell(c, row, pageId, st, H) {
  const rec = row.__rec;
  const store = rec ? ((rec.__wp = rec.__wp || {}), (rec.__wp[pageId] = rec.__wp[pageId] || {})) : st.config;
  const key = rec ? c.key : c.key + ':' + (row.__key ?? '');
  const cur = store[key] ?? '';
  const k = `in-${pageId}-${c.key}-${rec ? rec.__srcRow : row.__key}`;
  const commit = v => { store[key] = v; if (c.recompute !== false) H.onChange(false); H.soft(); };
  if (c.input === 'select') return el('td', { class: 'inp' }, el('select', { 'data-k': k, onchange: e => { store[key] = e.target.value; H.onChange(false); H.render(); } },
    ['', ...(c.options || [])].map(o => el('option', { value: o, selected: String(cur) === String(o) ? 'selected' : null }, el('span', { text: o || '—' })))));
  if (c.input === 'number') return el('td', { class: 'inp' }, Core.NumBox.make({ k, value: cur, commit, refresh: H.soft }));
  return el('td', { class: 'inp' + (c.wide ? ' wide' : '') }, el('input', { type: c.input, 'data-k': k, value: cur,
    oninput: e => commit(e.target.value) }));
}

return { render, el, money };
})();

/* --------------------------------------------------------------- export */
const SpecXL = (() => {
const C = XLSX.utils.encode_col;
const MONEY = '#,##0.00;[Red](#,##0.00)', PCT = '0.00%';
function put(ws, col, row, cell) {
  ws[C(col) + (row + 1)] = cell;
  const rng = XLSX.utils.decode_range(ws['!ref'] || 'A1');
  rng.e.c = Math.max(rng.e.c, col); rng.e.r = Math.max(rng.e.r, row);
  ws['!ref'] = XLSX.utils.encode_range(rng);
}
/* Append specs to an array-of-arrays plus a list of post-write cell ops. */
function toRows(specs, pageId, st, rowOffset = 0) {
  const a = [], ops = [];
  const cfg = st.config;
  for (const s of specs) {
    if (s.type === 'heading') { a.push([]); a.push([s.text]); }
    else if (s.type === 'note') { a.push([Core.plainText(s.html)]); }
    else if (s.type === 'stats') { s.items.forEach(i => a.push([i.label, i.value])); a.push([]); }
    else if (s.type === 'controls') { s.items.forEach(c => a.push([c.label, cfg[c.key] ?? ''])); a.push([]); }
    else if (s.type === 'checklist') {
      a.push(['Ref', 'Item', 'Answer', 'Applies to', 'Response / evidence']);
      s.items.forEach(it => { const v = (cfg[s.store] || {})[it.id] || {}; a.push([it.id, it.text, v.answer || '', (v.categories || []).join(', '), v.comment || '']); });
      a.push([]);
    }
    else if (s.type === 'table') {
      if (s.title) a.push([s.title]);
      a.push(s.columns.map(c => c.label));
      const first = a.length;
      (s.rows || []).forEach(row => a.push(s.columns.map(c => {
        if (c.input) { const rec = row.__rec; const store = rec ? (rec.__wp?.[pageId] || {}) : cfg; const v = store[rec ? c.key : c.key + ':' + (row.__key ?? '')]; return v === '' || v == null ? null : v; }
        const v = row[c.key]; return v instanceof Date ? Core.fmtDate(v) : (v == null ? null : v);
      })));
      const last = a.length - 1;
      s.columns.forEach((c, ci) => {
        for (let r = first; r <= last; r++) {
          if (c.formula) ops.push({ r, c: ci, cell: { t: 'n', f: c.formula(r + rowOffset + 1, i => C(i)), z: c.type === 'pct' ? PCT : MONEY } });
          else if (c.type === 'num' || c.input === 'number') ops.push({ r, c: ci, fmt: MONEY });
          else if (c.type === 'pct') ops.push({ r, c: ci, fmt: PCT });
        }
        if (c.sum && last >= first) ops.push({ r: last + 1, c: ci, cell: { t: 'n', f: `SUM(${C(ci)}${first + rowOffset + 1}:${C(ci)}${last + rowOffset + 1})`, z: MONEY } });
      });
      if (s.columns.some(c => c.sum) && last >= first) { a.push([]); ops.push({ r: last + 1, c: 0, cell: { t: 's', v: 'TOTAL' } }); }
      if (s.footnote) a.push([s.footnote]);
      a.push([]);
    }
  }
  return { a, ops };
}
function apply(ws, ops, offset) {
  for (const o of ops) {
    const ref = C(o.c) + (o.r + offset + 1);
    if (o.cell) put(ws, o.c, o.r + offset, o.cell);
    else if (o.fmt && ws[ref] && ws[ref].t === 'n') ws[ref].z = o.fmt;
  }
}
return { toRows, apply };
})();
