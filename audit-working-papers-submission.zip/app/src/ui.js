/* ==========================================================================
   ui.js -- the application shell.
   Modules that declare `pages` render as an audit file of working papers.
   Modules without pages fall back to the generic five-step flow.
   ========================================================================== */

const App = (() => {
const $ = s => document.querySelector(s);
const el = (t, a = {}, kids = []) => {
  const n = document.createElement(t);
  if (t === 'input' || t === 'textarea') n.autocomplete = 'off';
  for (const [k, v] of Object.entries(a)) {
    if (k === 'class') n.className = v;
    else if (k === 'html') Core.richText(n, v);
    else if (k === 'text') n.textContent = v;
    else if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
    else if (v !== null && v !== undefined && v !== false) n.setAttribute(k, v);
  }
  (Array.isArray(kids) ? kids : [kids]).forEach(c => c && n.append(c));
  return n;
};
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;' }[c]));
const money = n => n == null || n === '' || isNaN(n) ? '' :
  Number(n).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const money0 = n => n == null || n === '' || isNaN(n) ? '' : Number(n).toLocaleString(undefined, { maximumFractionDigits: 0 });
const pct = n => n == null || isNaN(n) ? '' : Number(n).toFixed(1) + '%';
const numCls = v => 'num mono' + (v < 0 ? ' neg' : '');

/* ------------------------------------------------------------- state */
const blankModule = code => {
  const M = Modules.byCode[code];
  return {
    code, sources: [], raw: null, chosenSheet: null, headerRow: null,
    clean: null, cleanLog: [], mapping: {}, mapIssues: [],
    config: M.defaultConfig ? M.defaultConfig() : Object.fromEntries((M.config || []).map(c => [c.key, c.def])),
    records: [], exceptions: [], derived: null, edits: [],
    adjustments: [], aiBlocks: [], comments: '', conclusion: '', matters: '',
    pageNotes: {}, trail: [], step: 0, page: (M.pages ? M.pages[0].id : null)
  };
};

const freshState = () => ({
  engagement: {
    client: '', firmRef: '', yearEnd: '', priorYearEnd: '', currency: 'SGD',
    framework: 'IFRS / SFRS(I)', preparedBy: '', datePrepared: '', reviewedBy: '', dateReviewed: '',
    indexRef: {},
    materiality: { basis: 'turnover', basisLabel: 'Turnover', benchmark: 0, rate: 0.02,
                   pmPct: 0.75, trivialPct: 0.05, om: 0, pm: 0, trivial: 0 },
    tbLink: {}
  },
  modules: Object.fromEntries(Modules.ALL.map(m => [m.code, blankModule(m.code)])),
  active: 'PPE'
});
let state = freshState();

const scope = document.querySelector('meta[name="awp-storage-scope"]')?.content;
const END_SIGNAL = 'awp.session.end.v1';
const readers = new Set();
let ended = false, generation = 0, settingsTimer, channel;
function purgeLegacy() {
  let removed = 0;
  for (const name of ['localStorage', 'sessionStorage']) {
    try {
      const storage = window[name], keys = [];
      for (let i = 0; i < storage.length; i++) {
        const key = storage.key(i);
        if (/^awp\.engagement\.v\d+(?::|$)/.test(key || '')) keys.push(key);
      }
      keys.forEach(key => { storage.removeItem(key); removed++; });
    } catch (e) {}
  }
  return removed;
}
// Engagements, profiles, schedules and auditor inputs exist only in this tab's memory.
function save() { purgeLegacy(); }
function load() { if (purgeLegacy()) toast('Earlier browser-saved engagement data was cleared for confidentiality. Start a new engagement.'); }
function endSession(notify = true) {
  if (ended) return;
  ended = true; generation++;
  clearTimeout(settingsTimer); clearTimeout(toastTimer); Core.NumBox.clear();
  for (const rd of readers) { rd.onload = null; rd.onerror = null; if (rd.readyState === 1) rd.abort(); }
  readers.clear(); purgeLegacy(); state = freshState();
  document.querySelectorAll('.modal,.toast').forEach(n => n.remove());
  $('#root').replaceChildren(el('div', { class: 'card', style: 'margin:32px;padding:28px' }, [
    el('h3', { text: 'Session ended' }),
    el('p', { text: 'Audit data has been cleared from this tab. Exported files remain on your device.' }),
    el('button', { class: 'btn', text: 'Start a new session', onclick: () => window.location.reload() })
  ]));
  if (notify) {
    try { channel?.postMessage('end'); } catch (e) {}
    try { localStorage.setItem(END_SIGNAL, String(Date.now())); localStorage.removeItem(END_SIGNAL); } catch (e) {}
  }
}
function requestEndSession() {
  const modal = el('div', { class: 'modal' }, el('div', { class: 'box' }, [
    el('h3', { text: 'Export your work before ending this session' }),
    el('div', { class: 'bd', text: 'This clears engagement details, uploaded schedules and working papers from all open tabs of this app. Export every section you need first. Exported files are not deleted.' }),
    el('div', { class: 'ft' }, [
      el('button', { class: 'btn ghost', text: 'Keep working', onclick: () => modal.remove() }),
      el('button', { class: 'btn', text: scope ? 'Clear data and sign out' : 'Clear data and end session', onclick: () => {
        endSession(); if (scope) window.top.location.href = '/signout-with-chatgpt?return_to=%2F';
      } })
    ])
  ]));
  document.body.append(modal);
}

/* A complete, fictitious engagement so the file can be explored at once and every
   field then edited from a sensible starting point. December year end on purpose:
   it is what most people expect, and every date control is easier to reason about. */
function fillDemo() {
  const e = state.engagement, m = e.materiality;
  Object.assign(e, { client: 'Harbourline Trading Pte. Ltd.', firmRef: 'DEMO/FY2025/001', yearEnd: '2025-12-31', priorYearEnd: '2024-12-31',
    currency: 'SGD', framework: 'IFRS / SFRS(I)', preparedBy: 'AB', datePrepared: '2026-02-16', reviewedBy: 'CD', dateReviewed: '2026-02-20' });
  Object.assign(m, { basis: 'turnover', basisLabel: 'Turnover', benchmark: 8500000, rate: 0.02, pmPct: 0.75, trivialPct: 0.05 });
  recalcMateriality(); save();
  Modules.ALL.forEach(mm => { if (state.modules[mm.code].records.length) recompute(mm, state.modules[mm.code], false); });
  render();
  toast('Demo engagement filled — a fictitious entity with a 31 December 2025 year end. Change anything in Engagement settings.');
}

function trail(code, event, detail) {
  state.modules[code].trail.push({ at: new Date().toISOString().replace('T', ' ').slice(0, 19), event, detail });
}
let toastTimer;
function toast(msg) {
  document.querySelectorAll('.toast').forEach(t => t.remove());
  const t = el('div', { class: 'toast', text: msg });
  document.body.append(t);
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.remove(), 3400);
}
function recalcMateriality() {
  const m = state.engagement.materiality;
  const b = Core.MAT_BASES.find(x => x.key === m.basis);
  m.basisLabel = b ? b.label : m.basis;
  Object.assign(m, Core.computeMateriality(m));
}
function yearEndDates() {
  const e = state.engagement;
  e.yearEndDate = e.yearEnd ? new Date(e.yearEnd + 'T00:00:00Z') : null;
  e.fyStartDate = null;
  if (e.yearEndDate) { const d = new Date(e.yearEndDate.getTime()); d.setUTCDate(d.getUTCDate() + 1); d.setUTCFullYear(d.getUTCFullYear() - 1);  /* day first, then year: FYE 28 Feb 2025 -> FYS 1 Mar 2024, not 29 Feb */ e.fyStartDate = d; }
}
const notes = (st, pid) => (st.pageNotes[pid] = st.pageNotes[pid] || { notes: '', conclusion: '' });

/* ============================================================== RENDER */
function render() {
  if (ended) return;
  recalcMateriality(); yearEndDates();
  $('#root').replaceChildren(topBar(), ribbon(), el('div', { class: 'wrap' }, moduleView()));
}

/* Re-render without stealing focus from the input being typed in. */
function soft() {
  Core.NumBox.sweep();
  const a = document.activeElement;
  const key = a && a.dataset && a.dataset.k;
  const pos = a && a.selectionStart;
  render();
  if (key) {
    const again = document.querySelector(`[data-k="${key}"]`);
    if (again) { again.focus(); try { if (pos != null) again.setSelectionRange(pos, pos); } catch (e) {} }
  }
}

function topBar() {
  const e = state.engagement;
  const missing = !e.client || !e.yearEnd || !e.materiality.om;
  return el('div', { class: 'top' }, el('div', { class: 'top-in' }, [
    el('div', { class: 'brand' }, [el('span', { class: 'n', text: 'Audit Working Papers' }), el('span', { class: 'v', text: 'Audit file' }),
      el('button', { class: 'btn ghost sm', onclick: () => Guide.open(), title: 'How to use this file, step by step', text: 'Guide' })]),
    el('div', { class: 'eng' }, [
      el('span', { html: e.client ? `<b>${esc(e.client)}</b>` : `<span class="miss">No entity set</span>` }),
      el('span', { html: e.yearEnd ? `FYE <b>${esc(e.yearEnd)}</b>` : `<span class="miss">No year end</span>` }),
      el('span', { html: e.materiality.om ? `PM <b class="mono">${money0(e.materiality.pm)}</b> · Trivial <b class="mono">${money0(e.materiality.trivial)}</b>` : `<span class="miss">No materiality</span>` }),
      missing ? el('button', { class: 'btn sm gold', onclick: fillDemo, title: 'Fictitious entity, December year end, materiality set — edit anything afterwards', text: 'Fill demo details' }) : null,
      el('button', { class: 'btn ghost sm', onclick: openSettings, text: missing ? 'Set up engagement' : 'Engagement settings' })
    ])
  ]));
}

function ribbon() {
  const groups = {};
  Modules.ALL.forEach(m => (groups[m.group] = groups[m.group] || []).push(m));
  const bar = el('div', { class: 'ribbon' });
  for (const [g, mods] of Object.entries(groups)) {
    const grp = el('div', { class: 'ribgrp' }, el('span', { class: 'lbl', text: g }));
    mods.forEach(m => {
      const st = state.modules[m.code];
      grp.append(el('button', {
        class: 'tab' + (state.active === m.code ? ' on' : '') + (st.records.length ? ' has' : '') + (st.exceptions.length ? ' exc' : ''),
        onclick: () => { state.active = m.code; render(); }
      }, [el('span', { class: 'dot' }), el('span', { text: m.code + ' · ' + m.name })]));
    });
    bar.append(grp);
  }
  bar.append(el('div', { class: 'ico' }, el('button', { class: 'btn ghost sm', onclick: openAbout, text: 'About' })));
  return bar;
}

function moduleView() {
  const M = Modules.byCode[state.active];
  const st = state.modules[state.active];
  if (M.pages) return fileView(M, st);
  return genericView(M, st);
}

/* ============================================================ AUDIT FILE */
function fileView(M, st) {
  const has = st.records.length > 0;
  const nav = el('div', { class: 'wpnav' }, M.pages.map(p => {
    const locked = !has && !['source'].includes(p.id);
    const done = pageStatus(M, st, p);
    return el('button', {
      class: 'wpnav-item' + (st.page === p.id ? ' on' : '') + (locked ? ' locked' : '') + (done ? ' ' + done : ''),
      disabled: locked ? true : null,
      onclick: () => { st.page = p.id; render(); }
    }, [el('span', { class: 'ref', text: p.ref }), el('span', { class: 'ttl', text: p.title }), el('span', { class: 'st' })]);
  }));
  const page = M.pages.find(p => p.id === st.page) || M.pages[0];
  const body = el('div', { class: 'wpbody' }, renderPage(M, st, page));
  return [el('div', { class: 'file' }, [nav, body])];
}

function pageStatus(M, st, p) {
  if (!st.records.length) return '';
  const n = st.pageNotes[p.id];
  if (n && n.conclusion) return 'done';
  const d = st.derived;
  if (p.flag && d) { try { return p.flag(st, d) ? 'flag' : ''; } catch (e) { return ''; } }
  if (p.id === 'lead' && d?.lead?.some?.(l => l.diffCost != null && Math.abs(l.diffCost) > 0.01)) return 'flag';
  if (p.id === 'depreciation' && d?.totals && Math.abs(d.totals.depDiff) > (state.engagement.materiality.trivial || 0)) return 'flag';
  if (p.id === 'impairment' && d?.impairment?.candidates?.some?.(c => !(c.r.__imp?.status))) return 'flag';
  return '';
}

/* The working-paper frame every page sits in: the same header block the
   three source firms use, then objective / source / procedures, the body,
   tickmarks, and the auditor's notes and conclusion for this paper.        */
function wpFrame(M, st, page, body, opts = {}) {
  const e = state.engagement;
  const pn = notes(st, page.id);
  const src = st.sources[0];
  return el('div', { class: 'wp' }, [
    el('table', { class: 'wphead' }, el('tbody', {}, [
      el('tr', {}, [th('Client'), td(e.client || '—'), th('Prepared by'), td(e.preparedBy || '—'), th('Date'), td(e.datePrepared || '—')]),
      el('tr', {}, [th('Year end'), td(e.yearEnd || '—'), th('Reviewed by'), td(e.reviewedBy || '—'), th('Date'), td(e.dateReviewed || '—')]),
      el('tr', {}, [th('WP ref'), td(page.ref, 'ref'), th('Subject'), el('td', { colspan: 3, text: `${M.name} — ${page.title}` })])
    ])),
    page.objective ? el('div', { class: 'wpsec' }, [el('b', { text: 'Objective' }), el('p', { text: page.objective })]) : null,
    src && page.kind !== 'source' ? el('div', { class: 'wpsec' }, [el('b', { text: 'Source' }),
      el('p', { text: `${src.fileName} · sheet "${src.sheetName}" · ${src.rowCount} assets · hash ${src.hash}` })]) : null,
    page.procedures ? el('div', { class: 'wpsec' }, [el('b', { text: 'Procedures' }),
      el('ol', {}, page.procedures.map(p => el('li', { text: p })))]) : null,
    ...body,
    opts.tickmarks !== false ? el('div', { class: 'ticks' }, [
      el('b', { text: 'Tickmarks' }),
      el('span', { html: '<code>TB</code> agreed to trial balance &nbsp; <code>PY</code> agreed to prior year audited &nbsp; <code>^</code> cast &nbsp; <code>vINV</code> vouched to invoice &nbsp; <code>R</code> recalculated &nbsp; <code>i/m</code> immaterial, no further work &nbsp; <code>&lt;ref&gt;</code> cross-reference' })
    ]) : null,
    opts.notes !== false ? el('div', { class: 'wpsec notes' }, [
      el('label', { class: 'fld' }, [el('span', { text: 'Findings and notes' }),
        el('textarea', { 'data-k': 'notes-' + page.id, oninput: ev => { pn.notes = ev.target.value; } }, el('span', { text: pn.notes }))]),
      el('label', { class: 'fld' }, [el('span', { text: 'Conclusion on this working paper' }),
        el('textarea', { 'data-k': 'concl-' + page.id, placeholder: 'Written by the auditor. Marks the paper as concluded in the file index.',
          oninput: ev => { pn.conclusion = ev.target.value; } }, el('span', { text: pn.conclusion }))])
    ]) : null
  ]);
}
const th = t => el('th', { text: t });
const td = (t, cls) => el('td', { class: cls || '', text: t });

function specCtx(M, st) {
  const e = state.engagement;
  return { eng: e, cfg: st.config, d: st.derived, recs: st.records.filter(r => !r.__excluded), all: st.records,
    money, money0, pct, fmtDate: Core.fmtDate, r2, pm: e.materiality.pm || 0, trivial: e.materiality.trivial || 0, M };
}
function specHooks(M, st) {
  return { onChange: structural => recompute(M, st, structural), soft, render, trail: (ev, det) => trail(M.code, ev, det) };
}
function renderPage(M, st, page) {
  if (page.render) {
    let specs;
    try { specs = page.render(st, specCtx(M, st)); }
    catch (err) { console.error(err); specs = [{ type: 'note', tone: 'bad', html: '<b>This working paper could not be rendered:</b> ' + esc(err.message) }]; }
    return [wpFrame(M, st, page, SpecUI.render(specs, page.id, st, specHooks(M, st)))];
  }
  switch (page.kind) {
    case 'source':       return pageSource(M, st, page);
    case 'cleaned':      return pageCleaned(M, st, page);
    case 'mapping':      return pageMapping(M, st, page);
    case 'lead':         return [wpFrame(M, st, page, pageLead(M, st))];
    case 'movement':     return [wpFrame(M, st, page, pageMovement(M, st))];
    case 'depreciation': return [wpFrame(M, st, page, pageDepreciation(M, st))];
    case 'additions':    return [wpFrame(M, st, page, pageAdditions(M, st))];
    case 'disposals':    return [wpFrame(M, st, page, pageDisposals(M, st))];
    case 'impairment':   return [wpFrame(M, st, page, pageImpairment(M, st))];
    case 'conclusion':   return pageConclusion(M, st, page);
  }
  return [el('div', { class: 'empty', text: 'Page not implemented' })];
}

/* ------------------------------------------------------------ E3.0 */
function pageSource(M, st, page) {
  const out = [];
  out.push(el('div', { class: 'card' }, [
    el('h3', {}, [el('span', { text: `${page.ref} — ${page.title}` }), el('span', { class: 'sub', text: 'What the client sent, exactly as received' })]),
    el('div', { class: 'pad' }, [dropZone(M, st),
      el('p', { class: 'small muted', style: 'margin-top:14px', text: 'Read in your browser with nothing uploaded anywhere. The original is preserved and exported unchanged on sheet 01 of the working paper.' })])
  ]));
  /* Before anything is uploaded, show what this section expects to receive. */
  const sample = Templates.card(M);
  if (sample) out.push(sample);
  if (!st.raw) return out;
  const sheet = st.raw.sheets.find(s => s.name === st.chosenSheet);
  out.push(el('div', { class: 'card' }, [
    el('h3', {}, [el('span', { text: 'Worksheet and header row' }), el('span', { class: 'sub', text: `${st.raw.fileName} · hash ${st.raw.hash}` })]),
    el('div', { class: 'pad' }, [
      el('div', { class: 'row', style: 'margin-bottom:12px' }, st.raw.sheets.map(s => el('button', {
        class: 'btn sm ' + (st.chosenSheet === s.name ? '' : 'ghost'), onclick: () => chooseSheet(M, st, s.name)
      }, [el('span', { text: `${s.name}${s.hidden ? ' (hidden)' : ''} · ${s.rows.length} rows` })]))),
      headerPicker(M, st)
    ])
  ]));
  /* raw grid, header row highlighted */
  const t = el('table', { class: 'raw' });
  const width = Math.max(...sheet.rows.slice(0, 60).map(r => (r || []).length), 1);
  t.append(el('thead', {}, el('tr', {}, [th('#'), ...Array.from({ length: width }, (_, i) => th(XLSX.utils.encode_col(i)))])));
  t.append(el('tbody', {}, sheet.rows.slice(0, 60).map((r, i) => el('tr', { class: i === st.headerRow ? 'hdr' : '' }, [
    el('td', { class: 'num muted', text: i + 1 }),
    ...Array.from({ length: width }, (_, j) => { const v = (r || [])[j]; return el('td', { class: typeof v === 'number' ? 'num' : '', text: v instanceof Date ? Core.fmtDate(v) : (v == null ? '' : String(v)) }); })
  ]))));
  out.push(el('div', { class: 'card' }, [
    el('h3', {}, [el('span', { text: 'Raw data' }), el('span', { class: 'sub', text: `First 60 of ${sheet.rows.length} rows · header row highlighted` })]),
    el('div', { class: 'tw' }, t)
  ]));
  return out;
}

function dropZone(M, st) {
  const input = el('input', { type: 'file', accept: M.accepts, style: 'display:none', onchange: e => e.target.files[0] && loadFile(M, st, e.target.files[0]) });
  const zone = el('div', { class: 'drop', onclick: () => input.click(),
    ondragover: e => { e.preventDefault(); zone.classList.add('over'); }, ondragleave: () => zone.classList.remove('over'),
    ondrop: e => { e.preventDefault(); zone.classList.remove('over'); e.dataTransfer.files[0] && loadFile(M, st, e.dataTransfer.files[0]); } }, [
    el('div', { class: 'big', text: st.raw ? 'Replace the fixed asset listing' : 'Upload the client\'s fixed asset listing' }),
    el('div', { class: 'sm', text: 'Drop the file here or click to choose · xlsx, xlsm, csv' }), input]);
  return zone;
}
function loadFile(M, st, file) {
  if (ended) return;
  const started = generation;
  const rd = new FileReader();
  readers.add(rd);
  rd.onload = () => {
    readers.delete(rd);
    if (ended || started !== generation) return;
    try {
      const wbData = Core.readWorkbook(rd.result, file.name);
      Object.assign(st, blankModule(M.code), { raw: wbData, config: st.config, pageNotes: {}, trail: st.trail });
      trail(M.code, 'Source uploaded', `${file.name} (${(file.size / 1024).toFixed(0)} KB), hash ${wbData.hash}`);
      chooseSheet(M, st, wbData.sheets[0].name);
      toast(`Read ${file.name}: ${st.records.length} assets, header on row ${st.headerRow + 1}`);
    } catch (err) { toast('Could not read that file: ' + err.message); console.error(err); }
  };
  rd.onerror = () => { readers.delete(rd); if (!ended) toast('Could not read that file. Please try again.'); };
  rd.readAsArrayBuffer(file);
}
function chooseSheet(M, st, name) {
  st.chosenSheet = name;
  st.headerRow = Core.detectHeader(st.raw.sheets.find(s => s.name === name).rows);
  rebuild(M, st, true); render();
}
function headerPicker(M, st) {
  const sheet = st.raw.sheets.find(s => s.name === st.chosenSheet);
  return el('label', { class: 'fld', style: 'max-width:900px;margin:0' }, [
    el('span', { text: 'Header row' }),
    el('select', { onchange: e => { st.headerRow = +e.target.value; rebuild(M, st, true); render(); } },
      Array.from({ length: Math.min(30, sheet.rows.length) }, (_, i) => el('option', { value: i, selected: i === st.headerRow ? 'selected' : null },
        el('span', { text: `Row ${i + 1}: ${(sheet.rows[i] || []).filter(c => !Core.isBlank(c)).slice(0, 7).map(c => Core.norm(c)).join(' | ').slice(0, 100) || '(blank)'}` })))),
    el('span', { class: 'help', text: 'Detected automatically. Override if the client put the header somewhere unusual.' })
  ]);
}

function rebuild(M, st, remap) {
  const sheet = st.raw.sheets.find(s => s.name === st.chosenSheet);
  st.clean = Core.cleanTable(sheet.rows, st.headerRow);
  st.cleanLog = st.clean.log;
  if (remap || !Object.keys(st.mapping).length) {
    const prof = state.profiles?.[profileKey(st)];
    if (prof) {
      st.mapping = {};
      for (const f of M.fields) {
        const col = prof[f.key] ? st.clean.headers.find(h => h.letter === prof[f.key]) : null;
        st.mapping[f.key] = col ? { colIndex: col.index, letter: col.letter, heading: col.heading, block: col.block, basis: 'saved profile', confidence: 'high', confirmed: true } : null;
      }
    } else st.mapping = Core.proposeMapping(st.clean.headers, M.fields, st.clean.rows.filter(r => r.__kind === 'data').slice(0, 40));
  }
  recompute(M, st, true);
  st.sources = [{ fileName: st.raw.fileName, hash: st.raw.hash, sheetName: st.chosenSheet, headerRow: st.headerRow,
    rowCount: st.records.length, uploadedAt: st.raw.uploadedAt, rawRows: sheet.rows }];
  if (M.pages && st.page === 'source') st.page = 'cleaned';
}
function profileKey(st) {
  return st.clean ? st.code + ':' + st.clean.headers.map(h => Core.keyify(h.heading)).filter(Boolean).sort().join('|') : '';
}

/* Rebuild records from the mapping (when structure changed), or just re-run
   the computation (when a config value or a cell edit changed).           */
function recompute(M, st, structural) {
  if (!st.clean) return;
  if (structural) {
    const built = Core.buildRecords(st.clean, M.fields, st.mapping);
    /* re-apply any auditor cell edits and working fields by source row */
    const prev = new Map((st.records || []).map(r => [r.__srcRow, r]));
    for (const r of built.records) {
      const p = prev.get(r.__srcRow);
      if (p) { ['__excluded', '__excludeReason', '__vouch', '__disp', '__imp'].forEach(k => { if (p[k] !== undefined) r[k] = p[k]; }); }
    }
    for (const ed of st.edits) { const r = built.records.find(x => x.__srcRow === ed.srcRow); if (r) r[ed.field] = ed.to; }
    st.records = built.records; st.mapIssues = built.issues; st.colInfo = built.colInfo;
  }
  const res = Core.runTests(M, st.records, st.config, state.engagement);
  st.exceptions = res.exceptions; st.derived = res.derived;
  if (M.code === 'TB') linkTB(st);
}
function linkTB(st) {
  const sum = re => st.records.filter(r => re.test(r.name || '')).reduce((s, r) => s + (r.__balance || 0), 0);
  state.engagement.tbSuggest = { turnover: Math.abs(sum(/^revenue|sales|turnover/i)) };
  state.engagement.tbRecords = st.records;
}

/* ----------------------------------------------------------- E3.0a */
function pageCleaned(M, st, page) {
  const d = st.derived || {};
  const cols = M.STANDARD_COLUMNS || M.fields.filter(f => st.mapping[f.key]).map(f => ({ key: f.key, label: f.label, type: f.type === 'number' ? 'num' : f.type === 'date' ? 'date' : 'text', edit: f.type !== 'text' }));
  const t = el('table', { class: 'std' });
  t.append(el('thead', {}, el('tr', {}, [th('Src'), ...cols.map(c => el('th', { class: c.type === 'num' ? 'num' : '', text: c.label })), th('Flags'), th('')])));
  t.append(el('tbody', {}, st.records.map(r => el('tr', { class: r.__excluded ? 'excluded' : '' }, [
    el('td', { class: 'num muted', text: r.__srcRow }),
    ...cols.map(c => cell(M, st, r, c)),
    el('td', {}, (r.__flags || []).slice(0, 4).map(f => el('span', { class: 'chip grey', title: f.rule + (f.raw != null ? ': ' + f.raw : ''), text: f.rule }))),
    el('td', {}, el('button', { class: 'btn ghost sm', onclick: () => toggleExclude(M, st, r), text: r.__excluded ? 'Include' : 'Exclude' }))
  ]))));
  return [
    el('div', { class: 'card' }, [
      el('h3', {}, [el('span', { text: `${page.ref} — ${page.title}` }), el('span', { class: 'sub', text: `${st.records.length} records in the standard format${d.lifeUnit ? ' · life read as ' + d.lifeUnit : ''} · click a number or date to correct it` })]),
      el('div', { class: 'pad' }, el('dl', { class: 'stats' }, [
        stat('Records', st.records.filter(r => !r.__excluded).length),
        ...(d.totals && d.totals.cost_close != null ? [stat('Cost c/f', money0(d.totals.cost_close)), stat('Acc dep c/f', money0(d.totals.accdep_close)), stat('NBV c/f', money0(d.totals.nbv_close))] : []),
        stat('Cleaning steps', st.cleanLog.length), stat('Auditor edits', st.edits.length)
      ])),
      el('div', { class: 'tw', style: 'max-height:720px' }, t)
    ]),
    el('div', { class: 'card' }, [
      el('h3', {}, [el('span', { text: 'Cleaning log' }), el('span', { class: 'sub', text: 'Every transformation from the client file to the standard format' })]),
      el('div', { class: 'tw', style: 'max-height:260px' }, logTable(st.cleanLog.concat(st.mapIssues || [])))
    ]),
    st.edits.length ? el('div', { class: 'card' }, [
      el('h3', {}, el('span', { text: 'Auditor corrections to the listing' })),
      el('div', { class: 'tw', style: 'max-height:260px' }, (() => {
        const t2 = el('table'); t2.append(el('thead', {}, el('tr', {}, [th('Src row'), th('Field'), th('From'), th('To'), th('Reason'), th('')])));
        t2.append(el('tbody', {}, st.edits.map((e, i) => el('tr', {}, [td(e.srcRow), td(e.field), td(fmtAny(e.from)), td(fmtAny(e.to)), td(e.reason),
          el('td', {}, el('button', { class: 'btn ghost sm', onclick: () => { st.edits.splice(i, 1); recompute(M, st, true); render(); }, text: 'Undo' }))]))));
        return t2;
      })())
    ]) : null
  ];
}
const fmtAny = v => v instanceof Date ? Core.fmtDate(v) : (typeof v === 'number' ? money(v) : (v ?? ''));
function stat(k, v, cls) { return el('div', {}, [el('dt', { text: k }), el('dd', { class: cls || '', text: v })]); }

function cell(M, st, r, c) {
  const v = r[c.key];
  let txt, cls = '';
  if (c.type === 'num') { txt = v == null ? '' : (c.dp === 1 ? Number(v).toFixed(1) : money(v)); cls = numCls(v); }
  else if (c.type === 'date') txt = v instanceof Date ? Core.fmtDate(v) : '';
  else txt = v == null ? '' : String(v);
  if (c.emphasis) cls += ' em';
  const node = el('td', { class: cls.trim(), text: txt });
  if (c.edit) {
    node.classList.add('editable'); node.title = 'Click to correct';
    node.onclick = () => editCell(M, st, r, c, node);
  }
  return node;
}
function editCell(M, st, r, c, node) {
  const field = c.edit === true ? c.key : c.edit;
  const cur = r[field];
  const inp = el('input', { type: c.type === 'date' ? 'date' : 'number', step: 'any',
    value: c.type === 'date' ? (cur instanceof Date ? Core.toISO(cur) : '') : (cur ?? '') });
  node.replaceChildren(inp); inp.focus();
  const commit = () => {
    let to = inp.value;
    if (to === '') { render(); return; }
    to = c.type === 'date' ? new Date(to + 'T00:00:00Z') : Number(to);
    const reason = prompt(`Reason for correcting ${c.label} on row ${r.__srcRow}:`, 'Agreed to supporting document');
    if (reason === null) { render(); return; }
    st.edits.push({ srcRow: r.__srcRow, field, from: cur, to, reason });
    r[field] = to;
    trail(M.code, 'Listing corrected', `Row ${r.__srcRow} ${c.label}: ${fmtAny(cur)} → ${fmtAny(to)} (${reason})`);
    recompute(M, st, false); render();
  };
  inp.onblur = commit; inp.onkeydown = e => { if (e.key === 'Enter') inp.blur(); if (e.key === 'Escape') render(); };
}
function toggleExclude(M, st, r) {
  if (r.__excluded) { r.__excluded = false; r.__excludeReason = ''; trail(M.code, 'Record included', `Row ${r.__srcRow}`); }
  else {
    const reason = prompt(`Reason for excluding row ${r.__srcRow} from the population:`);
    if (reason === null) return; if (!reason.trim()) { toast('A reason is required'); return; }
    r.__excluded = true; r.__excludeReason = reason.trim(); trail(M.code, 'Record excluded', `Row ${r.__srcRow}: ${reason.trim()}`);
  }
  recompute(M, st, false); render();
}
function logTable(items) {
  const t = el('table'); t.append(el('thead', {}, el('tr', {}, [th('Rule'), th('Row'), th('Detail')])));
  t.append(el('tbody', {}, items.map(l => el('tr', {}, [el('td', {}, el('span', { class: 'chip info', text: l.rule })), el('td', { class: 'num muted', text: l.row || '' }), el('td', { class: 'wrapcell', text: l.detail })]))));
  return t;
}

/* ----------------------------------------------------------- E3.0b */
function pageMapping(M, st, page) {
  const out = [];
  const unmapped = M.fields.filter(f => f.required && !st.mapping[f.key] && !(f.satisfiedByGroup && st.clean.hasGroups));
  if (unmapped.length) out.push(el('div', { class: 'note bad', html: `<b>Not mapped:</b> ${unmapped.map(f => esc(f.label)).join(', ')}. Working papers that depend on these fields will be incomplete.` }));
  (st.mapIssues || []).forEach(i => out.push(el('div', { class: 'note warn', html: `<b>${i.rule}</b> — ${esc(i.detail)}` })));
  const rows = M.fields.map(f => {
    const m = st.mapping[f.key];
    const sel = el('select', { onchange: e => {
      const v = e.target.value;
      st.mapping[f.key] = v === '' ? null : (() => { const col = st.clean.headers.find(h => String(h.index) === v);
        return { colIndex: col.index, letter: col.letter, heading: col.heading, block: col.block, basis: 'auditor selected', confidence: 'high', confirmed: true }; })();
      trail(M.code, 'Mapping changed', `${f.label} → ${v === '' ? 'none' : st.mapping[f.key].letter}`);
      recompute(M, st, true); render();
    } }, [el('option', { value: '', selected: m ? null : 'selected' }, el('span', { text: '— not mapped —' })),
      ...st.clean.headers.map(h => el('option', { value: h.index, selected: m && m.colIndex === h.index ? 'selected' : null },
        el('span', { text: `${h.letter} · ${h.heading || '(no heading)'}${h.block ? '  [' + h.block + ']' : ''}` })))]);
    const sample = m ? st.records.slice(0, 3).map(r => fmtAny(r[f.key]) || '—').join('   ·   ') : (f.satisfiedByGroup && st.clean.hasGroups ? 'From group header rows in the client file' : '');
    return el('div', { class: 'maprow' }, [
      el('div', {}, [el('div', { class: 'fname', text: f.label + (f.required ? ' *' : '') }), el('div', { class: 'fmeta', text: `${f.type}${f.block ? ' · ' + f.block + ' block' : ''}` })]),
      el('div', {}, [sel, sample ? el('div', { class: 'preview', text: sample }) : null]),
      el('div', {}, m ? el('span', { class: 'chip ' + (m.confidence === 'high' ? 'ok' : m.confidence === 'medium' ? 'warn' : 'bad'), text: m.confidence }) : el('span', { class: 'chip grey', text: 'none' })),
      el('div', { class: 'small muted', style: 'white-space:normal', text: m ? m.basis : '' })
    ]);
  });
  out.push(el('div', { class: 'card' }, [
    el('h3', {}, [el('span', { text: `${page.ref} — ${page.title}` }), el('span', { class: 'sub', text: 'Auto-mapped from the headings. Confirm or correct. * required' })]),
    el('div', { class: 'pad' }, [...rows, el('div', { class: 'row', style: 'margin-top:16px' }, [
      el('button', { class: 'btn', onclick: () => { st.page = 'lead'; render(); }, text: 'Confirm and open the lead schedule' }),
      el('button', { class: 'btn ghost', onclick: () => { state.profiles = state.profiles || {}; state.profiles[profileKey(st)] = Object.fromEntries(M.fields.map(f => [f.key, st.mapping[f.key]?.letter || null])); save(); toast('Layout remembered for this session only'); }, text: 'Remember layout for this session' })
    ])])
  ]));
  return out;
}

/* -------------------------------------------------------------- E3 */
function pageLead(M, st) {
  const d = st.derived, cfg = st.config, pm = state.engagement.materiality.pm;
  const t = el('table', { class: 'sched' });
  t.append(el('thead', {}, [
    el('tr', {}, [th(''), el('th', { colspan: 3, class: 'grp', text: 'Per listing' }), el('th', { colspan: 3, class: 'grp', text: 'Per trial balance' }), el('th', { colspan: 2, class: 'grp', text: 'Difference' }), el('th', { colspan: 3, class: 'grp', text: 'Prior year (audited)' }), el('th', { colspan: 2, class: 'grp', text: 'Movement' }), th('')]),
    el('tr', {}, ['Category', 'Cost', 'Acc dep', 'NBV', 'Cost', 'Acc dep', 'NBV', 'Cost', 'Acc dep', 'Cost', 'Acc dep', 'NBV', 'Variance', '%', 'Note'].map((h, i) => el('th', { class: i ? 'num' : '', text: h })))
  ]));
  const tb = key => (cfg.tb[key] = cfg.tb[key] || {}), py = key => (cfg.py[key] = cfg.py[key] || {});
  t.append(el('tbody', {}, d.lead.map(l => el('tr', {}, [
    td(l.category, 'em'),
    el('td', { class: numCls(l.listCost), text: money(l.listCost) }), el('td', { class: numCls(l.listDep), text: money(l.listDep) }), el('td', { class: numCls(l.listNBV) + ' em', text: money(l.listNBV) }),
    numInput(cfg, tb(l.category), 'cost', `tb-c-${l.category}`, M, st), numInput(cfg, tb(l.category), 'accdep', `tb-d-${l.category}`, M, st),
    el('td', { class: numCls(l.nbvTB), text: money(l.nbvTB) }),
    diffCell(l.diffCost, cfg.castTol), diffCell(l.diffDep, cfg.castTol),
    numInput(cfg, py(l.category), 'cost', `py-c-${l.category}`, M, st), numInput(cfg, py(l.category), 'accdep', `py-d-${l.category}`, M, st),
    el('td', { class: numCls(l.nbvPY), text: money(l.nbvPY) }),
    el('td', { class: numCls(l.variance) + (l.material ? ' em' : ''), text: money(l.variance) }),
    el('td', { class: 'num mono', text: pct(l.variancePct) }),
    el('td', {}, l.material ? el('span', { class: 'chip warn', text: 'Explain' }) : (l.variance != null ? el('span', { class: 'chip grey', text: 'i/m' }) : null))
  ]))));
  const T = d.totals;
  const sumTB = k => d.lead.reduce((s, l) => s + (l[k] || 0), 0);
  t.append(el('tfoot', {}, el('tr', {}, [td('TOTAL', 'em'),
    tdn(T.cost_close), tdn(T.accdep_close), tdn(T.nbv_close),
    tdn(sumTB('tbCost')), tdn(sumTB('tbDep')), tdn(sumTB('nbvTB')),
    diffCell(d.lead.some(l => l.diffCost != null) ? Core.parseNumber(sumTB('diffCost')).value : null, cfg.castTol),
    diffCell(d.lead.some(l => l.diffDep != null) ? sumTB('diffDep') : null, cfg.castTol),
    tdn(d.lead.some(l => l.nbvPY != null) ? d.lead.reduce((s, l) => s + (l.nbvPY != null ? Number(cfg.py[l.category].cost) : 0), 0) : null),
    tdn(d.lead.some(l => l.nbvPY != null) ? d.lead.reduce((s, l) => s + (l.nbvPY != null ? Math.abs(Number(cfg.py[l.category].accdep)) : 0), 0) : null),
    tdn(d.lead.some(l => l.nbvPY != null) ? sumTB('nbvPY') : null),
    tdn(d.lead.some(l => l.variance != null) ? sumTB('variance') : null), td(''), td('^')])));
  const tbAvail = state.engagement.tbRecords?.length;
  return [
    el('div', { class: 'note', html: `<b>Enter the trial balance and prior year balances by category.</b> The listing figures come from E3.0a. Variances are flagged where they exceed performance materiality (${money0(pm)}) <em>and</em> 10%.${tbAvail ? ' A trial balance is loaded in the TB module — the account names there are shown below for reference.' : ''}` }),
    el('div', { class: 'tw', style: 'max-height:none' }, t),
    tbAvail ? el('details', { class: 'small', style: 'margin-top:12px' }, [el('summary', { text: 'Trial balance accounts that look like PPE' }),
      el('ul', {}, state.engagement.tbRecords.filter(r => /plant|equipment|vehicle|furniture|fitting|renovation|computer|leasehold|improvement|depreciation|property/i.test(r.name || '')).map(r => el('li', { text: `${r.code} ${r.name}: ${money(r.__balance)}` })))]) : null
  ];
}
const tdn = v => el('td', { class: numCls(v), text: money(v) });
function diffCell(v, tol) {
  if (v == null) return td('');
  const ok = Math.abs(v) <= (tol || 0.01);
  return el('td', { class: numCls(v) + (ok ? ' okc' : ' badc'), text: ok ? (v === 0 ? '—' : money(v)) : money(v) });
}
function numInput(cfg, obj, key, k, M, st) {
  return el('td', { class: 'inp' }, Core.NumBox.make({ k, value: obj[key], placeholder: '—',
    commit: v => { obj[key] = v; recompute(M, st, false); }, refresh: soft }));
}

/* ------------------------------------------------------------ E3.1 */
function pageMovement(M, st) {
  const d = st.derived;
  const cats = d.byCategory, T = d.totals;
  const rows = [
    ['Cost', null], ['Balance brought forward', 'cost_open'], ['Additions', 'additions'], ['Disposals', 'disposals', true], ['Balance carried forward', 'cost_close', false, true],
    ['Accumulated depreciation', null], ['Balance brought forward', 'accdep_open'], ['Charge for the year', 'dep_charge'], ['Disposals', 'accdep_disp', true], ['Balance carried forward', 'accdep_close', false, true],
    ['Net book value', null], ['At beginning of year', 'nbv_open', false, true], ['At end of year', 'nbv_close', false, true]
  ];
  const t = el('table', { class: 'sched' });
  t.append(el('thead', {}, el('tr', {}, [th(''), ...cats.map(c => el('th', { class: 'num', text: c.category })), el('th', { class: 'num', text: 'Total' }), th('')])));
  t.append(el('tbody', {}, rows.map(([label, key, neg, bold]) => key === null
    ? el('tr', { class: 'section' }, [el('td', { colspan: cats.length + 3, text: label })])
    : el('tr', { class: bold ? 'total' : '' }, [td(label, bold ? 'em' : ''),
        ...cats.map(c => el('td', { class: numCls(neg ? -c[key] : c[key]), text: money(neg ? -c[key] : c[key]) })),
        el('td', { class: numCls(neg ? -T[key] : T[key]) + ' em', text: money(neg ? -T[key] : T[key]) }),
        td(bold ? '^' : '')]))));
  return [
    el('div', { class: 'tw', style: 'max-height:none' }, t),
    el('dl', { class: 'stats', style: 'margin-top:16px' }, [
      stat('Cost cast check', money(d.castCost), Math.abs(d.castCost) > st.config.castTol ? 'bad' : 'ok'),
      stat('Acc dep cast check', money(d.castDep), Math.abs(d.castDep) > st.config.castTol ? 'bad' : 'ok'),
      stat('Categories', cats.length), stat('Assets', T.count)
    ]),
    el('p', { class: 'small muted', style: 'margin-top:10px', text: 'Cast checks compare opening plus movements to the closing balance per the listing. A non-nil result means the client\'s closing column does not equal its own roll-forward — refer to E3.0a to find the rows.' })
  ];
}

/* ------------------------------------------------------------ E3.2 */
function pageDepreciation(M, st) {
  const d = st.derived, cfg = st.config, triv = state.engagement.materiality.trivial;
  const ctl = el('div', { class: 'ctl' }, [
    fldSel('Depreciation method (entity default)', cfg.method || 'sl', M.METHODS.map(m => [m.key, m.label]), v => { cfg.method = v; trail(M.code, 'Depreciation method', M.METHOD_LABEL(v)); recompute(M, st, false); render(); }),
    fldSel('Depreciation convention', cfg.convention, M.CONVENTIONS.map(c => [c.key, c.label]), v => { cfg.convention = v; trail(M.code, 'Depreciation convention', v); recompute(M, st, false); render(); }),
    fldSel('Useful life column is in', cfg.lifeUnit, [['auto', `Auto (read as ${d.lifeUnit})`], ['years', 'Years'], ['months', 'Months']], v => { cfg.lifeUnit = v; recompute(M, st, false); render(); }),
    fldSel('Recalculate using', cfg.recalcBasis, [['asset', 'Each asset\'s stated useful life'], ['policy', 'The category policy life entered below']], v => { cfg.recalcBasis = v; recompute(M, st, false); render(); }),
    fldNum('Difference threshold per asset', cfg.depTol, `depTol`, v => { cfg.depTol = v; recompute(M, st, false); soft(); }, `0 = use the trivial threshold (${money0(triv)})`),
    fldNum('Depreciation per the P&L', cfg.pnlDepreciation, `pnl`, v => { cfg.pnlDepreciation = v; recompute(M, st, false); soft(); }, 'For the tie to the income statement')
  ]);
  /* category summary with policy life input */
  const t = el('table', { class: 'sched' });
  t.append(el('thead', {}, el('tr', {}, ['Category', 'Assets', 'Cost', 'Method applied', 'Per register', 'Rate % (declining)', 'Life mode', 'Policy life (yrs)', 'Depn per audit', 'Depn per client', 'Difference', '% of cost', ''].map((h, i) => el('th', { class: i > 1 && i !== 3 && i !== 4 ? 'num' : '', text: h })))));
  t.append(el('tbody', {}, d.byCategory.map(c => {
    const diff = r2(c.dep_charge - c.expected);
    const flag = Math.abs(diff) > (cfg.depTol > 0 ? cfg.depTol : triv);
    const applied = cfg.methodPolicy[c.category] || cfg.method || 'sl';
    const stated = Object.entries(c.stated || {}).sort((a, b) => b[1] - a[1]);
    const statedTxt = stated.length ? stated.map(([k, n]) => `${k === 'unreadable' ? 'not recognised' : k === 'not stated' ? 'not stated' : M.METHOD_LABEL(k)}${stated.length > 1 ? ` (${n})` : ''}`).join(', ') : '—';
    const needsRate = applied === 'rb';
    return el('tr', {}, [td(c.category, 'em'), el('td', { class: 'num', text: c.count }), tdn(c.cost_close),
      el('td', { class: 'inp' }, el('select', { 'data-k': 'meth-' + c.category, onchange: e => { cfg.methodPolicy[c.category] = e.target.value; trail(M.code, 'Depreciation method', `${c.category} → ${M.METHOD_LABEL(e.target.value)}`); recompute(M, st, false); render(); } },
        M.METHODS.map(m => el('option', { value: m.key, selected: m.key === applied ? 'selected' : null }, el('span', { text: m.label }))))),
      el('td', { class: c.methodDiffers ? 'badc' : 'muted', text: statedTxt }),
      needsRate
        ? el('td', { class: 'inp' }, Core.NumBox.make({ k: 'rate-' + c.category, value: cfg.ratePolicy[c.category],
            placeholder: 'per asset', title: 'Used where the register gives no rate for the asset',
            commit: v => { cfg.ratePolicy[c.category] = v === '' ? undefined : v; recompute(M, st, false); }, refresh: soft }))
        : el('td', { class: 'num muted', text: '—' }),
      el('td', { class: 'num mono', text: c.modeLife ?? '' }),
      el('td', { class: 'inp' }, Core.NumBox.make({ k: 'pol-' + c.category, value: cfg.lifePolicy[c.category], placeholder: String(c.modeLife ?? ''),
        commit: v => { cfg.lifePolicy[c.category] = v === '' ? undefined : v; recompute(M, st, false); }, refresh: soft })),
      tdn(c.expected), tdn(c.dep_charge), el('td', { class: numCls(diff) + ' em', text: money(diff) }),
      el('td', { class: 'num mono', text: c.cost_close ? pct(diff / c.cost_close * 100) : '' }),
      el('td', {}, el('span', { class: 'chip ' + (flag ? 'bad' : 'grey'), text: flag ? 'Investigate' : 'i/m' }))]);
  })));
  const T = d.totals, tdiff = r2(T.dep_charge - T.expected);
  t.append(el('tfoot', {}, el('tr', {}, [td('TOTAL', 'em'), el('td', { class: 'num', text: T.count }), tdn(T.cost_close), td(''), td(''), td(''), td(''), tdn(T.expected), tdn(T.dep_charge), el('td', { class: numCls(tdiff) + ' em', text: money(tdiff) }), td(''), td('^ R')])));

  /* per asset */
  const onlyDiff = st.__depOnlyDiff !== false;
  const list = st.records.filter(r => !r.__excluded && (!onlyDiff || Math.abs(r.__depDiff || 0) > (cfg.depTol > 0 ? cfg.depTol : triv)));
  const t2 = el('table');
  t2.append(el('thead', {}, el('tr', {}, ['Src', 'Asset', 'Description', 'Category', 'Acquired', 'Life used', 'Months', 'Cost', 'Acc dep b/f', 'Per audit', 'Per client', 'Difference'].map((h, i) => el('th', { class: i > 4 ? 'num' : '', text: h })))));
  t2.append(el('tbody', {}, list.slice(0, 500).map(r => el('tr', {}, [el('td', { class: 'num muted', text: r.__srcRow }), td(r.asset_id), td(r.description), td(r.category),
    td(r.acq_date ? Core.fmtDate(r.acq_date) : ''), el('td', { class: 'num mono', text: r.__lifeUsed ? Number(r.__lifeUsed).toFixed(1) : '' }), el('td', { class: 'num mono', text: Number(r.__months).toFixed(1) }),
    tdn(r.cost_open || r.additions), tdn(r.accdep_open), tdn(r.__expectedDep), tdn(r.dep_charge), el('td', { class: numCls(r.__depDiff) + ' em', text: money(r.__depDiff) })]))));
  return [
    ctl,
    el('dl', { class: 'stats', style: 'margin:16px 0' }, [
      stat('Depreciation per audit', money0(T.expected)), stat('Per client (listing)', money0(T.dep_charge)),
      stat('Difference', money(tdiff), Math.abs(tdiff) > triv ? 'bad' : 'ok'),
      stat('Per P&L', d.pnlDepreciation != null ? money0(d.pnlDepreciation) : '—'),
      stat('Listing vs P&L', d.pnlDiff != null ? money(d.pnlDiff) : '—', d.pnlDiff != null && Math.abs(d.pnlDiff) > cfg.castTol ? 'bad' : 'ok'),
      stat('Assets with a difference', st.records.filter(r => Math.abs(r.__depDiff || 0) > (cfg.depTol > 0 ? cfg.depTol : triv)).length)
    ]),
    el('h4', { style: 'margin:18px 0 8px', text: 'By category' }),
    el('div', { class: 'tw', style: 'max-height:none' }, t),
    el('div', { class: 'row', style: 'margin:20px 0 8px' }, [el('h4', { style: 'margin:0', text: 'By asset' }),
      el('label', { class: 'small', style: 'margin-left:auto' }, [el('input', { type: 'checkbox', checked: onlyDiff ? 'checked' : null, onchange: e => { st.__depOnlyDiff = e.target.checked; render(); } }), el('span', { text: 'Show only assets with a difference above the threshold' })])]),
    el('div', { class: 'tw', style: 'max-height:520px' }, t2)
  ];
}
function fldSel(label, val, opts, on) {
  return el('label', { class: 'fld' }, [el('span', { text: label }), el('select', { onchange: e => on(e.target.value) }, opts.map(([v, l]) => el('option', { value: v, selected: v === val ? 'selected' : null }, el('span', { text: l }))))]);
}
function fldNum(label, val, k, on, help) {
  return el('label', { class: 'fld' }, [el('span', { text: label }),
    Core.NumBox.make({ k, value: val, commit: on, refresh: soft }),
    help ? el('span', { class: 'help', text: help }) : null]);
}
const r2 = n => n == null || isNaN(n) ? null : Math.round(n * 100) / 100;

/* ------------------------------------------------------------ E3.3 */
function pageAdditions(M, st) {
  const d = st.derived, cfg = st.config, A = d.additions, pm = state.engagement.materiality.pm;
  const ctl = el('div', { class: 'ctl' }, [
    fldNum('Testing threshold — every addition at or above this is tested', cfg.addThreshold, 'addT', v => { cfg.addThreshold = v; recompute(M, st, false); soft(); }, `Blank = performance materiality (${money0(pm)}). Currently ${money0(A.threshold)}.`),
    fldNum('Random sample from the remaining additions', cfg.addSampleN, 'addN', v => { cfg.addSampleN = v; recompute(M, st, false); soft(); }, `${A.residual.length} additions below the threshold, totalling ${money0(A.residualValue)}`),
    el('label', { class: 'fld' }, [el('span', { text: 'Sample seed (recorded so the selection is reproducible)' }), el('div', { class: 'row' }, [
      Core.NumBox.make({ k: 'seed', value: cfg.addSeed, style: 'max-width:200px',
        commit: v => { cfg.addSeed = Number(v) || 1; recompute(M, st, false); }, refresh: soft }),
      el('button', { class: 'btn ghost sm', onclick: () => { cfg.addSeed = Math.floor(Math.random() * 1e9); trail(M.code, 'Sample reselected', 'seed ' + cfg.addSeed); recompute(M, st, false); render(); }, text: 'Reselect' })])])
  ]);
  const sel = st.records.filter(r => r.__addSelected).sort((a, b) => (a.__addSelected === b.__addSelected ? 0 : a.__addSelected === 'key' ? -1 : 1) || (b.additions - a.additions));
  const t = el('table', { class: 'vouch' });
  t.append(el('thead', {}, el('tr', {}, ['Basis', 'Asset', 'Description', 'Category', 'Date per listing', 'Amount per listing', 'Invoice no', 'Invoice date', 'Supplier per invoice', 'Amount per invoice', 'Diff', 'Capitalise?', 'Right period?', 'Comment', ''].map((h, i) => el('th', { class: [5, 9, 10].includes(i) ? 'num' : '', text: h })))));
  t.append(el('tbody', {}, sel.map(r => {
    const v = (r.__vouch = r.__vouch || {});
    const amt = v.amtInv != null && v.amtInv !== '' ? Number(v.amtInv) : null;
    const diff = amt != null ? r2(r.additions - amt) : null;
    const set = (k, val) => { v[k] = val; };
    return el('tr', {}, [
      el('td', {}, el('span', { class: 'chip ' + (r.__addSelected === 'key' ? 'info' : 'ok'), text: r.__addSelected === 'key' ? 'Key' : 'Sample' })),
      td(r.asset_id), td(r.description), td(r.category), td(r.acq_date ? Core.fmtDate(r.acq_date) : ''), el('td', { class: 'num mono em', text: money(r.additions) }),
      vin(v, 'invNo', 'text', r), vin(v, 'invDate', 'date', r), vin(v, 'supplier', 'text', r), vin(v, 'amtInv', 'number', r, () => { recompute(M, st, false); soft(); }),
      el('td', { class: numCls(diff) + (diff && Math.abs(diff) > 0.01 ? ' badc' : ''), text: diff == null ? '' : money(diff) }),
      vsel(v, 'capOk', ['', 'Y', 'N', 'Query'], r), vsel(v, 'periodOk', ['', 'Y', 'N'], r), vin(v, 'note', 'text', r),
      el('td', {}, el('span', { class: 'small muted', text: amt != null && Math.abs(diff) <= 0.01 && v.capOk === 'Y' && v.periodOk === 'Y' ? 'vINV ✓' : '' }))
    ]);
  })));
  const vouched = sel.filter(r => r.__vouch?.amtInv != null && r.__vouch.amtInv !== '').length;
  return [
    ctl,
    el('dl', { class: 'stats', style: 'margin:16px 0' }, [
      stat('Additions in the year', `${A.all.length} · ${money0(A.total)}`), stat('Key items ≥ threshold', `${A.key.length} · ${money0(A.keyValue)}`),
      stat('Random sample', `${A.sample.length} · ${money0(A.sampleValue)}`), stat('Coverage of additions', pct(A.coverage), A.coverage >= 80 ? 'ok' : 'warn'),
      stat('Untested', `${A.residual.length - A.sample.length} · ${money0(A.untestedValue)}`), stat('Vouched so far', `${vouched} of ${sel.length}`)
    ]),
    el('div', { class: 'note', html: `<b>Fill in the invoice details as you vouch.</b> Amount per invoice is compared to the listing; capitalisation and period are your judgements. A row reads <code>vINV ✓</code> when the amount agrees and both judgements are Y. Untested additions below the threshold are listed at the foot for completeness.` }),
    el('div', { class: 'tw', style: 'max-height:640px' }, t),
    el('details', { class: 'small', style: 'margin-top:14px' }, [el('summary', { text: `Untested additions below the threshold (${A.residual.length - A.sample.length})` }),
      el('div', { class: 'tw', style: 'max-height:300px;margin-top:8px' }, (() => { const t3 = el('table'); t3.append(el('thead', {}, el('tr', {}, [th('Asset'), th('Description'), th('Category'), th('Date'), el('th', { class: 'num', text: 'Amount' })])));
        t3.append(el('tbody', {}, A.residual.filter(r => !A.sample.includes(r)).map(r => el('tr', {}, [td(r.asset_id), td(r.description), td(r.category), td(r.acq_date ? Core.fmtDate(r.acq_date) : ''), tdn(r.additions)])))); return t3; })())])
  ];
}
function vin(v, k, type, r, after) {
  return el('td', { class: 'inp' }, el('input', { type, step: 'any', 'data-k': `${k}-${r.__srcRow}`, value: v[k] ?? '', oninput: e => { v[k] = e.target.value; if (after) after(); } }));
}
function vsel(v, k, opts, r) {
  return el('td', { class: 'inp' }, el('select', { 'data-k': `${k}-${r.__srcRow}`, onchange: e => { v[k] = e.target.value; render(); } }, opts.map(o => el('option', { value: o, selected: (v[k] || '') === o ? 'selected' : null }, el('span', { text: o || '—' })))));
}

/* ------------------------------------------------------------ E3.4 */
function pageDisposals(M, st) {
  const d = st.derived, D = d.disposals;
  if (!D.length) return [el('div', { class: 'note', html: '<b>No disposals in the year</b> per the listing. Confirm with management that no assets were scrapped, sold or written off, and document the enquiry in the notes below.' })];
  const t = el('table', { class: 'vouch' });
  t.append(el('thead', {}, el('tr', {}, ['Asset', 'Description', 'Category', 'Acquired', 'Cost disposed', 'Acc dep written back', 'NBV disposed', 'Proceeds', 'Gain / (loss) per audit', 'Per client', 'Diff', 'Authorised?', 'Comment', ''].map((h, i) => el('th', { class: i >= 4 && i <= 10 ? 'num' : '', text: h })))));
  let totGL = 0;
  t.append(el('tbody', {}, D.map(x => {
    const r = x.r, v = (r.__disp = r.__disp || {});
    const perClient = v.perClient != null && v.perClient !== '' ? Number(v.perClient) : null;
    const diff = x.gainLoss != null && perClient != null ? r2(x.gainLoss - perClient) : null;
    totGL += x.gainLoss || 0;
    return el('tr', {}, [td(r.asset_id), td(r.description), td(r.category), td(r.acq_date ? Core.fmtDate(r.acq_date) : ''),
      tdn(r.disposals), el('td', { class: numCls(r.accdep_disp) + (x.noWriteBack ? ' badc' : ''), text: money(r.accdep_disp) }), tdn(x.nbvDisposed),
      vin(v, 'proceeds', 'number', r, () => { recompute(M, st, false); soft(); }),
      el('td', { class: numCls(x.gainLoss) + ' em', text: money(x.gainLoss) }),
      vin(v, 'perClient', 'number', r, () => soft()),
      el('td', { class: numCls(diff) + (diff && Math.abs(diff) > 0.01 ? ' badc' : ''), text: diff == null ? '' : money(diff) }),
      vsel(v, 'auth', ['', 'Y', 'N'], r), vin(v, 'note', 'text', r),
      el('td', {}, x.noWriteBack ? el('span', { class: 'chip bad', text: 'No write-back' }) : null)]);
  })));
  t.append(el('tfoot', {}, el('tr', {}, [td('TOTAL', 'em'), td(''), td(''), td(''), tdn(D.reduce((s, x) => s + (x.r.disposals || 0), 0)), tdn(D.reduce((s, x) => s + (x.r.accdep_disp || 0), 0)), tdn(D.reduce((s, x) => s + x.nbvDisposed, 0)),
    tdn(D.reduce((s, x) => s + (x.proceeds || 0), 0)), el('td', { class: numCls(totGL) + ' em', text: money(r2(totGL)) }), td(''), td(''), td(''), td(''), td('^')])));
  return [
    el('dl', { class: 'stats', style: 'margin-bottom:16px' }, [stat('Disposals', D.length), stat('Cost removed', money0(D.reduce((s, x) => s + (x.r.disposals || 0), 0))),
      stat('NBV disposed', money0(D.reduce((s, x) => s + x.nbvDisposed, 0))), stat('Gain / (loss)', money(r2(totGL)), totGL < 0 ? 'warn' : ''),
      stat('Without write-back', D.filter(x => x.noWriteBack).length, D.some(x => x.noWriteBack) ? 'bad' : 'ok')]),
    el('div', { class: 'note', html: '<b>Enter proceeds and the client\'s recorded gain or loss.</b> A disposal with no accumulated depreciation written back overstates the loss and leaves accumulated depreciation in the register — refer E3.1. A loss on disposal is an FRS 36 indicator for the rest of that category — it feeds E3.5 automatically.' }),
    el('div', { class: 'tw', style: 'max-height:none' }, t)
  ];
}

/* ------------------------------------------------------------ E3.5 */
function pageImpairment(M, st) {
  const d = st.derived, cfg = st.config, I = d.impairment, cats = d.byCategory.map(c => c.category);
  /* Part A -- indicators */
  const tA = el('table', { class: 'sched' });
  tA.append(el('thead', {}, el('tr', {}, [th('Ref'), th('Source'), th('Indicator (FRS 36 para 12 / 14)'), th('Present?'), th('Categories affected'), th('Management\'s response and evidence obtained')])));
  tA.append(el('tbody', {}, M.INDICATORS.map(ind => {
    const a = (cfg.indicators[ind.id] = cfg.indicators[ind.id] || { answer: '', comment: '', categories: [] });
    return el('tr', { class: a.answer === 'Y' ? 'yes' : '' }, [td(ind.id, 'mono'), td(ind.src), el('td', { class: 'wrapcell', text: ind.text }),
      el('td', { class: 'inp' }, el('select', { onchange: e => { a.answer = e.target.value; trail(M.code, 'Impairment indicator', `${ind.id} = ${a.answer}`); recompute(M, st, false); render(); } },
        ['', 'Y', 'N', 'n/a'].map(o => el('option', { value: o, selected: a.answer === o ? 'selected' : null }, el('span', { text: o || '—' }))))),
      el('td', { class: 'inp' }, el('select', { multiple: 'multiple', size: Math.min(3, cats.length), disabled: a.answer !== 'Y' ? 'disabled' : null, title: 'Leave none selected to apply to all categories',
        onchange: e => { a.categories = [...e.target.selectedOptions].map(o => o.value); recompute(M, st, false); render(); } },
        cats.map(c => el('option', { value: c, selected: a.categories.includes(c) ? 'selected' : null }, el('span', { text: c }))))),
      el('td', { class: 'inp wide' }, el('input', { type: 'text', 'data-k': 'ind-' + ind.id, value: a.comment, oninput: e => { a.comment = e.target.value; } }))]);
  })));
  /* Part B -- rules */
  const rules = el('div', { class: 'rules' }, M.CANDIDATE_RULES.map(r => el('label', { class: 'rule' }, [
    el('input', { type: 'checkbox', checked: cfg.rules[r.id] !== false ? 'checked' : null, onchange: e => { cfg.rules[r.id] = e.target.checked; recompute(M, st, false); render(); } }),
    el('span', {}, [el('b', { text: `${r.id} ${r.label}` }), el('span', { class: 'small muted', text: ' — ' + r.why })])])));
  /* Part C -- candidates */
  const tC = el('table', { class: 'vouch' });
  tC.append(el('thead', {}, el('tr', {}, ['Asset', 'Description', 'Category', 'NBV', 'Identified by', 'Work done', 'Work to be done', 'Status', 'Auditor notes', 'Conclusion'].map((h, i) => el('th', { class: i === 3 ? 'num' : '', text: h })))));
  tC.append(el('tbody', {}, I.candidates.map(c => {
    const r = c.r, v = (r.__imp = r.__imp || { status: '', note: '', conclusion: '' });
    const ruleDefs = c.rules.map(id => M.CANDIDATE_RULES.find(x => x.id === id));
    return el('tr', {}, [td(r.asset_id), td(r.description), td(r.category), el('td', { class: numCls(r.__nbv_close) + ' em', text: money(r.__nbv_close) }),
      el('td', {}, c.rules.map(id => el('span', { class: 'chip warn', title: M.CANDIDATE_RULES.find(x => x.id === id).label, text: id }))),
      el('td', { class: 'wrapcell small', text: 'Identified from the cleaned listing at ' + (state.engagement.yearEnd || 'year end') + ': ' + ruleDefs.map(x => x.label.toLowerCase()).join('; ') + '. Carrying amount, age and charge recalculated (E3.2).' }),
      el('td', { class: 'wrapcell small', html: ruleDefs.map(x => '• ' + esc(x.todo)).join('<br>') }),
      vsel(v, 'status', ['', 'Not started', 'Enquired', 'Evidence obtained', 'Concluded'], r),
      vin(v, 'note', 'text', r),
      vsel(v, 'conclusion', ['', 'No impairment', 'Impairment — adjust', 'Derecognise', 'Refer IMP module', 'Revise useful life'], r)]);
  })));
  const concluded = I.candidates.filter(c => c.r.__imp?.status === 'Concluded').length;
  return [
    el('h4', { style: 'margin:0 0 8px', text: 'A. Indicator assessment — FRS 36 para 12' }),
    el('div', { class: 'note', html: `<b>Answer each indicator with management.</b> A <b>Y</b> makes every asset in the affected categories (or all, if none are selected) a candidate below and triggers the requirement to estimate recoverable amount (para 9). Where a Y relates to a cash-generating unit rather than individual assets, the value-in-use model sits in the <b>IMP</b> module.` }),
    el('div', { class: 'tw', style: 'max-height:none' }, tA),
    el('h4', { style: 'margin:22px 0 8px', text: 'B. Candidate identification rules' }),
    rules,
    el('h4', { style: 'margin:22px 0 8px', text: 'C. Assets requiring assessment' }),
    el('dl', { class: 'stats', style: 'margin-bottom:14px' }, [stat('Candidates', I.candidates.length, I.candidates.length ? 'warn' : 'ok'), stat('Carrying amount in scope', money0(I.candidateValue)),
      stat('Share of total NBV', pct(I.coverage)), stat('Indicators answered Y', Object.values(cfg.indicators).filter(a => a.answer === 'Y').length), stat('Concluded', `${concluded} of ${I.candidates.length}`, concluded === I.candidates.length && I.candidates.length ? 'ok' : '')]),
    I.candidates.length ? el('div', { class: 'tw', style: 'max-height:640px' }, tC)
      : el('div', { class: 'note', html: '<b>No candidates.</b> No asset meets any enabled rule and no indicator is answered Y. Document the basis for concluding that no indication of impairment exists.' })
  ];
}

/* ------------------------------------------------------------ E3.9 */
function pageConclusion(M, st, page) {
  const e = state.engagement, d = st.derived;
  const by = s => st.exceptions.filter(x => x.severity === s).length;
  const idx = M.pages.filter(p => !['source', 'cleaned', 'mapping', 'conclusion'].includes(p.id)).map(p => {
    const n = st.pageNotes[p.id] || {};
    return el('tr', {}, [td(p.ref, 'mono'), td(p.title), el('td', {}, el('span', { class: 'chip ' + (n.conclusion ? 'ok' : 'grey'), text: n.conclusion ? 'Concluded' : 'Open' })), el('td', { class: 'wrapcell small', text: n.conclusion || n.notes || '' })]);
  });
  const t = el('table'); t.append(el('thead', {}, el('tr', {}, ['ID', 'Exception', 'Record', 'Difference', 'Severity', 'WP', 'Disposition', 'Reason'].map(h => th(h)))));
  t.append(el('tbody', {}, st.exceptions.map(x => el('tr', {}, [el('td', {}, el('span', { class: 'chip info', text: x.id })), el('td', { class: 'wrapcell' }, [el('div', { text: x.label }), x.detail ? el('div', { class: 'small muted', text: x.detail }) : null]),
    el('td', { class: 'small', text: String(x.recordKey ?? '') + (x.cell ? ` (${x.cell})` : '') }), el('td', { class: numCls(x.difference) + ' em', text: x.difference != null ? money(x.difference) : '' }),
    el('td', {}, el('span', { class: 'chip ' + (x.severity === 'above-pm' ? 'bad' : x.severity === 'above-trivial' ? 'warn' : 'grey'), text: Exporter.sevLabel(x.severity) })), td(x.basis, 'mono small'),
    el('td', {}, el('select', { onchange: ev => { x.disposition = ev.target.value; trail(M.code, 'Disposition', `${x.id} ${x.recordKey ?? ''} → ${ev.target.value}`); soft(); } }, ['open', 'accepted', 'cleared', 'adjusted', 'rejected'].map(o => el('option', { value: o, selected: x.disposition === o ? 'selected' : null }, el('span', { text: o }))))),
    el('td', { class: 'inp' }, el('input', { type: 'text', 'data-k': 'why-' + x.id + x.srcRow, value: x.reason || '', onchange: ev => { x.reason = ev.target.value; } }))]))));
  const blockers = [!e.client && 'entity name', !e.yearEnd && 'year end', !e.materiality.om && 'materiality'].filter(Boolean);
  return [
    el('div', { class: 'card' }, [el('h3', {}, [el('span', { text: `${page.ref} — File index and status` })]),
      el('div', { class: 'tw', style: 'max-height:none' }, (() => { const ti = el('table'); ti.append(el('thead', {}, el('tr', {}, [th('Ref'), th('Working paper'), th('Status'), th('Conclusion')]))); ti.append(el('tbody', {}, idx)); return ti; })())]),
    el('div', { class: 'card' }, [el('h3', {}, [el('span', { text: 'Exception register' }), el('span', { class: 'sub', text: `${st.exceptions.length} raised · ${by('above-pm')} above PM · ${by('above-trivial')} above trivial` })]),
      el('div', { class: 'tw' }, t)]),
    el('div', { class: 'card' }, [el('h3', {}, el('span', { text: 'Overall conclusion — ' + M.name })), el('div', { class: 'pad' }, [
      el('label', { class: 'fld' }, [el('span', { text: 'Auditor comments' }), el('textarea', { 'data-k': 'cmt', oninput: ev => { st.comments = ev.target.value; } }, el('span', { text: st.comments }))]),
      el('label', { class: 'fld' }, [el('span', { text: 'Conclusion' }), el('textarea', { 'data-k': 'ccl', placeholder: 'Never populated automatically.', oninput: ev => { st.conclusion = ev.target.value; } }, el('span', { text: st.conclusion }))]),
      el('button', { class: 'btn ghost sm', onclick: () => { st.conclusion = suggestConclusion(M, st); render(); }, text: 'Insert a template conclusion to edit' })])]),
    el('div', { class: 'card' }, [el('h3', {}, el('span', { text: 'Export the ' + M.code + ' file' })), el('div', { class: 'pad' }, [
      blockers.length ? el('div', { class: 'note warn' }, [el('span', { text: `${blockers.join(', ')} not set — the header will be incomplete. ` }), el('button', { class: 'btn ghost sm', onclick: openSettings, text: 'Set now' })]) : null,
      el('p', { class: 'small muted', text: 'One sheet per working paper, plus source data preserved verbatim, the cleaned listing, mapping, cleaning log, corrections, exceptions and the audit trail. Totals and recalculations are live Excel formulas.' }),
      el('div', { class: 'row', style: 'margin-top:14px' }, el('button', { class: 'btn', onclick: () => { try { const n = Exporter.download(state, M.code); trail(M.code, 'Exported', n); toast('Downloaded ' + n); } catch (err) { toast('Export failed: ' + err.message); console.error(err); } }, text: 'Download Excel working papers' }))])])
  ];
}
function suggestConclusion(M, st) {
  if (M.suggestConclusion) return M.suggestConclusion(st, specCtx(M, st));
  const d = st.derived, mat = st.exceptions.filter(x => x.severity === 'above-pm'), open = st.exceptions.filter(x => x.disposition === 'open');
  if (!d?.totals || d.totals.depDiff == null) return `Based on the procedures performed, ${M.name.toLowerCase()} is fairly stated in all material respects${st.exceptions.length ? `, subject to clearance of ${st.exceptions.filter(x => x.disposition === 'open').length} open exception(s)` : ''}.`;
  const dep = Math.abs(d.totals.depDiff) > state.engagement.materiality.trivial ? ` The depreciation recalculation shows a net ${d.totals.depDiff > 0 ? 'over' : 'under'}-charge of ${money(Math.abs(d.totals.depDiff))} against the listing.` : ' Depreciation recalculated is within the threshold of the charge recorded.';
  const imp = d.impairment.candidates.length ? ` ${d.impairment.candidates.length} asset(s) were identified for impairment assessment under FRS 36; ${d.impairment.candidates.filter(c => c.r.__imp?.status === 'Concluded').length} have been concluded.` : ' No indication of impairment was identified.';
  if (!st.exceptions.length) return `Based on the procedures performed on E3 to E3.5, property, plant and equipment is fairly stated in all material respects.${dep}${imp}`;
  return `Based on the procedures performed on E3 to E3.5, ${st.exceptions.length} exception(s) were identified${mat.length ? `, of which ${mat.length} exceed performance materiality` : ', none exceeding performance materiality'}; ${open.length} remain open.${dep}${imp} Subject to clearance of the open items, property, plant and equipment is fairly stated in all material respects.`;
}

/* ====================================================== GENERIC FLOW */
/* Modules without pages (TB, AR) keep the five-step flow. */
const STEPS = [{ k: 'Step 1', t: 'Source data' }, { k: 'Step 2', t: 'Clean & map' }, { k: 'Step 3', t: 'Test configuration' }, { k: 'Step 4', t: 'Exceptions' }, { k: 'Step 5', t: 'Working paper' }];
function genericView(M, st) {
  const out = [el('div', { class: 'steps' }, STEPS.map((s, i) => el('button', { class: 'step' + (st.step === i ? ' on' : '') + (i < st.step ? ' done' : ''), disabled: i > 0 && !st.records.length ? true : null, onclick: () => { st.step = i; render(); } }, [el('span', { class: 'k', text: s.k }), el('span', { class: 't', text: s.t })])))];
  if (st.step === 0) {
    out.push(el('div', { class: 'card' }, [el('h3', {}, [el('span', { text: `${M.code} — ${M.name}` }), el('span', { class: 'sub', text: M.blurb })]), el('div', { class: 'pad' }, dropZoneGeneric(M, st))]));
    const sample = Templates.card(M);
    if (sample) out.push(sample);
    if (st.raw) out.push(el('div', { class: 'card' }, [el('h3', {}, el('span', { text: 'Worksheet' })), el('div', { class: 'pad' }, [el('div', { class: 'row', style: 'margin-bottom:12px' }, st.raw.sheets.map(s => el('button', { class: 'btn sm ' + (st.chosenSheet === s.name ? '' : 'ghost'), onclick: () => chooseSheet(M, st, s.name) }, el('span', { text: `${s.name} · ${s.rows.length} rows` })))), headerPicker(M, st)])]));
  }
  if (st.step === 1) { const fake = { ref: M.code, title: 'Column mapping' }; out.push(...pageMapping(M, st, fake).map(x => x)); out.push(el('div', { class: 'card' }, [el('h3', {}, el('span', { text: 'Cleaning log' })), el('div', { class: 'tw', style: 'max-height:260px' }, logTable(st.cleanLog))])); }
  if (st.step === 2) out.push(...genericConfig(M, st));
  if (st.step === 3) out.push(...genericExceptions(M, st));
  if (st.step === 4) out.push(...genericPaper(M, st));
  return out;
}
function dropZoneGeneric(M, st) {
  const input = el('input', { type: 'file', accept: M.accepts, style: 'display:none', onchange: e => e.target.files[0] && loadFile(M, st, e.target.files[0]) });
  const zone = el('div', { class: 'drop', onclick: () => input.click(), ondragover: e => { e.preventDefault(); zone.classList.add('over'); }, ondragleave: () => zone.classList.remove('over'), ondrop: e => { e.preventDefault(); zone.classList.remove('over'); e.dataTransfer.files[0] && loadFile(M, st, e.dataTransfer.files[0]); } },
    [el('div', { class: 'big', text: (st.raw ? 'Replace the ' : 'Upload the ') + M.name.toLowerCase() }), el('div', { class: 'sm', text: 'Drop the client file here or click to choose' }), input]);
  return zone;
}
function genericConfig(M, st) {
  const groups = {}; (M.config || []).forEach(c => (groups[c.group || 'Test parameters'] = groups[c.group || 'Test parameters'] || []).push(c));
  const out = Object.entries(groups).map(([g, cs]) => el('div', { class: 'card' }, [el('h3', {}, el('span', { text: g === 'ECL' ? 'Provision matrix — FRS 109' : g })), el('div', { class: 'pad' }, el('div', { class: 'grid2' }, cs.map(c => configField(M, st, c))))]));
  if (M.code === 'AR' && st.derived?.matrix) out.push(eclCard(M, st));
  out.push(el('div', { class: 'row' }, el('button', { class: 'btn', onclick: () => { st.step = 3; render(); }, text: `Review ${st.exceptions.length} exception(s)` })));
  return out;
}
function configField(M, st, c) {
  const on = e => { st.config[c.key] = c.type === 'check' ? e.target.checked : c.type === 'number' ? (e.target.value === '' ? '' : Number(e.target.value)) : e.target.value; recompute(M, st, false); c.type === 'select' ? render() : soft(); };
  let input;
  if (c.type === 'select') input = el('select', { onchange: on }, c.options.map(o => el('option', { value: o, selected: st.config[c.key] === o ? 'selected' : null }, el('span', { text: o }))));
  else if (c.type === 'check') input = el('div', {}, el('label', { class: 'small' }, [el('input', { type: 'checkbox', checked: st.config[c.key] ? 'checked' : null, onchange: on }), el('span', { text: st.config[c.key] ? 'Enabled' : 'Disabled' })]));
  else input = el('input', { type: c.type === 'number' ? 'number' : 'text', step: 'any', 'data-k': 'cfg-' + c.key, value: st.config[c.key] ?? '', oninput: on });
  return el('label', { class: 'fld' }, [el('span', { text: c.label }), input, c.help ? el('span', { class: 'help', text: c.help }) : null]);
}
function eclCard(M, st) {
  const d = st.derived, t = el('table');
  t.append(el('thead', {}, el('tr', {}, ['Ageing bucket', 'Items', 'Gross', 'Loss rate', '× multiplier', 'Adjusted rate', 'Expected credit loss'].map((h, i) => el('th', { class: i ? 'num' : '', text: h })))));
  t.append(el('tbody', {}, d.matrix.map(m => el('tr', {}, [td(m.label), el('td', { class: 'num', text: m.count }), tdn(m.gross), el('td', { class: 'num mono', text: (m.rate * 100).toFixed(2) + '%' }), el('td', { class: 'num mono', text: (Number(st.config.fwdMultiplier) || 0).toFixed(2) }), el('td', { class: 'num mono', text: (m.adjRate * 100).toFixed(2) + '%' }), el('td', { class: 'num mono em', text: money(m.ecl) })]))));
  const rec = Number(st.config.recordedAllowance) || 0;
  return el('div', { class: 'card' }, [el('h3', {}, el('span', { text: 'Provision matrix' })), el('div', { class: 'tw', style: 'max-height:none' }, t), el('div', { class: 'pad' }, el('dl', { class: 'stats' }, [stat('Gross receivables', money0(d.total)), stat('ECL per audit', money0(d.ecl)), stat('Allowance per ledger', money0(rec)), stat('Difference', money(d.allowanceDiff), Math.abs(d.allowanceDiff) > (state.engagement.materiality.trivial || 0) ? 'bad' : 'ok')]))]);
}
function genericExceptions(M, st) {
  const t = el('table'); t.append(el('thead', {}, el('tr', {}, ['ID', 'Exception', 'Record', 'Expected', 'Actual', 'Difference', 'Severity', 'Disposition', 'Reason'].map((h, i) => el('th', { class: [3, 4, 5].includes(i) ? 'num' : '', text: h })))));
  t.append(el('tbody', {}, st.exceptions.map(x => el('tr', {}, [el('td', {}, el('span', { class: 'chip info', text: x.id })), el('td', { class: 'wrapcell' }, [el('div', { text: x.label }), x.detail ? el('div', { class: 'small muted', text: x.detail }) : null]), el('td', { class: 'small', text: String(x.recordKey ?? '') }), td(typeof x.expected === 'number' ? money(x.expected) : (x.expected ?? ''), 'num mono'), td(typeof x.actual === 'number' ? money(x.actual) : (x.actual ?? ''), 'num mono'), el('td', { class: numCls(x.difference) + ' em', text: x.difference != null ? money(x.difference) : '' }), el('td', {}, el('span', { class: 'chip ' + (x.severity === 'above-pm' ? 'bad' : x.severity === 'above-trivial' ? 'warn' : 'grey'), text: Exporter.sevLabel(x.severity) })), el('td', {}, el('select', { onchange: ev => { x.disposition = ev.target.value; } }, ['open', 'accepted', 'cleared', 'adjusted', 'rejected'].map(o => el('option', { value: o, selected: x.disposition === o ? 'selected' : null }, el('span', { text: o }))))), el('td', { class: 'inp' }, el('input', { type: 'text', value: x.reason || '', onchange: ev => { x.reason = ev.target.value; } }))]))));
  return [el('div', { class: 'card' }, [el('h3', {}, [el('span', { text: 'Exception register' }), el('span', { class: 'sub', text: `${st.exceptions.length} raised` })]), el('div', { class: 'tw' }, t)]), el('div', { class: 'row' }, el('button', { class: 'btn', onclick: () => { st.step = 4; render(); }, text: 'Continue to the working paper' }))];
}
function genericPaper(M, st) {
  return [el('div', { class: 'card' }, [el('h3', {}, el('span', { text: 'Working paper' })), el('div', { class: 'pad' }, [
    el('h4', { style: 'margin-bottom:8px', text: 'Objective' }), el('p', { class: 'small', text: M.objective }),
    el('h4', { style: 'margin:16px 0 8px', text: 'Procedures' }), el('ol', { class: 'small' }, M.procedures.map(p => el('li', { text: p }))),
    el('label', { class: 'fld', style: 'margin-top:18px' }, [el('span', { text: 'Auditor comments' }), el('textarea', { oninput: ev => { st.comments = ev.target.value; } }, el('span', { text: st.comments }))]),
    el('label', { class: 'fld' }, [el('span', { text: 'Conclusion' }), el('textarea', { oninput: ev => { st.conclusion = ev.target.value; } }, el('span', { text: st.conclusion }))]),
    el('button', { class: 'btn', onclick: () => { try { const n = Exporter.download(state, M.code); trail(M.code, 'Exported', n); toast('Downloaded ' + n); } catch (err) { toast('Export failed: ' + err.message); } }, text: 'Download Excel working paper' })])])];
}

/* ------------------------------------------------------------ MODALS */
function openSettings() {
  const e = state.engagement, m = e.materiality;
  const body = el('div', { class: 'bd' }, [
    el('div', { class: 'grid2' }, [
      el('div', {}, [el('h4', { style: 'margin-bottom:14px', text: 'Engagement' }),
        fld('Entity name', 'text', e.client, v => e.client = v, 'Never populated automatically.'), fld('Audit firm / file reference', 'text', e.firmRef, v => e.firmRef = v),
        fld('Financial year end', 'date', e.yearEnd, v => e.yearEnd = v), fld('Prior year end', 'date', e.priorYearEnd, v => e.priorYearEnd = v),
        fld('Presentation currency', 'text', e.currency, v => e.currency = v), selFld('Reporting framework', ['IFRS / SFRS(I)'], e.framework, v => e.framework = v)]),
      el('div', {}, [el('h4', { style: 'margin-bottom:14px', text: 'Sign-off' }),
        fld('Prepared by', 'text', e.preparedBy, v => e.preparedBy = v), fld('Date prepared', 'date', e.datePrepared, v => e.datePrepared = v),
        fld('Reviewed by', 'text', e.reviewedBy, v => e.reviewedBy = v), fld('Date reviewed', 'date', e.dateReviewed, v => e.dateReviewed = v),
        fld('PPE file reference (your firm\'s index)', 'text', e.indexRef.PPE || 'E3', v => e.indexRef.PPE = v)])]),
    el('h4', { style: 'margin:22px 0 14px', text: 'Materiality' }),
    el('div', { class: 'grid2' }, [
      el('div', {}, [selFld('Benchmark', Core.MAT_BASES.map(b => b.label), m.basisLabel, v => { const b = Core.MAT_BASES.find(x => x.label === v); m.basis = b.key; m.basisLabel = b.label; m.rate = b.def; refreshMat(); }),
        fld('Benchmark amount', 'number', m.benchmark, v => { m.benchmark = Number(v) || 0; refreshMat(); }, e.tbSuggest?.turnover ? `From the trial balance: turnover ${money(e.tbSuggest.turnover)}` : null),
        fld('Rate', 'number', m.rate, v => { m.rate = Number(v) || 0; refreshMat(); }, 'As a decimal. Turnover 0.01–0.03, PBT 0.03–0.07, total assets 0.01–0.03, net assets 0.03–0.05.')]),
      el('div', {}, [fld('Performance materiality as a proportion of overall', 'number', m.pmPct, v => { m.pmPct = Number(v) || 0; refreshMat(); }),
        fld('Trivial threshold as a proportion of overall', 'number', m.trivialPct, v => { m.trivialPct = Number(v) || 0; refreshMat(); }), el('dl', { class: 'stats', id: 'matout' })])]),
    el('h4', { style: 'margin:22px 0 14px', text: 'Privacy and local storage' }),
    el('div', { class: 'note', text: 'Client schedules and working papers stay in this browser. No audit data is sent to this website or to AI. AI assistance is unavailable in this release. Engagement details, mapping profiles, uploaded schedules and working papers are held only in this tab\'s memory. Nothing is saved in browser storage. Export every section before reloading, closing or signing out.' }),
    el('button', { class: 'btn ghost', onclick: requestEndSession, text: scope ? 'End session and sign out' : 'End session and clear data' })
  ]);
  const box = el('div', { class: 'box' }, [el('h3', {}, [el('span', { text: 'Engagement settings' }), el('span', { class: 'row' }, [el('button', { class: 'btn sm gold', onclick: () => { close(); fillDemo(); }, text: 'Fill demo details' }), el('button', { class: 'btn ghost sm', onclick: close, text: 'Close' })])]), body,
    el('div', { class: 'ft' }, [el('button', { class: 'btn ghost', onclick: close, text: 'Cancel' }), el('button', { class: 'btn', onclick: () => { save(); close(); Modules.ALL.forEach(mm => recompute(mm, state.modules[mm.code], false)); render(); toast('Applied for this session'); }, text: 'Apply to this session' })])]);
  const modal = el('div', { class: 'modal', onclick: ev => { if (ev.target === modal) close(); } }, box);
  document.body.append(modal); refreshMat();
  function close() { modal.remove(); }
  function refreshMat() { recalcMateriality(); const host = modal.querySelector('#matout'); if (host) host.replaceChildren(stat('Overall', money0(m.om)), stat('Performance', money0(m.pm)), stat('Trivial', money0(m.trivial))); }
}
function fld(label, type, value, set, help) { return el('label', { class: 'fld' }, [el('span', { text: label }), el('input', { type, step: 'any', value: value ?? '', oninput: ev => set(ev.target.value) }), help ? el('span', { class: 'help', text: help }) : null]); }
function selFld(label, options, value, set) { return el('label', { class: 'fld' }, [el('span', { text: label }), el('select', { onchange: ev => set(ev.target.value) }, options.map(o => el('option', { value: o, selected: o === value ? 'selected' : null }, el('span', { text: o }))))]); }
function openAbout() {
  const modal = el('div', { class: 'modal', onclick: ev => { if (ev.target === modal) modal.remove(); } }, el('div', { class: 'box' }, [el('h3', {}, [el('span', { text: 'About this build' }), el('button', { class: 'btn ghost sm', onclick: () => modal.remove(), text: 'Close' })]),
    el('div', { class: 'bd' }, [el('p', { html: '<b>The PPE file, end to end.</b> One uploaded fixed asset listing produces the lead schedule, the movement note, the depreciation reasonableness test, additions and disposals testing and the FRS 36 impairment assessment — as working papers you read and complete in the app before exporting.' }),
      el('p', { style: 'margin-top:14px', html: '<b>Nothing leaves your browser.</b> Files are read locally. Engagement details, schedules, working papers and mapping profiles are held only in this tab\'s memory. Export before reloading, closing or ending the session.' }),
      el('p', { style: 'margin-top:14px', html: '<b>Rules first.</b> Every figure is deterministic. AI is not used for any calculation.' })])]));
  document.body.append(modal);
}

function init() {
  load(); render();
  try { channel = new BroadcastChannel('awp-session'); channel.onmessage = e => { if (e.data === 'end') endSession(false); }; } catch (e) {}
  window.addEventListener('storage', e => {
    if (e.key === END_SIGNAL && e.newValue) endSession(false);
    else if (/^awp\.engagement\.v\d+(?::|$)/.test(e.key || '')) purgeLegacy();
  });
  window.addEventListener('pagehide', () => endSession(false));
  window.addEventListener('pageshow', e => { if (e.persisted) endSession(false); });
  settingsTimer = setTimeout(() => { if (!ended && !state.engagement.client) openSettings(); }, 350);
}
return { init, get state() { return state; }, render, recompute };
})();
document.addEventListener('DOMContentLoaded', App.init);
