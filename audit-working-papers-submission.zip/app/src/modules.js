/* ==========================================================================
   modules.js -- one entry per audit area.
   A module is data: a field dictionary, a config schema, a compute step and
   a list of tests. Adding an audit area does not require touching core.js
   or ui.js.
   ========================================================================== */

const Modules = (() => {
const D = Core;
const days = (a, b) => (a && b) ? Math.round((a - b) / 86400000) : null;
const r2 = n => n == null ? null : Math.round(n * 100) / 100;
const near = (a, b, tol) => Math.abs((a || 0) - (b || 0)) <= tol;

/* ======================================================================
   AR -- Trade receivables: aging rebuild and the FRS 109 provision matrix
   ====================================================================== */
const AR_BUCKETS = [
  { key:'b_current', label:'Not yet due', from:-1e9, to:0 },
  { key:'b_1_30',    label:'1–30 days',   from:1,   to:30 },
  { key:'b_31_60',   label:'31–60 days',  from:31,  to:60 },
  { key:'b_61_90',   label:'61–90 days',  from:61,  to:90 },
  { key:'b_91_180',  label:'91–180 days', from:91,  to:180 },
  { key:'b_181_365', label:'181–365 days',from:181, to:365 },
  { key:'b_over',    label:'Over 365 days',    from:366, to:1e9 }
];

const AR = {
  code:'AR', name:'Trade Receivables & ECL', group:'Assets',
  blurb:'Aging rebuilt from invoice dates and terms, credit balances and cut-off, and an FRS 109 provision matrix recomputed from loss rates the auditor sets per bucket.',
  accepts:'.xlsx,.xlsm,.csv',
  objective:'To obtain sufficient appropriate audit evidence that trade receivables exist, are recorded at the amounts due, and are stated net of an appropriate loss allowance measured in accordance with FRS 109.',
  fields: [
    { key:'cust_code', label:'Customer code', role:'key', type:'text',
      synonyms:['Customer Code','Cust Code','Debtor Code','A/C No','Code','Account No'] },
    { key:'cust_name', label:'Customer name', type:'text', required:true, dupKey:true,
      synonyms:['Customer','Customer Name','Debtor','Debtor Name','CUSTOMERS','Account Name','客户名称'] },
    { key:'invoice_no', label:'Invoice number', type:'text', required:true, dupKey:true,
      synonyms:['Invoice No','Inv No.','Document No','Ref','Invoice Number','Doc No','发票号'] },
    { key:'invoice_date', label:'Invoice date', type:'date', required:true,
      synonyms:['Invoice Date','Doc Date','Date','Inv. Date','Trans Date','发票日期'] },
    { key:'due_date', label:'Due date', type:'date',
      synonyms:['Due Date','Date Due','Maturity','Payment Due'] },
    { key:'terms', label:'Credit terms (days)', type:'number',
      synonyms:['Terms','Credit Terms','Term','Payment Terms','Days'] },
    { key:'currency', label:'Currency', type:'text',
      synonyms:['Currency','Cur','Curr','CCY','Txn Ccy','币种'] },
    { key:'amount', label:'Amount outstanding', type:'number', required:true, dupKey:true,
      synonyms:['Amount','Outstanding','Balance','Outstanding Balance','Amount Due','Total','金额'] },
    { key:'related', label:'Related party (Y/N)', type:'text',
      synonyms:['Related Party','RP','Intercompany','Related'] }
  ],
  config: [
    { key:'ageFrom', label:'Age balances from', type:'select',
      options:['Due date where present, else invoice date + terms','Invoice date'], def:'Due date where present, else invoice date + terms' },
    { key:'defaultTerms', label:'Default credit terms where not stated (days)', type:'number', def:30 },
    { key:'longOverdue', label:'Long outstanding threshold (days past due)', type:'number', def:365 },
    { key:'roundSum', label:'Round-sum flag: multiple of', type:'number', def:100000 },
    { key:'castTol', label:'Casting tolerance', type:'number', def:0.01 },
    { key:'eclOn', label:'Compute the FRS 109 provision matrix', type:'check', def:true },
    { key:'ecl_b_current', label:'Loss rate % — not yet due',    type:'number', def:0.2, group:'ECL' },
    { key:'ecl_b_1_30',    label:'Loss rate % — 1–30 days',  type:'number', def:0.5, group:'ECL' },
    { key:'ecl_b_31_60',   label:'Loss rate % — 31–60 days', type:'number', def:1.2, group:'ECL' },
    { key:'ecl_b_61_90',   label:'Loss rate % — 61–90 days', type:'number', def:2.8, group:'ECL' },
    { key:'ecl_b_91_180',  label:'Loss rate % — 91–180 days',type:'number', def:7.5, group:'ECL' },
    { key:'ecl_b_181_365', label:'Loss rate % — 181–365 days',type:'number', def:18.5, group:'ECL' },
    { key:'ecl_b_over',    label:'Loss rate % — over 365 days',  type:'number', def:52.0, group:'ECL' },
    { key:'fwdMultiplier', label:'Forward-looking multiplier', type:'number', def:1.0, group:'ECL',
      help:'Probability-weighted multiplier applied to every observed loss rate. FRS 109 para 5.5.17 requires forward-looking information; a multiplier of exactly 1 with no scenario support is itself reportable.' },
    { key:'recordedAllowance', label:'Loss allowance per the trial balance', type:'number', def:0, group:'ECL' }
  ],
  compute(recs, cfg, eng) {
    const ye = eng.yearEndDate;
    const buckets = {}; AR_BUCKETS.forEach(b => buckets[b.key] = { gross:0, count:0 });
    let total = 0, credits = 0;
    for (const r of recs) {
      r.__displayKey = (r.cust_name || r.cust_code || '') + ' / ' + (r.invoice_no || r.__srcRow);
      const terms = r.terms != null ? r.terms : cfg.defaultTerms;
      let dueDate = r.due_date;
      if (cfg.ageFrom === 'Invoice date') dueDate = r.invoice_date;
      else if (!dueDate && r.invoice_date)
        dueDate = new Date(r.invoice_date.getTime() + terms * 86400000);
      r.__dueDerived = !r.due_date && !!dueDate;
      r.__due = dueDate;
      r.__daysOverdue = (dueDate && ye) ? days(ye, dueDate) : null;
      r.__daysOutstanding = (r.invoice_date && ye) ? days(ye, r.invoice_date) : null;
      const od = r.__daysOverdue;
      const b = od == null ? null : AR_BUCKETS.find(x => od >= x.from && od <= x.to);
      r.__bucket = b ? b.key : null;
      r.__bucketLabel = b ? b.label : 'Not aged';
      if (b) { buckets[b.key].gross += (r.amount || 0); buckets[b.key].count++; }
      total += (r.amount || 0);
      if ((r.amount || 0) < 0) credits += r.amount;
    }
    /* provision matrix */
    const mult = Number(cfg.fwdMultiplier) || 0;
    let ecl = 0;
    const matrix = AR_BUCKETS.map(b => {
      const rate = (Number(cfg['ecl_' + b.key]) || 0) / 100;
      const adj = rate * mult;
      const amount = r2(buckets[b.key].gross * adj);
      ecl += amount;
      return { key:b.key, label:b.label, gross:r2(buckets[b.key].gross), count:buckets[b.key].count,
               rate, adjRate:adj, ecl:amount };
    });
    for (const r of recs) {
      const m = matrix.find(x => x.key === r.__bucket);
      r.__eclRate = m ? m.adjRate : 0;
      r.__ecl = r2((r.amount || 0) * (m ? m.adjRate : 0));
    }
    return { buckets, matrix, total:r2(total), credits:r2(credits), ecl:r2(ecl),
             allowanceDiff: r2(ecl - (Number(cfg.recordedAllowance) || 0)) };
  },
  tests: [
    { id:'EX-AR-01', label:'Credit balance in the receivables listing',
      basis:'amount < 0',
      fn:(r) => (r.amount||0) < -0.01 &&
        { actual:r.amount, difference:r.amount, cell:r['__cell_amount'],
          detail:'Credit balance may require reclassification to payables' } },
    { id:'EX-AR-02', label:'Invoice dated after the year end',
      basis:'invoice_date > year end',
      fn:(r,cfg,eng) => r.invoice_date && eng.yearEndDate && r.invoice_date > eng.yearEndDate &&
        { actual:Core.fmtDate(r.invoice_date), difference:r.amount, cell:r['__cell_invoice_date'],
          detail:'Cut-off: invoice raised after the reporting date' } },
    { id:'EX-AR-03', label:'Due date earlier than the invoice date',
      basis:'due_date < invoice_date', severity:'informational',
      fn:(r) => r.due_date && r.invoice_date && r.due_date < r.invoice_date &&
        { actual:Core.fmtDate(r.due_date), cell:r['__cell_due_date'] } },
    { id:'EX-AR-04', label:'Long outstanding balance',
      basis:'days past due beyond the auditor-set threshold',
      fn:(r,cfg) => r.__daysOverdue != null && r.__daysOverdue > cfg.longOverdue && (r.amount||0) > 0 &&
        { actual:r.__daysOverdue, difference:r.amount,
          detail:`${r.__daysOverdue} days past due — consider whether credit-impaired (FRS 109 para 5.5.3)` } },
    { id:'EX-AR-05', label:'Counterparty not stated',
      basis:'customer name blank', severity:'informational',
      fn:(r) => !r.cust_name && { difference:r.amount, cell:r['__cell_cust_name'] } },
    { id:'EX-AR-06', label:'Duplicate invoice',
      basis:'Same customer, invoice number and amount',
      fn:(r) => { const f = r.__flags.find(x => x.rule === 'DQ-10');
                  return f && { detail:f.detail, difference:r.amount }; } },
    { id:'EX-AR-08', label:'Round-sum item with a non-invoice reference',
      basis:'Round multiple and a reference not matching the invoice pattern', severity:'informational',
      fn:(r,cfg) => {
        const a = Math.abs(r.amount||0);
        if (!a || !cfg.roundSum || a % cfg.roundSum !== 0) return false;
        return { actual:r.amount, difference:r.amount,
                 detail:'Possible manual journal rather than an invoice' };
      } },
    { id:'EX-AR-10', label:'Nil value open item',
      basis:'amount = 0', severity:'informational',
      fn:(r) => r.amount != null && Math.abs(r.amount) < 0.005 && { detail:'Open item with no balance' } },
    { id:'EX-ECL-09', scope:'population', label:'Provision matrix does not agree to the recorded loss allowance',
      basis:'Computed ECL against the allowance in the trial balance',
      fn:(recs,cfg,eng,der) => {
        if (!cfg.eclOn) return false;
        const rec = Number(cfg.recordedAllowance) || 0;
        const d = r2(der.ecl - rec);
        return Math.abs(d) > Math.max(cfg.castTol, 0.01) &&
          { key:'Loss allowance', expected:der.ecl, actual:rec, difference:d,
            detail:'Recomputed expected credit loss against the allowance carried in the ledger' };
      } },
    { id:'EX-ECL-02', scope:'population', label:'No forward-looking adjustment applied',
      basis:'FRS 109 para 5.5.17 — unbiased probability-weighted amount reflecting forecasts',
      severity:'above-trivial',
      fn:(recs,cfg) => cfg.eclOn && Number(cfg.fwdMultiplier) === 1 &&
        { key:'Forward-looking overlay', actual:1,
          detail:'The multiplier is exactly 1. Record the scenarios, weights and source, or document why no adjustment is required.' } },
    { id:'EX-ECL-01', scope:'population', label:'Nil loss rate applied to a past-due bucket',
      basis:'FRS 109 para B5.5.35 — rates derived from observed loss history',
      fn:(recs,cfg,eng,der) => {
        if (!cfg.eclOn) return false;
        return der.matrix.filter(m => m.key !== 'b_current' && m.gross > 0 && m.rate === 0)
          .map(m => ({ key:m.label, actual:0, difference:m.gross,
                       detail:`${m.label} carries ${m.gross.toFixed(2)} at a nil loss rate` }));
      } }
  ],
  procedures: [
    'Rebuilt the ageing of trade receivables from the invoice date and credit terms and compared it to the ageing prepared by the Company.',
    'Reviewed the listing for credit balances, nil balances and items with no counterparty recorded.',
    'Tested cut-off by identifying invoices dated after the reporting date included in the balance.',
    'Identified balances outstanding beyond the threshold set for the engagement and considered whether they are credit-impaired.',
    'Recomputed the loss allowance using a provision matrix, applying loss rates by ageing bucket and a forward-looking multiplier, and compared the result to the allowance recorded.'
  ],
  columns: [
    { key:'cust_name', label:'Customer' }, { key:'invoice_no', label:'Invoice' },
    { key:'invoice_date', label:'Invoice date', type:'date' },
    { key:'__due', label:'Due', type:'date' },
    { key:'__daysOverdue', label:'Days overdue', type:'num', dp:0 },
    { key:'__bucketLabel', label:'Bucket' },
    { key:'currency', label:'Ccy' },
    { key:'amount', label:'Amount', type:'num' },
    { key:'__eclRate', label:'ECL rate', type:'pct' },
    { key:'__ecl', label:'ECL', type:'num', emphasis:true }
  ]
};

/* ======================================================================
   TB -- Trial balance. Feeds materiality and the register-to-ledger ties.
   ====================================================================== */
const TB = {
  code:'TB', name:'Trial Balance', group:'Foundations',
  blurb:'Balances the trial balance, derives the materiality benchmarks, and supplies the captions other modules tie their schedules back to.',
  accepts:'.xlsx,.xlsm,.csv',
  objective:'To agree the trial balance to the accounting records, confirm that it balances, and establish the benchmarks on which materiality and the schedule-to-ledger reconciliations are based.',
  fields: [
    { key:'code', label:'Account code', role:'key', type:'text', required:true,
      synonyms:['Account','Account No','A/C Code','GL Code','Account Number','Nominal Code','Account Code','科目代码'] },
    { key:'name', label:'Account name', type:'text', required:true,
      synonyms:['Account Name','Description','Account Description','Name','Particulars','Text for B/S P&L item','科目名称'] },
    { key:'debit', label:'Debit', type:'number',
      synonyms:['Debit','Dr','Debit (Dr)','Debit Amount','借方'] },
    { key:'credit', label:'Credit', type:'number',
      synonyms:['Credit','Cr','Credit (Cr)','Credit Amount','贷方'] },
    { key:'balance', label:'Balance', type:'number',
      synonyms:['Balance','Net Balance','Amount','Closing Balance','Balance at Year End','余额'] },
    { key:'balance_py', label:'Prior year', type:'number',
      synonyms:['Prior Year','PY Balance','Comparative','Last Year','Balance b/f'] },
    { key:'caption', label:'FS caption', type:'text',
      synonyms:['FS Line','Grouping','Map No.','FS Caption','L/S'] }
  ],
  config: [
    { key:'castTol', label:'Out-of-balance tolerance', type:'number', def:0.01 },
    { key:'signConv', label:'Balance sign convention', type:'select',
      options:['Debits positive, credits negative','Debits positive, credits positive (absolute)'],
      def:'Debits positive, credits negative' }
  ],
  compute(recs, cfg) {
    let dr = 0, cr = 0, net = 0;
    for (const r of recs) {
      r.__displayKey = (r.code || '') + ' ' + (r.name || '');
      let bal = r.balance;
      if (bal == null) {
        if (r.debit != null || r.credit != null) bal = (r.debit || 0) - (r.credit || 0);
      }
      r.__balance = bal == null ? 0 : bal;
      if (r.debit != null || r.credit != null) { dr += (r.debit || 0); cr += (r.credit || 0); }
      net += r.__balance;
    }
    return { debit:r2(dr), credit:r2(cr), net:r2(net), rows:recs.length,
             outOfBalance: r2(Math.abs(dr - cr) > 0.001 ? dr - cr : net) };
  },
  tests: [
    { id:'EX-TIE-02', scope:'population', label:'Trial balance does not balance',
      basis:'Debits ≠ credits, or balances do not net to nil',
      fn:(recs,cfg,eng,der) => Math.abs(der.outOfBalance) > cfg.castTol &&
        { key:'Trial balance', actual:der.outOfBalance, difference:der.outOfBalance,
          detail:`Out of balance by ${der.outOfBalance.toFixed(2)}` } },
    { id:'EX-TB-02', label:'Account with no code or no name',
      basis:'Mandatory field blank', severity:'informational',
      fn:(r) => (!r.code || !r.name) && { difference:r.__balance, detail:'Incomplete account master data' } },
    { id:'EX-TB-03', label:'Account carries both a debit and a credit',
      basis:'debit and credit both populated', severity:'informational',
      fn:(r) => (r.debit||0) !== 0 && (r.credit||0) !== 0 &&
        { detail:'Both columns populated on one line' } }
  ],
  procedures: [
    'Agreed the trial balance to the accounting records and confirmed that it balances.',
    'Reviewed account master data for completeness.',
    'Established the materiality benchmarks from the trial balance.'
  ],
  columns: [
    { key:'code', label:'Code' }, { key:'name', label:'Account name' },
    { key:'caption', label:'FS caption' },
    { key:'debit', label:'Debit', type:'num' }, { key:'credit', label:'Credit', type:'num' },
    { key:'__balance', label:'Balance', type:'num', emphasis:true },
    { key:'balance_py', label:'Prior year', type:'num' }
  ]
};

const ALL = [TB, PPEModule, AR];
const byCode = Object.fromEntries(ALL.map(m => [m.code, m]));
const register = m => {                       // a later module file replaces an earlier one with the same code
  const i = ALL.findIndex(x => x.code === m.code);
  if (i >= 0) ALL[i] = m; else ALL.push(m);
  byCode[m.code] = m;
};
return { ALL, byCode, AR_BUCKETS, register };
})();
