/* ==========================================================================
   ap.js -- Trade payables as an auditor actually works it.

   One uploaded open-item payables listing feeds:
     U3    Lead schedule                     U3.3  Subsequent payments
     U3.1  Ageing rebuilt by supplier        U3.4  Search for unrecorded liabilities
     U3.2  Supplier statements / circularisation   U3.5  Cut-off, duplicates and round sums
   ========================================================================== */

const APModule = (() => {
const r2 = n => n == null || isNaN(n) ? null : Math.round(n * 100) / 100;
const days = (a, b) => (a && b) ? Math.round((a - b) / 86400000) : null;
const num = v => (v === '' || v == null || isNaN(Number(v))) ? null : Number(v);
const inp = (cfg, key, k) => num(cfg[key + ':' + k]);
const txt = (cfg, key, k) => { const v = cfg[key + ':' + k]; return v == null ? '' : String(v); };

function mulberry32(seed) {
  let a = (seed >>> 0) || 1;
  return () => {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function sampleN(items, n, seed) {
  const rnd = mulberry32(seed);
  const pool = items.slice();
  const out = [];
  while (out.length < n && pool.length) out.push(pool.splice(Math.floor(rnd() * pool.length), 1)[0]);
  return out;
}

/* ---------------------------------------------------------------- fields */
const fields = [
  { key:'supplier_code', label:'Supplier code', role:'key', type:'text',
    synonyms:['Supplier Code','Vendor Code','Creditor Code','A/C No','Supplier No','Vendor No','Account No','Vendor ID','Supplier ID','Code','供应商编码','供应商代码'] },
  { key:'supplier_name', label:'Supplier name', type:'text', required:true, dupKey:true,
    synonyms:['Supplier','Supplier Name','Vendor Name','Creditor','Vendor','Payee','Creditor Name','Name','Account Name','Beneficiary','供应商名称','供应商'] },
  { key:'invoice_no', label:'Invoice number', type:'text', required:true, dupKey:true,
    synonyms:['Invoice No','Supplier Inv No','Bill No','Doc No','Ref','Invoice Number','Inv No.','Inv No','Reference','Document No','Bill Number','Voucher No','发票号','发票号码'] },
  { key:'invoice_date', label:'Invoice date', type:'date', required:true,
    synonyms:['Invoice Date','Bill Date','Date','Doc Date','Inv. Date','Inv Date','Document Date','Trans Date','Posting Date','发票日期','日期'] },
  { key:'due_date', label:'Due date', type:'date',
    synonyms:['Due Date','Date Due','Payment Due','Maturity','Due','到期日'] },
  { key:'terms', label:'Credit terms (days)', type:'number',
    synonyms:['Terms','Credit Terms','Term','Payment Terms','Days','Credit Days','Terms (Days)'] },
  { key:'currency', label:'Currency', type:'text',
    synonyms:['Currency','Cur','Curr','CCY','Txn Ccy','币种'] },
  { key:'amount', label:'Amount outstanding', type:'number', required:true, dupKey:true,
    synonyms:['Amount','Outstanding','Balance','Outstanding Balance','Amount Due','Total','Amount Outstanding','Open Amount','Balance Due','金额','余额'] },
  { key:'description', label:'Description', type:'text',
    synonyms:['Description','Particulars','Details','Narrative','Memo','摘要'] },
  { key:'related', label:'Related party (Y/N)', type:'text',
    synonyms:['Related Party','RP','Intercompany','Related','关联方'] }
];

const STANDARD_COLUMNS = [
  { key:'supplier_code', label:'Code' }, { key:'supplier_name', label:'Supplier' }, { key:'invoice_no', label:'Invoice' },
  { key:'invoice_date', label:'Invoice date', type:'date', edit:true }, { key:'__due', label:'Due', type:'date' },
  { key:'__daysOutstanding', label:'Days since invoice', type:'num', dp:0 }, { key:'__daysOverdue', label:'Days past due', type:'num', dp:0 },
  { key:'__bucketLabel', label:'Bucket' }, { key:'currency', label:'Ccy' }, { key:'amount', label:'Amount', type:'num', edit:true, emphasis:true }
];

const defaultConfig = () => ({
  castTol: 0.01,
  tbBalance: '', pyBalance: '', purchases: '',
  ageBasis: 'due',                       // 'due' = invoice date + terms (or due date); 'invoice' = days since invoice
  defaultTerms: 30,
  bucketEdges: '30,60,90,180,365',
  clientAgingTotal: '',
  longOutstanding: 365,
  roundSum: 10000,
  invoicePattern: '^[A-Za-z]{1,4}[-/ ]?\\d{3,}',
  circThreshold: '', circSampleN: 5, circSeed: 20250228,
  sulRows: 10
});

function buckets(cfg) {
  const edges = String(cfg.bucketEdges || '30,60,90,180,365').split(/[,\s;]+/).map(Number).filter(n => n > 0).sort((a, b) => a - b);
  const out = [{ key:'b0', label: cfg.ageBasis === 'invoice' ? `0–${edges[0] || 30} days` : 'Not yet due', from:-1e9, to: cfg.ageBasis === 'invoice' ? (edges[0] || 30) : 0 }];
  let prev = cfg.ageBasis === 'invoice' ? (edges[0] || 30) : 0;
  for (const e of (cfg.ageBasis === 'invoice' ? edges.slice(1) : edges)) { out.push({ key:'b' + prev + '_' + e, label:`${prev + 1}–${e} days`, from:prev + 1, to:e }); prev = e; }
  out.push({ key:'bover', label:`Over ${prev} days`, from:prev + 1, to:1e9 });
  return out;
}

/* ============================================================ COMPUTE */
function compute(recs, cfg, eng) {
  const ye = eng.yearEndDate;
  const pm = eng.materiality?.pm || 0, trivial = eng.materiality?.trivial || 0;
  const tol = Number(cfg.castTol) || 0.01;
  const B = buckets(cfg);
  const invRe = (() => { try { return new RegExp(cfg.invoicePattern || '^[A-Za-z]{1,4}[-/ ]?\\d{3,}', 'i'); } catch (e) { return /^[A-Za-z]{1,4}[-/ ]?\d{3,}/i; } })();
  const round = Number(cfg.roundSum) || 0;
  const live = recs.filter(r => !r.__excluded);

  const supKey = r => Core.keyify(r.supplier_name || '') || Core.keyify(r.supplier_code || '') || '(no supplier)';
  let total = 0, debits = 0, debitCount = 0, nils = 0, afterYE = 0, afterYEValue = 0;
  const byCcy = {}, sups = {}, bucketTot = {};
  B.forEach(b => bucketTot[b.key] = { key:b.key, label:b.label, amount:0, count:0 });

  for (const r of live) {
    r.__displayKey = (r.supplier_name || r.supplier_code || '(no supplier)') + ' / ' + (r.invoice_no || 'row ' + r.__srcRow);
    r.__supKey = supKey(r);
    const terms = r.terms != null ? r.terms : Number(cfg.defaultTerms) || 0;
    let due = r.due_date;
    if (!due && r.invoice_date) due = new Date(r.invoice_date.getTime() + terms * 86400000);
    r.__due = due; r.__dueDerived = !r.due_date && !!due;
    r.__daysOutstanding = (r.invoice_date && ye) ? days(ye, r.invoice_date) : null;
    r.__daysOverdue = (due && ye) ? days(ye, due) : null;
    const age = cfg.ageBasis === 'invoice' ? r.__daysOutstanding : r.__daysOverdue;
    const b = age == null ? null : B.find(x => age >= x.from && age <= x.to);
    r.__bucket = b ? b.key : null; r.__bucketLabel = b ? b.label : 'Not aged';
    const a = r.amount || 0;
    r.__afterYE = !!(r.invoice_date && ye && r.invoice_date > ye);
    r.__isRound = round > 0 && Math.abs(a) >= round && Math.abs(a % round) < 0.005;
    r.__nonInvoiceRef = !!(r.invoice_no && !invRe.test(String(r.invoice_no).trim()));
    r.__dup = r.__flags.find(x => x.rule === 'DQ-10') || null;
    r.__wsRef = !!r.__flags.find(x => x.rule === 'DQ-04' && x.field === 'invoice_no');
    r.__related = /^(y|yes|true|1|related|rp)$/i.test(String(r.related || '').trim());
    total += a;
    if (a < -0.005) { debits += a; debitCount++; }
    if (r.amount != null && Math.abs(a) < 0.005) nils++;
    if (r.__afterYE) { afterYE++; afterYEValue += a; }
    const c = r.currency || '(not stated)';
    const cc = byCcy[c] || (byCcy[c] = { currency:c, count:0, amount:0 }); cc.count++; cc.amount += a;
    if (b) { bucketTot[b.key].amount += a; bucketTot[b.key].count++; }
    const s = sups[r.__supKey] || (sups[r.__supKey] = { key:r.__supKey, supplier: r.supplier_name || r.supplier_code || '(no supplier)', code: r.supplier_code || '', count:0, amount:0, recs:[], related:false, oldest:null });
    s.count++; s.amount += a; s.recs.push(r); s.related = s.related || r.__related;
    if (b) s[b.key] = (s[b.key] || 0) + a;
    if (r.__daysOutstanding != null && (s.oldest == null || r.__daysOutstanding > s.oldest)) s.oldest = r.__daysOutstanding;
  }
  const currencies = Object.values(byCcy).map(c => ({ ...c, amount: r2(c.amount) })).sort((a, b) => Math.abs(b.amount) - Math.abs(a.amount));
  const suppliers = Object.values(sups).map(s => { const o = { ...s, amount: r2(s.amount) }; B.forEach(b => o[b.key] = r2(s[b.key] || 0)); return o; }).sort((a, b) => b.amount - a.amount);
  const bucketRows = B.map(b => ({ ...bucketTot[b.key], amount: r2(bucketTot[b.key].amount), client: inp(cfg, 'clientBucket', b.key) }))
    .map(b => ({ ...b, diff: b.client != null ? r2(b.amount - b.client) : null, share: total ? r2(b.amount / total * 100) : 0 }));
  const clientAging = num(cfg.clientAgingTotal);
  const clientBucketsEntered = bucketRows.some(b => b.client != null);
  const clientTotal = clientBucketsEntered ? r2(bucketRows.reduce((s, b) => s + (b.client || 0), 0)) : clientAging;

  /* ---- U3 lead ------------------------------------------------------- */
  const tb = num(cfg.tbBalance), py = num(cfg.pyBalance), purchases = num(cfg.purchases);
  const lead = { total: r2(total), tb, py, purchases,
    tbDiff: tb != null ? r2(total - tb) : null,
    variance: py != null ? r2(total - py) : null, variancePct: (py != null && py) ? r2((total - py) / Math.abs(py) * 100) : null,
    payableDays: (purchases && purchases > 0) ? r2(total / purchases * 365) : null,
    debits: r2(debits), debitCount, nils, afterYE, afterYEValue: r2(afterYEValue), count: live.length, supplierCount: suppliers.length };

  /* ---- U3.2 circularisation / supplier statements -------------------- */
  const threshold = cfg.circThreshold !== '' && cfg.circThreshold != null ? Number(cfg.circThreshold) : pm;
  const positive = suppliers.filter(s => s.amount > 0.005);
  const key = positive.filter(s => s.amount >= threshold || s.related);
  const residual = positive.filter(s => !key.includes(s));
  const nS = Math.min(Number(cfg.circSampleN) || 0, residual.length);
  const sample = sampleN(residual, nS, Number(cfg.circSeed) || 1);
  const selected = [...key, ...sample].sort((a, b) => b.amount - a.amount);
  const selectedKeys = new Set(selected.map(s => s.key));
  for (const r of live) r.__circSelected = selectedKeys.has(r.__supKey) ? (key.some(s => s.key === r.__supKey) ? 'key' : 'sample') : null;
  const circRows = selected.map(s => {
    const stmt = inp(cfg, 'stmtBal', s.key);
    return { ...s, basis: key.includes(s) ? (s.related ? 'Related party' : 'Key item') : 'Random sample', stmt,
      diff: stmt != null ? r2(stmt - s.amount) : null, recItems: txt(cfg, 'recItems', s.key), reconciled: txt(cfg, 'reconciled', s.key), altProc: txt(cfg, 'altProc', s.key),
      sent: txt(cfg, 'circSent', s.key), received: txt(cfg, 'circRecd', s.key) };
  });
  const selValue = r2(selected.reduce((s, x) => s + x.amount, 0));
  const posTotal = r2(positive.reduce((s, x) => s + x.amount, 0));
  const circ = { threshold, seed: Number(cfg.circSeed) || 1, key, residual, sample, selected, rows: circRows, selValue, posTotal,
    coverage: posTotal ? r2(selValue / posTotal * 100) : 0,
    reconciled: circRows.filter(x => x.reconciled === 'Y').length,
    unreconciled: circRows.filter(x => x.diff != null && Math.abs(x.diff) > tol && x.reconciled !== 'Y') };

  /* ---- U3.3 subsequent payments -------------------------------------- */
  const subpayRecs = live.filter(r => r.__circSelected && (r.amount || 0) > 0.005).sort((a, b) => (a.__supKey.localeCompare(b.__supKey)) || ((a.invoice_date || 0) - (b.invoice_date || 0)));
  let paid = 0;
  for (const r of subpayRecs) {
    const w = r.__wp?.subpay || {};
    r.__paid = num(w.payAmount);
    r.__unpaid = r2((r.amount || 0) - (r.__paid || 0));
    r.__payStatus = r.__paid == null ? 'Not yet traced' : r.__paid >= (r.amount || 0) - tol ? 'Paid in full' : r.__paid > 0 ? 'Part paid' : 'Unpaid';
    paid += Math.min(r.__paid || 0, r.amount || 0);
  }
  const subpayTotal = r2(subpayRecs.reduce((s, r) => s + (r.amount || 0), 0));
  const subpay = { recs: subpayRecs, total: subpayTotal, paid: r2(paid), coverage: subpayTotal ? r2(paid / subpayTotal * 100) : 0,
    traced: subpayRecs.filter(r => r.__paid != null).length, unpaid: subpayRecs.filter(r => r.__payStatus === 'Unpaid' || r.__payStatus === 'Part paid') };

  /* ---- U3.4 search for unrecorded liabilities ------------------------ */
  const nRows = Math.max(0, Math.min(60, Math.round(Number(cfg.sulRows) || 0)));
  const sulItems = [];
  for (let i = 1; i <= nRows; i++) {
    const k = 'sul' + i;
    const amount = inp(cfg, 'sulAmount', k), supplier = txt(cfg, 'sulSupplier', k);
    if (amount == null && !supplier && !txt(cfg, 'sulDesc', k)) continue;
    const relates = txt(cfg, 'sulRelates', k), recorded = txt(cfg, 'sulRecorded', k);
    sulItems.push({ key:k, i, supplier, date: txt(cfg, 'sulDate', k), amount, desc: txt(cfg, 'sulDesc', k), relates, recorded,
      required: relates === 'Y' && recorded === 'N' ? r2(amount || 0) : 0 });
  }
  const sul = { items: sulItems, examined: r2(sulItems.reduce((s, x) => s + (x.amount || 0), 0)),
    unrecorded: sulItems.filter(x => x.required > 0), unrecordedValue: r2(sulItems.reduce((s, x) => s + x.required, 0)),
    postYE: live.filter(r => r.__afterYE) };

  /* ---- U3.5 cut-off and duplicates ----------------------------------- */
  const dups = live.filter(r => r.__dup);
  const rounds = live.filter(r => r.__isRound);
  const cutoff = { afterYE: sul.postYE, dups, rounds, roundNonInvoice: rounds.filter(r => r.__nonInvoiceRef), wsRefs: live.filter(r => r.__wsRef) };

  const longOut = live.filter(r => r.__daysOutstanding != null && r.__daysOutstanding > (Number(cfg.longOutstanding) || 365) && (r.amount || 0) > 0.005);

  return { buckets: B, bucketRows, clientTotal, clientBucketsEntered, agingDiff: clientTotal != null ? r2(total - clientTotal) : null,
    currencies, suppliers, lead, circ, subpay, sul, cutoff, longOut, pm, trivial,
    debitRecs: live.filter(r => (r.amount || 0) < -0.005), nilRecs: live.filter(r => r.amount != null && Math.abs(r.amount) < 0.005) };
}

/* ============================================================== TESTS */
const tests = [
  { id:'EX-AP-01', label:'Debit balance in the payables listing', basis:'U3.1',
    fn:(r) => (r.amount || 0) < -0.005 && { actual:r.amount, difference:r.amount, cell:r['__cell_amount'], detail:'Debit balance — advance, unapplied credit note or duplicate payment; consider reclassification to receivables/prepayments' } },
  { id:'EX-AP-02', label:'Invoice dated after the year end', basis:'U3.5',
    fn:(r) => r.__afterYE && { actual:Core.fmtDate(r.invoice_date), difference:r.amount, cell:r['__cell_invoice_date'], detail:'Cut-off: invoice dated after the reporting date is included in the year-end balance' } },
  { id:'EX-AP-03', label:'Long-outstanding payable', basis:'U3.1',
    fn:(r, cfg) => r.__daysOutstanding != null && r.__daysOutstanding > (Number(cfg.longOutstanding) || 365) && (r.amount || 0) > 0.005 &&
      { actual:r.__daysOutstanding, difference:r.amount, cell:r['__cell_invoice_date'], detail:`${r.__daysOutstanding} days since invoice date — consider whether the liability still exists or has been settled or disputed` } },
  { id:'EX-AP-04', label:'Supplier not stated', basis:'U3.1',
    fn:(r) => !r.supplier_name && { difference:r.amount, cell:r['__cell_supplier_name'], detail:'No supplier name — cannot be circularised or agreed to a statement' } },
  { id:'EX-AP-05', label:'Duplicate supplier invoice', basis:'U3.5',
    fn:(r) => r.__dup && { difference:r.amount, cell:r['__cell_invoice_no'], detail:`Same supplier, invoice number and amount — ${r.__dup.detail}` } },
  { id:'EX-AP-06', label:'Round-sum item with a non-invoice reference', basis:'U3.5',
    fn:(r) => r.__isRound && r.__nonInvoiceRef && { actual:r.amount, difference:r.amount, cell:r['__cell_invoice_no'], detail:`Reference "${r.invoice_no}" does not follow the supplier-invoice pattern — possible accrual or manual journal booked as a trade payable` } },
  { id:'EX-AP-07', label:'Reference carries stray whitespace (near-duplicate risk)', basis:'U3.0a', severity:'informational',
    fn:(r) => r.__wsRef && { actual:r.invoice_no, cell:r['__cell_invoice_no'], detail:'Reference differs from another only by whitespace or case — check for a duplicate posting' } },
  { id:'EX-AP-08', label:'Nil-value open item', basis:'U3.1', severity:'informational',
    fn:(r) => r.amount != null && Math.abs(r.amount) < 0.005 && { detail:'Open item with no balance — should be cleared from the ledger', cell:r['__cell_amount'] } },
  { id:'EX-AP-09', label:'Round-sum payable', basis:'U3.5', severity:'informational',
    fn:(r) => r.__isRound && !r.__nonInvoiceRef && { actual:r.amount, cell:r['__cell_amount'], detail:'Round-sum invoice — agree to the supplier invoice' } },
  { id:'EX-AP-10', label:'Related-party supplier balance', basis:'U3.2', severity:'informational',
    fn:(r) => r.__related && { difference:r.amount, detail:'Related-party balance — confirm directly and consider FRS 24 disclosure' } },
  { id:'EX-AP-11', scope:'population', label:'Supplier statement does not agree to the listing', basis:'U3.2',
    fn:(recs, cfg, eng, d) => d.circ.unreconciled.map(x => ({ key:x.supplier, expected:x.amount, actual:x.stmt, difference:x.diff, detail:'Balance per supplier statement or confirmation differs from the listing and has not been reconciled' })) },
  { id:'EX-AP-12', scope:'population', label:'Unrecorded liability identified', basis:'U3.4',
    fn:(recs, cfg, eng, d) => d.sul.unrecorded.map(x => ({ key:`${x.supplier || 'Item ' + x.i}`, difference:x.required, actual:x.required, detail:`${x.desc || 'Post year-end item'} relates to the year under audit but was not recorded as a payable or accrual` })) },
  { id:'EX-AP-13', scope:'population', label:'Rebuilt ageing does not agree to the client\'s ageing', basis:'U3.1',
    fn:(recs, cfg, eng, d) => d.agingDiff != null && Math.abs(d.agingDiff) > (Number(cfg.castTol) || 0.01) &&
      { key:'Ageing total', expected:d.lead.total, actual:d.clientTotal, difference:d.agingDiff, detail:'Ageing rebuilt from the open items does not agree to the ageing report supplied' } },
  { id:'EX-TIE-01', scope:'population', label:'Payables listing does not agree to the trial balance', basis:'U3',
    fn:(recs, cfg, eng, d) => d.lead.tbDiff != null && Math.abs(d.lead.tbDiff) > (Number(cfg.castTol) || 0.01) &&
      { key:'Trade payables', expected:d.lead.tb, actual:d.lead.total, difference:d.lead.tbDiff, detail:'Listing total against the trade payables control account in the trial balance' } }
];

/* ============================================================== PAGES */
const yn = ['Y', 'N'];
const invRow = r => ({ __rec:r, supplier:r.supplier_name, code:r.supplier_code, invoice:r.invoice_no, invDate:r.invoice_date, due:r.__due, ccy:r.currency, amount:r.amount });
const INV_COLS = [
  { key:'supplier', label:'Supplier' }, { key:'invoice', label:'Invoice' }, { key:'invDate', label:'Invoice date', type:'date' },
  { key:'due', label:'Due', type:'date' }, { key:'ccy', label:'Ccy' }, { key:'amount', label:'Amount', type:'num', sum:true }
];

const pages = [
  { id:'source',  ref:'U3.0',  title:'Source data',     kind:'source' },
  { id:'cleaned', ref:'U3.0a', title:'Cleaned listing', kind:'cleaned' },
  { id:'mapping', ref:'U3.0b', title:'Column mapping',  kind:'mapping' },

  { id:'lead', ref:'U3', title:'Lead schedule',
    objective:'To agree trade payables per the open-item listing to the trial balance and the prior year audited figure, and to assess the balance against purchases for the year.',
    procedures:['Cast the open-item listing and analysed it by currency.',
                'Agreed the listing total to the trade payables control account in the trial balance.',
                'Compared the balance to the prior year and computed payable days from purchases for the year.'],
    render(st, ctx) {
      const d = ctx.d, Lz = d.lead, m0 = ctx.money0, money = ctx.money, pct = ctx.pct;
      return [
        { type:'controls', items:[
          { key:'tbBalance', label:'Trade payables per trial balance', kind:'number' },
          { key:'pyBalance', label:'Trade payables per prior year audited financial statements', kind:'number' },
          { key:'purchases', label:'Purchases / cost of sales for the year', kind:'number', help:'Used for payable days.' },
          { key:'castTol', label:'Tolerance', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Listing total', value: m0(Lz.total) }, { label:'Open items', value: `${Lz.count} · ${Lz.supplierCount} suppliers` },
          { label:'Per trial balance', value: Lz.tb == null ? '— enter —' : m0(Lz.tb) },
          { label:'Listing − TB', value: Lz.tbDiff == null ? '' : money(Lz.tbDiff), cls: Lz.tbDiff == null ? '' : Math.abs(Lz.tbDiff) > 0.01 ? 'bad' : 'ok' },
          { label:'Prior year', value: Lz.py == null ? '— enter —' : m0(Lz.py) },
          { label:'Movement vs PY', value: Lz.variance == null ? '' : `${money(Lz.variance)} (${pct(Lz.variancePct)})`, cls: Lz.variance != null && Math.abs(Lz.variance) > ctx.pm ? 'warn' : '' },
          { label:'Payable days', value: Lz.payableDays == null ? '— enter purchases —' : `${Lz.payableDays.toFixed(0)} days` },
          { label:'Debit balances', value: `${Lz.debitCount} · ${money(Lz.debits)}`, cls: Lz.debitCount ? 'warn' : 'ok' },
          { label:'Dated after year end', value: `${Lz.afterYE} · ${m0(Lz.afterYEValue)}`, cls: Lz.afterYE ? 'bad' : 'ok' } ] },
        { type:'table', title:'Listing by currency', columns:[
          { key:'currency', label:'Currency' }, { key:'count', label:'Items', type:'int' },
          { key:'amount', label:'Amount (functional currency)', type:'num', sum:true },
          { key:'rate', label:'Closing rate used by client', input:'number' },
          { key:'comment', label:'Auditor comment', input:'text', wide:true } ],
          rows: d.currencies.map(c => ({ __key: Core.keyify(c.currency) || 'none', ...c })),
          footnote:'Where the listing is multi-currency, agree the closing rate applied to the year-end rate and recompute a sample of translated balances.' },
        { type:'note', tone: Lz.tbDiff != null && Math.abs(Lz.tbDiff) > 0.01 ? 'bad' : 'info',
          html: Lz.tb == null ? 'Enter the trial balance figure to complete the tie (EX-TIE-01 fires on a difference).' : Math.abs(Lz.tbDiff) > 0.01 ? `<b>The listing does not agree to the trial balance</b> by ${money(Lz.tbDiff)}. Obtain the reconciliation from the client.` : 'The listing agrees to the trial balance.' }
      ];
    },
    flag(st, d) { return d.lead.tbDiff != null && Math.abs(d.lead.tbDiff) > 0.01; } },

  { id:'aging', ref:'U3.1', title:'Ageing rebuilt by supplier',
    objective:'To rebuild the ageing of trade payables from invoice dates and credit terms, compare it to the ageing supplied by the client, and identify debit balances, nil items and long-outstanding balances.',
    procedures:['Recomputed the due date of every open item from the invoice date and credit terms (or the due date stated) and aged it at the reporting date.',
                'Summarised the ageing by supplier and by bucket and compared the total to the ageing report supplied.',
                'Listed debit balances, nil-value items and items outstanding beyond the threshold set.'],
    render(st, ctx) {
      const d = ctx.d, B = d.buckets, m0 = ctx.money0, money = ctx.money;
      const supCols = [{ key:'supplier', label:'Supplier' }, { key:'code', label:'Code' }, { key:'count', label:'Items', type:'int' },
        ...B.map(b => ({ key:b.key, label:b.label, type:'num', sum:true })),
        { key:'amount', label:'Total', type:'num', sum:true, emphasis:true }, { key:'oldest', label:'Oldest item (days)', type:'int' }];
      return [
        { type:'controls', items:[
          { key:'ageBasis', label:'Age balances by', kind:'select', options:[['due', 'Days past due (due date, else invoice date + terms)'], ['invoice', 'Days since invoice date']] },
          { key:'defaultTerms', label:'Default credit terms where not stated (days)', kind:'number' },
          { key:'bucketEdges', label:'Bucket edges (days, comma-separated)', kind:'text' },
          { key:'longOutstanding', label:'Long-outstanding threshold (days since invoice)', kind:'number' },
          { key:'clientAgingTotal', label:'Total per client\'s ageing report', kind:'number', help:'Or enter the client\'s figure per bucket in the table below.' } ] },
        { type:'stats', items:[
          { label:'Rebuilt ageing total', value: m0(d.lead.total) },
          { label:'Per client ageing', value: d.clientTotal == null ? '— enter —' : m0(d.clientTotal) },
          { label:'Difference', value: d.agingDiff == null ? '' : money(d.agingDiff), cls: d.agingDiff == null ? '' : Math.abs(d.agingDiff) > 0.01 ? 'bad' : 'ok' },
          { label:'Long outstanding', value: `${d.longOut.length} · ${m0(d.longOut.reduce((s, r) => s + r.amount, 0))}`, cls: d.longOut.length ? 'warn' : 'ok' },
          { label:'Debit balances', value: d.debitRecs.length, cls: d.debitRecs.length ? 'warn' : 'ok' }, { label:'Nil items', value: d.nilRecs.length } ] },
        { type:'table', title:'Ageing by bucket — rebuilt vs client', columns:[
          { key:'label', label:'Bucket' }, { key:'count', label:'Items', type:'int' },
          { key:'amount', label:'Rebuilt', type:'num', sum:true }, { key:'share', label:'Share', type:'pct' },
          { key:'clientBucket', label:'Per client ageing', input:'number' },
          { key:'diff', label:'Rebuilt − client', type:'num', flag: v => v != null && Math.abs(v) > 0.01 } ],
          rows: d.bucketRows.map(b => ({ __key:b.key, ...b, share: b.share / 100 })) },
        { type:'table', title:'Ageing by supplier', columns: supCols, rows: d.suppliers.map(s => ({ ...s, __cls: s.amount < 0 ? 'flag' : '' })), maxHeight:'60vh' },
        { type:'table', title:'Long-outstanding items', columns:[...INV_COLS, { key:'daysOut', label:'Days since invoice', type:'int' },
          { key:'explanation', label:'Explanation obtained', input:'text', wide:true }, { key:'valid', label:'Liability still valid (Y/N)', input:'select', options:yn }],
          rows: d.longOut.map(r => ({ ...invRow(r), daysOut:r.__daysOutstanding })), emptyText:'No items outstanding beyond the threshold.' },
        { type:'table', title:'Debit balances', columns:[...INV_COLS, { key:'nature', label:'Nature (advance / credit note / error)', input:'text', wide:true },
          { key:'reclass', label:'Reclassify (Y/N)', input:'select', options:yn }],
          rows: d.debitRecs.map(invRow), emptyText:'No debit balances.' },
        { type:'table', title:'Nil-value items', columns:[...INV_COLS, { key:'comment', label:'Comment', input:'text', wide:true }],
          rows: d.nilRecs.map(invRow), emptyText:'No nil-value items.' }
      ];
    },
    flag(st, d) { return (d.agingDiff != null && Math.abs(d.agingDiff) > 0.01) || d.debitRecs.length > 0 || d.longOut.length > 0; } },

  { id:'circ', ref:'U3.2', title:'Supplier statements and circularisation',
    objective:'To obtain evidence of the existence and completeness of trade payables by agreeing selected supplier balances to supplier statements or direct confirmations and reconciling differences.',
    procedures:['Selected every supplier with a balance at or above the testing threshold and every related-party supplier as a key item, plus a random sample from the remaining suppliers using a recorded seed.',
                'Agreed each selected balance to the supplier statement or confirmation reply and reconciled differences to invoices in transit, unapplied payments or disputes.',
                'Where no statement or reply was available, performed alternative procedures (subsequent payments, U3.3).'],
    render(st, ctx) {
      const C = ctx.d.circ, m0 = ctx.money0, pct = ctx.pct;
      return [
        { type:'controls', items:[
          { key:'circThreshold', label:'Testing threshold — every supplier balance at or above is selected', kind:'number', help:`Blank = performance materiality (${m0(ctx.pm)}). Currently ${m0(C.threshold)}.` },
          { key:'circSampleN', label:'Random sample from the remaining suppliers', kind:'number', help:`${C.residual.length} suppliers below the threshold` },
          { key:'circSeed', label:'Random seed', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Suppliers with credit balances', value: `${C.key.length + C.residual.length} · ${m0(C.posTotal)}` },
          { label:'Key items', value: C.key.length }, { label:'Random sample', value: C.sample.length },
          { label:'Coverage of credit balances', value: pct(C.coverage), cls: C.coverage >= 70 ? 'ok' : 'warn' },
          { label:'Reconciled', value: `${C.reconciled} of ${C.rows.length}`, cls: C.reconciled === C.rows.length && C.rows.length ? 'ok' : 'warn' },
          { label:'Unreconciled differences', value: C.unreconciled.length, cls: C.unreconciled.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Selected suppliers', columns:[
          { key:'supplier', label:'Supplier' }, { key:'code', label:'Code' }, { key:'basis', label:'Basis', type:'chip', chipClass: v => v === 'Key item' ? 'info' : v === 'Related party' ? 'warn' : 'grey' },
          { key:'count', label:'Items', type:'int' }, { key:'amount', label:'Per listing', type:'num', sum:true },
          { key:'circSent', label:'Request sent (Y/N)', input:'select', options:yn },
          { key:'circRecd', label:'Statement / reply obtained (Y/N)', input:'select', options:yn },
          { key:'stmtBal', label:'Per supplier statement / confirmation', input:'number' },
          { key:'diff', label:'Statement − listing', type:'num', flag: v => v != null && Math.abs(v) > 0.01 },
          { key:'recItems', label:'Reconciling items (invoices in transit, unapplied payments, disputes)', input:'text', wide:true },
          { key:'reconciled', label:'Reconciled (Y/N)', input:'select', options:yn },
          { key:'altProc', label:'Alternative procedure where no reply', input:'text', wide:true } ],
          rows: C.rows.map(x => ({ __key:x.key, ...x, __cls: x.diff != null && Math.abs(x.diff) > 0.01 && x.reconciled !== 'Y' ? 'flag' : '' })),
          emptyText:'No suppliers selected — lower the threshold or increase the sample.',
          footnote:`Seed ${C.seed}. A difference not marked reconciled is raised as EX-AP-11.` }
      ];
    },
    flag(st, d) { return d.circ.unreconciled.length > 0; } },

  { id:'subpay', ref:'U3.3', title:'Subsequent payments',
    objective:'To corroborate the existence and valuation of selected payables by tracing them to payments made after the year end.',
    procedures:['For every open item of the suppliers selected on U3.2, traced settlement to the post year-end cash book or bank statement and recorded the date, amount and reference.',
                'Computed the proportion of the selected balance cleared after the year end and listed items still unpaid for enquiry.'],
    render(st, ctx) {
      const S = ctx.d.subpay, m0 = ctx.money0, pct = ctx.pct;
      return [
        { type:'stats', items:[
          { label:'Invoices of selected suppliers', value: `${S.recs.length} · ${m0(S.total)}` },
          { label:'Traced to payment', value: `${S.traced} of ${S.recs.length}` },
          { label:'Cleared after year end', value: m0(S.paid) },
          { label:'Coverage of selected balance', value: pct(S.coverage), cls: S.coverage >= 80 ? 'ok' : 'warn' },
          { label:'Unpaid or part paid', value: S.unpaid.length, cls: S.unpaid.length ? 'warn' : 'ok' } ] },
        { type:'table', title:'Open items of selected suppliers', columns:[
          ...INV_COLS,
          { key:'payDate', label:'Payment date', input:'text' }, { key:'payAmount', label:'Amount paid', input:'number' }, { key:'payRef', label:'Payment reference', input:'text' },
          { key:'unpaid', label:'Unpaid at date of test', type:'num', sum:true },
          { key:'status', label:'Status', type:'chip', chipClass: v => v === 'Paid in full' ? 'ok' : v === 'Not yet traced' ? 'grey' : 'warn' },
          { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: S.recs.map(r => ({ ...invRow(r), unpaid: r.__unpaid, status: r.__payStatus })), maxHeight:'70vh',
          emptyText:'Select suppliers on U3.2 first.' },
        { type:'note', html:'Items not paid by the date of testing are not necessarily misstated; obtain the reason (dispute, credit hold, long terms) and consider whether the liability remains valid.' }
      ];
    } },

  { id:'sul', ref:'U3.4', title:'Search for unrecorded liabilities',
    objective:'To identify liabilities existing at the reporting date that were not recorded as payables or accruals, by examining invoices and payments after the year end.',
    procedures:['Listed invoices in the payables listing dated after the year end (also on U3.5).',
                'Examined post year-end payments and invoices received above the threshold and recorded, for each, whether it relates to the year under audit and whether it was recorded as a payable or accrual.',
                'Summarised unrecorded liabilities for the summary of unadjusted differences.'],
    render(st, ctx) {
      const S = ctx.d.sul, m0 = ctx.money0;
      const rows = [];
      const n = Math.max(0, Math.min(60, Math.round(Number(ctx.cfg.sulRows) || 0)));
      for (let i = 1; i <= n; i++) { const it = S.items.find(x => x.i === i); rows.push({ __key:'sul' + i, line:i, required: it ? it.required || null : null, __cls: it?.required ? 'flag' : '' }); }
      return [
        { type:'controls', items:[{ key:'sulRows', label:'Lines available for post year-end items examined', kind:'number' }] },
        { type:'stats', items:[
          { label:'Post year-end items examined', value: `${S.items.length} · ${m0(S.examined)}` },
          { label:'Unrecorded liabilities', value: `${S.unrecorded.length} · ${m0(S.unrecordedValue)}`, cls: S.unrecorded.length ? 'bad' : 'ok' },
          { label:'Invoices dated after year end in the listing', value: S.postYE.length, cls: S.postYE.length ? 'warn' : 'ok' } ] },
        { type:'table', title:'Post year-end payments and invoices examined', columns:[
          { key:'line', label:'#', type:'int' },
          { key:'sulSupplier', label:'Supplier / payee', input:'text', wide:true },
          { key:'sulDate', label:'Document / payment date', input:'text' },
          { key:'sulDesc', label:'Description of goods or services', input:'text', wide:true },
          { key:'sulAmount', label:'Amount', input:'number' },
          { key:'sulRelates', label:'Relates to year under audit (Y/N)', input:'select', options:yn },
          { key:'sulRecorded', label:'Recorded as payable or accrual (Y/N)', input:'select', options:yn },
          { key:'required', label:'Unrecorded liability', type:'num', sum:true },
          { key:'sulComment', label:'Comment', input:'text', wide:true } ], rows,
          footnote:'An item that relates to the year and is not recorded is carried to the exception register as EX-AP-12.' },
        { type:'table', title:'Invoices in the listing dated after the year end', columns:[...INV_COLS, { key:'comment', label:'Comment', input:'text', wide:true }],
          rows: S.postYE.map(invRow), emptyText:'None.' }
      ];
    },
    flag(st, d) { return d.sul.unrecorded.length > 0; } },

  { id:'cutoff', ref:'U3.5', title:'Cut-off, duplicates and round sums',
    objective:'To identify items in the payables listing that indicate cut-off error, duplicate posting or manual accruals booked as trade payables.',
    procedures:['Listed invoices dated after the reporting date.',
                'Identified duplicate postings on supplier, invoice number and amount, and references differing only by whitespace.',
                'Listed round-sum balances and those whose reference does not follow the supplier-invoice pattern.'],
    render(st, ctx) {
      const C = ctx.d.cutoff, m0 = ctx.money0;
      return [
        { type:'controls', items:[
          { key:'roundSum', label:'Round-sum flag: multiple of', kind:'number' },
          { key:'invoicePattern', label:'Supplier invoice reference pattern (regular expression)', kind:'text' } ] },
        { type:'stats', items:[
          { label:'Dated after year end', value: `${C.afterYE.length} · ${m0(C.afterYE.reduce((s, r) => s + r.amount, 0))}`, cls: C.afterYE.length ? 'bad' : 'ok' },
          { label:'Duplicates', value: `${C.dups.length} · ${m0(C.dups.reduce((s, r) => s + r.amount, 0))}`, cls: C.dups.length ? 'bad' : 'ok' },
          { label:'Round sums', value: C.rounds.length }, { label:'Round sums with non-invoice reference', value: C.roundNonInvoice.length, cls: C.roundNonInvoice.length ? 'warn' : 'ok' },
          { label:'References with stray whitespace', value: C.wsRefs.length } ] },
        { type:'table', title:'Invoices dated after the year end', columns:[...INV_COLS, { key:'daysAfter', label:'Days after YE', type:'int' },
          { key:'goodsRecd', label:'Goods / services received before YE (Y/N)', input:'select', options:yn }, { key:'comment', label:'Comment', input:'text', wide:true }],
          rows: C.afterYE.map(r => ({ ...invRow(r), daysAfter: -r.__daysOutstanding })), emptyText:'None.' },
        { type:'table', title:'Duplicate postings', columns:[...INV_COLS, { key:'dupOf', label:'Duplicate of' },
          { key:'confirmed', label:'Confirmed duplicate (Y/N)', input:'select', options:yn }, { key:'comment', label:'Comment', input:'text', wide:true }],
          rows: C.dups.map(r => ({ ...invRow(r), dupOf: r.__dup.detail })), emptyText:'None.' },
        { type:'table', title:'Round-sum items', columns:[...INV_COLS, { key:'ref', label:'Reference pattern', type:'chip', chipClass: v => v === 'Non-invoice' ? 'bad' : 'grey' },
          { key:'doc', label:'Supporting document seen', input:'text', wide:true }, { key:'agreed', label:'Agreed (Y/N)', input:'select', options:yn }],
          rows: C.rounds.map(r => ({ ...invRow(r), ref: r.__nonInvoiceRef ? 'Non-invoice' : 'Invoice' })), emptyText:'None.' }
      ];
    },
    flag(st, d) { return d.cutoff.afterYE.length > 0 || d.cutoff.dups.length > 0 || d.cutoff.roundNonInvoice.length > 0; } },

  { id:'conclusion', ref:'U3.9', title:'Exceptions & conclusion', kind:'conclusion' }
];

function suggestConclusion(st, ctx) {
  const d = ctx.d, Lz = d.lead, C = d.circ;
  const ex = (st.exceptions || []).filter(e => e.disposition === 'open');
  return [
    `Trade payables per the listing total ${ctx.money(Lz.total)} across ${Lz.count} open items and ${Lz.supplierCount} suppliers${Lz.tbDiff == null ? '' : Math.abs(Lz.tbDiff) <= 0.01 ? ', agreeing to the trial balance' : `, differing from the trial balance by ${ctx.money(Lz.tbDiff)}`}.`,
    `The ageing was rebuilt from invoice dates and terms${d.agingDiff == null ? '' : Math.abs(d.agingDiff) <= 0.01 ? ' and agrees to the ageing supplied' : ` and differs from the ageing supplied by ${ctx.money(d.agingDiff)}`}.`,
    `${C.selected.length} suppliers (${ctx.pct(C.coverage)} of credit balances) were selected for statement reconciliation or confirmation; ${C.reconciled} reconciled.`,
    d.sul.unrecorded.length ? `${d.sul.unrecorded.length} unrecorded liabilit${d.sul.unrecorded.length === 1 ? 'y' : 'ies'} totalling ${ctx.money(d.sul.unrecordedValue)} were identified.` : 'The search for unrecorded liabilities identified no unrecorded items.',
    ex.length ? `${ex.length} exception(s) remain open in the register.` : 'No exceptions remain open.',
    'Subject to the above, trade payables are complete and fairly stated at the reporting date.'
  ].join(' ');
}

return {
  code:'AP', name:'Trade Payables', group:'Liabilities & equity', accepts:'.xlsx,.xlsm,.csv',
  blurb:'The trade payables audit file: lead, ageing rebuilt by supplier, supplier statements and circularisation, subsequent payments, search for unrecorded liabilities, cut-off and duplicates — from one uploaded open-item listing.',
  objective:'To obtain sufficient appropriate audit evidence that trade payables are complete, exist as obligations of the entity at the reporting date, are recorded at the correct amounts and in the correct period, and are appropriately presented.',
  fields, tests, compute, pages, defaultConfig, STANDARD_COLUMNS,
  procedures: pages.flatMap(p => p.procedures || []),
  columns: STANDARD_COLUMNS, suggestConclusion
};
})();

Modules.register(APModule);
