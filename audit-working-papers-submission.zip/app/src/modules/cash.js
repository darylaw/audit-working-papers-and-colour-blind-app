/* ==========================================================================
   cash.js -- Cash and bank as an auditor actually works it.

   One uploaded bank statement (transaction listing) feeds:
     M    Lead schedule                M3  Statement scrutiny
     M1   Bank reconciliation review   M4  Cut-off
     M2   Bank confirmation control    M5  Cash flow analytics
   ========================================================================== */

const CashModule = (() => {
const r2 = n => n == null || isNaN(n) ? null : Math.round(n * 100) / 100;
const days = (a, b) => (a && b) ? Math.round((a - b) / 86400000) : null;
const num = v => (v === '' || v == null || isNaN(Number(v))) ? null : Number(v);
const inp = (cfg, key, k) => num(cfg[key + ':' + k]);
const txt = (cfg, key, k) => { const v = cfg[key + ':' + k]; return v == null ? '' : String(v); };
const isoMonth = d => d ? `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}` : '(undated)';
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const monthLabel = k => k === '(undated)' ? k : `${MONTHS[Number(k.slice(5, 7)) - 1]} ${k.slice(0, 4)}`;

/* Seeded PRNG so a random sample is reproducible from its recorded seed. */
function mulberry32(seed) {
  let a = (seed >>> 0) || 1;
  return () => {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function sampleN(items, n, seed) {
  const rnd = mulberry32(seed);
  const pool = items.slice();
  const out = [];
  while (out.length < n && pool.length) out.push(pool.splice(Math.floor(rnd() * pool.length), 1)[0]);
  return out;
}

const OPENING_RE = /brought\s+forward|opening\s+balance|balance\s+b\/?f\b|\bb\/f\b|\bb\/d\b|opening\b/i;
const CLOSING_RE = /carried\s+forward|closing\s+balance|balance\s+c\/?f\b|\bc\/f\b|\bc\/d\b|closing\b/i;
const RP_RE = /related\s*part|director|shareholder|inter-?compan|holding|associate|subsidiar|\bR\/?P\b/i;
const UNID_RE = /unidentified|unknown|suspense|unapplied|unallocated|sundry|miscellaneous|cash\s+withdrawal|petty\s+cash/i;
const RECON_TYPES = ['Unpresented cheque', 'Deposit in transit', 'Bank charge not in ledger', 'Interest not in ledger', 'Ledger error', 'Bank error', 'Other'];

/* ---------------------------------------------------------------- fields */
const fields = [
  { key:'stmt_date', label:'Transaction date', type:'date', required:true, role:'key',
    synonyms:['Date','Value Date','Transaction Date','Posting Date','Txn Date','Tran Date','Booking Date','Entry Date','Statement Date','日期','交易日期'] },
  { key:'narrative', label:'Narrative', type:'text', required:true, dupKey:true,
    synonyms:['Description','Narrative','Details','Transaction Details','Particulars','Reference','Memo','Remarks','Transaction Description','Payee / Payer','Counterparty','摘要','备注'] },
  { key:'debit', label:'Withdrawal (debit)', type:'number', dupKey:true,
    synonyms:['Withdrawal','Debit','Paid Out','Dr','Payments','Withdrawals','Debits','Money Out','Out','Debit Amount','Payment','支出','借方'] },
  { key:'credit', label:'Deposit (credit)', type:'number', dupKey:true,
    synonyms:['Deposit','Credit','Paid In','Cr','Receipts','Deposits','Credits','Money In','In','Credit Amount','Receipt','收入','贷方'] },
  { key:'amount', label:'Signed amount (single column)', type:'number',
    synonyms:['Amount','Transaction Amount','Net Amount','Txn Amount','金额'] },
  { key:'balance', label:'Running balance', type:'number', required:true,
    synonyms:['Balance','Running Balance','Ledger Balance','Balance (SGD)','Balance (USD)','Closing Balance','Available Balance','Book Balance','Bal','余额'] },
  { key:'reference', label:'Reference / cheque number', type:'text',
    synonyms:['Cheque No','Cheque Number','Chq No','Ref No','Reference No','Transaction Ref','Txn Ref','Doc No','凭证号'] }
];

const STANDARD_COLUMNS = [
  { key:'stmt_date', label:'Date', type:'date', edit:true }, { key:'narrative', label:'Narrative' },
  { key:'reference', label:'Reference' },
  { key:'__out', label:'Withdrawal', type:'num' }, { key:'__in', label:'Deposit', type:'num' },
  { key:'__net', label:'Net', type:'num' }, { key:'balance', label:'Balance per statement', type:'num', edit:true },
  { key:'__expectedBal', label:'Balance recomputed', type:'num' }, { key:'__rollDiff', label:'Roll difference', type:'num', emphasis:true },
  { key:'__rowKind', label:'Row type' }
];

const defaultConfig = () => ({
  castTol: 0.01,
  extraAccounts: 2,               // accounts other than the uploaded statement, entered on M
  ledgerBalance: '',              // cash book balance per client at year end (M1)
  recItemRows: 8,                 // reconciling-item lines available on M1
  staleDays: 180,                 // reconciling item outstanding beyond this is flagged
  scrThreshold: '',               // blank = performance materiality
  roundSum: 10000,
  edgeDays: 15,                   // first / last N days of the year
  scrSampleN: 5, scrSeed: 20250228,
  rpPattern: '',                  // extra narrative pattern (regex) the auditor wants caught
  cutoffDays: 7,
  topN: 10,
  sulRows: 0
});

/* =========================================================== accounts */
function accounts(cfg, closingPerStatement) {
  const out = [{ key:'stmt', label: txt(cfg, 'accLabel', 'stmt') || 'Account per uploaded statement', fromUpload:true,
    stmtBal: closingPerStatement }];
  const n = Math.max(0, Math.min(12, Math.round(Number(cfg.extraAccounts) || 0)));
  for (let i = 1; i <= n; i++) out.push({ key:'acc' + i, label: txt(cfg, 'accLabel', 'acc' + i) || `Additional account ${i}`, fromUpload:false,
    stmtBal: inp(cfg, 'stmtBal', 'acc' + i) });
  return out;
}

/* ============================================================ COMPUTE */
function compute(recs, cfg, eng) {
  const ye = eng.yearEndDate, fys = eng.fyStartDate;
  const pm = eng.materiality?.pm || 0, trivial = eng.materiality?.trivial || 0;
  const tol = Number(cfg.castTol) || 0.01;
  const extraRe = (() => { try { return cfg.rpPattern ? new RegExp(cfg.rpPattern, 'i') : null; } catch (e) { return null; } })();

  /* ---- classify rows: opening / closing / transaction ---------------- */
  const live = recs.filter(r => !r.__excluded);
  let opening = null, closing = null;
  for (const r of live) {
    const noMove = Math.abs(r.debit || 0) < 0.005 && Math.abs(r.credit || 0) < 0.005 && Math.abs(r.amount || 0) < 0.005;
    const n = r.narrative || '';
    r.__rowKind = 'Transaction';
    if (noMove && OPENING_RE.test(n) && !opening) { r.__rowKind = 'Opening balance'; opening = r; }
    else if (noMove && CLOSING_RE.test(n)) { r.__rowKind = 'Closing balance'; closing = r; }
  }
  const txs = live.filter(r => r.__rowKind === 'Transaction');
  /* single signed column: negative = out */
  for (const r of recs) {
    r.__displayKey = (r.stmt_date ? Core.fmtDate(r.stmt_date) : 'undated') + ' · ' + (r.narrative || 'row ' + r.__srcRow);
    if (r.debit != null || r.credit != null) { r.__out = Math.abs(r.debit || 0); r.__in = Math.abs(r.credit || 0); }
    else if (r.amount != null) { r.__out = r.amount < 0 ? -r.amount : 0; r.__in = r.amount > 0 ? r.amount : 0; }
    else { r.__out = 0; r.__in = 0; }
    r.__net = r2(r.__in - r.__out);
    if (r.__rowKind === undefined) r.__rowKind = r.__excluded ? 'Excluded' : 'Transaction';
  }

  /* ---- running balance roll ----------------------------------------- */
  const openingBal = opening ? (opening.balance ?? null)
    : (txs.length && txs[0].balance != null ? r2(txs[0].balance - txs[0].__net) : null);
  const closingPerStatement = closing ? (closing.balance ?? null)
    : (txs.length && txs[txs.length - 1].balance != null ? txs[txs.length - 1].balance : null);
  let totalIn = 0, totalOut = 0, prev = openingBal, rollBreaks = 0;
  for (const r of txs) {
    totalIn += r.__in; totalOut += r.__out;
    r.__expectedBal = prev != null ? r2(prev + r.__net) : null;
    r.__rollDiff = (r.__expectedBal != null && r.balance != null) ? r2(r.balance - r.__expectedBal) : null;
    if (r.__rollDiff != null && Math.abs(r.__rollDiff) > tol) rollBreaks++;
    prev = r.balance != null ? r.balance : r.__expectedBal;
  }
  if (opening) { opening.__expectedBal = opening.balance; opening.__rollDiff = 0; }
  if (closing) { closing.__expectedBal = prev; closing.__rollDiff = (prev != null && closing.balance != null) ? r2(closing.balance - prev) : null; }
  const computedClosing = openingBal != null ? r2(openingBal + totalIn - totalOut) : null;
  const rollDiff = (computedClosing != null && closingPerStatement != null) ? r2(closingPerStatement - computedClosing) : null;
  const dates = txs.map(r => r.stmt_date).filter(Boolean).sort((a, b) => a - b);
  const statement = { opening: openingBal, closing: closingPerStatement, computedClosing, rollDiff, rollBreaks,
    totalIn: r2(totalIn), totalOut: r2(totalOut), net: r2(totalIn - totalOut), count: txs.length,
    firstDate: dates[0] || null, lastDate: dates[dates.length - 1] || null,
    hasOpeningRow: !!opening, hasClosingRow: !!closing,
    closingMatchesYE: closingPerStatement != null && !!closing?.stmt_date && ye && Math.abs(days(closing.stmt_date, ye)) <= 3 };

  /* ---- M lead: per account ------------------------------------------ */
  const accs = accounts(cfg, closingPerStatement);
  const lead = accs.map(a => {
    const rec = inp(cfg, 'recBal', a.key), tb = inp(cfg, 'tbBal', a.key), py = inp(cfg, 'pyBal', a.key);
    const diffStmtRec = (a.stmtBal != null && rec != null) ? r2(a.stmtBal - rec) : null;
    const diffRecTB = (rec != null && tb != null) ? r2(rec - tb) : null;
    const variance = (tb != null && py != null) ? r2(tb - py) : null;
    return { ...a, rec, tb, py, diffStmtRec, diffRecTB, variance,
      variancePct: (variance != null && py) ? r2(variance / Math.abs(py) * 100) : null,
      material: variance != null && Math.abs(variance) > pm };
  });
  const leadTotals = { stmt: r2(lead.reduce((s, a) => s + (a.stmtBal || 0), 0)), rec: r2(lead.reduce((s, a) => s + (a.rec || 0), 0)),
    tb: r2(lead.reduce((s, a) => s + (a.tb || 0), 0)), py: r2(lead.reduce((s, a) => s + (a.py || 0), 0)) };

  /* ---- M1 bank reconciliation review -------------------------------- */
  const ledger = num(cfg.ledgerBalance);
  const recRows = Math.max(0, Math.min(60, Math.round(Number(cfg.recItemRows) || 0)));
  const stale = Number(cfg.staleDays) || 180;
  const recItems = [];
  for (let i = 1; i <= recRows; i++) {
    const k = 'ri' + i;
    const type = txt(cfg, 'riType', k), amount = inp(cfg, 'riAmount', k);
    const dRaw = txt(cfg, 'riDate', k);
    const date = dRaw ? (Core.parseDateWith(dRaw, 'dmy').date || null) : null;
    if (!type && amount == null && !dRaw && !txt(cfg, 'riRef', k)) continue;
    const age = date && ye ? days(ye, date) : null;
    /* sign towards the ledger: statement + deposits in transit - unpresented cheques = ledger */
    let toLedger = 0;
    if (amount != null) {
      if (type === 'Unpresented cheque') toLedger = -Math.abs(amount);
      else if (type === 'Deposit in transit') toLedger = Math.abs(amount);
      else if (type === 'Bank charge not in ledger') toLedger = -Math.abs(amount);
      else if (type === 'Interest not in ledger') toLedger = Math.abs(amount);
      else toLedger = amount;          // ledger error / bank error / other: signed as entered
    }
    recItems.push({ key:k, i, type, date, ref: txt(cfg, 'riRef', k), amount, toLedger: r2(toLedger), age, stale: age != null && age > stale });
  }
  const unpresented = r2(recItems.filter(x => x.type === 'Unpresented cheque').reduce((s, x) => s + Math.abs(x.amount || 0), 0));
  const inTransit = r2(recItems.filter(x => x.type === 'Deposit in transit').reduce((s, x) => s + Math.abs(x.amount || 0), 0));
  const otherItems = r2(recItems.filter(x => x.type !== 'Unpresented cheque' && x.type !== 'Deposit in transit').reduce((s, x) => s + (x.toLedger || 0), 0));
  const expectedLedger = closingPerStatement != null ? r2(closingPerStatement + inTransit - unpresented + otherItems) : null;
  const recon = { ledger, unpresented, inTransit, otherItems, expectedLedger, items: recItems,
    unexplained: (expectedLedger != null && ledger != null) ? r2(ledger - expectedLedger) : null,
    staleItems: recItems.filter(x => x.stale), staleDays: stale };

  /* ---- M2 confirmation control -------------------------------------- */
  const confirmations = accs.map(a => {
    const conf = inp(cfg, 'confBal', a.key);
    return { ...a, sent: txt(cfg, 'confSent', a.key), received: txt(cfg, 'confRecd', a.key), conf,
      diff: (conf != null && a.stmtBal != null) ? r2(conf - a.stmtBal) : null,
      facilities: txt(cfg, 'confFac', a.key), security: txt(cfg, 'confSec', a.key) };
  });

  /* ---- M3 statement scrutiny ---------------------------------------- */
  const threshold = cfg.scrThreshold !== '' && cfg.scrThreshold != null ? Number(cfg.scrThreshold) : pm;
  const round = Number(cfg.roundSum) || 0;
  const edge = Number(cfg.edgeDays) || 0;
  const flagged = [], residual = [];
  for (const r of txs) {
    const reasons = [];
    const gross = Math.max(r.__in, r.__out);
    const n = r.narrative || '';
    if (threshold > 0 && gross >= threshold) reasons.push('Above threshold');
    if (round > 0 && gross >= round && Math.abs(gross % round) < 0.005) reasons.push('Round sum');
    if (r.stmt_date && [0, 6].includes(r.stmt_date.getUTCDay())) reasons.push('Weekend posting');
    if (RP_RE.test(n)) reasons.push('Related party / director');
    if (UNID_RE.test(n)) reasons.push('Unidentified / sundry');
    if (extraRe && extraRe.test(n)) reasons.push('Auditor pattern');
    if (r.stmt_date && ye && edge > 0) {
      const toYE = days(ye, r.stmt_date);
      if (toYE >= 0 && toYE < edge) reasons.push(`Last ${edge} days`);
      const fromStart = fys ? days(r.stmt_date, fys) : null;
      if (fromStart != null && fromStart >= 0 && fromStart < edge) reasons.push(`First ${edge} days`);
    }
    if (r.stmt_date && ye && fys && (r.stmt_date > ye || r.stmt_date < fys)) reasons.push('Outside financial year');
    if (!n.trim()) reasons.push('No narrative');
    r.__rp = RP_RE.test(n) || UNID_RE.test(n) || (extraRe ? extraRe.test(n) : false);
    r.__aboveThreshold = threshold > 0 && gross >= threshold;
    r.__scrReasons = reasons;
    if (reasons.length) flagged.push(r); else residual.push(r);
  }
  const nS = Math.min(Number(cfg.scrSampleN) || 0, residual.length);
  const sample = sampleN(residual, nS, Number(cfg.scrSeed) || 1);
  for (const r of txs) r.__scrSelected = r.__scrReasons.length ? 'flagged' : (sample.includes(r) ? 'sample' : null);
  const selected = [...flagged, ...sample].sort((a, b) => (a.stmt_date || 0) - (b.stmt_date || 0));
  const gross = r => Math.max(r.__in, r.__out);
  const popValue = r2(txs.reduce((s, r) => s + gross(r), 0));
  const selValue = r2(selected.reduce((s, r) => s + gross(r), 0));
  const vouched = selected.filter(r => r.__wp?.scrutiny?.agreed === 'Y').length;
  const scrutiny = { threshold, round, edge, seed: Number(cfg.scrSeed) || 1, flagged, residual, sample, selected,
    popValue, selValue, coverage: popValue ? r2(selValue / popValue * 100) : 0, vouched,
    byReason: selected.reduce((m, r) => { (r.__scrReasons.length ? r.__scrReasons : ['Random sample']).forEach(x => m[x] = (m[x] || 0) + 1); return m; }, {}) };

  /* ---- M4 cut-off --------------------------------------------------- */
  const cw = Number(cfg.cutoffDays) || 0;
  const cutoff = txs.filter(r => r.stmt_date && ye && Math.abs(days(r.stmt_date, ye)) <= cw).sort((a, b) => a.stmt_date - b.stmt_date);
  for (const r of txs) r.__cutoffSide = null;
  for (const r of cutoff) r.__cutoffSide = r.stmt_date > ye ? 'After year end' : 'Before year end';

  /* ---- M5 analytics ------------------------------------------------- */
  const months = {};
  for (const r of txs) {
    const k = isoMonth(r.stmt_date);
    const m = months[k] || (months[k] = { month:k, label: monthLabel(k), count:0, inflow:0, outflow:0 });
    m.count++; m.inflow += r.__in; m.outflow += r.__out;
  }
  const monthly = Object.values(months).sort((a, b) => a.month.localeCompare(b.month)).map(m => ({ ...m, inflow: r2(m.inflow), outflow: r2(m.outflow), net: r2(m.inflow - m.outflow) }));
  const stems = {};
  for (const r of txs) {
    const stem = counterpartyStem(r.narrative);
    r.__stem = stem;
    const s = stems[stem] || (stems[stem] = { stem, count:0, inflow:0, outflow:0 });
    s.count++; s.inflow += r.__in; s.outflow += r.__out;
  }
  const counterparties = Object.values(stems).map(s => ({ ...s, inflow: r2(s.inflow), outflow: r2(s.outflow), gross: r2(s.inflow + s.outflow),
    share: popValue ? r2((s.inflow + s.outflow) / popValue * 100) : 0 })).sort((a, b) => b.gross - a.gross);
  const topN = Math.max(1, Number(cfg.topN) || 10);

  return { statement, accounts: accs, lead, leadTotals, recon, confirmations, scrutiny, cutoff, cutoffDays: cw,
    monthly, counterparties, topCounterparties: counterparties.slice(0, topN), txCount: txs.length, pm, trivial };
}

function counterpartyStem(narrative) {
  let s = String(narrative || '').trim();
  if (!s) return '(no narrative)';
  s = s.split(/\s+[-–—:]\s+|\s{2,}|\//)[0];
  s = s.replace(/[0-9#*]+/g, ' ').replace(/\b(ref|no|nr|inv|txn|id)\b\.?/gi, ' ').replace(/\s+/g, ' ').trim();
  return s ? s.charAt(0).toUpperCase() + s.slice(1).toLowerCase() : '(no narrative)';
}

/* ============================================================== TESTS */
const tests = [
  { id:'EX-CASH-01', scope:'population', label:'Unexplained difference on the bank reconciliation', basis:'M1',
    fn:(recs, cfg, eng, d) => d.recon.unexplained != null && Math.abs(d.recon.unexplained) > (Number(cfg.castTol) || 0.01) &&
      { key:'Bank reconciliation', expected:d.recon.expectedLedger, actual:d.recon.ledger, difference:d.recon.unexplained,
        detail:`Statement ${d.statement.closing?.toFixed(2)} + deposits in transit ${d.recon.inTransit.toFixed(2)} − unpresented cheques ${d.recon.unpresented.toFixed(2)} ± other ${d.recon.otherItems.toFixed(2)} does not agree to the ledger balance entered` } },
  { id:'EX-CASH-02', scope:'population', label:'Long-outstanding reconciling item', basis:'M1',
    fn:(recs, cfg, eng, d) => d.recon.staleItems.map(x => ({ key:`${x.type || 'Reconciling item'} ${x.ref || ('line ' + x.i)}`, actual:x.age, difference:x.amount,
      detail:`${x.age} days outstanding at the year end (threshold ${d.recon.staleDays}). Consider whether it should be written back or reversed.` })) },
  { id:'EX-CASH-03', label:'Statement item above the testing threshold not yet vouched', basis:'M3', severity:'informational',
    fn:(r) => r.__rowKind === 'Transaction' && r.__aboveThreshold && r.__wp?.scrutiny?.agreed !== 'Y' &&
      { actual: Math.max(r.__in, r.__out), difference: Math.max(r.__in, r.__out), cell: r.__out ? r['__cell_debit'] : r['__cell_credit'],
        detail:'Selected as a key item on M3; supporting document not yet recorded as agreed' } },
  { id:'EX-CASH-04', label:'Related-party, director or unidentified counterparty in the narrative', basis:'M3', severity:'above-trivial',
    fn:(r) => r.__rowKind === 'Transaction' && r.__rp && { actual: r.narrative, difference: Math.max(r.__in, r.__out), cell: r['__cell_narrative'],
      detail: RP_RE.test(r.narrative || '') ? 'Narrative indicates a related party or director. Corroborate business purpose, approval and disclosure (FRS 24).' : 'Beneficiary or payer not identified in the narrative. Obtain the remittance advice and identify the counterparty.' } },
  { id:'EX-CASH-05', scope:'population', label:'Running balance does not roll from opening to closing', basis:'M',
    fn:(recs, cfg, eng, d) => d.statement.rollDiff != null && Math.abs(d.statement.rollDiff) > (Number(cfg.castTol) || 0.01) &&
      { key:'Statement roll', expected:d.statement.computedClosing, actual:d.statement.closing, difference:d.statement.rollDiff,
        detail:`Opening ${d.statement.opening?.toFixed(2)} + deposits ${d.statement.totalIn.toFixed(2)} − withdrawals ${d.statement.totalOut.toFixed(2)} ≠ closing per statement` } },
  { id:'EX-CASH-06', label:'Running balance breaks on this line', basis:'M',
    fn:(r, cfg) => r.__rowKind === 'Transaction' && r.__rollDiff != null && Math.abs(r.__rollDiff) > (Number(cfg.castTol) || 0.01) &&
      { expected:r.__expectedBal, actual:r.balance, difference:r.__rollDiff, cell:r['__cell_balance'], detail:'Balance per statement does not equal the prior balance plus this movement — possible missing or altered line' } },
  { id:'EX-CASH-07', label:'Transaction dated outside the financial year', basis:'M3', severity:'informational',
    fn:(r, cfg, eng) => r.__rowKind === 'Transaction' && r.stmt_date && eng.yearEndDate && eng.fyStartDate && (r.stmt_date > eng.yearEndDate || r.stmt_date < eng.fyStartDate) &&
      { actual: Core.fmtDate(r.stmt_date), difference: Math.max(r.__in, r.__out), cell:r['__cell_stmt_date'], detail:'Date falls outside the period under audit — confirm the statement period and the date format' } },
  { id:'EX-CASH-08', label:'Transaction with no narrative', basis:'M3', severity:'informational',
    fn:(r) => r.__rowKind === 'Transaction' && !(r.narrative || '').trim() && { difference: Math.max(r.__in, r.__out), cell:r['__cell_narrative'] } },
  { id:'EX-CASH-09', scope:'population', label:'Confirmed balance differs from the statement', basis:'M2',
    fn:(recs, cfg, eng, d) => d.confirmations.filter(c => c.diff != null && Math.abs(c.diff) > (Number(cfg.castTol) || 0.01))
      .map(c => ({ key:c.label, expected:c.stmtBal, actual:c.conf, difference:c.diff, detail:'Balance per bank confirmation does not agree to the statement balance' })) },
  { id:'EX-CASH-10', scope:'population', label:'Statement balance does not agree to the bank reconciliation or ledger', basis:'M',
    fn:(recs, cfg, eng, d) => d.lead.filter(a => (a.diffStmtRec != null && Math.abs(a.diffStmtRec) > (Number(cfg.castTol) || 0.01)) || (a.diffRecTB != null && Math.abs(a.diffRecTB) > (Number(cfg.castTol) || 0.01)))
      .map(a => ({ key:a.label, expected:a.stmtBal, actual:a.rec ?? a.tb, difference: r2((a.diffStmtRec || 0) + (a.diffRecTB || 0)),
        detail:`Statement vs reconciliation ${a.diffStmtRec != null ? a.diffStmtRec.toFixed(2) : 'n/a'}; reconciliation vs ledger ${a.diffRecTB != null ? a.diffRecTB.toFixed(2) : 'n/a'}` })) }
];

/* ============================================================== PAGES */
const yn = ['Y', 'N'];
const txRow = r => ({ __rec:r, date:r.stmt_date, narrative:r.narrative, reference:r.reference, out:r.__out || null, in_:r.__in || null, balance:r.balance });
const TX_COLS = [
  { key:'date', label:'Date', type:'date' }, { key:'narrative', label:'Narrative', wrap:true }, { key:'reference', label:'Reference' },
  { key:'out', label:'Withdrawal', type:'num', sum:true }, { key:'in_', label:'Deposit', type:'num', sum:true }, { key:'balance', label:'Balance', type:'num' }
];

const pages = [
  { id:'source',  ref:'M.0',  title:'Source data',     kind:'source' },
  { id:'cleaned', ref:'M.0a', title:'Cleaned listing', kind:'cleaned' },
  { id:'mapping', ref:'M.0b', title:'Column mapping',  kind:'mapping' },

  { id:'lead', ref:'M', title:'Lead schedule',
    objective:'To agree cash and bank balances per the bank statements to the bank reconciliations and the general ledger for every account, and to explain the movement against the prior year.',
    procedures:['Recomputed the closing balance of the uploaded statement from the opening balance and the transactions listed, and agreed it to the closing balance printed on the statement.',
                'Entered every bank account held, with the balance per statement, per the bank reconciliation, per the general ledger and per the prior year audited financial statements.',
                'Investigated differences between statement, reconciliation and ledger, and movements against the prior year above performance materiality.'],
    render(st, ctx) {
      const d = ctx.d, S = d.statement, cfg = ctx.cfg, m0 = ctx.money0, money = ctx.money;
      const rows = d.lead.map(a => ({ __key:a.key, source: a.fromUpload ? 'Uploaded statement' : 'Entered', stmtBalC: a.stmtBal,
        diffStmtRec: a.diffStmtRec, diffRecTB: a.diffRecTB, variance: a.variance, variancePct: a.variancePct != null ? a.variancePct / 100 : null,
        __cls: a.material ? 'flag' : '' }));
      return [
        { type:'stats', items:[
          { label:'Statement opening balance', value: m0(S.opening) },
          { label:'Deposits', value: m0(S.totalIn) }, { label:'Withdrawals', value: m0(S.totalOut) },
          { label:'Closing recomputed', value: m0(S.computedClosing) },
          { label:'Closing per statement', value: m0(S.closing) },
          { label:'Roll difference', value: money(S.rollDiff), cls: S.rollDiff == null ? '' : Math.abs(S.rollDiff) > 0.01 ? 'bad' : 'ok' },
          { label:'Lines that break the roll', value: S.rollBreaks, cls: S.rollBreaks ? 'bad' : 'ok' },
          { label:'Transactions', value: `${S.count} · ${S.firstDate ? Core.fmtDate(S.firstDate) : ''} – ${S.lastDate ? Core.fmtDate(S.lastDate) : ''}` } ] },
        { type:'note', tone: S.hasOpeningRow && S.hasClosingRow ? 'info' : 'warn',
          html: S.hasOpeningRow && S.hasClosingRow
            ? `The statement carries an opening and a closing balance line; both were held out of the transaction population and used to prove the roll.${S.closingMatchesYE ? '' : ' <b>The closing line is not dated at the year end</b> — confirm the statement covers the reporting date.'}`
            : `<b>No ${!S.hasOpeningRow ? 'opening' : ''}${!S.hasOpeningRow && !S.hasClosingRow ? ' or ' : ''}${!S.hasClosingRow ? 'closing' : ''} balance line was found.</b> The ${!S.hasOpeningRow ? 'opening balance was inferred from the first transaction' : 'closing balance was taken from the last transaction'}; confirm against the printed statement.` },
        { type:'controls', items:[
          { key:'extraAccounts', label:'Number of further bank accounts (not uploaded)', kind:'number', help:'One row per account below, in addition to the account whose statement was uploaded.' },
          { key:'castTol', label:'Tolerance for differences', kind:'number' } ] },
        { type:'table', title:'Cash and bank by account', columns:[
          { key:'source', label:'Source' },
          { key:'accLabel', label:'Account (bank, number, type)', input:'text', wide:true },
          { key:'stmtBal', label:'Statement balance (enter for further accounts)', input:'number' },
          { key:'stmtBalC', label:'Balance per statement', type:'num', sum:true },
          { key:'recBal', label:'Balance per bank reconciliation', input:'number' },
          { key:'tbBal', label:'Balance per ledger / TB', input:'number' },
          { key:'diffStmtRec', label:'Statement − reconciliation', type:'num', flag: v => v != null && Math.abs(v) > 0.01 },
          { key:'diffRecTB', label:'Reconciliation − ledger', type:'num', flag: v => v != null && Math.abs(v) > 0.01 },
          { key:'pyBal', label:'Prior year audited', input:'number' },
          { key:'variance', label:'Movement vs PY', type:'num', flag: (v, row) => row.__cls === 'flag' },
          { key:'variancePct', label:'Movement %', type:'pct' } ],
          rows,
          footnote:'Inputs are the auditor\'s. The first row is the account whose statement was uploaded: its statement balance is computed. Enter the statement balance for every further account. Differences above the tolerance are painted red and raised as EX-CASH-10.' },
        { type:'stats', items:[
          { label:'Total per statements', value: m0(d.leadTotals.stmt) }, { label:'Total per reconciliations', value: m0(d.leadTotals.rec) },
          { label:'Total per ledger', value: m0(d.leadTotals.tb) }, { label:'Total prior year', value: m0(d.leadTotals.py) },
          { label:'Movement in cash and bank', value: money(r2(d.leadTotals.tb - d.leadTotals.py)) } ] }
      ];
    },
    flag(st, d) { return (d.statement.rollDiff != null && Math.abs(d.statement.rollDiff) > 0.01) || d.lead.some(a => (a.diffStmtRec != null && Math.abs(a.diffStmtRec) > 0.01) || (a.diffRecTB != null && Math.abs(a.diffRecTB) > 0.01)); } },

  { id:'recon', ref:'M1', title:'Bank reconciliation review',
    objective:'To verify that the year-end bank reconciliation for the uploaded account is arithmetically correct, that reconciling items are valid and clear after the year end, and that no reconciling item is long outstanding.',
    procedures:['Agreed the balance per bank on the reconciliation to the closing balance per the statement.',
                'Listed every reconciling item with its date and amount, recomputed the reconciliation from the statement balance and compared the result to the cash book balance.',
                'Aged each reconciling item at the year end and flagged items outstanding beyond the threshold set; traced clearance to the post year-end statement.'],
    render(st, ctx) {
      const R = ctx.d.recon, S = ctx.d.statement, money = ctx.money, m0 = ctx.money0;
      const rows = [];
      const n = Math.max(0, Math.min(60, Math.round(Number(ctx.cfg.recItemRows) || 0)));
      for (let i = 1; i <= n; i++) {
        const it = R.items.find(x => x.i === i);
        rows.push({ __key:'ri' + i, line:i, toLedger: it ? it.toLedger : null, age: it ? it.age : null,
          status: it ? (it.stale ? 'Long outstanding' : (it.age != null ? 'Within threshold' : '')) : '', __cls: it?.stale ? 'flag' : '' });
      }
      return [
        { type:'controls', items:[
          { key:'ledgerBalance', label:'Cash book / ledger balance at year end (per client)', kind:'number' },
          { key:'recItemRows', label:'Reconciling item lines', kind:'number' },
          { key:'staleDays', label:'Long-outstanding threshold (days)', kind:'number', help:'Reconciling items older than this at the year end are flagged (EX-CASH-02).' } ] },
        { type:'table', title:'Reconciling items per the client\'s bank reconciliation', columns:[
          { key:'line', label:'#', type:'int' },
          { key:'riType', label:'Type', input:'select', options:RECON_TYPES },
          { key:'riDate', label:'Date of item (dd/mm/yyyy)', input:'text' },
          { key:'riRef', label:'Reference / payee', input:'text', wide:true },
          { key:'riAmount', label:'Amount', input:'number' },
          { key:'toLedger', label:'Effect towards ledger', type:'num', sum:true },
          { key:'age', label:'Days outstanding at YE', type:'int' },
          { key:'status', label:'Status', type:'chip', chipClass: v => v === 'Long outstanding' ? 'bad' : 'ok' },
          { key:'riCleared', label:'Cleared post YE (Y/N)', input:'select', options:yn },
          { key:'riComment', label:'Comment', input:'text', wide:true } ], rows,
          footnote:'Unpresented cheques reduce, deposits in transit increase, the statement balance to arrive at the ledger. Errors and other items are taken as signed (positive increases the expected ledger balance).' },
        { type:'stats', items:[
          { label:'Balance per bank statement', value: m0(S.closing) },
          { label:'Add: deposits in transit', value: m0(R.inTransit) },
          { label:'Less: unpresented cheques', value: m0(R.unpresented) },
          { label:'Other reconciling items', value: money(R.otherItems) },
          { label:'Expected ledger balance', value: m0(R.expectedLedger) },
          { label:'Ledger balance per client', value: R.ledger == null ? '— enter above —' : m0(R.ledger) },
          { label:'Unexplained difference', value: R.unexplained == null ? '' : money(R.unexplained), cls: R.unexplained == null ? '' : Math.abs(R.unexplained) > 0.01 ? 'bad' : 'ok' },
          { label:'Long-outstanding items', value: R.staleItems.length, cls: R.staleItems.length ? 'bad' : 'ok' } ] },
        { type:'note', tone: R.unexplained != null && Math.abs(R.unexplained) > 0.01 ? 'bad' : 'info',
          html: R.unexplained == null ? 'Enter the ledger balance and the reconciling items to prove the reconciliation.'
            : Math.abs(R.unexplained) > 0.01 ? `<b>The reconciliation does not prove</b> by ${money(R.unexplained)}. Raised as EX-CASH-01.` : 'The reconciliation proves to the ledger balance.' }
      ];
    },
    flag(st, d) { return (d.recon.unexplained != null && Math.abs(d.recon.unexplained) > 0.01) || d.recon.staleItems.length > 0; } },

  { id:'confirm', ref:'M2', title:'Bank confirmation control',
    objective:'To obtain external confirmation of every bank balance, facility and security held at the year end directly from the bank (ISA 505), and to agree confirmed balances to the statements.',
    procedures:['Sent a bank confirmation request for every account and facility under the auditor\'s control and recorded the date sent and the date received.',
                'Agreed each confirmed balance to the balance per statement and investigated differences.',
                'Recorded facilities, guarantees, security and restrictions reported by the bank for the disclosure review.'],
    render(st, ctx) {
      const C = ctx.d.confirmations, money = ctx.money;
      const recd = C.filter(c => c.received === 'Y').length;
      return [
        { type:'stats', items:[
          { label:'Accounts', value: C.length }, { label:'Confirmations received', value: `${recd} of ${C.length}`, cls: recd === C.length ? 'ok' : 'warn' },
          { label:'Balances agreeing', value: C.filter(c => c.diff != null && Math.abs(c.diff) <= 0.01).length },
          { label:'Differences', value: C.filter(c => c.diff != null && Math.abs(c.diff) > 0.01).length, cls: C.some(c => c.diff != null && Math.abs(c.diff) > 0.01) ? 'bad' : 'ok' } ] },
        { type:'table', title:'Confirmation control sheet', columns:[
          { key:'label', label:'Account' },
          { key:'stmtBal', label:'Balance per statement', type:'num', sum:true },
          { key:'confSent', label:'Request sent (date)', input:'text' },
          { key:'confRecd', label:'Reply received', input:'select', options:yn },
          { key:'confRecdDate', label:'Date received', input:'text' },
          { key:'confBal', label:'Balance per confirmation', input:'number' },
          { key:'diff', label:'Confirmation − statement', type:'num', flag: v => v != null && Math.abs(v) > 0.01 },
          { key:'confFac', label:'Facilities / loans reported', input:'text', wide:true },
          { key:'confSec', label:'Security / guarantees / restrictions', input:'text', wide:true },
          { key:'confComment', label:'Comment', input:'text', wide:true } ],
          rows: C.map(c => ({ __key:c.key, label:c.label, stmtBal:c.stmtBal, diff:c.diff, __cls: c.diff != null && Math.abs(c.diff) > 0.01 ? 'flag' : '' })),
          footnote:'Accounts are those entered on M. Differences are raised as EX-CASH-09.' },
        { type:'note', html:'Where a reply is not received, perform alternative procedures: obtain the year-end statement directly from the online banking portal in the presence of the client and record it in the comment column.' }
      ];
    },
    flag(st, d) { return d.confirmations.some(c => c.diff != null && Math.abs(c.diff) > 0.01); } },

  { id:'scrutiny', ref:'M3', title:'Statement scrutiny',
    objective:'To scrutinise the bank statement for large, unusual, round-sum, weekend, related-party or unidentified transactions and to vouch the items selected to supporting documentation.',
    procedures:['Flagged every transaction at or above the testing threshold, every round sum, every weekend posting, every narrative indicating a related party, director or unidentified counterparty, and every posting in the first and last days of the year.',
                'Drew a random sample from the remaining transactions using a recorded seed so the selection is reproducible.',
                'Vouched each selected item to the remittance advice, invoice, contract or board approval and recorded whether it agreed.'],
    render(st, ctx) {
      const S = ctx.d.scrutiny, m0 = ctx.money0, pct = ctx.pct;
      const rows = S.selected.map(r => ({ ...txRow(r), basis: r.__scrReasons.length ? r.__scrReasons.join('; ') : 'Random sample', __cls: r.__rp ? 'flag' : '' }));
      return [
        { type:'controls', items:[
          { key:'scrThreshold', label:'Testing threshold — every item at or above is selected', kind:'number', help:`Blank = performance materiality (${m0(ctx.pm)}). Currently ${m0(S.threshold)}.` },
          { key:'roundSum', label:'Round-sum flag: multiple of', kind:'number' },
          { key:'edgeDays', label:'First / last N days of the year', kind:'number' },
          { key:'rpPattern', label:'Additional narrative pattern (regular expression)', kind:'text', help:'Related party, director, shareholder, intercompany, unidentified, suspense and sundry are always caught.' },
          { key:'scrSampleN', label:'Random sample from the remaining transactions', kind:'number', help:`${S.residual.length} transactions not otherwise flagged` },
          { key:'scrSeed', label:'Random seed', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Transactions', value: `${ctx.d.txCount} · ${m0(S.popValue)}` },
          { label:'Flagged by rule', value: S.flagged.length }, { label:'Random sample', value: S.sample.length },
          { label:'Coverage of gross movement', value: pct(S.coverage), cls: S.coverage >= 60 ? 'ok' : 'warn' },
          { label:'Vouched and agreed', value: `${S.vouched} of ${S.selected.length}`, cls: S.vouched === S.selected.length && S.selected.length ? 'ok' : 'warn' },
          ...Object.entries(S.byReason).map(([k, v]) => ({ label: k, value: v })) ] },
        { type:'table', title:'Items selected for vouching', columns:[
          ...TX_COLS, { key:'basis', label:'Selection basis', wrap:true },
          { key:'doc', label:'Supporting document seen', input:'text', wide:true },
          { key:'agreed', label:'Agreed (Y/N)', input:'select', options:yn },
          { key:'comment', label:'Comment', input:'text', wide:true } ], rows, maxHeight:'70vh',
          emptyText:'No transactions selected — lower the threshold or increase the sample size.',
          footnote:`Seed ${S.seed}. Rows painted red carry a related-party, director or unidentified narrative (EX-CASH-04). Items above the threshold not agreed are listed as EX-CASH-03 until vouched.` }
      ];
    },
    flag(st, d) { return d.scrutiny.selected.some(r => r.__rp); } },

  { id:'cutoff', ref:'M4', title:'Cut-off',
    objective:'To verify that receipts and payments around the year end are recorded in the cash book in the period to which they belong.',
    procedures:['Listed every statement transaction within the cut-off window either side of the year end.',
                'Traced each item to the cash book and recorded whether it was posted in the correct period.'],
    render(st, ctx) {
      const C = ctx.d.cutoff, m0 = ctx.money0;
      const before = C.filter(r => r.__cutoffSide === 'Before year end'), after = C.filter(r => r.__cutoffSide === 'After year end');
      const done = C.filter(r => r.__wp?.cutoff?.correct).length;
      return [
        { type:'controls', items:[{ key:'cutoffDays', label:'Cut-off window (days either side of the year end)', kind:'number' }] },
        { type:'stats', items:[
          { label:'Items before year end', value: `${before.length} · ${m0(before.reduce((s, r) => s + Math.max(r.__in, r.__out), 0))}` },
          { label:'Items after year end', value: `${after.length} · ${m0(after.reduce((s, r) => s + Math.max(r.__in, r.__out), 0))}` },
          { label:'Tested', value: `${done} of ${C.length}`, cls: done === C.length && C.length ? 'ok' : 'warn' },
          { label:'Recorded in wrong period', value: C.filter(r => r.__wp?.cutoff?.correct === 'N').length, cls: C.some(r => r.__wp?.cutoff?.correct === 'N') ? 'bad' : 'ok' } ] },
        { type:'table', title:'Transactions within the cut-off window', columns:[
          ...TX_COLS, { key:'side', label:'Side', type:'chip', chipClass: v => v === 'After year end' ? 'info' : 'grey' },
          { key:'cbDate', label:'Date posted in cash book', input:'text' },
          { key:'correct', label:'Correct period (Y/N)', input:'select', options:yn },
          { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: C.map(r => ({ ...txRow(r), side:r.__cutoffSide })),
          emptyText:'No statement transactions fall within the cut-off window. Widen the window or confirm the statement covers the year end.' }
      ];
    },
    flag(st, d) { return d.cutoff.some(r => r.__wp?.cutoff?.correct === 'N'); } },

  { id:'analytics', ref:'M5', title:'Cash flow analytics',
    objective:'To understand the pattern of receipts and payments through the account over the year and to identify the principal counterparties, as a basis for the scrutiny and for the going concern assessment.',
    procedures:['Summarised inflows, outflows and net movement by month from the statement.',
                'Grouped transactions by counterparty stem in the narrative and listed the largest.'],
    render(st, ctx) {
      const d = ctx.d, m0 = ctx.money0;
      const peak = d.monthly.reduce((b, m) => !b || m.outflow > b.outflow ? m : b, null);
      return [
        { type:'stats', items:[
          { label:'Months with activity', value: d.monthly.length },
          { label:'Total inflows', value: m0(d.statement.totalIn) }, { label:'Total outflows', value: m0(d.statement.totalOut) },
          { label:'Net movement', value: ctx.money(d.statement.net), cls: d.statement.net < 0 ? 'warn' : 'ok' },
          { label:'Heaviest month for payments', value: peak ? `${peak.label} · ${m0(peak.outflow)}` : '' },
          { label:'Distinct counterparty stems', value: d.counterparties.length } ] },
        { type:'table', title:'Monthly inflows and outflows', columns:[
          { key:'label', label:'Month' }, { key:'count', label:'Transactions', type:'int' },
          { key:'inflow', label:'Inflows', type:'num', sum:true }, { key:'outflow', label:'Outflows', type:'num', sum:true },
          { key:'net', label:'Net', type:'num', sum:true, formula:(row, C) => `${C(2)}${row}-${C(3)}${row}` } ], rows: d.monthly },
        { type:'controls', items:[{ key:'topN', label:'Counterparties to list', kind:'number' }] },
        { type:'table', title:'Largest counterparties by narrative stem', columns:[
          { key:'stem', label:'Counterparty / narrative stem' }, { key:'count', label:'Transactions', type:'int' },
          { key:'inflow', label:'Inflows', type:'num', sum:true }, { key:'outflow', label:'Outflows', type:'num', sum:true },
          { key:'gross', label:'Gross', type:'num', sum:true }, { key:'share', label:'Share of gross movement', type:'pct' },
          { key:'comment', label:'Auditor comment', input:'text', wide:true } ],
          rows: d.topCounterparties.map(c => ({ __key: Core.keyify(c.stem) || 'blank', ...c, share: c.share / 100 })),
          footnote:'The stem is the narrative before any dash or reference, with numbers removed, so that recurring payees group together.' }
      ];
    } },

  { id:'conclusion', ref:'M.9', title:'Exceptions & conclusion', kind:'conclusion' }
];

function suggestConclusion(st, ctx) {
  const d = ctx.d, S = d.statement, R = d.recon;
  const ex = (st.exceptions || []).filter(e => e.disposition === 'open');
  return [
    `The closing balance per the uploaded bank statement of ${ctx.money(S.closing)} was recomputed from the opening balance and ${S.count} transactions${S.rollDiff != null && Math.abs(S.rollDiff) <= 0.01 ? ' and agrees' : ', with a difference of ' + ctx.money(S.rollDiff)}.`,
    R.unexplained == null ? 'The bank reconciliation has not yet been proved on M1.' : Math.abs(R.unexplained) <= 0.01 ? 'The bank reconciliation proves to the ledger with no unexplained difference.' : `The bank reconciliation carries an unexplained difference of ${ctx.money(R.unexplained)}.`,
    R.staleItems.length ? `${R.staleItems.length} reconciling item(s) are outstanding beyond ${R.staleDays} days.` : '',
    `${d.scrutiny.selected.length} statement items were selected for vouching (${ctx.pct(d.scrutiny.coverage)} of gross movement); ${d.scrutiny.vouched} agreed to supporting documents.`,
    ex.length ? `${ex.length} exception(s) remain open in the register.` : 'No exceptions remain open.',
    'Subject to the above, cash and bank balances are fairly stated at the reporting date.'
  ].filter(Boolean).join(' ');
}

return {
  code:'CASH', name:'Cash & Bank', group:'Assets', accepts:'.xlsx,.xlsm,.csv',
  blurb:'The cash and bank audit file: lead by account, bank reconciliation review, confirmation control, statement scrutiny, cut-off and cash flow analytics — from one uploaded bank statement.',
  objective:'To obtain sufficient appropriate audit evidence that cash and bank balances exist, are owned by the entity, are complete and accurately recorded at the reporting date, and that restrictions and facilities are properly disclosed.',
  fields, tests, compute, pages, defaultConfig, STANDARD_COLUMNS, RECON_TYPES,
  procedures: pages.flatMap(p => p.procedures || []),
  columns: STANDARD_COLUMNS, suggestConclusion
};
})();

Modules.register(CashModule);
