/* ==========================================================================
   gc.js -- Going concern (SSA / ISA 570) as an auditor actually works it.

   One uploaded sheet -- management's monthly cash flow forecast -- feeds the
   arithmetic; the covenant, facility and plans schedules are entered by the
   auditor on their own working papers:
     GC   Indicator register (gross)      GC4  Management's plans
     GC1  Cash flow forecast analysis     GC5  Sensitivity and reverse stress test
     GC2  Covenant compliance             GC6  Reporting decision
     GC3  Facility maturity profile

   Nothing here is drafted for the auditor. The module computes the period
   covered, the gross-versus-mitigated liquidity, the break-even variation and
   the opinion type that follows from the conclusions entered; the auditor
   concludes.
   ========================================================================== */

const GCModule = (() => {
const r2 = n => n == null || isNaN(n) ? null : Math.round(n * 100) / 100;
const num = v => (v === '' || v == null || isNaN(Number(v))) ? null : Number(v);
const inp = (cfg, key, k) => num(cfg[key + ':' + k]);
const txt = (cfg, key, k) => { const v = cfg[key + ':' + k]; return v == null ? '' : String(v).trim(); };
const lower = s => String(s == null ? '' : s).replace(/\s+/g, ' ').trim().toLowerCase();
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const MAXM = 24;

/* ---------------------------------------------------------- dates / months */
function parseDate(v) {
  if (v instanceof Date) return v;
  const s = String(v == null ? '' : v).trim();
  if (!s) return null;
  const iso = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  if (iso) return new Date(Date.UTC(+iso[1], +iso[2] - 1, +iso[3]));
  const p = Core.parseDateWith(s, 'dmy');
  return p && p.ok ? p.date : null;
}
/* "Mar 25", "Mar-2025", "March 2025", "2025-03", "03/2025" -> { y, m0 } */
function parseMonthLabel(h) {
  if (h instanceof Date) return { y: h.getUTCFullYear(), m0: h.getUTCMonth() };
  const s = String(h == null ? '' : h).trim();
  let m = s.match(/\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?[\s\-\/'’]*(\d{2}|\d{4})\b/i);
  if (m) { const mi = MONTHS.findIndex(x => x.toLowerCase() === m[1].toLowerCase()); let y = +m[2]; if (y < 100) y += 2000; return { y, m0: mi }; }
  m = s.match(/^(\d{4})[-\/](\d{1,2})$/);
  if (m) return { y: +m[1], m0: +m[2] - 1 };
  m = s.match(/^(\d{1,2})[-\/](\d{4})$/);
  if (m) return { y: +m[2], m0: +m[1] - 1 };
  return null;
}
const ymIndex = (y, m0) => y * 12 + m0;
const addMonths = (y, m0, k) => { const i = ymIndex(y, m0) + k; return { y: Math.floor(i / 12), m0: ((i % 12) + 12) % 12 }; };
const monthLabel = ({ y, m0 }) => `${MONTHS[m0]} ${y}`;
const monthEnd = ({ y, m0 }) => new Date(Date.UTC(y, m0 + 1, 0));

/* --------------------------------------------------------------- lines */
const KINDS = ['Operating', 'Debt service', 'Capital expenditure', 'Committed mitigating action', 'Uncommitted mitigating action', 'Summary line (excluded)'];
const SUMMARY_RE = /^(net cash ?flow|net (movement|change)|opening (cash|balance)|closing (cash|balance)|cash (at|brought|carried)|balance (b|c)\/f|undrawn|headroom|facility available|total liquidity|liquidity)/i;
const OPENING_RE = /^opening|brought forward|\bb\/f\b/i, CLOSING_RE = /^closing|carried forward|\bc\/f\b/i, HEADROOM_RE = /undrawn|headroom|facility available/i, NET_RE = /^net cash ?flow|^net (movement|change)/i;
const UNCOMMITTED_RE = /uncommitted|proposed|placement|share issue|equity (issue|injection|raise)|rights issue|shareholder (loan|injection|support)|new (loan|facility|borrowing)|refinanc|disposal of|sale of (property|business|asset)|grant|capital injection|subject to/i;
const DEBT_RE = /loan (principal|repayment|instalment)|principal repayment|repayment of (loan|borrowing)|interest paid|interest on|debt service|lease (payment|repayment)|hire purchase|finance cost/i;
const CAPEX_RE = /capital expenditure|capex|purchase of (ppe|property|plant|equipment|fixed asset)|acquisition of (ppe|property|equipment)/i;
const COMMITTED_RE = /deferr|headcount|cost saving|restructur|committed|reduction in|rent(al)? (holiday|reduction)|renegotiat/i;
function autoKind(line) {
  const n = lower(line);
  if (!n) return 'Operating';
  if (SUMMARY_RE.test(n)) return 'Summary line (excluded)';
  if (UNCOMMITTED_RE.test(n)) return 'Uncommitted mitigating action';
  if (DEBT_RE.test(n)) return 'Debt service';
  if (CAPEX_RE.test(n)) return 'Capital expenditure';
  if (COMMITTED_RE.test(n)) return 'Committed mitigating action';
  return 'Operating';
}

/* ---------------------------------------------------------------- fields */
const MONTH_SYN = [...MONTHS, 'Sept', 'January', 'February', 'March', 'April', 'June', 'July', 'August', 'September', 'October', 'November', 'December', 'Month 1', 'M1'];
const fields = [
  { key:'line', label:'Forecast line', role:'key', type:'text', required:true,
    synonyms:['Line','Cash flow line','Forecast line','Item','Description','Particulars','Category','Line item','Cash flows','项目','现金流项目'] },
  ...Array.from({ length: MAXM }, (_, i) => ({ key:'m' + (i + 1), label:`Month ${i + 1}`, type:'number', required: i === 0, block:'Forecast', synonyms: MONTH_SYN })),
  { key:'total', label:'Total for the period', type:'number', synonyms:['Total','Full year','Period total','12 months','Year total','合计'] }
];

const STANDARD_COLUMNS = [
  { key:'line', label:'Forecast line' }, { key:'__kind', label:'Classification' },
  ...Array.from({ length: 12 }, (_, i) => ({ key:'m' + (i + 1), label:`Month ${i + 1}`, type:'num', edit:true })),
  { key:'__total', label:'Total (recomputed)', type:'num', emphasis:true }, { key:'total', label:'Total per client', type:'num' }
];

const COVENANT_OPS = ['<=', '>='], CONSEQUENCES = ['Immediately repayable on demand', 'Step-up margin', 'Waiver obtained before year end', 'Renegotiation / cure period', 'Other'];
const yn = ['Y', 'N'];

/* SSA 570 para A3 -- the conditions the auditor asks about rather than computes. */
const INQUIRY_INDICATORS = [
  { id:'F-a', group:'Financial', text:'Fixed-term borrowings approaching maturity without realistic prospects of renewal or repayment, or excessive reliance on short-term borrowings to finance long-term assets' },
  { id:'F-b', group:'Financial', text:'Indications of withdrawal of financial support by creditors' },
  { id:'F-c', group:'Financial', text:'Adverse key financial ratios' },
  { id:'F-d', group:'Financial', text:'Substantial operating losses or significant deterioration in the value of assets used to generate cash flows' },
  { id:'F-e', group:'Financial', text:'Arrears or discontinuance of dividends' },
  { id:'F-f', group:'Financial', text:'Inability to pay creditors on due dates' },
  { id:'F-g', group:'Financial', text:'Change from credit to cash-on-delivery transactions with suppliers' },
  { id:'F-h', group:'Financial', text:'Inability to obtain financing for essential new product development or other essential investments' },
  { id:'O-a', group:'Operating', text:'Management intentions to liquidate the entity or to cease operations' },
  { id:'O-b', group:'Operating', text:'Loss of key management without replacement' },
  { id:'O-c', group:'Operating', text:'Loss of a major market, key customer(s), franchise, licence or principal supplier(s)' },
  { id:'O-d', group:'Operating', text:'Labour difficulties' },
  { id:'O-e', group:'Operating', text:'Shortages of important supplies' },
  { id:'O-f', group:'Operating', text:'Emergence of a highly successful competitor' },
  { id:'X-a', group:'Other', text:'Non-compliance with capital or other statutory or regulatory requirements' },
  { id:'X-b', group:'Other', text:'Pending legal or regulatory proceedings that may, if successful, result in claims the entity is unlikely to be able to satisfy' },
  { id:'X-c', group:'Other', text:'Changes in law or regulation or government policy expected to adversely affect the entity' },
  { id:'X-d', group:'Other', text:'Uninsured or underinsured catastrophes when they occur' },
];
const DISCLOSURE_ITEMS = [
  { id:'D1', text:'The note adequately describes the principal events or conditions that may cast significant doubt on the entity\'s ability to continue as a going concern' },
  { id:'D2', text:'The note describes management\'s plans to deal with those events or conditions' },
  { id:'D3', text:'The note states plainly that a material uncertainty exists that may cast significant doubt on the entity\'s ability to continue as a going concern and that the entity may be unable to realise its assets and discharge its liabilities in the normal course of business' },
  { id:'D4', text:'The basis of preparation states that the financial statements do not include the adjustments that would result if the entity were unable to continue as a going concern' },
  { id:'D5', text:'Where no material uncertainty is concluded after significant judgement (close call), the judgements made are disclosed (FRS 1 para 122 / ISA 570 para 20)' },
];

const defaultConfig = () => ({
  approvalDate: '',               // date the financial statements are (expected to be) approved -- dd/mm/yyyy or yyyy-mm-dd
  periodBasis: '2024',            // '2024': 12 months from approval; '2022': 12 months from the reporting date
  forecastStart: '',              // blank = month after the reporting date; else "Mar 2025" / "2025-03"
  auditedCash: '',                // cash and cash equivalents per the audited trial balance
  includeHeadroom: true,          // count undrawn committed facilities in liquidity
  undrawnCommitted: '',           // undrawn committed facility if the forecast carries no headroom line
  castTol: 0.01,
  covenantRows: 4, facilityRows: 4, planRows: 5,
  relianceLimitPct: 25,           // EX-GC-05: uncommitted funding above this % of minimum gross liquidity headroom
  tbTotalAssets: '', tbTotalLiabilities: '', tbCurrentAssets: '', tbCurrentLiabilities: '', tbPbtCY: '', tbPbtPY: '', tbOperatingCF: '',
  gcIndicators: {},               // checklist store
  downsidePct: 10, stressBasis: 'mitigated', sensitivityPrepared: '',
  mgmtAssessment: '', basisAppropriate: '', materialUncertainty: '', disclosureAdequate: '',
  gcDisclosure: {},
});

/* ============================================================ COMPUTE */
function compute(recs, cfg, eng) {
  const ye = eng.yearEndDate;
  const pm = eng.materiality?.pm || 0, trivial = eng.materiality?.trivial || 0;
  const tol = Number(cfg.castTol) || 0.01;
  const live = recs.filter(r => !r.__excluded);

  /* ---- classify lines -------------------------------------------------- */
  for (const r of recs) {
    r.__displayKey = r.line || ('row ' + r.__srcRow);
    r.__kindAuto = autoKind(r.line);
    const chosen = r.__wp?.forecast?.kind;
    r.__kind = KINDS.includes(chosen) ? chosen : r.__kindAuto;
    r.__vals = Array.from({ length: MAXM }, (_, i) => num(r['m' + (i + 1)]));
    r.__total = r2(r.__vals.reduce((s, v) => s + (v || 0), 0));
    r.__totalDiff = r.total != null ? r2(r.total - r.__total) : null;
  }
  const isSummary = r => r.__kind === 'Summary line (excluded)';
  const flows = live.filter(r => !isSummary(r));
  let N = 0;
  for (const r of live) r.__vals.forEach((v, i) => { if (v != null && i + 1 > N) N = i + 1; });

  /* ---- month sequence -------------------------------------------------- */
  let start = parseMonthLabel(cfg.forecastStart);
  if (!start && ye) start = addMonths(ye.getUTCFullYear(), ye.getUTCMonth(), 1);
  if (!start) start = { y: 2000, m0: 0 };
  const months = Array.from({ length: N }, (_, i) => { const ym = addMonths(start.y, start.m0, i); return { i, ...ym, label: monthLabel(ym) }; });
  const last = months[N - 1] || null;

  /* ---- client summary lines ------------------------------------------- */
  const find = re => live.find(r => isSummary(r) && re.test(r.line || ''));
  const openingRec = find(OPENING_RE), closingRec = find(CLOSING_RE), headroomRec = find(HEADROOM_RE), netRec = find(NET_RE);
  const auditedCash = num(cfg.auditedCash);
  const clientOpening = openingRec ? openingRec.__vals[0] : null;
  const openingUsed = clientOpening != null ? clientOpening : (auditedCash != null ? auditedCash : 0);
  const undrawnDefault = num(cfg.undrawnCommitted);

  /* ---- monthly arithmetic ---------------------------------------------- */
  const sumKind = (kind, t, sign) => flows.filter(r => r.__kind === kind).reduce((s, r) => { const v = r.__vals[t] || 0; return s + (sign == null ? v : (Math.sign(v) === sign ? v : 0)); }, 0);
  const monthly = [];
  let gCash = openingUsed, mCash = openingUsed;
  for (let t = 0; t < N; t++) {
    const receipts = sumKind('Operating', t, 1), payments = sumKind('Operating', t, -1);
    const debt = sumKind('Debt service', t), capex = sumKind('Capital expenditure', t), committed = sumKind('Committed mitigating action', t), uncommitted = sumKind('Uncommitted mitigating action', t);
    const grossFlow = receipts + payments + debt + capex + committed, mitFlow = grossFlow + uncommitted;
    const openG = gCash, openM = mCash;
    gCash += grossFlow; mCash += mitFlow;
    const headroom = cfg.includeHeadroom === false ? 0 : (headroomRec && headroomRec.__vals[t] != null ? headroomRec.__vals[t] : (undrawnDefault != null ? undrawnDefault : 0));
    const clientClosing = closingRec ? closingRec.__vals[t] : null;
    const clientNet = netRec ? netRec.__vals[t] : null;
    monthly.push({ i: t, label: months[t].label, receipts: r2(receipts), payments: r2(payments), debt: r2(debt), capex: r2(capex), committed: r2(committed), uncommitted: r2(uncommitted),
      grossFlow: r2(grossFlow), mitFlow: r2(mitFlow), openGross: r2(openG), openMit: r2(openM), grossCash: r2(gCash), mitCash: r2(mCash), headroom: r2(headroom),
      grossLiq: r2(gCash + headroom), mitLiq: r2(mCash + headroom), clientClosing, clientNet,
      closingDiff: clientClosing != null ? r2(clientClosing - mCash) : null, netDiff: clientNet != null ? r2(clientNet - mitFlow) : null });
  }
  const minOf = k => monthly.length ? monthly.reduce((b, m) => m[k] < b[k] ? m : b, monthly[0]) : null;
  const minGross = minOf('grossLiq'), minMit = minOf('mitLiq');
  const negGross = monthly.filter(m => m.grossLiq < -tol), negMit = monthly.filter(m => m.mitLiq < -tol);
  const firstNeg = arr => { const m = arr.find(x => x < -tol); return m == null ? null : arr.indexOf(m); };
  const totals = { receipts: 0, payments: 0, debt: 0, capex: 0, committed: 0, uncommitted: 0, grossFlow: 0, mitFlow: 0 };
  for (const m of monthly) for (const k of Object.keys(totals)) totals[k] += m[k] || 0;
  for (const k of Object.keys(totals)) totals[k] = r2(totals[k]);
  const closingRecomputed = monthly.length ? monthly[N - 1].mitCash : null;
  const clientFinalClosing = closingRec && monthly.length ? closingRec.__vals[N - 1] : null;
  const forecast = { N, months, start, last, openingUsed, clientOpening, auditedCash,
    openingDiff: (clientOpening != null && auditedCash != null) ? r2(clientOpening - auditedCash) : null,
    hasOpening: !!openingRec, hasClosing: !!closingRec, hasHeadroom: !!headroomRec, monthly, totals,
    minGross, minMit, negGross, negMit, firstNegGross: firstNeg(monthly.map(m => m.grossLiq)), firstNegMit: firstNeg(monthly.map(m => m.mitLiq)),
    closingRecomputed, clientFinalClosing, closingDiff: clientFinalClosing != null && closingRecomputed != null ? r2(clientFinalClosing - closingRecomputed) : null,
    uncommittedLines: flows.filter(r => r.__kind === 'Uncommitted mitigating action'), committedLines: flows.filter(r => r.__kind === 'Committed mitigating action'),
    lineCastBreaks: flows.filter(r => r.__totalDiff != null && Math.abs(r.__totalDiff) > tol) };

  /* ---- assessment period ----------------------------------------------- */
  const approval = parseDate(cfg.approvalDate);
  const monthsFromReporting = (last && ye) ? ymIndex(last.y, last.m0) - ymIndex(ye.getUTCFullYear(), ye.getUTCMonth()) : null;
  const monthsFromApproval = (last && approval) ? ymIndex(last.y, last.m0) - ymIndex(approval.getUTCFullYear(), approval.getUTCMonth()) : null;
  const basis = cfg.periodBasis === '2022' ? '2022' : '2024';
  const monthsSelected = basis === '2024' ? monthsFromApproval : monthsFromReporting;
  const periodEnd = last ? monthEnd(last) : null;
  const period = { approval, basis, monthsFromReporting, monthsFromApproval, monthsSelected, required: 12,
    shortfall: monthsSelected != null ? Math.max(0, 12 - monthsSelected) : null, periodEnd,
    deficient2024: monthsFromApproval != null && monthsFromApproval < 12, deficient2022: monthsFromReporting != null && monthsFromReporting < 12,
    deficient: monthsSelected != null && monthsSelected < 12,
    extensionTo: approval ? monthLabel(addMonths(approval.getUTCFullYear(), approval.getUTCMonth(), 12)) : null };

  /* ---- GC2 covenants --------------------------------------------------- */
  const nCov = Math.max(0, Math.min(20, Math.round(Number(cfg.covenantRows) || 0)));
  const covenants = [];
  for (let i = 1; i <= nCov; i++) {
    const k = 'c' + i;
    const facility = txt(cfg, 'covFacility', k), name = txt(cfg, 'covName', k), op = txt(cfg, 'covOp', k) || '>=';
    const threshold = inp(cfg, 'covThreshold', k), actual = inp(cfg, 'covActual', k), forecast = inp(cfg, 'covForecast', k);
    if (!facility && !name && threshold == null && actual == null && forecast == null) continue;
    const test = v => v == null || threshold == null ? null : (op === '<=' ? v <= threshold + 1e-9 : v >= threshold - 1e-9);
    const consequence = txt(cfg, 'covConsequence', k), current = txt(cfg, 'covCurrent', k);
    const actualOK = test(actual), forecastOK = test(forecast);
    covenants.push({ key:k, i, facility, name, op, threshold, actual, forecast, frequency: txt(cfg, 'covFreq', k), consequence, current,
      actualOK, forecastOK, headroom: forecast != null && threshold != null ? r2(op === '<=' ? threshold - forecast : forecast - threshold) : null,
      onDemand: /on demand|immediately repayable|repayable on demand|acceleration/i.test(consequence),
      breachForecast: forecastOK === false, breachActual: actualOK === false,
      ex03: forecastOK === false && /on demand|immediately repayable|repayable on demand|acceleration/i.test(consequence) && current !== 'Y' });
  }

  /* ---- GC3 facilities -------------------------------------------------- */
  const nFac = Math.max(0, Math.min(20, Math.round(Number(cfg.facilityRows) || 0)));
  const facilities = [];
  const fromDate = approval || ye;
  for (let i = 1; i <= nFac; i++) {
    const k = 'f' + i;
    const name = txt(cfg, 'facName', k), lender = txt(cfg, 'facLender', k);
    const limit = inp(cfg, 'facLimit', k), drawn = inp(cfg, 'facDrawn', k), maturity = parseDate(txt(cfg, 'facMaturity', k));
    if (!name && !lender && limit == null && drawn == null && !maturity) continue;
    const undrawn = limit != null ? r2(limit - (drawn || 0)) : null;
    const monthsToMaturity = (maturity && fromDate) ? ymIndex(maturity.getUTCFullYear(), maturity.getUTCMonth()) - ymIndex(fromDate.getUTCFullYear(), fromDate.getUTCMonth()) : null;
    const clientMonths = inp(cfg, 'facClientMonths', k);
    const renewal = txt(cfg, 'facRenewal', k);
    const withinPeriod = maturity && periodEnd ? maturity <= periodEnd : (monthsToMaturity != null ? monthsToMaturity < 12 : false);
    facilities.push({ key:k, i, name, lender, limit, drawn, undrawn, maturity, monthsToMaturity, clientMonths,
      monthsDiff: clientMonths != null && monthsToMaturity != null ? clientMonths - monthsToMaturity : null,
      renewal, evidence: txt(cfg, 'facEvidence', k), withinPeriod, ex04: !!withinPeriod && renewal !== 'Y', basisDate: approval ? 'approval date' : 'reporting date' });
  }
  const facTotals = { limit: r2(facilities.reduce((s, f) => s + (f.limit || 0), 0)), drawn: r2(facilities.reduce((s, f) => s + (f.drawn || 0), 0)), undrawn: r2(facilities.reduce((s, f) => s + (f.undrawn || 0), 0)) };

  /* ---- GC4 management's plans ----------------------------------------- */
  const nPlan = Math.max(0, Math.min(30, Math.round(Number(cfg.planRows) || 0)));
  const plans = [];
  for (let i = 1; i <= nPlan; i++) {
    const k = 'p' + i;
    const name = txt(cfg, 'planName', k), cash = inp(cfg, 'planCash', k);
    if (!name && cash == null) continue;
    const committed = txt(cfg, 'planCommitted', k), control = txt(cfg, 'planControl', k), evidence = txt(cfg, 'planEvidence', k);
    const noEvidence = !evidence || /^(none|nil|n\/?a|-|not obtained|not yet obtained|verbal.*only)$/i.test(evidence);
    plans.push({ key:k, i, name, cash, timing: txt(cfg, 'planTiming', k), status: txt(cfg, 'planStatus', k), committed, control, evidence, noEvidence,
      reliance: committed === 'Uncommitted' || control === 'N', assessment: txt(cfg, 'planAssessment', k) });
  }
  const planTotals = { all: r2(plans.reduce((s, p) => s + (p.cash || 0), 0)), uncommitted: r2(plans.filter(p => p.committed === 'Uncommitted').reduce((s, p) => s + (p.cash || 0), 0)),
    outsideControl: r2(plans.filter(p => p.control === 'N').reduce((s, p) => s + (p.cash || 0), 0)), reliance: r2(plans.filter(p => p.reliance).reduce((s, p) => s + (p.cash || 0), 0)),
    committed: r2(plans.filter(p => p.committed === 'Committed' && p.control !== 'N').reduce((s, p) => s + (p.cash || 0), 0)) };
  const limitPct = num(cfg.relianceLimitPct) != null ? num(cfg.relianceLimitPct) : 25;
  const minGrossHeadroom = minGross ? Math.max(0, minGross.grossLiq) : 0;
  const relianceLimit = r2(minGrossHeadroom * limitPct / 100);
  const reliance = { total: planTotals.reliance, limit: relianceLimit, limitPct, minGrossHeadroom, forecastUncommitted: totals.uncommitted,
    exceeded: planTotals.reliance > 0 && planTotals.reliance > relianceLimit + tol };

  /* ---- GC indicator register (gross) ----------------------------------- */
  const tb = { ta: num(cfg.tbTotalAssets), tl: num(cfg.tbTotalLiabilities), ca: num(cfg.tbCurrentAssets), cl: num(cfg.tbCurrentLiabilities), pbt: num(cfg.tbPbtCY), pbtPY: num(cfg.tbPbtPY), ocf: num(cfg.tbOperatingCF) };
  const fig = v => v == null ? '' : Number(v).toLocaleString(undefined, { maximumFractionDigits: 0 });
  const computed = [
    { id:'C1', label:'Net liability position', how:'Total liabilities > total assets (audited trial balance)', present: tb.ta != null && tb.tl != null ? tb.tl > tb.ta : null, figure: tb.ta != null && tb.tl != null ? `Net assets ${fig(tb.ta - tb.tl)}` : '' },
    { id:'C2', label:'Net current liability position', how:'Current liabilities > current assets (audited trial balance)', present: tb.ca != null && tb.cl != null ? tb.cl > tb.ca : null, figure: tb.ca != null && tb.cl != null ? `Net current assets ${fig(tb.ca - tb.cl)}; current ratio ${tb.cl ? (tb.ca / tb.cl).toFixed(2) : 'n/a'}` : '' },
    { id:'C3', label:'Negative operating cash flows', how:'Operating cash flow for the year < 0 (cash flow statement)', present: tb.ocf != null ? tb.ocf < 0 : null, figure: tb.ocf != null ? `Operating cash flow ${fig(tb.ocf)}` : '' },
    { id:'C4', label:'Recurring losses', how:'Profit before tax negative in the current and the prior period', present: tb.pbt != null && tb.pbtPY != null ? (tb.pbt < 0 && tb.pbtPY < 0) : (tb.pbt != null ? tb.pbt < 0 : null), figure: tb.pbt != null ? `PBT ${fig(tb.pbt)}${tb.pbtPY != null ? ' / PY ' + fig(tb.pbtPY) : ''}` : '' },
    { id:'C5', label:'Inability to comply with loan covenants', how:'Forecast covenant position outside threshold at any test date within the period (GC2)', present: covenants.length ? covenants.some(c => c.breachForecast || c.breachActual) : null, figure: covenants.length ? `${covenants.filter(c => c.breachForecast).length} of ${covenants.length} forecast to breach` : '' },
    { id:'C6', label:'Borrowings approaching maturity without renewal', how:'Facility maturing within the assessment period and renewal not confirmed in writing (GC3)', present: facilities.length ? facilities.some(f => f.ex04) : null, figure: facilities.length ? `${facilities.filter(f => f.ex04).length} facility(ies), undrawn ${fig(facilities.filter(f => f.ex04).reduce((s, f) => s + (f.undrawn || 0), 0))}` : '' },
    { id:'C7', label:'Negative liquidity before mitigating actions', how:'Gross liquidity negative in any forecast month (GC1)', present: N ? negGross.length > 0 : null, figure: minGross ? `Minimum gross liquidity ${fig(minGross.grossLiq)} in ${minGross.label}` : '' },
    { id:'C8', label:'Reliance on uncommitted funding', how:'Uncommitted or outside-control plans exceed the reliance limit (GC4)', present: plans.length ? reliance.exceeded : null, figure: plans.length ? `Uncommitted ${fig(planTotals.reliance)} vs limit ${fig(relianceLimit)}` : '' },
  ].map(c => { const ov = cfg['indOverride:' + c.id] || ''; const eff = ov === 'Y' ? true : ov === 'N' ? false : c.present; return { ...c, override: ov, effective: eff, comment: cfg['indComment:' + c.id] || '' }; });
  const inquiry = INQUIRY_INDICATORS.map(it => ({ ...it, answer: (cfg.gcIndicators || {})[it.id]?.answer || '', comment: (cfg.gcIndicators || {})[it.id]?.comment || '' }));
  const indicators = { computed, inquiry, tb, presentComputed: computed.filter(c => c.effective === true).length, presentInquiry: inquiry.filter(i => i.answer === 'Y').length,
    notAssessed: computed.filter(c => c.effective == null).length + inquiry.filter(i => !i.answer).length };
  indicators.anyPresent = indicators.presentComputed + indicators.presentInquiry > 0;

  /* ---- GC5 sensitivity and reverse stress test ------------------------- */
  const stressBasis = cfg.stressBasis === 'gross' ? 'gross' : 'mitigated';
  const liq = (opts = {}) => {              // recompute liquidity under a variation; returns { series, min, firstNeg }
    const cut = opts.receiptsCut || 0, up = opts.paymentsUp || 0, delay = opts.delay || 0;
    let cash = openingUsed; const series = [];
    for (let t = 0; t < N; t++) {
      const m = monthly[t];
      const rec = delay > 0 ? (t - delay >= 0 ? monthly[t - delay].receipts : 0) : m.receipts;
      const flow = rec * (1 - cut) + m.payments * (1 + up) + m.debt + m.capex + m.committed + (stressBasis === 'mitigated' ? m.uncommitted : 0);
      cash += flow;
      series.push(r2(cash + m.headroom));
    }
    const min = series.length ? Math.min(...series) : null;
    const fn = series.findIndex(v => v < -tol);
    return { series, min, firstNeg: fn < 0 ? null : fn, monthsHeadroom: fn < 0 ? N : fn };
  };
  const bisect = (f, lo, hi) => {          // f monotone decreasing; find x with f(x) = 0 in [lo, hi]
    let flo = f(lo), fhi = f(hi);
    if (flo <= 0) return lo; if (fhi > 0) return null;
    for (let i = 0; i < 60; i++) { const mid = (lo + hi) / 2; const fm = f(mid); if (fm > 0) lo = mid; else hi = mid; }
    return (lo + hi) / 2;
  };
  const baseLiq = liq();
  const beReceipts = N ? bisect(x => liq({ receiptsCut: x }).min, 0, 1) : null;
  const bePayments = N ? bisect(x => liq({ paymentsUp: x }).min, 0, 5) : null;
  const delays = N ? [1, 2, 3].map(k => ({ delay: k, ...liq({ delay: k }) })) : [];
  const downPct = num(cfg.downsidePct) != null ? num(cfg.downsidePct) : 10;
  const downside = N ? liq({ receiptsCut: downPct / 100 }) : null;
  const stress = { basis: stressBasis, base: baseLiq, beReceipts, bePayments, delays, downPct, downside,
    beReceiptsAmt: beReceipts != null ? r2(totals.receipts * beReceipts) : null, alreadyExhausted: baseLiq.min != null && baseLiq.min < -tol,
    sensitivityPrepared: cfg.sensitivityPrepared || '' };

  /* ---- GC6 reporting decision ------------------------------------------ */
  const A = cfg.mgmtAssessment || '', B = cfg.basisAppropriate || '', MU = cfg.materialUncertainty || '', D = cfg.disclosureAdequate || '';
  let opinion = '', section = '', path = '';
  if (A === 'N') { opinion = 'Consider qualified opinion or disclaimer'; section = 'Basis for qualified opinion / disclaimer: management unwilling to make or extend its assessment (ISA 570 para 24)'; path = 'Assessment refused'; }
  else if (B === 'N') { opinion = 'Adverse'; section = 'Basis for adverse opinion: going concern basis inappropriate (ISA 570 para 21)'; path = 'Basis inappropriate'; }
  else if (B === 'Y' && MU === 'N') { opinion = 'Unmodified'; section = 'No going concern section. Consider a key audit matter where the conclusion involved significant judgement (close call) and confirm the FRS 1 para 122 judgement disclosure.'; path = 'No material uncertainty'; }
  else if (B === 'Y' && MU === 'Y' && D === 'Y') { opinion = 'Unmodified with Material Uncertainty Related to Going Concern section'; section = 'Separate section headed "Material Uncertainty Related to Going Concern" drawing attention to the note and stating the opinion is not modified (ISA 570 para 22)'; path = 'Material uncertainty, adequately disclosed'; }
  else if (B === 'Y' && MU === 'Y' && D === 'N') { opinion = 'Qualified or adverse (pervasiveness judgement)'; section = 'Basis for qualified / adverse opinion stating that a material uncertainty exists and that the financial statements do not adequately disclose it (ISA 570 para 23)'; path = 'Material uncertainty, inadequately disclosed'; }
  const disclosure = DISCLOSURE_ITEMS.map(it => ({ ...it, answer: (cfg.gcDisclosure || {})[it.id]?.answer || '', comment: (cfg.gcDisclosure || {})[it.id]?.comment || '' }));
  const reporting = { mgmtAssessment: A, basisAppropriate: B, materialUncertainty: MU, disclosureAdequate: D, opinion, section, path, complete: !!opinion,
    disclosure, disclosureGaps: MU === 'Y' ? disclosure.filter(x => ['D1', 'D2', 'D3', 'D4'].includes(x.id) && x.answer === 'N') : [],
    inconsistent: MU === 'Y' && D === 'Y' && disclosure.some(x => ['D1', 'D2', 'D3'].includes(x.id) && x.answer === 'N') };

  return { forecast, period, covenants, facilities, facTotals, plans, planTotals, reliance, indicators, stress, reporting, pm, trivial, tol };
}

/* ============================================================== TESTS */
const tests = [
  { id:'EX-GC-01', scope:'population', label:'Assessment period covers less than twelve months', basis:'GC1', severity:'above-trivial',
    fn:(recs, cfg, eng, d) => d.period.deficient && { key:'forecast', expected:12, actual:d.period.monthsSelected, difference:null,
      detail:`Forecast covers ${d.period.monthsSelected} months from the ${d.period.basis === '2024' ? 'approval date (2024 basis)' : 'reporting date (2022 basis)'}${d.period.basis === '2024' && d.period.monthsFromReporting != null ? '; ' + d.period.monthsFromReporting + ' months from the reporting date' : ''}. Request an extension to ${d.period.extensionTo || 'twelve months from approval'}.` } },
  { id:'EX-GC-02', scope:'population', label:'Covenant forecast to be breached within the assessment period', basis:'GC2', severity:'above-trivial',
    fn:(recs, cfg, eng, d) => d.covenants.filter(c => c.breachForecast).map(c => ({ key:`${c.facility || 'Facility'} — ${c.name || 'covenant'}`, expected:`${c.op} ${c.threshold}`, actual:c.forecast,
      difference:null, detail:`Forecast ${c.forecast} against threshold ${c.op} ${c.threshold}${c.frequency ? ' (' + c.frequency + ')' : ''}. Consequence: ${c.consequence || 'not recorded'}.` })) },
  { id:'EX-GC-03', scope:'population', label:'Forecast breach makes the borrowing repayable on demand', basis:'GC2', severity:'above-trivial',
    fn:(recs, cfg, eng, d) => d.covenants.filter(c => c.ex03).map(c => ({ key:`${c.facility || 'Facility'} — ${c.name || 'covenant'}`, expected:'Classified current', actual:c.current || 'not recorded',
      detail:`Breach makes the borrowing repayable on demand (${c.consequence}); it is not recorded as classified current (FRS 1 paras 74–75). Consider classification and the going concern implication.` })) },
  { id:'EX-GC-04', scope:'population', label:'Facility maturing within the assessment period with no written renewal', basis:'GC3',
    fn:(recs, cfg, eng, d) => d.facilities.filter(f => f.ex04).map(f => ({ key:f.name || ('Facility ' + f.i), expected:'Renewal confirmed in writing', actual:f.renewal || 'not recorded', difference:f.limit,
      detail:`Matures ${f.maturity ? Core.fmtDate(f.maturity) : 'within the period'} — ${f.monthsToMaturity} month(s) from the ${f.basisDate}. Evidence: ${f.evidence || 'none'}.` })) },
  { id:'EX-GC-05', scope:'population', label:'Reliance on uncommitted funding outside management\'s control', basis:'GC4',
    fn:(recs, cfg, eng, d) => d.reliance.exceeded && { key:'plans', expected:d.reliance.limit, actual:d.reliance.total, difference:r2(d.reliance.total - d.reliance.limit),
      detail:`Uncommitted or outside-control inflows of ${d.reliance.total.toFixed(2)} against a limit of ${d.reliance.limitPct}% of minimum gross liquidity headroom (${d.reliance.minGrossHeadroom.toFixed(2)}). Forecast carries ${d.reliance.forecastUncommitted.toFixed(2)} of uncommitted inflow lines.` } },
  { id:'EX-GC-06', scope:'population', label:'Mitigating plan included with no supporting evidence', basis:'GC4',
    fn:(recs, cfg, eng, d) => d.plans.filter(p => p.noEvidence).map(p => ({ key:p.name || ('Plan ' + p.i), actual:p.evidence || 'none', difference:p.cash,
      detail:`${p.status || 'Status not recorded'}; ${p.committed || 'commitment not recorded'}. Obtain evidence of feasibility and of management's intent and ability (SSA 570 para 16(b)).` })) },
  { id:'EX-GC-07', scope:'population', label:'Negative gross liquidity before mitigating actions', basis:'GC1',
    fn:(recs, cfg, eng, d) => d.forecast.negGross.length > 0 && { key:'forecast', expected:0, actual:d.forecast.minGross.grossLiq, difference:d.forecast.minGross.grossLiq,
      detail:`Gross liquidity negative in ${d.forecast.negGross.length} of ${d.forecast.N} months, first in ${d.forecast.months[d.forecast.firstNegGross].label}; minimum ${d.forecast.minGross.grossLiq.toFixed(2)} in ${d.forecast.minGross.label}. Rescued only by uncommitted inflows of ${d.forecast.totals.uncommitted.toFixed(2)}.` } },
  { id:'EX-GC-08', scope:'population', label:'No downside or reverse stress test prepared by management', basis:'GC5', severity:'above-trivial',
    fn:(recs, cfg, eng, d) => d.stress.sensitivityPrepared === 'N' && { key:'forecast', expected:'Downside scenario and reverse stress test', actual:'Single scenario',
      detail:`Management's assessment rests on one scenario. The auditor's reverse stress test shows liquidity ${d.stress.alreadyExhausted ? 'is exhausted in the base case' : d.stress.beReceipts != null ? 'is exhausted by a ' + (d.stress.beReceipts * 100).toFixed(1) + '% shortfall in receipts' : 'survives a total loss of receipts'}.` } },
  { id:'EX-GC-09', scope:'population', label:'Forecast opening cash does not agree to audited cash', basis:'GC1',
    fn:(recs, cfg, eng, d) => d.forecast.openingDiff != null && Math.abs(d.forecast.openingDiff) > d.tol && { key:'forecast', expected:d.forecast.auditedCash, actual:d.forecast.clientOpening, difference:d.forecast.openingDiff,
      detail:'Opening cash per the forecast differs from cash and cash equivalents per the audited trial balance. The forecast does not start from audited figures.' } },
  { id:'EX-GC-11', scope:'population', label:'Material uncertainty concluded but disclosure inadequate', basis:'GC6', severity:'above-trivial',
    fn:(recs, cfg, eng, d) => d.reporting.materialUncertainty === 'Y' && (d.reporting.disclosureAdequate === 'N' || d.reporting.disclosureGaps.length > 0) &&
      { key:'disclosure', expected:'Events, plans and the material uncertainty statement disclosed', actual: d.reporting.disclosureAdequate === 'N' ? 'Disclosure concluded inadequate' : 'Checklist gaps: ' + d.reporting.disclosureGaps.map(x => x.id).join(', '),
        detail:'ISA 570 para 23: where adequate disclosure is not made, express a qualified or adverse opinion and state in the basis section that a material uncertainty exists.' } },
  { id:'EX-GC-13', scope:'population', label:'Conclusions entered are inconsistent with the disclosure checklist', basis:'GC6', severity:'informational',
    fn:(recs, cfg, eng, d) => d.reporting.inconsistent && { key:'reporting', expected:'Disclosure adequate = N', actual:'Disclosure adequate = Y with checklist items answered N',
      detail:'The disclosure adequacy conclusion does not match the checklist answers. Resolve before the opinion type is relied on.' } },
  { id:'EX-GC-20', label:'Forecast line does not cast to the total shown', basis:'GC1', severity:'informational',
    fn:(r, cfg) => r.__kind !== 'Summary line (excluded)' && r.__totalDiff != null && Math.abs(r.__totalDiff) > (Number(cfg.castTol) || 0.01) &&
      { expected:r.__total, actual:r.total, difference:r.__totalDiff, cell:r['__cell_total'] } },
];

/* ============================================================== PAGES */
const kindChip = v => v === 'Uncommitted mitigating action' ? 'bad' : v === 'Committed mitigating action' ? 'info' : v === 'Summary line (excluded)' ? 'grey' : v === 'Operating' ? 'ok' : 'warn';
const fmtM = (ctx, v) => v == null ? '' : ctx.money(v);

const pages = [
  { id:'source',  ref:'GC.0',  title:'Source data',     kind:'source' },
  { id:'cleaned', ref:'GC.0a', title:'Cleaned listing', kind:'cleaned' },
  { id:'mapping', ref:'GC.0b', title:'Column mapping',  kind:'mapping' },

  /* ------------------------------------------------------------ GC */
  { id:'indicators', ref:'GC', title:'Indicator register (gross)',
    objective:'To identify, before considering mitigating actions, the events or conditions that may cast significant doubt on the entity\'s ability to continue as a going concern (SSA 570 paras 10–11, A3).',
    procedures:['Computed the financial indicators from the audited trial balance figures entered, from the forecast (GC1), the covenant table (GC2), the facility profile (GC3) and management\'s plans (GC4), rather than accepting management\'s answers.',
                'Enquired of management about the operating and other conditions in SSA 570 para A3 and recorded the responses and evidence.',
                'Concluded on the gross position before mitigation as the starting point for evaluating management\'s assessment.'],
    flag:(st, d) => d.indicators.anyPresent,
    render(st, ctx) {
      const d = ctx.d, I = d.indicators;
      const rows = I.computed.map(c => ({ __key:c.id, id:c.id, label:c.label, how:c.how, figure:c.figure, computed: c.present == null ? 'No data' : c.present ? 'Present' : 'Not present',
        effective: c.effective == null ? '' : c.effective ? 'Present' : 'Not present', __cls: c.effective ? 'yes' : '' }));
      return [
        { type:'note', html:'Financial indicators are <b>computed</b> from the audited figures entered below and from the other working papers in this file. The auditor may override a computed result with a reason; operating and other conditions are inquiry-based and answered in the checklist.' },
        { type:'controls', items:[
          { key:'tbTotalAssets', label:'Total assets per audited TB', kind:'number' }, { key:'tbTotalLiabilities', label:'Total liabilities per audited TB', kind:'number' },
          { key:'tbCurrentAssets', label:'Current assets', kind:'number' }, { key:'tbCurrentLiabilities', label:'Current liabilities', kind:'number' },
          { key:'tbPbtCY', label:'Profit before tax — current year', kind:'number' }, { key:'tbPbtPY', label:'Profit before tax — prior year', kind:'number' },
          { key:'tbOperatingCF', label:'Operating cash flow for the year', kind:'number', help:'From the cash flow statement or the cash flow analytics in the CASH file.' } ] },
        { type:'stats', items:[
          { label:'Computed indicators present', value:`${I.presentComputed} of ${I.computed.length}`, cls: I.presentComputed ? 'bad' : 'ok' },
          { label:'Inquiry indicators present', value:`${I.presentInquiry} of ${I.inquiry.length}`, cls: I.presentInquiry ? 'bad' : 'ok' },
          { label:'Not yet assessed', value:I.notAssessed, cls: I.notAssessed ? 'warn' : 'ok' },
          { label:'Gross conclusion', value: I.anyPresent ? 'Events or conditions identified — evaluate management\'s assessment (para 16)' : I.notAssessed ? 'Incomplete' : 'No indicators identified', cls: I.anyPresent ? 'bad' : I.notAssessed ? 'warn' : 'ok' } ] },
        { type:'table', title:'Financial indicators — computed', columns:[
          { key:'id', label:'Ref' }, { key:'label', label:'Indicator' }, { key:'how', label:'Computed as', wrap:true }, { key:'figure', label:'Figure', wrap:true },
          { key:'computed', label:'Computed', type:'chip', chipClass:v => v === 'Present' ? 'bad' : v === 'No data' ? 'grey' : 'ok' },
          { key:'indOverride', label:'Auditor override (Y/N)', input:'select', options:yn },
          { key:'effective', label:'Concluded', type:'chip', chipClass:v => v === 'Present' ? 'bad' : v ? 'ok' : 'grey' },
          { key:'indComment', label:'Reason / procedure performed', input:'text', wide:true } ], rows,
          footnote:'C5–C8 are derived from the auditor\'s entries on GC1–GC4 and update as those working papers are completed.' },
        { type:'heading', text:'Operating and other conditions — by inquiry (SSA 570 para A3)' },
        { type:'checklist', store:'gcIndicators', items: INQUIRY_INDICATORS.map(it => ({ id:it.id, text:`[${it.group}] ${it.text}` })), answers:['Y', 'N', 'n/a'] },
      ];
    } },

  /* ----------------------------------------------------------- GC1 */
  { id:'forecast', ref:'GC1', title:'Cash flow forecast analysis',
    objective:'To evaluate management\'s cash flow forecast: the period it covers against the twelve-month minimum, whether it starts from audited cash, and the liquidity position each month before and after uncommitted mitigating inflows.',
    procedures:['Computed the months covered from the reporting date and from the date of approval of the financial statements and compared each to the twelve-month requirement.',
                'Agreed the opening cash in the forecast to cash and cash equivalents per the audited trial balance.',
                'Classified every forecast line as operating, debt service, capital expenditure, committed or uncommitted mitigating action, and recomputed closing cash and liquidity each month on a gross basis (excluding uncommitted inflows) and a mitigated basis.',
                'Compared the recomputed closing cash to the client\'s closing cash line and investigated differences.'],
    flag:(st, d) => d.period.deficient || d.forecast.negGross.length > 0 || (d.forecast.openingDiff != null && Math.abs(d.forecast.openingDiff) > d.tol),
    render(st, ctx) {
      const d = ctx.d, F = d.forecast, P = d.period, money = ctx.money;
      const mCols = F.months.map(m => ({ key:'m' + (m.i + 1), label:m.label, type:'num', sum:true }));
      const lineRows = ctx.recs.map(r => ({ __rec:r, line:r.line, kindAuto:r.__kindAuto, ...Object.fromEntries(F.months.map(m => ['m' + (m.i + 1), r.__vals[m.i]])), total:r.__total, clientTotal:r.total, totalDiff:r.__totalDiff,
        __cls: r.__kind === 'Uncommitted mitigating action' ? 'flag' : '' }));
      const headings = F.months.map(m => st.mapping?.['m' + (m.i + 1)]?.heading).filter(Boolean);
      const firstHeading = headings[0] ? parseMonthLabel(headings[0]) : null;
      const startMismatch = firstHeading && (firstHeading.y !== F.start.y || firstHeading.m0 !== F.start.m0);
      const monthRows = F.monthly.map(m => ({ __key:'mo' + m.i, ...m, __cls: m.grossLiq < 0 ? 'flag' : '' }));
      return [
        { type:'controls', items:[
          { key:'approvalDate', label:'Date financial statements approved (or expected)', kind:'text', help:'dd/mm/yyyy or yyyy-mm-dd. Drives the months-from-approval test and the facility maturity profile.' },
          { key:'periodBasis', label:'Assessment period basis', kind:'select', options:[['2024', '2024 revised standard — 12 months from the approval date'], ['2022', 'Earlier reading — 12 months from the reporting date']] },
          { key:'forecastStart', label:'First forecast month (blank = month after the reporting date)', kind:'text', help: headings.length ? `Client headings: ${headings[0]} … ${headings[headings.length - 1]}` : '' },
          { key:'auditedCash', label:'Cash and cash equivalents per audited TB', kind:'number' },
          { key:'includeHeadroom', label:'Count undrawn committed facilities in liquidity', kind:'check' },
          { key:'undrawnCommitted', label:'Undrawn committed facility (if no headroom line in the forecast)', kind:'number' } ] },
        startMismatch ? { type:'note', tone:'warn', html:`The first month heading in the client\'s file reads <b>${Core.escapeHTML(headings[0])}</b> but the analysis assumes <b>${Core.escapeHTML(F.months[0]?.label)}</b>. Enter the first forecast month above if the forecast does not start the month after the reporting date.` } : null,
        { type:'stats', items:[
          { label:'Months in the forecast', value:F.N },
          { label:'Months from reporting date', value: P.monthsFromReporting ?? '', cls: P.deficient2022 ? 'bad' : 'ok' },
          { label:'Months from approval date', value: P.monthsFromApproval ?? '— enter approval date —', cls: P.monthsFromApproval == null ? 'warn' : P.deficient2024 ? 'bad' : 'ok' },
          { label:`Requirement (${P.basis} basis)`, value: P.monthsSelected == null ? 'Not assessable' : P.deficient ? `Deficient — ${P.shortfall} month(s) short; extend to ${P.extensionTo || ''}` : 'Met', cls: P.monthsSelected == null ? 'warn' : P.deficient ? 'bad' : 'ok' },
          { label:'Opening cash per forecast', value: fmtM(ctx, F.clientOpening) },
          { label:'Cash per audited TB', value: F.auditedCash == null ? '— enter —' : money(F.auditedCash) },
          { label:'Difference', value: F.openingDiff == null ? '' : money(F.openingDiff), cls: F.openingDiff == null ? '' : Math.abs(F.openingDiff) > d.tol ? 'bad' : 'ok' },
          { label:'Minimum gross liquidity', value: F.minGross ? `${money(F.minGross.grossLiq)} · ${F.minGross.label}` : '', cls: F.minGross && F.minGross.grossLiq < 0 ? 'bad' : 'ok' },
          { label:'Minimum mitigated liquidity', value: F.minMit ? `${money(F.minMit.mitLiq)} · ${F.minMit.label}` : '', cls: F.minMit && F.minMit.mitLiq < 0 ? 'bad' : 'ok' },
          { label:'Uncommitted inflows in the forecast', value: money(F.totals.uncommitted), cls: F.totals.uncommitted > 0 ? 'warn' : 'ok' },
          { label:'Closing cash: client vs recomputed', value: F.closingDiff == null ? 'No closing line' : money(F.closingDiff), cls: F.closingDiff == null ? 'warn' : Math.abs(F.closingDiff) > d.tol ? 'bad' : 'ok' } ] },
        { type:'note', tone: P.deficient2024 && !P.deficient2022 ? 'warn' : 'info',
          html: P.monthsFromApproval == null ? 'Enter the approval date to test the period on the 2024 basis. The revised standard measures the twelve months from the date the financial statements are approved.'
            : P.deficient2024 && !P.deficient2022 ? `<b>Compliant on the old reading, deficient on the 2024 basis.</b> The forecast covers ${P.monthsFromReporting} months from the reporting date but only ${P.monthsFromApproval} from approval. Request an extension to ${P.extensionTo}.`
            : P.deficient ? `<b>The assessment period is too short</b> on the ${P.basis} basis. Raised as EX-GC-01.` : 'The assessment period meets the twelve-month requirement on the selected basis.' },
        { type:'table', title:'Forecast lines — classification (auditor may override)', columns:[
          { key:'line', label:'Forecast line', wrap:true },
          { key:'kindAuto', label:'Suggested', type:'chip', chipClass:kindChip },
          { key:'kind', label:'Classification', input:'select', options:KINDS },
          ...mCols, { key:'total', label:'Total recomputed', type:'num', sum:true }, { key:'clientTotal', label:'Total per client', type:'num' }, { key:'totalDiff', label:'Difference', type:'num', flag:v => v != null && Math.abs(v) > d.tol },
          { key:'evidence', label:'Basis / evidence for classification', input:'text', wide:true } ], rows: lineRows, maxHeight:'60vh',
          footnote:'Summary lines (net cash flow, opening and closing cash, headroom, total liquidity) are recognised and excluded from the flows; they are used to prove the client\'s arithmetic. Lines painted red are uncommitted mitigating inflows.' },
        { type:'table', title:'Monthly liquidity — gross (before uncommitted inflows) and mitigated', columns:[
          { key:'label', label:'Month' },
          { key:'receipts', label:'Operating receipts', type:'num', sum:true }, { key:'payments', label:'Operating payments', type:'num', sum:true },
          { key:'debt', label:'Debt service', type:'num', sum:true }, { key:'capex', label:'Capital expenditure', type:'num', sum:true }, { key:'committed', label:'Committed actions', type:'num', sum:true },
          { key:'grossFlow', label:'Gross net flow', type:'num', sum:true }, { key:'grossCash', label:'Gross closing cash', type:'num', flag:v => v < 0 },
          { key:'headroom', label:'Undrawn facility', type:'num' }, { key:'grossLiq', label:'Gross liquidity', type:'num', emphasis:true, flag:v => v < 0 },
          { key:'uncommitted', label:'Uncommitted inflows', type:'num', sum:true }, { key:'mitCash', label:'Mitigated closing cash', type:'num', flag:v => v < 0 }, { key:'mitLiq', label:'Mitigated liquidity', type:'num', emphasis:true, flag:v => v < 0 },
          { key:'clientClosing', label:'Closing cash per client', type:'num' }, { key:'closingDiff', label:'Difference', type:'num', flag:v => v != null && Math.abs(v) > d.tol } ], rows: monthRows,
          footnote:`Gross liquidity = opening cash + operating, committed, debt service and capital flows + undrawn facility. Mitigated liquidity adds the uncommitted inflows. Months with negative gross liquidity are painted red (EX-GC-07).` },
        F.lineCastBreaks.length ? { type:'note', tone:'warn', html:`${F.lineCastBreaks.length} forecast line(s) do not cast to the total column shown by the client (EX-GC-20).` } : null,
      ].filter(Boolean);
    } },

  /* ----------------------------------------------------------- GC2 */
  { id:'covenants', ref:'GC2', title:'Covenant compliance',
    objective:'To determine whether the entity complies with its borrowing covenants at the reporting date and is forecast to comply at each test date within the assessment period, and the consequence of any breach.',
    procedures:['Listed every covenant from the facility agreements with its threshold, test frequency and consequence of breach.',
                'Recomputed the actual position at the year end from the audited figures and the forecast position at the next test date from the forecast, and tested each against its threshold.',
                'Where a forecast breach makes the borrowing repayable on demand, considered the classification of the borrowing (FRS 1 paras 74–75) and the going concern implication.'],
    flag:(st, d) => d.covenants.some(c => c.breachForecast || c.breachActual),
    render(st, ctx) {
      const d = ctx.d;
      const n = Math.max(0, Math.min(20, Math.round(Number(ctx.cfg.covenantRows) || 0)));
      const rows = [];
      for (let i = 1; i <= n; i++) {
        const c = d.covenants.find(x => x.i === i);
        rows.push({ __key:'c' + i, n:i, actualStatus: c ? (c.actualOK == null ? '' : c.actualOK ? 'Compliant' : 'Breach') : '', forecastStatus: c ? (c.forecastOK == null ? '' : c.forecastOK ? 'Compliant' : 'Breach') : '',
          headroom: c ? c.headroom : null, ex03: c ? (c.ex03 ? 'On demand — not current' : c.onDemand && c.breachForecast ? 'On demand — classified current' : '') : '', __cls: c?.breachForecast ? 'flag' : '' });
      }
      return [
        { type:'controls', items:[{ key:'covenantRows', label:'Covenant lines', kind:'number' }] },
        { type:'table', title:'Covenants per the facility agreements', columns:[
          { key:'n', label:'#', type:'int' },
          { key:'covFacility', label:'Facility', input:'text', wide:true }, { key:'covName', label:'Covenant', input:'text', wide:true },
          { key:'covOp', label:'Test', input:'select', options:COVENANT_OPS }, { key:'covThreshold', label:'Threshold', input:'number' }, { key:'covFreq', label:'Measured', input:'text' },
          { key:'covActual', label:'Actual at year end (recomputed)', input:'number' }, { key:'actualStatus', label:'At year end', type:'chip', chipClass:v => v === 'Breach' ? 'bad' : 'ok' },
          { key:'covForecast', label:'Forecast at next test date', input:'number' }, { key:'forecastStatus', label:'Forecast', type:'chip', chipClass:v => v === 'Breach' ? 'bad' : 'ok' },
          { key:'headroom', label:'Headroom to threshold', type:'num', dp:2, flag:v => v != null && v < 0 },
          { key:'covConsequence', label:'Consequence of breach', input:'select', options:CONSEQUENCES },
          { key:'covCurrent', label:'Borrowing classified current (Y/N)', input:'select', options:yn },
          { key:'ex03', label:'Classification', type:'chip', chipClass:v => /not current/.test(v) ? 'bad' : v ? 'warn' : 'grey' },
          { key:'covComment', label:'Comment / waiver obtained', input:'text', wide:true } ], rows,
          footnote:'Enter ratios as decimals (1.50 for 1.50x) and monetary covenants as amounts. Actual and forecast figures are recomputed by the auditor from the audited figures and the forecast, not accepted from the client. Forecast breaches are raised as EX-GC-02; breaches that make the borrowing repayable on demand where it is not classified current as EX-GC-03.' },
        { type:'stats', items:[
          { label:'Covenants', value:d.covenants.length }, { label:'Breached at year end', value:d.covenants.filter(c => c.breachActual).length, cls: d.covenants.some(c => c.breachActual) ? 'bad' : 'ok' },
          { label:'Forecast to breach', value:d.covenants.filter(c => c.breachForecast).length, cls: d.covenants.some(c => c.breachForecast) ? 'bad' : 'ok' },
          { label:'Repayable on demand if breached', value:d.covenants.filter(c => c.breachForecast && c.onDemand).length, cls: d.covenants.some(c => c.ex03) ? 'bad' : 'ok' } ] },
      ];
    } },

  /* ----------------------------------------------------------- GC3 */
  { id:'facilities', ref:'GC3', title:'Facility maturity profile',
    objective:'To establish the borrowing facilities available, their drawn and undrawn amounts, when each matures or falls for review within the assessment period, and whether renewal is confirmed in writing.',
    procedures:['Listed every facility from the bank confirmations and facility letters with limit, amount drawn and maturity or next review date.',
                'Computed the months to maturity from the approval date and identified facilities maturing within the assessment period.',
                'Inspected written renewal confirmations; where none was obtained, recorded the evidence available and raised the exception.'],
    flag:(st, d) => d.facilities.some(f => f.ex04),
    render(st, ctx) {
      const d = ctx.d, money = ctx.money;
      const n = Math.max(0, Math.min(20, Math.round(Number(ctx.cfg.facilityRows) || 0)));
      const rows = [];
      for (let i = 1; i <= n; i++) {
        const f = d.facilities.find(x => x.i === i);
        rows.push({ __key:'f' + i, n:i, undrawn: f ? f.undrawn : null, months: f ? f.monthsToMaturity : null, monthsDiff: f ? f.monthsDiff : null,
          within: f ? (f.maturity ? (f.withinPeriod ? 'Within period' : 'After period') : '') : '', status: f ? (f.ex04 ? 'No written renewal' : f.withinPeriod ? 'Renewal confirmed' : '') : '', __cls: f?.ex04 ? 'flag' : '' });
      }
      return [
        { type:'controls', items:[{ key:'facilityRows', label:'Facility lines', kind:'number' }, { key:'approvalDate', label:'Approval date (shared with GC1)', kind:'text' }] },
        { type:'table', title:'Facilities', columns:[
          { key:'n', label:'#', type:'int' },
          { key:'facName', label:'Facility', input:'text', wide:true }, { key:'facLender', label:'Lender', input:'text' },
          { key:'facLimit', label:'Limit', input:'number' }, { key:'facDrawn', label:'Drawn at year end', input:'number' }, { key:'undrawn', label:'Undrawn', type:'num', sum:true },
          { key:'facMaturity', label:'Maturity / next review (dd/mm/yyyy)', input:'text' },
          { key:'facClientMonths', label:'Months to maturity per client', input:'number' }, { key:'months', label:'Months to maturity (recomputed)', type:'int' }, { key:'monthsDiff', label:'Difference', type:'int' },
          { key:'within', label:'Assessment period', type:'chip', chipClass:v => v === 'Within period' ? 'warn' : 'grey' },
          { key:'facRenewal', label:'Renewal confirmed in writing', input:'select', options:['Y', 'N', 'n/a'] },
          { key:'status', label:'Status', type:'chip', chipClass:v => v === 'No written renewal' ? 'bad' : 'ok' },
          { key:'facEvidence', label:'Evidence inspected', input:'text', wide:true } ], rows,
          footnote:`Months to maturity are counted from the ${d.period.approval ? 'approval date' : 'reporting date (enter the approval date on GC1 to use it)'}. A facility maturing on or before ${d.period.periodEnd ? Core.fmtDate(d.period.periodEnd) : 'the end of the forecast'} without written renewal is raised as EX-GC-04.` },
        { type:'stats', items:[
          { label:'Total limits', value:money(d.facTotals.limit) }, { label:'Drawn', value:money(d.facTotals.drawn) }, { label:'Undrawn', value:money(d.facTotals.undrawn) },
          { label:'Undrawn per forecast (month 1)', value: d.forecast.monthly[0] ? money(d.forecast.monthly[0].headroom) : '' },
          { label:'Maturing in period without written renewal', value:d.facilities.filter(f => f.ex04).length, cls: d.facilities.some(f => f.ex04) ? 'bad' : 'ok' },
          { label:'Undrawn on those facilities', value:money(r2(d.facilities.filter(f => f.ex04).reduce((s, f) => s + (f.undrawn || 0), 0))) } ] },
      ];
    } },

  /* ----------------------------------------------------------- GC4 */
  { id:'plans', ref:'GC4', title:'Management\'s plans',
    objective:'To evaluate management\'s plans for future actions: whether each is feasible, whether management has the intent and ability to carry it out, whether its outcome is likely to improve the situation, and whether the forecast relies on actions outside management\'s control (SSA 570 para 16(b)).',
    procedures:['Listed every plan reflected in the forecast with its cash effect, the timing assumed, its status and whether it is committed.',
                'Inspected the evidence supporting each plan (board minutes, signed agreements, term sheets, correspondence) and recorded whether the plan is within management\'s control.',
                'Totalled the inflows that are uncommitted or outside management\'s control and compared them to the minimum gross liquidity headroom.'],
    flag:(st, d) => d.reliance.exceeded || d.plans.some(p => p.noEvidence),
    render(st, ctx) {
      const d = ctx.d, money = ctx.money, R = d.reliance;
      const n = Math.max(0, Math.min(30, Math.round(Number(ctx.cfg.planRows) || 0)));
      const rows = [];
      for (let i = 1; i <= n; i++) {
        const p = d.plans.find(x => x.i === i);
        rows.push({ __key:'p' + i, n:i, reliance: p ? (p.reliance ? 'Relied upon, uncommitted' : p.committed ? 'Committed' : '') : '', evidenceStatus: p ? (p.noEvidence ? 'No evidence' : 'Evidence recorded') : '', __cls: p?.reliance ? 'flag' : '' });
      }
      return [
        { type:'controls', items:[{ key:'planRows', label:'Plan lines', kind:'number' }, { key:'relianceLimitPct', label:'Reliance limit — uncommitted funding as % of minimum gross liquidity headroom', kind:'number' }] },
        { type:'table', title:'Plans reflected in the forecast', columns:[
          { key:'n', label:'#', type:'int' },
          { key:'planName', label:'Plan', input:'text', wide:true }, { key:'planCash', label:'Cash effect', input:'number' },
          { key:'planTiming', label:'Timing in forecast', input:'text' }, { key:'planStatus', label:'Status', input:'text', wide:true },
          { key:'planCommitted', label:'Committed / uncommitted', input:'select', options:['Committed', 'Uncommitted'] },
          { key:'planEvidence', label:'Evidence obtained', input:'text', wide:true }, { key:'evidenceStatus', label:'', type:'chip', chipClass:v => v === 'No evidence' ? 'bad' : 'ok' },
          { key:'planControl', label:'Within management\'s control (Y/N)', input:'select', options:yn },
          { key:'reliance', label:'Reliance', type:'chip', chipClass:v => /uncommitted/.test(v) ? 'bad' : v ? 'ok' : 'grey' },
          { key:'planAssessment', label:'Auditor assessment (feasibility, intent, ability, outcome)', input:'text', wide:true } ], rows,
          footnote:'A plan is treated as relied upon but uncommitted where it is marked uncommitted or outside management\'s control. Plans with no evidence recorded are raised as EX-GC-06.' },
        { type:'stats', items:[
          { label:'Total cash effect of plans', value:money(d.planTotals.all) },
          { label:'Committed and within control', value:money(d.planTotals.committed), cls:'ok' },
          { label:'Uncommitted or outside control', value:money(R.total), cls: R.total > 0 ? 'bad' : 'ok' },
          { label:'Uncommitted inflow lines in the forecast (GC1)', value:money(R.forecastUncommitted) },
          { label:`Reliance limit (${R.limitPct}% of minimum gross headroom ${money(R.minGrossHeadroom)})`, value:money(R.limit) },
          { label:'Reliance test', value: R.exceeded ? 'Exceeded — EX-GC-05' : R.total > 0 ? 'Within limit' : 'No uncommitted reliance', cls: R.exceeded ? 'bad' : 'ok' } ] },
        R.minGrossHeadroom === 0 && R.total > 0 ? { type:'note', tone:'bad', html:`Gross liquidity is exhausted within the period without the uncommitted inflows, so <b>every unit of uncommitted funding is relied upon</b>. That is the shape of a material uncertainty: the forecast survives only if actions outside management's control complete on time.` } : null,
      ].filter(Boolean);
    } },

  /* ----------------------------------------------------------- GC5 */
  { id:'stress', ref:'GC5', title:'Sensitivity and reverse stress test',
    objective:'To determine how much the key forecast assumptions must deteriorate before liquidity is exhausted, and whether management prepared its own downside scenarios.',
    procedures:['Solved by bisection for the uniform shortfall in operating receipts, and separately for the uniform increase in operating payments, at which minimum liquidity within the period reaches nil.',
                'Delayed operating receipts by one, two and three months and recomputed the liquidity position and the months of headroom.',
                'Applied the auditor\'s downside percentage to receipts and reported the resulting minimum liquidity and first negative month.',
                'Recorded whether management prepared any downside or reverse stress-test scenario.'],
    flag:(st, d) => d.stress.sensitivityPrepared === 'N' || d.stress.alreadyExhausted || (d.stress.beReceipts != null && d.stress.beReceipts < 0.10),
    render(st, ctx) {
      const d = ctx.d, S = d.stress, F = d.forecast, money = ctx.money, pct = v => v == null ? '' : (v * 100).toFixed(1) + '%';
      const hm = x => x.firstNeg == null ? `> ${F.N} months (not exhausted)` : `${x.monthsHeadroom} month(s) — negative from ${F.months[x.firstNeg]?.label || ''}`;
      const beRows = [
        { __key:'be1', variation:'Base case (as classified on GC1)', value:'—', min: S.base.min, headroom: hm(S.base) },
        { __key:'be2', variation:'Shortfall in operating receipts that exhausts liquidity', value: S.alreadyExhausted ? 'Exhausted in the base case' : S.beReceipts == null ? 'Not exhausted by a total loss of receipts' : `${pct(S.beReceipts)} · ${money(S.beReceiptsAmt)} over the period`, min: 0, headroom: S.beReceipts != null ? hm(S.beReceipts === 0 ? S.base : { firstNeg: null, monthsHeadroom: F.N }) : '' },
        { __key:'be3', variation:'Increase in operating payments that exhausts liquidity', value: S.alreadyExhausted ? 'Exhausted in the base case' : S.bePayments == null ? 'Not exhausted within +500%' : pct(S.bePayments), min: 0, headroom: '' },
        { __key:'be4', variation:`Downside: receipts ${S.downPct}% lower`, value:`−${S.downPct}%`, min: S.downside ? S.downside.min : null, headroom: S.downside ? hm(S.downside) : '' },
        ...S.delays.map(x => ({ __key:'dl' + x.delay, variation:`Collection delay of ${x.delay} month(s)`, value:`${x.delay} month(s)`, min: x.min, headroom: hm(x) })),
      ];
      return [
        { type:'controls', items:[
          { key:'stressBasis', label:'Liquidity basis for the stress test', kind:'select', options:[['mitigated', 'Mitigated — management\'s forecast including uncommitted inflows'], ['gross', 'Gross — excluding uncommitted inflows']] },
          { key:'downsidePct', label:'Downside scenario: fall in operating receipts (%)', kind:'number' },
          { key:'sensitivityPrepared', label:'Did management prepare a downside or reverse stress-test scenario?', kind:'select', options:[['', '—'], ['Y', 'Y'], ['N', 'N']] } ] },
        { type:'stats', items:[
          { label:'Basis', value: S.basis === 'gross' ? 'Gross liquidity' : 'Mitigated liquidity' },
          { label:'Minimum liquidity — base case', value: S.base.min == null ? '' : money(S.base.min), cls: S.alreadyExhausted ? 'bad' : 'ok' },
          { label:'Break-even receipts shortfall', value: S.alreadyExhausted ? '0% — exhausted' : S.beReceipts == null ? 'None' : pct(S.beReceipts), cls: S.alreadyExhausted || (S.beReceipts != null && S.beReceipts < 0.10) ? 'bad' : S.beReceipts != null && S.beReceipts < 0.20 ? 'warn' : 'ok' },
          { label:'Break-even payments increase', value: S.alreadyExhausted ? '0%' : S.bePayments == null ? 'None' : pct(S.bePayments) },
          { label:'Management scenarios', value: S.sensitivityPrepared === 'Y' ? 'Downside prepared' : S.sensitivityPrepared === 'N' ? 'Single scenario only — EX-GC-08' : 'Not recorded', cls: S.sensitivityPrepared === 'N' ? 'bad' : S.sensitivityPrepared ? 'ok' : 'warn' } ] },
        { type:'table', title:'Reverse stress test and sensitivities', columns:[
          { key:'variation', label:'Variation', wrap:true }, { key:'value', label:'Break-even / applied value' },
          { key:'min', label:'Minimum liquidity', type:'num', flag:v => v != null && v < 0 }, { key:'headroom', label:'Months of headroom', wrap:true },
          { key:'comment', label:'Auditor comment', input:'text', wide:true } ], rows: beRows,
          footnote:'Receipts and payments are the positive and negative operating flows as classified on GC1. The break-even is solved to within 1e-12 by bisection; the delay scenarios shift receipts later and treat receipts falling beyond the horizon as not collected within the period.' },
        { type:'table', title:`Liquidity by month under each scenario (${S.basis})`, columns:[
          { key:'label', label:'Month' }, { key:'base', label:'Base case', type:'num', flag:v => v < 0 }, { key:'down', label:`Receipts −${S.downPct}%`, type:'num', flag:v => v < 0 },
          ...S.delays.map(x => ({ key:'d' + x.delay, label:`Delay ${x.delay}m`, type:'num', flag:v => v < 0 })) ],
          rows: F.months.map(m => ({ label:m.label, base:S.base.series[m.i], down:S.downside ? S.downside.series[m.i] : null, ...Object.fromEntries(S.delays.map(x => ['d' + x.delay, x.series[m.i]])) })) },
      ];
    } },

  /* ----------------------------------------------------------- GC6 */
  { id:'reporting', ref:'GC6', title:'Reporting decision',
    objective:'To record the auditor\'s two conclusions — whether the going concern basis is appropriate and whether a material uncertainty exists — and the disclosure adequacy assessment, and to derive the opinion type and report section that follow (ISA 570 paras 17–24).',
    procedures:['Recorded whether management made (or extended) its assessment when requested.',
                'Concluded on the appropriateness of the going concern basis and on the existence of a material uncertainty, on the evidence in GC to GC5.',
                'Assessed the adequacy of the going concern disclosure against the checklist.',
                'Derived the opinion type from the decision table and checked it for consistency with the conclusions and the checklist.'],
    flag:(st, d) => d.reporting.materialUncertainty === 'Y' || d.reporting.basisAppropriate === 'N' || d.reporting.inconsistent,
    render(st, ctx) {
      const d = ctx.d, R = d.reporting;
      const table = [
        { basis:'Y', mu:'N', disc:'n/a', opinion:'Unmodified', section:'None (consider KAM for a close call)' },
        { basis:'Y', mu:'Y', disc:'Y', opinion:'Unmodified', section:'Material Uncertainty Related to Going Concern' },
        { basis:'Y', mu:'Y', disc:'N', opinion:'Qualified or adverse', section:'Basis for qualified / adverse opinion' },
        { basis:'N', mu:'n/a', disc:'n/a', opinion:'Adverse', section:'Basis for adverse opinion' },
      ].map((x, i) => ({ ...x, __cls: R.path && ((x.basis === R.basisAppropriate && (x.mu === 'n/a' || x.mu === R.materialUncertainty) && (x.disc === 'n/a' || x.disc === R.disclosureAdequate))) ? 'yes' : '' }));
      return [
        { type:'note', tone:'warn', html:'<b>The conclusions on this page are the auditor\'s alone.</b> No AI assistance is offered or permitted in forming or drafting the going concern conclusion, the material uncertainty judgement or the audit report wording; the module only applies the ISA 570 decision table to the answers entered.' },
        { type:'controls', items:[
          { key:'mgmtAssessment', label:'Management made (or extended) its assessment when requested', kind:'select', options:[['', '—'], ['Y', 'Y'], ['N', 'N — unwilling']] },
          { key:'basisAppropriate', label:'Going concern basis of accounting appropriate', kind:'select', options:[['', '—'], ['Y', 'Y'], ['N', 'N']] },
          { key:'materialUncertainty', label:'Material uncertainty exists', kind:'select', options:[['', '—'], ['Y', 'Y'], ['N', 'N']] },
          { key:'disclosureAdequate', label:'Disclosure adequate (where a material uncertainty exists)', kind:'select', options:[['', '—'], ['Y', 'Y'], ['N', 'N']] } ] },
        { type:'stats', items:[
          { label:'Path', value: R.path || 'Incomplete — answer the questions above', cls: R.path ? '' : 'warn' },
          { label:'Opinion type', value: R.opinion || '', cls: /Unmodified with/.test(R.opinion) ? 'warn' : /Adverse|Qualified|disclaimer/.test(R.opinion) ? 'bad' : R.opinion ? 'ok' : '' },
          { label:'Report section', value: R.section || '' },
          { label:'Indicators present (GC)', value: `${d.indicators.presentComputed + d.indicators.presentInquiry}` },
          { label:'Minimum gross liquidity (GC1)', value: d.forecast.minGross ? ctx.money(d.forecast.minGross.grossLiq) : '' },
          { label:'Uncommitted reliance (GC4)', value: ctx.money(d.reliance.total) } ] },
        { type:'table', title:'ISA 570 decision table', columns:[
          { key:'basis', label:'Basis appropriate' }, { key:'mu', label:'Material uncertainty' }, { key:'disc', label:'Disclosure adequate' }, { key:'opinion', label:'Opinion', emphasis:true }, { key:'section', label:'Report section', wrap:true } ], rows: table,
          footnote:'A fifth path applies where management is unwilling to make or extend its assessment: consider the implications for the report, which may include a qualified opinion or a disclaimer (ISA 570 para 24). The highlighted row is the one the answers above select.' },
        { type:'heading', text:'Disclosure adequacy (GC-09) — complete where a material uncertainty exists or the conclusion was a close call' },
        { type:'checklist', store:'gcDisclosure', items: DISCLOSURE_ITEMS, answers:['Y', 'N', 'n/a'] },
        R.inconsistent ? { type:'note', tone:'bad', html:'<b>Inconsistent:</b> disclosure is concluded adequate but the checklist marks a required element as absent (EX-GC-13).' } : null,
        R.disclosureGaps.length && R.disclosureAdequate !== 'Y' ? { type:'note', tone:'bad', html:`The note omits ${R.disclosureGaps.map(x => x.id).join(', ')}. Where a material uncertainty exists and disclosure is inadequate, ISA 570 para 23 requires a qualified or adverse opinion (EX-GC-11).` } : null,
      ].filter(Boolean);
    } },

  { id:'conclusion', ref:'GC.9', title:'Exceptions & conclusion', kind:'conclusion' }
];

return {
  code:'GC', name:'Going Concern', group:'Completion', accepts:'.xlsx,.xlsm,.csv',
  blurb:'The going concern file: gross indicator register, cash flow forecast analysis (period, opening cash, gross versus mitigated liquidity), covenants, facility maturities, management\'s plans, reverse stress test and the ISA 570 reporting decision — from management\'s uploaded forecast.',
  objective:'To obtain sufficient appropriate audit evidence about the appropriateness of management\'s use of the going concern basis of accounting, to conclude whether a material uncertainty exists, and to determine the implications for the auditor\'s report (SSA 570 para 9).',
  fields, tests, compute, pages, defaultConfig, STANDARD_COLUMNS, KINDS, INQUIRY_INDICATORS, DISCLOSURE_ITEMS,
  procedures: pages.flatMap(p => p.procedures || []),
  columns: STANDARD_COLUMNS
  /* no suggestConclusion: the going concern conclusion is never drafted by the module */
};
})();

Modules.register(GCModule);
