/* ==========================================================================
   ar.js -- Trade receivables and expected credit losses, as an auditor
   actually works the section. One uploaded open-item listing feeds:

     L3    Lead schedule                 L3.4  Subsequent receipts
     L3.1  Ageing rebuild                L3.5  ECL — loss-rate derivation
     L3.2  Cut-off                       L3.6  ECL — forward-looking overlay
     L3.3  Circularisation control       L3.7  ECL — provision matrix
                                         L3.8  SICR & credit-impaired watchlist

   The provision matrix is computed, never accepted: observed rates come
   from L3.5, the multiplier from L3.6, individually assessed balances leave
   the collective pool via L3.8. The client's rate is compared to the result
   and never enters the computation (FRS 109 para B5.5.35).
   ========================================================================== */

const ARModule = (() => {
const r2 = n => n == null || isNaN(n) ? null : Math.round(n * 100) / 100;
const days = (a, b) => (a && b) ? Math.round((a - b) / 86400000) : null;
const num = v => (v === null || v === undefined || v === '' || isNaN(Number(v))) ? null : Number(v);
const isoDate = s => { if (!s) return null; if (s instanceof Date) return s; const d = new Date(String(s).slice(0, 10) + 'T00:00:00Z'); return isNaN(d) ? null : d; };
const yes = v => /^(y|yes|true|1|rp|related)/i.test(String(v == null ? '' : v).trim());
const addMonths = (d, m) => { const x = new Date(d.getTime()); x.setUTCMonth(x.getUTCMonth() + m); return x; };

/* Seeded PRNG so a random sample is reproducible from its recorded seed. */
function mulberry32(seed) {
  let a = (seed >>> 0) || 1;
  return () => {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function sampleN(items, n, seed) {
  const rnd = mulberry32(seed);
  const pool = items.slice();
  const out = [];
  while (out.length < n && pool.length) out.push(pool.splice(Math.floor(rnd() * pool.length), 1)[0]);
  return out;
}

/* ---------------------------------------------------------------- fields */
const fields = [
  { key:'cust_code', label:'Customer code', role:'key', type:'text',
    synonyms:['Customer Code','Cust Code','Debtor Code','A/C No','Code','Account No','Customer No','Cust No','Debtor No','客户代码','客户编号'] },
  { key:'cust_name', label:'Customer name', type:'text', required:true,
    synonyms:['Customer','Customer Name','Debtor','Debtor Name','CUSTOMERS','Account Name','Name','Counterparty','Client','客户名称','客户'] },
  { key:'invoice_no', label:'Invoice number', type:'text', required:true, dupKey:true,
    synonyms:['Invoice No','Inv No.','Inv No','Document No','Ref','Invoice Number','Doc No','Reference','Document Number','Invoice','发票号','发票号码','单据号'] },
  { key:'invoice_date', label:'Invoice date', type:'date', required:true,
    synonyms:['Invoice Date','Doc Date','Date','Inv. Date','Inv Date','Trans Date','Transaction Date','Document Date','Posting Date','发票日期','日期'] },
  { key:'due_date', label:'Due date', type:'date',
    synonyms:['Due Date','Date Due','Maturity','Payment Due','Due','Maturity Date','到期日'] },
  { key:'terms', label:'Credit terms (days)', type:'number',
    synonyms:['Terms','Credit Terms','Term','Payment Terms','Days','Credit Days','Terms (Days)','信用期'] },
  { key:'currency', label:'Currency', type:'text',
    synonyms:['Currency','Cur','Curr','CCY','Txn Ccy','Ccy','币种','货币'] },
  { key:'amount_orig', label:'Amount (original currency)', type:'number',
    synonyms:['Amount (Orig)','Foreign Amount','Amount FC','Orig. Amount','Original Amount','FC Amount','Txn Amount','原币金额'] },
  { key:'amount', label:'Amount outstanding (base currency)', type:'number', required:true,
    synonyms:['Amount','Outstanding','Balance','Outstanding Balance','Amount Due','Total','Base Amount','Amount (Base)','Local Amount','金额','余额','本位币金额'] },
  { key:'related', label:'Related party (Y/N)', type:'text',
    synonyms:['Related Party','RP','Intercompany','Related','Related Party (Y/N)','关联方'] },
  { key:'doc_type', label:'Document type', type:'text',
    synonyms:['Type','Doc Type','Document Type','Trans Type','Transaction Type','单据类型'] }
];

const STANDARD_COLUMNS = [
  { key:'cust_code', label:'Code' }, { key:'cust_name', label:'Customer' },
  { key:'invoice_no', label:'Invoice' }, { key:'invoice_date', label:'Invoice date', type:'date', edit:true },
  { key:'due_date', label:'Due date', type:'date', edit:true }, { key:'terms', label:'Terms', type:'num', dp:0, edit:true },
  { key:'currency', label:'Ccy' }, { key:'amount_orig', label:'Amount (orig)', type:'num' },
  { key:'amount', label:'Amount (base)', type:'num', emphasis:true, edit:true },
  { key:'__daysPastDue', label:'Days past due', type:'num', dp:0 }, { key:'__bucketLabel', label:'Bucket' }
];

const SCENARIOS = [
  { key:'base', label:'Base case' }, { key:'upside', label:'Upside' }, { key:'downside', label:'Downside' }
];
const HIST_YEARS = [ { y:3, label:'FY-3' }, { y:2, label:'FY-2' }, { y:1, label:'FY-1' } ];

const defaultConfig = () => ({
  ageBasis: 'due',                 // 'due' | 'invoice_terms' | 'invoice'
  defaultTerms: 30,
  bucketEdges: '30,60,90,180,365',
  longOverdue: 365,
  defaultDays: 90,                 // definition of default (FRS 109 para B5.5.37)
  sicrDays: 30,                    // SICR presumption (para 5.5.11)
  roundSum: 10000,
  nilTermsDays: 30,
  invoicePrefix: '',               // blank = infer the dominant reference prefix
  rareCcyMax: 1,
  castTol: 0.01,
  rateTol: 0.5,                    // percentage points, client rate vs audit rate
  cutoffDays: 14,
  circThreshold: null, circSampleN: 5, circSeed: 20250228,
  subsAll: false,
  tbGross: null, tbAllowance: null, pyGross: null, pyAllowance: null, revenue: null,
  writeOffPolicy: '', histSource: '',
  macroSource: '', overlayDate: '', overlayStaleMonths: 12,
  clientExcludesRP: false,
  watchExtra: ''
});

/* ---------------------------------------------------------------- buckets */
function buildBuckets(edgesStr) {
  const edges = [...new Set(String(edgesStr || '30,60,90,180,365').split(/[,;\s]+/).map(Number).filter(n => n > 0 && isFinite(n)))].sort((a, b) => a - b);
  const out = [{ key:'b_current', label:'Not yet due', from:-1e9, to:0 }];
  let prev = 0;
  for (const e of edges) { out.push({ key:`b_${prev + 1}_${e}`, label:`${prev + 1}–${e} days`, from:prev + 1, to:e }); prev = e; }
  out.push({ key:`b_over_${prev}`, label:`Over ${prev} days`, from:prev + 1, to:1e9 });
  return out;
}

/* ================================================================ COMPUTE */
function compute(recs, cfg, eng) {
  const ye = eng.yearEndDate;
  const pm = eng.materiality?.pm || 0, trivial = eng.materiality?.trivial || 0;
  const buckets = buildBuckets(cfg.bucketEdges);
  const defaultTerms = num(cfg.defaultTerms) ?? 30;
  const defaultDays = num(cfg.defaultDays) ?? 90;
  const sicrDays = num(cfg.sicrDays) ?? 30;
  const longOverdue = num(cfg.longOverdue) ?? 365;
  const cutoffDays = num(cfg.cutoffDays) ?? 14;
  const castTol = num(cfg.castTol) ?? 0.01;
  /* DQ: a row carrying an amount but no counterparty, reference or date is not an open
     item — typically the client's control-account total left under the listing. Held out. */
  for (const r of recs) r.__orphan = !r.cust_name && !r.cust_code && !r.invoice_no && !r.invoice_date && !r.due_date && r.amount != null;
  const orphans = recs.filter(r => r.__orphan && !r.__excluded);
  const live = recs.filter(r => !r.__excluded && !r.__orphan);

  /* reference pattern: the dominant alpha prefix is "an invoice" */
  const prefixOf = s => { const m = String(s || '').trim().match(/^([A-Za-z]+)/); return m ? m[1].toUpperCase() : ''; };
  let invPrefix = String(cfg.invoicePrefix || '').trim().toUpperCase();
  if (!invPrefix) {
    const cnt = {};
    live.forEach(r => { const p = prefixOf(r.invoice_no); if (p) cnt[p] = (cnt[p] || 0) + 1; });
    invPrefix = (Object.entries(cnt).sort((a, b) => b[1] - a[1])[0] || [''])[0];
  }
  /* currency profile */
  const ccy = {};
  live.forEach(r => { const c = String(r.currency || '').trim().toUpperCase() || '(blank)'; const x = ccy[c] || (ccy[c] = { currency:c, count:0, orig:0, base:0 }); x.count++; x.orig += r.amount_orig != null ? r.amount_orig : (r.amount || 0); x.base += r.amount || 0; });
  const currencies = Object.values(ccy).sort((a, b) => b.base - a.base);
  /* duplicates on the invoice reference */
  const seenInv = new Map();

  const byBucket = {};
  buckets.forEach(b => byBucket[b.key] = { key:b.key, label:b.label, count:0, gross:0, rp:0, individual:0 });
  const custs = {};
  let total = 0, credits = 0, creditCount = 0, nilCount = 0;

  for (const r of recs) {
    const name = String(r.cust_name || '').trim();
    r.__custKey = Core.keyify(name) || Core.keyify(r.cust_code || '') || ('row' + r.__srcRow);
    r.__custLabel = name || (r.cust_code ? String(r.cust_code) : '(no counterparty)');
    r.__displayKey = r.__custLabel + ' / ' + (r.invoice_no || ('row ' + r.__srcRow));
    const terms = r.terms != null ? r.terms : defaultTerms;
    let ageFrom = null, derived = false;
    if (cfg.ageBasis === 'invoice') ageFrom = r.invoice_date;
    else if (cfg.ageBasis === 'invoice_terms') { if (r.invoice_date) { ageFrom = new Date(r.invoice_date.getTime() + terms * 86400000); derived = true; } }
    else { ageFrom = r.due_date; if (!ageFrom && r.invoice_date) { ageFrom = new Date(r.invoice_date.getTime() + terms * 86400000); derived = true; } }
    r.__ageFrom = ageFrom; r.__dueDerived = derived;
    r.__daysPastDue = (ageFrom && ye) ? days(ye, ageFrom) : null;
    r.__daysOutstanding = (r.invoice_date && ye) ? days(ye, r.invoice_date) : null;
    const od = r.__daysPastDue;
    const b = od == null ? null : buckets.find(x => od >= x.from && od <= x.to);
    r.__bucket = b ? b.key : null; r.__bucketLabel = b ? b.label : 'Not aged';
    r.__rp = yes(r.related) || cfg['rp:' + r.__custKey] === 'Y';
    r.__nonInvoiceRef = !!invPrefix && !!r.invoice_no && prefixOf(r.invoice_no) !== invPrefix;
    r.__postYE = !!(r.invoice_date && ye && r.invoice_date > ye);
    r.__nearYE = !!(r.invoice_date && ye && !r.__postYE && days(ye, r.invoice_date) < cutoffDays);
    r.__dueBeforeInvoice = !!(r.due_date && r.invoice_date && r.due_date < r.invoice_date);
    r.__nilTerms = r.terms != null && r.terms === 0 && (r.amount || 0) > 0.005 &&
      ((r.due_date && r.invoice_date && r.due_date > r.invoice_date) || (r.__daysOutstanding || 0) > (num(cfg.nilTermsDays) ?? 30));
    const cc = String(r.currency || '').trim().toUpperCase();
    r.__rareCcy = !!cc && currencies.length > 1 && (ccy[cc]?.count || 0) <= (num(cfg.rareCcyMax) ?? 1);
    const ik = Core.keyify(r.invoice_no || '');
    r.__dupOf = null;
    if (ik) { if (seenInv.has(ik)) { const f = seenInv.get(ik); r.__dupOf = f.__srcRow; r.__dupSameAmount = Math.abs((f.amount || 0) - (r.amount || 0)) < 0.005; } else seenInv.set(ik, r); }
    r.__roundSum = (() => { const a = Math.abs(r.amount || 0), m = num(cfg.roundSum); return !!(a && m && a % m === 0); })();
    if (r.__excluded || r.__orphan) continue;

    const amt = r.amount || 0;
    total += amt;
    if (amt < -0.005) { credits += amt; creditCount++; }
    if (r.amount != null && Math.abs(amt) < 0.005) nilCount++;
    if (b) { byBucket[b.key].gross += amt; byBucket[b.key].count++; if (r.__rp) byBucket[b.key].rp += amt; }

    const c = custs[r.__custKey] || (custs[r.__custKey] = { key:r.__custKey, label:r.__custLabel, code:r.cust_code || '', currencies:new Set(), count:0, gross:0,
      maxPastDue:null, maxOutstanding:null, overDefault:0, overSicr:0, hasCredit:false, rp:false, buckets:Object.fromEntries(buckets.map(x => [x.key, 0])), recs:[] });
    c.count++; c.gross += amt; c.recs.push(r);
    if (r.currency) c.currencies.add(String(r.currency).trim().toUpperCase());
    if (b) c.buckets[b.key] += amt;
    if (od != null && amt > 0.005) { c.maxPastDue = c.maxPastDue == null ? od : Math.max(c.maxPastDue, od); if (od > defaultDays) c.overDefault += amt; if (od > sicrDays) c.overSicr += amt; }
    if (r.__daysOutstanding != null && amt > 0.005) c.maxOutstanding = c.maxOutstanding == null ? r.__daysOutstanding : Math.max(c.maxOutstanding, r.__daysOutstanding);
    if (amt < -0.005) c.hasCredit = true;
    if (r.__rp) c.rp = true;
  }
  const customers = Object.values(custs).sort((a, b) => b.gross - a.gross);
  for (const c of customers) { c.gross = r2(c.gross); c.overDefault = r2(c.overDefault); c.overSicr = r2(c.overSicr); for (const k of Object.keys(c.buckets)) c.buckets[k] = r2(c.buckets[k]); c.ccy = [...c.currencies].join(', '); }
  const grossPos = customers.filter(c => c.gross > 0.005);

  /* ---- L3 lead ---------------------------------------------------------- */
  const tbGross = num(cfg.tbGross), pyGross = num(cfg.pyGross), tbAllowance = num(cfg.tbAllowance), pyAllowance = num(cfg.pyAllowance), revenue = num(cfg.revenue);
  const top5 = customers.slice(0, 5).map(c => ({ ...c, share: total ? c.gross / total : null }));
  const top5Share = total ? top5.reduce((s, c) => s + c.gross, 0) / total : null;
  const recDays = revenue ? total / revenue * 365 : null;

  /* ---- L3.1 ageing vs client ageing ------------------------------------ */
  let anyClientAging = false;
  const aging = buckets.map(b => {
    const x = byBucket[b.key];
    const client = num(cfg['ca:' + b.key]);
    if (client != null) anyClientAging = true;
    return { key:b.key, label:b.label, count:x.count, gross:r2(x.gross), rp:r2(x.rp), client, diff: client != null ? r2(x.gross - client) : null, share: total ? x.gross / total : null };
  });
  const notAged = live.filter(r => !r.__bucket);
  const clientTotal = anyClientAging ? r2(aging.reduce((s, a) => s + (a.client || 0), 0)) : null;

  /* ---- L3.3 circularisation ------------------------------------------- */
  const threshold = num(cfg.circThreshold) ?? pm;
  const keyItems = grossPos.filter(c => c.gross >= threshold);
  const residual = grossPos.filter(c => c.gross < threshold);
  const n = Math.min(num(cfg.circSampleN) ?? 0, residual.length);
  const seed = num(cfg.circSeed) || 1;
  const sample = sampleN(residual, n, seed);
  const selectedSet = new Set([...keyItems, ...sample].map(c => c.key));
  const selected = [...keyItems, ...sample].map(c => {
    const k = ':' + c.key;
    const conf = num(cfg['c_conf' + k]);
    const row = { c, key:c.key, label:c.label, gross:c.gross, basis: keyItems.includes(c) ? 'Key item' : 'Random',
      sent: cfg['c_sent' + k] || '', reply: cfg['c_reply' + k] || '', conf, diff: conf != null ? r2(conf - c.gross) : null, recon: cfg['c_recon' + k] || '', alt: cfg['c_alt' + k] || '' };
    row.unreconciled = row.diff != null && Math.abs(row.diff) > castTol && row.recon !== 'Y';
    row.confirmed = row.reply === 'Y' && conf != null && !row.unreconciled;
    return row;
  });
  const selValue = r2(selected.reduce((s, x) => s + x.gross, 0));
  const posTotal = r2(grossPos.reduce((s, c) => s + c.gross, 0));
  const circ = { threshold, seed, keyItems, residual, sample, selected, selValue, posTotal,
    coverage: posTotal ? r2(selValue / posTotal * 100) : 0,
    replies: selected.filter(x => x.reply === 'Y').length,
    confirmedValue: r2(selected.filter(x => x.confirmed).reduce((s, x) => s + x.gross, 0)),
    unreconciled: selected.filter(x => x.unreconciled) };

  /* ---- L3.4 subsequent receipts --------------------------------------- */
  const subsPool = cfg.subsAll ? grossPos : grossPos.filter(c => selectedSet.has(c.key) && !selected.find(x => x.key === c.key)?.confirmed);
  const subs = subsPool.map(c => {
    const k = ':' + c.key;
    const amt = num(cfg['s_amt' + k]);
    return { c, key:c.key, label:c.label, gross:c.gross, date: cfg['s_date' + k] || '', amt, ref: cfg['s_ref' + k] || '',
      pct: amt != null && c.gross ? Math.min(1, Math.max(0, amt / c.gross)) : null, outstanding: amt != null ? r2(Math.max(0, c.gross - amt)) : c.gross };
  });
  const subsStats = { value: r2(subs.reduce((s, x) => s + x.gross, 0)), received: r2(subs.reduce((s, x) => s + (x.amt || 0), 0)) };
  subsStats.outstanding = r2(subsStats.value - subsStats.received);

  /* ---- L3.5 loss-rate derivation -------------------------------------- */
  const yearsWithData = new Set();
  const hist = buckets.map(b => {
    const row = { key:b.key, label:b.label, sumG:0, sumW:0, years:0 };
    for (const y of HIST_YEARS) {
      const g = num(cfg[`h_g${y.y}:${b.key}`]), w = num(cfg[`h_w${y.y}:${b.key}`]);
      row['g' + y.y] = g; row['w' + y.y] = w;
      if (g != null) { row.sumG += g; row.sumW += w || 0; row.years++; yearsWithData.add(y.y); }
    }
    row.observed = row.sumG > 0 ? row.sumW / row.sumG : (row.years ? 0 : null);
    return row;
  });
  const histYears = yearsWithData.size;
  const derivationEmpty = histYears === 0;

  /* ---- L3.6 forward-looking overlay ----------------------------------- */
  const scen = SCENARIOS.map(s => ({ key:s.key, label:s.label, w: num(cfg['o_w:' + s.key]), m: num(cfg['o_m:' + s.key]), note: cfg['o_note:' + s.key] || '', src: cfg['o_src:' + s.key] || '' }))
    .map(s => ({ ...s, contrib: (s.w != null && s.m != null) ? s.w * s.m : null }));
  const weighted = scen.filter(s => s.w != null && s.w > 0);
  const sumW = scen.reduce((s, x) => s + (x.w || 0), 0);
  const issues = [];
  if (!weighted.length) issues.push('No scenario carries a weighting');
  else {
    if (Math.abs(sumW - 1) > 0.001) issues.push(`Weightings sum to ${sumW.toFixed(3)}, not 1`);
    if (weighted.length === 1) issues.push('A single scenario carries 100% of the weighting');
    if (weighted.some(s => s.m == null)) issues.push('A weighted scenario has no multiplier');
    else if (weighted.every(s => s.m === 1)) issues.push('Every weighted multiplier is exactly 1');
    if (!weighted.some(s => String(s.note).trim())) issues.push('No macroeconomic indicator recorded against a weighted scenario');
  }
  const weightedMult = (weighted.length && weighted.every(s => s.m != null) && Math.abs(sumW - 1) <= 0.001) ? r2(weighted.reduce((s, x) => s + x.w * x.m, 0) * 10000) / 10000 : null;
  if (weightedMult === 1 && !issues.includes('Every weighted multiplier is exactly 1')) issues.push('Probability-weighted multiplier is exactly 1 — no adjustment results');
  const overlayValid = issues.length === 0;
  const overlayDate = isoDate(cfg.overlayDate);
  const staleMonths = num(cfg.overlayStaleMonths) ?? 12;
  const overlayAgeMonths = (overlayDate && ye) ? Math.round(days(ye, overlayDate) / 30.4375) : null;
  const overlayStale = overlayAgeMonths != null && overlayAgeMonths > staleMonths;
  const macroSource = String(cfg.macroSource || '').trim();
  const macroUnsourced = !macroSource || /management estimate|no external|not documented|internal|none/i.test(macroSource);
  const overlay = { scen, sumW: r2(sumW * 1000) / 1000, weightedMult, issues, valid: overlayValid, date: overlayDate, ageMonths: overlayAgeMonths, stale: overlayStale, macroSource, macroUnsourced, appliedMult: overlayValid ? weightedMult : null };

  /* ---- L3.8 watchlist ------------------------------------------------- */
  const extra = new Set(String(cfg.watchExtra || '').split(/[,;\n]+/).map(s => Core.keyify(s)).filter(Boolean));
  const watch = [];
  for (const c of customers) {
    const k = ':' + c.key;
    const inputs = { ind: cfg['w_ind' + k] || '', sicr: cfg['w_sicr' + k] || '', imp: cfg['w_imp' + k] || '', eclc: num(cfg['w_eclc' + k]), ecla: num(cfg['w_ecla' + k]), basis: cfg['w_basis' + k] || '' };
    const triggers = [];
    if (c.maxPastDue != null && c.maxPastDue > defaultDays) triggers.push(`>${defaultDays} days past due (default presumption)`);
    else if (c.maxPastDue != null && c.maxPastDue > sicrDays) triggers.push(`>${sicrDays} days past due (SICR presumption)`);
    if ((c.maxOutstanding != null && c.maxOutstanding > longOverdue) || (c.maxPastDue != null && c.maxPastDue > longOverdue)) triggers.push('Long outstanding');
    if (c.rp) triggers.push('Related party');
    if (c.hasCredit) triggers.push('Credit balance');
    if (extra.has(c.key)) triggers.push('Added by auditor');
    const anyInput = Object.values(inputs).some(v => v !== '' && v != null);
    if (!triggers.length && !anyInput) continue;
    if (!triggers.length) triggers.push('Auditor input recorded');
    const individual = inputs.sicr === 'Y' || inputs.imp === 'Y';
    const difficulty = !!String(inputs.ind).trim() && !/^(none|nil|no|n\/a|-)/i.test(String(inputs.ind).trim());
    watch.push({ c, key:c.key, label:c.label, rp:c.rp, gross:c.gross, maxPastDue:c.maxPastDue, overDefault:c.overDefault, triggers, ...inputs, individual, difficulty,
      credImpairedPresumed: c.maxPastDue != null && c.maxPastDue > defaultDays, sicrPresumed: c.maxPastDue != null && c.maxPastDue > sicrDays });
  }
  const individualSet = new Set(watch.filter(w => w.individual).map(w => w.key));
  for (const w of watch.filter(w => w.individual)) for (const b of buckets) if (w.c.buckets[b.key] > 0) byBucket[b.key].individual += w.c.buckets[b.key];
  for (const r of live) r.__individual = individualSet.has(r.__custKey);
  const indClient = r2(watch.reduce((s, w) => s + (w.eclc || 0), 0));
  const indAudit = r2(watch.reduce((s, w) => s + (w.ecla || 0), 0));

  /* ---- L3.7 provision matrix ------------------------------------------ */
  const mult = overlay.appliedMult;
  let collClient = 0, collAudit = 0, auditIncomplete = false, anyClientRate = false;
  const matrix = buckets.map(b => {
    const x = byBucket[b.key], h = hist.find(y => y.key === b.key);
    const base = r2(Math.max(0, x.gross - x.individual));
    const clientPct = num(cfg['m_rate:' + b.key]);
    if (clientPct != null) anyClientRate = true;
    const clientRate = clientPct != null ? clientPct / 100 : null;
    const observed = h ? h.observed : null;
    const auditRate = observed == null ? null : observed * (mult ?? 1);
    const eclClient = clientRate != null ? r2(base * clientRate) : null;
    const eclAudit = auditRate != null ? r2(base * auditRate) : null;
    if (eclClient != null) collClient += eclClient;
    if (eclAudit != null) collAudit += eclAudit; else if (base > 0) auditIncomplete = true;
    return { key:b.key, label:b.label, pastDue: b.key !== 'b_current', count:x.count, gross:r2(x.gross), rp:r2(x.rp), individual:r2(x.individual), base, clientPct, clientRate, observed, mult, auditRate,
      eclClient, eclAudit, diff: (eclClient != null && eclAudit != null) ? r2(eclAudit - eclClient) : null,
      rateGap: (clientRate != null && auditRate != null) ? (auditRate - clientRate) * 100 : null };
  });
  collClient = r2(collClient); collAudit = auditIncomplete ? null : r2(collAudit);
  const totalClient = anyClientRate ? r2(collClient + indClient) : null;
  const totalAudit = collAudit != null ? r2(collAudit + indAudit) : null;
  const allowanceDiff = (totalAudit != null && tbAllowance != null) ? r2(totalAudit - tbAllowance) : null;
  const rpGross = r2(buckets.reduce((s, b) => s + byBucket[b.key].rp, 0));
  for (const r of live) { const m = matrix.find(x => x.key === r.__bucket); r.__auditRate = m && !r.__individual ? m.auditRate : null; r.__eclAudit = r.__auditRate != null ? r2((r.amount || 0) * r.__auditRate) : null; }

  const lead = [
    { line:'Trade receivables — gross', listing:r2(total), tb:tbGross, diff: tbGross != null ? r2(total - tbGross) : null, py:pyGross, variance: pyGross != null ? r2(total - pyGross) : null, pct: pyGross ? (total - pyGross) / Math.abs(pyGross) : null },
    { line:'Loss allowance (per audit, L3.7)', listing:totalAudit, tb:tbAllowance, diff: (totalAudit != null && tbAllowance != null) ? r2(totalAudit - tbAllowance) : null, py:pyAllowance, variance: (totalAudit != null && pyAllowance != null) ? r2(totalAudit - pyAllowance) : null, pct: (totalAudit != null && pyAllowance) ? (totalAudit - pyAllowance) / Math.abs(pyAllowance) : null },
    { line:'Trade receivables — net', listing: totalAudit != null ? r2(total - totalAudit) : null, tb: (tbGross != null && tbAllowance != null) ? r2(tbGross - tbAllowance) : null,
      diff: (totalAudit != null && tbGross != null && tbAllowance != null) ? r2((total - totalAudit) - (tbGross - tbAllowance)) : null,
      py: (pyGross != null && pyAllowance != null) ? r2(pyGross - pyAllowance) : null, variance:null, pct:null }
  ];
  lead[2].variance = (lead[2].listing != null && lead[2].py != null) ? r2(lead[2].listing - lead[2].py) : null;
  lead[2].pct = (lead[2].variance != null && lead[2].py) ? lead[2].variance / Math.abs(lead[2].py) : null;

  return { buckets, byBucket, aging, notAged, anyClientAging, clientTotal, customers, grossPos, currencies, total:r2(total), credits:r2(credits), creditCount, nilCount, invPrefix, orphans,
    lead, tbGross, tbAllowance, pyGross, pyAllowance, revenue, recDays: recDays != null ? r2(recDays) : null, top5, top5Share,
    postYE: live.filter(r => r.__postYE), nearYE: live.filter(r => r.__nearYE), cutoffDays,
    circ, subs, subsStats, hist, histYears, derivationEmpty, overlay, watch, indClient, indAudit, matrix, collClient, collAudit, totalClient, totalAudit, allowanceDiff, rpGross,
    defaultDays, sicrDays, longOverdue, pm, trivial, castTol };
}

/* ================================================================== TESTS */
const tests = [
  { id:'EX-AR-01', label:'Credit balance in the receivables listing', basis:'L3.1',
    fn:(r) => (r.amount || 0) < -0.005 && { actual:r.amount, difference:r.amount, cell:r['__cell_amount'], detail:'Credit balance — consider reclassification to payables or offset against the same customer\'s debits' } },
  { id:'EX-AR-02', label:'Invoice dated after the year end', basis:'L3.2',
    fn:(r, cfg, eng) => r.__postYE && { actual:Core.fmtDate(r.invoice_date), difference:r.amount, cell:r['__cell_invoice_date'], detail:'Cut-off: invoice raised after the reporting date is included in the year-end balance' } },
  { id:'EX-AR-03', label:'Due date earlier than the invoice date', basis:'L3.1', severity:'informational',
    fn:(r) => r.__dueBeforeInvoice && { actual:Core.fmtDate(r.due_date), expected:Core.fmtDate(r.invoice_date), cell:r['__cell_due_date'], detail:'Ageing from the due date would overstate days past due; check the terms recorded' } },
  { id:'EX-AR-04', label:'Long outstanding balance', basis:'L3.1',
    fn:(r, cfg) => { const lim = num(cfg.longOverdue) ?? 365; const age = Math.max(r.__daysPastDue ?? -1e9, r.__daysOutstanding ?? -1e9);
      return (r.amount || 0) > 0.005 && age > lim && { actual:age, difference:r.amount, detail:`${r.__daysPastDue ?? 'n/a'} days past due, ${r.__daysOutstanding ?? 'n/a'} days since invoice — beyond ${lim} days; credit-impaired presumption (FRS 109 para B5.5.37) applies on L3.8` }; } },
  { id:'EX-AR-05', label:'Counterparty not stated', basis:'L3.1', severity:'informational',
    fn:(r) => !r.cust_name && { difference:r.amount, cell:r['__cell_cust_name'], detail:'Cannot be circularised or assessed for credit risk without a counterparty' } },
  { id:'EX-AR-06', label:'Duplicate invoice number', basis:'L3.1',
    fn:(r) => r.__dupOf != null && { difference:r.amount, cell:r['__cell_invoice_no'], detail:`Same invoice reference as source row ${r.__dupOf}${r.__dupSameAmount ? ' with the same amount — possible double posting' : ' with a different amount'}` } },
  { id:'EX-AR-07', label:'Nil credit terms on an aged balance', basis:'L3.1', severity:'informational',
    fn:(r) => r.__nilTerms && { actual:0, difference:r.amount, cell:r['__cell_terms'], detail:`Terms recorded as nil${r.due_date && r.invoice_date && r.due_date > r.invoice_date ? ` yet the due date is ${days(r.due_date, r.invoice_date)} days after the invoice` : ` yet ${r.__daysOutstanding} days since invoice`} — the terms and the ageing basis for this item are unreliable` } },
  { id:'EX-AR-08', label:'Round-sum item with a non-invoice reference', basis:'L3.1',
    fn:(r, cfg, eng, d) => r.__roundSum && r.__nonInvoiceRef && { actual:r.amount, difference:r.amount, cell:r['__cell_invoice_no'], detail:`Reference "${r.invoice_no}" does not follow the invoice pattern (${d.invPrefix}) and the amount is a round multiple of ${num(cfg.roundSum)} — possible manual journal` } },
  { id:'EX-AR-09', label:'Currency outside the customer base\'s normal set', basis:'L3', severity:'informational',
    fn:(r) => r.__rareCcy && { actual:r.currency, difference:r.amount, cell:r['__cell_currency'], detail:'Only invoice in this currency — confirm the translation rate and that the balance is genuine' } },
  { id:'EX-AR-10', label:'Nil value open item', basis:'L3.1', severity:'informational',
    fn:(r) => r.amount != null && Math.abs(r.amount) < 0.005 && { detail:'Open item with no balance — should have been cleared from the ledger' } },
  { id:'EX-AR-11', scope:'population', label:'Rebuilt ageing differs from the client\'s ageing', basis:'L3.1',
    fn:(recs, cfg, eng, d) => d.anyClientAging && d.aging.filter(a => a.client != null && Math.abs(a.diff) > d.castTol)
      .map(a => ({ key:a.label, expected:a.gross, actual:a.client, difference:a.diff, detail:`Rebuilt ${a.gross.toFixed(2)} vs client ageing ${a.client.toFixed(2)} for ${a.label}` })) },
  { id:'EX-AR-12', label:'Cut-off vouching: item recorded in the wrong period', basis:'L3.2',
    fn:(r) => r.__nearYE && r.__wp?.cutoff?.period === 'Incorrect' && { difference:r.amount, detail:'Delivery evidenced after the year end — revenue and receivable recognised early' } },
  { id:'EX-AR-13', label:'Confirmation difference not reconciled', basis:'L3.3',
    fn:(recs, cfg, eng, d) => d.circ.unreconciled.map(x => ({ key:x.label, expected:x.gross, actual:x.conf, difference:x.diff, detail:'Amount confirmed by the customer differs from the listing and no reconciliation has been recorded' })), scope:'population' },

  /* ---- FRS 109 ---------------------------------------------------------- */
  { id:'EX-ECL-01', scope:'population', label:'Loss rate applied by the client unsupported by the observed history', basis:'L3.7',
    fn:(recs, cfg, eng, d) => d.matrix.filter(m => m.pastDue && m.base > 0 && m.clientRate != null && (m.clientRate === 0 || (m.rateGap != null && Math.abs(m.rateGap) > (num(cfg.rateTol) ?? 0.5))))
      .map(m => ({ key:m.label, expected: m.auditRate != null ? r2(m.auditRate * 10000) / 100 : null, actual:m.clientPct, difference: m.diff != null ? m.diff : m.base,
        detail: m.clientRate === 0 ? `Nil loss rate applied to ${m.base.toFixed(2)} in ${m.label}${m.observed != null ? `; observed history gives ${(m.observed * 100).toFixed(2)}%` : ''} (FRS 109 para B5.5.35)`
          : `Client ${m.clientPct}% vs ${(m.auditRate * 100).toFixed(2)}% per audit for ${m.label}` })) },
  { id:'EX-ECL-02', scope:'population', label:'No forward-looking adjustment supported by scenarios', basis:'L3.6', severity:'above-trivial',
    fn:(recs, cfg, eng, d) => !d.overlay.valid && { key:'Forward-looking overlay', actual: d.overlay.weightedMult, detail: d.overlay.issues.join('; ') + ' (FRS 109 para 5.5.17). The observed rates are applied unadjusted until a valid overlay is recorded.' } },
  { id:'EX-ECL-03', scope:'population', label:'Forward-looking overlay is stale', basis:'L3.6', severity:'above-trivial',
    fn:(recs, cfg, eng, d) => d.overlay.stale && { key:'Forward-looking overlay', actual:Core.fmtDate(d.overlay.date), detail:`Last updated ${d.overlay.ageMonths} months before the year end — more than one reporting period` } },
  { id:'EX-ECL-04', scope:'population', label:'Macroeconomic inputs not externally sourced', basis:'L3.6', severity:'informational',
    fn:(recs, cfg, eng, d) => d.overlay.scen.some(s => s.w != null) && d.overlay.macroUnsourced && { key:'Forward-looking overlay', actual:d.overlay.macroSource || '(blank)', detail:'Scenario inputs are a management estimate with no external reference — not "reasonable and supportable" (FRS 109 para 5.5.17)' } },
  { id:'EX-ECL-05', scope:'population', label:'Debtor in financial difficulty with a nil allowance', basis:'L3.8',
    fn:(recs, cfg, eng, d) => d.watch.filter(w => w.difficulty && !(w.eclc > 0))
      .map(w => ({ key:w.label, expected:w.ecla, actual:w.eclc ?? 0, difference: w.ecla != null ? r2(w.ecla - (w.eclc || 0)) : w.gross, detail:`Indicator: ${w.ind}. Nil allowance per client on ${w.gross.toFixed(2)} (FRS 109 para 5.5.3)` })) },
  { id:'EX-ECL-06', scope:'population', label:'Balance beyond the default definition not assessed as credit-impaired', basis:'L3.8',
    fn:(recs, cfg, eng, d) => d.watch.filter(w => w.credImpairedPresumed && w.imp !== 'Y')
      .map(w => ({ key:w.label, actual:w.maxPastDue, difference:w.overDefault, detail:`${w.maxPastDue} days past due, ${w.overDefault.toFixed(2)} beyond ${d.defaultDays} days${w.imp === 'N' ? ' — presumption rebutted' + (w.basis ? ': ' + w.basis : ' with no basis recorded') : ' — not yet assessed'} (FRS 109 para B5.5.37)` })) },
  { id:'EX-ECL-07', scope:'population', label:'Related-party receivables excluded from the ECL assessment', basis:'L3.7',
    fn:(recs, cfg, eng, d) => !!cfg.clientExcludesRP && { key:'Related party balances', actual:d.rpGross, difference:d.rpGross, detail:`Client's model excludes related-party balances${d.rpGross ? ` of ${d.rpGross.toFixed(2)}` : ''}. FRS 109 applies to every in-scope financial asset; "recoverable on demand" requires evidence of the counterparty's ability to pay.` } },
  { id:'EX-ECL-09', scope:'population', label:'Provision matrix does not agree to the loss allowance in the trial balance', basis:'L3.7',
    fn:(recs, cfg, eng, d) => d.allowanceDiff != null && Math.abs(d.allowanceDiff) > d.castTol && { key:'Loss allowance', expected:d.totalAudit, actual:d.tbAllowance, difference:d.allowanceDiff, detail:`Collective ${d.collAudit != null ? d.collAudit.toFixed(2) : 'n/a'} + individual ${d.indAudit.toFixed(2)} per audit vs ${d.tbAllowance.toFixed(2)} carried in the ledger` } },
  { id:'EX-ECL-10', scope:'population', label:'Loss rates not derived from observed history', basis:'L3.5', severity:'above-trivial',
    fn:(recs, cfg, eng, d) => d.histYears < 3 && { key:'Loss rate derivation', actual:d.histYears, expected:3, detail: d.derivationEmpty ? 'No loss-rate derivation recorded — the matrix cannot be traced to history (FRS 109 para B5.5.35)' : `Only ${d.histYears} year(s) of history recorded; at least three are expected` } },
  { id:'EX-ECL-11', scope:'population', label:'30-day SICR presumption rebutted without a recorded reason', basis:'L3.8', severity:'informational',
    fn:(recs, cfg, eng, d) => d.watch.filter(w => w.sicrPresumed && w.sicr === 'N' && !String(w.basis).trim())
      .map(w => ({ key:w.label, actual:w.maxPastDue, difference:w.overDefault || w.gross, detail:'Marked as no significant increase in credit risk while more than 30 days past due; record the basis (FRS 109 para 5.5.11)' })) }
];

/* ================================================================== PAGES */
const chipRP = v => v === 'Y' ? 'warn' : 'grey';
const pctCol = (key, label, dp = 2) => ({ key, label, type:'pct', dp });

function bucketCols(d, prefix = '') {
  return d.buckets.map(b => ({ key: prefix + b.key, label: b.label, type:'num', sum:true }));
}

const pages = [
  { id:'source',  ref:'L3.0',  title:'Source data',     kind:'source' },
  { id:'cleaned', ref:'L3.0a', title:'Cleaned listing', kind:'cleaned' },
  { id:'mapping', ref:'L3.0b', title:'Column mapping',  kind:'mapping' },

  { id:'lead', ref:'L3', title:'Lead schedule',
    objective:'To agree trade receivables per the open-item listing to the trial balance and prior year, and to obtain an overview of the balance by currency, concentration and collection period.',
    procedures:['Agreed the total of the open-item listing to the trade receivables control account in the trial balance and to the prior year audited figure.',
                'Analysed the listing by currency and identified the five largest customers and their share of the balance.',
                'Computed receivable days against revenue for the year and compared to credit terms.'],
    render(st, ctx) {
      const d = ctx.d, cfg = ctx.cfg;
      const tol = d.castTol;
      return [
        { type:'controls', items:[
          { key:'tbGross', label:'Trade receivables per trial balance (gross)', kind:'number' },
          { key:'tbAllowance', label:'Loss allowance per trial balance', kind:'number', help:'Enter as a positive figure' },
          { key:'pyGross', label:'Prior year — gross receivables', kind:'number' },
          { key:'pyAllowance', label:'Prior year — loss allowance', kind:'number' },
          { key:'revenue', label:'Revenue for the year', kind:'number', help:'Used for receivable days' } ] },
        { type:'table', title:'Lead schedule', columns:[
          { key:'line', label:'Caption', emphasis:true }, { key:'listing', label:'Per listing / per audit', type:'num' }, { key:'tb', label:'Per trial balance', type:'num' },
          { key:'diff', label:'Difference', type:'num', flag:v => v != null && Math.abs(v) > tol }, { key:'py', label:'Prior year', type:'num' }, { key:'variance', label:'Movement', type:'num' }, pctCol('pct', 'Movement %', 1) ],
          rows: d.lead, totals:false, footnote:'Loss allowance per audit is the collective matrix (L3.7) plus individually assessed balances (L3.8). It is blank until the loss-rate derivation on L3.5 is completed.' },
        { type:'stats', items:[
          { label:'Open items', value:String(ctx.recs.length) }, { label:'Customers', value:String(d.customers.length) },
          { label:'Receivable days', value: d.recDays != null ? d.recDays.toFixed(0) : 'enter revenue', cls: d.recDays != null && d.recDays > 90 ? 'warn' : '' },
          { label:'Top 5 customers', value: d.top5Share != null ? (d.top5Share * 100).toFixed(1) + '%' : '—', cls: d.top5Share > 0.5 ? 'warn' : '' },
          { label:'Credit balances', value:`${d.creditCount} (${ctx.money(d.credits)})`, cls: d.creditCount ? 'warn' : 'ok' },
          { label:'Nil items', value:String(d.nilCount), cls: d.nilCount ? 'warn' : 'ok' } ] },
        { type:'table', title:'Listing by currency', columns:[
          { key:'currency', label:'Currency' }, { key:'count', label:'Items', type:'int' }, { key:'orig', label:'Amount in original currency', type:'num' }, { key:'base', label:'Amount in base currency', type:'num', sum:true } ],
          rows: d.currencies.map(c => ({ ...c, orig:r2(c.orig), base:r2(c.base) })), footnote:'Original-currency amounts are shown where the listing carries them; otherwise the base amount is repeated.' },
        { type:'table', title:'Concentration — five largest customers', columns:[
          { key:'label', label:'Customer' }, { key:'code', label:'Code' }, { key:'ccy', label:'Currencies' }, { key:'count', label:'Items', type:'int' }, { key:'gross', label:'Balance', type:'num', sum:true }, pctCol('share', 'Share of total', 1),
          { key:'maxPastDue', label:'Max days past due', type:'int' } ], rows: d.top5 }
      ];
    },
    flag(st, d) { return d.lead.some(l => l.diff != null && Math.abs(l.diff) > d.castTol); } },

  { id:'aging', ref:'L3.1', title:'Ageing rebuild',
    objective:'To rebuild the ageing of trade receivables independently from the open-item listing, compare it to the ageing prepared by the client, and identify credit balances, nil items and inconsistent dates.',
    procedures:['Rebuilt the ageing from the due date (or invoice date plus terms where no due date is recorded) into the buckets configured for the engagement.',
                'Compared each bucket to the client\'s ageing report and investigated differences above the casting tolerance.',
                'Listed credit balances, nil-value items, items whose due date precedes the invoice date, and items with nil terms.',
                'Marked related-party customers so that they are carried separately through the provision matrix.'],
    render(st, ctx) {
      const d = ctx.d;
      const cols = bucketCols(d);
      const out = [
        { type:'controls', items:[
          { key:'ageBasis', label:'Age balances from', kind:'select', options:[['due', 'Due date where present, else invoice date + terms'], ['invoice_terms', 'Invoice date + credit terms (ignore recorded due date)'], ['invoice', 'Invoice date (days since invoice)']] },
          { key:'defaultTerms', label:'Default credit terms where not stated (days)', kind:'number' },
          { key:'bucketEdges', label:'Bucket edges (days past due)', kind:'text', help:'Comma-separated upper edges, e.g. 30,60,90,180,365' } ] },
        { type:'table', title:'Ageing by bucket — rebuilt vs client', columns:[
          { key:'label', label:'Bucket', emphasis:true }, { key:'count', label:'Items', type:'int' }, { key:'gross', label:'Per audit (rebuilt)', type:'num', sum:true }, pctCol('share', '% of total', 1),
          { key:'ca', label:'Per client ageing', input:'number' }, { key:'diff', label:'Difference', type:'num', sum:true, flag:v => v != null && Math.abs(v) > d.castTol }, { key:'rp', label:'Of which related party', type:'num', sum:true } ],
          rows: d.aging.map(a => ({ ...a, __key:a.key })), footnote: d.anyClientAging ? `Client ageing total entered: ${ctx.money(d.clientTotal)} vs rebuilt ${ctx.money(d.total)}.` : 'Enter the client\'s ageing per bucket to compare.' }
      ];
      if (d.notAged.length) out.push({ type:'note', tone:'warn', html:`<b>${d.notAged.length} item(s) could not be aged</b> — no usable invoice or due date. They are included in the total but in no bucket.` });
      out.push({ type:'table', title:'Ageing by customer', maxHeight:'520px', columns:[
        { key:'label', label:'Customer', emphasis:true }, { key:'code', label:'Code' }, { key:'rp', label:'Related party', input:'select', options:['Y', 'N'] },
        ...cols, { key:'gross', label:'Total', type:'num', sum:true, emphasis:true }, { key:'maxPastDue', label:'Max days past due', type:'int' }, { key:'count', label:'Items', type:'int' } ],
        rows: d.customers.map(c => ({ ...c, ...c.buckets, __key:c.key })), footnote:'Mark related-party customers here; the provision matrix (L3.7) and the watchlist (L3.8) read this marker.' });
      const anomalies = ctx.recs.filter(r => (r.amount || 0) < -0.005 || (r.amount != null && Math.abs(r.amount) < 0.005) || r.__dueBeforeInvoice || r.__nilTerms || r.__dupOf != null || !r.cust_name);
      out.push({ type:'table', title:'Items requiring attention', emptyText:'No credit balances, nil items, inconsistent dates, nil terms or duplicate references.', columns:[
        { key:'__custLabel', label:'Customer' }, { key:'invoice_no', label:'Reference' }, { key:'invoice_date', label:'Invoice date', type:'date' }, { key:'due_date', label:'Due date', type:'date' }, { key:'terms', label:'Terms', type:'int' },
        { key:'amount', label:'Amount', type:'num', sum:true }, { key:'issue', label:'Issue', type:'chip', chipClass:v => /Credit|Duplicate/.test(v) ? 'bad' : 'warn' } ],
        rows: anomalies.map(r => ({ ...r, __rec:r, issue: (r.amount || 0) < -0.005 ? 'Credit balance' : (r.amount != null && Math.abs(r.amount) < 0.005) ? 'Nil item' : r.__dupOf != null ? 'Duplicate reference' : !r.cust_name ? 'No counterparty' : r.__dueBeforeInvoice ? 'Due before invoice' : 'Nil terms, aged' })) });
      return out;
    },
    flag(st, d) { return d.creditCount > 0 || d.aging.some(a => a.diff != null && Math.abs(a.diff) > d.castTol); } },

  { id:'cutoff', ref:'L3.2', title:'Cut-off',
    objective:'To determine that receivables and the related revenue are recorded in the correct period, by examining invoices raised around the year end.',
    procedures:['Identified invoices dated after the year end that are included in the year-end balance.',
                'For invoices raised in the final days before the year end, vouched to the delivery order or service evidence and concluded on the period of recognition.'],
    render(st, ctx) {
      const d = ctx.d;
      return [
        { type:'controls', items:[{ key:'cutoffDays', label:'Window before year end (days)', kind:'number' }] },
        { type:'stats', items:[
          { label:'Invoices dated after year end', value:String(d.postYE.length), cls: d.postYE.length ? 'bad' : 'ok' },
          { label:'Value after year end', value:ctx.money(r2(d.postYE.reduce((s, r) => s + (r.amount || 0), 0))) },
          { label:`Invoices in last ${d.cutoffDays} days`, value:String(d.nearYE.length) },
          { label:'Value in window', value:ctx.money(r2(d.nearYE.reduce((s, r) => s + (r.amount || 0), 0))) } ] },
        { type:'table', title:'Invoices dated after the year end', emptyText:'No invoices dated after the year end.', columns:[
          { key:'__custLabel', label:'Customer' }, { key:'invoice_no', label:'Reference' }, { key:'invoice_date', label:'Invoice date', type:'date' }, { key:'due_date', label:'Due date', type:'date' }, { key:'currency', label:'Ccy' }, { key:'amount', label:'Amount', type:'num', sum:true } ],
          rows: d.postYE.map(r => ({ ...r, __rec:r })), footnote:'Each of these is raised as EX-AR-02. Propose reversal unless the goods or services were delivered before the year end.' },
        { type:'table', title:`Invoices raised in the ${d.cutoffDays} days before the year end — vouching`, emptyText:'No invoices in the window.', maxHeight:'520px', columns:[
          { key:'__custLabel', label:'Customer' }, { key:'invoice_no', label:'Reference' }, { key:'invoice_date', label:'Invoice date', type:'date' }, { key:'amount', label:'Amount', type:'num', sum:true },
          { key:'doDate', label:'Delivery / DO date', input:'date' }, { key:'doRef', label:'Document vouched', input:'text' }, { key:'period', label:'Correct period?', input:'select', options:['Correct', 'Incorrect'] }, { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: d.nearYE.map(r => ({ ...r, __rec:r })), footnote:'An item marked "Incorrect" is raised as EX-AR-12.' }
      ];
    },
    flag(st, d) { return d.postYE.length > 0; } },

  { id:'circ', ref:'L3.3', title:'Circularisation control',
    objective:'To obtain external confirmation of customer balances for key items and a reproducible random sample, and to control replies, differences and reconciliations.',
    procedures:['Selected every customer with a balance at or above the testing threshold as a key item.',
                'Selected a random sample from the remaining customers using a recorded seed so that the selection is reproducible.',
                'Recorded the date each confirmation was sent, whether a reply was received, the amount confirmed and the reconciliation of any difference.',
                'Where no reply was received, performed alternative procedures (subsequent receipts, L3.4).'],
    render(st, ctx) {
      const d = ctx.d, C = d.circ;
      return [
        { type:'controls', items:[
          { key:'circThreshold', label:'Key-item threshold (customer balance)', kind:'number', help:`Blank = performance materiality ${ctx.money(ctx.pm)}` },
          { key:'circSampleN', label:'Random sample size from the residual', kind:'number' },
          { key:'circSeed', label:'Sample seed', kind:'number', help:'Change to reselect; record the seed used' } ] },
        { type:'stats', items:[
          { label:'Customers with debit balances', value:`${d.grossPos.length} (${ctx.money(C.posTotal)})` },
          { label:'Key items', value:`${C.keyItems.length} ≥ ${ctx.money(C.threshold)}` }, { label:'Random sample', value:`${C.sample.length} of ${C.residual.length}` },
          { label:'Coverage of debit balances', value:`${C.coverage}%`, cls: C.coverage >= 70 ? 'ok' : 'warn' },
          { label:'Replies received', value:`${C.replies} of ${C.selected.length}` }, { label:'Confirmed without difference', value:ctx.money(C.confirmedValue) },
          { label:'Unreconciled differences', value:String(C.unreconciled.length), cls: C.unreconciled.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Confirmation control sheet', emptyText:'No customers selected — lower the threshold or set a sample size.', columns:[
          { key:'label', label:'Customer', emphasis:true }, { key:'basis', label:'Selection', type:'chip', chipClass:v => v === 'Key item' ? 'info' : 'grey' }, { key:'gross', label:'Balance per listing', type:'num', sum:true },
          { key:'c_sent', label:'Confirmation sent', input:'date' }, { key:'c_reply', label:'Reply received', input:'select', options:['Y', 'N'] }, { key:'c_conf', label:'Amount confirmed', input:'number' },
          { key:'diff', label:'Difference', type:'num', flag:(v, row) => row.unreconciled }, { key:'c_recon', label:'Reconciled', input:'select', options:['Y', 'N'] }, { key:'c_alt', label:'Alternative procedure performed', input:'text', wide:true } ],
          rows: C.selected.map(x => ({ ...x, __key:x.key })), footnote:`Seed ${C.seed}. Differences are the amount confirmed less the balance per listing; an unreconciled difference is raised as EX-AR-13.` }
      ];
    },
    flag(st, d) { return d.circ.unreconciled.length > 0; } },

  { id:'subs', ref:'L3.4', title:'Subsequent receipts',
    objective:'To obtain evidence of existence and recoverability for balances not confirmed, by tracing to cash received after the year end.',
    procedures:['For each selected customer without a clean confirmation, traced the year-end balance to receipts in the post year-end bank statements.',
                'Recorded the receipt date, amount and bank reference, and computed the proportion of the balance cleared and the amount still outstanding.'],
    render(st, ctx) {
      const d = ctx.d, S = d.subsStats;
      return [
        { type:'controls', items:[{ key:'subsAll', label:'Test every customer with a debit balance (not only unconfirmed selections)', kind:'check' }] },
        { type:'stats', items:[
          { label:'Customers tested', value:String(d.subs.length) }, { label:'Balance tested', value:ctx.money(S.value) },
          { label:'Cleared by receipts', value:ctx.money(S.received) }, { label:'Still outstanding', value:ctx.money(S.outstanding), cls: S.outstanding > ctx.trivial ? 'warn' : 'ok' },
          { label:'% cleared', value: S.value ? (S.received / S.value * 100).toFixed(1) + '%' : '—' } ] },
        { type:'table', title:'Subsequent receipts testing', emptyText:'Every selected customer confirmed cleanly — no alternative procedures required. Tick the control above to test all customers.', columns:[
          { key:'label', label:'Customer', emphasis:true }, { key:'gross', label:'Balance per listing', type:'num', sum:true },
          { key:'s_date', label:'Receipt date', input:'date' }, { key:'s_amt', label:'Amount received', input:'number' }, { key:'s_ref', label:'Bank reference', input:'text' },
          pctCol('pct', '% of balance cleared', 1), { key:'outstanding', label:'Still outstanding', type:'num', sum:true, flag:v => v > ctx.trivial } ],
          rows: d.subs.map(x => ({ ...x, __key:x.key })), footnote:'A balance still outstanding after the subsequent-receipts window is evidence for the watchlist (L3.8).' }
      ];
    } },

  { id:'lossrate', ref:'L3.5', title:'ECL — loss-rate derivation',
    objective:'To derive observed historical loss rates by ageing bucket from at least three years of gross balances and subsequent write-offs, as the starting point for the provision matrix (FRS 109 para B5.5.35).',
    procedures:['Obtained, for each of the last three financial years, the gross receivables by ageing bucket at the year end and the amounts subsequently written off.',
                'Computed the observed loss rate per bucket as total written off over total gross across the years recorded.',
                'Recorded the client\'s write-off policy and definition of default and considered their consistency with the history (FRS 109 paras 5.4.4, B5.5.37).'],
    render(st, ctx) {
      const d = ctx.d;
      const cols = [{ key:'label', label:'Ageing bucket', emphasis:true }];
      for (const y of HIST_YEARS) { cols.push({ key:`h_g${y.y}`, label:`${y.label} gross at year end`, input:'number' }); cols.push({ key:`h_w${y.y}`, label:`${y.label} subsequently written off`, input:'number' }); }
      cols.push({ key:'sumG', label:'Total gross', type:'num', sum:true }, { key:'sumW', label:'Total written off', type:'num', sum:true }, { key:'observed', label:'Observed loss rate', type:'pct', dp:2 });
      return [
        { type:'controls', items:[
          { key:'histSource', label:'Source of the history', kind:'text', help:'e.g. prior-year audited ageings and the write-off register' },
          { key:'writeOffPolicy', label:'Write-off policy per client', kind:'text' },
          { key:'defaultDays', label:'Definition of default — days past due', kind:'number', help:'FRS 109 para B5.5.37 presumes no later than 90 days' } ] },
        { type:'stats', items:[
          { label:'Years of history recorded', value:`${d.histYears} of 3`, cls: d.histYears >= 3 ? 'ok' : 'bad' },
          { label:'Default definition', value:`${d.defaultDays} days`, cls: d.defaultDays > 90 ? 'warn' : 'ok' } ] },
        d.derivationEmpty ? { type:'note', tone:'bad', html:'<b>No derivation recorded.</b> Until gross balances and write-offs are entered per bucket, the provision matrix on L3.7 cannot be computed and EX-ECL-10 stands.' } : null,
        { type:'table', title:'Observed loss rate by bucket', columns:cols, rows: d.hist.map(h => ({ ...h, sumG:r2(h.sumG), sumW:r2(h.sumW), __key:h.key })),
          footnote:'Observed rate = Σ written off ÷ Σ gross across the years entered. A bucket with gross entered and no write-off column is read as nil write-offs.' }
      ].filter(Boolean);
    },
    flag(st, d) { return d.histYears < 3; } },

  { id:'overlay', ref:'L3.6', title:'ECL — forward-looking overlay',
    objective:'To assess the forward-looking adjustment applied to observed loss rates: the scenarios, their weightings, the macroeconomic indicators relied on, their source and currency (FRS 109 para 5.5.17).',
    procedures:['Recorded each macroeconomic scenario with its weighting, the indicator relied on, the external source and the multiplier applied to the observed loss rates.',
                'Recomputed the probability-weighted multiplier and confirmed the weightings sum to one.',
                'Recorded the source of the macroeconomic data and the date the overlay was last refreshed, and assessed whether it remains reasonable and supportable at the reporting date.'],
    render(st, ctx) {
      const d = ctx.d, O = d.overlay;
      return [
        { type:'table', title:'Scenarios', columns:[
          { key:'label', label:'Scenario', emphasis:true }, { key:'o_w', label:'Weighting (0–1)', input:'number' }, { key:'o_m', label:'Multiplier on observed rate', input:'number' },
          { key:'o_note', label:'Macroeconomic indicator relied on', input:'text', wide:true }, { key:'o_src', label:'Source', input:'text' }, { key:'contrib', label:'Weight × multiplier', type:'num', dp:4, sum:true } ],
          rows: O.scen.map(s => ({ ...s, __key:s.key })), footnote:'Probability-weighted multiplier = Σ weight × multiplier. Where the weightings do not sum to one the multiplier is rejected, not defaulted to 1.' },
        { type:'controls', items:[
          { key:'macroSource', label:'Source of macroeconomic data', kind:'text', help:'An external, citable source — a management estimate is not reasonable and supportable' },
          { key:'overlayDate', label:'Date the overlay was last updated', kind:'date' },
          { key:'overlayStaleMonths', label:'Stale after (months before year end)', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Sum of weightings', value: O.sumW != null ? String(O.sumW) : '—', cls: Math.abs((O.sumW || 0) - 1) <= 0.001 ? 'ok' : 'bad' },
          { label:'Probability-weighted multiplier', value: O.weightedMult != null ? O.weightedMult.toFixed(4) : 'rejected', cls: O.valid ? 'ok' : 'bad' },
          { label:'Applied to the matrix', value: O.appliedMult != null ? O.appliedMult.toFixed(4) : 'none — observed rates unadjusted', cls: O.valid ? 'ok' : 'warn' },
          { label:'Overlay age at year end', value: O.ageMonths != null ? `${O.ageMonths} months` : 'not recorded', cls: O.stale ? 'bad' : (O.ageMonths != null ? 'ok' : 'warn') } ] },
        O.issues.length ? { type:'note', tone:'bad', html:'<b>Overlay rejected:</b> ' + O.issues.join('; ') + '. Raised as EX-ECL-02.' } : { type:'note', tone:'info', html:'Overlay accepted: at least two weighted scenarios, weightings sum to one, indicators recorded.' },
        O.stale ? { type:'note', tone:'bad', html:`<b>Overlay stale:</b> last updated ${ctx.fmtDate(O.date)}, ${O.ageMonths} months before the year end (EX-ECL-03).` } : null,
        (O.scen.some(s => s.w != null) && O.macroUnsourced) ? { type:'note', tone:'warn', html:'<b>Macroeconomic inputs are not externally sourced</b> (EX-ECL-04).' } : null
      ].filter(Boolean);
    },
    flag(st, d) { return !d.overlay.valid || d.overlay.stale; } },

  { id:'matrix', ref:'L3.7', title:'ECL — provision matrix',
    objective:'To recompute the loss allowance on trade receivables using a provision matrix built from the rebuilt ageing, observed loss rates and the forward-looking multiplier, and to compare it to the client\'s matrix and the allowance carried in the trial balance.',
    procedures:['Applied the observed loss rate per bucket (L3.5) adjusted by the probability-weighted multiplier (L3.6) to the rebuilt gross balance per bucket net of balances assessed individually (L3.8).',
                'Recorded the rate applied by the client per bucket and computed the expected credit loss per client and per audit, and the difference.',
                'Added the individually assessed allowances and agreed the total to the loss allowance in the trial balance.',
                'Considered whether any class of in-scope balance — in particular related-party receivables — has been left out of the assessment.'],
    render(st, ctx) {
      const d = ctx.d;
      const rpNote = d.rpGross > 0 ? { type:'note', tone:'warn', html:`<b>Related-party balances of ${ctx.money(d.rpGross)}</b> are inside the collective pool at the bucket rate. An argument that they are "recoverable on demand" needs evidence of the counterparty's ability to pay; otherwise assess them individually on L3.8.` } : null;
      const summary = [
        { line:'Collective — provision matrix', client:d.collClient, audit:d.collAudit },
        { line:'Individually assessed (L3.8)', client:d.indClient, audit:d.indAudit },
        { line:'Total loss allowance', client:d.totalClient, audit:d.totalAudit },
        { line:'Loss allowance per trial balance', client:null, audit:d.tbAllowance },
        { line:'Difference — audit to ledger', client:null, audit:d.allowanceDiff }
      ].map(x => ({ ...x, diff: (x.client != null && x.audit != null) ? r2(x.audit - x.client) : null }));
      return [
        { type:'controls', items:[
          { key:'tbAllowance', label:'Loss allowance per trial balance', kind:'number' },
          { key:'rateTol', label:'Rate tolerance — client vs audit (percentage points)', kind:'number' },
          { key:'clientExcludesRP', label:'Client\'s model excludes related-party balances', kind:'check' } ] },
        d.collAudit == null ? { type:'note', tone:'bad', html:'<b>ECL per audit cannot be computed</b> for every bucket carrying a balance — complete the loss-rate derivation on L3.5.' } : null,
        !d.overlay.valid ? { type:'note', tone:'warn', html:'The forward-looking overlay on L3.6 was rejected; observed rates are applied unadjusted (EX-ECL-02).' } : null,
        rpNote,
        { type:'table', title:'Provision matrix', columns:[
          { key:'label', label:'Ageing bucket', emphasis:true }, { key:'gross', label:'Gross per rebuild', type:'num', sum:true }, { key:'rp', label:'Of which related party', type:'num', sum:true },
          { key:'individual', label:'Of which individually assessed', type:'num', sum:true }, { key:'base', label:'Collective base', type:'num', sum:true },
          { key:'m_rate', label:'Loss rate per client (%)', input:'number' }, pctCol('observed', 'Observed rate (L3.5)'), { key:'mult', label:'Multiplier (L3.6)', type:'num', dp:4 }, pctCol('auditRate', 'Loss rate per audit'),
          { key:'eclClient', label:'ECL per client', type:'num', sum:true }, { key:'eclAudit', label:'ECL per audit', type:'num', sum:true, emphasis:true }, { key:'diff', label:'Difference', type:'num', sum:true, flag:v => v != null && Math.abs(v) > ctx.trivial } ],
          rows: d.matrix.map(m => ({ ...m, __key:m.key })), footnote:'Rate per audit = observed rate × probability-weighted multiplier. The client\'s rate never enters the computation; it is compared to the result (EX-ECL-01 where it differs beyond tolerance or is nil on a past-due bucket).' },
        { type:'table', title:'Loss allowance — summary', columns:[
          { key:'line', label:'', emphasis:true }, { key:'client', label:'Per client', type:'num' }, { key:'audit', label:'Per audit', type:'num', emphasis:true }, { key:'diff', label:'Difference', type:'num', flag:v => v != null && Math.abs(v) > ctx.trivial } ],
          rows: summary, totals:false, footnote: d.allowanceDiff != null && Math.abs(d.allowanceDiff) > d.castTol ? `Matrix does not agree to the ledger by ${ctx.money(d.allowanceDiff)} (EX-ECL-09).` : (d.tbAllowance == null ? 'Enter the loss allowance per the trial balance to test the tie.' : 'Matrix agrees to the ledger within tolerance.') }
      ].filter(Boolean);
    },
    flag(st, d) { return d.allowanceDiff != null && Math.abs(d.allowanceDiff) > d.castTol; } },

  { id:'watchlist', ref:'L3.8', title:'SICR & credit-impaired watchlist',
    objective:'To identify counterparties whose credit risk has increased significantly since initial recognition or that are credit-impaired, assess them individually and remove them from the collective matrix (FRS 109 paras 5.5.3, 5.5.11, B5.5.37).',
    procedures:['Listed every customer with a balance beyond the default definition, beyond the 30-day SICR presumption, long outstanding, related, or in credit.',
                'Recorded any indicator of financial difficulty, concluded on SICR and credit-impairment for each, and recorded the individual allowance per client and per audit with its basis.',
                'Removed balances concluded as SICR or credit-impaired from the collective matrix (L3.7) so that they are assessed once.'],
    render(st, ctx) {
      const d = ctx.d;
      const indiv = d.watch.filter(w => w.individual);
      return [
        { type:'controls', items:[
          { key:'sicrDays', label:'SICR presumption — days past due', kind:'number', help:'FRS 109 para 5.5.11: 30 days' },
          { key:'defaultDays', label:'Default definition — days past due', kind:'number' },
          { key:'longOverdue', label:'Long-outstanding threshold (days)', kind:'number' },
          { key:'watchExtra', label:'Additional customers to assess (comma-separated names)', kind:'text' } ] },
        { type:'stats', items:[
          { label:'Candidates', value:String(d.watch.length) }, { label:'Candidate balances', value:ctx.money(r2(d.watch.reduce((s, w) => s + w.gross, 0))) },
          { label:'Beyond default definition', value:String(d.watch.filter(w => w.credImpairedPresumed).length), cls: d.watch.some(w => w.credImpairedPresumed && w.imp !== 'Y') ? 'bad' : 'ok' },
          { label:'Assessed individually', value:`${indiv.length} (${ctx.money(r2(indiv.reduce((s, w) => s + w.gross, 0)))})` },
          { label:'Individual ECL per client', value:ctx.money(d.indClient) }, { label:'Individual ECL per audit', value:ctx.money(d.indAudit) } ] },
        { type:'table', title:'Watchlist', emptyText:'No candidates — no balance is past the SICR presumption, long outstanding, related or in credit.', maxHeight:'560px', columns:[
          { key:'label', label:'Counterparty', emphasis:true }, { key:'relationship', label:'Relationship', type:'chip', chipClass:chipRP }, { key:'gross', label:'Gross balance', type:'num', sum:true }, { key:'maxPastDue', label:'Days past due (max)', type:'int' },
          { key:'overDefault', label:'Beyond default definition', type:'num', sum:true }, { key:'trig', label:'Auto trigger', wrap:true },
          { key:'w_ind', label:'Indicator of financial difficulty', input:'text', wide:true }, { key:'w_sicr', label:'SICR?', input:'select', options:['Y', 'N'] }, { key:'w_imp', label:'Credit-impaired?', input:'select', options:['Y', 'N'] },
          { key:'w_eclc', label:'Individual ECL per client', input:'number' }, { key:'w_ecla', label:'Individual ECL per audit', input:'number' }, { key:'w_basis', label:'Basis', input:'text', wide:true } ],
          rows: d.watch.map(w => ({ ...w, relationship: w.rp ? 'Y' : 'N', trig: w.triggers.join('; '), __key:w.key })),
          footnote:'A counterparty marked SICR or credit-impaired leaves the collective matrix. Indicators of difficulty with a nil client allowance raise EX-ECL-05; balances beyond the default definition not marked credit-impaired raise EX-ECL-06.' }
      ];
    },
    flag(st, d) { return d.watch.some(w => w.credImpairedPresumed && w.imp !== 'Y'); } },

  { id:'conclusion', ref:'L3.9', title:'Exceptions & conclusion', kind:'conclusion' }
];

function suggestConclusion(st, ctx) {
  const d = ctx.d;
  if (!d) return '';
  const ex = (st.exceptions || []).filter(e => e.disposition === 'open');
  return `Trade receivables of ${ctx.money(d.total)} per the open-item listing ${d.tbGross != null ? (Math.abs(d.total - d.tbGross) <= d.castTol ? 'agree to' : 'differ from') + ' the trial balance' : 'have not yet been agreed to the trial balance'}. ` +
    `The ageing was rebuilt independently${d.anyClientAging ? ' and compared to the client\'s ageing' : ''}; ${d.circ.selected.length} customer(s) covering ${d.circ.coverage}% of debit balances were selected for confirmation. ` +
    `The loss allowance was recomputed using a provision matrix${d.totalAudit != null ? ` giving ${ctx.money(d.totalAudit)} per audit against ${d.tbAllowance != null ? ctx.money(d.tbAllowance) : 'an unrecorded amount'} in the ledger` : ' (derivation incomplete)'}; ${d.watch.filter(w => w.individual).length} counterparty(ies) were assessed individually. ` +
    `${ex.length ? ex.length + ' exception(s) remain open and are addressed above.' : 'All exceptions have been dispositioned.'} ` +
    'Subject to the resolution of the matters noted, trade receivables are fairly stated net of an appropriate loss allowance measured in accordance with FRS 109.';
}

return {
  code:'AR', name:'Trade Receivables & ECL', group:'Assets', accepts:'.xlsx,.xlsm,.csv',
  blurb:'The receivables audit file: lead, ageing rebuild, cut-off, circularisation, subsequent receipts, and a three-schedule FRS 109 provision matrix with a SICR watchlist — from one uploaded open-item listing.',
  objective:'To obtain sufficient appropriate audit evidence that trade receivables exist, are recorded at the amounts due in the correct period, and are stated net of a loss allowance measured in accordance with FRS 109.',
  fields, tests, compute, pages, defaultConfig, STANDARD_COLUMNS, SCENARIOS, HIST_YEARS, buildBuckets,
  procedures: pages.flatMap(p => p.procedures || []),
  columns: STANDARD_COLUMNS,
  suggestConclusion
};
})();

Modules.register(ARModule);
