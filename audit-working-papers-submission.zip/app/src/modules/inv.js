/* ==========================================================================
   inv.js -- Inventory as an auditor actually works it.

   A set of working papers, each computed from the same cleaned listing:
     K    Lead schedule                  K4  Slow-moving and obsolescence
     K1   Extension and casting          K5  Count observation and roll-forward
     K2   Cost testing                   K6  Cut-off
     K3   Net realisable value           K7  Cost of sales reconciliation
   ========================================================================== */

const INVModule = (() => {
const r2 = n => n == null || n === '' || isNaN(n) ? null : Math.round(Number(n) * 100) / 100;
const num = v => v == null || v === '' || isNaN(v) ? null : Number(v);
const days = (a, b) => (a && b) ? Math.round((a - b) / 86400000) : null;
const lowerKey = s => String(s == null ? '' : s).replace(/\s+/g, ' ').trim().toLowerCase();
const fmt = n => n == null ? 'n/a' : Number(n).toLocaleString('en-GB', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const isYes = v => String(v || '').trim().toUpperCase() === 'Y';

/* Seeded PRNG so a random sample is reproducible from its recorded seed. */
function mulberry32(seed) {
  let a = (seed >>> 0) || 1;
  return () => {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function sampleN(items, n, seed) {
  const rnd = mulberry32(seed);
  const pool = items.slice();
  const out = [];
  while (out.length < n && pool.length) out.push(pool.splice(Math.floor(rnd() * pool.length), 1)[0]);
  return out;
}

/* Units of measure as clients write them, normalised to one spelling each. */
const UOM_CANON = [
  [/^(kg|kgs|kilo|kilos|kilogram|kilogramme|kilograms|kilogrammes)$/, 'KG'],
  [/^(g|gm|gms|gram|gramme|grams|grammes)$/, 'G'],
  [/^(t|mt|ton|tons|tonne|tonnes)$/, 'TONNE'],
  [/^(pc|pcs|piece|pieces|no|nos|nr|unit|units|unt|ea|each)$/, 'PCS'],
  [/^(box|boxes|bx)$/, 'BOX'],
  [/^(ctn|ctns|carton|cartons)$/, 'CTN'],
  [/^(pkt|pkts|pack|packs|packet|packets|pk)$/, 'PACK'],
  [/^(bag|bags)$/, 'BAG'],
  [/^(set|sets)$/, 'SET'],
  [/^(pr|pair|pairs)$/, 'PAIR'],
  [/^(roll|rolls|rl)$/, 'ROLL'],
  [/^(drum|drums)$/, 'DRUM'],
  [/^(m|mtr|mtrs|meter|meters|metre|metres)$/, 'M'],
  [/^(l|lt|ltr|ltrs|liter|liters|litre|litres)$/, 'L'],
  [/^(sqm|m2|sq m|square metre|square metres)$/, 'SQM'],
];
function canonUom(u) {
  if (u == null) return null;
  const s = String(u).trim().toLowerCase().replace(/[.\s]+/g, '');
  if (!s) return null;
  for (const [re, c] of UOM_CANON) if (re.test(s)) return c;
  return s.toUpperCase();
}

/* K6 -- what the cut-off answer should be for each document type. */
const CUTOFF_TYPES = [
  { key: 'GRN before year end', doc: 'Goods received note', inv: 'Y', ledger: 'Y', ledgerName: 'payables',   rule: 'Goods received before the year end belong in inventory and the liability in trade payables.' },
  { key: 'GRN after year end',  doc: 'Goods received note', inv: 'N', ledger: 'N', ledgerName: 'payables',   rule: 'Goods received after the year end belong in neither inventory nor trade payables.' },
  { key: 'DO before year end',  doc: 'Delivery order',      inv: 'N', ledger: 'Y', ledgerName: 'receivables', rule: 'Goods delivered before the year end leave inventory and the sale is recognised in receivables.' },
  { key: 'DO after year end',   doc: 'Delivery order',      inv: 'Y', ledger: 'N', ledgerName: 'receivables', rule: 'Goods delivered after the year end remain in inventory with no sale recognised.' },
];

const COUNT_CHECKS = [
  { id: 'C1', text: 'Count instructions obtained and reviewed before the count; counters independent of custodians' },
  { id: 'C2', text: 'Count sheets pre-numbered, controlled and reconciled after the count; no quantities pre-printed' },
  { id: 'C3', text: 'Test counts performed from the floor to the count sheets (completeness) and from the sheets to the floor (existence)' },
  { id: 'C4', text: 'Last goods received note, delivery order and internal transfer numbers noted at the count for cut-off' },
  { id: 'C5', text: 'Damaged, obsolete, slow-moving or excess stock identified at the count and referred to K3 / K4' },
  { id: 'C6', text: 'Inventory held by or for third parties (consignment, bonded warehouse) confirmed or attended separately' },
  { id: 'C7', text: 'Work in progress stage of completion assessed with production staff' },
  { id: 'C8', text: 'Count sheet totals agreed into the final inventory listing; count adjustments reviewed' },
];

/* ---------------------------------------------------------------- fields */
const fields = [
  { key: 'item_code',   label: 'Item code', role: 'key', type: 'text', required: true, dupKey: true,
    synonyms: ['Item Code', 'SKU', 'Part No.', 'Part No', 'Part Number', 'Stock Code', 'Item Code / Part No.', 'Material',
               'Material Code', 'Item No', 'Item No.', 'Item Number', 'Product Code', 'Stock No', 'Article', 'Article No', 'Code',
               '存货编码', '物料编码', '编码'] },
  { key: 'category',    label: 'Category', role: 'category', type: 'text', required: true, satisfiedByGroup: true,
    synonyms: ['Category', 'Stock Type', 'Class', 'Item Group', 'Inventory Class', 'Type', 'Group', 'Stock Class', 'Inventory Type',
               'Product Group', 'Classification', 'Stock Category', 'Item Class', '存货类别', '类别', '存货分类'] },
  { key: 'description', label: 'Description', type: 'text', required: true,
    synonyms: ['Description', 'Stock Name', 'Item Description', 'Material Description', 'Product', 'Item Name', 'Particulars',
               'Product Name', 'Name', 'Details', 'Product Description', 'Stock Description', '存货名称', '物料名称', '品名'] },
  { key: 'uom',         label: 'Unit of measure', type: 'text',
    synonyms: ['UOM', 'Unit', 'Unit of Measure', 'Units', 'U/M', 'UoM', 'Measure', 'Unit of Measurement', '单位', '计量单位'] },
  { key: 'qty',         label: 'Quantity on hand', type: 'number', required: true,
    synonyms: ['Quantity', 'Qty', 'Closing Qty', 'Final quantity as per client', 'Balance Qty', 'On Hand', 'Qty on Hand',
               'Stock Qty', 'Closing Quantity', 'Quantity on Hand', 'Bal Qty', 'Qty On Hand', 'Stock on Hand', 'Book Qty',
               '数量', '结存数量', '库存数量'] },
  { key: 'unit_cost',   label: 'Unit cost', type: 'number', required: true,
    synonyms: ['Unit Cost', 'Cost/Unit', 'Unit cost as per client', 'Std Cost', 'Avg Cost', 'Rate', 'Cost per Unit',
               'Average Cost', 'Standard Cost', 'Cost Price', 'WAC', 'Weighted Average Cost', 'Unit Price', 'Cost Each',
               '单价', '单位成本'] },
  { key: 'total_cost',  label: 'Total cost', type: 'number', required: true,
    synonyms: ['Total Cost', 'Value', 'Amount', 'Extended Cost', 'Closing Value', 'Total Value', 'Stock Value',
               'Inventory Value', 'Total', 'Cost', 'Book Value', 'Extended Value', 'Total Amount', '金额', '结存金额', '库存金额'] },
  { key: 'nrv',         label: 'NRV / selling price per unit', type: 'number',
    synonyms: ['NRV', 'Net Realisable Value', 'Net Realizable Value', 'Selling Price', 'Est. Selling Price', 'Market Value',
               'Unit Selling Price', 'Sales Price', 'List Price', 'Realisable Value', 'Estimated Selling Price', 'Unit NRV',
               '可变现净值', '售价'] },
  { key: 'last_movement', label: 'Last movement date', type: 'date',
    synonyms: ['Last Movement Date', 'Last Issue Date', 'Last Txn', 'Date of Last Movement', 'Last Used', 'Last Movement',
               'Last Transaction', 'Last Transaction Date', 'Last Receipt', 'Last Sale', 'Last Issue', 'Last Activity',
               'Last Movement Dt', '最后异动日期', '最后出入库日期'] },
  { key: 'location',    label: 'Location', type: 'text',
    synonyms: ['Location', 'Warehouse', 'Bin', 'Store', 'Whse', 'Site', 'Bin Location', 'Branch', '仓库', '库位'] },
];

/* The standard cleaned format every client's listing is normalised into. */
const STANDARD_COLUMNS = [
  { key: 'item_code', label: 'Item code' }, { key: 'category', label: 'Category' },
  { key: 'description', label: 'Description' }, { key: 'uom', label: 'UOM' }, { key: '__uomCanon', label: 'UOM (std)' },
  { key: 'qty', label: 'Quantity', type: 'num', edit: true }, { key: 'unit_cost', label: 'Unit cost', type: 'num', edit: true },
  { key: 'total_cost', label: 'Value per listing', type: 'num', edit: true, emphasis: true },
  { key: '__extended', label: 'Qty × cost', type: 'num' }, { key: '__extDiff', label: 'Extension diff', type: 'num' },
  { key: 'nrv', label: 'NRV / unit', type: 'num', edit: true }, { key: '__writeDown', label: 'Write-down', type: 'num' },
  { key: 'last_movement', label: 'Last movement', type: 'date', edit: true }, { key: '__daysSince', label: 'Days', type: 'num', dp: 0 },
  { key: 'location', label: 'Location' },
];

const defaultConfig = () => ({
  castTol: 0.01, extTol: 1.00,
  costThreshold: null, costSampleN: 5, costSeed: 20250228, costingPolicy: 'WAC',
  sellingCostPct: 0,
  tier1: 365, tier2: 730, tier3: 1095, tierPct1: 0, tierPct2: 25, tierPct3: 50, tierPct4: 100,
  tbProvision: null, pyProvision: null, cos: null, pyCos: null,
  countDate: '', countLocations: '', countPctValue: null, countRows: 8, countChecks: {},
  rfPerCount: null, rfPurchases: null, rfCos: null, rfOther: null,
  cutoffRows: 8,
  cogsOpening: null, cogsPurchases: null, cogsLabour: null, cogsOverhead: null, cogsPerPL: null, cogsTol: 0,
});

/* ========================================================== COMPUTE */
function compute(recs, cfg, eng) {
  const ye = eng.yearEndDate;
  const pm = eng.materiality?.pm || 0, trivial = eng.materiality?.trivial || 0;
  const castTol = num(cfg.castTol) ?? 0.01;

  /* slow-moving tiers from the configured edges */
  const edges = [num(cfg.tier1) ?? 365, num(cfg.tier2) ?? 730, num(cfg.tier3) ?? 1095].sort((a, b) => a - b);
  const pcts = [num(cfg.tierPct1) ?? 0, num(cfg.tierPct2) ?? 25, num(cfg.tierPct3) ?? 50, num(cfg.tierPct4) ?? 100];
  const tiers = [
    { idx: 0, label: `0–${edges[0]} days`,                 from: -1e9,         to: edges[0], pct: pcts[0] },
    { idx: 1, label: `${edges[0] + 1}–${edges[1]} days`,   from: edges[0] + 1, to: edges[1], pct: pcts[1] },
    { idx: 2, label: `${edges[1] + 1}–${edges[2]} days`,   from: edges[1] + 1, to: edges[2], pct: pcts[2] },
    { idx: 3, label: `Over ${edges[2]} days`,              from: edges[2] + 1, to: 1e9,      pct: pcts[3] },
  ].map(t => ({ ...t, count: 0, value: 0, suggested: 0 }));
  const noDate = { count: 0, value: 0 };
  const sellPct = num(cfg.sellingCostPct) || 0;
  const nrvMapped = recs.some(r => r.nrv != null);
  const uomMapped = recs.some(r => r.uom != null);
  const dateMapped = recs.some(r => r.last_movement != null);

  const catDisplay = new Map();
  const catOf = r => {
    const k = lowerKey(r.category) || '(uncategorised)';
    if (!catDisplay.has(k)) catDisplay.set(k, r.category ? String(r.category).replace(/\s+/g, ' ').trim() : '(uncategorised)');
    return catDisplay.get(k);
  };
  const uomVariants = new Map();
  const cats = {};
  const anomalies = { extension: 0, negQty: 0, negValue: 0, nilCost: 0, nilValue: 0, nilQty: 0, noUom: 0, duplicates: 0 };
  const extTol = num(cfg.extTol) ?? 1;

  for (const r of recs) {
    r.__displayKey = r.item_code || r.description || ('row ' + r.__srcRow);
    r.__cat = catOf(r);
    r.__uomCanon = canonUom(r.uom);
    if (r.uom != null && !r.__excluded) {
      const s = uomVariants.get(r.__uomCanon) || new Map();
      const raw = String(r.uom).trim();
      s.set(raw, (s.get(raw) || 0) + 1);
      uomVariants.set(r.__uomCanon, s);
    }
    const qty = r.qty, uc = r.unit_cost, tc = r.total_cost;
    r.__extended = (qty != null && uc != null) ? r2(qty * uc) : null;
    r.__value = tc != null ? tc : (r.__extended != null ? r.__extended : 0);
    r.__extDiff = (tc != null && r.__extended != null) ? r2(tc - r.__extended) : null;

    /* K1 anomaly classification -- one label per line, in priority order */
    const issues = [];
    if ((qty || 0) < -1e-9) issues.push('Negative quantity');
    if ((tc || 0) < -0.005 && (qty || 0) >= 0) issues.push('Negative value');
    if ((qty || 0) > 0 && r.__cell_unit_cost && (uc == null || Math.abs(uc) < 1e-9)) issues.push('Nil unit cost');
    if ((qty || 0) > 0 && (uc || 0) > 0 && tc != null && Math.abs(tc) < 0.005) issues.push('Nil value');
    if (qty != null && Math.abs(qty) < 1e-9 && Math.abs(tc || 0) > 0.005) issues.push('Value with nil quantity');
    if (r.__extDiff != null && qty && uc && tc && !(tc < 0 && qty > 0) && Math.abs(r.__extDiff) > extTol) issues.push('Extension error');
    if (uomMapped && r.uom == null) issues.push('No UOM');
    if (r.__flags.some(f => f.rule === 'DQ-10')) issues.push('Duplicate code');
    r.__issues = issues;
    r.__issue = issues[0] || null;

    /* K4 slow-moving */
    r.__daysSince = (r.last_movement && ye) ? days(ye, r.last_movement) : null;
    const tier = r.__daysSince == null ? null : (tiers.find(t => r.__daysSince >= t.from && r.__daysSince <= t.to) || tiers[3]);
    r.__tier = tier ? tier.idx : null;
    r.__tierLabel = tier ? tier.label : 'No movement date';
    r.__tierPct = tier ? tier.pct : null;
    r.__slowSuggested = (tier && r.__value > 0) ? r2(r.__value * tier.pct / 100) : 0;

    /* K3 net realisable value -- auditor evidence overrides the listing */
    const w = r.__wp?.nrv || {};
    const sp = num(w.sellPrice), sc = num(w.sellCost);
    let nrv = null, src = '';
    if (sp != null) { nrv = sp - (sc || 0); src = 'Post year-end selling price' + (sc ? ' less selling costs' : ''); }
    else if (r.nrv != null) { nrv = sc != null ? r.nrv - sc : r.nrv * (1 - sellPct / 100); src = (sc != null || sellPct) ? 'Listing NRV less selling costs' : 'Per listing'; }
    r.__nrvUsed = nrv != null ? r2(nrv) : null;
    r.__nrvSource = src;
    r.__nrvShort = (nrv != null && uc != null && uc > nrv) ? r2(uc - nrv) : 0;
    r.__writeDown = (r.__nrvShort > 0 && (qty || 0) > 0) ? r2(r.__nrvShort * qty) : 0;

    /* K2 cost testing inputs */
    const c = r.__wp?.cost || {};
    const iuc = num(c.invUnitCost);
    r.__invDiff = (iuc != null && uc != null) ? r2(iuc - uc) : null;
    r.__invDiffExt = (r.__invDiff != null && qty != null) ? r2(r.__invDiff * qty) : null;

    const cat = cats[r.__cat] || (cats[r.__cat] = { category: r.__cat, count: 0, value: 0, extended: 0, extDiff: 0, writeDown: 0,
      slowSuggested: 0, slowValue: 0, anomalies: 0 });
    if (r.__excluded) continue;
    cat.count++; cat.value += r.__value || 0; cat.extended += r.__extended || 0; cat.extDiff += r.__extDiff || 0;
    cat.writeDown += r.__writeDown || 0; cat.slowSuggested += r.__slowSuggested || 0;
    if ((r.__tier || 0) >= 1) cat.slowValue += Math.max(0, r.__value || 0);
    if (issues.length) cat.anomalies++;
    if (issues.includes('Extension error')) anomalies.extension++;
    if (issues.includes('Negative quantity')) anomalies.negQty++;
    if (issues.includes('Negative value')) anomalies.negValue++;
    if (issues.includes('Nil unit cost')) anomalies.nilCost++;
    if (issues.includes('Nil value')) anomalies.nilValue++;
    if (issues.includes('Value with nil quantity')) anomalies.nilQty++;
    if (issues.includes('No UOM')) anomalies.noUom++;
    if (issues.includes('Duplicate code')) anomalies.duplicates++;
    if (tier) { tier.count++; if (r.__value > 0) { tier.value += r.__value; tier.suggested += r.__slowSuggested; } }
    else { noDate.count++; noDate.value += Math.max(0, r.__value || 0); }
  }

  const live = recs.filter(r => !r.__excluded);
  const byCategory = Object.values(cats).sort((a, b) => a.category.localeCompare(b.category));
  for (const c of byCategory) for (const k of Object.keys(c)) if (typeof c[k] === 'number') c[k] = r2(c[k]);
  const totals = { count: 0, value: 0, extended: 0, extDiff: 0, writeDown: 0, slowSuggested: 0, slowValue: 0, anomalies: 0 };
  for (const c of byCategory) for (const k of Object.keys(totals)) totals[k] += c[k] || 0;
  for (const k of Object.keys(totals)) totals[k] = r2(totals[k]);
  for (const t of tiers) { t.value = r2(t.value); t.suggested = r2(t.suggested); }
  noDate.value = r2(noDate.value);

  /* ---- K lead: listing vs TB vs prior year, by category ------------- */
  const lead = byCategory.map(c => {
    const tbGross = num(cfg['tbGross:' + c.category]);
    const pyGross = num(cfg['pyGross:' + c.category]);
    const diff = tbGross != null ? r2(c.value - tbGross) : null;
    const variance = pyGross != null ? r2(c.value - pyGross) : null;
    return { category: c.category, count: c.count, listValue: c.value, tbGross, diff, pyGross, variance,
      variancePct: (pyGross ? variance / Math.abs(pyGross) : null),
      material: variance != null && Math.abs(variance) > pm && pyGross && Math.abs(variance / pyGross) > 0.10,
      status: tbGross == null ? 'TB not entered' : Math.abs(diff) > castTol ? 'Does not agree' : 'Agreed to TB' };
  });
  const tbGrossTotal = lead.some(l => l.tbGross != null) ? r2(lead.reduce((s, l) => s + (l.tbGross || 0), 0)) : null;
  const pyGrossTotal = lead.some(l => l.pyGross != null) ? r2(lead.reduce((s, l) => s + (l.pyGross || 0), 0)) : null;
  const tbProvision = num(cfg.tbProvision), pyProvision = num(cfg.pyProvision);
  const cos = num(cfg.cos), pyCos = num(cfg.pyCos);
  const net = { listing: r2(totals.value - Math.abs(tbProvision || 0)),
    tb: tbGrossTotal != null ? r2(tbGrossTotal - Math.abs(tbProvision || 0)) : null,
    py: pyGrossTotal != null ? r2(pyGrossTotal - Math.abs(pyProvision || 0)) : null };
  const invDays = cos ? r2(totals.value / Math.abs(cos) * 365) : null;
  const pyDays = (pyCos && pyGrossTotal != null) ? r2(pyGrossTotal / Math.abs(pyCos) * 365) : null;

  /* ---- K2 cost testing: key items above threshold + random sample ---- */
  const threshold = num(cfg.costThreshold) != null ? num(cfg.costThreshold) : pm;
  const pool = live.filter(r => (r.__value || 0) > 0.005);
  const key = pool.filter(r => r.__value >= threshold);
  const residual = pool.filter(r => r.__value < threshold);
  const n = Math.min(Number(cfg.costSampleN) || 0, residual.length);
  const seed = Number(cfg.costSeed) || 1;
  const sample = sampleN(residual, n, seed);
  const selectedSet = new Set([...key, ...sample].map(r => r.__i));
  for (const r of recs) r.__costSelected = selectedSet.has(r.__i) ? (key.includes(r) ? 'Key item' : 'Random sample') : null;
  const selected = [...key, ...sample].sort((a, b) => (b.__value || 0) - (a.__value || 0));
  const keyValue = r2(key.reduce((s, r) => s + r.__value, 0));
  const sampleValue = r2(sample.reduce((s, r) => s + r.__value, 0));
  const poolValue = r2(pool.reduce((s, r) => s + r.__value, 0));
  const vouched = selected.filter(r => num(r.__wp?.cost?.invUnitCost) != null);
  const costTest = { threshold, seed, pool, key, residual, sample, selected, keyValue, sampleValue, poolValue,
    coverage: poolValue ? r2((keyValue + sampleValue) / poolValue * 100) : 0,
    untestedValue: r2(poolValue - keyValue - sampleValue),
    vouched: vouched.length,
    invDiffTotal: r2(vouched.reduce((s, r) => s + (r.__invDiffExt || 0), 0)),
    policy: cfg.costingPolicy || '',
    inconsistent: selected.filter(r => r.__wp?.cost?.method && cfg.costingPolicy && r.__wp.cost.method !== cfg.costingPolicy).length };

  /* ---- K3 NRV summary ------------------------------------------------ */
  const nrvKnown = live.filter(r => r.__nrvUsed != null);
  const belowCost = live.filter(r => r.__writeDown > 0.005);
  const nrvRows = live.filter(r => r.__writeDown > 0.005 || r.__costSelected || (r.__nrvUsed == null && (r.__value || 0) >= threshold))
    .sort((a, b) => (b.__writeDown - a.__writeDown) || ((b.__value || 0) - (a.__value || 0)));
  const nrv = { mapped: nrvMapped, known: nrvKnown.length, knownValue: r2(nrvKnown.reduce((s, r) => s + Math.max(0, r.__value || 0), 0)),
    belowCost: belowCost.length, writeDown: totals.writeDown, rows: nrvRows,
    provision: tbProvision != null ? Math.abs(tbProvision) : null,
    shortfall: tbProvision != null ? r2(Math.abs(tbProvision) - totals.writeDown) : null,
    postYeSighted: belowCost.filter(r => isYes(r.__wp?.nrv?.postYeInvoice)).length };

  /* ---- K4 slow-moving summary --------------------------------------- */
  const slowRows = live.filter(r => (r.__tier || 0) >= 1 && (r.__value || 0) > 0).sort((a, b) => (b.__daysSince || 0) - (a.__daysSince || 0));
  const noDateRows = live.filter(r => r.__daysSince == null && (r.__value || 0) > 0);
  const slow = { tiers, edges, noDate, rows: slowRows, noDateRows, dateMapped,
    suggested: r2(tiers.reduce((s, t) => s + t.suggested, 0)),
    provision: tbProvision != null ? Math.abs(tbProvision) : null,
    shortfall: tbProvision != null ? r2(Math.abs(tbProvision) - tiers.reduce((s, t) => s + t.suggested, 0)) : null,
    beyondTop: tiers[3].count,
    agreed: slowRows.filter(r => isYes(r.__wp?.slow?.agreed)).length };

  /* ---- K5 count observation and roll-forward ------------------------- */
  const countDate = cfg.countDate ? new Date(cfg.countDate + 'T00:00:00Z') : null;
  const countRows = [];
  for (let i = 1; i <= (Number(cfg.countRows) || 0); i++) {
    const k = 'c' + i;
    const sheet = num(cfg['perSheet:' + k]), count = num(cfg['perCount:' + k]);
    const uc = num(cfg['unitCost:' + k]);
    const variance = (sheet != null && count != null) ? r2(count - sheet) : null;
    countRows.push({ __key: k, n: i, variance, varianceValue: (variance != null && uc != null) ? r2(variance * uc) : null,
      status: variance == null ? '' : Math.abs(variance) < 1e-9 ? 'Agreed' : 'Variance' });
  }
  const countGap = (countDate && ye) ? days(ye, countDate) : null;
  const rf = { needed: countGap != null && countGap !== 0, gapDays: countGap,
    perCount: num(cfg.rfPerCount), purchases: num(cfg.rfPurchases), cos: num(cfg.rfCos), other: num(cfg.rfOther) };
  rf.implied = rf.perCount != null ? r2(rf.perCount + (rf.purchases || 0) - Math.abs(rf.cos || 0) + (rf.other || 0)) : null;
  rf.diff = rf.implied != null ? r2(totals.value - rf.implied) : null;
  const count = { date: countDate, rows: countRows, completed: countRows.filter(r => r.variance != null).length,
    variances: countRows.filter(r => r.status === 'Variance').length, rf,
    pctValue: num(cfg.countPctValue), checks: COUNT_CHECKS };

  /* ---- K6 cut-off ---------------------------------------------------- */
  const cutoffRows = [];
  for (let i = 1; i <= (Number(cfg.cutoffRows) || 0); i++) {
    const k = 'k' + i;
    const type = CUTOFF_TYPES.find(t => t.key === cfg['type:' + k]) || null;
    const inv = String(cfg['inInventory:' + k] || '').toUpperCase(), led = String(cfg['inLedger:' + k] || '').toUpperCase();
    let assessment = '';
    if (type && inv && led) assessment = (inv === type.inv && led === type.ledger) ? 'Correct' : 'Cut-off error';
    else if (type) assessment = 'Incomplete';
    cutoffRows.push({ __key: k, n: i, expected: type ? `Inventory ${type.inv} · ${type.ledgerName} ${type.ledger}` : '', assessment,
      amount: num(cfg['amount:' + k]) });
  }
  const cutoff = { rows: cutoffRows, types: CUTOFF_TYPES, tested: cutoffRows.filter(r => r.assessment && r.assessment !== 'Incomplete').length,
    errors: cutoffRows.filter(r => r.assessment === 'Cut-off error').length,
    errorValue: r2(cutoffRows.filter(r => r.assessment === 'Cut-off error').reduce((s, r) => s + Math.abs(r.amount || 0), 0)) };

  /* ---- K7 cost of sales reconciliation ------------------------------- */
  const cg = { opening: num(cfg.cogsOpening), purchases: num(cfg.cogsPurchases), labour: num(cfg.cogsLabour),
    overhead: num(cfg.cogsOverhead), perPL: num(cfg.cogsPerPL) };
  cg.available = cg.opening != null && cg.perPL != null;
  cg.goodsAvailable = cg.available ? r2(cg.opening + (cg.purchases || 0) + (cg.labour || 0) + (cg.overhead || 0)) : null;
  cg.implied = cg.available ? r2(cg.goodsAvailable - Math.abs(cg.perPL)) : null;
  cg.diff = cg.available ? r2(totals.value - cg.implied) : null;
  cg.tol = num(cfg.cogsTol) > 0 ? num(cfg.cogsTol) : trivial;
  cg.impliedCos = cg.opening != null ? r2(cg.opening + (cg.purchases || 0) + (cg.labour || 0) + (cg.overhead || 0) - totals.value) : null;

  return { byCategory, totals, lead, tbGrossTotal, pyGrossTotal, tbProvision, pyProvision, net, cos, pyCos, invDays, pyDays,
    anomalies, uomVariants: [...uomVariants.entries()].map(([canon, m]) => ({ canon, variants: [...m.entries()], lines: [...m.values()].reduce((a, b) => a + b, 0) }))
      .sort((a, b) => b.lines - a.lines),
    uomMapped, nrvMapped, castTol, extTol, costTest, nrv, slow, count, cutoff, cogs: cg, pm, trivial,
    anomalyRows: live.filter(r => r.__issues.length).sort((a, b) => Math.abs(b.__value || 0) - Math.abs(a.__value || 0)) };
}

/* ============================================================== TESTS */
const tests = [
  { id: 'EX-INV-01', label: 'Net realisable value below cost', basis: 'K3',
    fn: (r) => r.__writeDown > 0.005 && { expected: r.__nrvUsed, actual: r.unit_cost, difference: r.__writeDown, cell: r.__cell_nrv || r.__cell_unit_cost,
      detail: `Unit cost ${fmt(r.unit_cost)} against NRV ${fmt(r.__nrvUsed)} (${r.__nrvSource}) on ${r.qty} units; write-down required ${fmt(r.__writeDown)}` } },
  { id: 'EX-INV-02', label: 'Negative quantity on hand', basis: 'K1',
    fn: (r) => (r.qty || 0) < -1e-9 && { actual: r.qty, difference: r.__value, cell: r.__cell_qty,
      detail: 'Physical stock cannot be negative; indicates unrecorded receipts or issues posted before receipt' } },
  { id: 'EX-INV-03', label: 'Negative inventory value', basis: 'K1',
    fn: (r) => (r.total_cost || 0) < -0.005 && (r.qty || 0) >= 0 && { expected: r.__extended, actual: r.total_cost, difference: r.total_cost, cell: r.__cell_total_cost,
      detail: 'Negative value carried against a non-negative quantity' } },
  { id: 'EX-INV-04', label: 'Extension error: quantity × unit cost differs from value', basis: 'K1',
    fn: (r) => r.__issues.includes('Extension error') && { expected: r.__extended, actual: r.total_cost, difference: r.__extDiff, cell: r.__cell_total_cost,
      detail: `${r.qty} × ${fmt(r.unit_cost)} = ${fmt(r.__extended)} against ${fmt(r.total_cost)} per listing` } },
  { id: 'EX-INV-05', label: 'Nil unit cost with quantity on hand', basis: 'K1', severity: 'above-trivial',
    fn: (r) => r.__issues.includes('Nil unit cost') && { actual: r.unit_cost ?? 0, cell: r.__cell_unit_cost,
      difference: r.__nrvUsed != null ? r2(r.qty * r.__nrvUsed) : null,
      detail: `${r.qty} units carried at no cost${r.__nrvUsed != null ? '; at NRV they would be worth ' + fmt(r.qty * r.__nrvUsed) : ''}` } },
  { id: 'EX-INV-06', label: 'No movement beyond the slow-moving threshold', basis: 'K4',
    fn: (r, cfg, eng, d) => r.__tier === 3 && (r.__value || 0) > 0 && { actual: r.__daysSince, difference: r.__value, cell: r.__cell_last_movement,
      detail: `${r.__daysSince} days since last movement (${Core.fmtDate(r.last_movement)}); tier "${r.__tierLabel}" at ${r.__tierPct}% suggests a provision of ${fmt(r.__slowSuggested)}` } },
  { id: 'EX-INV-07', label: 'Quantity on hand with nil value', basis: 'K1',
    fn: (r) => r.__issues.includes('Nil value') && { expected: r.__extended, actual: 0, difference: r.__extended, cell: r.__cell_total_cost,
      detail: `${r.qty} units at ${fmt(r.unit_cost)} should carry ${fmt(r.__extended)}` } },
  { id: 'EX-INV-08', label: 'Value carried with nil quantity', basis: 'K1',
    fn: (r) => r.__issues.includes('Value with nil quantity') && { expected: 0, actual: r.total_cost, difference: r.total_cost, cell: r.__cell_total_cost,
      detail: 'No units on hand; the value should be nil' } },
  { id: 'EX-INV-09', label: 'Unit of measure not stated', basis: 'K1', severity: 'informational',
    fn: (r) => r.__issues.includes('No UOM') && { cell: r.__cell_uom, difference: r.__value,
      detail: 'Quantity cannot be interpreted or counted without a unit of measure' } },
  { id: 'EX-INV-10', label: 'Duplicate item code', basis: 'K.0a',
    fn: (r) => { const f = r.__flags.find(x => x.rule === 'DQ-10'); return f && { detail: f.detail, difference: r.__value, cell: r.__cell_item_code }; } },
  { id: 'EX-INV-11', scope: 'population', label: 'Cost of sales reconciliation does not agree to the listing', basis: 'K7',
    fn: (recs, cfg, eng, d) => d.cogs.available && Math.abs(d.cogs.diff) > d.cogs.tol &&
      { key: 'Closing inventory', expected: d.cogs.implied, actual: d.totals.value, difference: d.cogs.diff,
        detail: `Opening ${fmt(d.cogs.opening)} + purchases ${fmt(d.cogs.purchases)} + labour ${fmt(d.cogs.labour)} + overhead ${fmt(d.cogs.overhead)} − cost of sales ${fmt(d.cogs.perPL)} implies closing ${fmt(d.cogs.implied)}` } },
  { id: 'EX-TIE-01', scope: 'population', label: 'Listing does not agree to the trial balance', basis: 'K',
    fn: (recs, cfg, eng, d) => d.lead.filter(l => l.diff != null && Math.abs(l.diff) > d.castTol)
      .map(l => ({ key: l.category, expected: l.tbGross, actual: l.listValue, difference: l.diff, detail: `Listing ${fmt(l.listValue)} against trial balance ${fmt(l.tbGross)}` })) },
];

/* ============================================================== PAGES */
const YN = ['Y', 'N'];
const chipStatus = v => /agreed|correct|within|^ok/i.test(v) ? 'ok' : /not entered|incomplete|n\/a|no movement/i.test(v) ? 'grey' : /error|does not|negative|nil|duplicate|variance|breach/i.test(v) ? 'bad' : 'warn';
const flagAbs = tol => v => v != null && Math.abs(v) > tol;

const pages = [
  { id: 'source',  ref: 'K.0',  title: 'Source data',     kind: 'source' },
  { id: 'cleaned', ref: 'K.0a', title: 'Cleaned listing', kind: 'cleaned' },
  { id: 'mapping', ref: 'K.0b', title: 'Column mapping',  kind: 'mapping' },

  { id: 'lead', ref: 'K', title: 'Lead schedule',
    objective: 'To agree inventory per the client\'s listing to the trial balance and prior year audited figures by category, to bring the obsolescence provision alongside the gross balance, and to explain material movements.',
    procedures: ['Agreed inventory per the listing to the trial balance by category and to the prior year audited figures.',
                 'Computed inventory days from cost of sales and compared with the prior year.',
                 'Investigated movements above performance materiality and 10% against the prior year.'],
    flag: (st, d) => d.lead.some(l => l.diff != null && Math.abs(l.diff) > d.castTol),
    render(st, ctx) {
      const d = ctx.d, cfg = ctx.cfg;
      const tbDiff = d.tbGrossTotal != null ? ctx.r2(d.totals.value - d.tbGrossTotal) : null;
      return [
        { type: 'note', html: `<b>Enter the trial balance and prior year gross balances by category</b>, then the obsolescence provision and cost of sales. The listing figures come from K.0a. Movements are flagged where they exceed performance materiality (${ctx.money0(ctx.pm)}) <em>and</em> 10%.` },
        { type: 'controls', items: [
          { key: 'tbProvision', label: 'Provision for obsolescence per TB', kind: 'number', help: 'Enter as a positive amount' },
          { key: 'pyProvision', label: 'Provision for obsolescence — prior year', kind: 'number' },
          { key: 'cos', label: 'Cost of sales for the year (P&L)', kind: 'number', help: 'Drives inventory days' },
          { key: 'pyCos', label: 'Cost of sales — prior year', kind: 'number' } ] },
        { type: 'stats', items: [
          { label: 'Inventory per listing (gross)', value: ctx.money0(d.totals.value) },
          { label: 'Per trial balance (gross)', value: d.tbGrossTotal != null ? ctx.money0(d.tbGrossTotal) : 'not entered' },
          { label: 'Difference', value: tbDiff != null ? ctx.money(tbDiff) : '—', cls: tbDiff == null ? '' : Math.abs(tbDiff) > d.castTol ? 'bad' : 'ok' },
          { label: 'Provision per TB', value: d.tbProvision != null ? ctx.money0(Math.abs(d.tbProvision)) : 'not entered' },
          { label: 'Net inventory per listing', value: ctx.money0(d.net.listing) },
          { label: 'Inventory days', value: d.invDays != null ? `${d.invDays} days` : 'enter cost of sales', cls: d.invDays != null && d.pyDays != null && d.invDays > d.pyDays * 1.2 ? 'warn' : '' },
          { label: 'Inventory days — prior year', value: d.pyDays != null ? `${d.pyDays} days` : '—' },
          { label: 'Lines / categories', value: `${d.totals.count} / ${d.byCategory.length}` } ] },
        { type: 'table', title: 'Inventory by category — listing vs trial balance vs prior year', columns: [
          { key: 'category', label: 'Category' }, { key: 'count', label: 'Lines', type: 'int' },
          { key: 'listValue', label: 'Per listing', type: 'num', sum: true, emphasis: true },
          { key: 'tbGross', label: 'Per TB (gross)', input: 'number' },
          { key: 'diff', label: 'Difference', type: 'num', sum: true, flag: flagAbs(d.castTol) },
          { key: 'pyGross', label: 'Prior year (gross)', input: 'number' },
          { key: 'variance', label: 'Movement vs PY', type: 'num', sum: true, flag: (v, row) => row.material },
          { key: 'variancePct', label: 'Movement %', type: 'pct' },
          { key: 'status', label: 'Tie', type: 'chip', chipClass: chipStatus } ],
          rows: d.lead.map(l => ({ ...l, __key: l.category })),
          footnote: 'TB agreed to trial balance · PY agreed to prior year audited. Enter TB figures as positive gross balances; the provision is entered once above.' },
        { type: 'table', title: 'Gross to net', columns: [
          { key: 'line', label: '' }, { key: 'listing', label: 'Per listing / audit', type: 'num' }, { key: 'tb', label: 'Per TB', type: 'num' },
          { key: 'diff', label: 'Difference', type: 'num', flag: flagAbs(d.castTol) }, { key: 'py', label: 'Prior year', type: 'num' }, { key: 'move', label: 'Movement', type: 'num' } ],
          rows: [
            { line: 'Gross inventory', listing: d.totals.value, tb: d.tbGrossTotal, diff: tbDiff, py: d.pyGrossTotal, move: d.pyGrossTotal != null ? ctx.r2(d.totals.value - d.pyGrossTotal) : null },
            { line: 'Less: provision for obsolescence', listing: d.tbProvision != null ? -Math.abs(d.tbProvision) : null, tb: d.tbProvision != null ? -Math.abs(d.tbProvision) : null, diff: null, py: d.pyProvision != null ? -Math.abs(d.pyProvision) : null, move: (d.tbProvision != null && d.pyProvision != null) ? ctx.r2(Math.abs(d.pyProvision) - Math.abs(d.tbProvision)) : null },
            { line: 'Net inventory', listing: d.net.listing, tb: d.net.tb, diff: (d.net.tb != null) ? ctx.r2(d.net.listing - d.net.tb) : null, py: d.net.py, move: d.net.py != null ? ctx.r2(d.net.listing - d.net.py) : null } ],
          footnote: `Provision required per K3 (NRV) ${ctx.money0(d.nrv.writeDown)} and per K4 (slow-moving) ${ctx.money0(d.slow.suggested)}; recorded ${d.tbProvision != null ? ctx.money0(Math.abs(d.tbProvision)) : 'not entered'}.` },
      ];
    } },

  { id: 'extension', ref: 'K1', title: 'Extension & casting',
    objective: 'To confirm that the inventory listing is arithmetically accurate: each line extends (quantity × unit cost = value), the categories cast to the total, and there are no negative, nil or duplicated lines.',
    procedures: ['Re-performed the extension of every line (quantity × unit cost) and compared with the value per the listing.',
                 'Cast the listing by category and in total.',
                 'Scanned for negative quantities and values, nil costs, nil values, nil quantities, missing units of measure and duplicated item codes.',
                 'Normalised units of measure so that quantities are comparable across lines.'],
    flag: (st, d) => d.anomalyRows.length > 0,
    render(st, ctx) {
      const d = ctx.d, a = d.anomalies;
      const cols = [
        { key: 'item_code', label: 'Item code' }, { key: '__cat', label: 'Category' }, { key: 'description', label: 'Description', wrap: true },
        { key: '__uomCanon', label: 'UOM' }, { key: 'qty', label: 'Quantity', type: 'num', flag: v => (v || 0) < 0 },
        { key: 'unit_cost', label: 'Unit cost', type: 'num', flag: (v, row) => (row.qty || 0) > 0 && !(v > 0) },
        { key: 'total_cost', label: 'Value per listing', type: 'num', emphasis: true, flag: v => (v || 0) < 0 },
        { key: '__extended', label: 'Qty × unit cost', type: 'num', formula: (row, C) => `${C(4)}${row}*${C(5)}${row}` },
        { key: '__extDiff', label: 'Difference', type: 'num', formula: (row, C) => `${C(6)}${row}-${C(7)}${row}`, flag: flagAbs(d.extTol) },
        { key: '__issueText', label: 'Issue', type: 'chip', chipClass: () => 'bad' } ];
      return [
        { type: 'controls', items: [ { key: 'extTol', label: 'Extension tolerance (rounding)', kind: 'number', help: 'Differences at or below this are treated as rounding' } ] },
        { type: 'stats', items: [
          { label: 'Lines', value: d.totals.count },
          { label: 'Value per listing', value: ctx.money0(d.totals.value) },
          { label: 'Value re-extended', value: ctx.money0(d.totals.extended) },
          { label: 'Net extension difference', value: ctx.money(d.totals.extDiff), cls: Math.abs(d.totals.extDiff || 0) > d.extTol ? 'bad' : 'ok' },
          { label: 'Extension errors', value: a.extension, cls: a.extension ? 'bad' : 'ok' },
          { label: 'Negative qty / value', value: `${a.negQty} / ${a.negValue}`, cls: a.negQty + a.negValue ? 'bad' : 'ok' },
          { label: 'Nil cost / nil value / nil qty', value: `${a.nilCost} / ${a.nilValue} / ${a.nilQty}`, cls: a.nilCost + a.nilValue + a.nilQty ? 'bad' : 'ok' },
          { label: 'No UOM / duplicate codes', value: `${a.noUom} / ${a.duplicates}`, cls: a.duplicates ? 'warn' : '' } ] },
        { type: 'table', title: 'Casting by category', columns: [
          { key: 'category', label: 'Category' }, { key: 'count', label: 'Lines', type: 'int' },
          { key: 'value', label: 'Per listing', type: 'num', sum: true, emphasis: true },
          { key: 'extended', label: 'Re-extended', type: 'num', sum: true },
          { key: 'extDiff', label: 'Difference', type: 'num', sum: true, flag: flagAbs(d.extTol) },
          { key: 'anomalies', label: 'Lines with issues', type: 'int' } ], rows: d.byCategory,
          footnote: '^ cast. The listing total is the sum of the client\'s value column; the re-extended total is Σ quantity × unit cost.' },
        { type: 'table', title: 'Lines requiring attention', columns: cols,
          rows: d.anomalyRows.map(r => ({ ...r, __rec: r, __issueText: r.__issues.join(' · ') })),
          emptyText: 'Every line extends within tolerance and no negative, nil or duplicated lines were found.', maxHeight: '520px',
          footnote: 'Each line is raised in the exception register under EX-INV-02 to EX-INV-10. Exclude a line on K.0a only with a documented reason.' },
        d.uomMapped
          ? { type: 'table', title: 'Units of measure — normalisation applied', columns: [
              { key: 'canon', label: 'Standard unit' }, { key: 'variantsText', label: 'As written by the client', wrap: true }, { key: 'lines', label: 'Lines', type: 'int' } ],
              rows: d.uomVariants.map(u => ({ canon: u.canon, lines: u.lines, variantsText: u.variants.map(([v, n]) => `"${v}" ×${n}`).join(', ') })),
              footnote: 'Quantities are not converted; the standard unit only makes like-for-like comparison of lines possible. Where one item is stated in two different units, agree the conversion factor to the bill of materials.' }
          : { type: 'note', tone: 'warn', html: 'No unit of measure column was mapped. Quantities cannot be compared across lines and count sheets should be checked for the unit used.' },
      ];
    } },

  { id: 'cost', ref: 'K2', title: 'Cost testing',
    objective: 'To verify that inventory is stated at cost measured on a consistent basis (FRS 2 paras 9–25): unit costs agree to supplier invoices and, for manufactured items, to bills of material with a systematic allocation of production overheads.',
    procedures: ['Selected every line at or above the testing threshold as a key item and a random sample from the remainder, using a recorded seed so the selection is reproducible.',
                 'Agreed the unit cost of each selected line to the latest supplier invoice (raw materials, consumables) or to the bill of materials and overhead absorption working (finished goods, work in progress).',
                 'Confirmed that the costing method applied is consistent with the stated accounting policy.'],
    flag: (st, d) => d.costTest.selected.length > d.costTest.vouched,
    render(st, ctx) {
      const d = ctx.d, T = d.costTest;
      return [
        { type: 'controls', items: [
          { key: 'costThreshold', label: 'Testing threshold — every line at or above this is tested', kind: 'number', help: `Blank = performance materiality (${ctx.money0(ctx.pm)}). Currently ${ctx.money0(T.threshold)}.` },
          { key: 'costSampleN', label: 'Random sample from the remaining lines', kind: 'number', help: `${T.residual.length} lines below the threshold, totalling ${ctx.money0(ctx.r2(T.poolValue - T.keyValue))}` },
          { key: 'costSeed', label: 'Sample seed (recorded)', kind: 'number', help: 'Same seed, same sample' },
          { key: 'costingPolicy', label: 'Costing method per accounting policy', kind: 'select', options: [['WAC', 'Weighted average cost'], ['FIFO', 'First-in, first-out'], ['Standard', 'Standard cost (variances reviewed)'], ['Specific', 'Specific identification']] } ] },
        { type: 'stats', items: [
          { label: 'Lines with value', value: `${T.pool.length} · ${ctx.money0(T.poolValue)}` },
          { label: 'Key items ≥ threshold', value: `${T.key.length} · ${ctx.money0(T.keyValue)}` },
          { label: 'Random sample', value: `${T.sample.length} · ${ctx.money0(T.sampleValue)}` },
          { label: 'Coverage of value', value: ctx.pct(T.coverage), cls: T.coverage >= 70 ? 'ok' : 'warn' },
          { label: 'Untested', value: `${T.residual.length - T.sample.length} · ${ctx.money0(T.untestedValue)}` },
          { label: 'Vouched so far', value: `${T.vouched} of ${T.selected.length}`, cls: T.vouched === T.selected.length ? 'ok' : 'warn' },
          { label: 'Net cost difference on vouched lines', value: ctx.money(T.invDiffTotal), cls: Math.abs(T.invDiffTotal || 0) > ctx.trivial ? 'bad' : '' },
          { label: 'Method inconsistent with policy', value: T.inconsistent, cls: T.inconsistent ? 'bad' : 'ok' } ] },
        { type: 'table', title: 'Selected lines — vouching to cost evidence', columns: [
          { key: 'item_code', label: 'Item code' }, { key: '__cat', label: 'Category' }, { key: 'description', label: 'Description', wrap: true },
          { key: 'qty', label: 'Quantity', type: 'num' }, { key: 'unit_cost', label: 'Unit cost per listing', type: 'num' },
          { key: '__value', label: 'Value', type: 'num', sum: true, emphasis: true },
          { key: '__costSelected', label: 'Basis', type: 'chip', chipClass: v => v === 'Key item' ? 'info' : 'grey' },
          { key: 'invNo', label: 'Invoice / BOM ref', input: 'text' }, { key: 'invDate', label: 'Invoice date', input: 'date' },
          { key: 'invUnitCost', label: 'Unit cost per evidence', input: 'number' },
          { key: '__invDiff', label: 'Difference / unit', type: 'num', flag: v => v != null && Math.abs(v) > 0.005 },
          { key: '__invDiffExt', label: 'Difference extended', type: 'num', sum: true, flag: flagAbs(ctx.trivial) },
          { key: 'method', label: 'Method applied', input: 'select', options: ['WAC', 'FIFO', 'Standard', 'Specific'] },
          { key: 'consistent', label: 'Consistent with policy', input: 'select', options: YN },
          { key: 'bom', label: 'BOM / overhead absorption checked (FG, WIP)', input: 'select', options: ['Y', 'N', 'n/a'] },
          { key: 'comment', label: 'Comment', input: 'text', wide: true } ],
          rows: T.selected.map(r => ({ ...r, __rec: r })), emptyText: 'No lines carry a positive value.', maxHeight: '560px',
          footnote: `vINV vouched to invoice. Key items are every line at or above ${ctx.money0(T.threshold)}; the random sample of ${T.sample.length} was drawn from the remaining ${T.residual.length} lines with seed ${T.seed}. A positive difference means the evidence shows a higher cost than the listing.` },
      ];
    } },

  { id: 'nrv', ref: 'K3', title: 'Net realisable value',
    objective: 'To confirm that inventory is carried at the lower of cost and net realisable value (FRS 2 paras 28–33), estimating NRV from post year-end selling prices less the costs to complete and sell.',
    procedures: ['Compared the unit cost of each line with its net realisable value, taken from the listing where provided and otherwise from post year-end sales invoices entered by the auditor.',
                 'Computed the write-down required as (cost − NRV) × quantity for every line where NRV is below cost.',
                 'Compared the total write-down required with the provision recorded in the trial balance.'],
    flag: (st, d) => d.nrv.shortfall != null && d.nrv.shortfall < -d.trivial,
    render(st, ctx) {
      const d = ctx.d, N = d.nrv;
      return [
        d.nrvMapped
          ? { type: 'note', html: `The listing carries a selling price / NRV column, used as the default. Enter a <b>post year-end selling price</b> and <b>selling costs per unit</b> on any line to override it with audit evidence.` }
          : { type: 'note', tone: 'warn', html: `<b>The listing carries no NRV column.</b> Enter the post year-end selling price (and selling costs) per unit for each selected line; the write-down is computed from what you enter.` },
        { type: 'controls', items: [ { key: 'sellingCostPct', label: 'Costs to sell as % of selling price (applied where no per-line selling cost is entered)', kind: 'number' } ] },
        { type: 'stats', items: [
          { label: 'Lines with NRV evidence', value: `${N.known} of ${d.totals.count} · ${ctx.money0(N.knownValue)}` },
          { label: 'Lines below cost', value: N.belowCost, cls: N.belowCost ? 'warn' : 'ok' },
          { label: 'Write-down required per audit', value: ctx.money0(N.writeDown), cls: N.writeDown > ctx.trivial ? 'warn' : 'ok' },
          { label: 'Provision recorded (K)', value: N.provision != null ? ctx.money0(N.provision) : 'enter on K' },
          { label: 'Provision (shortfall) / excess', value: N.shortfall != null ? ctx.money(N.shortfall) : '—', cls: N.shortfall == null ? '' : N.shortfall < -ctx.trivial ? 'bad' : 'ok' },
          { label: 'Post year-end invoices sighted', value: `${N.postYeSighted} of ${N.belowCost}` } ] },
        { type: 'table', title: 'Cost against net realisable value, by line', columns: [
          { key: 'item_code', label: 'Item code' }, { key: '__cat', label: 'Category' }, { key: 'description', label: 'Description', wrap: true },
          { key: 'qty', label: 'Quantity', type: 'num' }, { key: 'unit_cost', label: 'Unit cost', type: 'num' },
          { key: 'nrv', label: 'NRV per listing', type: 'num' },
          { key: 'sellPrice', label: 'Post YE selling price / unit', input: 'number' }, { key: 'sellCost', label: 'Selling costs / unit', input: 'number' },
          { key: '__nrvUsed', label: 'NRV used', type: 'num' }, { key: '__nrvSource', label: 'Source' },
          { key: '__nrvShort', label: 'Shortfall / unit', type: 'num', flag: v => v > 0 },
          { key: '__writeDown', label: 'Write-down required', type: 'num', sum: true, emphasis: true, flag: v => v > 0 },
          { key: 'postYeInvoice', label: 'Post YE invoice sighted', input: 'select', options: YN },
          { key: 'comment', label: 'Comment', input: 'text', wide: true } ],
          rows: N.rows.map(r => ({ ...r, __rec: r })), maxHeight: '560px',
          emptyText: 'No line is carried above its net realisable value and no line is awaiting NRV evidence.',
          footnote: 'Shown: every line below cost, every K2 selection, and every line at or above the K2 threshold without NRV evidence. Write-down = (unit cost − NRV) × quantity, nil where quantity is not positive.' },
      ];
    } },

  { id: 'slow', ref: 'K4', title: 'Slow-moving & obsolescence',
    objective: 'To identify slow-moving and obsolete inventory from the date of last movement and to assess whether the provision recorded is sufficient against a tiered policy.',
    procedures: ['Aged every line by days since last movement into the configured tiers and applied the provision percentage per tier to arrive at the suggested provision.',
                 'Compared the suggested provision with the provision recorded and with the NRV write-down on K3.',
                 'Obtained management\'s explanation for each line beyond the first tier and recorded whether the provision was agreed.'],
    flag: (st, d) => d.slow.shortfall != null && d.slow.shortfall < -d.trivial,
    render(st, ctx) {
      const d = ctx.d, S = d.slow;
      return [
        { type: 'controls', items: [
          { key: 'tier1', label: 'Tier 1 ends at (days)', kind: 'number' }, { key: 'tier2', label: 'Tier 2 ends at (days)', kind: 'number' }, { key: 'tier3', label: 'Tier 3 ends at (days)', kind: 'number' },
          { key: 'tierPct1', label: 'Provision % — tier 1', kind: 'number' }, { key: 'tierPct2', label: 'Provision % — tier 2', kind: 'number' },
          { key: 'tierPct3', label: 'Provision % — tier 3', kind: 'number' }, { key: 'tierPct4', label: 'Provision % — beyond tier 3', kind: 'number' } ] },
        ...(S.dateMapped ? [] : [{ type: 'note', tone: 'warn', html: '<b>No last-movement date column was mapped.</b> Ageing cannot be performed from the listing; obtain a stock movement report or age from the count sheets.' }]),
        { type: 'stats', items: [
          { label: 'Suggested provision per policy', value: ctx.money0(S.suggested), cls: S.suggested > ctx.trivial ? 'warn' : 'ok' },
          { label: 'Provision recorded (K)', value: S.provision != null ? ctx.money0(S.provision) : 'enter on K' },
          { label: 'Provision (shortfall) / excess', value: S.shortfall != null ? ctx.money(S.shortfall) : '—', cls: S.shortfall == null ? '' : S.shortfall < -ctx.trivial ? 'bad' : 'ok' },
          { label: 'NRV write-down per K3', value: ctx.money0(d.nrv.writeDown) },
          { label: 'Lines beyond the top tier', value: S.beyondTop, cls: S.beyondTop ? 'bad' : 'ok' },
          { label: 'No movement date', value: `${S.noDate.count} · ${ctx.money0(S.noDate.value)}`, cls: S.noDate.count ? 'warn' : '' },
          { label: 'Provision agreed by management', value: `${S.agreed} of ${S.rows.length}` } ] },
        { type: 'table', title: 'Ageing by days since last movement', columns: [
          { key: 'label', label: 'Tier' }, { key: 'count', label: 'Lines', type: 'int' }, { key: 'value', label: 'Value', type: 'num', sum: true },
          { key: 'pctFrac', label: 'Provision %', type: 'pct', dp: 0 }, { key: 'suggested', label: 'Suggested provision', type: 'num', sum: true, emphasis: true } ],
          rows: [...S.tiers.map(t => ({ ...t, pctFrac: t.pct / 100 })), { label: 'No movement date', count: S.noDate.count, value: S.noDate.value, pctFrac: null, suggested: 0 }],
          footnote: 'Only positive values are provided against. Lines with no movement date are listed below and are not provided for automatically.' },
        { type: 'table', title: 'Lines beyond the first tier', columns: [
          { key: 'item_code', label: 'Item code' }, { key: '__cat', label: 'Category' }, { key: 'description', label: 'Description', wrap: true },
          { key: 'last_movement', label: 'Last movement', type: 'date' }, { key: '__daysSince', label: 'Days', type: 'num', dp: 0 },
          { key: '__tierLabel', label: 'Tier', type: 'chip', chipClass: (v, row) => row.__tier === 3 ? 'bad' : row.__tier === 2 ? 'warn' : 'info' },
          { key: '__value', label: 'Value', type: 'num', sum: true }, { key: '__slowSuggested', label: 'Suggested provision', type: 'num', sum: true, emphasis: true },
          { key: 'explanation', label: 'Management explanation', input: 'text', wide: true },
          { key: 'agreed', label: 'Provision agreed', input: 'select', options: YN },
          { key: 'comment', label: 'Auditor comment', input: 'text', wide: true } ],
          rows: S.rows.map(r => ({ ...r, __rec: r })), maxHeight: '520px', emptyText: 'No line has been without movement beyond the first tier.' },
        { type: 'table', title: 'Lines with no movement date', columns: [
          { key: 'item_code', label: 'Item code' }, { key: '__cat', label: 'Category' }, { key: 'description', label: 'Description', wrap: true },
          { key: '__value', label: 'Value', type: 'num', sum: true }, { key: 'explanation', label: 'Management explanation', input: 'text', wide: true },
          { key: 'agreed', label: 'Provision agreed', input: 'select', options: YN } ],
          rows: S.noDateRows.map(r => ({ ...r, __rec: r })), maxHeight: '300px', emptyText: 'Every line carries a last-movement date.' },
      ];
    } },

  { id: 'count', ref: 'K5', title: 'Count observation',
    objective: 'To obtain evidence of the existence and condition of inventory by attending the physical count (SSA 501 para 4), performing test counts in both directions, and rolling the counted balance forward to the year end where the count was not held at the reporting date.',
    procedures: ['Attended the count, evaluated management\'s instructions and procedures, and observed the performance of the count.',
                 'Performed test counts from the floor to the count sheets and from the count sheets to the floor and recorded every variance.',
                 'Where the count was not at the year end, rolled the counted balance forward through purchases and cost of sales and compared with the year-end listing.'],
    flag: (st, d) => d.count.variances > 0 || (d.count.rf.diff != null && Math.abs(d.count.rf.diff) > d.trivial),
    render(st, ctx) {
      const d = ctx.d, C = d.count;
      const out = [
        { type: 'controls', items: [
          { key: 'countDate', label: 'Count date', kind: 'date', help: `Year end ${ctx.fmtDate(ctx.eng.yearEndDate)}` },
          { key: 'countLocations', label: 'Locations attended', kind: 'text' },
          { key: 'countPctValue', label: '% of inventory value covered by locations attended', kind: 'number' },
          { key: 'countRows', label: 'Test count lines', kind: 'number' } ] },
        { type: 'heading', text: 'Count procedures observed' },
        { type: 'checklist', store: 'countChecks', items: COUNT_CHECKS },
        { type: 'stats', items: [
          { label: 'Test counts recorded', value: `${C.completed} of ${C.rows.length}` },
          { label: 'Variances', value: C.variances, cls: C.variances ? 'bad' : 'ok' },
          { label: 'Coverage by value', value: C.pctValue != null ? ctx.pct(C.pctValue) : '—', cls: C.pctValue != null && C.pctValue < 70 ? 'warn' : '' },
          { label: 'Count date vs year end', value: C.rf.gapDays == null ? 'enter count date' : C.rf.gapDays === 0 ? 'At year end' : `${Math.abs(C.rf.gapDays)} days ${C.rf.gapDays > 0 ? 'before' : 'after'} year end`, cls: C.rf.needed ? 'warn' : 'ok' } ] },
        { type: 'table', title: 'Test counts', columns: [
          { key: 'n', label: '#', type: 'int' },
          { key: 'item', label: 'Item code', input: 'text' }, { key: 'description', label: 'Description', input: 'text', wide: true },
          { key: 'location', label: 'Location / bin', input: 'text' }, { key: 'direction', label: 'Direction', input: 'select', options: ['Floor to sheet', 'Sheet to floor'] },
          { key: 'perSheet', label: 'Qty per count sheet', input: 'number' }, { key: 'perCount', label: 'Qty per test count', input: 'number' },
          { key: 'variance', label: 'Variance', type: 'num', flag: v => v != null && Math.abs(v) > 1e-9 },
          { key: 'unitCost', label: 'Unit cost', input: 'number' }, { key: 'varianceValue', label: 'Variance value', type: 'num', sum: true },
          { key: 'status', label: '', type: 'chip', chipClass: chipStatus },
          { key: 'inListing', label: 'Agreed to final listing', input: 'select', options: YN },
          { key: 'comment', label: 'Comment', input: 'text', wide: true } ],
          rows: C.rows, footnote: 'Floor to sheet tests completeness; sheet to floor tests existence. Every variance should be traced to the final listing and its resolution documented.' },
      ];
      if (C.rf.needed) {
        const R = C.rf;
        out.push({ type: 'heading', text: 'Roll-forward from the count date to the year end' });
        out.push({ type: 'controls', items: [
          { key: 'rfPerCount', label: 'Inventory per count (valued)', kind: 'number' },
          { key: 'rfPurchases', label: 'Add: purchases / production from count date to year end', kind: 'number' },
          { key: 'rfCos', label: 'Less: cost of sales from count date to year end', kind: 'number' },
          { key: 'rfOther', label: 'Other movements (adjustments, write-offs; sign as it affects inventory)', kind: 'number' } ] });
        out.push({ type: 'table', title: 'Roll-forward', columns: [
          { key: 'line', label: '' }, { key: 'amount', label: 'Amount', type: 'num', emphasis: true } ], totals: false,
          rows: [
            { line: 'Inventory per count', amount: R.perCount }, { line: 'Add: purchases / production', amount: R.purchases },
            { line: 'Less: cost of sales', amount: R.cos != null ? -Math.abs(R.cos) : null }, { line: 'Other movements', amount: R.other },
            { line: 'Implied inventory at year end', amount: R.implied }, { line: 'Inventory per listing', amount: d.totals.value },
            { line: 'Difference', amount: R.diff } ],
          footnote: R.diff != null ? (Math.abs(R.diff) > ctx.trivial ? `Difference ${ctx.money(R.diff)} exceeds the trivial threshold; obtain the movement report for the intervening period.` : 'Roll-forward agrees within the trivial threshold.') : 'Enter the roll-forward figures above.' });
      } else if (C.rf.gapDays === 0) {
        out.push({ type: 'note', html: 'The count was held at the year end; no roll-forward is required.' });
      }
      return out;
    } },

  { id: 'cutoff', ref: 'K6', title: 'Cut-off',
    objective: 'To confirm that goods received and delivered around the year end are recorded in inventory, payables and receivables in the correct period.',
    procedures: ['Recorded the last goods received notes and delivery orders before the year end and the first after, as noted at the count and from the sequence.',
                 'For each document, traced whether the goods are included in the year-end listing and whether the purchase or sale is recorded in the ledger, and compared with the correct treatment.'],
    flag: (st, d) => d.cutoff.errors > 0,
    render(st, ctx) {
      const d = ctx.d, K = d.cutoff;
      return [
        { type: 'controls', items: [ { key: 'cutoffRows', label: 'Cut-off documents to test', kind: 'number' } ] },
        { type: 'note', html: '<b>Correct treatment:</b> ' + CUTOFF_TYPES.map(t => `<em>${t.key}</em> — inventory ${t.inv}, ${t.ledgerName} ${t.ledger}`).join('; ') + '.' },
        { type: 'stats', items: [
          { label: 'Documents tested', value: `${K.tested} of ${K.rows.length}` },
          { label: 'Cut-off errors', value: K.errors, cls: K.errors ? 'bad' : 'ok' },
          { label: 'Value of errors', value: ctx.money0(K.errorValue), cls: K.errorValue > ctx.trivial ? 'bad' : '' } ] },
        { type: 'table', title: 'Goods received notes and delivery orders around the year end', columns: [
          { key: 'n', label: '#', type: 'int' },
          { key: 'type', label: 'Document', input: 'select', options: CUTOFF_TYPES.map(t => t.key) },
          { key: 'docNo', label: 'Document no.', input: 'text' }, { key: 'docDate', label: 'Date', input: 'date' },
          { key: 'counterparty', label: 'Supplier / customer', input: 'text' }, { key: 'amount', label: 'Amount', input: 'number' },
          { key: 'inInventory', label: 'In year-end inventory', input: 'select', options: YN },
          { key: 'inLedger', label: 'In payables / receivables', input: 'select', options: YN },
          { key: 'expected', label: 'Correct treatment' },
          { key: 'assessment', label: 'Assessment', type: 'chip', chipClass: chipStatus },
          { key: 'correct', label: 'Auditor conclusion', input: 'select', options: ['Correct', 'Error — adjust', 'Error — immaterial'] },
          { key: 'comment', label: 'Comment', input: 'text', wide: true } ],
          rows: K.rows, footnote: 'The assessment compares the two answers with the correct treatment for the document type. Record the last document numbers noted at the count in the findings below.' },
      ];
    } },

  { id: 'cogs', ref: 'K7', title: 'Cost of sales reconciliation',
    objective: 'To reconcile the movement in inventory to cost of sales: opening inventory plus purchases, direct labour and overheads absorbed, less cost of sales per the profit or loss, should equal the closing listing.',
    procedures: ['Obtained opening inventory, purchases, direct labour, production overheads and cost of sales for the year.',
                 'Computed the implied closing inventory and compared it with the year-end listing; investigated the difference.'],
    flag: (st, d) => d.cogs.available && Math.abs(d.cogs.diff) > d.cogs.tol,
    render(st, ctx) {
      const d = ctx.d, G = d.cogs;
      return [
        { type: 'controls', items: [
          { key: 'cogsOpening', label: 'Opening inventory (prior year closing)', kind: 'number' },
          { key: 'cogsPurchases', label: 'Purchases for the year', kind: 'number' },
          { key: 'cogsLabour', label: 'Direct labour capitalised into inventory', kind: 'number' },
          { key: 'cogsOverhead', label: 'Production overheads absorbed', kind: 'number' },
          { key: 'cogsPerPL', label: 'Cost of sales per profit or loss', kind: 'number' },
          { key: 'cogsTol', label: 'Reconciliation tolerance', kind: 'number', help: `0 = trivial threshold (${ctx.money0(ctx.trivial)})` } ] },
        { type: 'table', title: 'Reconciliation', columns: [ { key: 'line', label: '' }, { key: 'amount', label: 'Amount', type: 'num', emphasis: true } ], totals: false,
          rows: [
            { line: 'Opening inventory', amount: G.opening }, { line: 'Add: purchases', amount: G.purchases },
            { line: 'Add: direct labour', amount: G.labour }, { line: 'Add: production overheads absorbed', amount: G.overhead },
            { line: 'Goods available for sale', amount: G.goodsAvailable },
            { line: 'Less: cost of sales per profit or loss', amount: G.perPL != null ? -Math.abs(G.perPL) : null },
            { line: 'Implied closing inventory', amount: G.implied }, { line: 'Closing inventory per listing (K)', amount: d.totals.value },
            { line: 'Difference — listing less implied', amount: G.diff },
            { line: 'Cost of sales implied by the listing', amount: G.impliedCos } ] },
        { type: 'stats', items: [
          { label: 'Difference', value: G.diff != null ? ctx.money(G.diff) : 'enter the figures above', cls: G.diff == null ? '' : Math.abs(G.diff) > G.tol ? 'bad' : 'ok' },
          { label: 'Tolerance', value: ctx.money0(G.tol) },
          { label: 'Gross margin check', value: d.cos ? `Inventory days ${d.invDays}` : '—' } ] },
        { type: 'note', html: G.available && Math.abs(G.diff) > G.tol
            ? `<b>The reconciliation does not agree.</b> A positive difference means the listing is higher than the movement implies: consider unrecorded cost of sales, purchases cut-off (K6), or costing changes (K2). A negative difference points to unrecorded purchases or inventory not on the listing.`
            : 'A reconciliation within tolerance corroborates the completeness of both cost of sales and the closing listing.' },
      ];
    } },

  { id: 'conclusion', ref: 'K9', title: 'Exceptions & conclusion', kind: 'conclusion' },
];

function suggestConclusion(st, ctx) {
  const d = ctx.d || {};
  const exc = (st.exceptions || []).filter(e => e.disposition === 'open');
  const parts = [];
  parts.push(`Inventory per the listing of ${ctx.money0(d.totals?.value)} ${d.tbGrossTotal != null ? (Math.abs(d.totals.value - d.tbGrossTotal) <= (d.castTol || 0.01) ? 'agrees to the trial balance' : 'does not agree to the trial balance (see K)') : 'has not yet been agreed to the trial balance'}.`);
  parts.push(`Extension and casting (K1) identified ${d.anomalyRows?.length || 0} line(s) requiring attention.`);
  parts.push(`Cost testing (K2) covered ${ctx.pct(d.costTest?.coverage)} of value with ${d.costTest?.vouched || 0} of ${d.costTest?.selected?.length || 0} selections vouched.`);
  parts.push(`The write-down required to net realisable value (K3) is ${ctx.money0(d.nrv?.writeDown)} and the slow-moving policy (K4) suggests ${ctx.money0(d.slow?.suggested)}, against a recorded provision of ${d.tbProvision != null ? ctx.money0(Math.abs(d.tbProvision)) : '[not entered]'}.`);
  parts.push(`${exc.length} exception(s) remain open. Subject to their resolution, inventory is [fairly stated / misstated by ...] at the reporting date.`);
  return parts.join(' ');
}

return {
  code: 'INV', name: 'Inventory', group: 'Assets', accepts: '.xlsx,.xlsm,.csv',
  blurb: 'The inventory audit file: lead, extension and casting, cost testing, NRV, slow-moving provision, count observation, cut-off and the cost of sales reconciliation — from one uploaded listing.',
  objective: 'To obtain sufficient appropriate audit evidence over the existence, completeness, valuation (lower of cost and net realisable value) and cut-off of inventory.',
  fields, tests, compute, pages, defaultConfig, STANDARD_COLUMNS, CUTOFF_TYPES, COUNT_CHECKS,
  procedures: pages.flatMap(p => p.procedures || []),
  columns: STANDARD_COLUMNS,
  suggestConclusion,
};
})();

Modules.register(INVModule);
