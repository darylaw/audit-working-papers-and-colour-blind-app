/* ==========================================================================
   loan.js -- Borrowings as an auditor actually works it.

   One uploaded loan schedule (one line per facility) feeds:
     V3    Lead schedule                     V3.4  Bank confirmation control
     V3.1  Movement reconciliation           V3.5  Covenant compliance
     V3.2  Interest recalculation            V3.6  Security and guarantees
     V3.3  Current / non-current split
   ========================================================================== */

const LOANModule = (() => {
const r2 = n => n == null || isNaN(n) ? null : Math.round(n * 100) / 100;
const num = v => (v === '' || v == null || isNaN(Number(v))) ? null : Number(v);
const inp = (cfg, key, k) => num(cfg[key + ':' + k]);
const txt = (cfg, key, k) => { const v = cfg[key + ':' + k]; return v == null ? '' : String(v); };
const monthDiff = (a, b) => (a && b) ? (b.getUTCFullYear() - a.getUTCFullYear()) * 12 + (b.getUTCMonth() - a.getUTCMonth()) : null;
const addMonths = (d, n) => d ? new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + n, Math.min(d.getUTCDate(), 28))) : null;

/* Annuity instalment for principal P at annual rate r% over n months. */
const annuity = (P, r, n) => { if (!(P > 0) || !(n > 0)) return null; const m = (r || 0) / 1200; return m === 0 ? P / n : P * m / (1 - Math.pow(1 + m, -n)); };

/* Reducing-balance amortisation: returns { interest, principal, closing, months } over `months` periods. */
function amortise(balance, rate, instalment, months) {
  let bal = Math.max(0, balance || 0), interest = 0, principal = 0, run = 0;
  const m = (rate || 0) / 1200;
  for (let i = 0; i < months; i++) {
    if (bal <= 0.005) break;
    const iv = bal * m;
    const pv = instalment > 0 ? Math.max(0, Math.min(bal, instalment - iv)) : 0;
    interest += iv; principal += pv; bal -= pv; run++;
  }
  return { interest: r2(interest), principal: r2(principal), closing: r2(bal), months: run };
}

const SECURITY_TYPES = ['Legal mortgage', 'Fixed charge', 'Floating charge', 'Debenture', 'Pledge of deposit', 'Corporate guarantee', 'Personal guarantee', 'Unsecured', 'Other'];
const COVENANT_TYPES = ['Minimum', 'Maximum'];

/* ---------------------------------------------------------------- fields */
const fields = [
  { key:'facility', label:'Facility', role:'key', type:'text', required:true, dupKey:true,
    synonyms:['Facility','Loan','Facility Name','Loan Description','Type of Facility','Loan Name','Borrowing','Description','Facility Type','Nature of Loan','贷款','借款','借款名称'] },
  { key:'lender', label:'Lender', type:'text',
    synonyms:['Lender','Bank','Financier','Institution','Bank / Lender','Financial Institution','Creditor','Counterparty','贷款银行','贷款人'] },
  { key:'account_no', label:'Account / facility number', type:'text', dupKey:true,
    synonyms:['Account No','Loan Account','Facility No','Ref No','Account Number','Loan No','Facility Reference','Agreement No','Loan Account No','账号','合同编号'] },
  { key:'currency', label:'Currency', type:'text', synonyms:['Currency','CCY','币种'] },   // no 'Cur'/'Curr': they substring-match "Current Portion"
  { key:'principal', label:'Principal / facility amount', type:'number', required:true,
    synonyms:['Principal','Loan Amount','Facility Limit','Original Amount','Amount Drawn','Facility Amount','Limit','Original Principal','Amount Borrowed','本金','借款金额'] },
  { key:'rate', label:'Interest rate % p.a.', type:'number', required:true,
    synonyms:['Interest Rate','Rate %','Rate','Effective Rate','Interest Rate %','Rate p.a.','Interest %','Interest Rate (p.a.)','Nominal Rate','利率','年利率'] },
  { key:'start', label:'Drawdown date', type:'date',
    synonyms:['Drawdown Date','Start Date','Commencement','Loan Date','Date of Drawdown','Disbursement Date','Agreement Date','Commencement Date','放款日期','起始日期'] },
  { key:'maturity', label:'Maturity date', type:'date',
    synonyms:['Maturity Date','Maturity','Expiry Date','Final Repayment Date','End Date','Due Date','到期日'] },
  { key:'tenor', label:'Tenor (months)', type:'number', required:true,
    synonyms:['Tenor (Months)','Term','Tenure','No. of Instalments','Tenor','Term (Months)','Tenure (Months)','Instalments','Number of Instalments','期限','期数'] },
  { key:'instalment', label:'Instalment', type:'number', required:true,
    synonyms:['Monthly Instalment','Instalment','Repayment','EMI','Monthly Repayment','Instalment Amount','Monthly Payment','Installment','每月还款'] },
  { key:'bal_open', label:'Opening balance', type:'number', required:true,
    synonyms:['Opening Balance','Balance B/F','Bal at Start','Balance Brought Forward','Opening','Balance at 1 Jan','Opening Bal','B/F','期初余额'] },
  { key:'drawdowns', label:'Drawdowns in the year', type:'number',
    synonyms:['Drawdowns','Additions','New Loans','Drawdown','Amount Drawn in Year','Additional Drawdown','Proceeds','本期借入'] },
  { key:'repaid', label:'Principal repaid in the year', type:'number', required:true,
    synonyms:['Repayments','Principal Repaid','Paid','Principal Repayments','Repaid','Capital Repaid','Repayment of Principal','Principal Paid','Less: Repayments','本期归还','本期偿还'] },
  { key:'interest', label:'Interest charged in the year', type:'number', required:true,
    synonyms:['Interest Charged','Interest Expense','Interest','Finance Cost','Interest for the Year','Interest Paid','Finance Charges','利息','利息费用'] },
  { key:'bal_close', label:'Closing balance', type:'number', required:true,
    synonyms:['Closing Balance','Balance C/F','Outstanding','Balance Carried Forward','Closing','Outstanding Balance','Balance at Year End','Closing Bal','C/F','期末余额'] },
  { key:'current', label:'Current portion per client', type:'number',
    synonyms:['Current Portion','Within 1 Year','Due < 1 Yr','Current','Due Within One Year','Repayable Within 1 Year','Short-term Portion','Within One Year','一年内到期'] },
  { key:'noncurrent', label:'Non-current portion per client', type:'number',
    synonyms:['Non-Current Portion','After 1 Year','Due > 1 Yr','Non-Current','Due After One Year','Repayable After 1 Year','Long-term Portion','After One Year','一年以上'] },
  { key:'security', label:'Security per schedule', type:'text', synonyms:['Security','Collateral','Secured By','Charge','Nature of Security','担保'] }
];

const STANDARD_COLUMNS = [
  { key:'facility', label:'Facility' }, { key:'lender', label:'Lender' }, { key:'account_no', label:'Account' },
  { key:'principal', label:'Principal', type:'num', edit:true }, { key:'rate', label:'Rate %', type:'num', dp:2, edit:true }, { key:'start', label:'Drawdown', type:'date', edit:true },
  { key:'tenor', label:'Tenor (m)', type:'num', dp:0, edit:true }, { key:'instalment', label:'Instalment', type:'num', edit:true },
  { key:'bal_open', label:'Opening', type:'num', edit:true }, { key:'__draw', label:'Drawdowns', type:'num' }, { key:'__repay', label:'Repaid', type:'num' },
  { key:'interest', label:'Interest', type:'num', edit:true }, { key:'bal_close', label:'Closing', type:'num', edit:true, emphasis:true },
  { key:'current', label:'Current', type:'num', edit:true }, { key:'noncurrent', label:'Non-current', type:'num', edit:true }
];

const defaultConfig = () => ({
  castTol: 0.01,
  pnlInterest: '',                 // finance cost per P&L
  intMethod: 'amort',              // amort | average | opening
  intTolPct: 5, intTol: '',        // blank = trivial
  splitBasis: 'client',            // recompute the next 12 months from the client's closing balance or the audited one
  splitTol: '',                    // blank = trivial
  covRows: 4
});

/* ============================================================ COMPUTE */
function compute(recs, cfg, eng) {
  const ye = eng.yearEndDate, fys = eng.fyStartDate;
  const pm = eng.materiality?.pm || 0, trivial = eng.materiality?.trivial || 0;
  const tol = Number(cfg.castTol) || 0.01;
  const intTol = cfg.intTol !== '' && cfg.intTol != null ? Number(cfg.intTol) : trivial;
  const intTolPct = Number(cfg.intTolPct) >= 0 ? Number(cfg.intTolPct) : 5;
  const splitTol = cfg.splitTol !== '' && cfg.splitTol != null ? Number(cfg.splitTol) : trivial;
  const live = recs.filter(r => !r.__excluded);

  for (const r of recs) {
    r.__displayKey = r.facility || r.account_no || ('row ' + r.__srcRow);
    r.__facKey = Core.keyify((r.facility || '') + '|' + (r.account_no || '')) || ('row' + r.__srcRow);
    /* two columns headed alike (instalment / repayment): a negative "instalment" beside a positive "repaid" is the swap */
    r.__swapped = false;
    if (r.instalment != null && r.instalment < -0.005 && (r.repaid == null || r.repaid >= 0) && Math.abs(r.instalment) > Math.abs(r.repaid || 0)) {
      const a = r.instalment; r.instalment = r.repaid; r.repaid = a; r.__swapped = true;
    }
    r.__draw = Math.abs(r.drawdowns || 0);
    r.__repay = Math.abs(r.repaid || 0);
    r.__lenderKey = r.lender || '(lender not stated)';
  }

  for (const r of live) {
    /* ---- V3.1 movement ------------------------------------------------ */
    r.__closeCalc = r2((r.bal_open || 0) + r.__draw - r.__repay);
    r.__moveDiff = r.bal_close != null ? r2(r.bal_close - r.__closeCalc) : null;
    r.__negative = r.bal_close != null && r.bal_close < -0.005;
    r.__overRepaid = r.__repay > (r.bal_open || 0) + r.__draw + tol;

    /* ---- tenor / maturity -------------------------------------------- */
    r.__maturity = r.maturity || (r.start && r.tenor > 0 ? addMonths(r.start, Math.round(r.tenor)) : null);
    r.__elapsed = (r.start && ye) ? Math.max(0, monthDiff(r.start, ye)) : null;
    r.__remaining = (r.tenor > 0 && r.__elapsed != null) ? Math.max(0, Math.round(r.tenor) - r.__elapsed) : null;
    r.__drawnInYear = !!(r.start && fys && r.start >= fys && r.start <= ye);
    r.__monthsInYear = r.__drawnInYear ? Math.max(0, Math.min(12, monthDiff(r.start, ye))) : 12;

    /* ---- V3.2 interest ------------------------------------------------ */
    const startBal = (r.bal_open || 0) > 0.005 ? r.bal_open : r.__draw;
    const am = amortise(startBal, r.rate, r.instalment, r.__monthsInYear);
    r.__amort = am;
    const avg = ((r.bal_open || 0) + (r.bal_close || 0)) / 2;
    if (cfg.intMethod === 'average') r.__intAudit = r2(avg * (r.rate || 0) / 100 * r.__monthsInYear / 12);
    else if (cfg.intMethod === 'opening') r.__intAudit = r2(startBal * (r.rate || 0) / 100 * r.__monthsInYear / 12);
    else r.__intAudit = am.interest;
    r.__intDiff = r.interest != null ? r2(r.interest - r.__intAudit) : null;
    r.__intTolLine = Math.max(intTol, Math.abs(r.__intAudit || 0) * intTolPct / 100);
    r.__intBreak = r.__intDiff != null && Math.abs(r.__intDiff) > r.__intTolLine;
    r.__effRate = avg > 0 && r.__monthsInYear > 0 ? r2((r.interest || 0) / avg * 12 / r.__monthsInYear * 100) : null;
    r.__instAudit = r2(annuity(r.principal, r.rate, r.tenor));
    r.__instDiff = (r.instalment != null && r.__instAudit != null) ? r2(r.instalment - r.__instAudit) : null;
    r.__instBreak = r.__instDiff != null && r.__instAudit > 0 && Math.abs(r.__instDiff) / r.__instAudit > 0.01;
    r.__repayAudit = am.principal;
    r.__repayDiff = r2(r.__repay - am.principal);

    /* ---- V3.3 split --------------------------------------------------- */
    const closeBasis = cfg.splitBasis === 'audit' ? r.__closeCalc : (r.bal_close ?? r.__closeCalc);
    r.__splitBase = closeBasis;
    let cur;
    if (r.instalment > 0) cur = amortise(closeBasis, r.rate, r.instalment, 12).principal;
    else cur = (r.__maturity && ye && monthDiff(ye, r.__maturity) <= 12) ? closeBasis : 0;   // bullet: whole balance current if it matures within a year
    r.__curAudit = r2(Math.min(Math.max(0, closeBasis || 0), cur || 0));
    r.__ncAudit = r2((closeBasis || 0) - r.__curAudit);
    r.__splitSum = (r.current != null || r.noncurrent != null) ? r2((r.current || 0) + (r.noncurrent || 0)) : null;
    r.__splitCast = (r.__splitSum != null && r.bal_close != null) ? r2(r.__splitSum - r.bal_close) : null;
    r.__splitExplainedByMove = r.__splitCast != null && r.__moveDiff != null && Math.abs(r2(r.__splitCast + r.__moveDiff)) <= tol;
    r.__curDiff = r.current != null ? r2(r.current - r.__curAudit) : null;
    r.__curBreak = r.__curDiff != null && Math.abs(r.__curDiff) > splitTol;

    /* ---- V3.4 confirmation ------------------------------------------- */
    const k = r.__facKey;
    r.__confBal = inp(cfg, 'confBal', k); r.__confRate = inp(cfg, 'confRate', k);
    r.__confDiff = (r.__confBal != null && r.bal_close != null) ? r2(r.__confBal - r.bal_close) : null;
    r.__confRateDiff = (r.__confRate != null && r.rate != null) ? r2(r.__confRate - r.rate) : null;
    r.__confRecd = txt(cfg, 'confRecd', k);

    /* ---- V3 lead ------------------------------------------------------ */
    r.__tb = inp(cfg, 'tb', k); r.__py = inp(cfg, 'py', k);
    r.__tbDiff = (r.__tb != null && r.bal_close != null) ? r2(r.bal_close - r.__tb) : null;
    r.__pyDiff = (r.__py != null) ? r2((r.bal_open || 0) - r.__py) : null;
    r.__movement = (r.__py != null && r.bal_close != null) ? r2(r.bal_close - r.__py) : null;
  }

  const sum = f => r2(live.reduce((s, r) => s + (f(r) || 0), 0));
  const totals = { principal: sum(r => r.principal), open: sum(r => r.bal_open), draw: sum(r => r.__draw), repay: sum(r => r.__repay), interest: sum(r => r.interest),
    close: sum(r => r.bal_close), closeCalc: sum(r => r.__closeCalc), current: sum(r => r.current), noncurrent: sum(r => r.noncurrent),
    curAudit: sum(r => r.__curAudit), ncAudit: sum(r => r.__ncAudit), intAudit: sum(r => r.__intAudit), tb: sum(r => r.__tb), py: sum(r => r.__py), conf: sum(r => r.__confBal) };
  totals.moveDiff = r2(totals.close - totals.closeCalc);
  totals.intDiff = r2(totals.interest - totals.intAudit);
  totals.splitCast = r2(totals.current + totals.noncurrent - totals.close);
  const pnl = num(cfg.pnlInterest);
  const lead = { rows: live, totals, pnl, pnlDiff: pnl != null ? r2(totals.interest - pnl) : null,
    tbEntered: live.filter(r => r.__tb != null).length, tbBreaks: live.filter(r => r.__tbDiff != null && Math.abs(r.__tbDiff) > tol),
    pyBreaks: live.filter(r => r.__pyDiff != null && Math.abs(r.__pyDiff) > tol),
    byLender: Object.values(live.reduce((m, r) => { const l = m[r.__lenderKey] || (m[r.__lenderKey] = { lender:r.__lenderKey, count:0, close:0, current:0 }); l.count++; l.close += r.bal_close || 0; l.current += r.__curAudit || 0; return m; }, {}))
      .map(l => ({ ...l, close: r2(l.close), current: r2(l.current), share: totals.close ? r2(l.close / totals.close * 100) : 0 })).sort((a, b) => b.close - a.close) };

  const movement = { breaks: live.filter(r => r.__moveDiff != null && Math.abs(r.__moveDiff) > tol), negative: live.filter(r => r.__negative), overRepaid: live.filter(r => r.__overRepaid), swapped: live.filter(r => r.__swapped) };
  const interest = { method: cfg.intMethod || 'amort', tol: intTol, tolPct: intTolPct, breaks: live.filter(r => r.__intBreak), instBreaks: live.filter(r => r.__instBreak), totals };
  const split = { basis: cfg.splitBasis || 'client', tol: splitTol, castBreaks: live.filter(r => r.__splitCast != null && Math.abs(r.__splitCast) > tol && !r.__splitExplainedByMove),
    castExplained: live.filter(r => r.__splitCast != null && Math.abs(r.__splitCast) > tol && r.__splitExplainedByMove), curBreaks: live.filter(r => r.__curBreak), totals };
  const confirmations = { received: live.filter(r => r.__confRecd === 'Y').length, breaks: live.filter(r => r.__confDiff != null && Math.abs(r.__confDiff) > tol),
    rateBreaks: live.filter(r => r.__confRateDiff != null && Math.abs(r.__confRateDiff) > 0.005), agreed: live.filter(r => r.__confDiff != null && Math.abs(r.__confDiff) <= tol).length };

  /* ---- V3.5 covenants -------------------------------------------------- */
  const nCov = Math.max(0, Math.min(40, Math.round(Number(cfg.covRows) || 0)));
  const covenants = [];
  for (let i = 1; i <= nCov; i++) {
    const k = 'cov' + i;
    const desc = txt(cfg, 'covDesc', k), type = txt(cfg, 'covType', k), thr = inp(cfg, 'covThreshold', k), act = inp(cfg, 'covActual', k);
    if (!desc && thr == null && act == null) continue;
    let status = 'Not tested';
    if (thr != null && act != null && type) status = (type === 'Minimum' ? act >= thr - 1e-9 : act <= thr + 1e-9) ? 'Complied' : 'Breached';
    covenants.push({ key:k, i, facility: txt(cfg, 'covFacility', k), desc, type, thr, act, status, headroom: (thr != null && act != null) ? r2(type === 'Minimum' ? act - thr : thr - act) : null });
  }
  const covenant = { rows: covenants, breaches: covenants.filter(c => c.status === 'Breached'), tested: covenants.filter(c => c.status !== 'Not tested').length };

  /* ---- V3.6 security --------------------------------------------------- */
  const security = live.map(r => { const k = r.__facKey; return { r, type: txt(cfg, 'secType', k), asset: txt(cfg, 'secAsset', k), carrying: inp(cfg, 'secCarrying', k), guarantor: txt(cfg, 'secGuarantor', k),
    sighted: txt(cfg, 'secSighted', k), disclosed: txt(cfg, 'secDisclosed', k) }; });
  const sec = { rows: security, secured: r2(security.filter(s => s.type && s.type !== 'Unsecured').reduce((a, s) => a + (s.r.bal_close || 0), 0)),
    unsecured: r2(security.filter(s => s.type === 'Unsecured').reduce((a, s) => a + (s.r.bal_close || 0), 0)), unclassified: security.filter(s => !s.type).length,
    pledged: r2(security.reduce((a, s) => a + (s.carrying || 0), 0)), guarantees: security.filter(s => /guarantee/i.test(s.type) || s.guarantor).length };

  return { lead, totals, movement, interest, split, confirmations, covenant, security: sec, facilities: live, pm, trivial, tol };
}

/* ============================================================== TESTS */
const tests = [
  { id:'EX-LOAN-01', label:'Movement does not reconcile to the closing balance', basis:'V3.1',
    fn:(r, cfg) => r.__moveDiff != null && Math.abs(r.__moveDiff) > (Number(cfg.castTol) || 0.01) &&
      { expected: r.__closeCalc, actual: r.bal_close, difference: r.__moveDiff, cell: r['__cell_bal_close'],
        detail:`Opening ${(r.bal_open || 0).toFixed(2)} + drawdowns ${r.__draw.toFixed(2)} − repayments ${r.__repay.toFixed(2)} = ${r.__closeCalc.toFixed(2)}; closing per schedule ${r.bal_close.toFixed(2)}. Obtain the lender statement and identify the missing movement.` } },
  { id:'EX-LOAN-02', label:'Current and non-current portions do not cast to the closing balance', basis:'V3.3',
    fn:(r, cfg) => r.__splitCast != null && Math.abs(r.__splitCast) > (Number(cfg.castTol) || 0.01) && !r.__splitExplainedByMove &&
      { expected: r.bal_close, actual: r.__splitSum, difference: r.__splitCast, cell: r['__cell_current'],
        detail:`Current ${(r.current || 0).toFixed(2)} + non-current ${(r.noncurrent || 0).toFixed(2)} = ${r.__splitSum.toFixed(2)} against closing ${r.bal_close.toFixed(2)}. Current portion per audit ${r.__curAudit.toFixed(2)}.` } },
  { id:'EX-LOAN-03', label:'Interest charged inconsistent with the stated rate', basis:'V3.2',
    fn:(r) => r.__intBreak && { expected: r.__intAudit, actual: r.interest, difference: r.__intDiff, cell: r['__cell_interest'],
      detail:`Recomputed at ${r.rate}% on the reducing balance over ${r.__monthsInYear} months gives ${r.__intAudit.toFixed(2)}; effective rate implied by the charge ${r.__effRate != null ? r.__effRate.toFixed(2) + '%' : 'n/a'}. Agree to the lender's interest advices.` } },
  { id:'EX-LOAN-04', label:'Current portion differs from the principal falling due in the next twelve months', basis:'V3.3', severity:'informational',
    fn:(r) => r.__curBreak && { expected: r.__curAudit, actual: r.current, difference: r.__curDiff, cell: r['__cell_current'],
      detail:`Principal repayable in the twelve months after the reporting date per the amortisation is ${r.__curAudit.toFixed(2)}` } },
  { id:'EX-LOAN-05', scope:'population', label:'Balance per bank confirmation differs from the schedule', basis:'V3.4',
    fn:(recs, cfg, eng, d) => d.confirmations.breaks.map(r => ({ key: r.__displayKey, expected: r.bal_close, actual: r.__confBal, difference: r.__confDiff, detail:'Confirmed balance does not agree to the closing balance per the schedule — reconcile for accrued interest or unposted repayments' })) },
  { id:'EX-LOAN-06', scope:'population', label:'Covenant breached at the reporting date', basis:'V3.5', severity:'above-trivial',
    fn:(recs, cfg, eng, d) => d.covenant.breaches.map(c => ({ key: `${c.facility || 'Covenant ' + c.i}: ${c.desc}`, expected: c.thr, actual: c.act, difference: null,
      detail:`${c.type} ${c.thr} required; actual ${c.act}. Consider whether the lender can demand repayment — the liability may need to be classified as current (IAS 1 para 74) — and the going concern implications.` })) },
  { id:'EX-LOAN-07', label:'Stated instalment differs from the annuity on principal, rate and tenor', basis:'V3.2', severity:'informational',
    fn:(r) => r.__instBreak && { expected: r.__instAudit, actual: r.instalment, difference: r.__instDiff, cell: r['__cell_instalment'], detail:'Instalment does not follow from the stated principal, rate and tenor — confirm the repayment profile in the facility letter' } },
  { id:'EX-LOAN-08', label:'Repayments exceed opening balance plus drawdowns, or closing balance negative', basis:'V3.1',
    fn:(r) => (r.__overRepaid || r.__negative) && { actual: r.bal_close, difference: r.__negative ? r.bal_close : r2(r.__repay - (r.bal_open || 0) - r.__draw), cell: r['__cell_repaid'] } },
  { id:'EX-LOAN-09', scope:'population', label:'Interest rate per confirmation differs from the schedule', basis:'V3.4', severity:'informational',
    fn:(recs, cfg, eng, d) => d.confirmations.rateBreaks.map(r => ({ key: r.__displayKey, expected: r.rate, actual: r.__confRate, difference: null, detail:'Rate confirmed by the lender differs from the rate used in the schedule — recompute interest at the confirmed rate' })) },
  { id:'EX-LOAN-10', label:'Instalment and repayment columns appear transposed', basis:'V3.0a', severity:'informational',
    fn:(r) => r.__swapped && { detail:'A negative instalment beside a positive repayment; the two values were swapped for the recalculation. Confirm the column mapping.' } },
  { id:'EX-LOAN-20', scope:'population', label:'Schedule does not agree to the trial balance', basis:'V3',
    fn:(recs, cfg, eng, d) => d.lead.tbBreaks.map(r => ({ key: r.__displayKey, expected: r.__tb, actual: r.bal_close, difference: r.__tbDiff, detail:'Closing balance per schedule against the loan account in the trial balance' })) },
  { id:'EX-LOAN-21', scope:'population', label:'Interest per schedule does not agree to finance cost in the profit or loss', basis:'V3',
    fn:(recs, cfg, eng, d) => d.lead.pnlDiff != null && Math.abs(d.lead.pnlDiff) > (Number(cfg.castTol) || 0.01) &&
      { key:'Interest charged', expected: d.lead.pnl, actual: d.totals.interest, difference: d.lead.pnlDiff, detail:'Consider accrued interest, other finance costs and capitalised interest' } },
  { id:'EX-LOAN-22', scope:'population', label:'Opening balance does not agree to the prior year closing balance', basis:'V3',
    fn:(recs, cfg, eng, d) => d.lead.pyBreaks.map(r => ({ key: r.__displayKey, expected: r.__py, actual: r.bal_open, difference: r.__pyDiff, detail:'Opening balance per schedule against the prior year audited closing balance' })) }
];

/* ============================================================== PAGES */
const yn = ['Y', 'N'];
const facRow = r => ({ __rec:r, __key:r.__facKey, facility:r.facility, lender:r.lender, account:r.account_no, principal:r.principal, rate:r.rate != null ? r.rate / 100 : null, start:r.start, tenor:r.tenor, instalment:r.instalment,
  open:r.bal_open, draw:r.__draw || null, repay:r.__repay || null, interest:r.interest, close:r.bal_close });
const FAC_COLS = [{ key:'facility', label:'Facility', emphasis:true }, { key:'lender', label:'Lender' }, { key:'account', label:'Account' }];

const pages = [
  { id:'source',  ref:'V3.0',  title:'Source data',     kind:'source' },
  { id:'cleaned', ref:'V3.0a', title:'Cleaned listing', kind:'cleaned' },
  { id:'mapping', ref:'V3.0b', title:'Column mapping',  kind:'mapping' },

  { id:'lead', ref:'V3', title:'Lead schedule',
    objective:'To agree borrowings per the loan schedule to the trial balance and to the prior year audited figures for every facility, and to agree interest charged to finance cost in the profit or loss.',
    procedures:['Cast the loan schedule by facility and summarised borrowings by lender.',
                'Agreed each closing balance to the loan account in the trial balance and each opening balance to the prior year audited closing balance.',
                'Agreed total interest charged per the schedule to finance cost in the profit or loss.'],
    render(st, ctx) {
      const d = ctx.d, T = d.totals, Lz = d.lead, m0 = ctx.money0, money = ctx.money;
      return [
        { type:'controls', items:[
          { key:'pnlInterest', label:'Finance cost per profit or loss (interest on borrowings)', kind:'number' },
          { key:'castTol', label:'Tolerance for differences', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Facilities', value: d.facilities.length }, { label:'Opening balance', value: m0(T.open) }, { label:'Drawdowns', value: m0(T.draw) }, { label:'Repayments', value: m0(T.repay) },
          { label:'Closing balance', value: m0(T.close) }, { label:'Of which current (per audit)', value: m0(T.curAudit) },
          { label:'Interest charged', value: m0(T.interest) },
          { label:'Interest − P&L finance cost', value: Lz.pnlDiff == null ? '— enter —' : money(Lz.pnlDiff), cls: Lz.pnlDiff == null ? '' : Math.abs(Lz.pnlDiff) > 0.01 ? 'bad' : 'ok' } ] },
        { type:'table', title:'Borrowings by facility — schedule vs trial balance vs prior year', columns:[...FAC_COLS,
          { key:'py', label:'Prior year audited closing', input:'number' }, { key:'open', label:'Opening per schedule', type:'num', sum:true },
          { key:'pyDiff', label:'Opening − PY', type:'num', flag: v => v != null && Math.abs(v) > 0.01 },
          { key:'close', label:'Closing per schedule', type:'num', sum:true }, { key:'tb', label:'Per trial balance', input:'number' },
          { key:'tbDiff', label:'Schedule − TB', type:'num', flag: v => v != null && Math.abs(v) > 0.01 },
          { key:'movement', label:'Movement vs PY', type:'num' }, { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: d.facilities.map(r => ({ ...facRow(r), pyDiff: r.__pyDiff, tbDiff: r.__tbDiff, movement: r.__movement, __cls: (r.__tbDiff != null && Math.abs(r.__tbDiff) > 0.01) ? 'flag' : '' })),
          footnote:'Differences to the trial balance are raised as EX-LOAN-20; opening balances not agreeing to the prior year as EX-LOAN-22.' },
        { type:'table', title:'Borrowings by lender', columns:[{ key:'lender', label:'Lender' }, { key:'count', label:'Facilities', type:'int' }, { key:'close', label:'Closing balance', type:'num', sum:true }, { key:'current', label:'Current per audit', type:'num', sum:true }, { key:'share', label:'Share', type:'pct' }],
          rows: Lz.byLender.map(l => ({ ...l, share: l.share / 100 })) }
      ];
    },
    flag(st, d) { return d.lead.tbBreaks.length > 0 || (d.lead.pnlDiff != null && Math.abs(d.lead.pnlDiff) > 0.01); } },

  { id:'movement', ref:'V3.1', title:'Movement reconciliation',
    objective:'To prove, for every facility, that the opening balance plus drawdowns less repayments equals the closing balance, and that repayments and drawdowns in the year are supported.',
    procedures:['Recomputed the closing balance of each facility from the opening balance, drawdowns and repayments and compared it with the closing balance per the schedule.',
                'Cast the columns and agreed total repayments to the bank statements and drawdowns to the facility letters.'],
    render(st, ctx) {
      const d = ctx.d, M = d.movement, T = d.totals, money = ctx.money;
      return [
        { type:'stats', items:[
          { label:'Opening', value: ctx.money0(T.open) }, { label:'+ Drawdowns', value: ctx.money0(T.draw) }, { label:'− Repayments', value: ctx.money0(T.repay) },
          { label:'= Closing recomputed', value: ctx.money0(T.closeCalc) }, { label:'Closing per schedule', value: ctx.money0(T.close) },
          { label:'Difference', value: money(T.moveDiff), cls: Math.abs(T.moveDiff || 0) > 0.01 ? 'bad' : 'ok' },
          { label:'Facilities not reconciling', value: M.breaks.length, cls: M.breaks.length ? 'bad' : 'ok' } ] },
        ...(M.swapped.length ? [{ type:'note', tone:'warn', html:`<b>${M.swapped.length} line(s) had a negative instalment beside a positive repayment</b>; the two values were swapped for the recalculation (EX-LOAN-10). Confirm the mapping on V3.0b.` }] : []),
        { type:'table', title:'Roll-forward by facility', columns:[...FAC_COLS,
          { key:'open', label:'Opening', type:'num', sum:true }, { key:'draw', label:'Drawdowns', type:'num', sum:true }, { key:'repay', label:'Repayments', type:'num', sum:true },
          { key:'closeCalc', label:'Closing per audit', type:'num', sum:true, formula:(row, C) => `${C(3)}${row}+${C(4)}${row}-${C(5)}${row}` }, { key:'close', label:'Closing per schedule', type:'num', sum:true },
          { key:'diff', label:'Difference', type:'num', sum:true, flag: v => v != null && Math.abs(v) > 0.01 },
          { key:'repayAgreed', label:'Repayments agreed to bank statements (Y/N)', input:'select', options:yn }, { key:'drawAgreed', label:'Drawdowns agreed to facility letter / bank (Y/N)', input:'select', options:yn },
          { key:'comment', label:'Explanation of difference', input:'text', wide:true } ],
          rows: d.facilities.map(r => ({ ...facRow(r), closeCalc: r.__closeCalc, diff: r.__moveDiff, __cls: r.__moveDiff != null && Math.abs(r.__moveDiff) > 0.01 ? 'flag' : '' })),
          footnote:'A difference above the tolerance is raised as EX-LOAN-01. Repayments are taken at their absolute value whether the schedule shows them negative or positive.' }
      ];
    },
    flag(st, d) { return d.movement.breaks.length > 0 || d.movement.overRepaid.length > 0; } },

  { id:'interest', ref:'V3.2', title:'Interest recalculation',
    objective:'To recompute interest for the year on each facility from the balance, stated rate and instalment on a reducing-balance basis, compare it with the interest charged, and assess the effective rate implied by the charge.',
    procedures:['Recomputed the instalment from principal, rate and tenor and compared it with the instalment stated.',
                'Amortised each facility month by month from the opening balance at the stated rate and instalment, accumulating interest and principal for the year.',
                'Compared recomputed interest with the interest charged and the effective rate implied by the charge with the stated rate; investigated differences beyond the tolerance.'],
    render(st, ctx) {
      const d = ctx.d, I = d.interest, T = d.totals, money = ctx.money, m0 = ctx.money0;
      return [
        { type:'controls', items:[
          { key:'intMethod', label:'Recalculation method', kind:'select', options:[['amort', 'Reducing balance — monthly amortisation from the opening balance at the stated instalment'], ['average', 'Average balance × rate'], ['opening', 'Opening balance × rate']] },
          { key:'intTolPct', label:'Tolerance — % of recomputed interest', kind:'number' },
          { key:'intTol', label:'Tolerance — absolute (blank = clearly trivial threshold)', kind:'number', help:`In use: ${m0(I.tol)}; a line is flagged when the difference exceeds the greater of the two.` } ] },
        { type:'stats', items:[
          { label:'Interest per schedule', value: m0(T.interest) }, { label:'Interest per audit', value: m0(T.intAudit) },
          { label:'Difference', value: money(T.intDiff), cls: Math.abs(T.intDiff || 0) > I.tol ? 'bad' : 'ok' },
          { label:'Facilities outside tolerance', value: I.breaks.length, cls: I.breaks.length ? 'bad' : 'ok' },
          { label:'Instalments not following the annuity', value: I.instBreaks.length, cls: I.instBreaks.length ? 'warn' : 'ok' } ] },
        { type:'table', title:'Instalment check', columns:[...FAC_COLS, { key:'principal', label:'Principal', type:'num' }, { key:'rate', label:'Rate', type:'pct', dp:2 }, { key:'tenor', label:'Tenor (months)', type:'int' },
          { key:'instAudit', label:'Annuity per audit', type:'num' }, { key:'instalment', label:'Instalment per schedule', type:'num' }, { key:'instDiff', label:'Difference', type:'num', flag: (v, row) => row.__break },
          { key:'start', label:'Drawdown', type:'date' }, { key:'maturity', label:'Maturity (derived)', type:'date' }, { key:'remaining', label:'Instalments remaining', type:'int' } ],
          rows: d.facilities.map(r => ({ ...facRow(r), instAudit: r.__instAudit, instDiff: r.__instDiff, maturity: r.__maturity, remaining: r.__remaining, __break: r.__instBreak })) },
        { type:'table', title:'Interest for the year — schedule vs audit', columns:[...FAC_COLS,
          { key:'open', label:'Opening', type:'num', sum:true }, { key:'months', label:'Months', type:'int' }, { key:'rate', label:'Stated rate', type:'pct', dp:2 },
          { key:'intAudit', label:'Interest per audit', type:'num', sum:true }, { key:'interest', label:'Interest per schedule', type:'num', sum:true }, { key:'intDiff', label:'Difference', type:'num', sum:true, flag: (v, row) => row.__break },
          { key:'effRate', label:'Effective rate implied', type:'pct', dp:2 },
          { key:'repayAudit', label:'Principal per amortisation', type:'num', sum:true }, { key:'repay', label:'Repaid per schedule', type:'num', sum:true },
          { key:'advices', label:'Agreed to lender interest advices (Y/N)', input:'select', options:yn }, { key:'comment', label:'Explanation', input:'text', wide:true } ],
          rows: d.facilities.map(r => ({ ...facRow(r), months: r.__monthsInYear, intAudit: r.__intAudit, intDiff: r.__intDiff, effRate: r.__effRate != null ? r.__effRate / 100 : null, repayAudit: r.__repayAudit, __break: r.__intBreak, __cls: r.__intBreak ? 'flag' : '' })),
          footnote:'Interest outside the tolerance is raised as EX-LOAN-03; instalments more than 1% from the annuity as EX-LOAN-07. Where a facility was drawn in the year the amortisation runs from the drawdown month.' }
      ];
    },
    flag(st, d) { return d.interest.breaks.length > 0; } },

  { id:'split', ref:'V3.3', title:'Current / non-current split',
    objective:'To recompute the portion of each facility repayable within twelve months of the reporting date from the amortisation profile and compare it with the split presented by the client.',
    procedures:['Amortised each facility for the twelve months after the reporting date at the stated rate and instalment to obtain the principal falling due — the current portion per audit.',
                'Compared the current and non-current portions per the client with the recomputation and checked that the client split casts to the closing balance.'],
    render(st, ctx) {
      const d = ctx.d, S = d.split, T = d.totals, money = ctx.money, m0 = ctx.money0;
      return [
        { type:'controls', items:[
          { key:'splitBasis', label:'Amortise the next twelve months from', kind:'select', options:[['client', 'Closing balance per the schedule'], ['audit', 'Closing balance recomputed on V3.1']] },
          { key:'splitTol', label:'Tolerance for the current portion (blank = clearly trivial threshold)', kind:'number', help:`In use: ${m0(S.tol)}` } ] },
        { type:'stats', items:[
          { label:'Current per client', value: m0(T.current) }, { label:'Current per audit', value: m0(T.curAudit) }, { label:'Difference', value: money(r2(T.current - T.curAudit)), cls: Math.abs(T.current - T.curAudit) > S.tol ? 'bad' : 'ok' },
          { label:'Non-current per client', value: m0(T.noncurrent) }, { label:'Non-current per audit', value: m0(T.ncAudit) },
          { label:'Client split − closing', value: money(T.splitCast), cls: Math.abs(T.splitCast || 0) > 0.01 ? 'bad' : 'ok' },
          { label:'Splits not casting', value: S.castBreaks.length, cls: S.castBreaks.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Split by facility', columns:[...FAC_COLS,
          { key:'close', label:'Closing per schedule', type:'num', sum:true }, { key:'current', label:'Current per client', type:'num', sum:true }, { key:'noncurrent', label:'Non-current per client', type:'num', sum:true },
          { key:'splitCast', label:'Client split − closing', type:'num', flag: (v, row) => row.__castBreak },
          { key:'curAudit', label:'Current per audit', type:'num', sum:true }, { key:'ncAudit', label:'Non-current per audit', type:'num', sum:true },
          { key:'curDiff', label:'Current: client − audit', type:'num', sum:true, flag: (v, row) => row.__curBreak },
          { key:'status', label:'Status', type:'chip', chipClass: v => v === 'Agrees' ? 'ok' : v === 'Does not cast' ? 'bad' : 'warn' },
          { key:'comment', label:'Comment / reclassification proposed', input:'text', wide:true } ],
          rows: d.facilities.map(r => ({ ...facRow(r), current: r.current, noncurrent: r.noncurrent, splitCast: r.__splitCast, curAudit: r.__curAudit, ncAudit: r.__ncAudit, curDiff: r.__curDiff,
            __castBreak: S.castBreaks.includes(r), __curBreak: r.__curBreak,
            status: S.castBreaks.includes(r) ? 'Does not cast' : r.__splitExplainedByMove ? 'Cast follows EX-LOAN-01' : r.__curBreak ? 'Differs' : 'Agrees', __cls: S.castBreaks.includes(r) || r.__curBreak ? 'flag' : '' })),
          footnote:'A client split that does not cast to the closing balance is raised as EX-LOAN-02 (unless the difference is the movement difference already raised as EX-LOAN-01); a current portion differing from the amortisation beyond the tolerance as EX-LOAN-04. A covenant breach at the reporting date may require the whole balance to be presented as current.' }
      ];
    },
    flag(st, d) { return d.split.castBreaks.length > 0 || d.split.curBreaks.length > 0; } },

  { id:'confirm', ref:'V3.4', title:'Bank confirmation control',
    objective:'To obtain direct confirmation from every lender of the balance outstanding, interest rate, repayment terms, security and covenants at the reporting date (ISA 505) and to agree the confirmed balance to the schedule.',
    procedures:['Sent a confirmation request to every lender under the auditor\'s control and recorded the dates sent and received.',
                'Agreed the confirmed balance and rate to the schedule and investigated differences.',
                'Recorded security, guarantees and covenants reported by the lender for V3.5 and V3.6.'],
    render(st, ctx) {
      const d = ctx.d, C = d.confirmations, T = d.totals, money = ctx.money;
      return [
        { type:'stats', items:[
          { label:'Facilities', value: d.facilities.length }, { label:'Confirmations received', value: `${C.received} of ${d.facilities.length}`, cls: C.received === d.facilities.length ? 'ok' : 'warn' },
          { label:'Balances agreeing', value: C.agreed }, { label:'Differences', value: C.breaks.length, cls: C.breaks.length ? 'bad' : 'ok' },
          { label:'Rate differences', value: C.rateBreaks.length, cls: C.rateBreaks.length ? 'warn' : 'ok' },
          { label:'Total per confirmations', value: ctx.money0(T.conf) } ] },
        { type:'table', title:'Confirmation control sheet', columns:[...FAC_COLS,
          { key:'close', label:'Closing per schedule', type:'num', sum:true },
          { key:'confSent', label:'Request sent (date)', input:'text' }, { key:'confRecd', label:'Reply received (Y/N)', input:'select', options:yn }, { key:'confDate', label:'Date received', input:'text' },
          { key:'confBal', label:'Balance per confirmation', input:'number' }, { key:'confDiff', label:'Confirmation − schedule', type:'num', flag: v => v != null && Math.abs(v) > 0.01 },
          { key:'rate', label:'Rate per schedule', type:'pct', dp:2 }, { key:'confRate', label:'Rate per confirmation (%)', input:'number' },
          { key:'confTerms', label:'Repayment terms confirmed', input:'text', wide:true }, { key:'confSecurity', label:'Security / covenants reported', input:'text', wide:true },
          { key:'confComment', label:'Comment', input:'text', wide:true } ],
          rows: d.facilities.map(r => ({ ...facRow(r), confDiff: r.__confDiff, __cls: r.__confDiff != null && Math.abs(r.__confDiff) > 0.01 ? 'flag' : '' })),
          footnote:'Differences are raised as EX-LOAN-05 (balance) and EX-LOAN-09 (rate). Where no reply is received, obtain the year-end lender statement directly and record it in the comment.' }
      ];
    },
    flag(st, d) { return d.confirmations.breaks.length > 0; } },

  { id:'covenants', ref:'V3.5', title:'Covenant compliance',
    objective:'To identify the financial covenants attaching to each facility, test compliance at the reporting date on audited figures, and assess the consequences of any breach for classification and going concern.',
    procedures:['Extracted each covenant from the facility letter or confirmation reply, with its threshold.',
                'Computed the actual ratio or amount from the audited financial statements and compared it with the threshold.',
                'For any breach or thin headroom, considered whether a waiver was obtained before the reporting date and the effect on classification (IAS 1 para 74) and going concern.'],
    render(st, ctx) {
      const V = ctx.d.covenant;
      const n = Math.max(0, Math.min(40, Math.round(Number(ctx.cfg.covRows) || 0)));
      const rows = [];
      for (let i = 1; i <= n; i++) { const c = V.rows.find(x => x.i === i); rows.push({ __key:'cov' + i, line:i, status: c ? c.status : '', headroom: c ? c.headroom : null, __cls: c?.status === 'Breached' ? 'flag' : '' }); }
      return [
        { type:'controls', items:[{ key:'covRows', label:'Covenant lines', kind:'number' }] },
        { type:'stats', items:[
          { label:'Covenants entered', value: V.rows.length }, { label:'Tested', value: V.tested },
          { label:'Breaches', value: V.breaches.length, cls: V.breaches.length ? 'bad' : V.rows.length ? 'ok' : '' } ] },
        { type:'table', title:'Covenants', columns:[
          { key:'line', label:'#', type:'int' }, { key:'covFacility', label:'Facility', input:'text' }, { key:'covDesc', label:'Covenant (e.g. Debt service cover, Gearing, Tangible net worth)', input:'text', wide:true },
          { key:'covType', label:'Type', input:'select', options:COVENANT_TYPES }, { key:'covThreshold', label:'Threshold', input:'number' }, { key:'covActual', label:'Actual (audited)', input:'number' },
          { key:'headroom', label:'Headroom', type:'num' }, { key:'status', label:'Status', type:'chip', chipClass: v => v === 'Complied' ? 'ok' : v === 'Breached' ? 'bad' : 'grey' },
          { key:'covWaiver', label:'Waiver obtained before year end (Y/N)', input:'select', options:yn }, { key:'covComment', label:'Comment / source', input:'text', wide:true } ], rows,
          footnote:'Minimum: actual must be at or above the threshold. Maximum: actual must be at or below. A breach is raised as EX-LOAN-06.' },
        { type:'note', html:'Where a covenant is breached at the reporting date and the lender has not waived the breach before that date, the liability is presented as current even if the lender agrees after the year end not to demand repayment (IAS 1 para 74–75).' }
      ];
    },
    flag(st, d) { return d.covenant.breaches.length > 0; } },

  { id:'security', ref:'V3.6', title:'Security and guarantees',
    objective:'To record the security, charges and guarantees attaching to each facility, agree them to the facility letters and confirmation replies, and accumulate the information for disclosure.',
    procedures:['Recorded for each facility the nature of security, the asset charged and its carrying amount, and any guarantor.',
                'Agreed the security to the facility agreement and the lender\'s confirmation and considered whether the charge is registered.',
                'Summarised secured and unsecured borrowings and the carrying amount of assets pledged for the notes to the financial statements.'],
    render(st, ctx) {
      const d = ctx.d, S = d.security, m0 = ctx.money0;
      return [
        { type:'stats', items:[
          { label:'Secured borrowings', value: m0(S.secured) }, { label:'Unsecured borrowings', value: m0(S.unsecured) },
          { label:'Facilities not yet classified', value: S.unclassified, cls: S.unclassified ? 'warn' : 'ok' },
          { label:'Carrying amount of assets pledged', value: m0(S.pledged) }, { label:'Guarantees', value: S.guarantees } ] },
        { type:'table', title:'Security schedule', columns:[...FAC_COLS, { key:'close', label:'Closing balance', type:'num', sum:true }, { key:'schedSec', label:'Security per schedule' },
          { key:'secType', label:'Nature of security', input:'select', options:SECURITY_TYPES }, { key:'secAsset', label:'Asset charged', input:'text', wide:true }, { key:'secCarrying', label:'Carrying amount of asset charged', input:'number' },
          { key:'secGuarantor', label:'Guarantor', input:'text' }, { key:'secSighted', label:'Facility agreement sighted (Y/N)', input:'select', options:yn }, { key:'secRegistered', label:'Charge registered (Y/N)', input:'select', options:yn },
          { key:'secDisclosed', label:'Disclosed in notes (Y/N)', input:'select', options:yn }, { key:'secComment', label:'Comment', input:'text', wide:true } ],
          rows: d.facilities.map(r => ({ ...facRow(r), schedSec: r.security })) },
        { type:'note', html:'Guarantees given by the entity for the borrowings of others are contingent liabilities — record them here and carry them to the commitments and contingencies note.' }
      ];
    } },

  { id:'conclusion', ref:'V3.9', title:'Exceptions & conclusion', kind:'conclusion' }
];

function suggestConclusion(st, ctx) {
  const d = ctx.d, T = d.totals;
  const ex = (st.exceptions || []).filter(e => e.disposition === 'open');
  return [
    `Borrowings per the schedule total ${ctx.money(T.close)} across ${d.facilities.length} facilit${d.facilities.length === 1 ? 'y' : 'ies'}${d.lead.tbEntered ? (d.lead.tbBreaks.length ? `, of which ${d.lead.tbBreaks.length} do not agree to the trial balance` : ', agreeing to the trial balance') : ''}.`,
    d.movement.breaks.length ? `The movement does not reconcile for ${d.movement.breaks.length} facilit${d.movement.breaks.length === 1 ? 'y' : 'ies'} (net difference ${ctx.money(T.moveDiff)}).` : 'Opening plus drawdowns less repayments reconciles to closing for every facility.',
    `Interest was recomputed on the reducing balance at the stated rates: ${ctx.money(T.intAudit)} per audit against ${ctx.money(T.interest)} charged${d.interest.breaks.length ? `; ${d.interest.breaks.length} facilit${d.interest.breaks.length === 1 ? 'y is' : 'ies are'} outside tolerance` : ''}.`,
    `The current portion per audit is ${ctx.money(T.curAudit)} against ${ctx.money(T.current)} per the client.`,
    `${d.confirmations.received} of ${d.facilities.length} lender confirmations were received${d.confirmations.breaks.length ? `; ${d.confirmations.breaks.length} balance(s) differ` : ''}.`,
    d.covenant.rows.length ? (d.covenant.breaches.length ? `${d.covenant.breaches.length} covenant(s) breached at the reporting date.` : 'All covenants tested were complied with.') : 'Covenants have not yet been entered on V3.5.',
    ex.length ? `${ex.length} exception(s) remain open in the register.` : 'No exceptions remain open.',
    'Subject to the above, borrowings are complete, accurately stated and appropriately classified and disclosed at the reporting date.'
  ].join(' ');
}

return {
  code:'LOAN', name:'Borrowings', group:'Liabilities & equity', accepts:'.xlsx,.xlsm,.csv',
  blurb:'The borrowings audit file: lead by facility, movement reconciliation, reducing-balance interest recalculation, current / non-current split, lender confirmations, covenant compliance and security — from one uploaded loan schedule.',
  objective:'To obtain sufficient appropriate audit evidence that borrowings are complete and exist as obligations at the reporting date, that interest is accurately computed and recorded, and that classification, security, covenants and other terms are appropriately presented and disclosed.',
  fields, tests, compute, pages, defaultConfig, STANDARD_COLUMNS, SECURITY_TYPES, COVENANT_TYPES,
  procedures: pages.flatMap(p => p.procedures || []),
  columns: STANDARD_COLUMNS, suggestConclusion
};
})();

Modules.register(LOANModule);
