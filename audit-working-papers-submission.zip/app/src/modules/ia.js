/* ==========================================================================
   ia.js -- Intangible assets (FRS 38 / FRS 36) as an auditor actually works it.

   One uploaded intangibles register (cost block / amortisation block, the same
   shape as a fixed asset register) feeds:
     G3    Lead schedule                   G3.4  Indefinite life / not yet in use
     G3.1  Movement schedule by class      G3.5  Impairment assessment (FRS 36)
     G3.2  Amortisation recalculation      G3.6  Disposals and derecognition
     G3.3  Additions and capitalisation
   ========================================================================== */

const IAModule = (() => {
const r2 = n => n == null || isNaN(n) ? null : Math.round(n * 100) / 100;
const days = (a, b) => (a && b) ? Math.round((a - b) / 86400000) : null;
const num = v => (v === '' || v == null || isNaN(Number(v))) ? null : Number(v);
const inp = (cfg, key, k) => num(cfg[key + ':' + k]);
const txt = (cfg, key, k) => { const v = cfg[key + ':' + k]; return v == null ? '' : String(v); };

/* Seeded PRNG so a random sample is reproducible from its recorded seed. */
function mulberry32(seed) {
  let a = (seed >>> 0) || 1;
  return () => {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function sampleN(items, n, seed) {
  const rnd = mulberry32(seed);
  const pool = items.slice();
  const out = [];
  while (out.length < n && pool.length) out.push(pool.splice(Math.floor(rnd() * pool.length), 1)[0]);
  return out;
}

/* FRS 36 para 12 -- the minimum indicators. Answered Y/N by the auditor. */
const INDICATORS = [
  { id:'12a', src:'External', text:'Significant decline in market value of assets, beyond the passage of time or normal use' },
  { id:'12b', src:'External', text:'Adverse change in the technological, market, economic or legal environment in which the entity operates' },
  { id:'12c', src:'External', text:'Market interest rates or other market rates of return have increased, likely to reduce recoverable amount materially' },
  { id:'12d', src:'External', text:'Carrying amount of the entity\'s net assets exceeds its market capitalisation (listed entities)' },
  { id:'12e', src:'Internal', text:'Evidence of obsolescence or physical damage' },
  { id:'12f', src:'Internal', text:'Asset idle, plans to discontinue or restructure the operation, plans to dispose earlier than expected, or useful life reassessed as finite' },
  { id:'12g', src:'Internal', text:'Internal reporting indicates economic performance of an asset is, or will be, worse than expected' },
  { id:'14',  src:'Internal', text:'Cash flows to acquire or operate the asset significantly above budget; actual results or budgeted cash flows significantly worse than expected' },
];

/* Capitalisation criteria (FRS 38 para 8–24, 57) answered per addition. */
const CRITERIA = [
  { key:'critIdent',   label:'Identifiable — separable or arising from contractual / legal rights (Y/N)' },
  { key:'critControl', label:'Controlled by the entity (Y/N)' },
  { key:'critBenefit', label:'Probable future economic benefits (Y/N)' },
  { key:'critCost',    label:'Cost reliably measurable (Y/N)' },
  { key:'critResearch',label:'Research-phase and other non-qualifying costs excluded (Y/N)' }
];

const CANDIDATE_RULES = [
  { id:'C1', label:'Fully amortised but still held', why:'Nil carrying amount with the asset still in the register — either the life was too short (FRS 38 para 104 requires annual review) or the asset is no longer used and should be derecognised.', todo:'Confirm whether the asset is still in use; if not, derecognise. If in use, reconsider the useful life policy.' },
  { id:'C2', label:'Negative carrying amount', why:'Accumulated amortisation exceeds cost — an error in the register.', todo:'Obtain the amortisation history and propose an adjustment.' },
  { id:'C3', label:'Finite-life asset with no amortisation charged', why:'A carrying amount with no charge suggests the asset is idle or amortisation has been suspended (FRS 36 para 12(f)).', todo:'Enquire whether the asset is in use; if idle with no plan to use, assess recoverable amount.' },
  { id:'C4', label:'Age exceeds stated useful life, not fully amortised', why:'Held longer than its stated life yet still carrying a balance — life, date or amortisation is inconsistent.', todo:'Reconcile acquisition date and life to supporting documents. Recompute accumulated amortisation.' },
  { id:'C5', label:'Carrying amount at or above performance materiality', why:'An individually material asset requires a specific indicator assessment (FRS 36 para 9).', todo:'Enquire about the asset\'s use and expected benefits; corroborate to budgets or contracts and document the assessment.' },
  { id:'C6', label:'Indefinite life or not yet available for use — annual test required', why:'FRS 36 para 10 requires an annual impairment test irrespective of indicators for intangibles with an indefinite life, intangibles not yet available for use and goodwill.', todo:'Obtain management\'s recoverable amount estimate (value in use or fair value less costs of disposal) and test the key assumptions. Refer to the IMP module for a CGU model.' },
  { id:'C7', label:'Class with an indicator answered Yes', why:'Where an FRS 36 para 12 indicator is present for a class, every asset in it above the trivial threshold must have recoverable amount estimated (para 9).', todo:'Estimate recoverable amount for the affected assets or CGU.' },
  { id:'C8', label:'Derecognition in the year at a loss in the same class', why:'A loss on derecognition is evidence that carrying amounts in that class may exceed recoverable amount (FRS 36 para 12(a)).', todo:'Consider whether the loss indicates impairment of the remaining assets in the class.' }
];

/* ---------------------------------------------------------------- fields */
const fields = [
  { key:'asset_id',    label:'Asset code',   role:'key', type:'text', required:true,
    synonyms:['Asset Code','Asset No.','Asset No','FA ID','Tag Number','Asset Ref','Asset Number','IA Code','Intangible Ref','Asset ID','Licence No','Licence Number','Registration No','Ref','资产编号','无形资产编号'] },
  { key:'category',    label:'Class',        role:'category', type:'text', required:true, satisfiedByGroup:true,
    synonyms:['Category','Asset Class','Asset Group','FA Type','Class','Type','Class of Intangible','Intangible Class','Type of Asset','Nature','Asset Type','Group','资产类别','无形资产类别','类别'] },
  { key:'description', label:'Description',  type:'text', required:true, dupKey:true,
    synonyms:['Description','Asset Description','Asset Name','Particulars','Item','Details','Software','Licence','License','Trademark','Patent','Development Project','Project','Intangible Asset','Name','Brand','资产名称','无形资产名称','名称'] },
  { key:'acq_date',    label:'Acquisition / capitalisation date', type:'date', required:true, dupKey:true,
    synonyms:['Purchase Date','Acquisition Date','Date Acquired','Capitalisation Date','Capitalization Date','Asset Date','In-Service Date','Date of Purchase','Cap. Date','Date Capitalised','Date Available for Use','Available for Use Date','Registration Date','Date of Acquisition','Go-live Date','Start Date','购置日期','取得日期'] },
  { key:'life',        label:'Useful life',  type:'number', required:true,
    synonyms:['Useful Life (Yrs)','Useful Life','Life','UL','Est. Useful Life','Dep. Life (Months)','Useful Life (Mths)','Amortisation Period','Amortisation Period (Yrs)','Amortization Period','Licence Period','Legal Life','Life (Years)','Amort Life','摊销年限','使用年限'] },
  { key:'method',      label:'Amortisation method', type:'text',
    synonyms:['Depreciation Method','Dep Method','Method','Depn Basis','Basis','Amortisation Method','Amortization Method','Amort Method','Amortisation Basis','摊销方法'] },
  { key:'rate',        label:'Amortisation rate %', type:'number',
    synonyms:['Dep Rate %','Rate','Depn Rate','Annual Rate %','Amortisation Rate %','Amort Rate','Amortisation Rate','Rate %','摊销率'] },
  { key:'cost_open',   label:'Cost b/f',     type:'number', required:true, block:'Cost',
    synonyms:['Cost B/F','Opening Cost','Op Bal','Cost Brought Forward','Cost at 1 Jan','Op Bal - Cost','Cost at Beginning','Gross Carrying Amount B/F','Opening Balance - Cost','Opening Gross Amount','期初原值','期初成本'] },
  { key:'additions',   label:'Additions',    type:'number', required:true, block:'Cost', dupKey:true,
    synonyms:['Additions','Add’ns','Add\'ns','Acquisitions','Purchases','Addition','Internally Generated','Development Costs Capitalised','Capitalised in Year','Capitalised','Acquired','Additions - Cost','本期增加'] },
  { key:'disposals',   label:'Disposals / derecognition', type:'number', required:true, block:'Cost',
    synonyms:['Disposals','Disposal / Write-off','Deletions','Retirements','Disposal','Derecognised','Derecognition','Written Off','Write-offs','Disposals / Write-offs','Write Off','本期减少'] },
  { key:'cost_close',  label:'Cost c/f',     type:'number', block:'Cost',
    synonyms:['Cost C/F','Closing Cost','End Bal','Cost at Year End','Total Cost','End Bal - Cost','Gross Carrying Amount C/F','Cost at End','Closing Gross Amount','期末原值'] },
  { key:'accdep_open', label:'Acc amortisation b/f',  type:'number', required:true, block:'Amortisation',
    synonyms:['Acc Dep B/F','Opening Accumulated Depreciation','Accum. Depn B/F','Op Bal','A/Depn Brought Forward','Op Bal - Depn','Acc Amort B/F','Accumulated Amortisation B/F','Opening Accumulated Amortisation','Amortisation B/F','Acc. Amortisation Opening','Accum. Amort B/F','期初累计摊销','期初累计折旧'] },
  { key:'dep_charge',  label:'Amortisation charge', type:'number', required:true, block:'Amortisation',
    synonyms:['Depreciation for the Year','Current Year Depreciation','Depn Charge','Charge for the Year','Dep - CY','Additions','Amortisation for the Year','Amortisation Charge','Amortisation','Amortization','Amort Charge','Charge for Year','Current Year Amortisation','Amortisation Expense','本期摊销','本期折旧'] },
  { key:'accdep_disp', label:'Acc amortisation on disposals', type:'number', block:'Amortisation',
    synonyms:['Acc Dep on Disposal','Depn on Disposals','Write-back on Disposal','Disposals','Amortisation on Disposals','Acc Amort on Disposal','Eliminated on Disposal','Derecognised','Write-back'] },
  { key:'accdep_close',label:'Acc amortisation c/f',  type:'number', block:'Amortisation',
    synonyms:['Acc Dep C/F','Closing Accumulated Depreciation','Accum. Depn C/F','End Bal','End Bal - Depn','Acc Amort C/F','Accumulated Amortisation C/F','Closing Accumulated Amortisation','Amortisation C/F','Accum. Amort C/F','期末累计摊销'] },
  { key:'impairment',  label:'Impairment loss in the year', type:'number', block:'Amortisation',
    synonyms:['Impairment','Impairment Loss','Impairment for the Year','Impairment Charge','减值','减值损失'] },
  { key:'nbv_close',   label:'Carrying amount c/f', type:'number', block:'NBV',
    synonyms:['NBV','Net Book Value','Carrying Amount','WDV','Net Book Value at Year End','Net Carrying Amount','Carrying Value','Closing Carrying Amount','账面价值','期末净值'] },
  { key:'life_type',   label:'Finite / indefinite', type:'text',
    synonyms:['Indefinite Life','Indefinite','Finite / Indefinite','Life Type','Amortised (Y/N)','Useful Life Assessment','Finite or Indefinite','寿命类型'] },
  { key:'status',      label:'Status / availability for use', type:'text',
    synonyms:['Status','Available for Use','In Use','Ready for Use','Stage','Phase','Asset Status','状态'] },
  { key:'supplier',    label:'Supplier / licensor', type:'text', synonyms:['Supplier','Vendor','Purchased From','Supplier Name','Licensor','Developer','Counterparty','供应商'] },
  { key:'location',    label:'Location / cost centre', type:'text', synonyms:['Location','Site','Cost Centre','Cost Center','Dept','Department','CGU','Business Unit','部门'] }
];

const STANDARD_COLUMNS = [
  { key:'asset_id', label:'Asset code' }, { key:'category', label:'Class' },
  { key:'description', label:'Description' }, { key:'acq_date', label:'Capitalised', type:'date', edit:true },
  { key:'__lifeYears', label:'Life (yrs)', type:'num', dp:1, edit:'life' }, { key:'method', label:'Method' },
  { key:'cost_open', label:'Cost b/f', type:'num', edit:true }, { key:'additions', label:'Additions', type:'num', edit:true },
  { key:'disposals', label:'Disposals', type:'num', edit:true }, { key:'__cost_close', label:'Cost c/f', type:'num' },
  { key:'accdep_open', label:'Acc amort b/f', type:'num', edit:true }, { key:'dep_charge', label:'Charge', type:'num', edit:true },
  { key:'accdep_disp', label:'Acc amort disp.', type:'num', edit:true }, { key:'__accdep_close', label:'Acc amort c/f', type:'num' },
  { key:'__nbv_open', label:'Carrying b/f', type:'num' }, { key:'__nbv_close', label:'Carrying c/f', type:'num', emphasis:true },
  { key:'__lifeBasis', label:'Life basis' }
];

const CONVENTIONS = [
  { key:'month-incl',  label:'Monthly — from the month of capitalisation (inclusive)' },
  { key:'month-next',  label:'Monthly — from the month after capitalisation' },
  { key:'daily',       label:'Daily pro-rata from the capitalisation date' },
  { key:'half-year',   label:'Half year in the year of capitalisation' },
  { key:'full-year',   label:'Full year in the year of capitalisation' },
  { key:'none-first',  label:'No amortisation in the year of capitalisation' },
];

const INDEF_RE = /indefinite|goodwill|perpetual|no\s*expiry|not\s*amortis/i;
const NYAFU_RE = /not\s*(yet\s*)?available|in\s*progress|under\s*development|development\s*phase|\bwip\b|\bcip\b|\bnyafu\b|pre-?launch|not\s*(yet\s*)?in\s*use|构建中|开发中/i;

/* Amortisation methods.  FRS 38 para 98 allows straight line, diminishing
   balance and units of production; the method is the auditor's conclusion about
   the policy, chosen per class here, not copied out of the register.  The
   arithmetic is PPEModule's, so depreciation and amortisation cannot drift.  */
const METHODS = [
  { key:'sl',    label:'Straight line' },
  { key:'rb',    label:'Diminishing balance (at the stated rate)' },
  { key:'ddb',   label:'Double declining balance (200% of straight line)' },
  { key:'syd',   label:"Sum of the years' digits" },
  { key:'none',  label:'Not amortised (indefinite life, or not yet available for use)' },
];
const METHOD_LABEL = k => (METHODS.find(m => m.key === k) || METHODS[0]).label;

const defaultConfig = () => ({
  lifeUnit: 'auto', convention: 'month-incl', recalcBasis: 'asset',
  method: 'sl', methodPolicy: {}, ratePolicy: {},   // amortisation method per class
  amortTol: 0, castTol: 0.01, capThreshold: 1000,
  addThreshold: '', addSampleN: 0, addSeed: 20250228,
  indicators: {},
  ruleC1: true, ruleC2: true, ruleC3: true, ruleC4: true, ruleC5: true, ruleC6: true, ruleC7: true, ruleC8: true,
  pnlAmortisation: ''
});

/* ========================================================== COMPUTE */
function monthsInUse(acq, fys, ye, convention) {
  if (!acq || !ye) return 12;
  if (acq > ye) return 0;
  if (fys && acq < fys) return 12;
  const m = (ye.getUTCFullYear() - acq.getUTCFullYear()) * 12 + (ye.getUTCMonth() - acq.getUTCMonth());
  switch (convention) {
    case 'month-incl': return Math.min(12, Math.max(0, m + 1));
    case 'month-next': return Math.min(12, Math.max(0, m));
    case 'daily':      return Math.min(12, Math.max(0, (days(ye, acq) + 1) / 365 * 12));
    case 'half-year':  return 6;
    case 'full-year':  return 12;
    case 'none-first': return 0;
    default:           return Math.min(12, Math.max(0, m + 1));
  }
}
const catOf = r => r.category || '(unclassified)';
const catKey = c => Core.keyify(c) || 'unclassified';
function mode(arr) { const m = new Map(); let best = arr[0], bc = 0; for (const v of arr) { const c = (m.get(v) || 0) + 1; m.set(v, c); if (c > bc) { bc = c; best = v; } } return best; }

function compute(recs, cfg, eng) {
  const ye = eng.yearEndDate, fys = eng.fyStartDate;
  const pm = eng.materiality?.pm || 0, trivial = eng.materiality?.trivial || 0;
  const tol = Number(cfg.castTol) || 0.01;
  const live = recs.filter(r => !r.__excluded);

  let unit = cfg.lifeUnit;
  if (unit === 'auto') { const vals = live.map(r => r.life).filter(v => v > 0); unit = vals.length && vals.filter(v => v > 30).length / vals.length > 0.5 ? 'months' : 'years'; }

  /* class names vary in case and spacing across a register ("Motor Vehicles" / "motor vehicles"): group by key, display the most common spelling */
  const spellings = {};
  for (const r of recs) {
    if (r.__excluded) continue;
    const raw = String(catOf(r)).replace(/\s+/g, ' ').trim(), k = catKey(raw);
    const s = spellings[k] || (spellings[k] = {}); s[raw] = (s[raw] || 0) + 1;
  }
  const canon = Object.fromEntries(Object.entries(spellings).map(([k, s]) => [k, Object.entries(s).sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))[0][0]]));

  const cats = {};
  for (const r of recs) {
    r.__displayKey = r.asset_id || r.description || ('row ' + r.__srcRow);
    r.__catKey = catKey(String(catOf(r)).replace(/\s+/g, ' ').trim());
    r.__cat = canon[r.__catKey] || String(catOf(r)).replace(/\s+/g, ' ').trim();
    const w = r.__wp || {};
    const text = [r.__cat, r.description, r.life_type, r.method, r.status].filter(Boolean).join(' ');
    /* indefinite life: auditor flag, or the register says so */
    r.__indefSource = w.indef?.indefinite === 'Y' ? 'auditor' : w.indef?.indefinite === 'N' ? '' : (INDEF_RE.test(text) ? 'register' : '');
    r.__indefinite = !!r.__indefSource;
    r.__nyafuSource = w.indef?.nyafu === 'Y' ? 'auditor' : w.indef?.nyafu === 'N' ? '' : (NYAFU_RE.test([r.description, r.status, r.__cat].filter(Boolean).join(' ')) ? 'register' : '');
    r.__nyafu = !!r.__nyafuSource;
    r.__annualTest = r.__indefinite || r.__nyafu;
    r.__lifeBasis = r.__indefinite ? 'Indefinite' : r.__nyafu ? 'Not yet available for use' : 'Finite';

    const lifeMonths = unit === 'months' ? (r.life || 0) : (r.life || 0) * 12;
    r.__lifeYears = lifeMonths ? lifeMonths / 12 : 0;
    const policy = inp(cfg, 'policyLife', r.__catKey);
    r.__policyLife = policy > 0 ? policy : null;
    r.__lifeUsed = (cfg.recalcBasis === 'policy' && r.__policyLife) ? r.__policyLife : r.__lifeYears;

    r.__cost_close = r.cost_close != null ? r.cost_close : r2((r.cost_open || 0) + (r.additions || 0) - (r.disposals || 0));
    r.__accdep_close = r.accdep_close != null ? r.accdep_close : r2((r.accdep_open || 0) + (r.dep_charge || 0) + (r.impairment || 0) - (r.accdep_disp || 0));
    r.__nbv_open = r2((r.cost_open || 0) - (r.accdep_open || 0));
    r.__nbv_close = r2(r.__cost_close - r.__accdep_close);
    r.__isAddition = (r.additions || 0) > 0.005 || (r.acq_date && fys && r.acq_date >= fys && r.acq_date <= ye);
    r.__isDisposal = (r.disposals || 0) > 0.005;
    r.__months = monthsInUse(r.acq_date, fys, ye, cfg.convention);

    /* amortisation: straight line over the life used, capped at the remaining carrying amount; nil for indefinite / not yet available */
    const base = r.__isAddition && !r.cost_open ? (r.additions || 0) : (r.cost_open || 0) + (r.__isAddition ? (r.additions || 0) : 0);
    const clsMethod = r.__annualTest ? 'none' : (cfg.methodPolicy[r.__cat] || cfg.method || 'sl');
    r.__method = clsMethod;
    r.__methodStated = PPEModule.readMethod ? PPEModule.readMethod(r.method) : null;
    r.__methodRaw = r.method || '';
    r.__methodDiffers = !!(r.__methodStated && !r.__annualTest && r.__methodStated !== clsMethod);
    const rateUsed = r.rate > 0 ? r.rate : (Number(cfg.ratePolicy[r.__cat]) || 0);
    r.__rateUsed = rateUsed;
    let expected = 0;
    if (base > 0) {
      const c = PPEModule.charge(clsMethod, { base, opened: r.accdep_open || 0, life: r.__lifeUsed,
        months: r.__months, rate: rateUsed, age: r.__ageYears || 0 });
      if (c == null) { r.__noBasis = true; expected = 0; }
      else expected = Math.min(c, Math.max(0, base - (r.accdep_open || 0)));
    }
    if (r.__isDisposal && (r.__cost_close || 0) < 0.005) expected = Math.min(expected, r.dep_charge || 0);
    r.__expectedDep = r2(expected);
    r.__depDiff = r2((r.dep_charge || 0) - expected);
    r.__fullyDepOpen = (r.cost_open || 0) > 0 && (r.accdep_open || 0) >= (r.cost_open || 0) - 0.01;
    r.__ageYears = (r.acq_date && ye) ? days(ye, r.acq_date) / 365.25 : null;

    /* G3.4 recoverable amount entered */
    r.__recoverable = num(w.indef?.recoverable);
    r.__headroom = r.__recoverable != null ? r2(r.__recoverable - (r.__nbv_close || 0)) : null;
    r.__impTested = w.indef?.impTested === 'Y';

    /* G3.3 capitalisation criteria */
    const a = w.additions || {};
    r.__critAnswers = CRITERIA.map(c => a[c.key] || '');
    r.__critFails = CRITERIA.filter(c => a[c.key] === 'N').map(c => c.key);
    r.__critMet = CRITERIA.every(c => a[c.key] === 'Y');
    r.__critStatus = r.__critFails.length ? 'Not met' : r.__critMet ? 'Met' : r.__critAnswers.some(Boolean) ? 'Incomplete' : '';

    const c = cats[r.__cat] || (cats[r.__cat] = { category:r.__cat, key:r.__catKey, count:0, cost_open:0, additions:0, disposals:0, cost_close:0,
      accdep_open:0, dep_charge:0, impairment:0, accdep_disp:0, accdep_close:0, nbv_open:0, nbv_close:0, expected:0, depDiff:0, lives:[], indefinite:0, nyafu:0 });
    if (r.__excluded) continue;
    c.count++;
    c.cost_open += r.cost_open || 0; c.additions += r.additions || 0; c.disposals += r.disposals || 0; c.cost_close += r.__cost_close || 0;
    c.accdep_open += r.accdep_open || 0; c.dep_charge += r.dep_charge || 0; c.impairment += r.impairment || 0; c.accdep_disp += r.accdep_disp || 0; c.accdep_close += r.__accdep_close || 0;
    c.nbv_open += r.__nbv_open || 0; c.nbv_close += r.__nbv_close || 0; c.expected += expected; c.depDiff += r.__depDiff || 0;
    if (r.__lifeYears > 0) c.lives.push(r.__lifeYears);
    if (r.__indefinite) c.indefinite++; if (r.__nyafu) c.nyafu++;
  }
  const byCategory = Object.values(cats).sort((a, b) => a.category.localeCompare(b.category));
  const totals = { category:'TOTAL', count:0, cost_open:0, additions:0, disposals:0, cost_close:0, accdep_open:0, dep_charge:0, impairment:0, accdep_disp:0, accdep_close:0, nbv_open:0, nbv_close:0, expected:0, depDiff:0, indefinite:0, nyafu:0 };
  for (const c of byCategory) {
    for (const k of Object.keys(totals)) if (typeof c[k] === 'number') totals[k] += c[k];
    c.modeLife = c.lives.length ? mode(c.lives) : null; c.minLife = c.lives.length ? Math.min(...c.lives) : null; c.maxLife = c.lives.length ? Math.max(...c.lives) : null;
    c.policyLife = inp(cfg, 'policyLife', c.key);
    c.offPolicy = c.policyLife > 0 ? c.lives.filter(l => Math.abs(l - c.policyLife) > 0.01).length : null;
    for (const k of Object.keys(c)) if (typeof c[k] === 'number') c[k] = r2(c[k]);
  }
  for (const k of Object.keys(totals)) if (typeof totals[k] === 'number') totals[k] = r2(totals[k]);

  /* ---- G3 lead: register vs TB vs prior year, by class ---------------- */
  const lead = byCategory.map(c => {
    const tbCost = inp(cfg, 'tbCost', c.key), tbAccRaw = inp(cfg, 'tbAcc', c.key), pyCost = inp(cfg, 'pyCost', c.key), pyAccRaw = inp(cfg, 'pyAcc', c.key);
    const tbAcc = tbAccRaw != null ? Math.abs(tbAccRaw) : null, pyAcc = pyAccRaw != null ? Math.abs(pyAccRaw) : null;
    const nbvTB = tbCost != null && tbAcc != null ? r2(tbCost - tbAcc) : null;
    const nbvPY = pyCost != null && pyAcc != null ? r2(pyCost - pyAcc) : null;
    const variance = nbvPY != null ? r2(c.nbv_close - nbvPY) : null;
    return { ...c, tbCost, tbAcc, nbvTB, diffCost: tbCost != null ? r2(c.cost_close - tbCost) : null, diffAcc: tbAcc != null ? r2(c.accdep_close - tbAcc) : null,
      pyCost, pyAcc, nbvPY, openCostDiff: pyCost != null ? r2(c.cost_open - pyCost) : null, openAccDiff: pyAcc != null ? r2(c.accdep_open - pyAcc) : null,
      variance, variancePct: nbvPY ? r2(variance / Math.abs(nbvPY) * 100) : null, material: variance != null && Math.abs(variance) > pm && nbvPY && Math.abs(variance / nbvPY) > 0.10 };
  });
  const tbBreaks = lead.filter(l => (l.diffCost != null && Math.abs(l.diffCost) > tol) || (l.diffAcc != null && Math.abs(l.diffAcc) > tol));
  const pyBreaks = lead.filter(l => (l.openCostDiff != null && Math.abs(l.openCostDiff) > tol) || (l.openAccDiff != null && Math.abs(l.openAccDiff) > tol));
  const pnl = num(cfg.pnlAmortisation);

  /* ---- G3.3 additions: key items above threshold + random sample ------ */
  const threshold = cfg.addThreshold !== '' && cfg.addThreshold != null ? Number(cfg.addThreshold) : pm;
  const adds = live.filter(r => (r.additions || 0) > 0.005);
  const key = adds.filter(r => r.additions >= threshold);
  const residual = adds.filter(r => r.additions < threshold);
  const n = Math.min(Number(cfg.addSampleN) || 0, residual.length);
  const sample = sampleN(residual, n, Number(cfg.addSeed) || 1);
  const selectedSet = new Set([...key, ...sample].map(r => r.__i));
  for (const r of recs) r.__addSelected = selectedSet.has(r.__i) ? (key.includes(r) ? 'Key item' : 'Random sample') : null;
  const selected = adds.filter(r => r.__addSelected).sort((a, b) => (b.additions || 0) - (a.additions || 0));
  const addTotal = r2(adds.reduce((s, r) => s + r.additions, 0)), keyVal = r2(key.reduce((s, r) => s + r.additions, 0)), sampleVal = r2(sample.reduce((s, r) => s + r.additions, 0));
  const additions = { threshold, all: adds, key, residual, sample, selected, seed: Number(cfg.addSeed) || 1, total: addTotal, keyValue: keyVal, sampleValue: sampleVal,
    coverage: addTotal ? r2((keyVal + sampleVal) / addTotal * 100) : 0, residualValue: r2(addTotal - keyVal), untestedValue: r2(addTotal - keyVal - sampleVal),
    critMet: selected.filter(r => r.__critMet).length, critFail: selected.filter(r => r.__critFails.length), vouched: selected.filter(r => r.__wp?.additions?.agreed === 'Y').length,
    belowCap: adds.filter(r => r.additions < (Number(cfg.capThreshold) || 0)), negative: live.filter(r => (r.additions || 0) < -0.01), afterYE: live.filter(r => r.acq_date && ye && r.acq_date > ye) };

  /* ---- G3.6 disposals ------------------------------------------------- */
  const disposals = live.filter(r => r.__isDisposal).map(r => {
    const proceeds = num(r.__wp?.disposals?.proceeds);
    const nbvDisposed = r2((r.disposals || 0) - (r.accdep_disp || 0));
    return { r, nbvDisposed, proceeds, gainLoss: proceeds != null ? r2(proceeds - nbvDisposed) : null, noWriteBack: Math.abs(r.accdep_disp || 0) < 0.005 };
  });
  const disp = { rows: disposals, cost: r2(disposals.reduce((s, x) => s + (x.r.disposals || 0), 0)), accdep: r2(disposals.reduce((s, x) => s + (x.r.accdep_disp || 0), 0)),
    nbv: r2(disposals.reduce((s, x) => s + x.nbvDisposed, 0)), proceeds: r2(disposals.reduce((s, x) => s + (x.proceeds || 0), 0)), gainLoss: r2(disposals.filter(x => x.gainLoss != null).reduce((s, x) => s + x.gainLoss, 0)),
    noWriteBack: disposals.filter(x => x.noWriteBack), priced: disposals.filter(x => x.proceeds != null).length };

  /* ---- G3.4 indefinite / not yet available ---------------------------- */
  const annual = live.filter(r => r.__annualTest);
  const indef = { rows: annual, count: annual.length, carrying: r2(annual.reduce((s, r) => s + (r.__nbv_close || 0), 0)), tested: annual.filter(r => r.__impTested).length,
    untested: annual.filter(r => !r.__impTested), shortfall: annual.filter(r => r.__headroom != null && r.__headroom < -0.005), amortised: annual.filter(r => Math.abs(r.dep_charge || 0) > 0.01) };

  /* ---- G3.5 impairment: indicators and candidates --------------------- */
  const yesCats = new Set(); let anyYes = false;
  for (const ind of INDICATORS) { const a = (cfg.indicators || {})[ind.id]; if (a?.answer === 'Y') { anyYes = true; (a.categories || []).forEach(c => yesCats.add(c)); if (!(a.categories || []).length) yesCats.add('*'); } }
  const lossCats = new Set(disposals.filter(x => x.gainLoss != null && x.gainLoss < 0).map(x => x.r.__cat));
  const on = id => cfg['rule' + id] !== false;
  const candidates = [];
  for (const r of live) {
    const hits = [];
    if (on('C1') && (r.__cost_close || 0) > 0.005 && Math.abs(r.__nbv_close || 0) < 0.01) hits.push('C1');
    if (on('C2') && (r.__nbv_close || 0) < -0.01) hits.push('C2');
    if (on('C3') && !r.__annualTest && (r.__nbv_open || 0) > trivial && Math.abs(r.dep_charge || 0) < 0.005 && !r.__isDisposal && !r.__fullyDepOpen) hits.push('C3');
    if (on('C4') && !r.__annualTest && r.__ageYears != null && r.__lifeYears > 0 && r.__ageYears > r.__lifeYears + 0.5 && (r.__nbv_close || 0) > trivial) hits.push('C4');
    if (on('C5') && pm > 0 && (r.__nbv_close || 0) >= pm) hits.push('C5');
    if (on('C6') && r.__annualTest && (r.__nbv_close || 0) > 0.005) hits.push('C6');
    if (on('C7') && anyYes && (yesCats.has('*') || yesCats.has(r.__cat)) && (r.__nbv_close || 0) > trivial) hits.push('C7');
    if (on('C8') && lossCats.has(r.__cat) && !r.__isDisposal && (r.__nbv_close || 0) > trivial) hits.push('C8');
    r.__candidateRules = hits;
    if (hits.length) candidates.push({ r, rules: hits });
  }
  candidates.sort((a, b) => (b.r.__nbv_close || 0) - (a.r.__nbv_close || 0));
  const candValue = r2(candidates.reduce((s, c) => s + Math.max(0, c.r.__nbv_close || 0), 0));
  const impairment = { anyYes, yesCats: [...yesCats], candidates, candidateValue: candValue, coverage: totals.nbv_close ? r2(candValue / totals.nbv_close * 100) : 0,
    byRule: CANDIDATE_RULES.map(rule => ({ ...rule, on: on(rule.id), count: candidates.filter(c => c.rules.includes(rule.id)).length })) };

  return { lifeUnit: unit, byCategory, categories: byCategory.map(c => c.category), totals, lead, tbBreaks, pyBreaks, additions, disposals: disp, indef, impairment,
    pnlAmortisation: pnl, pnlDiff: pnl != null ? r2(totals.dep_charge - pnl) : null,
    castCost: r2(totals.cost_open + totals.additions - totals.disposals - totals.cost_close),
    castDep: r2(totals.accdep_open + totals.dep_charge + totals.impairment - totals.accdep_disp - totals.accdep_close),
    depBreaks: live.filter(r => r.__depDiff != null && Math.abs(r.__depDiff) > (Number(cfg.amortTol) > 0 ? Number(cfg.amortTol) : (trivial || 1))), pm, trivial, tol };
}

/* ============================================================== TESTS */
const tests = [
  { id:'EX-IA-01', label:'Amortisation charge differs from the recalculation', basis:'G3.2',
    fn:(r, cfg, eng) => { if (r.__annualTest) return false; const tol = Number(cfg.amortTol) > 0 ? Number(cfg.amortTol) : (eng.materiality?.trivial || 1);
      return r.__depDiff != null && Math.abs(r.__depDiff) > tol && { expected:r.__expectedDep, actual:r.dep_charge, difference:r.__depDiff, cell:r['__cell_dep_charge'],
        detail:`${r.__depDiff < 0 ? 'Under' : 'Over'}-amortised by ${Math.abs(r.__depDiff).toFixed(2)} on ${r.__months} months over ${r.__lifeUsed} years` }; } },
  { id:'EX-IA-02', label:'Amortisation charged on an indefinite-life asset or one not yet available for use', basis:'G3.4', severity:'above-trivial',
    fn:(r) => r.__annualTest && Math.abs(r.dep_charge || 0) > 0.01 && { actual:r.dep_charge, difference:r.dep_charge, cell:r['__cell_dep_charge'],
      detail:`${r.__lifeBasis} (per ${r.__indefSource || r.__nyafuSource}) — FRS 38 para 97 and 107: amortisation begins when the asset is available for use and indefinite-life assets are not amortised` } },
  { id:'EX-IA-03', label:'Negative carrying amount', basis:'G3.5 C2', severity:'above-trivial',
    fn:(r) => (r.__nbv_close || 0) < -0.01 && { actual:r.__nbv_close, difference:r.__nbv_close, cell:r['__cell_nbv_close'] } },
  { id:'EX-IA-04', label:'Amortisation charged on a fully amortised asset', basis:'G3.2',
    fn:(r) => r.__fullyDepOpen && (r.dep_charge || 0) > 0.01 && { actual:r.dep_charge, difference:r.dep_charge, cell:r['__cell_dep_charge'] } },
  { id:'EX-IA-05', label:'Useful life differs from the class policy', basis:'G3.2', severity:'informational',
    fn:(r) => !r.__annualTest && r.__policyLife && r.__lifeYears > 0 && Math.abs(r.__lifeYears - r.__policyLife) > 0.01 && { actual:r.__lifeYears, expected:r.__policyLife, cell:r['__cell_life'], detail:`Stated ${r.__lifeYears} years; policy ${r.__policyLife} years` } },
  { id:'EX-IA-06', label:'No useful life or rate but amortisation charged', basis:'G3.2',
    fn:(r) => !r.__annualTest && !r.__lifeYears && !(r.rate > 0) && (r.dep_charge || 0) > 0.01 && { actual:r.dep_charge, difference:r.dep_charge, cell:r['__cell_life'], detail:'Either the life is missing from the register or the asset is being treated as indefinite while still amortised' } },
  { id:'EX-IA-07', label:'Capitalised after the year end', basis:'G3.3', severity:'above-trivial',
    fn:(r, cfg, eng) => r.acq_date && eng.yearEndDate && r.acq_date > eng.yearEndDate && { actual:Core.fmtDate(r.acq_date), difference:r.additions, cell:r['__cell_acq_date'] } },
  { id:'EX-IA-08', label:'Cost roll-forward does not cast', basis:'G3.1',
    fn:(r, cfg) => { if (r.cost_close == null) return false; const d = r2(r.cost_close - ((r.cost_open || 0) + (r.additions || 0) - (r.disposals || 0)));
      return Math.abs(d) > (Number(cfg.castTol) || 0.01) && { expected:r2(r.cost_close - d), actual:r.cost_close, difference:d, cell:r['__cell_cost_close'] }; } },
  { id:'EX-IA-08b', label:'Accumulated amortisation roll-forward does not cast', basis:'G3.1',
    fn:(r, cfg) => { if (r.accdep_close == null) return false; const calc = r2((r.accdep_open || 0) + (r.dep_charge || 0) + (r.impairment || 0) - (r.accdep_disp || 0)); const d = r2(r.accdep_close - calc);
      return Math.abs(d) > (Number(cfg.castTol) || 0.01) && { expected:calc, actual:r.accdep_close, difference:d, cell:r['__cell_accdep_close'] }; } },
  { id:'EX-IA-09', label:'Derecognition with no accumulated amortisation written back', basis:'G3.6',
    fn:(r) => r.__isDisposal && Math.abs(r.accdep_disp || 0) < 0.005 && { actual:r.disposals, difference:r.disposals, cell:r['__cell_accdep_disp'] } },
  { id:'EX-IA-10', label:'Negative addition', basis:'G3.3',
    fn:(r) => (r.additions || 0) < -0.01 && { actual:r.additions, difference:r.additions, cell:r['__cell_additions'] } },
  { id:'EX-IA-11', label:'Addition below the capitalisation threshold', basis:'G3.3', severity:'informational',
    fn:(r, cfg) => (r.additions || 0) > 0.005 && r.additions < (Number(cfg.capThreshold) || 0) && { actual:r.additions, difference:r.additions, cell:r['__cell_additions'] } },
  { id:'EX-IA-12', label:'Possible duplicate asset', basis:'G3.0a', severity:'informational',
    fn:(r) => { const f = (r.__flags || []).find(x => x.rule === 'DQ-10'); return f && { detail:f.detail, difference:r.additions || r.cost_open }; } },
  { id:'EX-IA-13', label:'Addition does not meet the recognition criteria for an intangible asset', basis:'G3.3', severity:'above-trivial',
    fn:(r) => r.__addSelected && r.__critFails.length > 0 && { actual: r.__critFails.map(k => CRITERIA.find(c => c.key === k).label.replace(/ \(Y\/N\)$/, '')).join('; '), difference:r.additions, cell:r['__cell_additions'],
      detail:'One or more FRS 38 recognition criteria answered No — the cost should be expensed (para 68) unless the assessment is revised.' } },
  { id:'EX-IA-14', label:'Indefinite-life or not-yet-available asset without an annual impairment test recorded', basis:'G3.4', severity:'informational',
    fn:(r) => r.__annualTest && !r.__impTested && (r.__nbv_close || 0) > 0.005 && { actual:r.__lifeBasis, difference:r.__nbv_close, cell:r['__cell_nbv_close'], detail:'FRS 36 para 10 requires an annual test irrespective of indicators' } },
  { id:'EX-IA-15', label:'Recoverable amount below carrying amount', basis:'G3.4',
    fn:(r) => r.__headroom != null && r.__headroom < -0.005 && { expected:r.__recoverable, actual:r.__nbv_close, difference:r.__headroom, cell:r['__cell_nbv_close'], detail:'Impairment loss to be recognised (FRS 36 para 59)' } },
  { id:'EX-IA-20', scope:'population', label:'Register does not agree to the trial balance', basis:'G3',
    fn:(recs, cfg, eng, d) => d.tbBreaks.map(l => ({ key:l.category, expected:l.nbvTB, actual:l.nbv_close, difference:r2((l.diffCost || 0) - (l.diffAcc || 0)),
      detail:`Cost ${l.diffCost != null ? l.diffCost.toFixed(2) : 'n/a'}, accumulated amortisation ${l.diffAcc != null ? l.diffAcc.toFixed(2) : 'n/a'}` })) },
  { id:'EX-IA-21', scope:'population', label:'Amortisation per register does not agree to the profit or loss', basis:'G3',
    fn:(recs, cfg, eng, d) => d.pnlDiff != null && Math.abs(d.pnlDiff) > (Number(cfg.castTol) || 0.01) && { key:'Amortisation charge', expected:d.pnlAmortisation, actual:d.totals.dep_charge, difference:d.pnlDiff } },
  { id:'EX-IA-22', scope:'population', label:'Opening balances do not agree to the prior year audited figures', basis:'G3',
    fn:(recs, cfg, eng, d) => d.pyBreaks.map(l => ({ key:l.category, expected:l.pyCost, actual:l.cost_open, difference:r2((l.openCostDiff || 0) - (l.openAccDiff || 0)),
      detail:`Cost b/f − PY ${l.openCostDiff != null ? l.openCostDiff.toFixed(2) : 'n/a'}; accumulated amortisation b/f − PY ${l.openAccDiff != null ? l.openAccDiff.toFixed(2) : 'n/a'}` })) },
  { id:'EX-IA-23', scope:'population', label:'Register does not cast', basis:'G3.1',
    fn:(recs, cfg, eng, d) => (Math.abs(d.castCost || 0) > (Number(cfg.castTol) || 0.01) || Math.abs(d.castDep || 0) > (Number(cfg.castTol) || 0.01)) &&
      { key:'Register totals', expected:d.totals.cost_close, actual:r2(d.totals.cost_close + d.castCost), difference:r2((d.castCost || 0) + (d.castDep || 0)), detail:`Cost cast ${d.castCost.toFixed(2)}; accumulated amortisation cast ${d.castDep.toFixed(2)}` } }
];

/* ============================================================== PAGES */
const yn = ['Y', 'N'];
const flagAbs = (v, t = 0.01) => v != null && Math.abs(v) > t;
const assetRow = r => ({ __rec:r, code:r.asset_id, cls_:r.__cat, desc:r.description, acq:r.acq_date, life:r.__lifeYears || null, basis:r.__lifeBasis });
const ASSET_COLS = [{ key:'code', label:'Asset code', emphasis:true }, { key:'cls_', label:'Class' }, { key:'desc', label:'Description', wrap:true }];

const pages = [
  { id:'source',  ref:'G3.0',  title:'Source data',     kind:'source' },
  { id:'cleaned', ref:'G3.0a', title:'Cleaned listing', kind:'cleaned' },
  { id:'mapping', ref:'G3.0b', title:'Column mapping',  kind:'mapping' },

  { id:'lead', ref:'G3', title:'Lead schedule',
    objective:'To agree intangible assets per the register to the trial balance and to the prior year audited figures by class, to agree the amortisation charge to the profit or loss, and to explain material movements.',
    procedures:['Agreed cost and accumulated amortisation per the register to the trial balance by class.',
                'Agreed opening cost and accumulated amortisation to the prior year audited figures and compared closing carrying amounts with the prior year, investigating variances above performance materiality and 10%.',
                'Agreed the total amortisation charge per the register to the profit or loss.'],
    render(st, ctx) {
      const d = ctx.d, T = d.totals, m0 = ctx.money0, money = ctx.money;
      return [
        { type:'controls', items:[
          { key:'pnlAmortisation', label:'Amortisation per profit or loss', kind:'number' },
          { key:'castTol', label:'Tolerance for differences', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Assets', value: `${T.count} in ${d.byCategory.length} class${d.byCategory.length === 1 ? '' : 'es'}` },
          { label:'Cost c/f', value: m0(T.cost_close) }, { label:'Accumulated amortisation c/f', value: m0(T.accdep_close) }, { label:'Carrying amount c/f', value: m0(T.nbv_close) },
          { label:'Amortisation per register', value: m0(T.dep_charge) },
          { label:'Amortisation − P&L', value: d.pnlDiff == null ? '— enter —' : money(d.pnlDiff), cls: d.pnlDiff == null ? '' : flagAbs(d.pnlDiff) ? 'bad' : 'ok' },
          { label:'Classes not agreeing to TB', value: d.tbBreaks.length, cls: d.tbBreaks.length ? 'bad' : 'ok' },
          { label:'Indefinite / not yet in use', value: `${T.indefinite} / ${T.nyafu}` } ] },
        { type:'table', title:'Intangible assets by class — register vs trial balance', columns:[
          { key:'category', label:'Class', emphasis:true }, { key:'count', label:'Assets', type:'int' },
          { key:'cost_close', label:'Cost per register', type:'num', sum:true }, { key:'tbCost', label:'Cost per TB', input:'number' }, { key:'diffCost', label:'Cost: register − TB', type:'num', flag: v => flagAbs(v) },
          { key:'accdep_close', label:'Acc amort per register', type:'num', sum:true }, { key:'tbAcc', label:'Acc amort per TB', input:'number' }, { key:'diffAcc', label:'Acc amort: register − TB', type:'num', flag: v => flagAbs(v) },
          { key:'nbv_close', label:'Carrying amount per register', type:'num', sum:true }, { key:'nbvTB', label:'Carrying amount per TB', type:'num' },
          { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: d.lead.map(l => ({ ...l, __key:l.key, __cls: (flagAbs(l.diffCost) || flagAbs(l.diffAcc)) ? 'flag' : '' })),
          footnote:'Enter the TB balances per class (accumulated amortisation may be entered as a credit; the sign is ignored). Differences are raised as EX-IA-20.' },
        { type:'table', title:'Prior year comparison by class', columns:[
          { key:'category', label:'Class', emphasis:true },
          { key:'pyCost', label:'PY audited cost', input:'number' }, { key:'cost_open', label:'Cost b/f per register', type:'num', sum:true }, { key:'openCostDiff', label:'Cost b/f − PY', type:'num', flag: v => flagAbs(v) },
          { key:'pyAcc', label:'PY audited acc amort', input:'number' }, { key:'accdep_open', label:'Acc amort b/f per register', type:'num', sum:true }, { key:'openAccDiff', label:'Acc amort b/f − PY', type:'num', flag: v => flagAbs(v) },
          { key:'nbvPY', label:'PY carrying amount', type:'num' }, { key:'nbv_close', label:'Carrying amount c/f', type:'num', sum:true }, { key:'variance', label:'Movement', type:'num', flag: (v, row) => row.material }, { key:'variancePct', label:'Movement %', type:'pct' },
          { key:'explain', label:'Explanation of movement', input:'text', wide:true } ],
          rows: d.lead.map(l => ({ ...l, __key:l.key, variancePct: l.variancePct != null ? l.variancePct / 100 : null, __cls: l.material || flagAbs(l.openCostDiff) || flagAbs(l.openAccDiff) ? 'flag' : '' })),
          footnote:'Opening balances not agreeing to the prior year are raised as EX-IA-22. Movements above performance materiality and 10% of the prior year carrying amount are painted red.' }
      ];
    },
    flag(st, d) { return d.tbBreaks.length > 0 || d.pyBreaks.length > 0 || flagAbs(d.pnlDiff); } },

  { id:'movement', ref:'G3.1', title:'Movement schedule by class',
    objective:'To prepare the movement in cost, accumulated amortisation and carrying amount by class for the year, and confirm it casts and cross-casts.',
    procedures:['Prepared the roll-forward of cost and accumulated amortisation by class from the cleaned register.',
                'Cast each column and cross-cast each row; agreed opening balances to the prior year closing on G3.'],
    render(st, ctx) {
      const d = ctx.d, T = d.totals, m0 = ctx.money0, money = ctx.money;
      const rows = d.byCategory.map(c => ({ ...c, __key:c.key, castCost: r2(c.cost_open + c.additions - c.disposals - c.cost_close), castDep: r2(c.accdep_open + c.dep_charge + c.impairment - c.accdep_disp - c.accdep_close) }));
      return [
        { type:'stats', items:[
          { label:'Cost b/f', value: m0(T.cost_open) }, { label:'Additions', value: m0(T.additions) }, { label:'Disposals', value: m0(T.disposals) }, { label:'Cost c/f', value: m0(T.cost_close) },
          { label:'Cost cast difference', value: money(d.castCost), cls: flagAbs(d.castCost) ? 'bad' : 'ok' },
          { label:'Acc amort b/f', value: m0(T.accdep_open) }, { label:'Charge', value: m0(T.dep_charge) }, { label:'Impairment', value: m0(T.impairment) }, { label:'Acc amort c/f', value: m0(T.accdep_close) },
          { label:'Acc amort cast difference', value: money(d.castDep), cls: flagAbs(d.castDep) ? 'bad' : 'ok' },
          { label:'Carrying amount b/f → c/f', value: `${m0(T.nbv_open)} → ${m0(T.nbv_close)}` } ] },
        { type:'table', title:'Cost', columns:[{ key:'category', label:'Class', emphasis:true }, { key:'count', label:'Assets', type:'int' },
          { key:'cost_open', label:'B/f', type:'num', sum:true }, { key:'additions', label:'Additions', type:'num', sum:true }, { key:'disposals', label:'Disposals / derecognised', type:'num', sum:true },
          { key:'cost_close', label:'C/f per register', type:'num', sum:true }, { key:'castCost', label:'Cast difference', type:'num', flag: v => flagAbs(v) }], rows },
        { type:'table', title:'Accumulated amortisation and impairment', columns:[{ key:'category', label:'Class', emphasis:true },
          { key:'accdep_open', label:'B/f', type:'num', sum:true }, { key:'dep_charge', label:'Charge for the year', type:'num', sum:true }, { key:'impairment', label:'Impairment', type:'num', sum:true }, { key:'accdep_disp', label:'Eliminated on disposal', type:'num', sum:true },
          { key:'accdep_close', label:'C/f per register', type:'num', sum:true }, { key:'castDep', label:'Cast difference', type:'num', flag: v => flagAbs(v) }], rows },
        { type:'table', title:'Carrying amount', columns:[{ key:'category', label:'Class', emphasis:true }, { key:'nbv_open', label:'B/f', type:'num', sum:true }, { key:'nbv_close', label:'C/f', type:'num', sum:true, formula:(row, C) => `${C(1)}${row}+0` },
          { key:'indefinite', label:'Indefinite-life assets', type:'int' }, { key:'nyafu', label:'Not yet available for use', type:'int' }, { key:'comment', label:'Comment', input:'text', wide:true }], rows,
          footnote:'Per-asset roll-forwards that do not cast are raised as EX-IA-08 and EX-IA-08b; the register as a whole as EX-IA-23.' }
      ];
    },
    flag(st, d) { return flagAbs(d.castCost) || flagAbs(d.castDep); } },

  { id:'amortisation', ref:'G3.2', title:'Amortisation recalculation',
    objective:'To recalculate the amortisation charge for the year for every finite-life intangible asset and assess whether useful lives are consistent with the stated accounting policy (FRS 38 para 97–104).',
    procedures:['Recalculated the charge for each finite-life asset on a straight-line basis over the useful life, applying the convention selected, and capped at the remaining carrying amount.',
                'Compared the recalculated charge to the charge recorded, by asset and by class; investigated differences beyond the tolerance.',
                'Compared stated useful lives with the class policy entered and confirmed no charge on indefinite-life assets or assets not yet available for use.'],
    render(st, ctx) {
      const d = ctx.d, T = d.totals, m0 = ctx.money0, money = ctx.money, cfg = ctx.cfg;
      const tolUsed = Number(cfg.amortTol) > 0 ? Number(cfg.amortTol) : (ctx.trivial || 1);
      return [
        { type:'controls', items:[
          { key:'lifeUnit', label:'Useful life stated in', kind:'select', options:[['auto', `Auto-detect (currently ${d.lifeUnit})`], ['years', 'Years'], ['months', 'Months']] },
          { key:'convention', label:'Amortisation convention in the year of capitalisation', kind:'select', options: CONVENTIONS.map(c => [c.key, c.label]) },
          { key:'method', label:'Amortisation method (entity default; override per class below)', kind:'select', options: METHODS.map(m => [m.key, m.label]) },
          { key:'recalcBasis', label:'Recalculate over', kind:'select', options:[['asset', 'The life stated for each asset'], ['policy', 'The class policy life entered below (where given)']] },
          { key:'amortTol', label:'Tolerance per asset (0 = clearly trivial threshold)', kind:'number', help:`In use: ${m0(tolUsed)}` } ] },
        { type:'stats', items:[
          { label:'Charge per register', value: m0(T.dep_charge) }, { label:'Charge per audit', value: m0(T.expected) }, { label:'Difference', value: money(T.depDiff), cls: Math.abs(T.depDiff || 0) > tolUsed ? 'bad' : 'ok' },
          { label:'Assets outside tolerance', value: d.depBreaks.length, cls: d.depBreaks.length ? 'bad' : 'ok' },
          { label:'Indefinite / not yet in use (no charge expected)', value: d.indef.count }, { label:'Of which amortised', value: d.indef.amortised.length, cls: d.indef.amortised.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'By class — lives and recalculation', columns:[{ key:'category', label:'Class', emphasis:true }, { key:'count', label:'Assets', type:'int' },
          { key:'modeLife', label:'Most common life (yrs)', type:'num', dp:1 }, { key:'minLife', label:'Min', type:'num', dp:1 }, { key:'maxLife', label:'Max', type:'num', dp:1 },
          { key:'policyLife', label:'Policy life per accounting policy (yrs)', input:'number' }, { key:'offPolicy', label:'Assets off policy', type:'int' },
          { key:'dep_charge', label:'Charge per register', type:'num', sum:true }, { key:'expected', label:'Charge per audit', type:'num', sum:true }, { key:'depDiff', label:'Difference', type:'num', sum:true, flag: v => flagAbs(v, tolUsed) },
          { key:'comment', label:'Comment', input:'text', wide:true }],
          rows: d.byCategory.map(c => ({ ...c, __key:c.key, __cls: Math.abs(c.depDiff || 0) > tolUsed ? 'flag' : '' })),
          footnote:'Lives differing from the policy are raised as EX-IA-05 (informational).' },
        { type:'table', title:'By asset — charge per register vs audit', maxHeight:'70vh', columns:[...ASSET_COLS,
          { key:'acq', label:'Capitalised', type:'date' }, { key:'basis', label:'Life basis', type:'chip', chipClass: v => v === 'Finite' ? 'grey' : 'info' }, { key:'life', label:'Life (yrs)', type:'num', dp:1 }, { key:'lifeUsed', label:'Life used', type:'num', dp:1 }, { key:'months', label:'Months', type:'int' },
          { key:'cost', label:'Cost c/f', type:'num', sum:true }, { key:'accOpen', label:'Acc amort b/f', type:'num', sum:true },
          { key:'charge', label:'Charge per register', type:'num', sum:true }, { key:'expected', label:'Charge per audit', type:'num', sum:true }, { key:'diff', label:'Difference', type:'num', sum:true, flag: v => flagAbs(v, tolUsed) },
          { key:'nbv', label:'Carrying c/f', type:'num', sum:true }, { key:'comment', label:'Explanation', input:'text', wide:true } ],
          rows: ctx.recs.map(r => ({ ...assetRow(r), lifeUsed:r.__lifeUsed || null, months:r.__months, cost:r.__cost_close, accOpen:r.accdep_open, charge:r.dep_charge, expected:r.__expectedDep, diff:r.__depDiff, nbv:r.__nbv_close,
            __cls: Math.abs(r.__depDiff || 0) > tolUsed ? 'flag' : '' })),
          footnote:'Differences beyond the tolerance are raised as EX-IA-01; a charge on an indefinite-life asset or one not yet available for use as EX-IA-02; a charge on a fully amortised asset as EX-IA-04; a charge with no life or rate as EX-IA-06.' }
      ];
    },
    flag(st, d) { return d.depBreaks.length > 0 || d.indef.amortised.length > 0; } },

  { id:'additions', ref:'G3.3', title:'Additions and capitalisation',
    objective:'To verify that additions in the year exist, are recorded at cost in the correct period, and meet the FRS 38 recognition criteria — identifiability, control, probable future economic benefits and reliable measurement — with research-phase and other non-qualifying costs expensed.',
    procedures:['Selected every addition at or above the testing threshold as a key item and a random sample from the remainder using a recorded seed.',
                'For each selected item, vouched cost to invoices, contracts or development cost records and agreed the capitalisation date.',
                'Completed the recognition-criteria checklist for each selected addition and, for internally generated assets, confirmed the six development-phase conditions of FRS 38 para 57.'],
    render(st, ctx) {
      const A = ctx.d.additions, m0 = ctx.money0, pct = ctx.pct;
      return [
        { type:'controls', items:[
          { key:'addThreshold', label:'Testing threshold — every addition at or above is a key item', kind:'number', help:`Blank = performance materiality (${m0(ctx.pm)}). Currently ${m0(A.threshold)}.` },
          { key:'addSampleN', label:'Random sample from the remaining additions', kind:'number', help:`${A.residual.length} additions below the threshold, ${m0(A.residualValue)}` },
          { key:'addSeed', label:'Random seed', kind:'number' },
          { key:'capThreshold', label:'Capitalisation threshold per accounting policy', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Additions', value: `${A.all.length} · ${m0(A.total)}` }, { label:'Key items', value: `${A.key.length} · ${m0(A.keyValue)}` }, { label:'Random sample', value: `${A.sample.length} · ${m0(A.sampleValue)}` },
          { label:'Coverage', value: pct(A.coverage), cls: A.coverage >= 70 ? 'ok' : 'warn' }, { label:'Untested', value: m0(A.untestedValue) },
          { label:'Vouched and agreed', value: `${A.vouched} of ${A.selected.length}`, cls: A.selected.length && A.vouched === A.selected.length ? 'ok' : 'warn' },
          { label:'Criteria met / not met', value: `${A.critMet} / ${A.critFail.length}`, cls: A.critFail.length ? 'bad' : 'ok' },
          { label:'Below capitalisation threshold', value: A.belowCap.length, cls: A.belowCap.length ? 'warn' : 'ok' } ] },
        { type:'table', title:'Additions selected for testing', maxHeight:'70vh', columns:[...ASSET_COLS,
          { key:'acq', label:'Capitalised', type:'date' }, { key:'amount', label:'Addition', type:'num', sum:true }, { key:'sel', label:'Selection', type:'chip', chipClass: v => v === 'Key item' ? 'info' : 'grey' },
          { key:'supplier', label:'Supplier / developer' },
          { key:'doc', label:'Document vouched to', input:'text', wide:true }, { key:'agreed', label:'Cost and date agreed (Y/N)', input:'select', options:yn },
          ...CRITERIA.map(c => ({ key:c.key, label:c.label, input:'select', options:yn })),
          { key:'crit', label:'Criteria', type:'chip', chipClass: v => v === 'Met' ? 'ok' : v === 'Not met' ? 'bad' : 'warn' },
          { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: A.selected.map(r => ({ ...assetRow(r), amount:r.additions, sel:r.__addSelected, supplier:r.supplier, crit:r.__critStatus, __cls: r.__critFails.length ? 'flag' : '' })),
          emptyText:'No additions selected — lower the threshold or increase the sample size.',
          footnote:`Seed ${A.seed}. A criterion answered No is raised as EX-IA-13 (above-trivial). Additions below the capitalisation threshold are listed as EX-IA-11; negative additions as EX-IA-10; capitalisation dated after the year end as EX-IA-07.` },
        { type:'note', html:'Internally generated brands, mastheads, customer lists and similar items are never recognised (FRS 38 para 63); research expenditure is expensed (para 54); development expenditure is capitalised only from the date all six para 57 conditions are met.' }
      ];
    },
    flag(st, d) { return d.additions.critFail.length > 0 || d.additions.negative.length > 0 || d.additions.afterYE.length > 0; } },

  { id:'indef', ref:'G3.4', title:'Indefinite life and assets not yet in use',
    objective:'To identify intangible assets with an indefinite useful life, and assets not yet available for use, for which FRS 36 para 10 requires an annual impairment test irrespective of indicators, and to record the test performed.',
    procedures:['Flagged each asset the register or the auditor identifies as having an indefinite useful life or as not yet available for use.',
                'Confirmed no amortisation is charged on those assets and that the indefinite-life assessment remains supportable (FRS 38 para 109).',
                'Recorded the recoverable amount estimated for each and compared it with the carrying amount.'],
    render(st, ctx) {
      const d = ctx.d, I = d.indef, m0 = ctx.money0;
      return [
        { type:'stats', items:[
          { label:'Assets requiring an annual test', value: I.count }, { label:'Carrying amount', value: m0(I.carrying) },
          { label:'Tests recorded', value: `${I.tested} of ${I.count}`, cls: I.count && I.tested === I.count ? 'ok' : I.count ? 'warn' : '' },
          { label:'Amortised in error', value: I.amortised.length, cls: I.amortised.length ? 'bad' : 'ok' },
          { label:'Recoverable amount below carrying', value: I.shortfall.length, cls: I.shortfall.length ? 'bad' : 'ok' } ] },
        { type:'note', html:'Flag an asset here to exclude it from the amortisation recalculation on G3.2 and to add it to the G3.5 candidates under rule C6. The register is scanned for words such as <i>indefinite</i>, <i>goodwill</i>, <i>in progress</i> or <i>not yet available</i>; the auditor\'s answer overrides the scan.' },
        { type:'table', title:'Useful-life assessment by asset', maxHeight:'70vh', columns:[...ASSET_COLS,
          { key:'acq', label:'Capitalised', type:'date' }, { key:'life', label:'Life (yrs)', type:'num', dp:1 }, { key:'lifeType', label:'Life type per register' }, { key:'status', label:'Status per register' },
          { key:'indefinite', label:'Indefinite life (Y/N)', input:'select', options:yn }, { key:'nyafu', label:'Not yet available for use (Y/N)', input:'select', options:yn },
          { key:'basis', label:'Basis used', type:'chip', chipClass: v => v === 'Finite' ? 'grey' : 'info' }, { key:'source', label:'Source' },
          { key:'charge', label:'Charge per register', type:'num' }, { key:'nbv', label:'Carrying amount', type:'num', sum:true },
          { key:'impTested', label:'Annual impairment test performed (Y/N)', input:'select', options:yn }, { key:'recoverable', label:'Recoverable amount', input:'number' }, { key:'headroom', label:'Headroom', type:'num', flag: v => v != null && v < -0.005 },
          { key:'comment', label:'Basis for indefinite life / expected date available for use', input:'text', wide:true } ],
          rows: ctx.recs.map(r => ({ ...assetRow(r), lifeType:r.life_type, status:r.status, source: r.__indefSource || r.__nyafuSource || '', charge:r.dep_charge, nbv:r.__nbv_close, headroom:r.__headroom,
            __cls: (r.__annualTest && (Math.abs(r.dep_charge || 0) > 0.01 || (r.__headroom != null && r.__headroom < -0.005))) ? 'flag' : '' })),
          footnote:'A charge on a flagged asset is raised as EX-IA-02; a flagged asset without a test recorded as EX-IA-14; a recoverable amount below carrying as EX-IA-15.' }
      ];
    },
    flag(st, d) { return d.indef.amortised.length > 0 || d.indef.shortfall.length > 0; } },

  { id:'impairment', ref:'G3.5', title:'Impairment assessment',
    objective:'To assess, at the reporting date, whether there is any indication that finite-life intangible assets may be impaired (FRS 36 para 9), to confirm the annual test for indefinite-life assets and assets not yet available for use (para 10), and to identify the assets for which recoverable amount must be estimated.',
    procedures:['Completed the FRS 36 para 12 indicator assessment with management, by class.',
                'Applied the candidate rules to the cleaned register to identify assets requiring individual assessment.',
                'For each candidate, documented the work performed, the recoverable amount where estimated, and the work remaining.'],
    render(st, ctx) {
      const d = ctx.d, I = d.impairment, m0 = ctx.money0, pct = ctx.pct;
      return [
        { type:'heading', text:'FRS 36 para 12 indicators' },
        { type:'checklist', store:'indicators', items: INDICATORS.map(i => ({ id:i.id, text:`${i.src}: ${i.text}` })), answers:['Y', 'N', 'n/a'], categories: d.categories },
        { type:'heading', text:'Candidate rules' },
        { type:'controls', items: CANDIDATE_RULES.map(r => ({ key:'rule' + r.id, label:`${r.id} ${r.label}`, kind:'check', help:r.why })) },
        { type:'stats', items:[
          { label:'Indicator answered Yes', value: I.anyYes ? `Yes — ${I.yesCats.includes('*') ? 'all classes' : I.yesCats.join(', ')}` : 'No', cls: I.anyYes ? 'warn' : 'ok' },
          { label:'Candidates', value: I.candidates.length }, { label:'Candidate carrying amount', value: m0(I.candidateValue) }, { label:'Coverage of carrying amount', value: pct(I.coverage) },
          ...I.byRule.filter(r => r.count).map(r => ({ label: `${r.id} ${r.label}`, value: r.count })) ] },
        { type:'table', title:'Assets requiring individual assessment', maxHeight:'70vh', columns:[...ASSET_COLS,
          { key:'basis', label:'Life basis', type:'chip', chipClass: v => v === 'Finite' ? 'grey' : 'info' }, { key:'nbv', label:'Carrying amount', type:'num', sum:true }, { key:'rules', label:'Rules', wrap:true },
          { key:'why', label:'Why it matters', wrap:true }, { key:'todo', label:'Work to be done', wrap:true },
          { key:'workDone', label:'Work done', input:'text', wide:true }, { key:'recoverable', label:'Recoverable amount', input:'number' }, { key:'impaired', label:'Impairment required (Y/N)', input:'select', options:yn },
          { key:'comment', label:'Conclusion', input:'text', wide:true } ],
          rows: I.candidates.map(c => ({ ...assetRow(c.r), nbv:c.r.__nbv_close, rules:c.rules.join(', '), why: c.rules.map(id => CANDIDATE_RULES.find(x => x.id === id).why).join(' '), todo: c.rules.map(id => CANDIDATE_RULES.find(x => x.id === id).todo).join(' '),
            __cls: c.rules.includes('C2') || c.rules.includes('C7') ? 'flag' : '' })),
          emptyText:'No candidates under the rules enabled.',
          footnote:'Where an indicator exists, recoverable amount is the higher of fair value less costs of disposal and value in use (FRS 36 para 18). Refer to the IMP module for a CGU model where the asset does not generate independent cash inflows.' }
      ];
    },
    flag(st, d) { return d.impairment.anyYes || d.impairment.candidates.some(c => c.rules.includes('C2')); } },

  { id:'disposals', ref:'G3.6', title:'Disposals and derecognition',
    objective:'To verify that intangible assets disposed of, expired or retired in the year are derecognised with both cost and accumulated amortisation removed, and that the gain or loss on derecognition is correctly computed (FRS 38 para 112–113).',
    procedures:['Listed every derecognition in the year with cost, accumulated amortisation eliminated and carrying amount derecognised.',
                'Obtained proceeds (nil for expiries and retirements) and recalculated the gain or loss; agreed it to the profit or loss.',
                'Vouched to disposal authorisation, licence expiry or sale documentation.'],
    render(st, ctx) {
      const D = ctx.d.disposals, m0 = ctx.money0, money = ctx.money;
      return [
        { type:'stats', items:[
          { label:'Assets derecognised', value: D.rows.length }, { label:'Cost removed', value: m0(D.cost) }, { label:'Acc amort eliminated', value: m0(D.accdep) }, { label:'Carrying amount derecognised', value: m0(D.nbv) },
          { label:'Proceeds entered', value: `${D.priced} of ${D.rows.length}` }, { label:'Gain / (loss)', value: money(D.gainLoss), cls: D.gainLoss < 0 ? 'warn' : 'ok' },
          { label:'No amortisation written back', value: D.noWriteBack.length, cls: D.noWriteBack.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Derecognitions in the year', columns:[...ASSET_COLS,
          { key:'acq', label:'Capitalised', type:'date' }, { key:'cost', label:'Cost removed', type:'num', sum:true }, { key:'acc', label:'Acc amort eliminated', type:'num', sum:true }, { key:'nbv', label:'Carrying amount', type:'num', sum:true, formula:(row, C) => `${C(4)}${row}-${C(5)}${row}` },
          { key:'proceeds', label:'Proceeds', input:'number' }, { key:'gainLoss', label:'Gain / (loss) per audit', type:'num', sum:true, flag: v => v != null && v < -0.005 },
          { key:'reason', label:'Reason (sale / expiry / retired / replaced)', input:'text' }, { key:'authorised', label:'Authorised (Y/N)', input:'select', options:yn }, { key:'pnlAgreed', label:'Gain / loss agreed to P&L (Y/N)', input:'select', options:yn },
          { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: D.rows.map(x => ({ ...assetRow(x.r), cost:x.r.disposals, acc:x.r.accdep_disp, nbv:x.nbvDisposed, gainLoss:x.gainLoss, __cls: x.noWriteBack ? 'flag' : '' })),
          emptyText:'No disposals or derecognitions in the year.',
          footnote:'A derecognition with no accumulated amortisation written back is raised as EX-IA-09. A loss on derecognition feeds candidate rule C8 on G3.5.' }
      ];
    },
    flag(st, d) { return d.disposals.noWriteBack.length > 0; } },

  { id:'conclusion', ref:'G3.9', title:'Exceptions & conclusion', kind:'conclusion' }
];

function suggestConclusion(st, ctx) {
  const d = ctx.d, T = d.totals;
  const ex = (st.exceptions || []).filter(e => e.disposition === 'open');
  return [
    `Intangible assets per the register total ${ctx.money(T.nbv_close)} (cost ${ctx.money(T.cost_close)}) across ${T.count} assets in ${d.byCategory.length} class${d.byCategory.length === 1 ? '' : 'es'}${d.lead.some(l => l.tbCost != null) ? (d.tbBreaks.length ? `; ${d.tbBreaks.length} class${d.tbBreaks.length === 1 ? ' does' : 'es do'} not agree to the trial balance` : ', agreeing to the trial balance') : ''}.`,
    flagAbs(d.castCost) || flagAbs(d.castDep) ? `The register does not cast (cost ${ctx.money(d.castCost)}, accumulated amortisation ${ctx.money(d.castDep)}).` : 'The register casts and cross-casts.',
    `Amortisation was recalculated at ${ctx.money(T.expected)} against ${ctx.money(T.dep_charge)} recorded${d.depBreaks.length ? `; ${d.depBreaks.length} asset${d.depBreaks.length === 1 ? ' is' : 's are'} outside tolerance` : ''}.`,
    d.indef.count ? `${d.indef.count} asset${d.indef.count === 1 ? '' : 's'} (${ctx.money(d.indef.carrying)}) ${d.indef.count === 1 ? 'has' : 'have'} an indefinite life or ${d.indef.count === 1 ? 'is' : 'are'} not yet available for use; ${d.indef.tested} annual impairment test${d.indef.tested === 1 ? '' : 's'} recorded.` : 'No indefinite-life assets or assets not yet available for use were identified.',
    `${d.additions.selected.length} additions (${ctx.pct(d.additions.coverage)} by value) were selected; ${d.additions.critMet} met all recognition criteria${d.additions.critFail.length ? ` and ${d.additions.critFail.length} did not` : ''}.`,
    d.disposals.rows.length ? `${d.disposals.rows.length} derecognition${d.disposals.rows.length === 1 ? '' : 's'} with a net gain / (loss) of ${ctx.money(d.disposals.gainLoss)}.` : 'There were no derecognitions in the year.',
    d.impairment.anyYes ? `An FRS 36 indicator was answered Yes; ${d.impairment.candidates.length} candidates require recoverable amount to be estimated.` : `No FRS 36 indicator was identified; ${d.impairment.candidates.length} candidate${d.impairment.candidates.length === 1 ? '' : 's'} arose under the rules.`,
    ex.length ? `${ex.length} exception${ex.length === 1 ? '' : 's'} remain${ex.length === 1 ? 's' : ''} open in the register.` : 'No exceptions remain open.',
    'Subject to the above, intangible assets exist, are complete, are carried at cost less accumulated amortisation and impairment in accordance with FRS 38, and are appropriately presented and disclosed.'
  ].join(' ');
}

return { METHODS, METHOD_LABEL,
  code:'IA', name:'Intangible Assets', group:'Assets', accepts:'.xlsx,.xlsm,.csv',
  blurb:'The intangibles audit file: lead by class, movement schedule, amortisation recalculation, additions with the FRS 38 recognition criteria, indefinite-life and not-yet-in-use flags, FRS 36 impairment and derecognition — from one uploaded register.',
  objective:'To obtain sufficient appropriate audit evidence over the existence, completeness, valuation, rights and presentation of intangible assets, including that capitalised costs meet the FRS 38 recognition criteria and that indefinite-life assets and assets not yet available for use are tested annually for impairment.',
  fields, tests, compute, pages, defaultConfig, STANDARD_COLUMNS, CONVENTIONS, INDICATORS, CANDIDATE_RULES, CRITERIA,
  procedures: pages.flatMap(p => p.procedures || []),
  columns: STANDARD_COLUMNS, suggestConclusion
};
})();

Modules.register(IAModule);
