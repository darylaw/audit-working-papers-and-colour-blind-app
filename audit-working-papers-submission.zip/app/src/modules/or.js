/* ==========================================================================
   or.js -- Other receivables, deposits and prepayments as an auditor works it.

   One uploaded prepayments schedule (or an other-receivables / deposits
   listing) feeds:
     L4    Lead schedule by nature          L4.3  Other receivables recoverability
     L4.1  Prepayment amortisation          L4.4  Current / non-current classification
     L4.2  Deposits vouching
   ========================================================================== */

const ORModule = (() => {
const r2 = n => n == null || isNaN(n) ? null : Math.round(n * 100) / 100;
const days = (a, b) => (a && b) ? Math.round((a - b) / 86400000) : null;
const num = v => (v === '' || v == null || isNaN(Number(v))) ? null : Number(v);
const inp = (cfg, key, k) => num(cfg[key + ':' + k]);
const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
const addMonths = (d, m) => { const x = new Date(d.getTime()); x.setUTCMonth(x.getUTCMonth() + Math.round(m)); return x; };

const NATURES = ['Prepayments', 'Deposits', 'Other receivables', 'Staff advances'];
const natKey = n => n.toLowerCase().replace(/[^a-z]+/g, '-');
const STAFF_RE = /staff|employee|salary\s+advance|payroll\s+advance|loan\s+to\s+(staff|employee|director)|director.{0,12}(loan|advance)|advance\s+to\s+(staff|employee)/i;
const DEPOSIT_RE = /deposit|security\b|retention|guarantee|bond\b|bank\s+guarantee|collateral/i;
const PREPAY_RE = /prepay|prepaid|insurance|subscription|licen[cs]e|rent(al)?\s+in\s+advance|maintenance|retainer|advance\s+payment|property\s+tax|road\s+tax|membership|software|warranty|service\s+contract|support\s+contract|premium/i;
const OTHER_RE = /gst|vat|tax\s+recover|receivable|refund|interest\s+rec|dividend|sundry|accrued\s+income|advance\s+to\s+supplier|claim|grant|rebate|reimburse/i;

/* ---------------------------------------------------------------- fields */
const fields = [
  { key:'description', label:'Description', type:'text', required:true, role:'key', dupKey:true,
    synonyms:['Description','Particulars','Nature of Accrual','Nature of Prepayment','Details','Item','Prepayment','Name','Narrative','Nature','Expense Type','Policy / Contract','Contract','摘要','项目','说明'] },
  { key:'nature', label:'Nature / type', type:'text', role:'category', satisfiedByGroup:true,
    synonyms:['Type','Category','Class','Classification','Balance Type','Account Type','Group','类别','类型'] },
  { key:'account', label:'Account code', type:'text',
    synonyms:['GL Code','Account','A/C','Account Code','GL Account','Account No','Nominal Code','科目代码'] },
  { key:'amount_paid', label:'Amount paid / cost', type:'number', block:'Cost',
    synonyms:['Amount Paid','Invoice Amount','Total Paid','Cost','Gross Amount','Original Amount','Amount Prepaid','Prepaid Amount','Principal','Contract Value','Premium Paid','Total Premium','付款金额','原值'] },
  { key:'period_from', label:'Coverage from', type:'date',
    synonyms:['Period From','From','Start Date','Coverage From','Commencement','Period Start','Effective Date','From Date','Start','Coverage Start','Date From','起始日期','开始日期'] },
  { key:'period_to', label:'Coverage to', type:'date',
    synonyms:['Period To','To','End Date','Coverage To','Expiry','Expiry Date','Period End','To Date','End','Coverage End','Date To','Maturity','截止日期','结束日期'] },
  { key:'months', label:'Coverage months', type:'number',
    synonyms:['Months','No. of Months','Period (Months)','Term (Months)','Tenure','Coverage Months','Mths','No of Months','月数'] },
  { key:'opening', label:'Balance b/f', type:'number',
    synonyms:['Opening Balance','Balance B/F','Bal 1 Jan','Opening','Bal B/F','Brought Forward','期初余额'] },
  { key:'expensed', label:'Amortised to P&L in the year', type:'number',
    synonyms:['Amortised to P&L','Expensed','Charge for Year','Released','Amortisation','Amortised','Expensed in Year','Charge','Utilised','Utilised / Reversed','Released to P&L','Amortisation for the Year','Current Year Charge','本期摊销','本期摊销额'] },
  /* counterparty is declared after the coverage dates: its 'Paid To' synonym would otherwise take a bare 'To' heading first */
  { key:'counterparty', label:'Counterparty', type:'text',
    synonyms:['Counterparty','Supplier','Vendor','Payee','Landlord','Paid To','Debtor','Employee','Name of Party','Party','Insurer','Provider','Paid to','供应商','对方单位'] },
  { key:'closing', label:'Balance at year end', type:'number', required:true, dupKey:true,
    synonyms:['Closing Balance','Balance C/F','Bal at Year End','Balance','Amount','Outstanding','Carrying Amount','Closing','Prepaid Balance','Balance at Year End','Unamortised','Unamortised Balance','Bal C/F','Amount Outstanding','余额','期末余额','金额'] },
  { key:'date', label:'Date paid / advanced', type:'date',
    synonyms:['Date','Date Paid','Payment Date','Invoice Date','Date of Advance','Transaction Date','Doc Date','Paid On','日期','付款日期'] },
  { key:'due_date', label:'Expected recovery date', type:'date',
    synonyms:['Due Date','Expected Recovery Date','Repayment Date','Recovery Date','Refund Date','Expected Refund','到期日'] },
  { key:'refundable', label:'Refundable (Y/N)', type:'text',
    synonyms:['Refundable','Refundable (Y/N)','Refundable?','Recoverable','可退还'] }
];

const STANDARD_COLUMNS = [
  { key:'description', label:'Description' }, { key:'counterparty', label:'Counterparty' }, { key:'__nature', label:'Nature' },
  { key:'amount_paid', label:'Paid / cost', type:'num', edit:true }, { key:'period_from', label:'From', type:'date', edit:true },
  { key:'period_to', label:'To', type:'date', edit:true }, { key:'months', label:'Months', type:'num', dp:0, edit:true },
  { key:'expensed', label:'Amortised (client)', type:'num', edit:true }, { key:'closing', label:'Balance (client)', type:'num', edit:true, emphasis:true },
  { key:'__expClosing', label:'Balance per audit', type:'num' }, { key:'__closeDiff', label:'Difference', type:'num' }, { key:'__status', label:'Status' }
];

const defaultConfig = () => ({
  castTol: 0.01,
  amortBasis: 'daily',            // 'daily' | 'monthly'
  amortTol: '',                   // blank = max(trivial, 0.5% of cost, 1)
  longOutstanding: 365,
  tbTotal: '', pyTotal: ''
});

/* ============================================================ COMPUTE */
function classify(r) {
  const o = r.__wp?.lead?.nature;
  if (NATURES.includes(o)) return o;
  const n = String(r.nature || '');
  if (n) {
    if (STAFF_RE.test(n)) return 'Staff advances';
    if (/deposit/i.test(n)) return 'Deposits';
    if (/prepay|prepaid/i.test(n)) return 'Prepayments';
    if (/other|sundry|receiv/i.test(n)) return 'Other receivables';
  }
  const d = String(r.description || '');
  const hasCoverage = !!(r.period_from && (r.period_to || r.months > 0));
  if (STAFF_RE.test(d)) return 'Staff advances';
  if (hasCoverage) return 'Prepayments';
  if (DEPOSIT_RE.test(d)) return 'Deposits';
  if (PREPAY_RE.test(d)) return 'Prepayments';
  if (OTHER_RE.test(d)) return 'Other receivables';
  return 'Other receivables';
}

function compute(recs, cfg, eng) {
  const ye = eng.yearEndDate, fys = eng.fyStartDate;
  const pm = eng.materiality?.pm || 0, trivial = eng.materiality?.trivial || 0;
  const basis = cfg.amortBasis === 'monthly' ? 'monthly' : 'daily';
  const longOut = Number(cfg.longOutstanding) || 365;
  const tolOf = paid => { const t = num(cfg.amortTol); return t != null && t > 0 ? t : Math.max(trivial, 0.005 * Math.abs(paid || 0), 1); };
  const live = recs.filter(r => !r.__excluded);

  const nat = {};
  NATURES.forEach(n => nat[n] = { nature:n, key:natKey(n), count:0, closing:0, paid:0, expensed:0, expClosing:0, expCharge:0 });

  for (const r of recs) {
    r.__displayKey = r.description || r.counterparty || ('row ' + r.__srcRow);
    r.__nature = classify(r);
    r.__isPrepayment = r.__nature === 'Prepayments';
    const paid = r.amount_paid, closing = r.closing || 0;
    let from = r.period_from, to = r.period_to;
    if (!to && from && r.months > 0) to = addMonths(from, r.months);
    r.__from = from; r.__to = to;
    r.__totalDays = (from && to) ? days(to, from) : null;
    r.__periodInvalid = r.__isPrepayment && (!from || !to || r.__totalDays <= 0);
    r.__negative = closing < -0.005;
    r.__tol = tolOf(paid != null ? paid : closing);
    r.__expClosing = null; r.__expCharge = null; r.__closeDiff = null; r.__chargeDiff = null; r.__consumed = null;
    r.__remainingDays = null; r.__current = null; r.__nonCurrent = null;
    /* coverage that ended before the year end is expired whatever the state of the other dates — a balance on it is an error of any size */
    r.__expired = !!(r.__isPrepayment && to && ye && to < ye);

    if (r.__isPrepayment && paid != null && from && to && r.__totalDays > 0) {
      let consumed, chargeFrac;
      if (basis === 'monthly') {
        const totM = Math.max(1, Math.round(r.__totalDays / 30.4375));
        const usedM = clamp(Math.round(days(ye, from) / 30.4375), 0, totM);
        const start = fys && from < fys ? fys : from, end = to < ye ? to : ye;
        const inYearM = clamp(Math.round(Math.max(0, days(end, start)) / 30.4375), 0, totM);
        consumed = usedM / totM; chargeFrac = inYearM / totM;
      } else {
        consumed = clamp(days(ye, from) / r.__totalDays, 0, 1);
        const start = fys && from < fys ? fys : from, end = to < ye ? to : ye;
        chargeFrac = clamp(Math.max(0, days(end, start)) / r.__totalDays, 0, 1);
      }
      r.__consumed = consumed;
      r.__expClosing = r2(paid * (1 - consumed));
      r.__expCharge = r2(paid * chargeFrac);
      r.__expired = to < ye;
      r.__remainingDays = Math.max(0, days(to, ye));
      r.__current = r2(paid * clamp(r.__remainingDays, 0, 365) / r.__totalDays);
      r.__nonCurrent = r2(Math.max(0, r.__expClosing - r.__current));
      r.__closeDiff = r2(closing - r.__expClosing);
      r.__chargeDiff = r.expensed != null ? r2(r.expensed - r.__expCharge) : null;
      r.__status = r.__negative ? 'Negative' : (r.__expired && closing > 0.01) ? 'Expired' : r.__closeDiff > r.__tol ? 'Under-amortised' : r.__closeDiff < -r.__tol ? 'Over-amortised' : 'Agrees';
    } else if (r.__isPrepayment) {
      r.__status = r.__negative ? 'Negative' : (r.__expired && closing > 0.01) ? 'Expired' : 'No coverage data';
      r.__current = r2(closing); r.__nonCurrent = 0;
    } else {
      r.__status = r.__negative ? 'Negative' : '';
      const beyond = r.__wp?.classif?.beyond12 === 'Y' || (r.due_date && ye && days(r.due_date, ye) > 365);
      r.__current = beyond ? 0 : r2(closing); r.__nonCurrent = beyond ? r2(closing) : 0;
    }
    r.__impliedOpening = (paid != null && r.expensed != null) ? r2(closing + r.expensed - paid) : null;
    r.__castDiff = (r.__impliedOpening != null && from && fys && from >= fys && !r.__expired) ? r.__impliedOpening : null;

    /* recoverability (other receivables / staff advances) */
    r.__age = r.date && ye ? days(ye, r.date) : null;
    const w = r.__wp?.recov || {};
    r.__receipt = num(w.receipt); r.__provision = num(w.provision);
    r.__unrecovered = r2(closing - (r.__receipt || 0));
    r.__netExposure = r2(r.__unrecovered - (r.__provision || 0));
    r.__longOut = r.__age != null && r.__age > longOut;
    r.__refundable = String(r.__wp?.deposits?.refundable || r.refundable || '').trim();
    r.__clientClass = r.__wp?.classif?.clientClass || '';

    if (r.__excluded) continue;
    const c = nat[r.__nature];
    c.count++; c.closing += closing; c.paid += paid || 0; c.expensed += r.expensed || 0;
    c.expClosing += r.__expClosing != null ? r.__expClosing : closing; c.expCharge += r.__expCharge || 0;
  }

  /* ---- L4 lead by nature -------------------------------------------- */
  const tbTotal = num(cfg.tbTotal), pyTotal = num(cfg.pyTotal);
  const lead = NATURES.map(n => {
    const c = nat[n], tb = inp(cfg, 'tb', c.key), py = inp(cfg, 'py', c.key);
    const variance = py != null ? r2(c.closing - py) : null;
    return { ...c, closing: r2(c.closing), paid: r2(c.paid), expensed: r2(c.expensed), expClosing: r2(c.expClosing), expCharge: r2(c.expCharge),
      tb, py, tbDiff: tb != null ? r2(c.closing - tb) : null, variance, variancePct: (variance != null && py) ? r2(variance / Math.abs(py) * 100) : null,
      material: variance != null && Math.abs(variance) > pm };
  });
  const total = r2(live.reduce((s, r) => s + (r.closing || 0), 0));
  const leadTotals = { closing: total, tb: r2(lead.reduce((s, l) => s + (l.tb || 0), 0)), py: r2(lead.reduce((s, l) => s + (l.py || 0), 0)),
    tbEntered: lead.some(l => l.tb != null), pyEntered: lead.some(l => l.py != null) };
  const tbRef = leadTotals.tbEntered ? leadTotals.tb : tbTotal;
  const pyRef = leadTotals.pyEntered ? leadTotals.py : pyTotal;

  /* ---- L4.1 amortisation ------------------------------------------- */
  const preps = live.filter(r => r.__isPrepayment).sort((a, b) => (b.closing || 0) - (a.closing || 0));
  const withCalc = preps.filter(r => r.__expClosing != null);
  const amort = { rows: preps, basis, count: preps.length,
    closing: r2(preps.reduce((s, r) => s + (r.closing || 0), 0)),
    expClosing: r2(withCalc.reduce((s, r) => s + r.__expClosing, 0)),
    closingCovered: r2(withCalc.reduce((s, r) => s + (r.closing || 0), 0)),
    expensed: r2(preps.reduce((s, r) => s + (r.expensed || 0), 0)),
    expCharge: r2(withCalc.reduce((s, r) => s + r.__expCharge, 0)),
    under: preps.filter(r => r.__status === 'Under-amortised' || (r.__status === 'Expired' && r.__closeDiff > r.__tol)),
    over: preps.filter(r => r.__status === 'Over-amortised'),
    expired: preps.filter(r => r.__expired && (r.closing || 0) > 0.01),
    negative: live.filter(r => r.__negative),
    invalid: preps.filter(r => r.__periodInvalid),
    noCalc: preps.filter(r => r.__expClosing == null),
    vouched: preps.filter(r => r.__wp?.amort?.invoice === 'Y').length };
  amort.diff = r2(amort.closingCovered - amort.expClosing);

  /* ---- L4.2 deposits ------------------------------------------------ */
  const deps = live.filter(r => r.__nature === 'Deposits').sort((a, b) => (b.closing || 0) - (a.closing || 0));
  const deposits = { rows: deps, total: r2(deps.reduce((s, r) => s + (r.closing || 0), 0)),
    vouched: deps.filter(r => r.__wp?.deposits?.doc === 'Y').length,
    confirmed: deps.filter(r => r.__wp?.deposits?.confirmed === 'Y').length,
    nonRefundable: deps.filter(r => /^n/i.test(r.__refundable)) };

  /* ---- L4.3 recoverability ------------------------------------------ */
  const oth = live.filter(r => r.__nature === 'Other receivables' || r.__nature === 'Staff advances').sort((a, b) => (b.closing || 0) - (a.closing || 0));
  const recov = { rows: oth, longOut, total: r2(oth.reduce((s, r) => s + (r.closing || 0), 0)),
    received: r2(oth.reduce((s, r) => s + Math.min(r.__receipt || 0, r.closing || 0), 0)),
    provided: r2(oth.reduce((s, r) => s + (r.__provision || 0), 0)),
    traced: oth.filter(r => r.__receipt != null).length,
    longOutstanding: oth.filter(r => r.__longOut),
    exposed: oth.filter(r => r.__netExposure > trivial && (r.__longOut || r.__receipt != null)),
    staff: oth.filter(r => r.__nature === 'Staff advances') };
  recov.coverage = recov.total ? r2(recov.received / recov.total * 100) : 0;

  /* ---- L4.4 classification ------------------------------------------ */
  const classRows = live.filter(r => r.closing != null).sort((a, b) => (b.__nonCurrent || 0) - (a.__nonCurrent || 0));
  const classif = { rows: classRows,
    current: r2(classRows.reduce((s, r) => s + (r.__current || 0), 0)),
    nonCurrent: r2(classRows.reduce((s, r) => s + (r.__nonCurrent || 0), 0)),
    nonCurrentItems: classRows.filter(r => (r.__nonCurrent || 0) > trivial),
    mismatched: classRows.filter(r => (r.__nonCurrent || 0) > trivial && r.__clientClass === 'Current') };

  return { natures: NATURES, lead, leadTotals, total, tbRef, pyRef,
    tbDiff: tbRef != null ? r2(total - tbRef) : null, variance: pyRef != null ? r2(total - pyRef) : null,
    variancePct: (pyRef != null && pyRef) ? r2((total - pyRef) / Math.abs(pyRef) * 100) : null,
    amort, deposits, recov, classif, count: live.length, pm, trivial };
}

/* ============================================================== TESTS */
const tests = [
  { id:'EX-PRE-01', label:'Prepayment under-amortised — balance exceeds the straight-line recalculation', basis:'L4.1',
    fn:(r) => r.__isPrepayment && r.__closeDiff != null && r.__closeDiff > r.__tol && !r.__negative &&
      { expected:r.__expClosing, actual:r.closing, difference:r.__closeDiff, cell:r['__cell_closing'],
        detail:`${(r.__consumed * 100).toFixed(1)}% of the coverage period (${Core.fmtDate(r.__from)} – ${Core.fmtDate(r.__to)}) had elapsed at the year end; balance per audit ${r.__expClosing.toFixed(2)} against ${(r.closing || 0).toFixed(2)} recorded` } },
  { id:'EX-PRE-02', label:'Balance carried on an expired coverage period', basis:'L4.1',
    fn:(r) => r.__isPrepayment && r.__expired && (r.closing || 0) > 0.01 &&
      { expected:0, actual:r.closing, difference:r.closing, cell:r['__cell_closing'],
        detail:`Coverage ended ${Core.fmtDate(r.__to)}, before the year end${r.__totalDays <= 0 ? ' (period end precedes period start)' : ''}. The whole balance should have been released to profit or loss.` } },
  { id:'EX-PRE-03', label:'Negative balance', basis:'L4.1', severity:'above-trivial',
    fn:(r) => r.__negative && { actual:r.closing, difference:r.closing, cell:r['__cell_closing'],
      detail:'A credit balance in prepayments or receivables — over-amortisation, a refund received in excess, or a liability misclassified. Reclassify or correct.' } },
  { id:'EX-PRE-04', label:'Prepayment over-amortised — balance below the straight-line recalculation', basis:'L4.1',
    fn:(r) => r.__isPrepayment && r.__closeDiff != null && r.__closeDiff < -r.__tol && !r.__negative &&
      { expected:r.__expClosing, actual:r.closing, difference:r.__closeDiff, cell:r['__cell_closing'], detail:'Balance is lower than the unexpired portion of the cost — the charge to profit or loss appears overstated' } },
  { id:'EX-PRE-05', label:'Prepayment without a usable coverage period', basis:'L4.1', severity:'informational',
    fn:(r) => r.__isPrepayment && (r.__periodInvalid || r.amount_paid == null) && (r.closing || 0) > 0.005 &&
      { actual: r.__from && r.__to ? `${Core.fmtDate(r.__from)} – ${Core.fmtDate(r.__to)}` : 'dates missing', difference:r.closing, cell:r['__cell_period_to'],
        detail: r.__totalDays != null && r.__totalDays <= 0 ? 'Coverage end date is on or before the start date — obtain the policy or contract and correct the schedule' : 'Coverage dates or cost not stated — the balance cannot be recalculated; obtain the invoice and coverage period' } },
  { id:'EX-PRE-06', label:'Schedule line does not cast (cost − amortised ≠ balance)', basis:'L4.1',
    fn:(r, cfg) => r.__castDiff != null && Math.abs(r.__castDiff) > Math.max(Number(cfg.castTol) || 0.01, 0.01) &&
      { expected:r2((r.amount_paid || 0) - (r.expensed || 0)), actual:r.closing, difference:r.__castDiff, cell:r['__cell_closing'],
        detail:'Coverage started in the year, so cost less the charge for the year should equal the balance; the line does not cast' } },
  { id:'EX-PRE-07', label:'Non-current portion identified — presentation to be confirmed', basis:'L4.4', severity:'informational',
    fn:(r, cfg, eng) => (r.__nonCurrent || 0) > (eng.materiality?.trivial || 0) && r.__clientClass !== 'Non-current' && r.__clientClass !== 'Split' &&
      { actual:r.__nonCurrent, difference:r.__nonCurrent, detail:`${r.__nonCurrent.toFixed(2)} of the balance is recoverable more than twelve months after the reporting date${r.__clientClass === 'Current' ? ' but is classified as current by the client' : ''}` } },
  { id:'EX-PRE-08', label:'Other receivable not recovered after the year end and not provided for', basis:'L4.3',
    fn:(r) => (r.__nature === 'Other receivables' || r.__nature === 'Staff advances') && r.__netExposure > 0.005 && (r.__longOut || r.__receipt != null) &&
      r.__netExposure > (r.__tol || 0) && { actual:r.__unrecovered, difference:r.__netExposure, cell:r['__cell_closing'],
        detail:`${r.__longOut ? r.__age + ' days old at the year end; ' : ''}${r.__receipt != null ? 'subsequent receipts ' + r.__receipt.toFixed(2) + '; ' : ''}unprovided exposure ${r.__netExposure.toFixed(2)}` } },
  { id:'EX-PRE-09', label:'Non-refundable deposit carried as an asset', basis:'L4.2', severity:'informational',
    fn:(r) => r.__nature === 'Deposits' && /^n/i.test(r.__refundable) && (r.closing || 0) > 0.005 &&
      { actual:r.closing, difference:r.closing, detail:'A non-refundable deposit is a prepayment of the related cost, not a recoverable amount — consider reclassification or release' } },
  { id:'EX-PRE-10', label:'Possible duplicate line', basis:'L4.0a', severity:'informational',
    fn:(r) => { const f = r.__flags.find(x => x.rule === 'DQ-10'); return f && { detail:f.detail, difference:r.closing }; } },
  { id:'EX-PRE-20', scope:'population', label:'Listing does not agree to the trial balance', basis:'L4',
    fn:(recs, cfg, eng, d) => {
      const tol = Number(cfg.castTol) || 0.01;
      const perNature = d.lead.filter(l => l.tbDiff != null && Math.abs(l.tbDiff) > tol)
        .map(l => ({ key:l.nature, expected:l.tb, actual:l.closing, difference:l.tbDiff, detail:'Listing total for this nature against the trial balance figure entered' }));
      if (perNature.length) return perNature;
      return !d.leadTotals.tbEntered && d.tbDiff != null && Math.abs(d.tbDiff) > tol &&
        { key:'Other receivables, deposits and prepayments', expected:d.tbRef, actual:d.total, difference:d.tbDiff, detail:'Listing total against the trial balance total entered' };
    } }
];

/* ============================================================== PAGES */
const yn = ['Y', 'N'];
const baseRow = r => ({ __rec:r, description:r.description, counterparty:r.counterparty, nature:r.__nature, closing:r.closing });
const chipNature = v => v === 'Prepayments' ? 'info' : v === 'Deposits' ? 'grey' : v === 'Staff advances' ? 'warn' : 'ok';
const chipStatus = v => v === 'Agrees' ? 'ok' : v === 'Negative' || v === 'Expired' || v === 'Under-amortised' ? 'bad' : v === 'Over-amortised' || v === 'No coverage data' ? 'warn' : 'grey';

const pages = [
  { id:'source',  ref:'L4.0',  title:'Source data',     kind:'source' },
  { id:'cleaned', ref:'L4.0a', title:'Cleaned listing', kind:'cleaned' },
  { id:'mapping', ref:'L4.0b', title:'Column mapping',  kind:'mapping' },

  { id:'lead', ref:'L4', title:'Lead schedule',
    objective:'To agree other receivables, deposits and prepayments per the client\'s schedule to the trial balance and the prior year audited figures by nature, and to explain material movements.',
    procedures:['Classified every line of the schedule by nature — prepayments, deposits, other receivables and staff advances — from the description and coverage data, and confirmed the classification.',
                'Agreed the total by nature to the trial balance and compared it to the prior year audited figure; investigated movements above performance materiality.'],
    render(st, ctx) {
      const d = ctx.d, m0 = ctx.money0, money = ctx.money;
      return [
        { type:'controls', items:[
          { key:'tbTotal', label:'Total per trial balance (if not entered by nature below)', kind:'number' },
          { key:'pyTotal', label:'Total per prior year audited financial statements', kind:'number' },
          { key:'castTol', label:'Tolerance', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Listing total', value: m0(d.total) }, { label:'Lines', value: d.count },
          { label:'Per trial balance', value: d.tbRef == null ? '— enter —' : m0(d.tbRef) },
          { label:'Listing − TB', value: d.tbDiff == null ? '' : money(d.tbDiff), cls: d.tbDiff == null ? '' : Math.abs(d.tbDiff) > 0.01 ? 'bad' : 'ok' },
          { label:'Prior year', value: d.pyRef == null ? '— enter —' : m0(d.pyRef) },
          { label:'Movement vs PY', value: d.variance == null ? '' : `${money(d.variance)} (${ctx.pct(d.variancePct)})`, cls: d.variance != null && Math.abs(d.variance) > ctx.pm ? 'warn' : '' },
          { label:'Negative balances', value: d.amort.negative.length, cls: d.amort.negative.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Balance by nature — listing vs trial balance vs prior year', columns:[
          { key:'nature', label:'Nature', type:'chip', chipClass: chipNature }, { key:'count', label:'Lines', type:'int' },
          { key:'paid', label:'Cost / paid', type:'num', sum:true }, { key:'expensed', label:'Amortised in year (client)', type:'num', sum:true },
          { key:'closing', label:'Balance per listing', type:'num', sum:true, emphasis:true },
          { key:'tb', label:'Per trial balance', input:'number' },
          { key:'tbDiff', label:'Listing − TB', type:'num', flag: v => v != null && Math.abs(v) > 0.01 },
          { key:'py', label:'Prior year audited', input:'number' },
          { key:'variance', label:'Movement vs PY', type:'num', flag: (v, row) => row.__cls === 'flag' }, { key:'variancePct', label:'Movement %', type:'pct' },
          { key:'comment', label:'Explanation of movement', input:'text', wide:true } ],
          rows: d.lead.map(l => ({ __key:l.key, ...l, variancePct: l.variancePct != null ? l.variancePct / 100 : null, __cls: l.material ? 'flag' : '' })),
          footnote:'Enter the trial balance and prior year figure for each nature. Differences above the tolerance are raised as EX-PRE-20.' },
        { type:'table', title:'Schedule lines and their classification', columns:[
          { key:'description', label:'Description' }, { key:'counterparty', label:'Counterparty' },
          { key:'natureC', label:'Nature per audit', type:'chip', chipClass: chipNature },
          { key:'nature', label:'Override nature', input:'select', options:NATURES, recompute:true },
          { key:'from', label:'From', type:'date' }, { key:'to', label:'To', type:'date' },
          { key:'closing', label:'Balance', type:'num', sum:true, flag: v => v != null && v < -0.005 } ],
          rows: ctx.recs.map(r => ({ ...baseRow(r), natureC:r.__nature, from:r.__from, to:r.__to, __cls: r.__negative ? 'flag' : '' })), maxHeight:'50vh',
          footnote:'Nature is inferred from the description and coverage dates; where a line carries coverage dates and an amortisation charge it is treated as a prepayment. Use the override where the inference is wrong — the rest of the file follows the override.' }
      ];
    },
    flag(st, d) { return (d.tbDiff != null && Math.abs(d.tbDiff) > 0.01) || d.lead.some(l => l.tbDiff != null && Math.abs(l.tbDiff) > 0.01) || d.amort.negative.length > 0; } },

  { id:'amort', ref:'L4.1', title:'Prepayment amortisation',
    objective:'To recalculate the unexpired portion of each prepayment on a straight-line basis over its coverage period and compare it to the balance carried, identifying balances under- or over-amortised, carried beyond the coverage period, or negative.',
    procedures:['For each prepayment, recalculated the charge for the year and the unexpired balance at the reporting date on a straight-line basis over the coverage period stated.',
                'Compared the recalculated balance to the balance per the schedule and investigated differences above the tolerance.',
                'Identified balances whose coverage period ended before the year end and negative balances.',
                'Vouched the cost and coverage period of each prepayment to the supplier invoice, policy or contract.'],
    render(st, ctx) {
      const A = ctx.d.amort, m0 = ctx.money0, money = ctx.money;
      const rows = A.rows.map(r => ({ __rec:r, description:r.description, counterparty:r.counterparty, paid:r.amount_paid, from:r.__from, to:r.__to,
        totalDays:r.__totalDays, consumed:r.__consumed, expensed:r.expensed, expCharge:r.__expCharge, chargeDiff:r.__chargeDiff,
        closing:r.closing, expClosing:r.__expClosing, closeDiff:r.__closeDiff, cast:r.__castDiff, status:r.__status,
        __cls: ['Negative', 'Expired', 'Under-amortised'].includes(r.__status) ? 'flag' : '' }));
      return [
        { type:'controls', items:[
          { key:'amortBasis', label:'Straight-line basis', kind:'select', options:[['daily', 'Daily — actual days elapsed over the coverage period'], ['monthly', 'Monthly — whole months elapsed over the coverage period']] },
          { key:'amortTol', label:'Tolerance for differences', kind:'number', help:`Blank = the greater of the trivial threshold (${m0(ctx.trivial)}) and 0.5% of the cost.` } ] },
        { type:'stats', items:[
          { label:'Prepayments', value: `${A.count} · ${m0(A.closing)}` },
          { label:'Balance per audit (lines recalculated)', value: m0(A.expClosing) },
          { label:'Balance per client (same lines)', value: m0(A.closingCovered) },
          { label:'Difference', value: money(A.diff), cls: A.diff == null ? '' : Math.abs(A.diff) > 0.01 ? 'bad' : 'ok' },
          { label:'Charge per client vs per audit', value: `${m0(A.expensed)} vs ${m0(A.expCharge)}` },
          { label:'Under-amortised', value: A.under.length, cls: A.under.length ? 'bad' : 'ok' },
          { label:'Over-amortised', value: A.over.length, cls: A.over.length ? 'warn' : 'ok' },
          { label:'Expired coverage still carried', value: A.expired.length, cls: A.expired.length ? 'bad' : 'ok' },
          { label:'Negative balances', value: A.negative.length, cls: A.negative.length ? 'bad' : 'ok' },
          { label:'Cannot recalculate', value: A.noCalc.length, cls: A.noCalc.length ? 'warn' : 'ok' },
          { label:'Vouched to invoice / policy', value: `${A.vouched} of ${A.count}`, cls: A.vouched === A.count && A.count ? 'ok' : 'warn' } ] },
        { type:'table', title:'Straight-line recalculation', columns:[
          { key:'description', label:'Description' }, { key:'counterparty', label:'Counterparty' },
          { key:'paid', label:'Cost', type:'num', sum:true }, { key:'from', label:'From', type:'date' }, { key:'to', label:'To', type:'date' },
          { key:'totalDays', label:'Days', type:'int' }, { key:'consumed', label:'Elapsed at YE', type:'pct', dp:1 },
          { key:'expensed', label:'Charge per client', type:'num', sum:true }, { key:'expCharge', label:'Charge per audit', type:'num', sum:true },
          { key:'chargeDiff', label:'Charge difference', type:'num', flag: (v, row) => v != null && Math.abs(v) > (row.__rec.__tol || 0) },
          { key:'closing', label:'Balance per client', type:'num', sum:true, emphasis:true }, { key:'expClosing', label:'Balance per audit', type:'num', sum:true, emphasis:true },
          { key:'closeDiff', label:'Difference', type:'num', flag: (v, row) => v != null && Math.abs(v) > (row.__rec.__tol || 0) },
          { key:'cast', label:'Cost − charge − balance', type:'num', flag: v => v != null && Math.abs(v) > 0.01 },
          { key:'status', label:'Status', type:'chip', chipClass: chipStatus },
          { key:'invoice', label:'Invoice / policy sighted (Y/N)', input:'select', options:yn },
          { key:'coverage', label:'Coverage period agreed (Y/N)', input:'select', options:yn },
          { key:'comment', label:'Comment', input:'text', wide:true } ], rows, maxHeight:'70vh',
          emptyText:'No lines classified as prepayments. Check the classification on L4.',
          footnote:'Balance per audit = cost × unexpired portion of the coverage period at the reporting date. Charge per audit = cost × portion of the coverage period falling within the financial year. The cast column is shown only where coverage began within the year (otherwise the difference is prior-year amortisation).' }
      ];
    },
    flag(st, d) { return d.amort.under.length > 0 || d.amort.expired.length > 0 || d.amort.negative.length > 0 || d.amort.over.length > 0; } },

  { id:'deposits', ref:'L4.2', title:'Deposits vouching',
    objective:'To verify that deposits exist, are held by the counterparty stated, are refundable and recoverable, and are correctly classified between current and non-current.',
    procedures:['Listed every deposit and vouched it to the agreement, receipt or invoice evidencing the amount and the refund terms.',
                'Recorded whether each deposit is refundable and, where significant, confirmed the amount held directly with the counterparty.',
                'Noted the expected recovery date for the classification review on L4.4.'],
    render(st, ctx) {
      const D = ctx.d.deposits, m0 = ctx.money0;
      return [
        { type:'stats', items:[
          { label:'Deposits', value: `${D.rows.length} · ${m0(D.total)}` },
          { label:'Vouched to agreement / receipt', value: `${D.vouched} of ${D.rows.length}`, cls: D.vouched === D.rows.length && D.rows.length ? 'ok' : 'warn' },
          { label:'Confirmed with counterparty', value: `${D.confirmed} of ${D.rows.length}` },
          { label:'Non-refundable', value: D.nonRefundable.length, cls: D.nonRefundable.length ? 'warn' : 'ok' } ] },
        { type:'table', title:'Deposits held at the year end', columns:[
          { key:'description', label:'Description' }, { key:'counterparty', label:'Held by (counterparty)' },
          { key:'date', label:'Date paid', type:'date' }, { key:'closing', label:'Amount', type:'num', sum:true, emphasis:true },
          { key:'doc', label:'Agreement / receipt sighted (Y/N)', input:'select', options:yn },
          { key:'docRef', label:'Document reference', input:'text', wide:true },
          { key:'refundable', label:'Refundable (Y/N)', input:'select', options:yn, recompute:true },
          { key:'confirmed', label:'Confirmed with counterparty (Y/N)', input:'select', options:yn },
          { key:'recovery', label:'Expected recovery / expiry', input:'text' },
          { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: D.rows.map(r => ({ ...baseRow(r), date:r.date, __cls: /^n/i.test(r.__refundable) ? 'flag' : '' })),
          emptyText:'No lines classified as deposits. If the schedule carries deposits under another description, override the nature on L4.',
          footnote:'A deposit marked non-refundable is raised as EX-PRE-09 for reclassification.' }
      ];
    },
    flag(st, d) { return d.deposits.nonRefundable.length > 0; } },

  { id:'recov', ref:'L4.3', title:'Other receivables recoverability',
    objective:'To assess whether other receivables and staff advances are recoverable at the reporting date, by ageing each balance, tracing recovery after the year end and evaluating the provision required.',
    procedures:['Aged each other receivable and staff advance from the date advanced to the reporting date and flagged balances outstanding beyond the threshold set.',
                'Traced each balance to receipts after the year end and computed the amount not yet recovered.',
                'Compared the unrecovered amount to any provision made and identified exposures not provided for.',
                'For staff and director advances, considered approval, terms and the disclosure requirements for related parties.'],
    render(st, ctx) {
      const R = ctx.d.recov, m0 = ctx.money0, pct = ctx.pct;
      return [
        { type:'controls', items:[{ key:'longOutstanding', label:'Long-outstanding threshold (days from date advanced)', kind:'number' }] },
        { type:'stats', items:[
          { label:'Other receivables and advances', value: `${R.rows.length} · ${m0(R.total)}` },
          { label:'Staff / director advances', value: R.staff.length, cls: R.staff.length ? 'warn' : '' },
          { label:'Traced to subsequent receipt', value: `${R.traced} of ${R.rows.length}` },
          { label:'Recovered after year end', value: `${m0(R.received)} (${pct(R.coverage)})`, cls: R.coverage >= 80 ? 'ok' : 'warn' },
          { label:'Provision recorded', value: m0(R.provided) },
          { label:'Long outstanding', value: R.longOutstanding.length, cls: R.longOutstanding.length ? 'warn' : 'ok' },
          { label:'Unprovided exposure', value: R.exposed.length, cls: R.exposed.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Recoverability assessment', columns:[
          { key:'description', label:'Description' }, { key:'counterparty', label:'Counterparty' },
          { key:'nature', label:'Nature', type:'chip', chipClass: chipNature },
          { key:'date', label:'Date advanced', type:'date' }, { key:'age', label:'Days at YE', type:'int' },
          { key:'closing', label:'Balance', type:'num', sum:true, emphasis:true },
          { key:'receipt', label:'Received after year end', input:'number' },
          { key:'receiptDate', label:'Date received', input:'text' },
          { key:'unrecovered', label:'Not yet recovered', type:'num', sum:true },
          { key:'provision', label:'Provision per client', input:'number' },
          { key:'exposure', label:'Unprovided exposure', type:'num', sum:true, flag: (v, row) => v != null && v > ctx.trivial && (row.__rec.__longOut || row.__rec.__receipt != null) },
          { key:'basis', label:'Basis of recoverability (agreement, approval, offset)', input:'text', wide:true },
          { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: R.rows.map(r => ({ ...baseRow(r), date:r.date, age:r.__age, unrecovered:r.__unrecovered, exposure:r.__netExposure, __cls: r.__longOut ? 'flag' : '' })),
          emptyText:'No lines classified as other receivables or staff advances.',
          footnote:`Balances older than ${R.longOut} days, or with a shortfall against subsequent receipts, that are not provided for are raised as EX-PRE-08.` }
      ];
    },
    flag(st, d) { return d.recov.exposed.length > 0 || d.recov.longOutstanding.length > 0; } },

  { id:'classif', ref:'L4.4', title:'Current / non-current classification',
    objective:'To verify that the portion of each balance recoverable more than twelve months after the reporting date is presented as non-current.',
    procedures:['For each prepayment, computed the portion of the unexpired balance that falls more than twelve months after the reporting date.',
                'For deposits and other receivables, recorded whether recovery is expected beyond twelve months.',
                'Compared the classification per audit to the client\'s presentation.'],
    render(st, ctx) {
      const C = ctx.d.classif, m0 = ctx.money0;
      return [
        { type:'stats', items:[
          { label:'Current per audit', value: m0(C.current) }, { label:'Non-current per audit', value: m0(C.nonCurrent), cls: C.nonCurrent > ctx.trivial ? 'warn' : 'ok' },
          { label:'Lines with a non-current portion', value: C.nonCurrentItems.length },
          { label:'Classified current by client despite non-current portion', value: C.mismatched.length, cls: C.mismatched.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Classification per audit vs per client', columns:[
          { key:'description', label:'Description' }, { key:'nature', label:'Nature', type:'chip', chipClass: chipNature },
          { key:'to', label:'Coverage / recovery to', type:'date' }, { key:'remaining', label:'Days after YE', type:'int' },
          { key:'closing', label:'Balance', type:'num', sum:true, emphasis:true },
          { key:'current', label:'Current per audit', type:'num', sum:true }, { key:'nonCurrent', label:'Non-current per audit', type:'num', sum:true, flag: v => v != null && v > ctx.trivial },
          { key:'beyond12', label:'Recovery beyond 12 months (deposits / receivables) (Y/N)', input:'select', options:yn, recompute:true },
          { key:'clientClass', label:'Client classification', input:'select', options:['Current', 'Non-current', 'Split'], recompute:true },
          { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: C.rows.map(r => ({ ...baseRow(r), to: r.__to || r.due_date || null, remaining: r.__remainingDays, current:r.__current, nonCurrent:r.__nonCurrent,
            __cls: (r.__nonCurrent || 0) > ctx.trivial && r.__clientClass === 'Current' ? 'flag' : '' })), maxHeight:'60vh',
          footnote:'For prepayments the non-current portion is the cost attributable to coverage more than twelve months after the reporting date. Lines with a non-current portion above the trivial threshold are raised as EX-PRE-07 until classified.' }
      ];
    },
    flag(st, d) { return d.classif.mismatched.length > 0; } },

  { id:'conclusion', ref:'L4.9', title:'Exceptions & conclusion', kind:'conclusion' }
];

function suggestConclusion(st, ctx) {
  const d = ctx.d, A = d.amort;
  const ex = (st.exceptions || []).filter(e => e.disposition === 'open');
  return [
    `Other receivables, deposits and prepayments per the schedule total ${ctx.money(d.total)} across ${d.count} lines${d.tbDiff == null ? '' : Math.abs(d.tbDiff) <= 0.01 ? ', agreeing to the trial balance' : `, differing from the trial balance by ${ctx.money(d.tbDiff)}`}.`,
    `${A.count} prepayment(s) totalling ${ctx.money(A.closing)} were recalculated on a straight-line basis; the recalculated balance was ${ctx.money(A.expClosing)} against ${ctx.money(A.closingCovered)} recorded.`,
    A.under.length ? `${A.under.length} balance(s) are under-amortised.` : '', A.expired.length ? `${A.expired.length} balance(s) are carried on coverage that expired before the year end.` : '',
    A.negative.length ? `${A.negative.length} negative balance(s) require reclassification.` : '',
    d.deposits.rows.length ? `${d.deposits.rows.length} deposit(s) totalling ${ctx.money(d.deposits.total)} were vouched; ${d.deposits.vouched} agreed to agreements or receipts.` : '',
    d.recov.rows.length ? `${d.recov.rows.length} other receivable(s) were assessed for recoverability; ${ctx.money(d.recov.received)} was recovered after the year end.` : '',
    d.classif.nonCurrent > ctx.trivial ? `A non-current portion of ${ctx.money(d.classif.nonCurrent)} was identified for separate presentation.` : '',
    ex.length ? `${ex.length} exception(s) remain open in the register.` : 'No exceptions remain open.',
    'Subject to the above, other receivables, deposits and prepayments are fairly stated and appropriately classified at the reporting date.'
  ].filter(Boolean).join(' ');
}

return {
  code:'OR', name:'Other Receivables, Deposits & Prepayments', group:'Assets', accepts:'.xlsx,.xlsm,.csv',
  blurb:'The prepayments and other receivables audit file: lead by nature, straight-line amortisation recalculation, deposits vouching, recoverability and current / non-current classification — from one uploaded schedule.',
  objective:'To obtain sufficient appropriate audit evidence that other receivables, deposits and prepayments exist, are recoverable, are measured at the unexpired or recoverable amount at the reporting date, and are correctly classified between current and non-current.',
  fields, tests, compute, pages, defaultConfig, STANDARD_COLUMNS, NATURES,
  procedures: pages.flatMap(p => p.procedures || []),
  columns: STANDARD_COLUMNS, suggestConclusion
};
})();

Modules.register(ORModule);
