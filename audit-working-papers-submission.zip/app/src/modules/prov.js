/* ==========================================================================
   prov.js -- Provisions and contingencies (FRS 37 / SFRS(I) 1-37) as an
   auditor actually works the area.

   One uploaded provisions and contingencies schedule (movement per provision,
   the current / non-current analysis, expected timing, discount rate,
   undiscounted estimate and expected reimbursement) plus auditor evidence
   feeds:

     U7    Lead schedule                     U7.5  Legal and claims
     U7.1  Movement and casting              U7.6  Contingencies
     U7.2  Recognition test (para 14)        U7.7  Completeness
     U7.3  Measurement (paras 36-58)         U7.8  Estimate evaluation (SSA 540)
     U7.4  Specific provision types          U7.9  Exceptions and conclusion
   ========================================================================== */

const ProvModule = (() => {
const r2 = n => n == null || isNaN(n) ? null : Math.round(n * 100) / 100;
const num = v => (v === '' || v == null || isNaN(Number(v))) ? null : Number(v);
const inp = (cfg, key, k) => num(cfg[key + ':' + k]);
const txt = (cfg, key, k) => { const v = cfg[key + ':' + k]; return v == null ? '' : String(v).trim(); };
const DAY = 86400000;

function toDate(v) {
  if (v instanceof Date) return isNaN(v.getTime()) ? null : v;
  const s = String(v == null ? '' : v).trim();
  if (!/^\d{4}-\d{2}-\d{2}/.test(s)) return null;
  const d = new Date(s.slice(0, 10) + 'T00:00:00Z');
  return isNaN(d.getTime()) ? null : d;
}
const monthsBetween = (from, to) => (from == null || to == null) ? null : r2((to - from) / (DAY * 30.4375));
const yearsBetween = (from, to) => (from == null || to == null) ? null : (to - from) / (DAY * 365.25);
const pv = (amount, ratePct, years) => (amount == null || ratePct == null || years == null) ? null
  : r2(amount / Math.pow(1 + ratePct / 100, Math.max(0, years)));

/* ---------------------------------------------------------------- fields */
const fields = [
  { key:'description', label:'Provision or contingency', role:'key', type:'text', required:true, dupKey:true,
    synonyms:['Nature of Provision','Description','Particulars','Provision / Contingency','Details','Provision','Item','Narrative','Nature','Nature of Obligation','Contingency','摘要','项目','事项'] },
  { key:'class', label:'Class of provision', role:'category', type:'text', required:true, satisfiedByGroup:true, dupKey:true,
    synonyms:['Class of Provision','Provision Type','Category','Class','Type of Provision','Type','Group','Provision Class','Nature / Class','类别','种类'] },
  { key:'status', label:'Classification (provision / contingent)', type:'text',
    synonyms:['Classification','Recognised / Disclosed','Treatment','Provision or Contingency','Status','Recognised or Disclosed','Accounting Treatment','Disclosure','性质','列报'] },
  { key:'account_code', label:'GL account', type:'text',
    synonyms:['GL Code','Account','A/C','Account Code','Nominal','GL Account','Nominal Code','Account No','G/L','科目代码','科目'] },
  { key:'bal_open', label:'Opening balance', type:'number', required:true,
    synonyms:['Opening Balance','Balance B/F','Bal 1 Jan','At Beginning of Year','Brought Forward','Opening','B/F','Balance Brought Forward','At 1 January','Op Bal','期初余额','期初'] },
  { key:'additional', label:'Additional provisions charged', type:'number', required:true,
    synonyms:['Additional Provisions','Charged to P&L','Provided During Year','Additions','Increase in Provision','Charge for the Year','Provided','Additional Provision','Charge','Provisions Made','Increase','本期计提','本期增加'] },
  { key:'utilised', label:'Utilised in the year', type:'number', required:true,
    synonyms:['Utilised During Year','Amounts Used','Utilised','Payments','Applied During Year','Amounts Utilised','Used','Utilized','Utilisation','Settled','Paid','本期使用','本期支付'] },
  { key:'released', label:'Unused amounts reversed', type:'number', required:true,
    synonyms:['Unused Amounts Reversed','Released to P&L','Write-back','Reversals','Released','Unused Amounts Released','Write Back','Reversal of Provision','Released Unused','Written Back','本期转回','转回'] },
  { key:'unwind', label:'Unwinding of discount', type:'number',
    synonyms:['Unwinding of Discount','Discount Unwind','Accretion of Discount','Interest Accretion','Finance Charge on Provision','Unwind of Discount','Unwinding','Accretion','Imputed Interest','折现摊销'] },
  { key:'bal_close', label:'Closing balance', type:'number', required:true,
    synonyms:['Closing Balance','Balance C/F','Bal at Year End','At End of Year','Carried Forward','Closing','C/F','Balance Carried Forward','Year End Balance','At 31 December','期末余额','期末'] },
  { key:'current', label:'Current portion', type:'number',
    synonyms:['Current Portion','Due Within 12 Months','Current','Within One Year','Current Liability','Payable Within 12 Months','Short Term','Within 1 Year','一年内'] },
  { key:'noncurrent', label:'Non-current portion', type:'number',
    synonyms:['Non-current Portion','Due After 12 Months','Non-current','After One Year','Long Term Portion','Payable After 12 Months','Long Term','Non Current','一年以上'] },
  { key:'timing', label:'Expected timing of settlement', type:'date',
    synonyms:['Expected Timing of Settlement','Expected Settlement Date','Estimated Timing','Expected Outflow Date','Settlement Date','Expected Timing','Timing','Expected Date of Settlement','预计支付日期'] },
  { key:'disc_rate', label:'Discount rate applied (%)', type:'number',
    synonyms:['Discount Rate %','Discount Rate','Rate Applied %','Pre-tax Discount Rate','Rate %','Discount %','Rate Applied','折现率'] },
  { key:'undiscounted', label:'Undiscounted estimate / financial effect', type:'number',
    synonyms:['Undiscounted Amount','Gross Expected Outflow','Estimated Financial Effect','Best Estimate (Undiscounted)','Expected Outflow','Undiscounted','Financial Effect','Estimate of Financial Effect','Gross Amount','Maximum Exposure','未折现金额'] },
  { key:'reimbursement', label:'Expected reimbursement', type:'number',
    synonyms:['Expected Reimbursement','Reimbursement Receivable','Recovery Expected','Insurance Recovery','Reimbursement','Recoverable','Expected Recovery','Indemnity','预计补偿'] },
  { key:'basis', label:'Basis of estimate (per client)', type:'text',
    synonyms:['Basis of Estimate','Basis','Basis of Computation','Method of Estimation','Remarks','Comments','Computation','Assumptions','Notes','估计依据'] }
];

const STANDARD_COLUMNS = [
  { key:'description', label:'Provision or contingency' }, { key:'class', label:'Class' },
  { key:'status', label:'Classification' },
  { key:'bal_open', label:'Opening', type:'num', edit:true },
  { key:'additional', label:'Additional', type:'num', edit:true },
  { key:'utilised', label:'Utilised', type:'num', edit:true },
  { key:'released', label:'Released', type:'num', edit:true },
  { key:'unwind', label:'Unwind of discount', type:'num', edit:true },
  { key:'__computedClose', label:'Closing recomputed', type:'num' },
  { key:'bal_close', label:'Closing per client', type:'num', edit:true, emphasis:true },
  { key:'__castDiff', label:'Cast difference', type:'num' },
  { key:'current', label:'Current', type:'num', edit:true },
  { key:'noncurrent', label:'Non-current', type:'num', edit:true },
  { key:'__splitDiff', label:'Split difference', type:'num' }
];

/* ------------------------------------------------------------ the tables
   the auditor completes on U7.4, U7.5 and U7.8.  Each is a fixed number of
   numbered rows stored in cfg as "<column>:<rowKey>", the same idiom the
   post year-end review uses in the accruals file.                         */
const COMPLETENESS = [
  ['cm1', 'Enquired of management and of those charged with governance about litigation, claims, guarantees, indemnities and onerous contracts (SSA 501 para 9).'],
  ['cm2', 'Read the minutes of meetings of the board and of its committees for the period and up to the date of this file.'],
  ['cm3', 'Scanned the legal and professional expense accounts for the year for payments indicating a claim or dispute.'],
  ['cm4', 'Reviewed correspondence with the entity\'s external legal counsel.'],
  ['cm5', 'Reviewed payments made after the reporting date for evidence of obligations existing at the reporting date but not recorded.'],
  ['cm6', 'Obtained written representations that all known actual or possible litigation and claims have been disclosed (SSA 501 para 12).'],
  ['cm7', 'Reviewed significant contracts entered into during the year for onerous terms, guarantees and indemnities.'],
  ['cm8', 'Considered events after the reporting period for evidence of conditions existing at the reporting date (SSA 560, FRS 10).']
];

const EST_PROCESS = [
  { id:'ep1', group:'Understanding', text:'The method, assumptions and data management uses to make each provision estimate have been understood and documented (SSA 540 para 13(b)).' },
  { id:'ep2', group:'Understanding', text:'The controls over the estimation process, including review and approval of the estimates, have been understood (SSA 540 para 13(c)).' },
  { id:'ep3', group:'Understanding', text:'Management\'s use of a specialist (legal counsel, actuary, engineer) has been considered and the competence, capability and objectivity of that specialist evaluated.' },
  { id:'ep4', group:'Evaluation', text:'The method selected is appropriate to the nature of the obligation and has been applied consistently with the prior year (SSA 540 para 23(a)).' },
  { id:'ep5', group:'Evaluation', text:'The significant assumptions are reasonable individually and taken together, and are consistent with those used elsewhere in the financial statements.' },
  { id:'ep6', group:'Evaluation', text:'The data used is relevant and reliable and has been agreed to source records.' },
  { id:'ep7', group:'Stand back', text:'Audit evidence that is contradictory to management\'s estimate has been sought and considered (SSA 540 paras 33, 35).' },
  { id:'ep8', group:'Stand back', text:'The indicators of possible management bias identified have been evaluated and their effect on the audit approach considered (SSA 540 para 32).' }
];

const ASSESS = ['Probable', 'Possible', 'Remote', 'Unable to assess'];
const yn = ['Y', 'N'];
const ynna = ['Y', 'N', 'n/a'];

const defaultConfig = () => ({
  castTol: 0.01,
  movementSign: 'auto',                 /* auto | signed | positive */
  tbProvisions: '', tbCurrent: '', tbNonCurrent: '', pyProvisions: '', financeCost: '',
  discThreshold: '',                    /* blank = performance materiality */
  discMonths: 12,
  unwindTolPct: 5,
  measTolPct: 2,
  retroTol: '',                         /* blank = trivial threshold */
  ocRows: 5, rsRows: 3, wtRows: 4, dcRows: 4, legalRows: 8, kaRows: 6,
  methodChange: '', methodChangeReason: '',
  sensPct: 10,
  standBack: '',
  estProcess: {}
});

/* ============================================================== COMPUTE */
function compute(recs, cfg, eng) {
  const pm = eng.materiality?.pm || 0, trivial = eng.materiality?.trivial || 0;
  const tol = Number(cfg.castTol) || 0.01;
  const ye = eng.yearEndDate || null;
  const live = recs.filter(r => !r.__excluded);

  /* The schedule may carry utilisations and releases as negatives (a movement
     column) or as positives (a deduction column).  Decide once, from the data. */
  let sign = cfg.movementSign;
  if (sign === 'auto') {
    const nz = live.flatMap(r => [r.utilised, r.released]).filter(v => v != null && Math.abs(v) > 0.005);
    sign = nz.length && nz.filter(v => v < 0).length / nz.length > 0.5 ? 'signed' : 'positive';
  }
  const asReduction = v => { const x = v || 0; return sign === 'signed' ? -x : x; };

  const discThreshold = cfg.discThreshold !== '' && cfg.discThreshold != null ? Number(cfg.discThreshold) : pm;
  const discMonths = Number(cfg.discMonths);
  const unwindTolPct = Number(cfg.unwindTolPct) || 0;
  const measTolPct = Number(cfg.measTolPct) || 0;
  const retroTol = cfg.retroTol !== '' && cfg.retroTol != null ? Number(cfg.retroTol) : trivial;

  const T = { open:0, additional:0, utilised:0, released:0, unwind:0, computed:0, close:0,
    castDiff:0, current:0, noncurrent:0, undiscounted:0, reimbursement:0, count:0 };
  const TC = { cl:0, ca:0, clCount:0, caCount:0 };

  for (const r of live) {
    r.__displayKey = r.description || (r.class ? r.class + ' (row ' + r.__srcRow + ')' : 'row ' + r.__srcRow);
    const st = String(r.status || '').toLowerCase();
    r.__status = /contingent\s*asset|或有资产/.test(st) ? 'Contingent asset'
      : /contingent\s*liab|contingency|或有负债/.test(st) ? 'Contingent liability' : 'Provision';
    r.__isProvision = r.__status === 'Provision';
    r.__isCL = r.__status === 'Contingent liability';
    r.__isCA = r.__status === 'Contingent asset';
    r.__class = r.class || 'Unclassified';

    r.__used = r2(asReduction(r.utilised));
    r.__rel = r2(asReduction(r.released));
    r.__unwind = r2(r.unwind || 0);
    r.__computedClose = r2((r.bal_open || 0) + (r.additional || 0) - r.__used - r.__rel + r.__unwind);
    r.__castDiff = r.bal_close != null ? r2(r.bal_close - r.__computedClose) : null;

    const hasSplit = r.current != null || r.noncurrent != null;
    r.__splitTotal = hasSplit ? r2((r.current || 0) + (r.noncurrent || 0)) : null;
    r.__splitDiff = (r.__splitTotal != null && r.bal_close != null) ? r2(r.__splitTotal - r.bal_close) : null;

    /* bias indicators read straight off the movement (SSA 540 para 32) */
    const open = r.bal_open || 0;
    r.__releasedInFull = open > tol && Math.abs(r.__rel - open) <= Math.max(tol, open * 0.005) &&
      Math.abs(r.bal_close || 0) <= tol && Math.abs(r.__used) <= tol;
    r.__reCreated = open > tol && r.__rel >= open * 0.9 && (r.additional || 0) > tol && Math.abs(r.bal_close || 0) > tol;

    /* measurement inputs (U7.3) */
    const M = r.__wp?.measurement || {};
    r.__population = M.population || '';
    r.__method = M.method || '';
    r.__methodEvidence = (M.evidence || '').trim();
    r.__methodMismatch = !!(r.__population && r.__method &&
      ((r.__population === 'Large population' && r.__method === 'Most likely outcome') ||
       (r.__population === 'Single obligation' && r.__method === 'Expected value')));
    r.__methodUnsupported = r.__isProvision && Math.abs(r.bal_close || 0) > tol && !!r.__method &&
      (r.__methodMismatch || !r.__methodEvidence);

    r.__ratePct = r.disc_rate == null ? null : (Math.abs(r.disc_rate) <= 1 && r.disc_rate !== 0 ? r2(r.disc_rate * 100) : r2(r.disc_rate));
    r.__auditRate = num(M.rate);
    r.__auditSettle = toDate(M.settle) || r.timing || null;
    r.__auditUndisc = num(M.undisc) ?? (r.undiscounted != null ? r.undiscounted : null);
    r.__months = monthsBetween(ye, r.timing);
    r.__years = yearsBetween(ye, r.__auditSettle);

    r.__needsDiscount = r.__isProvision && r.__ratePct == null && r.__months != null &&
      r.__months > discMonths && Math.abs(r.bal_close || 0) >= discThreshold;

    r.__pvAudit = pv(r.__auditUndisc, r.__auditRate, r.__years);
    r.__pvDiff = (r.__pvAudit != null && r.bal_close != null) ? r2(r.bal_close - r.__pvAudit) : null;
    r.__pvTol = r.__pvAudit != null ? Math.max(tol, Math.abs(r.__pvAudit) * measTolPct / 100) : tol;

    r.__expectedUnwind = (r.__ratePct != null && Math.abs(r.bal_open || 0) > tol)
      ? r2((r.bal_open || 0) * r.__ratePct / 100) : null;
    r.__unwindDiff = r.__expectedUnwind != null ? r2(r.__unwind - r.__expectedUnwind) : null;
    r.__unwindTol = r.__expectedUnwind != null ? Math.max(tol, Math.abs(r.__expectedUnwind) * unwindTolPct / 100) : tol;

    r.__reimb = r.reimbursement != null ? r.reimbursement : num(M.reimb);
    r.__reimbCap = (r.__reimb != null && r.bal_close != null) ? r2(Math.max(0, r.bal_close)) : null;
    r.__reimbExcess = (r.__reimb != null && r.__reimbCap != null) ? r2(r.__reimb - r.__reimbCap) : null;
    r.__reimbVC = M.reimbVC || '';
    r.__reimbSep = M.reimbSep || '';
    r.__risks = M.risks || '';
    r.__gains = M.gains || '';

    /* recognition inputs (U7.2) */
    const R = r.__wp?.recognition || {};
    r.__recObligation = R.obligation || '';
    r.__recProbable = R.probable || '';
    r.__recReliable = R.reliable || '';
    r.__recAnswers = [r.__recObligation, r.__recProbable, r.__recReliable];
    r.__recAnswered = r.__recAnswers.filter(Boolean).length;
    r.__recAll = r.__recAnswered === 3 && r.__recAnswers.every(a => a === 'Y');
    r.__recAnyNo = r.__recAnswers.some(a => a === 'N');
    r.__recFailed = r.__recAnyNo ? r.__recAnswers.map((a, i) => a === 'N' ? ['present obligation from a past event', 'probable outflow of resources', 'reliable estimate'][i] : null).filter(Boolean) : [];

    /* U7.4 future operating losses (para 63) */
    const Ty = r.__wp?.types || {};
    r.__folAnswer = Ty.folYN || '';
    r.__futureOpLoss = r.__folAnswer === 'Y' ||
      (r.__folAnswer !== 'N' && /future operating loss|future trading loss|operating losses of/i.test(String(r.description || '')));

    /* U7.8 retrospective review */
    const E = r.__wp?.estimate || {};
    r.__retroPY = num(E.pyProv);
    r.__retroActual = num(E.actual);
    r.__retroDiff = (r.__retroPY != null && r.__retroActual != null) ? r2(r.__retroActual - r.__retroPY) : null;
    r.__retroDir = r.__retroDiff == null ? '' : r.__retroDiff < -retroTol ? 'Over-provided'
      : r.__retroDiff > retroTol ? 'Under-provided' : 'In line';

    if (r.__isProvision) {
      T.open += r.bal_open || 0; T.additional += r.additional || 0; T.utilised += r.__used;
      T.released += r.__rel; T.unwind += r.__unwind; T.computed += r.__computedClose || 0;
      T.close += r.bal_close || 0; T.castDiff += r.__castDiff || 0;
      T.current += r.current || 0; T.noncurrent += r.noncurrent || 0;
      T.undiscounted += r.undiscounted || 0; T.reimbursement += r.__reimb || 0; T.count++;
    } else if (r.__isCL) { TC.cl += r.undiscounted || 0; TC.clCount++; }
    else { TC.ca += r.undiscounted || 0; TC.caCount++; }
  }
  for (const k of Object.keys(T)) T[k] = r2(T[k]);
  TC.cl = r2(TC.cl); TC.ca = r2(TC.ca);

  const provisions = live.filter(r => r.__isProvision);
  const contLiabs = live.filter(r => r.__isCL);
  const contAssets = live.filter(r => r.__isCA);

  /* ---- U7 lead ------------------------------------------------------- */
  const byClass = [];
  const seen = new Map();
  for (const r of provisions) {
    let g = seen.get(r.__class);
    if (!g) { g = { class:r.__class, count:0, open:0, additional:0, utilised:0, released:0, unwind:0, close:0, current:0, noncurrent:0 }; seen.set(r.__class, g); byClass.push(g); }
    g.count++; g.open += r.bal_open || 0; g.additional += r.additional || 0; g.utilised += r.__used;
    g.released += r.__rel; g.unwind += r.__unwind; g.close += r.bal_close || 0;
    g.current += r.current || 0; g.noncurrent += r.noncurrent || 0;
  }
  for (const g of byClass) for (const k of ['open', 'additional', 'utilised', 'released', 'unwind', 'close', 'current', 'noncurrent']) g[k] = r2(g[k]);
  byClass.sort((a, b) => Math.abs(b.close) - Math.abs(a.close));

  const tb = num(cfg.tbProvisions), py = num(cfg.pyProvisions);
  const tbCur = num(cfg.tbCurrent), tbNon = num(cfg.tbNonCurrent);
  const lead = { total:T.close, tb, py,
    tbDiff: tb != null ? r2(T.close - tb) : null,
    tbSplit: (tbCur != null || tbNon != null) ? r2((tbCur || 0) + (tbNon || 0)) : null,
    pyDiff: py != null ? r2(T.open - py) : null,
    variance: py != null ? r2(T.close - py) : null,
    variancePct: (py != null && py) ? r2((T.close - py) / Math.abs(py) * 100) : null,
    movement: r2(T.close - T.open),
    movementPct: T.open ? r2((T.close - T.open) / Math.abs(T.open) * 100) : null,
    splitDiff: r2(T.current + T.noncurrent - T.close) };
  lead.tbSplitDiff = lead.tbSplit != null ? r2(lead.tbSplit - T.close) : null;

  /* ---- U7.1 movement ------------------------------------------------- */
  const castFails = live.filter(r => r.__castDiff != null && Math.abs(r.__castDiff) > tol);
  const splitFails = live.filter(r => r.__splitDiff != null && Math.abs(r.__splitDiff) > tol);
  const releasedInFull = live.filter(r => r.__releasedInFull);
  const reCreated = live.filter(r => r.__reCreated);
  const stale = provisions.filter(r => (r.bal_open || 0) > tol && Math.abs(r.__used) <= tol && Math.abs(r.__rel) <= tol);

  /* ---- U7.2 recognition ---------------------------------------------- */
  const recognition = {
    answered: live.filter(r => r.__recAnswered > 0).length,
    complete: live.filter(r => r.__recAnswered === 3).length,
    supported: provisions.filter(r => r.__recAll).length,
    failed: provisions.filter(r => Math.abs(r.bal_close || 0) > tol && r.__recAnyNo),
    shouldRecognise: contLiabs.filter(r => r.__recAll) };

  /* ---- U7.3 measurement ---------------------------------------------- */
  const measurement = {
    threshold: discThreshold, months: discMonths,
    entered: provisions.filter(r => r.__method).length,
    unsupported: provisions.filter(r => r.__methodUnsupported),
    needDiscount: live.filter(r => r.__needsDiscount),
    discounted: provisions.filter(r => r.__ratePct != null),
    pvDiffs: provisions.filter(r => r.__pvDiff != null && Math.abs(r.__pvDiff) > r.__pvTol),
    unwindFails: provisions.filter(r => r.__unwindDiff != null && Math.abs(r.__unwindDiff) > r.__unwindTol),
    unwindTotal: r2(provisions.reduce((s, r) => s + r.__unwind, 0)),
    expectedUnwindTotal: r2(provisions.reduce((s, r) => s + (r.__expectedUnwind || 0), 0)),
    reimbursements: live.filter(r => r.__reimb != null && Math.abs(r.__reimb) > tol),
    reimbExcess: live.filter(r => r.__reimbExcess != null && r.__reimbExcess > tol),
    reimbNotVC: live.filter(r => r.__reimb != null && Math.abs(r.__reimb) > tol && r.__reimbVC === 'N'),
    gainsIncluded: provisions.filter(r => r.__gains === 'Y'),
    risksNotConsidered: provisions.filter(r => r.__risks === 'N') };
  measurement.financeCost = num(cfg.financeCost);
  measurement.financeDiff = measurement.financeCost != null ? r2(measurement.unwindTotal - measurement.financeCost) : null;

  /* ---- U7.4 specific types ------------------------------------------- */
  const rowKeys = (prefix, n) => { const out = []; const k = Math.max(0, Math.min(40, Math.round(Number(n) || 0))); for (let i = 1; i <= k; i++) out.push(prefix + i); return out; };

  const onerous = rowKeys('oc', cfg.ocRows).map((k, i) => {
    const contract = txt(cfg, 'ocContract', k);
    const cost = inp(cfg, 'ocCost', k), benefit = inp(cfg, 'ocBenefit', k);
    const penalty = inp(cfg, 'ocPenalty', k), provided = inp(cfg, 'ocProvided', k);
    const net = (cost != null || benefit != null) ? r2((cost || 0) - (benefit || 0)) : null;
    const lower = net == null ? null : (penalty != null ? r2(Math.min(net, penalty)) : net);
    const required = lower == null ? null : r2(Math.max(0, lower));
    return { __key:k, i:i + 1, line:i + 1, contract, cost, benefit, penalty, provided, net, lower, required,
      shortfall: required == null ? null : r2(required - (provided || 0)),
      onerous: required != null && required > 0, comment: txt(cfg, 'ocComment', k) };
  });
  const onerousShort = onerous.filter(x => x.shortfall != null && x.shortfall > tol);

  const restructuring = rowKeys('rs', cfg.rsRows).map((k, i) => {
    const plan = txt(cfg, 'rsPlan', k);
    const approved = toDate(txt(cfg, 'rsApproved', k)), announced = toDate(txt(cfg, 'rsAnnounced', k)), started = toDate(txt(cfg, 'rsStart', k));
    const provided = inp(cfg, 'rsProvided', k);
    const retrain = inp(cfg, 'rsRetrain', k), relocate = inp(cfg, 'rsRelocate', k),
      marketing = inp(cfg, 'rsMarketing', k), futureLoss = inp(cfg, 'rsFutureLoss', k);
    const excluded = r2((retrain || 0) + (relocate || 0) + (marketing || 0) + (futureLoss || 0));
    const raised = !!ye && ((announced != null && announced <= ye) || (started != null && started <= ye));
    return { __key:k, i:i + 1, line:i + 1, plan, approved, announced, started, provided,
      retrain, relocate, marketing, futureLoss, excluded,
      direct: provided == null ? null : r2(provided - excluded),
      valid: raised, hasPlan: !!plan || provided != null,
      notRaised: provided != null && Math.abs(provided) > tol && !raised,
      comment: txt(cfg, 'rsComment', k) };
  });
  const rsNotRaised = restructuring.filter(x => x.notRaised);
  const rsExcluded = restructuring.filter(x => x.provided != null && x.excluded > tol);

  const warranty = rowKeys('wt', cfg.wtRows).map((k, i) => {
    const product = txt(cfg, 'wtProduct', k);
    const sales = inp(cfg, 'wtSales', k), rate = inp(cfg, 'wtRate', k), provided = inp(cfg, 'wtProvided', k);
    const expected = (sales != null && rate != null) ? r2(sales * rate / 100) : null;
    return { __key:k, i:i + 1, line:i + 1, product, sales, rate, expected, provided,
      diff: (expected != null && provided != null) ? r2(provided - expected) : null,
      period: txt(cfg, 'wtPeriod', k), comment: txt(cfg, 'wtComment', k) };
  });

  const decommissioning = rowKeys('dc', cfg.dcRows).map((k, i) => {
    const asset = txt(cfg, 'dcAsset', k);
    const estimate = inp(cfg, 'dcEstimate', k), rate = inp(cfg, 'dcRate', k), years = inp(cfg, 'dcYears', k);
    const value = pv(estimate, rate, years);
    const provided = inp(cfg, 'dcProvided', k);
    return { __key:k, i:i + 1, line:i + 1, asset, estimate, rate, years, pv:value, provided,
      diff: (value != null && provided != null) ? r2(provided - value) : null,
      capitalised: txt(cfg, 'dcCapitalised', k), comment: txt(cfg, 'dcComment', k) };
  });

  const futureOpLosses = provisions.filter(r => r.__futureOpLoss && Math.abs(r.bal_close || 0) > tol);

  /* ---- U7.5 legal and claims ------------------------------------------ */
  const legalItems = rowKeys('lc', cfg.legalRows).map((k, i) => {
    const claim = txt(cfg, 'lcClaim', k), counterparty = txt(cfg, 'lcCounterparty', k);
    const amount = inp(cfg, 'lcAmount', k), provided = inp(cfg, 'lcProvided', k);
    const sent = txt(cfg, 'lcSent', k), received = txt(cfg, 'lcReceived', k);
    const solicitor = txt(cfg, 'lcSolicitor', k);
    const solAssess = txt(cfg, 'lcSolAssess', k), mgmtAssess = txt(cfg, 'lcMgmtAssess', k), conc = txt(cfg, 'lcAuditConc', k);
    const used = !!(claim || counterparty || amount != null);
    return { __key:k, i:i + 1, line:i + 1, claim, counterparty, amount, solicitor, sent, received,
      solAssess, mgmtAssess, provided, conc, comment: txt(cfg, 'lcComment', k), used,
      confirmed: !!(sent && received),
      missingConf: used && !(sent && received),
      disagrees: used && !!conc && !!mgmtAssess && conc !== mgmtAssess };
  });
  const legal = { items: legalItems.filter(x => x.used), all: legalItems,
    claimed: r2(legalItems.reduce((s, x) => s + (x.used ? (x.amount || 0) : 0), 0)),
    provided: r2(legalItems.reduce((s, x) => s + (x.used ? (x.provided || 0) : 0), 0)),
    missingConf: legalItems.filter(x => x.missingConf),
    disagreements: legalItems.filter(x => x.disagrees),
    replies: legalItems.filter(x => x.confirmed).length };

  /* ---- U7.6 contingencies --------------------------------------------- */
  const contingent = { liabilities: contLiabs, assets: contAssets,
    clTotal: TC.cl, caTotal: TC.ca,
    recognisedAssets: contAssets.filter(r => Math.abs(r.bal_close || 0) > tol),
    disclosed: live.filter(r => !r.__isProvision && (r.__wp?.contingent?.disclosed === 'Y')).length };

  /* ---- U7.7 completeness ---------------------------------------------- */
  const compItems = COMPLETENESS.map(([k, text]) => ({ __key:k, key:k, text,
    done: txt(cfg, 'cmDone', k), from: txt(cfg, 'cmFrom', k), to: txt(cfg, 'cmTo', k),
    evidence: txt(cfg, 'cmEvidence', k), findings: txt(cfg, 'cmFindings', k) }));
  const completeness = { items: compItems,
    performed: compItems.filter(x => x.done === 'Y').length,
    notPerformed: compItems.filter(x => x.done === 'N'),
    outstanding: compItems.filter(x => !x.done).length };

  /* ---- U7.8 estimate evaluation (SSA 540 Revised) --------------------- */
  const retro = provisions.filter(r => r.__retroPY != null || r.__retroActual != null);
  const over = retro.filter(r => r.__retroDir === 'Over-provided').length;
  const under = retro.filter(r => r.__retroDir === 'Under-provided').length;
  const assumptions = rowKeys('ka', cfg.kaRows).map((k, i) => ({ __key:k, i:i + 1, line:i + 1,
    assumption: txt(cfg, 'kaAssumption', k), mgmtBasis: txt(cfg, 'kaMgmtBasis', k),
    supporting: txt(cfg, 'kaSupporting', k), contradictory: txt(cfg, 'kaContradictory', k),
    conclusion: txt(cfg, 'kaConclusion', k) }));
  const sensPct = Number(cfg.sensPct) || 0;
  const estimate = { retro, retroTol, over, under,
    exceptions: retro.filter(r => r.__retroDiff != null && Math.abs(r.__retroDiff) > retroTol),
    biasIndicator: retro.length >= 2 && (over === 0 || under === 0) && (over + under) >= 2,
    biasDirection: over > under ? 'Over-provided' : under > over ? 'Under-provided' : '',
    assumptions, used: assumptions.filter(a => a.assumption),
    contradictory: assumptions.filter(a => a.contradictory),
    notReasonable: assumptions.filter(a => a.conclusion && a.conclusion !== 'Reasonable'),
    methodChange: cfg.methodChange || '', methodChangeReason: cfg.methodChangeReason || '',
    sensPct, sensAmount: r2(T.close * sensPct / 100),
    sensAbovePm: Math.abs(T.close * sensPct / 100) > pm,
    processAnswered: EST_PROCESS.filter(i => (cfg.estProcess || {})[i.id]?.answer).length,
    processNo: EST_PROCESS.filter(i => (cfg.estProcess || {})[i.id]?.answer === 'N') };

  return { sign, tol, totals:T, contTotals:TC, provisions, contLiabs, contAssets, byClass, lead,
    castFails, splitFails, releasedInFull, reCreated, stale,
    recognition, measurement,
    types: { onerous, onerousShort, restructuring, rsNotRaised, rsExcluded, warranty, decommissioning, futureOpLosses },
    legal, contingent, completeness, estimate, pm, trivial };
}

/* ================================================================ TESTS */
const tests = [
  { id:'EX-PROV-01', label:'Provision movement does not cast to the closing balance', basis:'U7.1',
    fn:(r, cfg) => r.__castDiff != null && Math.abs(r.__castDiff) > (Number(cfg.castTol) || 0.01) &&
      { expected:r.__computedClose, actual:r.bal_close, difference:r.__castDiff, cell:r['__cell_bal_close'],
        detail:`Opening ${(r.bal_open || 0).toFixed(2)} + additional ${(r.additional || 0).toFixed(2)} − utilised ${r.__used.toFixed(2)} − released ${r.__rel.toFixed(2)} + unwind ${r.__unwind.toFixed(2)} = ${r.__computedClose.toFixed(2)}, not ${(r.bal_close || 0).toFixed(2)} (FRS 37 para 84(a)-(e))` } },

  { id:'EX-PROV-02', label:'Current and non-current analysis does not agree to the closing balance', basis:'U7',
    fn:(r, cfg) => r.__splitDiff != null && Math.abs(r.__splitDiff) > (Number(cfg.castTol) || 0.01) &&
      { expected:r.bal_close, actual:r.__splitTotal, difference:r.__splitDiff, cell:r['__cell_current'],
        detail:`Current ${(r.current || 0).toFixed(2)} + non-current ${(r.noncurrent || 0).toFixed(2)} = ${r.__splitTotal.toFixed(2)}, against a closing balance of ${(r.bal_close || 0).toFixed(2)}` } },

  { id:'EX-PROV-03', label:'Provision recognised although a recognition criterion is not met', basis:'U7.2',
    fn:(r, cfg) => r.__isProvision && Math.abs(r.bal_close || 0) > (Number(cfg.castTol) || 0.01) && r.__recAnyNo &&
      { actual:r.bal_close, difference:r.bal_close, cell:r['__cell_bal_close'],
        detail:`FRS 37 para 14 is not satisfied — ${r.__recFailed.join(' and ')} answered "No". The item should be disclosed as a contingent liability (paras 27-28) or not disclosed at all.` } },

  { id:'EX-PROV-04', label:'Contingent liability disclosed although all three recognition criteria are met', basis:'U7.2',
    fn:(r) => r.__isCL && r.__recAll &&
      { actual:r.undiscounted, difference:r.undiscounted, cell:r['__cell_undiscounted'],
        detail:'All three FRS 37 para 14 criteria are answered "Yes", so a provision was required. FRS 37 paras 27-28 permit disclosure only where the outflow is not probable or the amount cannot be measured reliably.' } },

  { id:'EX-PROV-05', label:'Measurement method not supported', basis:'U7.3',
    fn:(r) => r.__methodUnsupported &&
      { actual:r.bal_close, difference:r.bal_close, cell:r['__cell_bal_close'],
        detail: r.__methodMismatch
          ? `A ${r.__population.toLowerCase()} is measured using the ${r.__method.toLowerCase()} — FRS 37 paras 39-40 require expected value for a large population of items and the most likely outcome for a single obligation.`
          : 'No evidence has been recorded for the measurement method applied (FRS 37 paras 36-40).' } },

  { id:'EX-PROV-06', label:'Provision not discounted where the effect of the time value of money is material', basis:'U7.3',
    fn:(r, cfg, eng, d) => r.__needsDiscount &&
      { actual:r.bal_close, difference:r.bal_close, cell:r['__cell_bal_close'],
        detail:`Settlement is expected in about ${Math.round(r.__months)} months and the provision of ${(r.bal_close || 0).toFixed(2)} is at or above the discounting threshold of ${d.measurement.threshold.toFixed(2)}, yet no discount rate is applied (FRS 37 paras 45-47).` } },

  { id:'EX-PROV-07', label:'Discounted amount per audit differs from the provision recognised', basis:'U7.3',
    fn:(r) => r.__pvDiff != null && Math.abs(r.__pvDiff) > r.__pvTol &&
      { expected:r.__pvAudit, actual:r.bal_close, difference:r.__pvDiff, cell:r['__cell_bal_close'],
        detail:`Undiscounted estimate ${(r.__auditUndisc || 0).toFixed(2)} discounted at ${r.__auditRate}% over ${r.__years == null ? '?' : r.__years.toFixed(2)} years gives ${(r.__pvAudit || 0).toFixed(2)} (FRS 37 paras 45-47).` } },

  { id:'EX-PROV-08', label:'Unwinding of the discount does not agree to the recomputation', basis:'U7.3',
    fn:(r) => r.__unwindDiff != null && Math.abs(r.__unwindDiff) > r.__unwindTol &&
      { expected:r.__expectedUnwind, actual:r.__unwind, difference:r.__unwindDiff, cell:r['__cell_unwind'],
        detail:`Opening provision ${(r.bal_open || 0).toFixed(2)} at ${r.__ratePct}% gives an unwind of ${(r.__expectedUnwind || 0).toFixed(2)}, against ${r.__unwind.toFixed(2)} per the schedule. The unwind is a borrowing cost and is presented in finance costs (FRS 37 para 60).` } },

  { id:'EX-PROV-09', scope:'population', label:'Restructuring provision recognised before a valid expectation was raised', basis:'U7.4',
    fn:(recs, cfg, eng, d) => d.types.rsNotRaised.map(x => ({ key:x.plan || 'Restructuring ' + x.line, actual:x.provided, difference:x.provided,
      detail:'FRS 37 paras 72 and 75 require a detailed formal plan and a valid expectation raised in those affected — by starting to implement the plan or announcing its main features — before the reporting date. No announcement or implementation before the year end has been recorded.' })) },

  { id:'EX-PROV-10', scope:'population', label:'Restructuring provision includes costs excluded by FRS 37 para 80', basis:'U7.4',
    fn:(recs, cfg, eng, d) => d.types.rsExcluded.map(x => ({ key:x.plan || 'Restructuring ' + x.line, expected:x.direct, actual:x.provided, difference:x.excluded,
      detail:`The provision includes ${[x.retrain ? 'retraining' : '', x.relocate ? 'relocation' : '', x.marketing ? 'marketing' : '', x.futureLoss ? 'future operating losses' : ''].filter(Boolean).join(', ')} — costs of the continuing business, which FRS 37 paras 80-83 exclude from a restructuring provision.` })) },

  { id:'EX-PROV-11', label:'Contingent asset recognised', basis:'U7.6',
    fn:(r, cfg) => r.__isCA && Math.abs(r.bal_close || 0) > (Number(cfg.castTol) || 0.01) &&
      { actual:r.bal_close, difference:r.bal_close, cell:r['__cell_bal_close'],
        detail:'FRS 37 para 31 prohibits the recognition of a contingent asset. It is disclosed where an inflow is probable (para 34) and recognised only when realisation of the income is virtually certain, at which point it is no longer contingent (paras 33, 35).' } },

  { id:'EX-PROV-12', label:'Expected reimbursement exceeds the provision or is not virtually certain', basis:'U7.3',
    fn:(r, cfg) => {
      const t = Number(cfg.castTol) || 0.01;
      if (r.__reimbExcess != null && r.__reimbExcess > t)
        return { expected:r.__reimbCap, actual:r.__reimb, difference:r.__reimbExcess, cell:r['__cell_reimbursement'],
          detail:`FRS 37 para 53 caps the reimbursement asset at the amount of the provision (${(r.__reimbCap || 0).toFixed(2)}); ${(r.__reimb || 0).toFixed(2)} has been recognised. The reimbursement is presented as a separate asset and may be netted only in profit or loss (para 54).` };
      if (r.__reimb != null && Math.abs(r.__reimb) > t && r.__reimbVC === 'N')
        return { actual:r.__reimb, difference:r.__reimb, cell:r['__cell_reimbursement'],
          detail:'FRS 37 para 53 permits a reimbursement to be recognised only when it is virtually certain that it will be received. The auditor has concluded that it is not.' };
      return false;
    } },

  { id:'EX-PROV-13', scope:'population', label:'Onerous contract not provided for', basis:'U7.4',
    fn:(recs, cfg, eng, d) => d.types.onerousShort.map(x => ({ key:x.contract || 'Contract ' + x.line, expected:x.required, actual:x.provided || 0, difference:x.shortfall,
      detail:`FRS 37 paras 66-68 require the present obligation under an onerous contract to be provided at the lower of the cost of fulfilling it (${(x.net || 0).toFixed(2)}) and any compensation or penalty for failing to fulfil it${x.penalty != null ? ` (${x.penalty.toFixed(2)})` : ''}.` })) },

  { id:'EX-PROV-14', label:'Provision made for future operating losses', basis:'U7.4',
    fn:(r, cfg) => r.__isProvision && r.__futureOpLoss && Math.abs(r.bal_close || 0) > (Number(cfg.castTol) || 0.01) &&
      { actual:r.bal_close, difference:r.bal_close, cell:r['__cell_bal_close'],
        detail:'FRS 37 para 63 prohibits a provision for future operating losses: they do not arise from a past obligating event. An expectation of future operating losses is instead an indicator that the related assets may be impaired (FRS 36).' } },

  { id:'EX-PROV-15', scope:'population', label:'Legal confirmation not obtained for a claim', basis:'U7.5',
    fn:(recs, cfg, eng, d) => d.legal.missingConf.map(x => ({ key:x.claim || x.counterparty || 'Claim ' + x.line, actual:x.amount, difference:x.amount,
      detail:`No ${x.sent ? 'reply to the' : ''} legal confirmation has been recorded for this claim. SSA 501 paras 10-11 require direct communication with the entity's external legal counsel where litigation or claims have been identified.` })) },

  { id:'EX-PROV-16', scope:'population', label:'Auditor\'s conclusion on a claim differs from management\'s assessment', basis:'U7.5',
    fn:(recs, cfg, eng, d) => d.legal.disagreements.map(x => ({ key:x.claim || x.counterparty || 'Claim ' + x.line, expected:x.mgmtAssess, actual:x.conc, difference:x.amount,
      detail:`Management assess the outflow as ${x.mgmtAssess.toLowerCase()}; the auditor concludes it is ${x.conc.toLowerCase()}${x.solAssess ? ` and counsel assess it as ${x.solAssess.toLowerCase()}` : ''}. Consider whether a provision is required or the disclosure changed (FRS 37 paras 14, 27-28).` })) },

  { id:'EX-PROV-17', scope:'population', label:'Completeness procedure not performed', basis:'U7.7',
    fn:(recs, cfg, eng, d) => d.completeness.notPerformed.map(x => ({ key:x.key.toUpperCase(),
      detail:x.text + ' — recorded as not performed. Completeness is the direction of risk for provisions; document the reason or perform the procedure.' })) },

  { id:'EX-PROV-18', label:'Prior-year provision released in full in the year', basis:'U7.8', severity:'informational',
    fn:(r) => r.__releasedInFull &&
      { expected:0, actual:r.bal_open, difference:r.bal_open, cell:r['__cell_released'],
        detail:'The whole of the opening provision was released unused with no utilisation. SSA 540 (Revised) para 32 treats this as an indicator of possible management bias in the prior-year estimate; consider the effect on the current year estimates and on the audit approach.' } },

  { id:'EX-PROV-19', label:'Provision released and re-created in the same year', basis:'U7.1',
    fn:(r) => r.__reCreated &&
      { expected:r.bal_open, actual:r.additional, difference:r.additional, cell:r['__cell_additional'],
        detail:`The opening provision of ${(r.bal_open || 0).toFixed(2)} was released and ${(r.additional || 0).toFixed(2)} charged again in the same year. FRS 37 para 61 requires a provision to be used only for the expenditure it was originally recognised for; establish whether this is a genuine re-estimate or a reset of the balance.` } },

  { id:'EX-PROV-20', label:'Retrospective review: prior-year provision differs from the outcome', basis:'U7.8',
    fn:(r, cfg, eng, d) => r.__retroDiff != null && Math.abs(r.__retroDiff) > d.estimate.retroTol &&
      { expected:r.__retroPY, actual:r.__retroActual, difference:r.__retroDiff,
        detail:`The prior-year provision of ${(r.__retroPY || 0).toFixed(2)} settled at ${(r.__retroActual || 0).toFixed(2)} — ${r.__retroDir.toLowerCase()} by ${Math.abs(r.__retroDiff).toFixed(2)}. SSA 540 (Revised) paras 23(c) and 32 require the outcome to be considered for indicators of management bias.` } },

  { id:'EX-TIE-01', scope:'population', label:'Provisions schedule does not agree to the trial balance', basis:'U7',
    fn:(recs, cfg, eng, d) => d.lead.tbDiff != null && Math.abs(d.lead.tbDiff) > (Number(cfg.castTol) || 0.01) &&
      { key:'Provisions', expected:d.lead.tb, actual:d.totals.close, difference:d.lead.tbDiff,
        detail:'Total provisions per the schedule against the provisions captions in the trial balance' } }
];

/* ================================================================ PAGES */
const line = r => ({ __rec:r, description:r.description, cls:r.__class, status:r.__status,
  open:r.bal_open, additional:r.additional, utilised:r.__used, released:r.__rel, unwind:r.__unwind,
  computed:r.__computedClose, close:r.bal_close, castDiff:r.__castDiff,
  current:r.current, noncurrent:r.noncurrent, splitDiff:r.__splitDiff });

const statusChip = v => v === 'Provision' ? 'info' : v === 'Contingent asset' ? 'bad' : 'warn';

const pages = [
  { id:'source',  ref:'U7.0',  title:'Source data',      kind:'source' },
  { id:'cleaned', ref:'U7.0a', title:'Cleaned schedule', kind:'cleaned' },
  { id:'mapping', ref:'U7.0b', title:'Column mapping',   kind:'mapping' },

  /* ------------------------------------------------------------- U7 lead */
  { id:'lead', ref:'U7', title:'Lead schedule',
    objective:'To agree provisions per the schedule to the trial balance and the prior year audited figure, to analyse them by class and between current and non-current, and to separate provisions from the contingent liabilities and contingent assets disclosed.',
    procedures:['Cast the provisions and contingencies schedule and agreed the closing total to the provisions captions in the trial balance.',
                'Agreed the opening balances to the prior year audited closing balance and explained the movement in the year.',
                'Analysed provisions by class and between amounts falling due within and after twelve months, and agreed the analysis to the closing balance.',
                'Separated items recognised as provisions from those disclosed as contingent liabilities and contingent assets.'],
    render(st, ctx) {
      const d = ctx.d, T = d.totals, L = d.lead, m0 = ctx.money0, money = ctx.money, pct = ctx.pct;
      return [
        { type:'controls', items:[
          { key:'tbProvisions', label:'Provisions per trial balance', kind:'number' },
          { key:'tbCurrent', label:'Provisions — current, per trial balance', kind:'number' },
          { key:'tbNonCurrent', label:'Provisions — non-current, per trial balance', kind:'number' },
          { key:'pyProvisions', label:'Provisions per prior year audited financial statements', kind:'number', help:'Compared to the opening balance per the schedule and to the closing balance for the movement.' },
          { key:'castTol', label:'Tolerance', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Provisions on the schedule', value: T.count },
          { label:'Opening', value: m0(T.open) },
          { label:'Additional provisions', value: m0(T.additional) },
          { label:'Utilised', value: m0(T.utilised) },
          { label:'Released unused', value: m0(T.released) },
          { label:'Unwinding of discount', value: m0(T.unwind) },
          { label:'Closing per schedule', value: m0(T.close) },
          { label:'Closing recomputed', value: m0(T.computed) },
          { label:'Cast difference', value: money(T.castDiff), cls: Math.abs(T.castDiff) > 0.01 ? 'bad' : 'ok' },
          { label:'Per trial balance', value: L.tb == null ? '— enter —' : m0(L.tb) },
          { label:'Schedule − TB', value: L.tbDiff == null ? '' : money(L.tbDiff), cls: L.tbDiff == null ? '' : Math.abs(L.tbDiff) > 0.01 ? 'bad' : 'ok' },
          { label:'Opening − prior year closing', value: L.pyDiff == null ? '' : money(L.pyDiff), cls: L.pyDiff == null ? '' : Math.abs(L.pyDiff) > 0.01 ? 'bad' : 'ok' },
          { label:'Movement in the year', value: `${money(L.movement)}${L.movementPct == null ? '' : ' (' + pct(L.movementPct) + ')'}`, cls: Math.abs(L.movement) > ctx.pm ? 'warn' : '' },
          { label:'Contingent liabilities disclosed', value: `${d.contLiabs.length} · ${m0(d.contingent.clTotal)}` },
          { label:'Contingent assets disclosed', value: `${d.contAssets.length} · ${m0(d.contingent.caTotal)}`, cls: d.contingent.recognisedAssets.length ? 'bad' : '' } ] },
        { type:'table', title:'Provisions by class', columns:[
          { key:'class', label:'Class of provision', emphasis:true },
          { key:'count', label:'Items', type:'int' },
          { key:'open', label:'Opening', type:'num', sum:true },
          { key:'additional', label:'Additional', type:'num', sum:true },
          { key:'utilised', label:'Utilised', type:'num', sum:true },
          { key:'released', label:'Released unused', type:'num', sum:true },
          { key:'unwind', label:'Unwind of discount', type:'num', sum:true },
          { key:'close', label:'Closing', type:'num', sum:true, emphasis:true, formula:(row, C) => `${C(2)}${row}+${C(3)}${row}-${C(4)}${row}-${C(5)}${row}+${C(6)}${row}` },
          { key:'current', label:'Due within 12 months', type:'num', sum:true },
          { key:'noncurrent', label:'Due after 12 months', type:'num', sum:true },
          { key:'comment', label:'Nature and basis (auditor)', input:'text', wide:true } ],
          rows: d.byClass.map(g => ({ ...g, __key:g.class })),
          emptyText:'No provisions on the schedule.',
          footnote:'FRS 37 para 84 requires this movement for each class of provision, together with a brief description of the nature of the obligation and the expected timing (para 85).' },
        { type:'table', title:'Provisions, contingent liabilities and contingent assets', columns:[
          { key:'status', label:'Classification', type:'chip', chipClass: statusChip },
          { key:'count', label:'Items', type:'int' },
          { key:'amount', label:'Recognised', type:'num', sum:true },
          { key:'effect', label:'Estimate of financial effect (disclosed)', type:'num', sum:true },
          { key:'note', label:'Treatment' } ],
          rows: [
            { __key:'prov', status:'Provision', count:T.count, amount:T.close, effect:T.undiscounted || null, note:'Recognised — FRS 37 para 14' },
            { __key:'cl', status:'Contingent liability', count:d.contLiabs.length, amount:null, effect:d.contingent.clTotal, note:'Disclosed only — FRS 37 paras 27-28, 86' },
            { __key:'ca', status:'Contingent asset', count:d.contAssets.length, amount: r2(d.contAssets.reduce((s, r) => s + (r.bal_close || 0), 0)) || null, effect:d.contingent.caTotal, note:'Not recognised — FRS 37 paras 31-35, 89' }
          ] },
        { type:'table', title:'Current and non-current analysis', columns:[
          { key:'description', label:'Provision', emphasis:true },
          { key:'close', label:'Closing balance', type:'num', sum:true },
          { key:'current', label:'Due within 12 months', type:'num', sum:true },
          { key:'noncurrent', label:'Due after 12 months', type:'num', sum:true },
          { key:'splitDiff', label:'Analysis − closing', type:'num', sum:true, flag: v => v != null && Math.abs(v) > 0.01 },
          { key:'timing', label:'Expected timing per the schedule', type:'date' },
          { key:'comment', label:'Auditor comment', input:'text', wide:true } ],
          rows: d.provisions.map(r => ({ ...line(r), timing:r.timing, __cls: r.__splitDiff != null && Math.abs(r.__splitDiff) > 0.01 ? 'flag' : '' })),
          emptyText:'No provisions to analyse.',
          footnote:'A split that does not agree to the closing balance is raised as EX-PROV-02.' },
        { type:'note', tone: L.tbDiff != null && Math.abs(L.tbDiff) > 0.01 ? 'bad' : 'info',
          html: L.tb == null ? 'Enter the trial balance figure to complete the tie (EX-TIE-01 fires on a difference).'
            : Math.abs(L.tbDiff) > 0.01 ? `<b>The schedule does not agree to the trial balance</b> by ${money(L.tbDiff)}.`
            : 'The schedule agrees to the trial balance.' }
      ];
    },
    flag(st, d) { return (d.lead.tbDiff != null && Math.abs(d.lead.tbDiff) > 0.01) || (d.lead.pyDiff != null && Math.abs(d.lead.pyDiff) > 0.01) || d.splitFails.length > 0; } },

  /* -------------------------------------------------------- U7.1 movement */
  { id:'movement', ref:'U7.1', title:'Movement and casting',
    objective:'To verify that every provision rolls forward arithmetically from the opening balance through additional provisions, amounts utilised, unused amounts reversed and the unwinding of the discount to the closing balance, and to identify balances that were released in full or released and re-created.',
    procedures:['Recomputed the closing balance of every line as opening + additional − utilised − released + unwinding of discount and compared it to the closing balance per the schedule.',
                'Cast the schedule down each movement column and across each line.',
                'Identified prior-year provisions released in full, provisions released and re-created in the same year, and provisions neither utilised nor released.'],
    render(st, ctx) {
      const d = ctx.d, m0 = ctx.money0, money = ctx.money;
      return [
        { type:'controls', items:[
          { key:'movementSign', label:'Sign of the utilised and released columns', kind:'select',
            options:[['auto', `Detect from the data (currently: ${d.sign === 'signed' ? 'negative = reduction' : 'positive = reduction'})`],
                     ['signed', 'Negative amounts reduce the provision'], ['positive', 'Positive amounts reduce the provision']] },
          { key:'castTol', label:'Casting tolerance', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Lines that do not cast', value: d.castFails.length, cls: d.castFails.length ? 'bad' : 'ok' },
          { label:'Total cast difference', value: money(d.totals.castDiff), cls: Math.abs(d.totals.castDiff) > 0.01 ? 'bad' : 'ok' },
          { label:'Column cast — opening + movement', value: m0(d.totals.computed) },
          { label:'Column cast — closing per schedule', value: m0(d.totals.close) },
          { label:'Released in full', value: `${d.releasedInFull.length} · ${m0(d.releasedInFull.reduce((s, r) => s + (r.bal_open || 0), 0))}`, cls: d.releasedInFull.length ? 'warn' : 'ok' },
          { label:'Released and re-created', value: d.reCreated.length, cls: d.reCreated.length ? 'bad' : 'ok' },
          { label:'Neither utilised nor released', value: d.stale.length, cls: d.stale.length ? 'warn' : 'ok' } ] },
        { type:'table', title:'Roll-forward by provision', columns:[
          { key:'description', label:'Provision', emphasis:true },
          { key:'cls', label:'Class' },
          { key:'status', label:'Classification', type:'chip', chipClass: statusChip },
          { key:'open', label:'Opening', type:'num', sum:true },
          { key:'additional', label:'Additional', type:'num', sum:true },
          { key:'utilised', label:'Utilised', type:'num', sum:true },
          { key:'released', label:'Released unused', type:'num', sum:true },
          { key:'unwind', label:'Unwind of discount', type:'num', sum:true },
          { key:'computed', label:'Closing recomputed', type:'num', sum:true, formula:(row, C) => `${C(3)}${row}+${C(4)}${row}-${C(5)}${row}-${C(6)}${row}+${C(7)}${row}` },
          { key:'close', label:'Closing per schedule', type:'num', sum:true, emphasis:true },
          { key:'castDiff', label:'Cast difference', type:'num', sum:true, flag: v => v != null && Math.abs(v) > 0.01, formula:(row, C) => `${C(9)}${row}-${C(8)}${row}` },
          { key:'flags', label:'Flags', type:'chip', chipClass: v => /cast|re-created/i.test(v) ? 'bad' : 'warn' },
          { key:'comment', label:'Auditor comment', input:'text', wide:true } ],
          rows: ctx.recs.map(r => ({ ...line(r),
            flags: [r.__castDiff != null && Math.abs(r.__castDiff) > 0.01 ? 'Does not cast' : '',
                    r.__releasedInFull ? 'Released in full' : '',
                    r.__reCreated ? 'Released and re-created' : '',
                    (r.bal_open || 0) > 0.01 && Math.abs(r.__used) <= 0.01 && Math.abs(r.__rel) <= 0.01 ? 'No movement' : ''].filter(Boolean).join(', ') || null,
            __cls: (r.__castDiff != null && Math.abs(r.__castDiff) > 0.01) || r.__reCreated ? 'flag' : '' })),
          emptyText:'Nothing on the schedule.' },
        { type:'table', title:'Provisions released in full or released and re-created', columns:[
          { key:'description', label:'Provision', emphasis:true },
          { key:'open', label:'Opening', type:'num', sum:true },
          { key:'additional', label:'Re-charged in the year', type:'num', sum:true },
          { key:'released', label:'Released unused', type:'num', sum:true },
          { key:'close', label:'Closing', type:'num', sum:true },
          { key:'why', label:'Reason for the release, per management', input:'text', wide:true },
          { key:'evidence', label:'Evidence obtained', input:'text', wide:true },
          { key:'bias', label:'Indicator of bias (Y/N)', input:'select', options:yn } ],
          rows: [...new Set([...d.releasedInFull, ...d.reCreated])].map(line),
          emptyText:'No provision was released in full or released and re-created in the year.',
          footnote:'FRS 37 para 61 permits a provision to be used only for the expenditure for which it was originally recognised. A release in full is an indicator of possible bias under SSA 540 (Revised) para 32.' }
      ];
    },
    flag(st, d) { return d.castFails.length > 0 || d.reCreated.length > 0 || d.releasedInFull.length > 0; } },

  /* ----------------------------------------------------- U7.2 recognition */
  { id:'recognition', ref:'U7.2', title:'Recognition test',
    objective:'To determine, for every item on the schedule, whether the three FRS 37 para 14 recognition criteria are met — a present obligation arising from a past event, a probable outflow of resources embodying economic benefits, and a reliable estimate of the amount — and therefore whether the item belongs in the balance sheet, in the notes, or nowhere.',
    procedures:['For each item, determined whether a present obligation, legal or constructive, exists at the reporting date as a result of a past event, and recorded the obligating event and the evidence.',
                'Assessed whether an outflow of resources embodying economic benefits is probable — more likely than not (FRS 37 para 23).',
                'Assessed whether a reliable estimate of the obligation can be made (FRS 37 paras 25-26).',
                'Compared the conclusion reached with the treatment adopted by the client and raised the difference where the two do not agree.'],
    render(st, ctx) {
      const d = ctx.d, R = d.recognition;
      return [
        { type:'note', tone:'info', html:'<b>FRS 37 para 14.</b> A provision is recognised when, and only when, (a) an entity has a present obligation (legal or constructive) as a result of a past event; (b) it is probable that an outflow of resources embodying economic benefits will be required to settle the obligation; and (c) a reliable estimate can be made of the amount. <b>All three</b> must be answered "Yes". Where they are not, the item is a contingent liability disclosed under paras 27-28, or — where the possibility of an outflow is remote — nothing at all (para 28).' },
        { type:'stats', items:[
          { label:'Items assessed', value: `${R.complete} of ${ctx.recs.length} complete` },
          { label:'Provisions supported by all three criteria', value: `${R.supported} of ${d.provisions.length}`, cls: R.supported === d.provisions.length && d.provisions.length ? 'ok' : 'warn' },
          { label:'Provisions failing a criterion', value: R.failed.length, cls: R.failed.length ? 'bad' : 'ok' },
          { label:'Contingent liabilities meeting all three', value: R.shouldRecognise.length, cls: R.shouldRecognise.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Recognition test — FRS 37 para 14', columns:[
          { key:'description', label:'Provision or contingency', emphasis:true },
          { key:'cls', label:'Class' },
          { key:'status', label:'Client treatment', type:'chip', chipClass: statusChip },
          { key:'close', label:'Amount recognised', type:'num', sum:true },
          { key:'event', label:'Obligating event (past event)', input:'text', wide:true },
          { key:'legalOrConstructive', label:'Legal or constructive', input:'select', options:['Legal', 'Constructive'] },
          { key:'obligation', label:'(a) Present obligation from a past event', input:'select', options:yn },
          { key:'probable', label:'(b) Probable outflow of resources', input:'select', options:yn },
          { key:'reliable', label:'(c) Reliable estimate can be made', input:'select', options:yn },
          { key:'conclusion', label:'Recognise / disclose / neither', type:'chip', chipClass: v => v === 'Recognise' ? 'ok' : v === 'Disclose' ? 'warn' : v === 'Neither' ? 'grey' : 'grey' },
          { key:'agrees', label:'Agrees to client treatment', type:'chip', chipClass: v => v === 'Yes' ? 'ok' : v === 'No' ? 'bad' : 'grey' },
          { key:'evidence', label:'Evidence obtained', input:'text', wide:true } ],
          rows: ctx.recs.map(r => {
            const conclusion = r.__recAnswered < 3 ? null : r.__recAll ? 'Recognise'
              : (r.__recObligation === 'N' && r.__recProbable === 'N') ? 'Neither' : 'Disclose';
            const agrees = conclusion == null ? null
              : (conclusion === 'Recognise') === r.__isProvision ? 'Yes' : 'No';
            return { ...line(r), conclusion, agrees, __cls: agrees === 'No' ? 'flag' : '' };
          }),
          emptyText:'Nothing on the schedule.',
          footnote:'A provision recognised with a criterion answered "No" is raised as EX-PROV-03. An item disclosed as contingent with all three answered "Yes" is raised as EX-PROV-04 — recognition was required (paras 27-28).' }
      ];
    },
    flag(st, d) { return d.recognition.failed.length > 0 || d.recognition.shouldRecognise.length > 0; } },

  /* ----------------------------------------------------- U7.3 measurement */
  { id:'measurement', ref:'U7.3', title:'Measurement',
    objective:'To verify that each provision is the best estimate of the expenditure required to settle the present obligation at the reporting date, measured by the method the standard requires, discounted where the effect of the time value of money is material, and that reimbursements are recognised only when virtually certain and are capped at the amount of the provision.',
    procedures:['For each provision, recorded whether the obligation is a large population of items or a single obligation, and the measurement method applied — expected value or most likely outcome (FRS 37 paras 39-40).',
                'Obtained and recorded the evidence supporting the best estimate and assessed whether the risks and uncertainties surrounding the obligation were taken into account (FRS 37 para 42).',
                'Established whether gains from the expected disposal of assets have been taken into account in measuring a provision, which FRS 37 para 51 prohibits.',
                'Where settlement is beyond twelve months, recomputed the discounted amount from the pre-tax rate and expected settlement date and compared it to the provision recognised (FRS 37 paras 45-47).',
                'Recomputed the unwinding of the discount on the opening provision and agreed it to the finance cost in profit or loss (FRS 37 para 60).',
                'Confirmed that expected reimbursements are virtually certain, do not exceed the amount of the provision and are presented as a separate asset (FRS 37 paras 53-58).'],
    render(st, ctx) {
      const d = ctx.d, M = d.measurement, m0 = ctx.money0, money = ctx.money;
      return [
        { type:'controls', items:[
          { key:'discThreshold', label:'Discounting threshold — provisions at or above are expected to be discounted', kind:'number', help:`Blank = performance materiality (${m0(ctx.pm)}). Currently ${m0(M.threshold)}.` },
          { key:'discMonths', label:'Months beyond which discounting is expected', kind:'number' },
          { key:'measTolPct', label:'Tolerance on the recomputed discounted amount (%)', kind:'number' },
          { key:'unwindTolPct', label:'Tolerance on the recomputed unwind (%)', kind:'number' },
          { key:'financeCost', label:'Unwinding of discount per the finance cost note', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Measurement method recorded', value: `${M.entered} of ${d.provisions.length}` },
          { label:'Method not supported', value: M.unsupported.length, cls: M.unsupported.length ? 'bad' : 'ok' },
          { label:'Provisions discounted', value: M.discounted.length },
          { label:'Discounting expected but not applied', value: M.needDiscount.length, cls: M.needDiscount.length ? 'bad' : 'ok' },
          { label:'Recomputed present value differs', value: M.pvDiffs.length, cls: M.pvDiffs.length ? 'bad' : 'ok' },
          { label:'Unwind per schedule', value: m0(M.unwindTotal) },
          { label:'Unwind recomputed', value: m0(M.expectedUnwindTotal), cls: M.unwindFails.length ? 'bad' : 'ok' },
          { label:'Unwind vs finance cost', value: M.financeDiff == null ? '— enter —' : money(M.financeDiff), cls: M.financeDiff == null ? '' : Math.abs(M.financeDiff) > 0.01 ? 'bad' : 'ok' },
          { label:'Reimbursements recognised', value: `${M.reimbursements.length} · ${m0(M.reimbursements.reduce((s, r) => s + (r.__reimb || 0), 0))}`, cls: M.reimbExcess.length || M.reimbNotVC.length ? 'bad' : '' } ] },
        { type:'table', title:'Best estimate — method and evidence (FRS 37 paras 36-42)', columns:[
          { key:'description', label:'Provision', emphasis:true },
          { key:'close', label:'Provision recognised', type:'num', sum:true },
          { key:'basis', label:'Basis per the client' },
          { key:'population', label:'Nature of the obligation', input:'select', options:['Large population', 'Single obligation'] },
          { key:'method', label:'Measurement method applied', input:'select', options:['Expected value', 'Most likely outcome', 'Best estimate — other'] },
          { key:'evidence', label:'Evidence supporting the best estimate', input:'text', wide:true },
          { key:'risks', label:'Risks and uncertainties considered (para 42)', input:'select', options:yn },
          { key:'gains', label:'Gains on expected disposal included (para 51)', input:'select', options:yn },
          { key:'auditEstimate', label:'Best estimate per audit', input:'number' },
          { key:'methodFlag', label:'Method', type:'chip', chipClass: v => v === 'Not supported' ? 'bad' : 'ok' },
          { key:'comment', label:'Conclusion', input:'text', wide:true } ],
          rows: d.provisions.map(r => ({ ...line(r), basis:r.basis,
            methodFlag: r.__method ? (r.__methodUnsupported ? 'Not supported' : 'Supported') : null,
            __cls: r.__methodUnsupported || r.__gains === 'Y' ? 'flag' : '' })),
          emptyText:'No provisions to measure.',
          footnote:'FRS 37 para 39 measures a large population of items at expected value; para 40 measures a single obligation at the most likely outcome. Para 51 prohibits taking gains from the expected disposal of assets into account.' },
        { type:'table', title:'Discounting and the unwinding of the discount (FRS 37 paras 45-47, 60)', columns:[
          { key:'description', label:'Provision', emphasis:true },
          { key:'close', label:'Provision recognised', type:'num', sum:true },
          { key:'timing', label:'Expected settlement per the schedule', type:'date' },
          { key:'months', label:'Months to settlement', type:'num', dp:0 },
          { key:'clientRate', label:'Discount rate per the client (%)', type:'num', dp:2 },
          { key:'undisc', label:'Undiscounted estimate per audit', input:'number' },
          { key:'rate', label:'Pre-tax discount rate per audit (%)', input:'number' },
          { key:'settle', label:'Expected settlement date per audit', input:'date' },
          { key:'pvAudit', label:'Discounted amount per audit', type:'num' },
          { key:'pvDiff', label:'Provision − discounted per audit', type:'num', flag: (v, row) => row.__pvFlag },
          { key:'unwind', label:'Unwind per schedule', type:'num', sum:true },
          { key:'expectedUnwind', label:'Unwind recomputed', type:'num', sum:true },
          { key:'unwindDiff', label:'Unwind difference', type:'num', flag: (v, row) => row.__unwindFlag },
          { key:'comment', label:'Auditor comment', input:'text', wide:true } ],
          rows: d.provisions.map(r => ({ ...line(r), timing:r.timing, months:r.__months, clientRate:r.__ratePct,
            pvAudit:r.__pvAudit, pvDiff:r.__pvDiff, expectedUnwind:r.__expectedUnwind, unwindDiff:r.__unwindDiff,
            __pvFlag: r.__pvDiff != null && Math.abs(r.__pvDiff) > r.__pvTol,
            __unwindFlag: r.__unwindDiff != null && Math.abs(r.__unwindDiff) > r.__unwindTol,
            __cls: r.__needsDiscount || (r.__unwindDiff != null && Math.abs(r.__unwindDiff) > r.__unwindTol) ? 'flag' : '' })),
          emptyText:'No provisions to discount.',
          footnote:'Where the effect of the time value of money is material the provision is the present value of the expenditure expected to settle the obligation, discounted at a pre-tax rate reflecting current market assessments and the risks specific to the liability (para 47). The unwinding of the discount is a borrowing cost (para 60).' },
        { type:'table', title:'Reimbursements (FRS 37 paras 53-58)', columns:[
          { key:'description', label:'Provision', emphasis:true },
          { key:'close', label:'Provision recognised', type:'num', sum:true },
          { key:'reimb', label:'Reimbursement recognised', type:'num', sum:true },
          { key:'excess', label:'Reimbursement above the provision', type:'num', flag: v => v != null && v > 0.01 },
          { key:'source', label:'Source of the reimbursement (insurer, indemnity, counterparty)', input:'text', wide:true },
          { key:'reimbVC', label:'Virtually certain (Y/N)', input:'select', options:yn },
          { key:'reimbSep', label:'Presented as a separate asset (Y/N)', input:'select', options:yn },
          { key:'evidence', label:'Evidence obtained', input:'text', wide:true } ],
          rows: ctx.recs.filter(r => r.__reimb != null && Math.abs(r.__reimb) > 0.01).map(r => ({ ...line(r), reimb:r.__reimb, excess:r.__reimbExcess,
            __cls: (r.__reimbExcess != null && r.__reimbExcess > 0.01) || r.__reimbVC === 'N' ? 'flag' : '' })),
          emptyText:'No reimbursements are recognised on the schedule.',
          footnote:'A reimbursement is recognised only when it is virtually certain that it will be received, is treated as a separate asset and may not exceed the amount of the provision (para 53). In profit or loss the expense may be presented net of the reimbursement (para 54).' }
      ];
    },
    flag(st, d) { const M = d.measurement; return M.needDiscount.length > 0 || M.unwindFails.length > 0 || M.pvDiffs.length > 0 || M.unsupported.length > 0 || M.reimbExcess.length > 0; } },

  /* ----------------------------------------------------------- U7.4 types */
  { id:'types', ref:'U7.4', title:'Specific provision types',
    objective:'To apply the specific requirements FRS 37 sets for onerous contracts, restructurings, warranties, decommissioning and restoration obligations, and to confirm that no provision has been made for future operating losses.',
    procedures:['For each contract identified as potentially onerous, compared the unavoidable cost of meeting the obligation with the economic benefits expected to be received and provided the lower of the cost of fulfilling the contract and any penalty for failing to fulfil it (FRS 37 paras 66-69).',
                'For each restructuring, established that a detailed formal plan existed and a valid expectation had been raised in those affected before the reporting date, and that the provision includes only direct expenditure necessarily entailed by the restructuring (FRS 37 paras 70-83).',
                'Recomputed the warranty provision from sales under warranty and the claims rate derived from history (FRS 37 paras 24, 39).',
                'Recomputed decommissioning and restoration provisions as the present value of the estimated cost and confirmed the corresponding amount was capitalised in the cost of the related asset.',
                'Confirmed that no provision has been made for future operating losses (FRS 37 paras 63-65).'],
    render(st, ctx) {
      const d = ctx.d, Ty = d.types, m0 = ctx.money0;
      const rows = (list) => list.map(x => ({ ...x }));
      return [
        { type:'controls', items:[
          { key:'ocRows', label:'Lines for onerous contracts', kind:'number' },
          { key:'rsRows', label:'Lines for restructurings', kind:'number' },
          { key:'wtRows', label:'Lines for warranty computations', kind:'number' },
          { key:'dcRows', label:'Lines for decommissioning and restoration', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Onerous contracts under-provided', value: Ty.onerousShort.length, cls: Ty.onerousShort.length ? 'bad' : 'ok' },
          { label:'Restructurings without a valid expectation raised', value: Ty.rsNotRaised.length, cls: Ty.rsNotRaised.length ? 'bad' : 'ok' },
          { label:'Restructurings including excluded costs', value: Ty.rsExcluded.length, cls: Ty.rsExcluded.length ? 'bad' : 'ok' },
          { label:'Future operating losses provided', value: `${Ty.futureOpLosses.length} · ${m0(Ty.futureOpLosses.reduce((s, r) => s + (r.bal_close || 0), 0))}`, cls: Ty.futureOpLosses.length ? 'bad' : 'ok' } ] },

        { type:'heading', text:'Onerous contracts — FRS 37 paras 66-69' },
        { type:'note', tone:'info', html:'The unavoidable costs of meeting the obligations under a contract are the <b>lower</b> of the cost of fulfilling it and any compensation or penalties arising from failure to fulfil it (para 68). Before a separate provision is established, any impairment loss on assets dedicated to the contract is recognised (para 69).' },
        { type:'table', columns:[
          { key:'line', label:'#', type:'int' },
          { key:'ocContract', label:'Contract and counterparty', input:'text', wide:true },
          { key:'ocCost', label:'Unavoidable cost of fulfilling the contract', input:'number' },
          { key:'ocBenefit', label:'Economic benefits expected to be received', input:'number' },
          { key:'net', label:'Net cost of fulfilling', type:'num' },
          { key:'ocPenalty', label:'Compensation or penalty to exit', input:'number' },
          { key:'required', label:'Provision required — lower of the two', type:'num', sum:true },
          { key:'ocProvided', label:'Provision recognised', input:'number' },
          { key:'shortfall', label:'Under-provided', type:'num', sum:true, flag: v => v != null && v > 0.01 },
          { key:'ocComment', label:'Evidence and conclusion', input:'text', wide:true } ],
          rows: rows(Ty.onerous), footnote:'An under-provided onerous contract is raised as EX-PROV-13.' },

        { type:'heading', text:'Restructuring — FRS 37 paras 70-83' },
        { type:'note', tone:'info', html:'A constructive obligation to restructure arises only when the entity has a <b>detailed formal plan</b> identifying at least the business concerned, the principal locations, the location, function and approximate number of employees to be compensated, the expenditure to be undertaken and when the plan will be implemented (para 72(a)); <b>and</b> has raised a valid expectation in those affected by starting to implement the plan or announcing its main features (para 72(b)). A management or board decision alone does not give rise to a constructive obligation (para 75). The provision includes only direct expenditure necessarily entailed by the restructuring and not associated with the ongoing activities — <b>excluding</b> retraining or relocating continuing staff, marketing, and investment in new systems and distribution networks (para 80), and excluding identifiable future operating losses (para 82).' },
        { type:'table', columns:[
          { key:'line', label:'#', type:'int' },
          { key:'rsPlan', label:'Restructuring and business affected', input:'text', wide:true },
          { key:'rsApproved', label:'Board approval date', input:'date' },
          { key:'rsAnnounced', label:'Date announced to those affected', input:'date' },
          { key:'rsStart', label:'Date implementation began', input:'date' },
          { key:'validChip', label:'Valid expectation raised before year end', type:'chip', chipClass: v => v === 'Yes' ? 'ok' : 'bad' },
          { key:'rsProvided', label:'Provision recognised', input:'number', },
          { key:'rsRetrain', label:'Retraining continuing staff (excluded)', input:'number' },
          { key:'rsRelocate', label:'Relocating continuing staff (excluded)', input:'number' },
          { key:'rsMarketing', label:'Marketing and promotion (excluded)', input:'number' },
          { key:'rsFutureLoss', label:'Future operating losses (excluded)', input:'number' },
          { key:'excluded', label:'Total excluded costs', type:'num', sum:true, flag: v => v != null && v > 0.01 },
          { key:'direct', label:'Direct expenditure — provision supportable', type:'num', sum:true },
          { key:'rsComment', label:'Evidence and conclusion', input:'text', wide:true } ],
          rows: Ty.restructuring.map(x => ({ ...x, validChip: x.hasPlan ? (x.valid ? 'Yes' : 'No') : null, __cls: x.notRaised || x.excluded > 0.01 ? 'flag' : '' })),
          footnote:'A provision recognised with no valid expectation raised before the year end is EX-PROV-09; excluded costs inside the provision are EX-PROV-10.' },

        { type:'heading', text:'Warranties — FRS 37 paras 24, 39 and Appendix C example 1' },
        { type:'table', columns:[
          { key:'line', label:'#', type:'int' },
          { key:'wtProduct', label:'Product or class of sales under warranty', input:'text', wide:true },
          { key:'wtPeriod', label:'Warranty period', input:'text' },
          { key:'wtSales', label:'Sales under warranty at the reporting date', input:'number' },
          { key:'wtRate', label:'Claims rate from history (%)', input:'number' },
          { key:'expected', label:'Expected value per audit', type:'num', sum:true },
          { key:'wtProvided', label:'Provision recognised', input:'number', },
          { key:'diff', label:'Provision − expected value', type:'num', sum:true, flag: v => v != null && Math.abs(v) > 0.01 },
          { key:'wtComment', label:'Source of the claims rate and conclusion', input:'text', wide:true } ],
          rows: rows(Ty.warranty), footnote:'A warranty obligation is a large population of items, so the best estimate is the expected value — the obligation weighted by the probability of each outcome (para 39).' },

        { type:'heading', text:'Decommissioning and restoration' },
        { type:'table', columns:[
          { key:'line', label:'#', type:'int' },
          { key:'dcAsset', label:'Asset or site', input:'text', wide:true },
          { key:'dcEstimate', label:'Estimated cost, undiscounted', input:'number' },
          { key:'dcRate', label:'Pre-tax discount rate (%)', input:'number' },
          { key:'dcYears', label:'Years to settlement', input:'number' },
          { key:'pv', label:'Present value per audit', type:'num', sum:true },
          { key:'dcProvided', label:'Provision recognised', input:'number' },
          { key:'diff', label:'Provision − present value', type:'num', sum:true, flag: v => v != null && Math.abs(v) > 0.01 },
          { key:'dcCapitalised', label:'Capitalised in the cost of the asset (Y/N)', input:'select', options:yn },
          { key:'dcComment', label:'Source of the estimate and conclusion', input:'text', wide:true } ],
          rows: rows(Ty.decommissioning),
          footnote:'The obligation is recognised at present value and the corresponding amount is capitalised in the cost of the related asset (FRS 16 para 16(c)); the subsequent unwind is a finance cost (FRS 37 para 60).' },

        { type:'heading', text:'Future operating losses — FRS 37 paras 63-65' },
        { type:'note', tone: Ty.futureOpLosses.length ? 'bad' : 'info',
          html:'Provisions are <b>not</b> recognised for future operating losses: they do not meet the definition of a liability and do not arise from a past obligating event (para 63). An expectation of future operating losses is an indication that assets of the operation may be impaired, and the entity tests them under FRS 36 (para 65).' },
        { type:'table', columns:[
          { key:'description', label:'Provision', emphasis:true },
          { key:'cls', label:'Class' },
          { key:'close', label:'Amount recognised', type:'num', sum:true },
          { key:'basis', label:'Basis per the client' },
          { key:'folYN', label:'Relates to future operating losses (Y/N)', input:'select', options:yn },
          { key:'folChip', label:'Assessment', type:'chip', chipClass: v => v === 'Not permitted' ? 'bad' : 'ok' },
          { key:'impairment', label:'FRS 36 impairment test performed instead (Y/N)', input:'select', options:yn },
          { key:'folComment', label:'Conclusion', input:'text', wide:true } ],
          rows: d.provisions.map(r => ({ ...line(r), basis:r.basis,
            folChip: r.__futureOpLoss ? 'Not permitted' : (r.__folAnswer === 'N' ? 'Permitted' : null),
            __cls: r.__futureOpLoss ? 'flag' : '' })),
          emptyText:'No provisions on the schedule.',
          footnote:'A provision for future operating losses is raised as EX-PROV-14.' }
      ];
    },
    flag(st, d) { const T = d.types; return T.onerousShort.length > 0 || T.rsNotRaised.length > 0 || T.rsExcluded.length > 0 || T.futureOpLosses.length > 0; } },

  /* ----------------------------------------------------------- U7.5 legal */
  { id:'legal', ref:'U7.5', title:'Legal and claims',
    objective:'To identify litigation and claims involving the entity and to obtain audit evidence about them by direct communication with the entity\'s external legal counsel, comparing counsel\'s assessment, management\'s assessment and the amount provided.',
    procedures:['Enquired of management and of in-house counsel about litigation and claims, and reviewed the legal expense accounts and correspondence (SSA 501 para 9).',
                'Sent a letter of enquiry to each external legal counsel identified, requesting direct communication, and recorded the date sent and the date the reply was received (SSA 501 paras 10-11).',
                'Recorded counsel\'s assessment of the likely outcome and the estimated financial effect, compared it with management\'s assessment and with the amount provided, and formed an independent conclusion.',
                'Where no reply was received, performed alternative procedures and considered the effect on the auditor\'s report (SSA 501 para 11).'],
    render(st, ctx) {
      const d = ctx.d, L = d.legal, m0 = ctx.money0;
      return [
        { type:'controls', items:[{ key:'legalRows', label:'Lines available for claims', kind:'number' }] },
        { type:'stats', items:[
          { label:'Claims recorded', value: L.items.length },
          { label:'Total claimed', value: m0(L.claimed) },
          { label:'Total provided', value: m0(L.provided) },
          { label:'Confirmations replied', value: `${L.replies} of ${L.items.length}`, cls: L.items.length && L.replies === L.items.length ? 'ok' : 'warn' },
          { label:'No legal confirmation', value: L.missingConf.length, cls: L.missingConf.length ? 'bad' : 'ok' },
          { label:'Auditor differs from management', value: L.disagreements.length, cls: L.disagreements.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Legal confirmation control sheet (SSA 501 / SSA 505)', columns:[
          { key:'line', label:'#', type:'int' },
          { key:'lcClaim', label:'Claim or matter', input:'text', wide:true },
          { key:'lcCounterparty', label:'Counterparty', input:'text', wide:true },
          { key:'lcAmount', label:'Amount claimed', input:'number' },
          { key:'lcSolicitor', label:'External legal counsel', input:'text', wide:true },
          { key:'lcSent', label:'Letter sent', input:'date' },
          { key:'lcReceived', label:'Reply received', input:'date' },
          { key:'confChip', label:'Confirmation', type:'chip', chipClass: v => v === 'Received' ? 'ok' : 'bad' },
          { key:'lcSolAssess', label:'Counsel\'s assessment', input:'select', options:ASSESS },
          { key:'lcMgmtAssess', label:'Management\'s assessment', input:'select', options:ASSESS },
          { key:'lcProvided', label:'Amount provided', input:'number' },
          { key:'lcAuditConc', label:'Auditor\'s conclusion', input:'select', options:ASSESS },
          { key:'agreeChip', label:'Agrees with management', type:'chip', chipClass: v => v === 'Yes' ? 'ok' : 'bad' },
          { key:'lcComment', label:'Alternative procedures and conclusion', input:'text', wide:true } ],
          rows: L.all.map(x => ({ ...x, confChip: x.used ? (x.confirmed ? 'Received' : 'Outstanding') : null,
            agreeChip: x.used && x.conc && x.mgmtAssess ? (x.disagrees ? 'No' : 'Yes') : null,
            __cls: x.missingConf || x.disagrees ? 'flag' : '' })),
          footnote:'A claim with no legal confirmation is raised as EX-PROV-15; a conclusion differing from management\'s is EX-PROV-16. A matter assessed as probable with a reliable estimate is provided; possible is disclosed as a contingent liability; remote is neither provided nor disclosed (FRS 37 paras 14, 27-28).' }
      ];
    },
    flag(st, d) { return d.legal.missingConf.length > 0 || d.legal.disagreements.length > 0; } },

  /* ------------------------------------------------------ U7.6 contingent */
  { id:'contingent', ref:'U7.6', title:'Contingencies',
    objective:'To verify that contingent liabilities are disclosed with the information FRS 37 para 86 requires, that no contingent asset has been recognised, and that contingent assets are disclosed only where an inflow of economic benefits is probable.',
    procedures:['For each contingent liability, recorded the nature of the obligation, an estimate of its financial effect, the uncertainties about the amount or timing of any outflow and the possibility of any reimbursement (FRS 37 para 86).',
                'Confirmed that an item is disclosed rather than provided only because an outflow is not probable or the amount cannot be measured with sufficient reliability (paras 27-28), and that nothing is disclosed where the possibility of an outflow is remote.',
                'Confirmed that no contingent asset has been recognised and that contingent assets are disclosed only where an inflow is probable (paras 31-35, 89).'],
    render(st, ctx) {
      const d = ctx.d, C = d.contingent, m0 = ctx.money0;
      return [
        { type:'note', tone: C.recognisedAssets.length ? 'bad' : 'info',
          html:'A <b>contingent liability</b> is a possible obligation whose existence will be confirmed only by uncertain future events, or a present obligation not recognised because an outflow is not probable or cannot be measured reliably (para 10). It is disclosed unless the possibility of an outflow is remote (para 28). A <b>contingent asset</b> is never recognised (para 31); it is disclosed where an inflow is probable (para 34) and recognised only when realisation is virtually certain, at which point it is no longer a contingent asset (para 33).' },
        { type:'stats', items:[
          { label:'Contingent liabilities', value: `${C.liabilities.length} · ${m0(C.clTotal)}` },
          { label:'Contingent assets', value: `${C.assets.length} · ${m0(C.caTotal)}` },
          { label:'Contingent assets recognised', value: C.recognisedAssets.length, cls: C.recognisedAssets.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Contingent liabilities — disclosure schedule (FRS 37 para 86)', columns:[
          { key:'description', label:'Nature of the contingency', emphasis:true },
          { key:'effect', label:'Estimate of financial effect per the client', type:'num', sum:true },
          { key:'nature', label:'Nature of the obligation and how it arose', input:'text', wide:true },
          { key:'auditEffect', label:'Estimate of financial effect per audit', input:'number' },
          { key:'uncertainties', label:'Uncertainties about amount or timing', input:'text', wide:true },
          { key:'reimbursement', label:'Possibility of reimbursement', input:'text', wide:true },
          { key:'likelihood', label:'Likelihood of outflow', input:'select', options:['Probable', 'Possible', 'Remote'] },
          { key:'disclosed', label:'Disclosed in the financial statements (Y/N)', input:'select', options:ynna },
          { key:'evidence', label:'Evidence obtained', input:'text', wide:true } ],
          rows: C.liabilities.map(r => ({ ...line(r), effect:r.undiscounted })),
          emptyText:'No contingent liabilities are recorded on the schedule. Record any identified through enquiry, minutes and legal confirmations on U7.5 and U7.7.',
          footnote:'Where disclosure is impracticable, that fact is stated (para 91); in the extremely rare case where disclosure would seriously prejudice the entity\'s position, the general nature of the dispute is given with the reason for non-disclosure (para 92).' },
        { type:'table', title:'Contingent assets (FRS 37 paras 31-35, 89)', columns:[
          { key:'description', label:'Nature of the contingent asset', emphasis:true },
          { key:'effect', label:'Estimate of financial effect per the client', type:'num', sum:true },
          { key:'close', label:'Amount recognised', type:'num', sum:true, flag: v => v != null && Math.abs(v) > 0.01 },
          { key:'nature', label:'Nature and how it arose', input:'text', wide:true },
          { key:'likelihood', label:'Likelihood of inflow', input:'select', options:['Virtually certain', 'Probable', 'Possible', 'Remote'] },
          { key:'disclosed', label:'Disclosed in the financial statements (Y/N)', input:'select', options:ynna },
          { key:'treatment', label:'Treatment per audit', type:'chip', chipClass: v => v === 'Recognised — not permitted' ? 'bad' : 'ok' },
          { key:'evidence', label:'Evidence obtained', input:'text', wide:true } ],
          rows: C.assets.map(r => ({ ...line(r), effect:r.undiscounted,
            treatment: Math.abs(r.bal_close || 0) > 0.01 ? 'Recognised — not permitted' : 'Not recognised',
            __cls: Math.abs(r.bal_close || 0) > 0.01 ? 'flag' : '' })),
          emptyText:'No contingent assets are recorded on the schedule.',
          footnote:'A contingent asset carried in the balance sheet is raised as EX-PROV-11.' }
      ];
    },
    flag(st, d) { return d.contingent.recognisedAssets.length > 0; } },

  /* --------------------------------------------------- U7.7 completeness */
  { id:'completeness', ref:'U7.7', title:'Completeness',
    objective:'To obtain evidence that all provisions, contingent liabilities and contingent assets have been identified and recorded — the direction of risk for this area is understatement and omission.',
    procedures:['Performed the completeness procedures set out below and recorded for each the period covered, the evidence obtained and the matters identified.',
                'Followed up every matter identified to the provisions and contingencies schedule or to the summary of unadjusted differences.'],
    render(st, ctx) {
      const C = ctx.d.completeness;
      return [
        { type:'note', tone: C.notPerformed.length ? 'bad' : C.outstanding ? 'warn' : 'info',
          html: C.notPerformed.length ? `<b>${C.notPerformed.length} completeness procedure(s) recorded as not performed.</b> Each is raised as EX-PROV-17.`
            : C.outstanding ? `${C.outstanding} procedure(s) not yet answered.` : 'All completeness procedures recorded as performed.' },
        { type:'stats', items:[
          { label:'Procedures performed', value: `${C.performed} of ${C.items.length}`, cls: C.performed === C.items.length ? 'ok' : 'warn' },
          { label:'Not performed', value: C.notPerformed.length, cls: C.notPerformed.length ? 'bad' : 'ok' },
          { label:'Not yet answered', value: C.outstanding, cls: C.outstanding ? 'warn' : 'ok' } ] },
        { type:'table', title:'Completeness procedures', columns:[
          { key:'key', label:'Ref' },
          { key:'text', label:'Procedure', wrap:true },
          { key:'cmDone', label:'Performed (Y/N/n-a)', input:'select', options:ynna },
          { key:'cmFrom', label:'Period covered from', input:'date' },
          { key:'cmTo', label:'Period covered to', input:'date' },
          { key:'cmEvidence', label:'Evidence obtained / documents examined', input:'text', wide:true },
          { key:'cmFindings', label:'Matters identified and follow-up', input:'text', wide:true } ],
          rows: C.items.map(x => ({ ...x, key:x.key.toUpperCase(), __cls: x.done === 'N' ? 'flag' : '' })),
          footnote:'The minutes reviewed and the post year-end payments reviewed must carry the date range examined — the review is only as complete as the period it covers. Events after the reporting period are considered under SSA 560 and FRS 10 up to the date of the auditor\'s report.' }
      ];
    },
    flag(st, d) { return d.completeness.notPerformed.length > 0; } },

  /* ------------------------------------------------------ U7.8 estimates */
  { id:'estimate', ref:'U7.8', title:'Estimate evaluation',
    objective:'To evaluate the provisions as accounting estimates under SSA 540 (Revised): to understand management\'s estimation process, to review the outcome of prior-year estimates, to evaluate the significant assumptions and the evidence for and against them, and to stand back and consider whether the estimates are reasonable or indicate management bias.',
    procedures:['Obtained an understanding of the method, assumptions and data management uses for each class of provision and of the controls over the estimation process (SSA 540 paras 13, 23).',
                'Performed a retrospective review of the prior-year provisions against their actual outcome and considered the differences for indicators of management bias (SSA 540 paras 23(c), 32).',
                'Identified the significant assumptions, recorded the evidence supporting each and the evidence contradicting it, and concluded on whether each is reasonable (SSA 540 paras 23(b), 33).',
                'Established whether the method changed from the prior year and whether the change is appropriate in the circumstances.',
                'Performed a sensitivity analysis over the aggregate provision and considered the effect against performance materiality.',
                'Stood back and evaluated whether the audit evidence obtained is sufficient and appropriate and whether the estimates are reasonable in the context of the applicable financial reporting framework (SSA 540 paras 33-36).'],
    render(st, ctx) {
      const d = ctx.d, E = d.estimate, m0 = ctx.money0, money = ctx.money;
      return [
        { type:'controls', items:[
          { key:'retroTol', label:'Tolerance on the retrospective review', kind:'number', help:`Blank = trivial threshold (${m0(ctx.trivial)}). Currently ${m0(E.retroTol)}.` },
          { key:'methodChange', label:'Method changed from the prior year', kind:'select', options:['', 'No change', 'Changed'] },
          { key:'methodChangeReason', label:'Reason for the change and why it is appropriate', kind:'text' },
          { key:'sensPct', label:'Sensitivity applied to the aggregate provision (%)', kind:'number' },
          { key:'kaRows', label:'Lines for significant assumptions', kind:'number' },
          { key:'standBack', label:'Stand-back conclusion (SSA 540 paras 33-36)', kind:'text' } ] },
        { type:'stats', items:[
          { label:'Process questions answered', value: `${E.processAnswered} of ${EST_PROCESS.length}` },
          { label:'Process weaknesses', value: E.processNo.length, cls: E.processNo.length ? 'warn' : 'ok' },
          { label:'Prior-year estimates reviewed', value: E.retro.length },
          { label:'Over-provided in the prior year', value: E.over },
          { label:'Under-provided in the prior year', value: E.under },
          { label:'Indicator of management bias', value: E.biasIndicator ? `Yes — consistently ${E.biasDirection.toLowerCase()}` : 'Not indicated', cls: E.biasIndicator ? 'bad' : 'ok' },
          { label:'Method vs prior year', value: E.methodChange || '— record —', cls: E.methodChange === 'Changed' && !E.methodChangeReason ? 'warn' : '' },
          { label:`Sensitivity ${E.sensPct}%`, value: money(E.sensAmount), cls: E.sensAbovePm ? 'warn' : 'ok' },
          { label:'Assumptions not reasonable', value: E.notReasonable.length, cls: E.notReasonable.length ? 'bad' : 'ok' } ] },

        { type:'heading', text:'Understanding and evaluation of management\'s estimation process' },
        { type:'checklist', store:'estProcess', items: EST_PROCESS.map(i => ({ id:i.id, text:i.text, group:i.group })) },

        { type:'heading', text:'Retrospective review of the prior-year provisions (SSA 540 paras 23(c), 32)' },
        { type:'table', columns:[
          { key:'description', label:'Provision', emphasis:true },
          { key:'cls', label:'Class' },
          { key:'pyProv', label:'Provision at the prior year end', input:'number' },
          { key:'actual', label:'Actual outcome — amount finally settled or released', input:'number' },
          { key:'retroDiff', label:'Outcome − provision', type:'num', sum:true, flag: (v, row) => row.__retroFlag },
          { key:'retroDir', label:'Direction', type:'chip', chipClass: v => v === 'In line' ? 'ok' : v ? 'warn' : 'grey' },
          { key:'comment', label:'Explanation and effect on this year\'s estimate', input:'text', wide:true } ],
          rows: d.provisions.map(r => ({ ...line(r), retroDiff:r.__retroDiff, retroDir:r.__retroDir || null,
            __retroFlag: r.__retroDiff != null && Math.abs(r.__retroDiff) > E.retroTol,
            __cls: r.__retroDiff != null && Math.abs(r.__retroDiff) > E.retroTol ? 'flag' : '' })),
          emptyText:'No provisions to review.',
          footnote:'The retrospective review is not a reassessment with hindsight; it is evidence about the effectiveness of management\'s estimation process and about possible bias. A difference above the tolerance is raised as EX-PROV-20.' },

        { type:'heading', text:'Significant assumptions — evidence for and against' },
        { type:'table', columns:[
          { key:'line', label:'#', type:'int' },
          { key:'kaAssumption', label:'Significant assumption', input:'text', wide:true },
          { key:'kaMgmtBasis', label:'Management\'s basis for it', input:'text', wide:true },
          { key:'kaSupporting', label:'Evidence supporting the assumption', input:'text', wide:true },
          { key:'kaContradictory', label:'Evidence contradicting the assumption', input:'text', wide:true },
          { key:'kaConclusion', label:'Auditor\'s conclusion', input:'select', options:['Reasonable', 'Not reasonable', 'Indicative of bias'] } ],
          rows: E.assumptions.map(x => ({ ...x, __cls: x.conclusion && x.conclusion !== 'Reasonable' ? 'flag' : '' })),
          footnote:'SSA 540 (Revised) paras 33 and 35 require contradictory evidence to be sought and considered, not only evidence that corroborates management\'s estimate.' },

        { type:'note', tone: E.sensAbovePm ? 'warn' : 'info',
          html: `A ${E.sensPct}% movement in the aggregate provision of ${money(d.totals.close)} is ${money(E.sensAmount)}, ${E.sensAbovePm ? '<b>above</b>' : 'below'} performance materiality of ${money(ctx.pm)}.` },
        { type:'note', tone: E.standBack ? 'info' : 'warn',
          html: E.standBack ? `<b>Stand-back conclusion:</b> ${String(E.standBack).replace(/</g, '&lt;')}` : 'Record the stand-back conclusion in the control above (SSA 540 paras 33-36).' }
      ];
    },
    flag(st, d) { return d.estimate.biasIndicator || d.estimate.exceptions.length > 0 || d.estimate.notReasonable.length > 0; } },

  { id:'conclusion', ref:'U7.9', title:'Exceptions & conclusion', kind:'conclusion' }
];

/* =========================================================== CONCLUSION */
function suggestConclusion(st, ctx) {
  const d = ctx.d, T = d.totals, L = d.lead, M = d.measurement, C = d.contingent;
  const ex = (st.exceptions || []).filter(e => e.disposition === 'open');
  return [
    `Provisions total ${ctx.money(T.close)} across ${T.count} item(s) in ${d.byClass.length} class(es)${L.tbDiff == null ? '' : Math.abs(L.tbDiff) <= 0.01 ? ', agreeing to the trial balance' : `, differing from the trial balance by ${ctx.money(L.tbDiff)}`}.`,
    d.castFails.length ? `${d.castFails.length} provision(s) do not cast (total difference ${ctx.money(T.castDiff)}).` : 'Every provision rolls forward arithmetically from opening to closing.',
    d.splitFails.length ? `${d.splitFails.length} current / non-current analysis(es) do not agree to the closing balance.` : '',
    `The FRS 37 para 14 recognition criteria were tested for each item; ${d.recognition.supported} of ${d.provisions.length} provision(s) are supported by all three criteria${d.recognition.failed.length ? ` and ${d.recognition.failed.length} fail at least one` : ''}.`,
    M.needDiscount.length ? `${M.needDiscount.length} provision(s) settling beyond ${M.months} months are carried undiscounted.` : 'Provisions settling beyond twelve months are discounted at a pre-tax rate.',
    M.unwindFails.length ? `The unwinding of the discount does not agree to the recomputation on ${M.unwindFails.length} provision(s).` : '',
    d.types.futureOpLosses.length ? `${d.types.futureOpLosses.length} provision(s) relate to future operating losses, which FRS 37 para 63 does not permit.` : '',
    d.types.onerousShort.length ? `${d.types.onerousShort.length} onerous contract(s) are under-provided by ${ctx.money(d.types.onerousShort.reduce((s, x) => s + x.shortfall, 0))}.` : '',
    d.legal.items.length ? `${d.legal.items.length} claim(s) were controlled through legal confirmations; ${d.legal.replies} repl(ies) were received${d.legal.disagreements.length ? ` and the auditor's conclusion differs from management's on ${d.legal.disagreements.length}` : ''}.` : 'No litigation or claims were identified.',
    `${C.liabilities.length} contingent liabilit(ies) (${ctx.money(C.clTotal)}) and ${C.assets.length} contingent asset(s) (${ctx.money(C.caTotal)}) are disclosed${C.recognisedAssets.length ? `; ${C.recognisedAssets.length} contingent asset(s) have been recognised, which FRS 37 para 31 prohibits` : ''}.`,
    `${d.completeness.performed} of ${d.completeness.items.length} completeness procedures were performed${d.completeness.notPerformed.length ? `; ${d.completeness.notPerformed.length} were not` : ''}.`,
    d.estimate.biasIndicator ? `The retrospective review indicates the prior-year provisions were consistently ${d.estimate.biasDirection.toLowerCase()} — an indicator of possible management bias under SSA 540 (Revised).` : '',
    ex.length ? `${ex.length} exception(s) remain open in the register.` : 'No exceptions remain open.',
    'Subject to the above, provisions are complete, represent present obligations at the reporting date measured at the best estimate of the expenditure required to settle them, and contingent liabilities and contingent assets are appropriately disclosed in accordance with FRS 37.'
  ].filter(Boolean).join(' ');
}

return {
  code:'PROV', name:'Provisions & Contingencies', group:'Liabilities & equity', accepts:'.xlsx,.xlsm,.csv',
  blurb:'The FRS 37 file: lead and class analysis, movement and casting, the para 14 recognition test, measurement and discounting, onerous contracts and restructuring, legal confirmations, contingency disclosure, completeness and an SSA 540 estimate evaluation — from one uploaded provisions and contingencies schedule.',
  objective:'To obtain sufficient appropriate audit evidence that provisions are complete, represent present obligations at the reporting date, are measured at the best estimate of the expenditure required to settle them, and that contingent liabilities and contingent assets are appropriately disclosed in accordance with FRS 37 / SFRS(I) 1-37.',
  fields, tests, compute, pages, defaultConfig, STANDARD_COLUMNS,
  procedures: pages.flatMap(p => p.procedures || []),
  columns: STANDARD_COLUMNS, suggestConclusion
};
})();

Modules.register(ProvModule);
