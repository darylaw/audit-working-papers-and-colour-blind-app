/* ==========================================================================
   rp.js -- Related parties (FRS 24) as an auditor actually works it.

   One uploaded movement schedule -- balances and transactions grouped under
   each related party, with a brought-forward and a carried-forward line per
   party, in the original currency and translated to the functional currency
   -- feeds:
     L5    Related party register        L5.4  Confirmation control
     L5.1  Balances and movements        L5.5  Key management personnel
     L5.2  Translation check             L5.6  Disclosure schedule
     L5.3  Terms and arm's length

   The party header rows carry the counterparty and, where stated, the
   relationship; the core cleaner treats a lone name as a group header and a
   name-plus-relationship row as data. Both are recognised here and forward-
   filled into every movement line beneath them.
   ========================================================================== */

const RPModule = (() => {
const r2 = n => n == null || isNaN(n) ? null : Math.round(n * 100) / 100;
const r4 = n => n == null || isNaN(n) ? null : Math.round(n * 10000) / 10000;
const num = v => (v === '' || v == null || isNaN(Number(v))) ? null : Number(v);
const inp = (cfg, key, k) => num(cfg[key + ':' + k]);
const txt = (cfg, key, k) => { const v = cfg[key + ':' + k]; return v == null ? '' : String(v).trim(); };
const isBlank = v => v == null || String(v).trim() === '';
const pkey = name => Core.keyify(name) || 'blank';

const OPENING_RE = /\bb\/?f\b|brought\s+forward|opening|\bb\/d\b|beginning/i;
const CLOSING_RE = /\bc\/?f\b|carried\s+forward|closing|\bc\/d\b|ending/i;
const KMP_RE = /key\s*management|\bkmp\b|chief\s+\w+\s+officer|\bceo\b|\bcfo\b|\bcoo\b|executive officer|管理人员/i;
const DIRECTOR_RE = /director|董事/i, ENTITY_VIA_RE = /common|controlled|entity|company|owned|shareholder|holding/i;
/* a director is KMP; an entity related "through" a director (common director, entity controlled by KMP) is not */
const isKMPText = s => { const v = String(s || ''); return KMP_RE.test(v) || (DIRECTOR_RE.test(v) && !ENTITY_VIA_RE.test(v)); };
const ADVANCE_RE = /\bloan|advance|lent|lend|funding/i;
const NOT_ADVANCE_RE = /repay|interest|novation|settle/i;

const RELATIONSHIPS = ['Parent', 'Subsidiary', 'Fellow subsidiary', 'Entity under common control', 'Associate', 'Joint venture',
  'Key management personnel', 'Close family member of KMP', 'Entity controlled by KMP', 'Common director', 'Shareholder', 'Post-employment benefit plan', 'Other related party'];
const NATURES = [
  { label:'Sales of goods', re:/\bsales?\b|goods sold|sold to/i },
  { label:'Purchases of goods', re:/purchase|goods (bought|received)|bought from/i },
  { label:'Services rendered / received', re:/service|consultanc|commission/i },
  { label:'Management fees', re:/management fee|admin(istration)? fee|service fee/i },
  { label:'Interest', re:/interest/i },
  { label:'Loans and advances given', re:/loan (given|granted|to)|advance|lent|funding/i },
  { label:'Loans received', re:/loan (received|from)|borrow/i },
  { label:'Repayments', re:/repay|settle/i },
  { label:'Expenses paid on behalf', re:/on behalf|reimburse|recharge/i },
  { label:'Novation / assignment', re:/novation|assign|transfer/i },
  { label:'Exchange differences', re:/exchange|translation|fx\b/i },
  { label:'Dividends', re:/dividend/i },
  { label:'Rental', re:/rent|lease/i },
  { label:'Other transactions', re:/./ },
];
const natureOf = s => (NATURES.find(n => n.re.test(String(s || ''))) || NATURES[NATURES.length - 1]).label;
const VOUCH_DOCS = ['Confirmation reply', 'Agreement / contract', 'Invoice', 'Bank statement', 'Board resolution', 'Journal / voucher', 'Prior year file', 'Other'];
const yn = ['Y', 'N'];

/* ---------------------------------------------------------------- fields */
const fields = [
  { key:'party', label:'Related party', role:'category', type:'text', required:true, satisfiedByGroup:true,
    synonyms:['Name of Related Party','关联方 Name of Related Party','关联方','Related Party','Related party name','Counterparty','Party','Name','Entity','Company','Related Party Name','关联方名称'] },
  { key:'relationship', label:'Relationship', type:'text',
    synonyms:['RP Type','Relationship','Nature of relationship','Type of relationship','Relation','Related party type','Category','关系'] },
  { key:'txn_type', label:'Balance / transaction type', type:'text', required:true, dupKey:true,
    synonyms:['Type of Balance','Type of Transaction','Transaction type','Nature','Nature of transaction','Description','Particulars','Details','Movement','Narrative','交易性质','摘要'] },
  { key:'currency', label:'Currency', type:'text', synonyms:['Currency','Ccy','Txn Ccy','Original currency','Cur','币种','货币'] },
  { key:'rate', label:'Exchange rate', type:'number', synonyms:['Rate','Exchange rate','FX rate','Translation rate','Conversion rate','汇率'] },
  { key:'amount', label:'Amount in original currency', type:'number', required:true, dupKey:true,
    synonyms:['Amount in Txn Ccy','Amount in transaction currency','Amount','Original amount','Amount (FCY)','Foreign currency amount','Amount in original currency','原币金额','金额'] },
  { key:'functional', label:'Amount in functional currency (per book)', type:'number',
    synonyms:['Per book','Per books','Converted','Amount in USD','Amount in SGD','Amount (SGD)','Amount (USD)','Book amount','Functional currency','Translated amount','Reporting currency','本位币金额'] },
  { key:'workdone', label:'Work done (client tick)', type:'text', synonyms:['Workdone','Work done','Tickmark','Remarks','Notes','Ref','备注'] },
  { key:'txn_date', label:'Date', type:'date', synonyms:['Date','Transaction date','Posting date','日期'] },
];

const STANDARD_COLUMNS = [
  { key:'__party', label:'Related party' }, { key:'__relationship', label:'Relationship' },
  { key:'__rowKind', label:'Row type' }, { key:'txn_type', label:'Balance / transaction' }, { key:'__nature', label:'Nature' },
  { key:'currency', label:'Ccy' }, { key:'rate', label:'Rate', type:'num', dp:4, edit:true },
  { key:'amount', label:'Original currency', type:'num', edit:true }, { key:'functional', label:'Per book (functional)', type:'num', edit:true },
  { key:'__impliedRate', label:'Implied rate', type:'num', dp:4 }, { key:'workdone', label:'Client tick' }
];

const defaultConfig = () => ({
  functionalCcy: 'USD',
  castTol: 0.01,
  rateTolPct: 2,                 // stated rate vs year-end rate beyond this % -> EX-RP-02
  lineRateTolPct: 0.5,           // implied rate on a line vs stated rate beyond this % -> EX-RP-06
  roundSum: 100000,              // advance is "round" when a multiple of this in the original currency
  advThreshold: '',              // blank = performance materiality, in the functional currency
  kmpThreshold: '',              // blank = trivial threshold
});

/* ============================================================ COMPUTE */
function compute(recs, cfg, eng) {
  const pm = eng.materiality?.pm || 0, trivial = eng.materiality?.trivial || 0;
  const tol = Number(cfg.castTol) || 0.01;
  const fcy = String(cfg.functionalCcy || '').trim().toUpperCase();

  /* ---- forward-fill the party and relationship from header rows -------- */
  let cur = { party: null, relationship: null }, prevGroup = undefined;
  for (const r of recs) {
    if (r.__group !== prevGroup) { cur = { party: r.__group || null, relationship: null }; prevGroup = r.__group; }
    const ownName = !isBlank(r.party) && r.party !== r.__group ? r.party : null;
    const isHeader = r.amount == null && isBlank(r.txn_type) && (ownName || !isBlank(r.relationship));
    if (isHeader) { cur = { party: ownName || r.party, relationship: isBlank(r.relationship) ? null : r.relationship }; r.__rowKind = 'Party header'; r.__isHeader = true; }
    else { r.__isHeader = false; if (!isBlank(r.relationship) && !cur.relationship) cur.relationship = r.relationship; }
    r.__party = cur.party || '(no party)';
    r.__relationship = cur.relationship;
    if (!r.__isHeader) {
      const t = String(r.txn_type || '');
      r.__rowKind = OPENING_RE.test(t) ? 'Opening balance' : CLOSING_RE.test(t) ? 'Closing balance' : 'Movement';
    }
    r.__nature = r.__rowKind === 'Movement' ? natureOf(r.txn_type) : r.__rowKind;
    r.__displayKey = r.__isHeader ? r.__party : `${r.__party} · ${r.txn_type || 'row ' + r.__srcRow}`;
    r.__impliedRate = (r.amount != null && r.functional != null && Math.abs(r.functional) > 0.005) ? r4(r.amount / r.functional) : null;
    r.__lineRateDiffPct = (r.__impliedRate != null && r.rate > 0) ? r2((r.__impliedRate - r.rate) / r.rate * 100) : null;
  }
  const live = recs.filter(r => !r.__excluded && !r.__isHeader);

  /* ---- per party ------------------------------------------------------- */
  const byParty = new Map();
  for (const r of recs) {
    if (r.__excluded) continue;
    const k = pkey(r.__party);
    if (!byParty.has(k)) byParty.set(k, { key:k, party:r.__party, relationshipListed:r.__relationship, lines:[], currencies:new Set(), rates:[] });
    const p = byParty.get(k);
    if (!p.relationshipListed && r.__relationship) p.relationshipListed = r.__relationship;
    if (r.__isHeader) continue;
    p.lines.push(r);
    if (r.currency) p.currencies.add(String(r.currency).toUpperCase());
    if (r.rate > 0) p.rates.push(r.rate);
  }
  const sum = (arr, f) => r2(arr.reduce((s, x) => s + (f(x) || 0), 0));
  const parties = [...byParty.values()].map(p => {
    const open = p.lines.filter(r => r.__rowKind === 'Opening balance'), close = p.lines.filter(r => r.__rowKind === 'Closing balance'), mov = p.lines.filter(r => r.__rowKind === 'Movement');
    const currency = [...p.currencies][0] || fcy || '';
    const relInput = txt(cfg, 'relType', p.key);
    const relationship = relInput || p.relationshipListed || '';
    const statedRate = p.rates.length ? mode(p.rates) : null;
    const yeRate = inp(cfg, 'yeRate', currency);
    const o = { ...p, currency, multiCcy: p.currencies.size > 1, relationship, relInput, relationshipMissing: !relationship,
      isKMP: isKMPText(relationship) || isKMPText(p.party),
      openOrig: sum(open, r => r.amount), movOrig: sum(mov, r => r.amount), closeOrigClient: close.length ? sum(close, r => r.amount) : null,
      openFunc: sum(open, r => r.functional), movFunc: sum(mov, r => r.functional), closeFuncClient: close.length ? sum(close, r => r.functional) : null,
      hasOpening: open.length > 0, hasClosing: close.length > 0, movements: mov.length,
      natures: [...new Set(mov.map(r => r.__nature))],
      statedRate, yeRate, agreement: txt(cfg, 'agreement', p.key), interest: txt(cfg, 'interest', p.key), repayment: txt(cfg, 'repayment', p.key),
      secured: txt(cfg, 'secured', p.key), armsLength: txt(cfg, 'armsLength', p.key),
      confSent: txt(cfg, 'confSent', p.key), confRecd: txt(cfg, 'confRecd', p.key), confBal: inp(cfg, 'confBal', p.key), confAlt: txt(cfg, 'confAlt', p.key),
      kmpDisclosed: txt(cfg, 'kmpDisclosed', p.key), natureInput: txt(cfg, 'nature', p.key) };
    o.closeOrigAudit = r2(o.openOrig + o.movOrig);
    o.closeFuncAudit = r2(o.openFunc + o.movFunc);
    o.castDiffOrig = o.closeOrigClient != null ? r2(o.closeOrigClient - o.closeOrigAudit) : null;
    o.castDiffFunc = o.closeFuncClient != null ? r2(o.closeFuncClient - o.closeFuncAudit) : null;
    o.castBreak = (o.castDiffOrig != null && Math.abs(o.castDiffOrig) > tol) || (o.castDiffFunc != null && Math.abs(o.castDiffFunc) > tol);
    o.closeOrig = o.closeOrigClient != null ? o.closeOrigClient : o.closeOrigAudit;
    o.closeFunc = o.closeFuncClient != null ? o.closeFuncClient : o.closeFuncAudit;
    /* translation: functional = original / rate (rate quoted as units of original per unit of functional) */
    o.impliedRate = (o.closeOrig != null && o.closeFunc != null && Math.abs(o.closeFunc) > 0.005) ? r4(o.closeOrig / o.closeFunc) : null;
    o.isFunctional = !!fcy && currency === fcy;
    o.rateDiffPct = (o.yeRate > 0 && o.statedRate > 0) ? r2((o.statedRate - o.yeRate) / o.yeRate * 100) : null;
    o.closeAtYE = (o.yeRate > 0 && o.closeOrig != null) ? r2(o.closeOrig / o.yeRate) : null;
    o.translationDiff = (o.closeAtYE != null && o.closeFunc != null) ? r2(o.closeFunc - o.closeAtYE) : null;
    o.rateDivergent = !o.isFunctional && o.rateDiffPct != null && Math.abs(o.rateDiffPct) > (num(cfg.rateTolPct) ?? 2);
    o.termsRecorded = o.agreement === 'Y' || !!o.repayment || !!o.interest;
    o.confDiff = (o.confBal != null && o.closeOrig != null) ? r2(o.confBal - o.closeOrig) : null;
    o.confBreak = o.confDiff != null && Math.abs(o.confDiff) > tol;
    o.lineRateBreaks = mov.concat(open, close).filter(r => r.__lineRateDiffPct != null && Math.abs(r.__lineRateDiffPct) > (num(cfg.lineRateTolPct) ?? 0.5)).length;
    return o;
  }).sort((a, b) => a.party.localeCompare(b.party));
  const partyByKey = Object.fromEntries(parties.map(p => [p.key, p]));
  for (const r of recs) r.__partyKey = pkey(r.__party);

  /* ---- round-sum advances ---------------------------------------------- */
  const round = Number(cfg.roundSum) || 0;
  const advThreshold = cfg.advThreshold !== '' && cfg.advThreshold != null ? Number(cfg.advThreshold) : pm;
  const advances = [];
  for (const r of live) {
    r.__isAdvance = r.__rowKind === 'Movement' && ADVANCE_RE.test(r.txn_type || '') && !NOT_ADVANCE_RE.test(r.txn_type || '') && (r.amount || 0) > 0.005;
    r.__isRound = r.__isAdvance && round > 0 && Math.abs(r.amount) >= round && Math.abs(r.amount % round) < 0.005;
    const func = r.functional != null ? Math.abs(r.functional) : (r.rate > 0 ? Math.abs(r.amount / r.rate) : Math.abs(r.amount || 0));
    r.__funcAbs = r2(func);
    const p = partyByKey[r.__partyKey];
    r.__advNoTerms = r.__isRound && func >= advThreshold && !(p && p.termsRecorded);
    if (r.__isAdvance) advances.push(r);
  }

  /* ---- currencies (translation inputs) --------------------------------- */
  const ccyMap = {};
  for (const p of parties) { const c = ccyMap[p.currency] || (ccyMap[p.currency] = { currency:p.currency, parties:0, closeOrig:0, closeFunc:0, rates:new Set() }); c.parties++; c.closeOrig += p.closeOrig || 0; c.closeFunc += p.closeFunc || 0; if (p.statedRate) c.rates.add(p.statedRate); }
  const currencies = Object.values(ccyMap).map(c => ({ ...c, closeOrig:r2(c.closeOrig), closeFunc:r2(c.closeFunc), ratesUsed:[...c.rates].map(x => x.toFixed(4)).join(', '), yeRate: inp(cfg, 'yeRate', c.currency), avgRate: inp(cfg, 'avgRate', c.currency), isFunctional: !!fcy && c.currency === fcy })).sort((a, b) => a.currency.localeCompare(b.currency));

  /* ---- KMP ------------------------------------------------------------- */
  const kmpThreshold = cfg.kmpThreshold !== '' && cfg.kmpThreshold != null ? Number(cfg.kmpThreshold) : trivial;
  const kmp = parties.filter(p => p.isKMP).map(p => ({ ...p, txnFunc: sum(p.lines.filter(r => r.__rowKind === 'Movement'), r => Math.abs(r.functional)), material: Math.abs(p.closeFunc || 0) > kmpThreshold, disclosureGap: Math.abs(p.closeFunc || 0) > kmpThreshold && p.kmpDisclosed !== 'Y' }));

  /* ---- disclosure schedule --------------------------------------------- */
  const disc = {};
  for (const p of parties) {
    const rel = p.relationship || '(relationship not stated)';
    const g = disc[rel] || (disc[rel] = { relationship:rel, parties:0, closeFunc:0, natures:{} });
    g.parties++; g.closeFunc += p.closeFunc || 0;
    for (const r of p.lines.filter(x => x.__rowKind === 'Movement')) g.natures[r.__nature] = (g.natures[r.__nature] || 0) + (r.functional || 0);
  }
  const disclosure = Object.values(disc).sort((a, b) => a.relationship.localeCompare(b.relationship)).map(g => ({ ...g, closeFunc:r2(g.closeFunc), natures:Object.entries(g.natures).map(([nature, amount]) => ({ nature, amount:r2(amount) })).sort((a, b) => a.nature.localeCompare(b.nature)) }));

  const totals = { parties:parties.length, lines:live.length, openFunc:sum(parties, p => p.openFunc), movFunc:sum(parties, p => p.movFunc), closeFunc:sum(parties, p => p.closeFunc), closeFuncAudit:sum(parties, p => p.closeFuncAudit),
    castBreaks:parties.filter(p => p.castBreak).length, missingRel:parties.filter(p => p.relationshipMissing).length, rateDivergent:parties.filter(p => p.rateDivergent).length,
    advances:advances.length, roundNoTerms:advances.filter(r => r.__advNoTerms).length, kmp:kmp.length, kmpGaps:kmp.filter(k => k.disclosureGap).length,
    confSent:parties.filter(p => p.confSent).length, confRecd:parties.filter(p => p.confRecd === 'Y').length, confBreaks:parties.filter(p => p.confBreak).length };
  return { parties, partyByKey, currencies, advances, kmp, disclosure, totals, fcy, tol, pm, trivial, advThreshold, kmpThreshold, round };
}

function mode(arr) {
  const m = new Map(); let best = arr[0], bc = 0;
  for (const v of arr) { const c = (m.get(v) || 0) + 1; m.set(v, c); if (c > bc) { bc = c; best = v; } }
  return best;
}

/* ============================================================== TESTS */
const tests = [
  { id:'EX-RP-01', scope:'population', label:'Related party movement does not cast', basis:'L5.1',
    fn:(recs, cfg, eng, d) => d.parties.filter(p => p.castBreak).map(p => ({ key:p.party, expected:p.closeOrigAudit, actual:p.closeOrigClient ?? p.closeFuncClient,
      difference: p.castDiffFunc != null && Math.abs(p.castDiffFunc) > d.tol ? p.castDiffFunc : (p.castDiffOrig != null && p.impliedRate ? r2(p.castDiffOrig / p.impliedRate) : p.castDiffOrig),
      detail:`Opening ${fmt(p.openOrig)} + movements ${fmt(p.movOrig)} = ${fmt(p.closeOrigAudit)} ${p.currency}; balance carried forward per schedule ${fmt(p.closeOrigClient)} (difference ${fmt(p.castDiffOrig)} ${p.currency}${p.castDiffFunc != null ? ', ' + fmt(p.castDiffFunc) + ' ' + d.fcy : ''}).` })) },
  { id:'EX-RP-02', scope:'population', label:'Translation rate differs from the year-end rate', basis:'L5.2',
    fn:(recs, cfg, eng, d) => d.parties.filter(p => p.rateDivergent).map(p => ({ key:p.party, expected:p.yeRate, actual:p.statedRate, difference:p.translationDiff,
      detail:`Schedule translates ${p.currency} at ${p.statedRate}; year-end rate entered ${p.yeRate} (${p.rateDiffPct}% apart, tolerance ${cfg.rateTolPct}%). Closing balance per book ${fmt(p.closeFunc)} ${d.fcy} vs ${fmt(p.closeAtYE)} ${d.fcy} at the year-end rate.` })) },
  { id:'EX-RP-03', scope:'population', label:'Relationship not stated', basis:'L5', severity:'above-trivial',
    fn:(recs, cfg, eng, d) => d.parties.filter(p => p.relationshipMissing).map(p => ({ key:p.party, expected:'Relationship stated', actual:'Not stated', difference:p.closeFunc,
      detail:`No relationship recorded in the schedule or by the auditor for a party with a closing balance of ${fmt(p.closeFunc)} ${d.fcy}. FRS 24 para 18 requires the nature of the relationship to be disclosed; the completeness of the related party population cannot be assessed without it.` })) },
  { id:'EX-RP-04', label:'Material round-sum advance with no stated terms', basis:'L5.3',
    fn:(r, cfg, eng, d) => r.__advNoTerms && { actual:r.amount, difference:r.__funcAbs, cell:r['__cell_amount'],
      detail:`${r.txn_type} of ${fmt(r.amount)} ${r.currency || ''} (${fmt(r.__funcAbs)} ${d.fcy}) is a round sum at or above ${fmt(d.advThreshold)} ${d.fcy} and no agreement, interest rate or repayment terms are recorded for ${r.__party}. Obtain the agreement and assess arm's length terms (FRS 24 paras 18, 23).` } },
  { id:'EX-RP-05', scope:'population', label:'Key management personnel balance requiring separate disclosure', basis:'L5.5', severity:'above-trivial',
    fn:(recs, cfg, eng, d) => d.kmp.filter(k => k.disclosureGap).map(k => ({ key:k.party, expected:'Disclosed separately (FRS 24 paras 17-18)', actual:k.kmpDisclosed || 'Not confirmed', difference:k.closeFunc,
      detail:`Balance with key management personnel of ${fmt(k.closeFunc)} ${d.fcy} (transactions ${fmt(k.txnFunc)} ${d.fcy}) must be disclosed separately from other related party categories, together with compensation by category (para 17).` })) },
  { id:'EX-RP-06', label:'Translated amount does not agree to the stated rate', basis:'L5.2', severity:'informational',
    fn:(r, cfg) => !r.__isHeader && r.__lineRateDiffPct != null && Math.abs(r.__lineRateDiffPct) > (num(cfg.lineRateTolPct) ?? 0.5) &&
      { expected:r.rate, actual:r.__impliedRate, difference: r.rate > 0 ? r2(r.functional - r.amount / r.rate) : null, cell:r['__cell_functional'], detail:`Implied rate ${r.__impliedRate} vs stated ${r.rate} (${r.__lineRateDiffPct}%).` } },
  { id:'EX-RP-07', scope:'population', label:'Balance per confirmation differs from the schedule', basis:'L5.4',
    fn:(recs, cfg, eng, d) => d.parties.filter(p => p.confBreak).map(p => ({ key:p.party, expected:p.closeOrig, actual:p.confBal, difference: p.impliedRate ? r2(p.confDiff / p.impliedRate) : p.confDiff,
      detail:`Confirmed ${fmt(p.confBal)} ${p.currency} against ${fmt(p.closeOrig)} ${p.currency} per the schedule.` })) },
  { id:'EX-RP-08', scope:'population', label:'Party with no opening or closing balance line', basis:'L5.1', severity:'informational',
    fn:(recs, cfg, eng, d) => d.parties.filter(p => !p.hasOpening || !p.hasClosing).map(p => ({ key:p.party, actual:`${p.hasOpening ? '' : 'no opening'}${!p.hasOpening && !p.hasClosing ? ', ' : ''}${p.hasClosing ? '' : 'no closing'}`,
      detail:'The movement cannot be proved from opening to closing; agree the balance to the ledger directly.' })) },
];
const fmt = n => n == null ? 'n/a' : Number(n).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/* ============================================================== PAGES */
const relChip = v => !v || /not stated/i.test(v) ? 'bad' : isKMPText(v) ? 'warn' : 'info';
const lineRow = r => ({ __rec:r, party:r.__party, kind:r.__rowKind, txn:r.txn_type, nature:r.__nature, ccy:r.currency, rate:r.rate, amount:r.amount, functional:r.functional, implied:r.__impliedRate, lineDiff:r.__lineRateDiffPct != null ? r.__lineRateDiffPct / 100 : null, tick:r.workdone });

const pages = [
  { id:'source',  ref:'L5.0',  title:'Source data',     kind:'source' },
  { id:'cleaned', ref:'L5.0a', title:'Cleaned listing', kind:'cleaned' },
  { id:'mapping', ref:'L5.0b', title:'Column mapping',  kind:'mapping' },

  { id:'register', ref:'L5', title:'Related party register',
    objective:'To identify every related party of the entity, the nature of the relationship and of the transactions and balances with each (FRS 24 paras 9, 18), as the basis for assessing completeness of identification and adequacy of disclosure.',
    procedures:['Built the register from the party header rows of the client\'s movement schedule, forward-filling the counterparty and relationship into every balance and transaction line beneath.',
                'Recorded the relationship per the schedule and, where absent or imprecise, the relationship per the auditor\'s enquiry and inspection of the register of members, directors\' declarations and group structure.',
                'Classified the nature of transactions with each party from the transaction descriptions and recorded the auditor\'s description for the disclosure note.'],
    flag:(st, d) => d.totals.missingRel > 0,
    render(st, ctx) {
      const d = ctx.d, money = ctx.money;
      const rows = d.parties.map(p => ({ __key:p.key, party:p.party, relListed:p.relationshipListed || '', relEff:p.relationship || 'Not stated', ccy:p.currency, natures:p.natures.join('; '), lines:p.movements, closeFunc:p.closeFunc, kmp: p.isKMP ? 'KMP' : '', __cls: p.relationshipMissing ? 'flag' : '' }));
      return [
        { type:'controls', items:[{ key:'functionalCcy', label:'Functional / presentation currency', kind:'text', help:'Balances translated "per book" are in this currency.' }] },
        { type:'stats', items:[
          { label:'Related parties', value:d.totals.parties }, { label:'Balance and transaction lines', value:d.totals.lines },
          { label:'Closing balances per book', value:money(d.totals.closeFunc) },
          { label:'Relationship not stated', value:d.totals.missingRel, cls: d.totals.missingRel ? 'bad' : 'ok' },
          { label:'Key management personnel', value:d.totals.kmp, cls: d.totals.kmp ? 'warn' : '' } ] },
        { type:'table', title:'Register of related parties', columns:[
          { key:'party', label:'Counterparty', emphasis:true }, { key:'relListed', label:'Relationship per schedule' },
          { key:'relType', label:'Relationship per auditor', input:'select', options:RELATIONSHIPS },
          { key:'relEff', label:'Relationship concluded', type:'chip', chipClass:relChip },
          { key:'kmp', label:'KMP', type:'chip', chipClass:() => 'warn' },
          { key:'ccy', label:'Ccy' }, { key:'natures', label:'Nature of transactions (derived)', wrap:true },
          { key:'nature', label:'Nature per auditor (for the note)', input:'text', wide:true },
          { key:'lines', label:'Movements', type:'int' }, { key:'closeFunc', label:`Closing balance (${d.fcy || 'functional'})`, type:'num', sum:true },
          { key:'source', label:'Source of identification', input:'text', wide:true } ], rows,
          footnote:'Rows painted red have no relationship stated in the schedule or by the auditor and are raised as EX-RP-03. The relationship per auditor overrides the schedule for the disclosure schedule on L5.6.' },
        { type:'note', html:'Completeness: compare the register to the register of members, directors\' interests declarations, the group structure chart, minutes and the prior year note. Add any party not in the client\'s schedule as an exception in the register.' }
      ];
    } },

  { id:'movement', ref:'L5.1', title:'Balances and transactions movement',
    objective:'To prove that, for every related party, the opening balance plus the transactions in the year equals the closing balance in the original currency and per book, and to vouch the transactions to supporting evidence.',
    procedures:['Recomputed the closing balance of every party as opening balance plus movements in the original currency and in the functional currency, and compared it to the balance carried forward per the schedule.',
                'Listed every balance and transaction line with the party, nature, currency and translated amount, and recorded the document to which each was vouched and whether it agreed.'],
    flag:(st, d) => d.totals.castBreaks > 0,
    render(st, ctx) {
      const d = ctx.d, money = ctx.money;
      const rows = d.parties.map(p => ({ __key:p.key, party:p.party, ccy:p.currency, openOrig:p.openOrig, movOrig:p.movOrig, closeOrigAudit:p.closeOrigAudit, closeOrigClient:p.closeOrigClient, diffOrig:p.castDiffOrig,
        openFunc:p.openFunc, movFunc:p.movFunc, closeFuncAudit:p.closeFuncAudit, closeFuncClient:p.closeFuncClient, diffFunc:p.castDiffFunc, __cls: p.castBreak ? 'flag' : '' }));
      const lines = ctx.recs.filter(r => !r.__isHeader).map(lineRow);
      const vouched = ctx.recs.filter(r => !r.__isHeader && r.__rowKind === 'Movement' && r.__wp?.movement?.agreed === 'Y').length;
      return [
        { type:'controls', items:[{ key:'castTol', label:'Casting tolerance', kind:'number' }] },
        { type:'stats', items:[
          { label:'Parties that cast', value:`${d.totals.parties - d.totals.castBreaks} of ${d.totals.parties}`, cls: d.totals.castBreaks ? 'bad' : 'ok' },
          { label:`Opening balances (${d.fcy})`, value:money(d.totals.openFunc) }, { label:`Movements (${d.fcy})`, value:money(d.totals.movFunc) },
          { label:`Closing per audit (${d.fcy})`, value:money(d.totals.closeFuncAudit) }, { label:`Closing per schedule (${d.fcy})`, value:money(d.totals.closeFunc) },
          { label:'Movements vouched and agreed', value:`${vouched} of ${ctx.recs.filter(r => r.__rowKind === 'Movement').length}` } ] },
        { type:'table', title:'Movement by party — original currency', columns:[
          { key:'party', label:'Related party', emphasis:true }, { key:'ccy', label:'Ccy' },
          { key:'openOrig', label:'Balance b/f', type:'num' }, { key:'movOrig', label:'Movements', type:'num' },
          { key:'closeOrigAudit', label:'Closing per audit', type:'num', formula:(row, C) => `${C(2)}${row}+${C(3)}${row}` },
          { key:'closeOrigClient', label:'Balance c/f per schedule', type:'num' },
          { key:'diffOrig', label:'Difference', type:'num', flag:v => v != null && Math.abs(v) > d.tol } ], rows,
          footnote:'Balances in the original currency of each party; multi-currency parties are summed as shown and should be split by the auditor.' },
        { type:'table', title:`Movement by party — per book (${d.fcy || 'functional currency'})`, columns:[
          { key:'party', label:'Related party', emphasis:true },
          { key:'openFunc', label:'Balance b/f', type:'num', sum:true }, { key:'movFunc', label:'Movements', type:'num', sum:true },
          { key:'closeFuncAudit', label:'Closing per audit', type:'num', sum:true, formula:(row, C) => `${C(1)}${row}+${C(2)}${row}` },
          { key:'closeFuncClient', label:'Balance c/f per schedule', type:'num', sum:true },
          { key:'diffFunc', label:'Difference', type:'num', sum:true, flag:v => v != null && Math.abs(v) > d.tol },
          { key:'castComment', label:'Explanation of difference', input:'text', wide:true } ], rows,
          footnote:'Differences beyond the tolerance are raised as EX-RP-01.' },
        { type:'table', title:'Balance and transaction lines — vouching', columns:[
          { key:'party', label:'Related party' }, { key:'kind', label:'Row', type:'chip', chipClass:v => v === 'Movement' ? 'info' : 'grey' },
          { key:'txn', label:'Balance / transaction', wrap:true }, { key:'nature', label:'Nature' }, { key:'ccy', label:'Ccy' },
          { key:'rate', label:'Rate', type:'num', dp:4 }, { key:'amount', label:'Original', type:'num' }, { key:'functional', label:'Per book', type:'num' },
          { key:'tick', label:'Client tick' },
          { key:'doc', label:'Vouched to', input:'select', options:VOUCH_DOCS },
          { key:'agreed', label:'Agreed (Y/N)', input:'select', options:yn },
          { key:'comment', label:'Comment', input:'text', wide:true } ], rows:lines, maxHeight:'70vh' }
      ];
    } },

  { id:'translation', ref:'L5.2', title:'Translation check',
    objective:'To verify that foreign currency balances with related parties are translated at the closing rate at the reporting date (FRS 21 para 23) and that transactions are translated at the rate on the transaction date or an appropriate average.',
    procedures:['Entered the closing rate at the reporting date and the average rate for the year for each currency in the schedule.',
                'Compared the rate used in the schedule for each party to the closing rate entered, and recomputed the closing balance at the closing rate.',
                'Recomputed the implied rate on every line as original amount divided by the translated amount and compared it to the rate stated.'],
    flag:(st, d) => d.totals.rateDivergent > 0,
    render(st, ctx) {
      const d = ctx.d, money = ctx.money;
      const ccyRows = d.currencies.map(c => ({ __key:c.currency, currency:c.currency, parties:c.parties, ratesUsed:c.ratesUsed, closeOrig:c.closeOrig, closeFunc:c.closeFunc, fn: c.isFunctional ? 'Functional' : '' }));
      const rows = d.parties.filter(p => !p.isFunctional).map(p => ({ __key:p.key, party:p.party, ccy:p.currency, statedRate:p.statedRate, impliedRate:p.impliedRate, yeRate:p.yeRate, diffPct: p.rateDiffPct != null ? p.rateDiffPct / 100 : null,
        closeOrig:p.closeOrig, closeFunc:p.closeFunc, closeAtYE:p.closeAtYE, translationDiff:p.translationDiff, lineBreaks:p.lineRateBreaks, __cls: p.rateDivergent ? 'flag' : '' }));
      return [
        { type:'controls', items:[
          { key:'rateTolPct', label:'Tolerance — schedule rate vs year-end rate (%)', kind:'number' },
          { key:'lineRateTolPct', label:'Tolerance — implied rate on a line vs stated rate (%)', kind:'number' } ] },
        { type:'table', title:'Currencies in the schedule — rates per audit', columns:[
          { key:'currency', label:'Currency', emphasis:true }, { key:'fn', label:'', type:'chip', chipClass:() => 'grey' }, { key:'parties', label:'Parties', type:'int' },
          { key:'ratesUsed', label:'Rate(s) used in the schedule' },
          { key:'yeRate', label:'Closing rate at year end (per audit)', input:'number' },
          { key:'avgRate', label:'Average rate for the year (per audit)', input:'number' },
          { key:'rateSource', label:'Source of rate', input:'text', wide:true },
          { key:'closeOrig', label:'Closing balances (original)', type:'num' }, { key:'closeFunc', label:`Closing balances (${d.fcy})`, type:'num', sum:true } ], rows:ccyRows,
          footnote:'Rates are units of the original currency per unit of the functional currency, as the schedule quotes them (functional = original ÷ rate).' },
        { type:'stats', items:[
          { label:'Foreign currency parties', value:rows.length },
          { label:'Rate differs from year-end rate', value:d.totals.rateDivergent, cls: d.totals.rateDivergent ? 'bad' : 'ok' },
          { label:'Translation difference at year-end rate', value:money(r2(rows.reduce((s, r) => s + (r.translationDiff || 0), 0))) },
          { label:'Lines where implied rate differs from stated', value:d.parties.reduce((s, p) => s + p.lineRateBreaks, 0), cls: d.parties.some(p => p.lineRateBreaks) ? 'warn' : 'ok' } ] },
        { type:'table', title:'Closing balances — rate per schedule vs closing rate', columns:[
          { key:'party', label:'Related party', emphasis:true }, { key:'ccy', label:'Ccy' },
          { key:'statedRate', label:'Rate per schedule', type:'num', dp:4 }, { key:'impliedRate', label:'Implied rate (original ÷ per book)', type:'num', dp:4 },
          { key:'yeRate', label:'Closing rate per audit', type:'num', dp:4 }, { key:'diffPct', label:'Divergence', type:'pct', dp:2 },
          { key:'closeOrig', label:'Closing (original)', type:'num' }, { key:'closeFunc', label:`Closing per book (${d.fcy})`, type:'num', sum:true },
          { key:'closeAtYE', label:`Closing at year-end rate (${d.fcy})`, type:'num', sum:true },
          { key:'translationDiff', label:'Difference', type:'num', sum:true, flag:(v, row) => row.__cls === 'flag' },
          { key:'lineBreaks', label:'Line rate breaks', type:'int' },
          { key:'trComment', label:'Comment', input:'text', wide:true } ], rows,
          emptyText:'Every party is denominated in the functional currency; no translation to test.',
          footnote:'Parties painted red use a rate beyond the tolerance from the closing rate entered and are raised as EX-RP-02 with the translation difference as the misstatement.' }
      ];
    } },

  { id:'terms', ref:'L5.3', title:'Terms and arm\'s length',
    objective:'To obtain the terms of related party balances — agreement, interest, repayment and security — and to assess whether transactions were on arm\'s length terms, in particular round-sum advances with no documented terms (FRS 24 paras 18, 23).',
    procedures:['For every party, recorded whether a signed agreement was sighted, the interest rate, the repayment terms, whether the balance is secured and the auditor\'s arm\'s length assessment.',
                'Identified every loan or advance in the year that is a round sum at or above the threshold and had no terms recorded, and raised it for follow-up.'],
    flag:(st, d) => d.totals.roundNoTerms > 0,
    render(st, ctx) {
      const d = ctx.d, money = ctx.money, m0 = ctx.money0;
      const rows = d.parties.map(p => ({ __key:p.key, party:p.party, rel:p.relationship || 'Not stated', ccy:p.currency, closeOrig:p.closeOrig, closeFunc:p.closeFunc, terms: p.termsRecorded ? 'Terms recorded' : 'No terms', __cls: !p.termsRecorded && d.advances.some(r => r.__partyKey === p.key && r.__isRound) ? 'flag' : '' }));
      const adv = d.advances.map(r => ({ ...lineRow(r), funcAbs:r.__funcAbs, round: r.__isRound ? 'Round sum' : '', status: r.__advNoTerms ? 'No terms — EX-RP-04' : r.__isRound ? (r.__funcAbs >= d.advThreshold ? 'Terms recorded' : 'Below threshold') : 'Not round', __cls: r.__advNoTerms ? 'flag' : '' }));
      return [
        { type:'controls', items:[
          { key:'roundSum', label:'Round-sum test: multiple of (original currency)', kind:'number' },
          { key:'advThreshold', label:`Materiality threshold for advances (${d.fcy})`, kind:'number', help:`Blank = performance materiality (${m0(ctx.pm)}). Currently ${m0(d.advThreshold)}.` } ] },
        { type:'table', title:'Terms per party', columns:[
          { key:'party', label:'Related party', emphasis:true }, { key:'rel', label:'Relationship', type:'chip', chipClass:relChip }, { key:'ccy', label:'Ccy' },
          { key:'closeOrig', label:'Closing (original)', type:'num' }, { key:'closeFunc', label:`Closing (${d.fcy})`, type:'num', sum:true },
          { key:'agreement', label:'Agreement sighted (Y/N)', input:'select', options:yn },
          { key:'interest', label:'Interest rate / basis', input:'text' },
          { key:'repayment', label:'Repayment terms', input:'text', wide:true },
          { key:'secured', label:'Secured (Y/N)', input:'select', options:yn },
          { key:'armsLength', label:'Arm\'s length (Y/N)', input:'select', options:yn },
          { key:'terms', label:'Status', type:'chip', chipClass:v => v === 'No terms' ? 'warn' : 'ok' },
          { key:'termsComment', label:'Basis of arm\'s length assessment', input:'text', wide:true } ], rows,
          footnote:'FRS 24 para 23 permits a statement that terms are equivalent to arm\'s length only if such terms can be substantiated — record the basis here.' },
        { type:'stats', items:[
          { label:'Loans and advances in the year', value:d.advances.length },
          { label:'Round-sum advances', value:d.advances.filter(r => r.__isRound).length },
          { label:'Material round sums with no terms', value:d.totals.roundNoTerms, cls: d.totals.roundNoTerms ? 'bad' : 'ok' },
          { label:'Value of advances', value:money(r2(d.advances.reduce((s, r) => s + (r.__funcAbs || 0), 0))) } ] },
        { type:'table', title:'Loans and advances given in the year', columns:[
          { key:'party', label:'Related party' }, { key:'txn', label:'Transaction', wrap:true }, { key:'ccy', label:'Ccy' },
          { key:'amount', label:'Original', type:'num' }, { key:'funcAbs', label:`Per book (${d.fcy})`, type:'num', sum:true },
          { key:'round', label:'Round sum', type:'chip', chipClass:() => 'warn' },
          { key:'status', label:'Status', type:'chip', chipClass:v => /EX-RP/.test(v) ? 'bad' : v === 'Terms recorded' ? 'ok' : 'grey' },
          { key:'purpose', label:'Business purpose per management', input:'text', wide:true },
          { key:'approval', label:'Approval sighted', input:'text', wide:true } ], rows:adv,
          emptyText:'No loans or advances to related parties in the year.' }
      ];
    } },

  { id:'confirm', ref:'L5.4', title:'Confirmation control',
    objective:'To obtain direct confirmation of the balance with each related party at the reporting date (ISA 505) and to agree the confirmed balance to the schedule.',
    procedures:['Sent a confirmation request to every related party under the auditor\'s control and recorded the dates sent and received.',
                'Agreed the balance confirmed to the closing balance per the schedule in the original currency and investigated differences.',
                'Recorded alternative procedures where no reply was received.'],
    flag:(st, d) => d.totals.confBreaks > 0,
    render(st, ctx) {
      const d = ctx.d;
      const rows = d.parties.map(p => ({ __key:p.key, party:p.party, rel:p.relationship || 'Not stated', ccy:p.currency, closeOrig:p.closeOrig, closeFunc:p.closeFunc, confDiff:p.confDiff, __cls: p.confBreak ? 'flag' : '' }));
      return [
        { type:'stats', items:[
          { label:'Parties', value:d.totals.parties }, { label:'Requests sent', value:`${d.totals.confSent} of ${d.totals.parties}`, cls: d.totals.confSent === d.totals.parties ? 'ok' : 'warn' },
          { label:'Replies received', value:`${d.totals.confRecd} of ${d.totals.parties}`, cls: d.totals.confRecd === d.totals.parties ? 'ok' : 'warn' },
          { label:'Balances agreeing', value:d.parties.filter(p => p.confDiff != null && !p.confBreak).length },
          { label:'Differences', value:d.totals.confBreaks, cls: d.totals.confBreaks ? 'bad' : 'ok' } ] },
        { type:'table', title:'Confirmation control sheet', columns:[
          { key:'party', label:'Related party', emphasis:true }, { key:'rel', label:'Relationship', type:'chip', chipClass:relChip }, { key:'ccy', label:'Ccy' },
          { key:'closeOrig', label:'Balance per schedule (original)', type:'num' }, { key:'closeFunc', label:`Per book (${d.fcy})`, type:'num', sum:true },
          { key:'confSent', label:'Request sent (date)', input:'text' },
          { key:'confRecd', label:'Reply received (Y/N)', input:'select', options:yn },
          { key:'confRecdDate', label:'Date received', input:'text' },
          { key:'confBal', label:'Balance per confirmation (original)', input:'number' },
          { key:'confDiff', label:'Confirmation − schedule', type:'num', flag:v => v != null && Math.abs(v) > d.tol },
          { key:'confAlt', label:'Alternative procedures / comment', input:'text', wide:true } ], rows,
          footnote:'Differences beyond the tolerance are raised as EX-RP-07. Where no reply is received, agree the balance to the counterparty\'s signed financial statements or subsequent settlement.' }
      ];
    } },

  { id:'kmp', ref:'L5.5', title:'Key management personnel',
    objective:'To identify balances and transactions with key management personnel and confirm they are disclosed separately from other related party categories, together with compensation by category (FRS 24 paras 17-18).',
    procedures:['Identified every party whose relationship or name indicates a director or other key management personnel.',
                'Summarised the closing balance and gross transactions with each and recorded whether the balance is disclosed separately in the draft financial statements.'],
    flag:(st, d) => d.totals.kmpGaps > 0,
    render(st, ctx) {
      const d = ctx.d, money = ctx.money, m0 = ctx.money0;
      const rows = d.kmp.map(k => ({ __key:k.key, party:k.party, rel:k.relationship || 'Not stated', ccy:k.currency, closeFunc:k.closeFunc, txnFunc:k.txnFunc, natures:k.natures.join('; '), status: k.disclosureGap ? 'Disclosure not confirmed' : k.material ? 'Disclosed' : 'Below threshold', __cls: k.disclosureGap ? 'flag' : '' }));
      return [
        { type:'controls', items:[{ key:'kmpThreshold', label:`Threshold for separate disclosure (${d.fcy})`, kind:'number', help:`Blank = trivial threshold (${m0(ctx.trivial)}). Currently ${m0(d.kmpThreshold)}.` }] },
        { type:'stats', items:[
          { label:'Key management personnel identified', value:d.kmp.length },
          { label:`Closing balances (${d.fcy})`, value:money(r2(d.kmp.reduce((s, k) => s + (k.closeFunc || 0), 0))) },
          { label:'Separate disclosure not confirmed', value:d.totals.kmpGaps, cls: d.totals.kmpGaps ? 'bad' : 'ok' } ] },
        { type:'table', title:'Balances and transactions with key management personnel', columns:[
          { key:'party', label:'Key management personnel', emphasis:true }, { key:'rel', label:'Relationship' }, { key:'ccy', label:'Ccy' },
          { key:'closeFunc', label:`Closing balance (${d.fcy})`, type:'num', sum:true }, { key:'txnFunc', label:`Gross transactions (${d.fcy})`, type:'num', sum:true },
          { key:'natures', label:'Nature', wrap:true },
          { key:'kmpDisclosed', label:'Disclosed separately (Y/N)', input:'select', options:yn },
          { key:'kmpComp', label:'Compensation disclosed by category (Y/N)', input:'select', options:yn },
          { key:'status', label:'Status', type:'chip', chipClass:v => /not confirmed/.test(v) ? 'bad' : v === 'Disclosed' ? 'ok' : 'grey' },
          { key:'kmpComment', label:'Comment', input:'text', wide:true } ], rows,
          emptyText:'No key management personnel identified among the related parties. Confirm with the register of directors.',
          footnote:'Balances above the threshold not confirmed as separately disclosed are raised as EX-RP-05. Loans to directors may also require disclosure under the Companies Act — consider separately.' }
      ];
    } },

  { id:'disclosure', ref:'L5.6', title:'Disclosure schedule',
    objective:'To prepare, by category of related party, the amounts of transactions and outstanding balances required by FRS 24 paras 18-19 for the financial statements note, and to agree the draft note to it.',
    procedures:['Grouped every related party under its concluded relationship and summarised transactions by nature and closing balances in the functional currency.',
                'Agreed the draft related party note to this schedule and recorded the reference.'],
    render(st, ctx) {
      const d = ctx.d, money = ctx.money;
      const rows = [];
      for (const g of d.disclosure) {
        for (const n of g.natures) rows.push({ __key: pkey(g.relationship + '|' + n.nature), relationship:g.relationship, item:n.nature, kind:'Transaction', amount:n.amount, __cls: /not stated/.test(g.relationship) ? 'flag' : '' });
        rows.push({ __key: pkey(g.relationship + '|closing'), relationship:g.relationship, item:`Balance outstanding at year end (${g.parties} part${g.parties === 1 ? 'y' : 'ies'})`, kind:'Balance', amount:g.closeFunc, __cls: /not stated/.test(g.relationship) ? 'flag' : '' });
      }
      return [
        { type:'stats', items:[
          { label:'Relationship categories', value:d.disclosure.length },
          { label:`Closing balances (${d.fcy})`, value:money(d.totals.closeFunc) },
          { label:'Parties with relationship not stated', value:d.totals.missingRel, cls: d.totals.missingRel ? 'bad' : 'ok' } ] },
        { type:'table', title:'Related party disclosure schedule — by category (FRS 24 para 19)', columns:[
          { key:'relationship', label:'Category of related party', emphasis:true, type:'chip', chipClass:relChip },
          { key:'item', label:'Nature of transaction / balance', wrap:true }, { key:'kind', label:'', type:'chip', chipClass:v => v === 'Balance' ? 'info' : 'grey' },
          { key:'amount', label:`Amount (${d.fcy})`, type:'num' },
          { key:'noteRef', label:'Draft note reference', input:'text' },
          { key:'agreedNote', label:'Agreed to draft note (Y/N)', input:'select', options:yn },
          { key:'discComment', label:'Comment', input:'text', wide:true } ], rows, totals:false,
          footnote:'Balances are as carried forward per the schedule. Terms and conditions, guarantees and provisions for doubtful debts (para 18(b)-(d)) are taken from L5.3 and the receivables file.' },
        { type:'checklist', store:'rpDisclosure', items:[
          { id:'D1', text:'Name of the parent and, if different, the ultimate controlling party disclosed (para 13)' },
          { id:'D2', text:'Key management personnel compensation disclosed in total and by category (para 17)' },
          { id:'D3', text:'Nature of the relationship, amount of transactions and outstanding balances disclosed by category (paras 18-19)' },
          { id:'D4', text:'Terms and conditions, security, and guarantees given or received disclosed (para 18(b))' },
          { id:'D5', text:'Provisions for doubtful debts and expense recognised for bad debts from related parties disclosed (para 18(c)-(d))' },
          { id:'D6', text:'Arm\'s length statement made only where substantiated (para 23)' } ], answers:['Y', 'N', 'n/a'] }
      ];
    } },

  { id:'conclusion', ref:'L5.9', title:'Exceptions & conclusion', kind:'conclusion' }
];

function suggestConclusion(st, ctx) {
  const d = ctx.d, ex = (st.exceptions || []).filter(e => e.disposition === 'open');
  return [
    `${d.totals.parties} related parties with closing balances of ${ctx.money(d.totals.closeFunc)} ${d.fcy} were identified from the client's schedule and the movement of each was recomputed from opening balance plus transactions${d.totals.castBreaks ? `; ${d.totals.castBreaks} did not cast` : ' and agreed'}.`,
    d.totals.missingRel ? `${d.totals.missingRel} part${d.totals.missingRel === 1 ? 'y has' : 'ies have'} no relationship stated.` : 'A relationship is recorded for every party.',
    d.totals.rateDivergent ? `${d.totals.rateDivergent} foreign currency balance(s) are translated at a rate other than the closing rate.` : '',
    d.totals.roundNoTerms ? `${d.totals.roundNoTerms} material round-sum advance(s) have no documented terms.` : '',
    d.kmp.length ? `${d.kmp.length} key management personnel balance(s) were identified${d.totals.kmpGaps ? `, of which ${d.totals.kmpGaps} are not yet confirmed as separately disclosed` : ' and are separately disclosed'}.` : '',
    ex.length ? `${ex.length} exception(s) remain open in the register.` : 'No exceptions remain open.',
    'Subject to the above, related party transactions and balances are completely identified, accurately recorded and adequately disclosed in accordance with FRS 24.'
  ].filter(Boolean).join(' ');
}

return {
  code:'RP', name:'Related Parties', group:'Other', accepts:'.xlsx,.xlsm,.csv',
  blurb:'The related party file: register, movement by party, translation check, terms and arm\'s length, confirmation control, key management personnel and the FRS 24 disclosure schedule — from one uploaded movement schedule.',
  objective:'To obtain sufficient appropriate audit evidence that related party relationships, transactions and balances are completely identified, appropriately accounted for and adequately disclosed in accordance with FRS 24 (ISA 550).',
  fields, tests, compute, pages, defaultConfig, STANDARD_COLUMNS, RELATIONSHIPS, NATURES,
  procedures: pages.flatMap(p => p.procedures || []),
  columns: STANDARD_COLUMNS, suggestConclusion
};
})();

Modules.register(RPModule);
