/* ==========================================================================
   eq.js -- Equity as an auditor actually works it.

   Working papers computed from the share capital and reserves schedule:
     O3    Lead schedule                  O3.3  Dividends
     O3.1  Share capital movement         O3.4  Statement of changes in equity proof
     O3.2  Reserves roll-forward          O3.5  Disclosure and compliance checklist

   The client schedule normally carries two blocks (share capital movement and
   reserves). Header detection picks one; the auditor enters the other through
   the input tables on O3.1 / O3.2, so every figure is still reproducible.
   ========================================================================== */

const EQModule = (() => {
const r2 = n => n == null || isNaN(n) ? null : Math.round(n * 100) / 100;
const num = v => (v === '' || v == null || isNaN(Number(v))) ? null : Number(v);
const n0 = v => num(v) || 0;
const YN = ['Y', 'N', 'n/a'];

/* ---------------------------------------------------------------- fields */
const fields = [
  { key:'description', label:'Description of movement', role:'key', type:'text', required:true,
    synonyms:['Description','Particulars','Movement','Details','Item','Narrative','Nature','Description of Movement','项目','说明'] },
  { key:'date', label:'Date of movement', type:'date',
    synonyms:['Date','Allotment Date','Effective Date','Date of Allotment','Date of Issue','Issue Date','Transaction Date','日期'] },
  { key:'shares', label:'Number of shares', type:'number',
    synonyms:['No. of Shares','Shares','Share Count','Units','Number of Shares','No of Shares','Quantity','Ordinary Shares','股数'] },
  { key:'amount', label:'Share capital amount', type:'number',
    synonyms:['Amount','Share Capital','Value','Consideration','Paid-up Capital','Amount Paid','Proceeds','Capital','金额','股本'] },
  { key:'retained', label:'Retained earnings', type:'number',
    synonyms:['Retained Earnings','Accumulated Profits','Accumulated Losses','Revenue Reserve','Retained Profits','Accumulated Profit/(Loss)','Accumulated Profit','未分配利润','留存收益'] },
  { key:'other_reserve', label:'Other reserve', type:'number',
    synonyms:['Translation Reserve','Other Reserve','Other Reserves','Foreign Currency Translation Reserve','FCTR','Capital Reserve','Revaluation Reserve','Statutory Reserve','Merger Reserve','其他储备','资本公积'] },
  { key:'total', label:'Total', type:'number',
    synonyms:['Total','Total Reserves','Total Equity','Total Shareholders\' Funds','合计'] }
];

const STANDARD_COLUMNS = [
  { key:'description', label:'Description' }, { key:'__kind', label:'Classified as' },
  { key:'date', label:'Date', type:'date' }, { key:'shares', label:'Shares', type:'int' },
  { key:'amount', label:'Share capital', type:'num' }, { key:'retained', label:'Retained earnings', type:'num' },
  { key:'other_reserve', label:'Other reserve', type:'num' }, { key:'total', label:'Total', type:'num' }
];

/* How a schedule line is read. Order matters: a "total comprehensive income" line must not be taken as a closing balance. */
function classify(desc) {
  const s = String(desc || '').toLowerCase();
  if (!s) return 'other';
  if (/dividend/.test(s)) return 'dividend';
  if (/total comprehensive|comprehensive income|profit for the|loss for the|net (profit|income|loss)|result for the/.test(s)) return 'tci';
  if (/brought forward|\bb\/f\b|\bbf\b|opening|beginning of|at 1 /.test(s)) return 'open';
  if (/carried forward|\bc\/f\b|\bcf\b|closing|end of|at 3[01] /.test(s)) return 'close';
  if (/buy[\s-]?back|redemption|redeem|cancel|repurchase|treasury/.test(s)) return 'buyback';
  if (/allot|issue|subscription|placement|rights|bonus|capitalisation|capitalization|conversion/.test(s)) return 'issue';
  if (/translation|exchange difference|other comprehensive|\boci\b|revaluation|fair value/.test(s)) return 'oci';
  if (/transfer/.test(s)) return 'transfer';
  return 'other';
}
const KIND_LABEL = { open:'Balance brought forward', close:'Balance carried forward', issue:'Shares issued / allotted', buyback:'Buy-back / cancellation',
  dividend:'Dividends', tci:'Total comprehensive income', oci:'Other comprehensive income', transfer:'Transfer between reserves', other:'Other movement' };

const DIV_ROWS = ['d1', 'd2', 'd3', 'd4', 'd5', 'd6'];
const SC_ROWS = [['bf', 'Balance brought forward'], ['issue', 'Shares allotted / issued in the year'], ['buyback', 'Shares bought back / cancelled'], ['other', 'Other movement'], ['cf', 'Balance carried forward per client']];

const CHECKLIST = [
  { id:'D1', group:'Share capital', text:'Number and class of shares issued and fully paid are disclosed and agree to the register of members / company registry extract' },
  { id:'D2', group:'Share capital', text:'Shares have no par value (Companies Act) or par value is disclosed where the jurisdiction retains it' },
  { id:'D3', group:'Share capital', text:'Rights, preferences and restrictions attaching to each class (dividends, voting, repayment of capital) are disclosed' },
  { id:'D4', group:'Share capital', text:'Allotments in the year were lodged with the registry within the statutory period and the return of allotment has been sighted' },
  { id:'D5', group:'Share capital', text:'Any buy-back met the solvency requirements and was made from distributable profits or capital as permitted, with directors\' solvency statement sighted' },
  { id:'D6', group:'Reserves', text:'Nature and purpose of each reserve within equity is described (translation, revaluation, statutory, merger)' },
  { id:'D7', group:'Reserves', text:'Restrictions on the distribution of reserves are disclosed (statutory reserves, revaluation surplus, capital reserves)' },
  { id:'D8', group:'Dividends', text:'Dividends declared and paid in the year are disclosed with the amount per share' },
  { id:'D9', group:'Dividends', text:'Dividends proposed or declared after the reporting date are disclosed and not recognised as a liability (FRS 10 para 12 / FRS 1 para 137)' },
  { id:'D10', group:'Capital management', text:'Objectives, policies and processes for managing capital, what is managed as capital and externally imposed requirements are disclosed (FRS 1 paras 134–136)' },
  { id:'D11', group:'Capital management', text:'Compliance with externally imposed capital requirements (banking covenants, regulatory capital) confirmed for the year' },
  { id:'D12', group:'Other', text:'No share options, warrants, convertible instruments or treasury shares outstanding; otherwise disclosed' },
  { id:'D13', group:'Other', text:'Non-controlling interests, where any, presented within equity separately from owners of the parent' }
];

const defaultConfig = () => ({
  castTol: 0.01, divTol: 0,
  /* Reserves roll-forward inputs (O3.2) */
  profit: null, oci: null, otherRE: null, otherOR: null,
  reOpenInput: null, orOpenInput: null,          // used only where the schedule carries no reserves block
  reCloseClient: null, orCloseClient: null,      // client's closing figures where the schedule's c/f line carries no value
  /* Trial balance and prior year (O3) */
  tbShareCapital: null, tbRetained: null, tbOther: null,
  pyShareCapital: null, pyRetained: null, pyOther: null, pyShares: null,
  /* Dividends (O3.3) */
  divCashAgreed: '', divWithholding: '',
  disclosure: {}
});

/* ========================================================== COMPUTE */
function compute(recs, cfg, eng) {
  const pm = eng.materiality?.pm || 0, trivial = eng.materiality?.trivial || 0;
  const live = recs.filter(r => !r.__excluded);
  for (const r of recs) {
    r.__kind = classify(r.description);
    r.__kindLabel = KIND_LABEL[r.__kind] || r.__kind;
    r.__displayKey = r.description || ('row ' + r.__srcRow);
  }
  const shareBlock = live.some(r => r.shares != null || (r.amount != null && r.retained == null && r.other_reserve == null));
  const reserveBlock = live.some(r => r.retained != null || r.other_reserve != null);
  const sum = (rows, k) => r2(rows.reduce((s, r) => s + (r[k] || 0), 0));
  const of = kind => live.filter(r => r.__kind === kind);

  /* ---- O3.1 share capital ------------------------------------------- */
  let sc;
  if (shareBlock) {
    const issues = of('issue'), buybacks = of('buyback'), others = live.filter(r => ['other', 'transfer'].includes(r.__kind) && (r.shares != null || r.amount != null));
    const closeRows = of('close');
    sc = { source:'schedule',
      open: { shares: sum(of('open'), 'shares'), amount: sum(of('open'), 'amount') },
      issue: { shares: sum(issues, 'shares'), amount: sum(issues, 'amount') },
      buyback: { shares: Math.abs(sum(buybacks, 'shares')), amount: Math.abs(sum(buybacks, 'amount')) },
      other: { shares: sum(others, 'shares'), amount: sum(others, 'amount') },
      closeClient: closeRows.length && (closeRows[0].shares != null || closeRows[0].amount != null) ? { shares: sum(closeRows, 'shares'), amount: sum(closeRows, 'amount') } : null,
      issues, buybacks, others };
  } else {
    const g = (k, row) => n0(cfg[`sc_${k}:${row}`]);
    const cfS = num(cfg['sc_shares:cf']), cfA = num(cfg['sc_amount:cf']);
    sc = { source:'input',
      open: { shares: g('shares', 'bf'), amount: g('amount', 'bf') },
      issue: { shares: g('shares', 'issue'), amount: g('amount', 'issue') },
      buyback: { shares: Math.abs(g('shares', 'buyback')), amount: Math.abs(g('amount', 'buyback')) },
      other: { shares: g('shares', 'other'), amount: g('amount', 'other') },
      closeClient: (cfS != null || cfA != null) ? { shares: cfS || 0, amount: cfA || 0 } : null,
      issues: [], buybacks: [], others: [] };
  }
  sc.close = { shares: r2(sc.open.shares + sc.issue.shares - sc.buyback.shares + sc.other.shares),
               amount: r2(sc.open.amount + sc.issue.amount - sc.buyback.amount + sc.other.amount) };
  sc.castDiff = sc.closeClient ? { shares: r2(sc.closeClient.shares - sc.close.shares), amount: r2(sc.closeClient.amount - sc.close.amount) } : null;
  sc.issuePrice = sc.issue.shares ? r2(sc.issue.amount / sc.issue.shares) : null;
  sc.buybackPrice = sc.buyback.shares ? r2(sc.buyback.amount / sc.buyback.shares) : null;
  sc.openPrice = sc.open.shares ? r2(sc.open.amount / sc.open.shares) : null;
  sc.pyShares = num(cfg.pyShares);
  sc.pySharesDiff = sc.pyShares != null ? r2(sc.open.shares - sc.pyShares) : null;

  /* ---- O3.3 dividends (auditor-entered register) --------------------- */
  const divRows = DIV_ROWS.map(k => ({ key:k, date: cfg['div_date:' + k] || '', resolution: cfg['div_resolution:' + k] || '', amount: num(cfg['div_amount:' + k]),
    paidDate: cfg['div_paid:' + k] || '', perShare: num(cfg['div_pershare:' + k]) })).filter(x => x.amount != null || x.date || x.resolution);
  const divDeclared = r2(divRows.reduce((s, x) => s + Math.abs(x.amount || 0), 0));
  const divSchedule = Math.abs(sum(of('dividend'), reserveBlock ? 'retained' : 'amount'));
  const dividends = divRows.length ? divDeclared : divSchedule;

  /* ---- O3.2 reserves ------------------------------------------------- */
  const openRows = of('open'), closeRows = of('close'), tciRows = of('tci'), ociRows = of('oci'), otherRows = live.filter(r => ['other', 'transfer'].includes(r.__kind));
  const re = {}, or = {};
  if (reserveBlock) {
    re.open = sum(openRows, 'retained'); or.open = sum(openRows, 'other_reserve');
    re.tciSchedule = tciRows.length ? sum(tciRows, 'retained') : null; or.tciSchedule = tciRows.length ? sum(tciRows, 'other_reserve') : null;
    re.otherSchedule = sum(otherRows, 'retained') + sum(ociRows, 'retained'); or.otherSchedule = sum(otherRows, 'other_reserve') + sum(ociRows, 'other_reserve');
    const cl = closeRows.find(r => r.retained != null || r.other_reserve != null);
    re.closeClient = cl ? sum(closeRows, 'retained') : num(cfg.reCloseClient);
    or.closeClient = cl ? sum(closeRows, 'other_reserve') : num(cfg.orCloseClient);
    re.closeSource = cl ? 'schedule' : (re.closeClient != null ? 'input' : null);
  } else {
    re.open = n0(cfg.reOpenInput); or.open = n0(cfg.orOpenInput);
    re.tciSchedule = null; or.tciSchedule = null; re.otherSchedule = 0; or.otherSchedule = 0;
    re.closeClient = num(cfg.reCloseClient); or.closeClient = num(cfg.orCloseClient);
    re.closeSource = re.closeClient != null ? 'input' : null;
  }
  const profit = num(cfg.profit), oci = num(cfg.oci);
  re.tci = profit != null ? profit : (re.tciSchedule ?? 0);
  or.tci = oci != null ? oci : (or.tciSchedule ?? 0);
  re.tciSource = profit != null ? 'P&L input' : (re.tciSchedule != null ? 'schedule' : 'not entered');
  re.other = r2(n0(cfg.otherRE) + (re.otherSchedule || 0)); or.other = r2(n0(cfg.otherOR) + (or.otherSchedule || 0));
  re.dividends = dividends; or.dividends = 0;
  re.close = r2(re.open + re.tci - re.dividends + re.other); or.close = r2(or.open + or.tci + or.other);
  re.diff = re.closeClient != null ? r2(re.closeClient - re.close) : null;
  or.diff = or.closeClient != null ? r2(or.closeClient - or.close) : null;
  const reserves = { re, or, source: reserveBlock ? 'schedule' : 'input',
    totalOpen: r2(re.open + or.open), totalTci: r2(re.tci + or.tci), totalClose: r2(re.close + or.close),
    totalCloseClient: (re.closeClient != null || or.closeClient != null) ? r2(n0(re.closeClient) + n0(or.closeClient)) : null };
  reserves.totalDiff = reserves.totalCloseClient != null ? r2(reserves.totalCloseClient - reserves.totalClose) : null;

  /* distributable profits test: opening retained earnings plus profit for the year */
  const distributable = r2(re.open + (profit != null ? profit : (re.tciSchedule ?? 0)));
  const divExcess = r2(Math.max(0, dividends - Math.max(0, distributable)));
  let running = re.open + (profit != null ? profit : (re.tciSchedule ?? 0));
  const divDetail = divRows.map(x => { running -= Math.abs(x.amount || 0); return { ...x, available: r2(running), impliedPerShare: sc.close.shares ? r2(Math.abs(x.amount || 0) / sc.close.shares) : null,
    perShareDiff: x.perShare != null && sc.close.shares ? r2(x.perShare - Math.abs(x.amount || 0) / sc.close.shares) : null, exceeds: running < -0.005 }; });
  const divs = { rows: divDetail, declared: divDeclared, schedule: divSchedule, used: dividends, distributable, excess: divExcess,
    scheduleDiff: divRows.length ? r2(divDeclared - divSchedule) : null, cashAgreed: cfg.divCashAgreed || '' };

  /* ---- O3 lead ------------------------------------------------------- */
  const leadRow = (key, label, audit, tb, py) => { const t = num(tb), p = num(py); return { key, label, audit, tb: t, diff: t != null ? r2(audit - t) : null,
    py: p, movement: p != null ? r2(audit - p) : null, movementPct: p ? r2((audit - p) / Math.abs(p) * 100) : null }; };
  const lead = [
    leadRow('sc', 'Share capital', sc.close.amount, cfg.tbShareCapital, cfg.pyShareCapital),
    leadRow('re', 'Retained earnings / (accumulated losses)', re.close, cfg.tbRetained, cfg.pyRetained),
    leadRow('or', 'Other reserves', or.close, cfg.tbOther, cfg.pyOther)
  ];
  const anyTB = lead.some(l => l.tb != null), anyPY = lead.some(l => l.py != null);
  lead.push({ key:'total', label:'TOTAL EQUITY', audit: r2(lead.reduce((s, l) => s + l.audit, 0)),
    tb: anyTB ? r2(lead.reduce((s, l) => s + n0(l.tb), 0)) : null, diff: anyTB ? r2(lead.reduce((s, l) => s + n0(l.diff), 0)) : null,
    py: anyPY ? r2(lead.reduce((s, l) => s + n0(l.py), 0)) : null, movement: anyPY ? r2(lead.reduce((s, l) => s + n0(l.movement), 0)) : null, movementPct: null });

  /* ---- O3.4 statement of changes in equity ---------------------------- */
  const line = (label, scv, rev, orv) => ({ label, sc: r2(scv), re: r2(rev), or: r2(orv), total: r2((scv || 0) + (rev || 0) + (orv || 0)) });
  const socie = [
    line('Balance at beginning of year', sc.open.amount, re.open, or.open),
    line('Profit / (loss) for the year', 0, re.tci, 0),
    line('Other comprehensive income', 0, 0, or.tci),
    line('Total comprehensive income', 0, re.tci, or.tci),
    line('Dividends', 0, -dividends, 0),
    line('Issue of shares', sc.issue.amount, 0, 0),
    line('Buy-back / cancellation of shares', -sc.buyback.amount, 0, 0),
    line('Other movements / transfers', sc.other.amount, re.other, or.other),
    line('Balance at end of year', sc.close.amount, re.close, or.close)
  ];
  const mv = socie.slice(1).filter(l => !/^Total comprehensive|^Balance at end/.test(l.label));
  const crossCast = { sc: r2(socie[0].sc + mv.reduce((s, l) => s + l.sc, 0) - socie[8].sc), re: r2(socie[0].re + mv.reduce((s, l) => s + l.re, 0) - socie[8].re),
    or: r2(socie[0].or + mv.reduce((s, l) => s + l.or, 0) - socie[8].or) };
  crossCast.total = r2(socie[8].total - lead[3].audit);

  return { shareBlock, reserveBlock, sc, reserves, divs, lead, socie, crossCast, pm, trivial,
    totalEquity: lead[3].audit, kinds: live.map(r => r.__kind) };
}

/* ============================================================== TESTS */
const tests = [
  { id:'EX-EQ-01', scope:'population', label:'Reserves roll-forward does not agree to the client\'s closing balance', basis:'O3.2',
    fn:(recs,cfg,eng,d) => { const out = [];
      if (d.reserves.re.diff != null && Math.abs(d.reserves.re.diff) > cfg.castTol) out.push({ key:'Retained earnings', expected:d.reserves.re.close, actual:d.reserves.re.closeClient, difference:d.reserves.re.diff,
        detail:`Opening ${d.reserves.re.open.toFixed(2)} + total comprehensive income ${d.reserves.re.tci.toFixed(2)} − dividends ${d.reserves.re.dividends.toFixed(2)} + other ${d.reserves.re.other.toFixed(2)}` });
      if (d.reserves.or.diff != null && Math.abs(d.reserves.or.diff) > cfg.castTol) out.push({ key:'Other reserves', expected:d.reserves.or.close, actual:d.reserves.or.closeClient, difference:d.reserves.or.diff,
        detail:`Opening ${d.reserves.or.open.toFixed(2)} + other comprehensive income ${d.reserves.or.tci.toFixed(2)} + other ${d.reserves.or.other.toFixed(2)}` });
      return out.length ? out : false; } },
  { id:'EX-EQ-02', scope:'population', label:'Dividends exceed distributable reserves', basis:'O3.3', severity:'above-trivial',
    fn:(recs,cfg,eng,d) => d.divs.excess > (cfg.divTol || 0) && { key:'Dividends', expected:Math.max(0, d.divs.distributable), actual:d.divs.used, difference:d.divs.excess,
      detail:`Distributable profits (opening retained earnings plus profit for the year) ${d.divs.distributable.toFixed(2)}; dividends ${d.divs.used.toFixed(2)}. Companies Act permits dividends only out of profits.` } },
  { id:'EX-EQ-03', scope:'population', label:'Share capital movement does not cast to the closing balance', basis:'O3.1',
    fn:(recs,cfg,eng,d) => { const c = d.sc.castDiff; if (!c) return false; const out = [];
      if (Math.abs(c.amount) > cfg.castTol) out.push({ key:'Share capital — amount', expected:d.sc.close.amount, actual:d.sc.closeClient.amount, difference:c.amount, detail:'Brought forward + allotments − buy-backs + other ≠ carried forward per client' });
      if (Math.abs(c.shares) > 0.5) out.push({ key:'Share capital — number of shares', expected:d.sc.close.shares, actual:d.sc.closeClient.shares, difference:c.shares, detail:'Share count does not roll forward' });
      return out.length ? out : false; } },
  { id:'EX-EQ-04', label:'Allotment or buy-back not supported by a resolution, register entry or bank receipt', basis:'O3.1', severity:'above-trivial',
    fn:(r) => { if (!['issue', 'buyback'].includes(r.__kind)) return false; const v = (r.__wp || {}).sharecap || {};
      const missing = [['register', 'register / registry extract'], ['resolution', 'resolution'], ['bank', 'consideration to bank']].filter(([k]) => v[k] === 'N').map(([, l]) => l);
      return missing.length && { actual: r.amount, amount: r.amount, cell: r['__cell_amount'], detail:'Answered No: ' + missing.join(', ') }; } },
  { id:'EX-EQ-05', scope:'population', label:'Dividend register does not agree to dividends per the schedule', basis:'O3.3',
    fn:(recs,cfg,eng,d) => d.divs.scheduleDiff != null && Math.abs(d.divs.scheduleDiff) > cfg.castTol &&
      { key:'Dividends', expected:d.divs.schedule, actual:d.divs.declared, difference:d.divs.scheduleDiff, detail:'Dividends per the O3.3 register against the dividends line of the reserves schedule' } },
  { id:'EX-EQ-06', scope:'population', label:'Opening number of shares does not agree to the prior year', basis:'O3.1', severity:'informational',
    fn:(recs,cfg,eng,d) => d.sc.pySharesDiff != null && Math.abs(d.sc.pySharesDiff) > 0.5 && { key:'Shares brought forward', expected:d.sc.pyShares, actual:d.sc.open.shares, difference:d.sc.pySharesDiff } },
  { id:'EX-EQ-07', scope:'population', label:'Statement of changes in equity does not cross-cast', basis:'O3.4',
    fn:(recs,cfg,eng,d) => Math.abs(d.crossCast.total) > cfg.castTol && { key:'Total equity', expected:d.totalEquity, actual:d.socie[8].total, difference:d.crossCast.total } },
  { id:'EX-TIE-01', scope:'population', label:'Equity per the schedule does not agree to the trial balance', basis:'O3',
    fn:(recs,cfg,eng,d) => d.lead.filter(l => l.key !== 'total' && l.diff != null && Math.abs(l.diff) > cfg.castTol)
      .map(l => ({ key:l.label, expected:l.tb, actual:l.audit, difference:l.diff, detail:'Closing balance per audit against the trial balance caption entered on O3' })) }
];

/* ============================================================== PAGES */
const chipYN = v => v === 'Y' ? 'ok' : v === 'N' ? 'bad' : 'grey';
const pages = [
  { id:'source',  ref:'O3.0',  title:'Source data',     kind:'source' },
  { id:'cleaned', ref:'O3.0a', title:'Cleaned listing', kind:'cleaned' },
  { id:'mapping', ref:'O3.0b', title:'Column mapping',  kind:'mapping' },

  { id:'lead', ref:'O3', title:'Lead schedule',
    objective:'To agree share capital and each reserve per the client\'s schedule to the trial balance and to the prior year audited financial statements, and to explain the movements in the year.',
    procedures:['Agreed share capital, retained earnings and other reserves per the schedule to the trial balance.',
                'Compared closing balances to the prior year audited financial statements and reconciled the movement to the statement of changes in equity (O3.4).'],
    flag:(st, d) => d.lead.some(l => l.diff != null && Math.abs(l.diff) > (st.config.castTol || 0)),
    render(st, ctx) {
      const d = ctx.d, cfg = ctx.cfg;
      return [
        { type:'note', html:`<b>Enter the trial balance and prior year figures.</b> Closing balances per audit come from O3.1 (share capital) and O3.2 (reserves). Schedule read: ${d.shareBlock ? 'share capital block' : ''}${d.shareBlock && d.reserveBlock ? ' and ' : ''}${d.reserveBlock ? 'reserves block' : ''}${!d.shareBlock && !d.reserveBlock ? 'no recognisable block — enter both through O3.1 and O3.2' : ''}.` },
        { type:'controls', items:[
          { key:'tbShareCapital', label:'Share capital per TB', kind:'number' }, { key:'tbRetained', label:'Retained earnings per TB', kind:'number', help:'Credit balances positive; accumulated losses negative' },
          { key:'tbOther', label:'Other reserves per TB', kind:'number' },
          { key:'pyShareCapital', label:'Share capital — prior year audited', kind:'number' }, { key:'pyRetained', label:'Retained earnings — prior year audited', kind:'number' },
          { key:'pyOther', label:'Other reserves — prior year audited', kind:'number' } ] },
        { type:'table', title:'Equity per audit, per trial balance and prior year', columns:[
          { key:'label', label:'Component', emphasis:true }, { key:'audit', label:'Per audit (closing)', type:'num' }, { key:'tb', label:'Per trial balance', type:'num' },
          { key:'diff', label:'Difference', type:'num', flag:v => v != null && Math.abs(v) > cfg.castTol }, { key:'py', label:'Prior year audited', type:'num' },
          { key:'movement', label:'Movement', type:'num' }, { key:'movementPct', label:'Movement %', type:'num', dp:1 } ],
          rows: d.lead.map(l => ({ ...l, __cls: l.key === 'total' ? 'em' : '' })), totals:false,
          footnote:'Movements in retained earnings should equal total comprehensive income less dividends; movements in share capital should equal allotments less buy-backs. See O3.4.' },
        { type:'stats', items:[
          { label:'Total equity per audit', value: ctx.money(d.totalEquity) },
          { label:'Agreed to TB', value: d.lead[3].tb == null ? 'TB not entered' : (Math.abs(d.lead[3].diff) <= cfg.castTol ? 'Yes' : 'Difference ' + ctx.money(d.lead[3].diff)), cls: d.lead[3].tb == null ? 'warn' : (Math.abs(d.lead[3].diff) <= cfg.castTol ? 'ok' : 'bad') },
          { label:'Movement vs prior year', value: d.lead[3].movement == null ? 'PY not entered' : ctx.money(d.lead[3].movement), cls: d.lead[3].movement == null ? 'warn' : '' } ] }
      ];
    } },

  { id:'sharecap', ref:'O3.1', title:'Share capital movement',
    objective:'To verify that shares in issue at the year end, and every allotment or buy-back in the year, are authorised, recorded at the consideration received and agreed to the register of members.',
    procedures:['Rolled forward the number of shares and the share capital amount from the opening balance through allotments and buy-backs to the closing balance, and agreed the closing position to the register of members / company registry extract.',
                'For each allotment, sighted the board and shareholder resolutions and agreed the consideration to the bank statement.',
                'Recomputed the implied price per share on each movement and considered its reasonableness.'],
    flag:(st, d) => d.sc.castDiff && (Math.abs(d.sc.castDiff.amount) > (st.config.castTol || 0) || Math.abs(d.sc.castDiff.shares) > 0.5),
    render(st, ctx) {
      const d = ctx.d, sc = d.sc, cfg = ctx.cfg;
      const out = [];
      if (sc.source === 'input') {
        out.push({ type:'note', tone:'warn', html:'<b>The schedule read carries the reserves block only.</b> Enter the share capital movement from the client\'s share capital block below; the roll-forward, price per share and cast are computed from these entries.' });
        out.push({ type:'table', title:'Share capital movement — entered from the client schedule', columns:[
          { key:'label', label:'Movement', emphasis:true }, { key:'sc_date', label:'Date', input:'date' }, { key:'sc_shares', label:'Number of shares', input:'number' }, { key:'sc_amount', label:'Amount', input:'number' } ],
          rows: SC_ROWS.map(([k, label]) => ({ __key:k, label })), totals:false, footnote:'Enter buy-backs as positive figures; they are deducted in the roll-forward.' });
      } else {
        out.push({ type:'table', title:'Movements per the schedule — vouching', columns:[
          { key:'description', label:'Description' }, { key:'__kindLabel', label:'Classified as' }, { key:'date', label:'Date', type:'date' }, { key:'shares', label:'Shares', type:'int' }, { key:'amount', label:'Amount', type:'num' },
          { key:'__price', label:'Price per share', type:'num', dp:4 },
          { key:'register', label:'Register / registry extract agreed', input:'select', options:YN }, { key:'resolution', label:'Resolution sighted', input:'select', options:YN },
          { key:'bank', label:'Consideration to bank', input:'select', options:YN }, { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: ctx.recs.filter(r => r.shares != null || r.amount != null).map(r => ({ ...r, __rec:r, __price: r.shares ? r2((r.amount || 0) / r.shares) : null })),
          totals:false, emptyText:'No share capital lines in the schedule.' });
      }
      const rows = [
        { label:'Balance brought forward', shares:sc.open.shares, amount:sc.open.amount, price:sc.openPrice },
        { label:'Add: shares allotted / issued', shares:sc.issue.shares, amount:sc.issue.amount, price:sc.issuePrice },
        { label:'Less: shares bought back / cancelled', shares:-sc.buyback.shares, amount:-sc.buyback.amount, price:sc.buybackPrice },
        { label:'Other movements', shares:sc.other.shares, amount:sc.other.amount, price:null },
        { label:'Balance carried forward per audit', shares:sc.close.shares, amount:sc.close.amount, price: sc.close.shares ? r2(sc.close.amount / sc.close.shares) : null, __cls:'em' },
        { label:'Balance carried forward per client', shares:sc.closeClient ? sc.closeClient.shares : null, amount:sc.closeClient ? sc.closeClient.amount : null, price:null },
        { label:'Difference', shares:sc.castDiff ? sc.castDiff.shares : null, amount:sc.castDiff ? sc.castDiff.amount : null, price:null, __cls:'em' } ];
      out.push({ type:'table', title:'Roll-forward per audit', columns:[
        { key:'label', label:'', emphasis:true }, { key:'shares', label:'Number of shares', type:'int' }, { key:'amount', label:'Amount', type:'num', flag:(v, row) => row.label === 'Difference' && v != null && Math.abs(v) > cfg.castTol },
        { key:'price', label:'Implied price per share', type:'num', dp:4 } ], rows, totals:false,
        footnote: sc.closeClient ? 'The client\'s carried-forward line is compared to the recomputed closing balance.' : 'The client schedule carries no closing value (a formula with no cached result) — enter it on the input rows above or agree the recomputed closing balance directly to the registry extract.' });
      out.push({ type:'controls', items:[{ key:'pyShares', label:'Shares in issue per prior year audited financial statements', kind:'number', help:'Opening shares are agreed to this figure' }] });
      out.push({ type:'stats', items:[
        { label:'Shares in issue at year end', value: sc.close.shares.toLocaleString() }, { label:'Share capital at year end', value: ctx.money(sc.close.amount) },
        { label:'Allotments in year', value: sc.issue.shares ? `${sc.issue.shares.toLocaleString()} shares · ${ctx.money(sc.issue.amount)}` : 'None' },
        { label:'Cast', value: sc.castDiff ? (Math.abs(sc.castDiff.amount) <= cfg.castTol && Math.abs(sc.castDiff.shares) <= 0.5 ? 'Agrees' : 'Does not cast') : 'Client c/f not available', cls: sc.castDiff ? (Math.abs(sc.castDiff.amount) <= cfg.castTol ? 'ok' : 'bad') : 'warn' },
        { label:'Opening shares vs prior year', value: sc.pySharesDiff == null ? 'PY not entered' : (Math.abs(sc.pySharesDiff) <= 0.5 ? 'Agrees' : 'Difference ' + sc.pySharesDiff), cls: sc.pySharesDiff == null ? 'warn' : (Math.abs(sc.pySharesDiff) <= 0.5 ? 'ok' : 'bad') } ] });
      return out;
    } },

  { id:'reserves', ref:'O3.2', title:'Reserves roll-forward',
    objective:'To recompute the movement in retained earnings and other reserves from the audited opening balances, total comprehensive income and dividends, and to agree the result to the client\'s closing balances.',
    procedures:['Agreed opening reserves to the prior year audited financial statements.',
                'Entered profit for the year and other comprehensive income per the audited statement of comprehensive income and rolled the reserves forward, deducting dividends per O3.3.',
                'Compared the recomputed closing reserves to the client\'s schedule and investigated any difference.'],
    flag:(st, d) => (d.reserves.re.diff != null && Math.abs(d.reserves.re.diff) > (st.config.castTol || 0)) || (d.reserves.or.diff != null && Math.abs(d.reserves.or.diff) > (st.config.castTol || 0)),
    render(st, ctx) {
      const d = ctx.d, R = d.reserves, cfg = ctx.cfg;
      const items = [{ key:'profit', label:'Profit / (loss) for the year per audited P&L', kind:'number' }, { key:'oci', label:'Other comprehensive income for the year', kind:'number', help:'Translation differences, revaluation and other items taken to other reserves' },
        { key:'otherRE', label:'Other movements in retained earnings', kind:'number', help:'Transfers to statutory reserve, prior year adjustments (enter with sign)' }, { key:'otherOR', label:'Other movements in other reserves', kind:'number' }];
      if (R.source === 'input') items.unshift({ key:'reOpenInput', label:'Retained earnings brought forward', kind:'number' }, { key:'orOpenInput', label:'Other reserves brought forward', kind:'number' });
      if (R.re.closeSource !== 'schedule') items.push({ key:'reCloseClient', label:'Retained earnings carried forward per client', kind:'number' }, { key:'orCloseClient', label:'Other reserves carried forward per client', kind:'number' });
      const rows = [
        { label:'Balance brought forward', re:R.re.open, or:R.or.open, total:R.totalOpen },
        { label:'Total comprehensive income for the year' + (R.re.tciSource === 'schedule' ? ' (per schedule)' : R.re.tciSource === 'P&L input' ? ' (per audited P&L)' : ' — not entered'), re:R.re.tci, or:R.or.tci, total:R.totalTci },
        { label:'Dividends (O3.3)', re:-R.re.dividends, or:0, total:-R.re.dividends },
        { label:'Other movements', re:R.re.other, or:R.or.other, total:r2(R.re.other + R.or.other) },
        { label:'Balance carried forward per audit', re:R.re.close, or:R.or.close, total:R.totalClose, __cls:'em' },
        { label:'Balance carried forward per client', re:R.re.closeClient, or:R.or.closeClient, total:R.totalCloseClient },
        { label:'Difference', re:R.re.diff, or:R.or.diff, total:R.totalDiff, __cls:'em' } ];
      return [
        { type:'note', html:`<b>Source:</b> ${R.source === 'schedule' ? 'opening balances and dividends read from the reserves block of the schedule' : 'no reserves block in the schedule read — enter the opening balances below'}. The client\'s total comprehensive income line is a subtotal and is held out of the population; enter profit and other comprehensive income from the audited statement of comprehensive income so the roll-forward is independent of the client\'s arithmetic.` },
        { type:'controls', items },
        { type:'table', title:'Roll-forward', columns:[
          { key:'label', label:'', emphasis:true }, { key:'re', label:'Retained earnings', type:'num', flag:(v, row) => row.label === 'Difference' && v != null && Math.abs(v) > cfg.castTol },
          { key:'or', label:'Other reserves', type:'num', flag:(v, row) => row.label === 'Difference' && v != null && Math.abs(v) > cfg.castTol }, { key:'total', label:'Total reserves', type:'num' } ], rows, totals:false },
        { type:'stats', items:[
          { label:'Closing reserves per audit', value: ctx.money(R.totalClose) },
          { label:'Retained earnings', value: R.re.diff == null ? 'Client c/f not available' : (Math.abs(R.re.diff) <= cfg.castTol ? 'Agrees' : 'Difference ' + ctx.money(R.re.diff)), cls: R.re.diff == null ? 'warn' : (Math.abs(R.re.diff) <= cfg.castTol ? 'ok' : 'bad') },
          { label:'Other reserves', value: R.or.diff == null ? 'Client c/f not available' : (Math.abs(R.or.diff) <= cfg.castTol ? 'Agrees' : 'Difference ' + ctx.money(R.or.diff)), cls: R.or.diff == null ? 'warn' : (Math.abs(R.or.diff) <= cfg.castTol ? 'ok' : 'bad') },
          { label:'Profit for the year', value: R.re.tciSource === 'not entered' ? 'Not entered' : ctx.money(R.re.tci), cls: R.re.tciSource === 'not entered' ? 'warn' : '' } ] }
      ];
    } },

  { id:'dividends', ref:'O3.3', title:'Dividends',
    objective:'To verify that dividends declared and paid in the year were authorised, were paid out of profits available for distribution, and are correctly recorded and disclosed.',
    procedures:['Listed every dividend declared in the year from board minutes and dividend resolutions, with the amount, record date and payment date.',
                'Tested that each dividend was covered by profits available for distribution at the date of declaration.',
                'Agreed dividends paid to the bank statement and the dividend per share to the number of shares in issue.'],
    flag:(st, d) => d.divs.excess > 0,
    render(st, ctx) {
      const d = ctx.d, D = d.divs, cfg = ctx.cfg;
      const byKey = Object.fromEntries(D.rows.map(x => [x.key, x]));
      return [
        { type:'note', html:`<b>Distributable profits</b> at the start of the year plus profit for the year: <b>${ctx.money(D.distributable)}</b>. Dividends per the schedule: ${ctx.money(D.schedule)}. Enter each dividend below; the running balance shows the profits remaining after each distribution.` },
        { type:'table', title:'Dividend register', columns:[
          { key:'label', label:'#' }, { key:'div_date', label:'Date declared', input:'date' }, { key:'div_resolution', label:'Resolution sighted', input:'select', options:YN },
          { key:'div_amount', label:'Amount', input:'number' }, { key:'div_paid', label:'Date paid', input:'date' }, { key:'div_pershare', label:'Per share (per resolution)', input:'number' },
          { key:'implied', label:'Per share (recomputed)', type:'num', dp:4 }, { key:'available', label:'Profits remaining after', type:'num', flag:v => v != null && v < -0.005 },
          { key:'status', label:'Status', type:'chip', chipClass:v => v === 'Covered' ? 'ok' : v === 'Exceeds profits' ? 'bad' : 'grey' } ],
          rows: DIV_ROWS.map((k, i) => { const x = byKey[k]; return { __key:k, label: i + 1, implied: x ? x.impliedPerShare : null, available: x ? x.available : null, status: x ? (x.exceeds ? 'Exceeds profits' : 'Covered') : '' }; }),
          totals:false, footnote:`Recomputed per share uses ${d.sc.close.shares.toLocaleString()} shares in issue at year end (O3.1).` },
        { type:'controls', items:[{ key:'divCashAgreed', label:'Dividends paid agreed to bank statement / cash flow statement', kind:'select', options:[['', '—'], ['Y', 'Yes'], ['N', 'No'], ['n/a', 'No dividends paid']] },
          { key:'divWithholding', label:'Withholding tax considered for non-resident shareholders', kind:'select', options:[['', '—'], ['Y', 'Yes'], ['N', 'No'], ['n/a', 'Not applicable']] }] },
        { type:'stats', items:[
          { label:'Dividends per register', value: ctx.money(D.declared) }, { label:'Dividends per schedule', value: ctx.money(D.schedule) },
          { label:'Register vs schedule', value: D.scheduleDiff == null ? 'Register not completed' : (Math.abs(D.scheduleDiff) <= cfg.castTol ? 'Agrees' : 'Difference ' + ctx.money(D.scheduleDiff)), cls: D.scheduleDiff == null ? 'warn' : (Math.abs(D.scheduleDiff) <= cfg.castTol ? 'ok' : 'bad') },
          { label:'Excess over distributable profits', value: D.excess > 0 ? ctx.money(D.excess) : 'None', cls: D.excess > 0 ? 'bad' : 'ok' } ] }
      ];
    } },

  { id:'socie', ref:'O3.4', title:'Statement of changes in equity proof',
    objective:'To prove that the statement of changes in equity casts and cross-casts, and that every component reconciles from the audited opening balance to the closing balance.',
    procedures:['Built the statement of changes in equity from the audited components on O3.1 to O3.3.',
                'Cast each component column from opening to closing and cross-cast every row to the total column.'],
    flag:(st, d) => Math.abs(d.crossCast.total) > (st.config.castTol || 0),
    render(st, ctx) {
      const d = ctx.d, cfg = ctx.cfg;
      return [
        { type:'table', title:'Statement of changes in equity', columns:[
          { key:'label', label:'', emphasis:true }, { key:'sc', label:'Share capital', type:'num' }, { key:'re', label:'Retained earnings', type:'num' }, { key:'or', label:'Other reserves', type:'num' }, { key:'total', label:'Total equity', type:'num', emphasis:true } ],
          rows: d.socie.map(l => ({ ...l, __cls: /^Balance|^Total comprehensive/.test(l.label) ? 'em' : '' })), totals:false },
        { type:'table', title:'Cast and cross-cast checks', columns:[{ key:'label', label:'Check' }, { key:'value', label:'Difference', type:'num', flag:v => v != null && Math.abs(v) > cfg.castTol }, { key:'result', label:'Result', type:'chip', chipClass:v => v === 'Casts' ? 'ok' : 'bad' }],
          rows: [['Share capital column', d.crossCast.sc], ['Retained earnings column', d.crossCast.re], ['Other reserves column', d.crossCast.or], ['Closing total vs lead schedule', d.crossCast.total]]
            .map(([label, value]) => ({ label, value, result: Math.abs(value || 0) <= cfg.castTol ? 'Casts' : 'Does not cast' })), totals:false }
      ];
    } },

  { id:'disclosure', ref:'O3.5', title:'Disclosure and compliance checklist',
    objective:'To confirm that share capital, reserves, dividends and capital management are disclosed in accordance with the applicable financial reporting framework and the Companies Act.',
    procedures:['Completed the disclosure checklist against the draft financial statements, the register of members and the registry extract.',
                'Considered events after the reporting date affecting equity (dividends proposed, allotments, buy-backs).'],
    render(st, ctx) {
      return [
        { type:'note', html:'Answer each item <b>Y</b> where the disclosure is present and agreed, <b>N</b> where it is missing or incorrect (raise in the exceptions and conclusion), <b>n/a</b> where the item does not apply. Record the evidence sighted.' },
        { type:'checklist', store:'disclosure', items: CHECKLIST.map(c => ({ id:c.id, text:`[${c.group}] ${c.text}` })) }
      ];
    } },

  { id:'conclusion', ref:'O3.9', title:'Exceptions & conclusion', kind:'conclusion' }
];

return {
  code:'EQ', name:'Equity', group:'Liabilities & equity', accepts:'.xlsx,.xlsm,.csv',
  blurb:'The equity audit file: lead, share capital movement, reserves roll-forward, dividends, statement of changes in equity proof and disclosure checklist — from the share capital and reserves schedule.',
  objective:'To obtain sufficient appropriate audit evidence that share capital and reserves are completely and accurately recorded, that movements in the year were authorised and made in accordance with the constitution and the Companies Act, and that equity is appropriately presented and disclosed.',
  fields, tests, compute, pages, defaultConfig, STANDARD_COLUMNS, CHECKLIST, classify,
  procedures: pages.flatMap(p => p.procedures || []),
  columns: STANDARD_COLUMNS,
  suggestConclusion(st, ctx) {
    const d = st.derived || {}; const ex = (st.exceptions || []).filter(e => e.disposition === 'open');
    return `Share capital of ${ctx.money(d.sc?.close?.amount)} (${(d.sc?.close?.shares || 0).toLocaleString()} shares) and reserves of ${ctx.money(d.reserves?.totalClose)} were agreed to the trial balance and rolled forward from the prior year audited balances. ` +
      `Allotments and buy-backs in the year were vouched to resolutions, the register of members and bank receipts. Dividends of ${ctx.money(d.divs?.used)} were ${d.divs?.excess > 0 ? 'NOT ' : ''}covered by distributable profits. ` +
      (ex.length ? `${ex.length} exception(s) remain open and are summarised on O3.9.` : 'No exceptions remain open.') + ' In our opinion equity is fairly stated and appropriately disclosed.';
  }
};
})();
Modules.register(EQModule);
