/* ==========================================================================
   exp.js -- Operating expenses as an auditor actually works it.

   One uploaded expense listing (purchase invoices / vouchers by account) feeds:
     Z3    Lead schedule by account         Z3.4  Capital vs revenue screen
     Z3.1  Monthly analysis by account      Z3.5  Related-party and round-sum flags
     Z3.2  Targeted testing and vouching    Z3.6  Legal and professional fees (100%)
     Z3.3  Cut-off
   ========================================================================== */

const EXPModule = (() => {
const r2 = n => n == null || isNaN(n) ? null : Math.round(n * 100) / 100;
const days = (a, b) => (a && b) ? Math.round((a - b) / 86400000) : null;
const num = v => (v === '' || v == null || isNaN(Number(v))) ? null : Number(v);
const inp = (cfg, key, k) => num(cfg[key + ':' + k]);
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const isoMonth = d => d ? `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}` : null;
const monthLabel = k => `${MONTHS[Number(k.slice(5, 7)) - 1]} ${k.slice(0, 2) === '20' ? k.slice(2, 4) : k.slice(0, 4)}`;

function mulberry32(seed) {
  let a = (seed >>> 0) || 1;
  return () => {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function sampleN(items, n, seed) {
  const rnd = mulberry32(seed);
  const pool = items.slice();
  const out = [];
  while (out.length < n && pool.length) out.push(pool.splice(Math.floor(rnd() * pool.length), 1)[0]);
  return out;
}

const RP_RE = /related\s*part|director|shareholder|inter-?compan|holding|associate|subsidiar|\bR\/?P\b|affiliate|group\s+co|parent\s+co|fellow|管理层|关联/i;
/* Accounts screened for capital items: repairs, equipment and the like — but never depreciation / amortisation
   charges or running, hire and rental costs, whose names merely mention the asset class. */
const DEFAULT_CAP = '^(?!.*(depreciation|amortisation|amortization|impairment|running|hire|rental|lease|fuel|insurance))(?=.*(repair|maintenance|equipment|renovation|computer|furniture|fitting|tools|software|hardware|upgrade|installation|machinery|vehicle|office\\s+equipment|small\\s+assets|improvement))';
const DEFAULT_LEGAL = 'legal|professional|consult|advisory|solicitor|lawyer|attorney|litigation|secretarial|tax\\s+agent|audit';

/* ---------------------------------------------------------------- fields */
const fields = [
  { key:'doc_no', label:'Document number', type:'text', required:true, role:'key',
    synonyms:['Invoice No','Doc No','Voucher No','Ref','Reference','Invoice Number','Document No','Bill No','Supplier Inv No','PV No','Payment Voucher','Inv No','Inv No.','Voucher','Document Number','Journal No','发票号','凭证号','单据号'] },
  { key:'doc_date', label:'Document date', type:'date', required:true,
    synonyms:['Invoice Date','Date','Doc Date','Posting Date','Transaction Date','Document Date','Bill Date','Entry Date','GL Date','Voucher Date','Inv Date','发票日期','日期','凭证日期'] },
  { key:'supplier', label:'Supplier / payee', type:'text', required:true,
    synonyms:['Supplier','Payee','Vendor','Paid To','Supplier Name','Vendor Name','Creditor','Beneficiary','Name','Counterparty','Paid to','供应商','供应商名称','收款人'] },
  { key:'account_name', label:'Account name', type:'text', required:true, role:'category', satisfiedByGroup:true,
    synonyms:['Account Name','Expense Type','Category','Nature','Account Description','Expense Category','GL Description','Expense Head','Nature of Expense','Expense Account','Account Title','科目名称','费用类别'] },
  { key:'amount', label:'Amount', type:'number', required:true,
    synonyms:['Amount','Net Amount','Value','Expense','Debit','Dr','Amount (Excl. GST)','Net','Total','Expense Amount','Amount Excl GST','Base Amount','Local Amount','金额','借方金额','不含税金额'] },
  { key:'account_code', label:'Account code', type:'text',
    synonyms:['Account','GL Code','Expense Code','Cost Element','Account Code','A/C','GL Account','Nominal Code','Account No','GL','科目代码','科目编码'] },
  { key:'tax', label:'Input tax', type:'number', synonyms:['GST','Tax','Input Tax','VAT','GST Amount','Tax Amount','税额','进项税'] },
  { key:'description', label:'Description', type:'text',
    synonyms:['Description','Narration','Details','Particulars','Memo','Remarks','Narrative','Line Description','摘要','备注'] },
  { key:'cost_centre', label:'Cost centre / department', type:'text',
    synonyms:['Cost Centre','Cost Center','Department','Dept','Division','Business Unit','部门'] },
  { key:'related', label:'Related party (Y/N)', type:'text', synonyms:['Related Party','RP','Related','Intercompany','关联方'] },
  { key:'paid_date', label:'Payment date', type:'date', synonyms:['Payment Date','Date Paid','Paid On','Settlement Date','付款日期'] }
];

const STANDARD_COLUMNS = [
  { key:'doc_no', label:'Document' }, { key:'doc_date', label:'Date', type:'date', edit:true }, { key:'supplier', label:'Supplier' },
  { key:'account_code', label:'Code' }, { key:'account_name', label:'Account' }, { key:'description', label:'Description' },
  { key:'amount', label:'Amount', type:'num', edit:true, emphasis:true }, { key:'__month', label:'Month' }, { key:'__flagsText', label:'Flags' }
];

const defaultConfig = () => ({
  castTol: 0.01,
  tbTotal: '', pyTotal: '',
  varThreshold: 10,                 // lead: variance % vs PY beyond which an account is flagged
  monthThreshold: 50,               // monthly: month above the account's average by more than this % is flagged
  testThreshold: '', sampleN: 10, sampleSeed: 20250228, sampleMode: 'overall',
  cutoffDays: 14,
  capThreshold: 5000, capPattern: DEFAULT_CAP,
  roundSum: 10000, rpNames: '', rpPattern: '',
  legalPattern: DEFAULT_LEGAL
});

const safeRe = (s, fallback) => { try { return s ? new RegExp(s, 'i') : fallback; } catch (e) { return fallback; } };

/* ============================================================ COMPUTE */
function compute(recs, cfg, eng) {
  const ye = eng.yearEndDate, fys = eng.fyStartDate;
  const pm = eng.materiality?.pm || 0, trivial = eng.materiality?.trivial || 0;
  const round = Number(cfg.roundSum) || 0, cw = Number(cfg.cutoffDays) || 0;
  const capT = Number(cfg.capThreshold) || 0;
  const capRe = safeRe(cfg.capPattern, new RegExp(DEFAULT_CAP, 'i'));
  const legalRe = safeRe(cfg.legalPattern, new RegExp(DEFAULT_LEGAL, 'i'));
  const rpExtra = safeRe(cfg.rpPattern, null);
  const rpNames = String(cfg.rpNames || '').split(/[,;\n]+/).map(s => Core.keyify(s)).filter(Boolean);
  const threshold = cfg.testThreshold !== '' && cfg.testThreshold != null ? Number(cfg.testThreshold) : pm;
  const live = recs.filter(r => !r.__excluded);

  /* account code → names, duplicates by document + amount */
  const codeNames = {};
  const seen = new Map();
  for (const r of live) {
    const code = String(r.account_code || '').trim(), name = String(r.account_name || '').trim();
    if (code) (codeNames[code] = codeNames[code] || new Set()).add(name || '(blank)');
  }
  const accs = {};
  const monthKeys = [];
  if (fys && ye) {
    /* A year starting on the last day of a month (e.g. 29 Feb 2024 for a 28 Feb 2025 year end) belongs to the following month. */
    const next = new Date(fys.getTime() + 86400000);
    const d = next.getUTCMonth() !== fys.getUTCMonth() ? new Date(Date.UTC(next.getUTCFullYear(), next.getUTCMonth(), 1)) : new Date(Date.UTC(fys.getUTCFullYear(), fys.getUTCMonth(), 1));
    while (d <= ye && monthKeys.length < 24) { monthKeys.push(isoMonth(d)); d.setUTCMonth(d.getUTCMonth() + 1); }
  }
  let total = 0;

  for (const r of recs) {
    r.__displayKey = r.doc_no || ('row ' + r.__srcRow);
    const a = r.amount || 0;
    const code = String(r.account_code || '').trim(), name = String(r.account_name || '').trim() || '(no account)';
    r.__accKey = Core.keyify(code + ' ' + name) || 'none';
    r.__accLabel = (code ? code + ' · ' : '') + name;
    r.__afterYE = !!(r.doc_date && ye && r.doc_date > ye);
    r.__beforeFY = !!(r.doc_date && fys && r.doc_date < fys);
    r.__inPeriod = !!r.doc_date && !r.__afterYE && !r.__beforeFY;
    r.__daysToYE = r.doc_date && ye ? days(ye, r.doc_date) : null;
    r.__month = r.doc_date ? isoMonth(r.doc_date) : null;
    r.__credit = a < -0.005;
    r.__noPayee = !String(r.supplier || '').trim();
    r.__round = round > 0 && Math.abs(a) >= round && Math.abs(a % round) < 0.005;
    r.__roundAbove = r.__round && Math.abs(a) >= threshold;
    r.__capital = capRe.test(name) && a >= capT && capT > 0;
    r.__legal = legalRe.test(name);
    r.__codeConflict = !!(code && codeNames[code] && codeNames[code].size > 1);
    const sup = String(r.supplier || ''), supKey = Core.keyify(sup);
    r.__rp = /^(y|yes|true|1|related|rp)$/i.test(String(r.related || '').trim()) || RP_RE.test(sup) || RP_RE.test(String(r.description || '')) ||
      (rpExtra ? rpExtra.test(sup) || rpExtra.test(String(r.description || '')) : false) || (supKey && rpNames.some(n => supKey.includes(n)));
    r.__inCutoffWindow = cw > 0 && r.__daysToYE != null && Math.abs(r.__daysToYE) <= cw;
    r.__dupOf = null;
    if (!r.__excluded) {
      const k = Core.keyify(r.doc_no || '') + '|' + (r.amount != null ? Math.abs(r.amount).toFixed(2) : '');
      if (Core.keyify(r.doc_no || '')) { if (seen.has(k)) r.__dupOf = seen.get(k); else seen.set(k, r.__srcRow); }
    }
    const w = r.__wp?.testing || {};
    r.__amtPerInv = num(w.amountPerInv);
    r.__amtDiff = r.__amtPerInv != null ? r2(a - r.__amtPerInv) : null;
    r.__flagsText = [r.__afterYE ? 'After YE' : null, r.__beforeFY ? 'Prior period' : null, r.__credit ? 'Credit' : null, r.__noPayee ? 'No payee' : null,
      r.__dupOf ? 'Duplicate' : null, r.__round ? 'Round sum' : null, r.__capital ? 'Capital?' : null, r.__rp ? 'Related party' : null, r.__codeConflict ? 'Code conflict' : null].filter(Boolean).join('; ');
    if (r.__excluded) continue;
    total += a;
    const acc = accs[r.__accKey] || (accs[r.__accKey] = { key:r.__accKey, code, name, label:r.__accLabel, count:0, amount:0, months:{}, outside:0, recs:[], legal:r.__legal, capital:capRe.test(name) });
    acc.count++; acc.amount += a; acc.recs.push(r);
    if (r.__inPeriod) acc.months[r.__month] = (acc.months[r.__month] || 0) + a; else acc.outside += a;
  }

  /* ---- Z3 lead by account ------------------------------------------- */
  const varT = Number(cfg.varThreshold) || 0;
  const accounts = Object.values(accs).sort((a, b) => (a.code || '').localeCompare(b.code || '') || a.name.localeCompare(b.name));
  const lead = accounts.map(acc => {
    const tb = inp(cfg, 'tb', acc.key), py = inp(cfg, 'py', acc.key);
    const variance = py != null ? r2(acc.amount - py) : null;
    const variancePct = (variance != null && py) ? r2(variance / Math.abs(py) * 100) : null;
    return { ...acc, amount: r2(acc.amount), outside: r2(acc.outside), share: total ? r2(acc.amount / total * 100) : 0, tb, tbDiff: tb != null ? r2(acc.amount - tb) : null,
      py, variance, variancePct, flagged: variance != null && Math.abs(variance) > trivial && (variancePct == null || Math.abs(variancePct) > varT),
      conflict: !!(acc.code && codeNames[acc.code] && codeNames[acc.code].size > 1) };
  });
  const tbEntered = lead.some(l => l.tb != null), pyEntered = lead.some(l => l.py != null);
  const tbRef = tbEntered ? r2(lead.reduce((s, l) => s + (l.tb || 0), 0)) : num(cfg.tbTotal);
  const pyRef = pyEntered ? r2(lead.reduce((s, l) => s + (l.py || 0), 0)) : num(cfg.pyTotal);
  const leadTotals = { total: r2(total), count: live.length, accounts: lead.length, tb: tbRef, tbDiff: tbRef != null ? r2(total - tbRef) : null,
    py: pyRef, variance: pyRef != null ? r2(total - pyRef) : null, variancePct: (pyRef != null && pyRef) ? r2((total - pyRef) / Math.abs(pyRef) * 100) : null,
    tbEntered, pyEntered, flagged: lead.filter(l => l.flagged), conflicts: lead.filter(l => l.conflict),
    credits: live.filter(r => r.__credit), afterYE: live.filter(r => r.__afterYE), beforeFY: live.filter(r => r.__beforeFY) };

  /* ---- Z3.1 monthly by account -------------------------------------- */
  const mT = Number(cfg.monthThreshold) || 0;
  const monthly = accounts.map(acc => {
    const vals = monthKeys.map(k => r2(acc.months[k] || 0));
    const active = vals.filter(v => Math.abs(v) > 0.005);
    const avg = monthKeys.length ? r2(vals.reduce((s, v) => s + v, 0) / monthKeys.length) : 0;
    const spikes = monthKeys.filter((k, i) => mT > 0 && avg > 0 && vals[i] > avg * (1 + mT / 100) && vals[i] - avg > trivial);
    const row = { key:acc.key, label:acc.label, name:acc.name, total: r2(acc.amount), outside: r2(acc.outside), avg, activeMonths: active.length, spikes, max: Math.max(...vals, 0) };
    monthKeys.forEach((k, i) => row[k] = vals[i]);
    return row;
  });
  const monthTotals = monthKeys.map(k => r2(accounts.reduce((s, acc) => s + (acc.months[k] || 0), 0)));
  const spikes = monthly.flatMap(m => m.spikes.map(k => ({ account:m.label, month:k, label:monthLabel(k), amount:m[k], avg:m.avg, pct: m.avg ? r2((m[k] - m.avg) / m.avg * 100) : null })));

  /* ---- Z3.2 targeted testing ---------------------------------------- */
  const pop = live.filter(r => (r.amount || 0) > 0.005 && !r.__afterYE);
  const key = pop.filter(r => r.amount >= threshold);
  const residual = pop.filter(r => r.amount < threshold);
  const seed = Number(cfg.sampleSeed) || 1, nWanted = Math.max(0, Math.round(Number(cfg.sampleN) || 0));
  let sample = [];
  if (cfg.sampleMode === 'per-account') {
    accounts.forEach((acc, i) => { const res = residual.filter(r => r.__accKey === acc.key); sample.push(...sampleN(res, Math.min(nWanted, res.length), seed + i)); });
  } else sample = sampleN(residual, Math.min(nWanted, residual.length), seed);
  const sampleSet = new Set(sample.map(r => r.__i));
  for (const r of recs) r.__selected = key.includes(r) ? 'Key item' : sampleSet.has(r.__i) ? 'Random sample' : null;
  const selected = [...key, ...sample].sort((a, b) => a.__accLabel.localeCompare(b.__accLabel) || (b.amount || 0) - (a.amount || 0));
  const popValue = r2(pop.reduce((s, r) => s + r.amount, 0)), keyValue = r2(key.reduce((s, r) => s + r.amount, 0)), sampleValue = r2(sample.reduce((s, r) => s + r.amount, 0));
  const testing = { threshold, seed, mode: cfg.sampleMode === 'per-account' ? 'per-account' : 'overall', pop, key, residual, sample, selected, popValue, keyValue, sampleValue,
    coverage: popValue ? r2((keyValue + sampleValue) / popValue * 100) : 0, untested: r2(popValue - keyValue - sampleValue),
    vouched: selected.filter(r => r.__wp?.testing?.natureCorrect === 'Y' && r.__wp?.testing?.periodCorrect === 'Y').length,
    amountDiffs: selected.filter(r => r.__amtDiff != null && Math.abs(r.__amtDiff) > 0.01),
    exceptions: selected.filter(r => r.__wp?.testing?.natureCorrect === 'N' || r.__wp?.testing?.periodCorrect === 'N'),
    byAccount: accounts.map(acc => { const sel = selected.filter(r => r.__accKey === acc.key); const v = sel.reduce((s, r) => s + r.amount, 0);
      return { key:acc.key, label:acc.label, count:acc.count, amount:r2(acc.amount), selected:sel.length, selectedValue:r2(v), coverage: acc.amount > 0 ? r2(v / acc.amount * 100) : 0 }; }) };

  /* ---- Z3.3 cut-off ------------------------------------------------- */
  const cutRows = live.filter(r => r.__afterYE || r.__beforeFY || r.__inCutoffWindow || !r.doc_date).sort((a, b) => (a.doc_date || 0) - (b.doc_date || 0));
  const cutoff = { rows: cutRows, days: cw, afterYE: live.filter(r => r.__afterYE), beforeFY: live.filter(r => r.__beforeFY), undated: live.filter(r => !r.doc_date),
    window: live.filter(r => r.__inCutoffWindow && !r.__afterYE && !r.__beforeFY),
    tested: cutRows.filter(r => r.__wp?.cutoff?.correct).length, wrong: cutRows.filter(r => r.__wp?.cutoff?.correct === 'N'),
    afterYEValue: r2(live.filter(r => r.__afterYE).reduce((s, r) => s + (r.amount || 0), 0)), beforeFYValue: r2(live.filter(r => r.__beforeFY).reduce((s, r) => s + (r.amount || 0), 0)) };

  /* ---- Z3.4 capital vs revenue -------------------------------------- */
  const capRows = live.filter(r => r.__capital).sort((a, b) => (b.amount || 0) - (a.amount || 0));
  const capital = { rows: capRows, threshold: capT, total: r2(capRows.reduce((s, r) => s + (r.amount || 0), 0)),
    accounts: accounts.filter(a => a.capital).map(a => a.label), toCapitalise: capRows.filter(r => r.__wp?.capital?.capitalise === 'Y'),
    toCapitaliseValue: r2(capRows.filter(r => r.__wp?.capital?.capitalise === 'Y').reduce((s, r) => s + (r.amount || 0), 0)), conflicts: live.filter(r => r.__codeConflict) };

  /* ---- Z3.5 related party / round sums ------------------------------ */
  const rpRows = live.filter(r => r.__rp), roundRows = live.filter(r => r.__round);
  const rp = { rows: [...new Set([...rpRows, ...roundRows])].sort((a, b) => (b.amount || 0) - (a.amount || 0)), rpRows, roundRows, roundAbove: live.filter(r => r.__roundAbove),
    rpValue: r2(rpRows.reduce((s, r) => s + (r.amount || 0), 0)), roundValue: r2(roundRows.reduce((s, r) => s + (r.amount || 0), 0)), noPayee: live.filter(r => r.__noPayee), dups: live.filter(r => r.__dupOf) };

  /* ---- Z3.6 legal & professional ------------------------------------ */
  const legalRows = live.filter(r => r.__legal).sort((a, b) => (a.__accLabel.localeCompare(b.__accLabel)) || ((a.doc_date || 0) - (b.doc_date || 0)));
  const legal = { rows: legalRows, total: r2(legalRows.reduce((s, r) => s + (r.amount || 0), 0)), accounts: accounts.filter(a => a.legal).map(a => a.label),
    sighted: legalRows.filter(r => r.__wp?.legal?.invoice === 'Y').length, litigation: legalRows.filter(r => r.__wp?.legal?.litigation === 'Y') };

  return { lead, leadTotals, monthKeys, monthLabels: monthKeys.map(monthLabel), monthly, monthTotals, spikes, testing, cutoff, capital, rp, legal, pm, trivial, accounts: accounts.length };
}

/* ============================================================== TESTS */
const tests = [
  { id:'EX-EXP-01', label:'Expense dated after the year end', basis:'Z3.3',
    fn:(r) => r.__afterYE && { actual:Core.fmtDate(r.doc_date), difference:r.amount, cell:r['__cell_doc_date'], detail:`Dated ${-r.__daysToYE} day(s) after the reporting date — belongs to the following year unless the service was received before the year end` } },
  { id:'EX-EXP-02', label:'Credit posting in the expense listing', basis:'Z3',
    fn:(r) => r.__credit && { actual:r.amount, difference:r.amount, cell:r['__cell_amount'], detail:'Negative amount — a credit note, reversal or misposting; obtain the supporting document' } },
  { id:'EX-EXP-03', label:'Duplicate supplier invoice', basis:'Z3.5',
    fn:(r) => r.__dupOf && { actual:r.doc_no, difference:r.amount, cell:r['__cell_doc_no'], detail:`Same document number and amount as row ${r.__dupOf} — possible double recording` } },
  { id:'EX-EXP-04', label:'Round-sum expense at or above the testing threshold', basis:'Z3.5',
    fn:(r) => r.__roundAbove && { actual:r.amount, difference:r.amount, cell:r['__cell_amount'], detail:`Round sum of ${(r.amount || 0).toFixed(2)} in ${r.__accLabel} — unusual for a supplier invoice; agree to the invoice and consider whether it is an accrual, provision or misclassified item` } },
  { id:'EX-EXP-05', label:'Payee not stated', basis:'Z3.5',
    fn:(r) => r.__noPayee && { difference:r.amount, cell:r['__cell_supplier'], detail:'No supplier or payee on the document — occurrence cannot be established without the invoice' } },
  { id:'EX-EXP-06', label:'Possible capital item expensed', basis:'Z3.4',
    fn:(r) => r.__capital && { actual:r.amount, difference:r.amount, cell:r['__cell_amount'],
      detail:`${(r.amount || 0).toFixed(2)} charged to ${r.__accLabel} exceeds the capitalisation threshold${r.__codeConflict ? '; account code is also used for another account name' : ''} — inspect the invoice for an asset that should be capitalised` } },
  { id:'EX-EXP-07', label:'Expense dated in the prior period', basis:'Z3.3',
    fn:(r) => r.__beforeFY && { actual:Core.fmtDate(r.doc_date), difference:r.amount, cell:r['__cell_doc_date'], detail:'Dated before the start of the financial year — confirm it was not accrued in the prior year (double count) or that the date is an error' } },
  { id:'EX-EXP-08', label:'Account code used with more than one account name', basis:'Z3', severity:'informational',
    fn:(r) => r.__codeConflict && { actual:r.__accLabel, difference:r.amount, cell:r['__cell_account_name'], detail:'The same account code appears with different account names in the listing — possible misposting or renamed account' } },
  { id:'EX-EXP-09', label:'Related-party or director payee', basis:'Z3.5', severity:'informational',
    fn:(r) => r.__rp && { actual:r.supplier, difference:r.amount, cell:r['__cell_supplier'], detail:'Payee indicates a related party or director — corroborate business purpose, approval and FRS 24 disclosure' } },
  { id:'EX-EXP-10', label:'Round-sum expense below the testing threshold', basis:'Z3.5', severity:'informational',
    fn:(r) => r.__round && !r.__roundAbove && { actual:r.amount, cell:r['__cell_amount'], detail:'Round sum — agree to the supplier invoice' } },
  { id:'EX-EXP-11', label:'Amount per invoice differs from the amount recorded', basis:'Z3.2',
    fn:(r) => r.__amtDiff != null && Math.abs(r.__amtDiff) > 0.01 && { expected:r.__amtPerInv, actual:r.amount, difference:r.__amtDiff, cell:r['__cell_amount'], detail:'Recorded amount does not agree to the supplier invoice sighted' } },
  { id:'EX-EXP-12', label:'Tested item — nature or period not correct', basis:'Z3.2',
    fn:(r) => (r.__wp?.testing?.natureCorrect === 'N' || r.__wp?.testing?.periodCorrect === 'N') && { actual:r.amount, difference:r.amount,
      detail:`${r.__wp.testing.natureCorrect === 'N' ? 'Charged to the wrong account. ' : ''}${r.__wp.testing.periodCorrect === 'N' ? 'Recorded in the wrong period.' : ''} ${r.__wp.testing.comment || ''}`.trim() } },
  { id:'EX-EXP-13', label:'Legal or professional fee indicating litigation or a claim', basis:'Z3.6', severity:'above-trivial',
    fn:(r) => r.__legal && r.__wp?.legal?.litigation === 'Y' && { actual:r.supplier, difference:r.amount, detail:`Litigation or claim indicated: ${r.__wp.legal.nature || r.__wp.legal.comment || 'see Z3.6'} — consider provisions and contingent liabilities (FRS 37) and a legal confirmation` } },
  { id:'EX-EXP-20', scope:'population', label:'Expense listing does not agree to the trial balance', basis:'Z3',
    fn:(recs, cfg, eng, d) => {
      const tol = Number(cfg.castTol) || 0.01;
      const acc = d.lead.filter(l => l.tbDiff != null && Math.abs(l.tbDiff) > tol).map(l => ({ key:l.label, expected:l.tb, actual:l.amount, difference:l.tbDiff, detail:'Listing total for the account against the trial balance figure entered' }));
      if (acc.length) return acc;
      return !d.leadTotals.tbEntered && d.leadTotals.tbDiff != null && Math.abs(d.leadTotals.tbDiff) > tol &&
        { key:'Operating expenses', expected:d.leadTotals.tb, actual:d.leadTotals.total, difference:d.leadTotals.tbDiff, detail:'Listing total against the trial balance total entered' };
    } },
  { id:'EX-EXP-21', scope:'population', label:'Account movement against the prior year beyond the threshold', basis:'Z3', severity:'informational',
    fn:(recs, cfg, eng, d) => d.leadTotals.flagged.map(l => ({ key:l.label, expected:l.py, actual:l.amount, difference:l.variance, detail:`${l.variancePct != null ? l.variancePct.toFixed(1) + '% ' : ''}movement against the prior year — obtain the business reason` })) },
  { id:'EX-EXP-22', scope:'population', label:'Month above the account\'s monthly average beyond the threshold', basis:'Z3.1', severity:'informational',
    fn:(recs, cfg, eng, d) => d.spikes.map(s => ({ key:`${s.account} · ${s.label}`, expected:s.avg, actual:s.amount, difference:r2(s.amount - s.avg), detail:`${s.pct != null ? s.pct.toFixed(0) + '% above' : 'Above'} the account's monthly average — obtain the reason` })) }
];

/* ============================================================== PAGES */
const yn = ['Y', 'N'];
const docRow = r => ({ __rec:r, doc:r.doc_no, date:r.doc_date, supplier:r.supplier, account:r.__accLabel, description:r.description, amount:r.amount });
const DOC_COLS = [
  { key:'doc', label:'Document' }, { key:'date', label:'Date', type:'date' }, { key:'supplier', label:'Supplier / payee' },
  { key:'account', label:'Account' }, { key:'amount', label:'Amount', type:'num', sum:true }
];

const pages = [
  { id:'source',  ref:'Z3.0',  title:'Source data',     kind:'source' },
  { id:'cleaned', ref:'Z3.0a', title:'Cleaned listing', kind:'cleaned' },
  { id:'mapping', ref:'Z3.0b', title:'Column mapping',  kind:'mapping' },

  { id:'lead', ref:'Z3', title:'Lead schedule by account',
    objective:'To agree operating expenses per the expense listing to the trial balance by account and to the prior year audited figures, and to explain movements beyond the threshold.',
    procedures:['Cast the expense listing and summarised it by account code and name.',
                'Agreed each account total to the trial balance and compared it to the prior year; flagged movements beyond the variance threshold and above the trivial threshold.',
                'Identified account codes used with more than one account name, credit postings and items dated outside the year.'],
    render(st, ctx) {
      const d = ctx.d, T = d.leadTotals, m0 = ctx.money0, money = ctx.money, pct = ctx.pct;
      return [
        { type:'controls', items:[
          { key:'tbTotal', label:'Total operating expenses per trial balance (if not entered by account)', kind:'number' },
          { key:'pyTotal', label:'Total per prior year audited financial statements (if not entered by account)', kind:'number' },
          { key:'varThreshold', label:'Flag movements vs prior year beyond (%)', kind:'number' },
          { key:'castTol', label:'Tolerance', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Listing total', value: m0(T.total) }, { label:'Documents', value: `${T.count} · ${T.accounts} accounts` },
          { label:'Per trial balance', value: T.tb == null ? '— enter —' : m0(T.tb) },
          { label:'Listing − TB', value: T.tbDiff == null ? '' : money(T.tbDiff), cls: T.tbDiff == null ? '' : Math.abs(T.tbDiff) > 0.01 ? 'bad' : 'ok' },
          { label:'Movement vs PY', value: T.variance == null ? '— enter PY —' : `${money(T.variance)} (${pct(T.variancePct)})`, cls: T.variance != null && Math.abs(T.variance) > ctx.pm ? 'warn' : '' },
          { label:'Accounts flagged vs PY', value: T.flagged.length, cls: T.flagged.length ? 'warn' : 'ok' },
          { label:'Account code conflicts', value: T.conflicts.length, cls: T.conflicts.length ? 'warn' : 'ok' },
          { label:'Credit postings', value: T.credits.length, cls: T.credits.length ? 'warn' : 'ok' },
          { label:'Dated after year end', value: T.afterYE.length, cls: T.afterYE.length ? 'bad' : 'ok' }, { label:'Dated in prior period', value: T.beforeFY.length, cls: T.beforeFY.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Expenses by account — listing vs trial balance vs prior year', columns:[
          { key:'code', label:'Code' }, { key:'name', label:'Account' }, { key:'count', label:'Items', type:'int' },
          { key:'amount', label:'Per listing', type:'num', sum:true, emphasis:true }, { key:'share', label:'Share', type:'pct' },
          { key:'tb', label:'Per trial balance', input:'number' }, { key:'tbDiff', label:'Listing − TB', type:'num', flag: v => v != null && Math.abs(v) > 0.01 },
          { key:'py', label:'Prior year', input:'number' }, { key:'variance', label:'Movement', type:'num', flag: (v, row) => row.__flagged }, { key:'variancePct', label:'Movement %', type:'pct' },
          { key:'note', label:'Note', type:'chip', chipClass: v => v === 'Code conflict' ? 'warn' : 'grey' },
          { key:'explanation', label:'Explanation of movement', input:'text', wide:true } ],
          rows: d.lead.map(l => ({ __key:l.key, ...l, share: l.share / 100, variancePct: l.variancePct != null ? l.variancePct / 100 : null, note: l.conflict ? 'Code conflict' : '', __flagged: l.flagged, __cls: l.flagged || l.conflict ? 'flag' : '' })), maxHeight:'70vh',
          footnote:'Enter the trial balance and prior year figure per account. Differences above the tolerance are raised as EX-EXP-20; movements beyond the threshold as EX-EXP-21. A code conflict means the same code carries two account names (EX-EXP-08).' }
      ];
    },
    flag(st, d) { return (d.leadTotals.tbDiff != null && Math.abs(d.leadTotals.tbDiff) > 0.01) || d.leadTotals.conflicts.length > 0 || d.leadTotals.afterYE.length > 0 || d.leadTotals.beforeFY.length > 0; } },

  { id:'monthly', ref:'Z3.1', title:'Monthly analysis by account',
    objective:'To analyse each expense account by month, identify months materially above the account\'s average, and obtain explanations.',
    procedures:['Spread each account by month of document date across the financial year.',
                'Computed the monthly average per account and flagged months above the average by more than the threshold and above the trivial threshold.',
                'Obtained management\'s explanation for each flagged month and corroborated it.'],
    render(st, ctx) {
      const d = ctx.d, m0 = ctx.money0;
      const cols = [{ key:'label', label:'Account' },
        ...d.monthKeys.map((k, i) => ({ key:k, label:d.monthLabels[i], type:'num', sum:true, flag: (v, row) => row.__spikes.includes(k) })),
        { key:'outside', label:'Outside year', type:'num', sum:true }, { key:'total', label:'Total', type:'num', sum:true, emphasis:true },
        { key:'avg', label:'Monthly average', type:'num' }, { key:'activeMonths', label:'Active months', type:'int' }];
      return [
        { type:'controls', items:[{ key:'monthThreshold', label:'Flag a month above the account average by more than (%)', kind:'number' }] },
        { type:'stats', items:[
          { label:'Accounts', value: d.monthly.length }, { label:'Months in the year', value: d.monthKeys.length },
          { label:'Highest month overall', value: d.monthTotals.length ? (() => { const i = d.monthTotals.indexOf(Math.max(...d.monthTotals)); return `${d.monthLabels[i]} · ${m0(d.monthTotals[i])}`; })() : '' },
          { label:'Flagged account-months', value: d.spikes.length, cls: d.spikes.length ? 'warn' : 'ok' } ] },
        { type:'table', title:'Expense by account and month', columns: cols,
          rows: d.monthly.map(m => ({ ...m, __spikes: m.spikes, __cls: m.spikes.length ? 'flag' : '' })), maxHeight:'70vh',
          footnote:'Cells painted red are above the account\'s monthly average by more than the threshold (EX-EXP-22). Accounts with fewer than twelve active months may indicate missing postings or annual charges.' },
        { type:'table', title:'Flagged account-months', columns:[
          { key:'account', label:'Account' }, { key:'label', label:'Month' }, { key:'amount', label:'Amount', type:'num' }, { key:'avg', label:'Monthly average', type:'num' }, { key:'pct', label:'Above average', type:'pct', dp:0 },
          { key:'explanation', label:'Explanation obtained', input:'text', wide:true }, { key:'corroborated', label:'Corroborated (Y/N)', input:'select', options:yn } ],
          rows: d.spikes.map(s => ({ __key: Core.keyify(s.account + ' ' + s.month), ...s, pct: s.pct != null ? s.pct / 100 : null })), emptyText:'No account-month exceeds the threshold.' }
      ];
    },
    flag(st, d) { return d.spikes.length > 0; } },

  { id:'testing', ref:'Z3.2', title:'Targeted testing and vouching',
    objective:'To obtain evidence of the occurrence, accuracy, classification and period of recorded expenses by vouching key items and a random sample to supplier invoices.',
    procedures:['Selected every expense at or above the testing threshold as a key item.',
                'Drew a random sample from the remaining items — overall or per account — using a recorded seed so the selection is reproducible.',
                'For each selected item, recorded the invoice number, date, supplier and amount per the invoice, and whether the nature and period recorded are correct.'],
    render(st, ctx) {
      const T = ctx.d.testing, m0 = ctx.money0, pct = ctx.pct;
      return [
        { type:'controls', items:[
          { key:'testThreshold', label:'Testing threshold — every item at or above is a key item', kind:'number', help:`Blank = performance materiality (${m0(ctx.pm)}). Currently ${m0(T.threshold)}.` },
          { key:'sampleMode', label:'Random sample drawn', kind:'select', options:[['overall', 'Overall — N items from all remaining items'], ['per-account', 'Per account — N items from each account']] },
          { key:'sampleN', label:'Random sample size (N)', kind:'number', help:`${T.residual.length} items below the threshold` },
          { key:'sampleSeed', label:'Random seed', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Population (debits dated up to the year end)', value: `${T.pop.length} · ${m0(T.popValue)}` },
          { label:'Key items', value: `${T.key.length} · ${m0(T.keyValue)}` }, { label:'Random sample', value: `${T.sample.length} · ${m0(T.sampleValue)}` },
          { label:'Coverage', value: pct(T.coverage), cls: T.coverage >= 50 ? 'ok' : 'warn' }, { label:'Untested value', value: m0(T.untested) },
          { label:'Vouched (nature and period correct)', value: `${T.vouched} of ${T.selected.length}`, cls: T.vouched === T.selected.length && T.selected.length ? 'ok' : 'warn' },
          { label:'Amount differences', value: T.amountDiffs.length, cls: T.amountDiffs.length ? 'bad' : 'ok' }, { label:'Exceptions', value: T.exceptions.length, cls: T.exceptions.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Items selected for vouching', columns:[
          ...DOC_COLS, { key:'description', label:'Description' },
          { key:'basis', label:'Basis', type:'chip', chipClass: v => v === 'Key item' ? 'info' : 'grey' },
          { key:'invNo', label:'Invoice no. per invoice', input:'text' }, { key:'invDate', label:'Invoice date per invoice', input:'text' },
          { key:'supplierPerInv', label:'Supplier per invoice', input:'text', wide:true }, { key:'amountPerInv', label:'Amount per invoice', input:'number' },
          { key:'amtDiff', label:'Recorded − invoice', type:'num', flag: v => v != null && Math.abs(v) > 0.01 },
          { key:'natureCorrect', label:'Nature / account correct (Y/N)', input:'select', options:yn },
          { key:'periodCorrect', label:'Period correct (Y/N)', input:'select', options:yn },
          { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: T.selected.map(r => ({ ...docRow(r), basis:r.__selected, amtDiff:r.__amtDiff, __cls: (r.__amtDiff != null && Math.abs(r.__amtDiff) > 0.01) || r.__wp?.testing?.natureCorrect === 'N' || r.__wp?.testing?.periodCorrect === 'N' ? 'flag' : '' })), maxHeight:'70vh',
          emptyText:'No items selected — lower the threshold or increase the sample size.',
          footnote:`Seed ${T.seed}; ${T.mode === 'per-account' ? 'sample drawn per account (seed offset by account position)' : 'sample drawn from the whole residual population'}. Amount differences are raised as EX-EXP-11; wrong nature or period as EX-EXP-12.` },
        { type:'table', title:'Coverage by account', columns:[
          { key:'label', label:'Account' }, { key:'count', label:'Items', type:'int' }, { key:'amount', label:'Per listing', type:'num', sum:true },
          { key:'selected', label:'Selected', type:'int' }, { key:'selectedValue', label:'Selected value', type:'num', sum:true }, { key:'coverage', label:'Coverage', type:'pct' } ],
          rows: T.byAccount.map(a => ({ ...a, coverage: a.coverage / 100 })), maxHeight:'50vh' }
      ];
    },
    flag(st, d) { return d.testing.amountDiffs.length > 0 || d.testing.exceptions.length > 0; } },

  { id:'cutoff', ref:'Z3.3', title:'Cut-off',
    objective:'To verify that expenses are recorded in the period in which the goods or services were received, by examining items dated outside the financial year and in the days either side of the year end.',
    procedures:['Listed every item dated after the year end, before the start of the year, or undated.',
                'Listed every item dated within the cut-off window either side of the year end and recorded the service period per the invoice.',
                'Assessed whether each item belongs to the year and whether an accrual or prepayment is required.'],
    render(st, ctx) {
      const C = ctx.d.cutoff, m0 = ctx.money0;
      return [
        { type:'controls', items:[{ key:'cutoffDays', label:'Cut-off window (days either side of the year end)', kind:'number' }] },
        { type:'stats', items:[
          { label:'Dated after year end', value: `${C.afterYE.length} · ${m0(C.afterYEValue)}`, cls: C.afterYE.length ? 'bad' : 'ok' },
          { label:'Dated in the prior period', value: `${C.beforeFY.length} · ${m0(C.beforeFYValue)}`, cls: C.beforeFY.length ? 'bad' : 'ok' },
          { label:'Undated', value: C.undated.length, cls: C.undated.length ? 'warn' : 'ok' },
          { label:`Within ±${C.days} days of year end`, value: C.window.length },
          { label:'Tested', value: `${C.tested} of ${C.rows.length}`, cls: C.tested === C.rows.length && C.rows.length ? 'ok' : 'warn' },
          { label:'Wrong period', value: C.wrong.length, cls: C.wrong.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Items outside the year and around the year end', columns:[
          ...DOC_COLS, { key:'daysToYE', label:'Days before YE', type:'int' },
          { key:'position', label:'Position', type:'chip', chipClass: v => v === 'After year end' || v === 'Prior period' ? 'bad' : v === 'Undated' ? 'warn' : 'grey' },
          { key:'servicePeriod', label:'Service period per invoice', input:'text', wide:true },
          { key:'correct', label:'Correct period (Y/N)', input:'select', options:yn },
          { key:'adjustment', label:'Accrual / prepayment required', input:'text', wide:true },
          { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: C.rows.map(r => ({ ...docRow(r), daysToYE:r.__daysToYE, position: r.__afterYE ? 'After year end' : r.__beforeFY ? 'Prior period' : !r.doc_date ? 'Undated' : 'Within window', __cls: r.__afterYE || r.__beforeFY ? 'flag' : '' })), maxHeight:'70vh',
          emptyText:'No items outside the year or within the cut-off window.',
          footnote:'Items dated after the year end are EX-EXP-01; items dated in the prior period are EX-EXP-07.' }
      ];
    },
    flag(st, d) { return d.cutoff.afterYE.length > 0 || d.cutoff.beforeFY.length > 0 || d.cutoff.wrong.length > 0; } },

  { id:'capital', ref:'Z3.4', title:'Capital vs revenue screen',
    objective:'To identify expenditure charged to repairs, maintenance, equipment and similar accounts that may represent capital items to be recognised as property, plant and equipment.',
    procedures:['Identified the accounts whose names indicate repairs, maintenance, equipment, renovation, software or similar expenditure.',
                'Listed every item in those accounts at or above the capitalisation threshold and inspected the invoice for the nature of the expenditure.',
                'Concluded for each item whether it enhances or extends the asset (capitalise) or maintains it (expense).'],
    render(st, ctx) {
      const K = ctx.d.capital, m0 = ctx.money0;
      return [
        { type:'controls', items:[
          { key:'capThreshold', label:'Capitalisation threshold', kind:'number' },
          { key:'capPattern', label:'Account name pattern screened (regular expression)', kind:'text' } ] },
        { type:'stats', items:[
          { label:'Accounts screened', value: K.accounts.length ? K.accounts.join('; ') : 'none matched' },
          { label:'Items at or above threshold', value: `${K.rows.length} · ${m0(K.total)}`, cls: K.rows.length ? 'warn' : 'ok' },
          { label:'To capitalise', value: `${K.toCapitalise.length} · ${m0(K.toCapitaliseValue)}`, cls: K.toCapitalise.length ? 'bad' : 'ok' },
          { label:'Account code conflicts', value: K.conflicts.length, cls: K.conflicts.length ? 'warn' : 'ok' } ] },
        { type:'table', title:'Items screened for capitalisation', columns:[
          ...DOC_COLS, { key:'description', label:'Description' },
          { key:'conflict', label:'Code', type:'chip', chipClass: v => v ? 'warn' : 'grey' },
          { key:'nature', label:'Nature per invoice', input:'text', wide:true },
          { key:'capitalise', label:'Capitalise (Y/N)', input:'select', options:yn },
          { key:'life', label:'Useful life if capitalised (years)', input:'number' },
          { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: K.rows.map(r => ({ ...docRow(r), conflict: r.__codeConflict ? 'Code conflict' : '', __cls: r.__codeConflict ? 'flag' : '' })),
          emptyText:'No item in the screened accounts reaches the capitalisation threshold.',
          footnote:'Every item listed is raised as EX-EXP-06 until concluded on. Items marked to capitalise should be carried to the PPE file and the summary of unadjusted differences.' }
      ];
    },
    flag(st, d) { return d.capital.rows.length > 0; } },

  { id:'rp', ref:'Z3.5', title:'Related-party and round-sum flags',
    objective:'To identify payments to related parties or directors, round-sum amounts, duplicated documents and items with no payee, and to vouch them to supporting documentation and approval.',
    procedures:['Flagged every payee whose name or description indicates a related party, director, shareholder or group company, and every payee named by the auditor.',
                'Flagged every round-sum amount, separating those at or above the testing threshold.',
                'Identified duplicated document numbers and items without a payee.',
                'Vouched each flagged item to the invoice and approval and recorded the relationship and business purpose.'],
    render(st, ctx) {
      const R = ctx.d.rp, m0 = ctx.money0;
      return [
        { type:'controls', items:[
          { key:'rpNames', label:'Related-party names (comma-separated, from the related-party listing)', kind:'text' },
          { key:'rpPattern', label:'Additional payee pattern (regular expression)', kind:'text' },
          { key:'roundSum', label:'Round-sum flag: multiple of', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Related-party / director items', value: `${R.rpRows.length} · ${m0(R.rpValue)}`, cls: R.rpRows.length ? 'warn' : 'ok' },
          { label:'Round sums', value: `${R.roundRows.length} · ${m0(R.roundValue)}` },
          { label:'Round sums at or above threshold', value: R.roundAbove.length, cls: R.roundAbove.length ? 'bad' : 'ok' },
          { label:'Duplicate documents', value: R.dups.length, cls: R.dups.length ? 'bad' : 'ok' },
          { label:'No payee', value: R.noPayee.length, cls: R.noPayee.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Related-party and round-sum items', columns:[
          ...DOC_COLS, { key:'description', label:'Description' },
          { key:'reason', label:'Flag', type:'chip', chipClass: v => /Related/.test(v) ? 'warn' : /above/.test(v) ? 'bad' : 'grey' },
          { key:'relationship', label:'Relationship / business purpose', input:'text', wide:true },
          { key:'approval', label:'Approval sighted (Y/N)', input:'select', options:yn },
          { key:'agreed', label:'Agreed to invoice (Y/N)', input:'select', options:yn },
          { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: R.rows.map(r => ({ ...docRow(r), reason: [r.__rp ? 'Related party' : null, r.__roundAbove ? 'Round sum above threshold' : r.__round ? 'Round sum' : null].filter(Boolean).join(' · '), __cls: r.__rp || r.__roundAbove ? 'flag' : '' })), maxHeight:'60vh',
          emptyText:'No related-party or round-sum items identified.',
          footnote:'Round sums at or above the testing threshold are EX-EXP-04; related-party payees EX-EXP-09 (informational).' },
        { type:'table', title:'Duplicate documents', columns:[...DOC_COLS, { key:'dupOf', label:'Duplicate of row', type:'int' }, { key:'confirmed', label:'Confirmed duplicate (Y/N)', input:'select', options:yn }, { key:'comment', label:'Comment', input:'text', wide:true }],
          rows: R.dups.map(r => ({ ...docRow(r), dupOf:r.__dupOf })), emptyText:'No duplicated document numbers.' },
        { type:'table', title:'Items with no payee', columns:[...DOC_COLS, { key:'description', label:'Description' }, { key:'payeePerInv', label:'Payee per invoice', input:'text', wide:true }, { key:'comment', label:'Comment', input:'text', wide:true }],
          rows: R.noPayee.map(docRow), emptyText:'Every item carries a payee.' }
      ];
    },
    flag(st, d) { return d.rp.roundAbove.length > 0 || d.rp.dups.length > 0 || d.rp.noPayee.length > 0; } },

  { id:'legal', ref:'Z3.6', title:'Legal and professional fees',
    objective:'To examine every legal and professional fee for the year, to identify litigation, claims or regulatory matters requiring provision or disclosure, and to verify the nature of the services.',
    procedures:['Listed every item in the legal, professional, consultancy and similar accounts (100% of the population).',
                'Sighted each invoice, recorded the nature of the service and whether it indicates litigation, a claim or a regulatory matter.',
                'Carried indications of litigation to the provisions and contingencies assessment and considered a legal letter.'],
    render(st, ctx) {
      const Lg = ctx.d.legal, m0 = ctx.money0;
      return [
        { type:'controls', items:[{ key:'legalPattern', label:'Account name pattern (regular expression)', kind:'text' }] },
        { type:'stats', items:[
          { label:'Accounts included', value: Lg.accounts.length ? Lg.accounts.join('; ') : 'none matched' },
          { label:'Items (100% tested)', value: `${Lg.rows.length} · ${m0(Lg.total)}` },
          { label:'Invoices sighted', value: `${Lg.sighted} of ${Lg.rows.length}`, cls: Lg.sighted === Lg.rows.length && Lg.rows.length ? 'ok' : 'warn' },
          { label:'Litigation or claim indicated', value: Lg.litigation.length, cls: Lg.litigation.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Legal and professional fees — every item', columns:[
          ...DOC_COLS, { key:'description', label:'Description' },
          { key:'invoice', label:'Invoice sighted (Y/N)', input:'select', options:yn },
          { key:'nature', label:'Nature of service per invoice', input:'text', wide:true },
          { key:'litigation', label:'Litigation / claim / regulatory matter indicated (Y/N)', input:'select', options:yn },
          { key:'enquiry', label:'Enquiry of management / legal letter', input:'text', wide:true },
          { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: Lg.rows.map(r => ({ ...docRow(r), __cls: r.__wp?.legal?.litigation === 'Y' ? 'flag' : '' })), maxHeight:'70vh',
          emptyText:'No account name matches the legal and professional pattern.',
          footnote:'An item marked as indicating litigation is raised as EX-EXP-13 for the provisions and contingencies assessment.' }
      ];
    },
    flag(st, d) { return d.legal.litigation.length > 0; } },

  { id:'conclusion', ref:'Z3.9', title:'Exceptions & conclusion', kind:'conclusion' }
];

function suggestConclusion(st, ctx) {
  const d = ctx.d, T = d.leadTotals, S = d.testing;
  const ex = (st.exceptions || []).filter(e => e.disposition === 'open');
  return [
    `Operating expenses per the listing total ${ctx.money(T.total)} across ${T.count} documents and ${T.accounts} accounts${T.tbDiff == null ? '' : Math.abs(T.tbDiff) <= 0.01 ? ', agreeing to the trial balance' : `, differing from the trial balance by ${ctx.money(T.tbDiff)}`}.`,
    T.flagged.length ? `${T.flagged.length} account(s) moved beyond the variance threshold against the prior year and were explained.` : '',
    `${S.selected.length} items (${ctx.pct(S.coverage)} of the population) were selected for vouching; ${S.vouched} agreed in nature and period.`,
    d.cutoff.afterYE.length || d.cutoff.beforeFY.length ? `Cut-off testing identified ${d.cutoff.afterYE.length} item(s) dated after the year end and ${d.cutoff.beforeFY.length} dated in the prior period.` : 'Cut-off testing identified no items dated outside the year.',
    d.capital.rows.length ? `${d.capital.rows.length} item(s) totalling ${ctx.money(d.capital.total)} were screened for capitalisation; ${d.capital.toCapitalise.length} to be capitalised.` : '',
    `${d.legal.rows.length} legal and professional fee item(s) totalling ${ctx.money(d.legal.total)} were examined in full; ${d.legal.litigation.length} indicated litigation or claims.`,
    ex.length ? `${ex.length} exception(s) remain open in the register.` : 'No exceptions remain open.',
    'Subject to the above, operating expenses are fairly stated for the year.'
  ].filter(Boolean).join(' ');
}

return {
  code:'EXP', name:'Operating Expenses', group:'Profit or loss', accepts:'.xlsx,.xlsm,.csv',
  blurb:'The operating expenses audit file: lead by account, monthly analysis, targeted testing and vouching, cut-off, capital vs revenue screen, related-party and round-sum flags, and 100% testing of legal and professional fees — from one uploaded expense listing.',
  objective:'To obtain sufficient appropriate audit evidence that recorded operating expenses occurred, are complete, are accurately measured and classified, and are recognised in the correct period.',
  fields, tests, compute, pages, defaultConfig, STANDARD_COLUMNS,
  procedures: pages.flatMap(p => p.procedures || []),
  columns: STANDARD_COLUMNS, suggestConclusion
};
})();

Modules.register(EXPModule);
