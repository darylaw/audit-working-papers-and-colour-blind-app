/* ==========================================================================
   tax.js -- Taxation as an auditor actually works it.

   Accepts either of two uploads and detects which it was given:
     * the trial balance  -> the current tax computation is seeded from the
       P&L and balance sheet captions (every figure can be overridden);
     * the fixed asset register (same shape as PPE) -> the capital allowance
       schedule is built by category; the computation figures are entered.

     W3    Lead schedule                    W3.4  Tax payable roll-forward
     W3.0c Tax classification of the TB     W3.5  Indirect tax reasonableness
     W3.1  Current tax computation          W3.6  Prior year assessment
     W3.2  Capital allowances
     W3.3  Deferred tax
   Rates, exemption tiers and claim bases are all auditor-configurable; the
   defaults are only defaults.
   ========================================================================== */

const TaxModule = (() => {
const r2 = n => n == null || isNaN(n) ? null : Math.round(n * 100) / 100;
const num = v => (v === '' || v == null || isNaN(Number(v))) ? null : Number(v);
const n0 = v => num(v) || 0;
const inp = (cfg, key, k) => num(cfg[key + ':' + k]);
const txt = (cfg, key, k) => { const v = cfg[key + ':' + k]; return v == null ? '' : String(v); };
const YN = ['Y', 'N'];

/* ---------------------------------------------------------------- fields */
const fields = [
  /* trial balance shape */
  { key:'code', label:'Account code', role:'key', type:'text',
    synonyms:['Account','Account No','A/C Code','GL Code','Account Number','Nominal Code','Account Code','A/C','科目代码','科目编码'] },
  { key:'name', label:'Account name', type:'text',
    synonyms:['Account Name','Description','Account Description','Name','Particulars','Text for B/S P&L item','Account Title','GL Description','科目名称','科目'] },
  { key:'balance', label:'Balance (debit positive)', type:'number',
    synonyms:['Balance','Net Balance','Amount','Closing Balance','Balance at Year End','YTD Balance','Current Year Balance','余额','本期余额','期末余额'] },
  { key:'debit', label:'Debit', type:'number',
    synonyms:['Debit','Dr','Debit (Dr)','Debit Amount','Dr Amount','借方','借方金额'] },
  { key:'credit', label:'Credit', type:'number',
    synonyms:['Credit','Cr','Credit (Cr)','Credit Amount','Cr Amount','贷方','贷方金额'] },
  { key:'balance_py', label:'Prior year balance', type:'number',
    synonyms:['Prior Year','PY Balance','Comparative','Last Year','Balance b/f','Prior Year Balance','Previous Year','上年','期初余额'] },
  { key:'caption', label:'FS caption', type:'text',
    synonyms:['FS Line','Grouping','Map No.','FS Caption','L/S','Caption','Lead Schedule','报表项目'] },
  /* fixed asset register shape (capital allowances) */
  { key:'asset_id', label:'Asset code', type:'text',
    synonyms:['Asset Code','Asset No.','Asset No','FA ID','Tag Number','Asset Ref','Asset Number','资产编号'] },
  { key:'category', label:'Asset category', role:'category', type:'text', satisfiedByGroup:true,
    synonyms:['Category','Asset Class','Asset Group','FA Type','Class','Type','资产类别'] },
  { key:'acq_date', label:'Acquisition date', type:'date',
    synonyms:['Purchase Date','Acquisition Date','Date Acquired','Capitalisation Date','Capitalization Date','Asset Date','In-Service Date','Date of Purchase','Cap. Date','购置日期'] },
  { key:'life', label:'Useful life', type:'number',
    synonyms:['Useful Life (Yrs)','Useful Life','Life','UL','Est. Useful Life','Dep. Life (Months)','Useful Life (Mths)'] },
  { key:'cost_open', label:'Cost b/f', type:'number', block:'Cost',
    synonyms:['Cost B/F','Opening Cost','Op Bal','Cost Brought Forward','Cost at 1 Jan','Op Bal - Cost','期初原值'] },
  { key:'additions', label:'Additions (cost)', type:'number', block:'Cost',
    synonyms:['Additions','Add’ns','Add\'ns','Acquisitions','Purchases','Addition','本期增加'] },
  { key:'disposals', label:'Disposals (cost)', type:'number', block:'Cost',
    synonyms:['Disposals','Disposal / Write-off','Deletions','Retirements','Disposal','本期减少'] },
  { key:'cost_close', label:'Cost c/f', type:'number', block:'Cost',
    synonyms:['Cost C/F','Closing Cost','End Bal','Cost at Year End','Total Cost','End Bal - Cost'] },
  /* the depreciation block must be claimable exactly, or a trial-balance
     field fuzzy-matches "Current Year Depreciation" on a register */
  { key:'accdep_open', label:'Acc dep b/f', type:'number', block:'Depreciation',
    synonyms:['Acc Dep B/F','Opening Accumulated Depreciation','Accum. Depn B/F','Op Bal - Depn','A/Depn Brought Forward','期初累计折旧'] },
  { key:'dep_charge', label:'Depreciation charge', type:'number', block:'Depreciation',
    synonyms:['Depreciation for the Year','Current Year Depreciation','Depn Charge','Charge for the Year','Dep - CY','Additions','本期折旧'] },
  { key:'accdep_disp', label:'Acc dep on disposals', type:'number', block:'Depreciation',
    synonyms:['Acc Dep on Disposal','Depn on Disposals','Write-back on Disposal','Disposals'] },
  { key:'accdep_close', label:'Acc dep c/f', type:'number', block:'Depreciation',
    synonyms:['Acc Dep C/F','Closing Accumulated Depreciation','Accum. Depn C/F','End Bal - Depn'] },
  { key:'nbv_close', label:'NBV c/f', type:'number', block:'NBV',
    synonyms:['NBV','Net Book Value','Carrying Amount','WDV','Net Book Value at Year End'] }
];

const STANDARD_COLUMNS = [
  { key:'code', label:'Code' }, { key:'name', label:'Account name' }, { key:'__bal', label:'Balance', type:'num', emphasis:true },
  { key:'balance_py', label:'Prior year', type:'num' }, { key:'__sideLabel', label:'Side' }, { key:'__clsLabel', label:'Tax class' },
  { key:'asset_id', label:'Asset' }, { key:'category', label:'Category' }, { key:'additions', label:'Additions', type:'num' }, { key:'__nbv', label:'NBV', type:'num' }
];

/* Tax classes: how each trial balance line enters the computation. */
const CLASSES = [
  { id:'revenue',      side:'pl', label:'Revenue' },
  { id:'otherIncome',  side:'pl', label:'Other income' },
  { id:'cogs',         side:'pl', label:'Cost of sales / purchases' },
  { id:'staff',        side:'pl', label:'Staff costs' },
  { id:'depreciation', side:'pl', label:'Depreciation (add back)' },
  { id:'amortisation', side:'pl', label:'Amortisation (add back)' },
  { id:'impairment',   side:'pl', label:'Provisions / impairment / write-downs (add back)' },
  { id:'entertainment',side:'pl', label:'Entertainment (partly non-deductible)' },
  { id:'donation',     side:'pl', label:'Donations (add back)' },
  { id:'fines',        side:'pl', label:'Fines and penalties (add back)' },
  { id:'interest',     side:'pl', label:'Finance costs' },
  { id:'otherExpense', side:'pl', label:'Other operating expenses' },
  { id:'taxExpense',   side:'pl', label:'Income tax expense' },
  { id:'taxProvision', side:'bs', label:'Provision for taxation / tax payable' },
  { id:'deferredTax',  side:'bs', label:'Deferred tax' },
  { id:'gst',          side:'bs', label:'Indirect tax (GST / VAT) payable' },
  { id:'bs',           side:'bs', label:'Balance sheet — not in the computation' }
];
const CLASS_LABEL = Object.fromEntries(CLASSES.map(c => [c.id, c.label]));
const CLASS_SIDE = Object.fromEntries(CLASSES.map(c => [c.id, c.side]));

/* Deterministic name-based classification. Order matters. Lines that can sit on
   either side (allowances, provisions) are P&L when they carry a debit balance. */
function classify(name, bal) {
  const s = String(name || '').toLowerCase().replace(/\s+/g, ' ').trim();
  if (!s) return 'bs';
  /* P&L charges named after the asset they relate to must win over the
     balance-sheet cost-line rule below, or "Depreciation of right-of-use
     assets" and "Amortisation of intangible assets" land on the balance sheet. */
  if (/^(depreciation|amortisation|amortization)\b/.test(s) && !/accumulated|accum/.test(s)) return /amorti/.test(s) ? 'amortisation' : 'depreciation';
  if (/accumulated|acc\.? dep|accum/.test(s)) return 'bs';
  if (/-\s*cost$|\bat cost$|right-of-use assets?( - cost)?$|intangible assets?( - cost)?$|- (nbv|net book value)$/.test(s)) return 'bs';   // fixed asset cost lines
  if (/income tax expense|tax expense|taxation expense|^taxation$|tax charge|deferred tax (expense|charge|credit)|^income tax$/.test(s)) return 'taxExpense';
  if (/deferred tax/.test(s)) return 'deferredTax';
  if (/\bgst\b|\bvat\b|goods and services tax|sales tax|output tax|input tax|value added tax/.test(s)) return 'gst';
  if (/provision for (income )?tax|income tax payable|tax payable|taxation payable|current tax|tax recoverable|tax liabilit/.test(s)) return 'taxProvision';
  if (/cost of (sales|goods|materials|services)|purchases|direct (labour|labor|material|cost)|subcontract|factory overhead|production overhead|consumed/.test(s)) return 'cogs';
  if (/other income|interest income|dividend income|gain on|scrap sales|rental income|grant|foreign exchange gain|exchange gain|sundry income|miscellaneous income|income -/.test(s)) return 'otherIncome';
  if (/\b(revenue|sales|turnover)\b/.test(s) && !/payable|receivable|deposit/.test(s)) return 'revenue';
  if (/depreciation/.test(s)) return 'depreciation';
  if (/amorti[sz]ation/.test(s)) return 'amortisation';
  if (/allowance for|impairment|written down|write-?down|bad debt|written off|write-?off|provision for(?! tax)|expected credit loss/.test(s)) return (bal || 0) > 0 ? 'impairment' : 'bs';
  if (/entertainment/.test(s)) return 'entertainment';
  if (/donation/.test(s)) return 'donation';
  if (/\bfines?\b|penalt/.test(s)) return 'fines';
  if (/interest (on|expense|paid|payable$)|finance cost|bank interest|interest -/.test(s) && !/receivable|income/.test(s)) return 'interest';
  if (/salar|wages|bonus|\bcpf\b|statutory contribution|remuneration|welfare|staff|medical|training|payroll|employee/.test(s)) return 'staff';
  if (/\bfees?\b|rental|\brent\b|utilit|repair|maintenance|insurance|travel|motor|freight|delivery|advertis|promotion|commission|bank charge|foreign exchange loss|exchange loss|printing|stationery|postage|telephone|subscription|licen[cs]e|general|sundry|miscellaneous|expense|loss on|upkeep|transport|courier|cleaning|security|marketing/.test(s)) return 'otherExpense';
  return 'bs';
}

const CA_BASES = [['1-year', '1-year write-off (100% in year of purchase)'], ['3-year', '3-year straight line (1/3 per year)'], ['working life', 'Working life (cost ÷ prescribed life)'], ['not qualifying', 'Not qualifying — no allowance']];

const defaultConfig = () => ({
  castTol: 0.01,
  taxRate: 17,                       // % — corporate rate
  exemptTiers: '10000:75,190000:50', // partial exemption: "band:percent" cumulative bands; blank = none
  rebatePct: 0, rebateCap: 0,        // tax rebate % of tax payable, capped
  entPct: 50,                        // non-deductible % of entertainment
  pbtOverride: '', addDepreciation: '', addAmortisation: '', addProvisions: '', addEntertainment: '', addDonations: '', addFines: '',
  exemptIncome: '', lossesBF: '', caOverride: '',
  adjRows: 6,                        // further adjustment lines (positive = add back, negative = deduct)
  tbCurrentTax: '', tbDeferredTax: '', tbTaxProvision: '', tbGst: '', tbRevenue: '', tbPurchases: '',
  /* capital allowances */
  caDefaultBasis: '3-year', caRows: 6, lifeUnit: 'auto',
  /* deferred tax */
  dtRows: 4, dtPY: '', recogniseLossDTA: 'N',
  /* tax payable roll-forward */
  taxPayableOpen: '', payRows: 6,
  /* indirect tax */
  gstRate: 9, stdRatedPct: 100, claimablePct: 100, gstVarPct: 10, outputTaxClient: '', inputTaxClient: '', purchasesOverride: '',
  /* prior year assessment */
  pyProvision: '', noaAmount: '', noaDate: '', noaSighted: '', pyAdjRecorded: '', pyAdjBooked: ''
});

/* exemption tiers "10000:75,190000:50" → [{band, pct}] */
function tiers(cfg) {
  return String(cfg.exemptTiers || '').split(/[,;]\s*/).map(x => x.trim()).filter(Boolean).map(x => { const [b, p] = x.split(':').map(Number); return { band: b || 0, pct: p || 0 }; }).filter(x => x.band > 0);
}
function exemption(ci, T) {
  let rem = Math.max(0, ci), ex = 0; const rows = [];
  for (const t of T) { const slice = Math.min(rem, t.band); const e = slice * t.pct / 100; rows.push({ ...t, slice: r2(slice), exempt: r2(e) }); ex += e; rem -= slice; }
  return { exempt: r2(ex), rows };
}
const kf = s => Core.keyify(s || '') || 'none';

/* ============================================================ COMPUTE */
function compute(recs, cfg, eng) {
  const pm = eng.materiality?.pm || 0, trivial = eng.materiality?.trivial || 0;
  const tol = Number(cfg.castTol) || 0.01;
  const rate = n0(cfg.taxRate) / 100;
  const live = recs.filter(r => !r.__excluded);
  const regShape = live.some(r => r.additions != null || r.cost_open != null) || (live.some(r => r.asset_id != null) && !live.some(r => r.balance != null || r.debit != null || r.credit != null));
  const mode = regShape ? 'register' : 'tb';

  /* ---- trial balance: classify every line ----------------------------- */
  const sums = Object.fromEntries(CLASSES.map(c => [c.id, 0])), sumsPY = Object.fromEntries(CLASSES.map(c => [c.id, 0]));
  let tbNet = 0, plCount = 0, overridden = 0;
  for (const r of recs) {
    if (mode === 'tb') {
      r.__bal = r.balance != null ? r.balance : ((r.debit != null || r.credit != null) ? r2((r.debit || 0) - (r.credit || 0)) : 0);
      r.__displayKey = ((r.code || '') + ' ' + (r.name || '')).trim() || ('row ' + r.__srcRow);
      const auto = classify(r.name, r.__bal);
      const ov = r.__wp?.classify?.cls;
      r.__clsAuto = auto;
      r.__cls = ov && CLASS_LABEL[ov] ? ov : auto;
      r.__overridden = !!(ov && CLASS_LABEL[ov] && ov !== auto);
      r.__side = CLASS_SIDE[r.__cls];
      r.__sideLabel = r.__side === 'pl' ? 'Profit or loss' : 'Balance sheet';
      r.__clsLabel = CLASS_LABEL[r.__cls];
      r.__nbv = null;
      if (r.__excluded) continue;
      sums[r.__cls] += r.__bal; sumsPY[r.__cls] += r.balance_py || 0; tbNet += r.__bal;
      if (r.__side === 'pl') plCount++;
      if (r.__overridden) overridden++;
    } else {
      r.__displayKey = r.asset_id || ('row ' + r.__srcRow);
      r.__bal = null; r.__cls = null; r.__clsLabel = ''; r.__sideLabel = '';
      r.__cost_close = r.cost_close != null ? r.cost_close : r2((r.cost_open || 0) + (r.additions || 0) - (r.disposals || 0));
      r.__nbv = r.nbv_close != null ? r.nbv_close : (r.accdep_close != null ? r2(r.__cost_close - r.accdep_close) : null);
    }
  }
  for (const k of Object.keys(sums)) { sums[k] = r2(sums[k]); sumsPY[k] = r2(sumsPY[k]); }
  const plSum = CLASSES.filter(c => c.side === 'pl' && c.id !== 'taxExpense').reduce((s, c) => s + sums[c.id], 0);
  const tb = mode === 'tb' ? {
    pbt: r2(-plSum), revenue: r2(-(sums.revenue)), otherIncome: r2(-sums.otherIncome), cogs: sums.cogs,
    depreciation: sums.depreciation, amortisation: sums.amortisation, impairment: sums.impairment, entertainment: sums.entertainment, donation: sums.donation, fines: sums.fines,
    interest: sums.interest, staff: sums.staff, otherExpense: sums.otherExpense,
    taxExpense: sums.taxExpense, taxProvision: r2(-sums.taxProvision), deferredTax: r2(-sums.deferredTax), gst: r2(-sums.gst),
    taxProvisionPY: r2(-sumsPY.taxProvision), deferredTaxPY: r2(-sumsPY.deferredTax), gstPY: r2(-sumsPY.gst), taxExpensePY: sumsPY.taxExpense,
    net: r2(tbNet), plCount, overridden, lines: live.length, hasPY: live.some(r => r.balance_py != null)
  } : null;

  /* ---- W3.2 capital allowances ---------------------------------------- */
  let unit = cfg.lifeUnit;
  if (unit === 'auto') { const vals = live.map(r => r.life).filter(v => v > 0); unit = vals.length && vals.filter(v => v > 30).length / vals.length > 0.5 ? 'months' : 'years'; }
  const cats = {};
  if (mode === 'register') {
    for (const r of live) {
      const c = r.category || '(uncategorised)';
      /* group on the normalised key so "Computers and IT" / "COMPUTERS AND IT"
         (DQ-12 case noise in the client file) are one category, not two rows
         that share a key and both pick up the same auditor input */
      const k = kf(c) || 'uncategorised';
      const o = cats[k] || (cats[k] = { category:c, key:k, count:0, additions:0, costOpen:0, costClose:0, disposals:0, nbv:0, lives:[], source:'register' });
      o.count++; o.additions += Math.max(0, r.additions || 0); o.costOpen += r.cost_open || 0; o.costClose += r.__cost_close || 0; o.disposals += r.disposals || 0; o.nbv += r.__nbv || 0;
      const ly = unit === 'months' ? (r.life || 0) / 12 : (r.life || 0);
      if (ly > 0) o.lives.push(ly);
    }
  } else {
    const n = Math.max(0, Math.min(30, Math.round(Number(cfg.caRows) || 0)));
    for (let i = 1; i <= n; i++) {
      const k = 'ca' + i, name = txt(cfg, 'caCategory', k);
      if (!name && inp(cfg, 'caAdditions', k) == null && inp(cfg, 'caNBV', k) == null) continue;
      const c = name || ('Category ' + i);
      cats[c] = { category:c, key:kf(c) + '_' + i, row:k, count:null, additions: n0(inp(cfg, 'caAdditions', k)), costOpen: n0(inp(cfg, 'caCostBF', k)), costClose: null, disposals:0, nbv: inp(cfg, 'caNBV', k), lives:[], source:'input' };
    }
  }
  const caRows = Object.values(cats).sort((a, b) => a.category.localeCompare(b.category)).map(c => {
    const basis = txt(cfg, 'caBasis', c.key) || cfg.caDefaultBasis || '3-year';
    const lifeIn = inp(cfg, 'caLife', c.key);
    const life = lifeIn != null ? lifeIn : (c.lives.length ? mode_(c.lives) : null);
    const bf = n0(inp(cfg, 'caBF', c.key)), balancing = n0(inp(cfg, 'caBalancing', c.key));
    let cy = 0;
    if (basis === '1-year') cy = c.additions;
    else if (basis === '3-year') cy = c.additions / 3;
    else if (basis === 'working life') cy = life > 0 ? c.additions / life : 0;
    const total = r2(cy + bf + balancing);
    const wdvOpen = inp(cfg, 'caWDVOpen', c.key);
    const wdvClose = wdvOpen != null ? r2(wdvOpen + c.additions - (basis === 'not qualifying' ? 0 : total)) : null;
    return { ...c, additions: r2(c.additions), costOpen: r2(c.costOpen), costClose: c.costClose != null ? r2(c.costClose) : null, nbv: c.nbv != null ? r2(c.nbv) : null,
      basis, life, cyAllowance: r2(cy), bf, balancing, total, wdvOpen, wdvClose,
      tempDiff: (c.nbv != null && wdvClose != null) ? r2(c.nbv - wdvClose) : null, noBasisLife: basis === 'working life' && !(life > 0) && c.additions > 0 };
  });
  const ca = { rows: caRows, mode, lifeUnit: unit,
    additions: r2(caRows.reduce((s, c) => s + c.additions, 0)), cyAllowance: r2(caRows.reduce((s, c) => s + c.cyAllowance, 0)),
    bf: r2(caRows.reduce((s, c) => s + c.bf, 0)), balancing: r2(caRows.reduce((s, c) => s + c.balancing, 0)),
    total: r2(caRows.reduce((s, c) => s + c.total, 0)), nbv: r2(caRows.reduce((s, c) => s + (c.nbv || 0), 0)) };

  /* ---- W3.1 current tax computation ----------------------------------- */
  const pick = (ovKey, tbVal) => num(cfg[ovKey]) != null ? { v: num(cfg[ovKey]), src:'input' } : (tbVal != null ? { v: tbVal, src:'TB' } : { v: 0, src:'not entered' });
  const pbt = pick('pbtOverride', tb?.pbt);
  const dep = pick('addDepreciation', tb?.depreciation), amort = pick('addAmortisation', tb?.amortisation), prov = pick('addProvisions', tb?.impairment);
  const entBase = pick('addEntertainment', tb?.entertainment); const entAdd = r2(entBase.v * n0(cfg.entPct) / 100);
  const don = pick('addDonations', tb?.donation), fin = pick('addFines', tb?.fines);
  const caUsed = num(cfg.caOverride) != null ? { v: num(cfg.caOverride), src:'input' } : { v: ca.total, src:'W3.2' };
  const nA = Math.max(0, Math.min(30, Math.round(Number(cfg.adjRows) || 0)));
  const adj = [];
  for (let i = 1; i <= nA; i++) { const k = 'adj' + i, a = inp(cfg, 'adjAmount', k), dsc = txt(cfg, 'adjDesc', k); if (a == null && !dsc) continue; adj.push({ key:k, i, desc:dsc, amount: n0(a), ref: txt(cfg, 'adjRef', k) }); }
  const adjTotal = r2(adj.reduce((s, x) => s + x.amount, 0));
  const addBacks = r2(dep.v + amort.v + prov.v + entAdd + don.v + fin.v);
  const exemptIncome = n0(cfg.exemptIncome);
  const adjustedProfit = r2(pbt.v + addBacks + adjTotal - exemptIncome - caUsed.v);
  const lossesBF = Math.max(0, n0(cfg.lossesBF));
  const lossesUsed = r2(Math.min(lossesBF, Math.max(0, adjustedProfit)));
  const ci = r2(Math.max(0, adjustedProfit - lossesUsed));
  const lossesCF = r2(lossesBF - lossesUsed + Math.max(0, -adjustedProfit));
  const T = tiers(cfg);
  const ex = exemption(ci, T);
  const taxable = r2(Math.max(0, ci - ex.exempt));
  const grossTax = r2(taxable * rate);
  const rebate = r2(Math.min(grossTax * n0(cfg.rebatePct) / 100, n0(cfg.rebateCap) > 0 ? n0(cfg.rebateCap) : Infinity) || 0);
  const taxCharge = r2(grossTax - rebate);
  const tbCurrentTax = pick('tbCurrentTax', tb?.taxExpense);
  const comp = { pbt, dep, amort, prov, entBase, entPct: n0(cfg.entPct), entAdd, don, fin, adj, adjTotal, addBacks, exemptIncome, caUsed, adjustedProfit,
    lossesBF, lossesUsed, lossesCF, ci, tiers: T, exemptRows: ex.rows, exempt: ex.exempt, taxable, rate: n0(cfg.taxRate), grossTax, rebate, taxCharge,
    tbCurrentTax, diff: r2(taxCharge - tbCurrentTax.v), effectiveRate: pbt.v ? r2(taxCharge / Math.abs(pbt.v) * 100) : null };

  /* ---- W3.3 deferred tax ----------------------------------------------- */
  const dtCats = caRows.filter(c => c.tempDiff != null).map(c => ({ key:c.key, label:c.category, tempDiff:c.tempDiff, dt: r2(c.tempDiff * rate), source:'W3.2' }));
  const nD = Math.max(0, Math.min(20, Math.round(Number(cfg.dtRows) || 0)));
  const dtOther = [];
  for (let i = 1; i <= nD; i++) { const k = 'dt' + i, a = inp(cfg, 'dtAmount', k), dsc = txt(cfg, 'dtDesc', k); if (a == null && !dsc) continue; dtOther.push({ key:k, i, desc:dsc, tempDiff: n0(a), dt: r2(n0(a) * rate) }); }
  const lossDTA = cfg.recogniseLossDTA === 'Y' ? r2(-lossesCF * rate) : 0;
  const dtAudit = r2(dtCats.reduce((s, x) => s + x.dt, 0) + dtOther.reduce((s, x) => s + x.dt, 0) + lossDTA);
  const tbDT = pick('tbDeferredTax', tb?.deferredTax);
  const dtPY = num(cfg.dtPY) != null ? { v: num(cfg.dtPY), src:'input' } : (tb?.hasPY ? { v: tb.deferredTaxPY, src:'TB' } : { v: 0, src:'not entered' });
  const deferred = { cats: dtCats, other: dtOther, lossDTA, lossesCF, audit: dtAudit, tb: tbDT, diff: r2(dtAudit - tbDT.v), py: dtPY, movement: r2(dtAudit - dtPY.v),
    tempDiffTotal: r2(dtCats.reduce((s, x) => s + x.tempDiff, 0) + dtOther.reduce((s, x) => s + x.tempDiff, 0)) };

  /* ---- W3.6 prior year assessment ------------------------------------- */
  const pyProv = num(cfg.pyProvision) != null ? { v: num(cfg.pyProvision), src:'input' } : (tb?.hasPY ? { v: tb.taxProvisionPY, src:'TB' } : { v: null, src:'not entered' });
  const noa = num(cfg.noaAmount);
  const pyDiff = (noa != null && pyProv.v != null) ? r2(noa - pyProv.v) : null;       // positive = under-provided in PY
  const pyBooked = num(cfg.pyAdjBooked);
  const prior = { provision: pyProv, noa, noaDate: cfg.noaDate || '', sighted: cfg.noaSighted || '', diff: pyDiff, recorded: cfg.pyAdjRecorded || '', booked: pyBooked,
    unrecorded: pyDiff != null && Math.abs(pyDiff) > tol && cfg.pyAdjRecorded !== 'Y', bookedDiff: (pyDiff != null && pyBooked != null) ? r2(pyBooked - pyDiff) : null };

  /* ---- W3.4 tax payable roll-forward ---------------------------------- */
  const open = num(cfg.taxPayableOpen) != null ? { v: num(cfg.taxPayableOpen), src:'input' } : (tb?.hasPY ? { v: tb.taxProvisionPY, src:'TB' } : { v: 0, src:'not entered' });
  const nP = Math.max(0, Math.min(30, Math.round(Number(cfg.payRows) || 0)));
  const pays = [];
  for (let i = 1; i <= nP; i++) { const k = 'pay' + i, a = inp(cfg, 'payAmount', k); if (a == null && !txt(cfg, 'payRef', k) && !txt(cfg, 'payDate', k)) continue;
    pays.push({ key:k, i, date: txt(cfg, 'payDate', k), ref: txt(cfg, 'payRef', k), amount: n0(a), vouched: txt(cfg, 'payVouched', k), yaLabel: txt(cfg, 'payYA', k) }); }
  const paid = r2(pays.reduce((s, x) => s + x.amount, 0));
  const pyAdj = prior.recorded === 'Y' && pyDiff != null ? pyDiff : 0;
  const closeAudit = r2(open.v + taxCharge + pyAdj - paid);
  const tbProv = pick('tbTaxProvision', tb?.taxProvision);
  const payable = { open, charge: taxCharge, pyAdj, pays, paid, closeAudit, tb: tbProv, diff: r2(closeAudit - tbProv.v), unvouched: pays.filter(x => x.vouched !== 'Y') };

  /* ---- W3.5 indirect tax ---------------------------------------------- */
  const gRate = n0(cfg.gstRate) / 100;
  const revenue = pick('tbRevenue', tb?.revenue);
  const purchases = num(cfg.purchasesOverride) != null ? { v: num(cfg.purchasesOverride), src:'input' } : (tb ? { v: r2(tb.cogs + tb.otherExpense), src:'TB (cost of sales + other operating expenses)' } : { v: 0, src:'not entered' });
  const expOut = r2(revenue.v * n0(cfg.stdRatedPct) / 100 * gRate), expIn = r2(purchases.v * n0(cfg.claimablePct) / 100 * gRate);
  const outC = num(cfg.outputTaxClient), inC = num(cfg.inputTaxClient);
  const varPct = (e, c) => (c != null && e) ? r2((c - e) / Math.abs(e) * 100) : null;
  const tbGst = pick('tbGst', tb?.gst);
  const indirect = { rate: n0(cfg.gstRate), revenue, purchases, expOut, expIn, outC, inC, outDiff: outC != null ? r2(outC - expOut) : null, inDiff: inC != null ? r2(inC - expIn) : null,
    outVarPct: varPct(expOut, outC), inVarPct: varPct(expIn, inC), netClient: (outC != null && inC != null) ? r2(outC - inC) : null, netExpected: r2(expOut - expIn), tb: tbGst,
    threshold: n0(cfg.gstVarPct) };
  indirect.netDiff = indirect.netClient != null ? r2(indirect.netClient - tbGst.v) : null;
  indirect.outFlag = indirect.outVarPct != null && Math.abs(indirect.outVarPct) > indirect.threshold && Math.abs(indirect.outDiff) > trivial;
  indirect.inFlag = indirect.inVarPct != null && Math.abs(indirect.inVarPct) > indirect.threshold && Math.abs(indirect.inDiff) > trivial;

  /* ---- W3 lead --------------------------------------------------------- */
  const lead = [
    { key:'current', label:'Current tax expense', audit: taxCharge, tb: tbCurrentTax.v, src: tbCurrentTax.src, py: tb?.hasPY ? tb.taxExpensePY : null },
    { key:'deferredExp', label:'Deferred tax expense / (credit)', audit: deferred.movement, tb: null, src:'', py: null },
    { key:'provision', label:'Provision for taxation (liability)', audit: closeAudit, tb: tbProv.v, src: tbProv.src, py: open.src === 'TB' ? open.v : null },
    { key:'deferred', label:'Deferred tax liability / (asset)', audit: dtAudit, tb: tbDT.v, src: tbDT.src, py: dtPY.src === 'TB' ? dtPY.v : null },
    { key:'gst', label:'Indirect tax payable', audit: indirect.netClient, tb: tbGst.v, src: tbGst.src, py: tb?.hasPY ? tb.gstPY : null }
  ].map(l => ({ ...l, diff: (l.audit != null && l.tb != null) ? r2(l.audit - l.tb) : null, movement: (l.tb != null && l.py != null) ? r2(l.tb - l.py) : null }));

  return { mode, tb, ca, comp, deferred, prior, payable, indirect, lead, pm, trivial, tol,
    plLines: live.filter(r => r.__side === 'pl'), bsLines: live.filter(r => r.__side === 'bs'), classes: CLASSES };
}
function mode_(arr) { const m = new Map(); let best = arr[0], bc = 0; for (const v of arr) { const c = (m.get(v) || 0) + 1; m.set(v, c); if (c > bc) { bc = c; best = v; } } return best; }

/* ============================================================== TESTS */
const above = (d, v) => Math.abs(v) > (d.tol || 0.01);
const tests = [
  { id:'EX-TAX-01', scope:'population', label:'Current tax per the computation differs from the tax expense recorded', basis:'W3.1',
    fn:(recs, cfg, eng, d) => d.comp.tbCurrentTax.src !== 'not entered' && above(d, d.comp.diff) &&
      { key:'Current tax', expected:d.comp.taxCharge, actual:d.comp.tbCurrentTax.v, difference:-d.comp.diff,
        detail:`Chargeable income ${d.comp.ci.toFixed(2)} less exemption ${d.comp.exempt.toFixed(2)} at ${d.comp.rate}% = ${d.comp.taxCharge.toFixed(2)}; recorded ${d.comp.tbCurrentTax.v.toFixed(2)} (${d.comp.tbCurrentTax.src})` } },
  { id:'EX-TAX-02', scope:'population', label:'Deferred tax per the temporary differences differs from the balance recorded', basis:'W3.3',
    fn:(recs, cfg, eng, d) => d.deferred.tb.src !== 'not entered' && (d.deferred.cats.length || d.deferred.other.length || d.deferred.lossDTA) && above(d, d.deferred.diff) &&
      { key:'Deferred tax', expected:d.deferred.audit, actual:d.deferred.tb.v, difference:-d.deferred.diff, detail:`Temporary differences ${d.deferred.tempDiffTotal.toFixed(2)} × ${d.comp.rate}%${d.deferred.lossDTA ? ' plus deferred tax asset on losses ' + d.deferred.lossDTA.toFixed(2) : ''}` } },
  { id:'EX-TAX-03', scope:'population', label:'Tax payable roll-forward does not agree to the provision recorded', basis:'W3.4',
    fn:(recs, cfg, eng, d) => d.payable.tb.src !== 'not entered' && d.payable.open.src !== 'not entered' && above(d, d.payable.diff) &&
      { key:'Provision for taxation', expected:d.payable.closeAudit, actual:d.payable.tb.v, difference:-d.payable.diff,
        detail:`Opening ${d.payable.open.v.toFixed(2)} + charge ${d.payable.charge.toFixed(2)} ${d.payable.pyAdj ? '+ prior year adjustment ' + d.payable.pyAdj.toFixed(2) + ' ' : ''}− payments ${d.payable.paid.toFixed(2)} = ${d.payable.closeAudit.toFixed(2)}` } },
  { id:'EX-TAX-04', scope:'population', label:'Indirect tax per returns is not consistent with revenue or purchases', basis:'W3.5',
    fn:(recs, cfg, eng, d) => { const out = [];
      if (d.indirect.outFlag) out.push({ key:'Output tax', expected:d.indirect.expOut, actual:d.indirect.outC, difference:d.indirect.outDiff, detail:`Revenue ${d.indirect.revenue.v.toFixed(2)} × ${cfg.stdRatedPct}% standard-rated × ${d.indirect.rate}% = ${d.indirect.expOut.toFixed(2)}; per returns ${d.indirect.outC.toFixed(2)} (${d.indirect.outVarPct}%)` });
      if (d.indirect.inFlag) out.push({ key:'Input tax', expected:d.indirect.expIn, actual:d.indirect.inC, difference:d.indirect.inDiff, detail:`Purchases ${d.indirect.purchases.v.toFixed(2)} × ${cfg.claimablePct}% claimable × ${d.indirect.rate}% = ${d.indirect.expIn.toFixed(2)}; per returns ${d.indirect.inC.toFixed(2)} (${d.indirect.inVarPct}%)` });
      return out.length ? out : false; } },
  { id:'EX-TAX-05', scope:'population', label:'Prior year assessment differs from the provision and the adjustment is not recorded', basis:'W3.6',
    fn:(recs, cfg, eng, d) => d.prior.unrecorded && { key:'Prior year assessment', expected:d.prior.noa, actual:d.prior.provision.v, difference:d.prior.diff,
      detail:`Notice of assessment ${d.prior.noa.toFixed(2)} vs provision brought forward ${d.prior.provision.v.toFixed(2)}: ${d.prior.diff > 0 ? 'under' : 'over'}-provision of ${Math.abs(d.prior.diff).toFixed(2)} not recorded in the current year` } },
  { id:'EX-TAX-06', scope:'population', label:'Tax payment not vouched', basis:'W3.4', severity:'informational',
    fn:(recs, cfg, eng, d) => d.payable.unvouched.map(x => ({ key:`Payment ${x.ref || ('line ' + x.i)}`, actual:x.amount, difference:x.amount, detail:'Payment entered on the roll-forward not yet vouched to the receipt or bank statement' })) },
  { id:'EX-TAX-07', scope:'population', label:'Capital allowance basis needs a prescribed life', basis:'W3.2', severity:'informational',
    fn:(recs, cfg, eng, d) => d.ca.rows.filter(c => c.noBasisLife).map(c => ({ key:c.category, difference:c.additions, detail:'Working-life basis selected but no life is available — enter the prescribed working life' })) },
  { id:'EX-TAX-08', scope:'population', label:'Trial balance uploaded does not net to nil', basis:'W3.0c', severity:'informational',
    fn:(recs, cfg, eng, d) => d.mode === 'tb' && d.tb && Math.abs(d.tb.net) > Math.max(1, d.tol) && { key:'Trial balance', actual:d.tb.net, difference:d.tb.net, detail:'Debits and credits do not net to nil — confirm the extract is complete before relying on the computation' } },
  { id:'EX-TAX-09', label:'Tax classification overridden by the auditor', basis:'W3.0c', severity:'informational',
    fn:(r) => r.__overridden && { actual:CLASS_LABEL[r.__cls], expected:CLASS_LABEL[r.__clsAuto], difference:r.__bal, cell:r['__cell_name'], detail:`Reclassified from "${CLASS_LABEL[r.__clsAuto]}" to "${CLASS_LABEL[r.__cls]}" for the computation` } }
];

/* ============================================================== PAGES */
const src = s => s.src === 'input' ? 'Auditor input' : s.src === 'TB' ? 'Per trial balance' : s.src === 'W3.2' ? 'Per W3.2' : s.src === 'not entered' ? 'Not entered' : s.src;
const flagDiff = (v) => v != null && Math.abs(v) > 0.01;

const pages = [
  { id:'source',  ref:'W3.0',  title:'Source data',     kind:'source' },
  { id:'cleaned', ref:'W3.0a', title:'Cleaned listing', kind:'cleaned' },
  { id:'mapping', ref:'W3.0b', title:'Column mapping',  kind:'mapping' },

  { id:'classify', ref:'W3.0c', title:'Tax classification of the trial balance',
    objective:'To classify every trial balance line for the purposes of the tax computation — revenue, deductible and non-deductible expenses, tax captions — so that the computation is built from the ledger rather than from the client\'s own working.',
    procedures:['Classified each profit or loss line by nature (revenue, cost of sales, staff, depreciation, provisions, entertainment, finance costs, other) and each balance sheet tax caption (provision for taxation, deferred tax, indirect tax).',
                'Reviewed the automatic classification and overrode it where the account name was ambiguous.'],
    render(st, ctx) {
      const d = ctx.d, m0 = ctx.money0;
      if (d.mode === 'register') return [{ type:'note', tone:'warn', html:'<b>A fixed asset register was uploaded</b>, so there is no trial balance to classify. The capital allowance schedule (W3.2) is built from the register; enter the accounting profit and the tax captions on W3.1 to W3.5.' }];
      const opts = CLASSES.map(c => c.id);
      const rows = (recs) => recs.map(r => ({ __rec:r, code:r.code, name:r.name, bal:r.__bal, py:r.balance_py, auto:CLASS_LABEL[r.__clsAuto], cls:r.__clsLabel, __cls: r.__overridden ? 'flag' : '' }));
      const cols = [{ key:'code', label:'Code' }, { key:'name', label:'Account name', wrap:true }, { key:'bal', label:'Balance (Dr +)', type:'num', sum:true }, { key:'py', label:'Prior year', type:'num' },
        { key:'auto', label:'Classified as', type:'chip', chipClass: v => /add back|non-deductible/.test(v) ? 'warn' : /Revenue|income/.test(v) ? 'info' : 'grey' },
        { key:'cls', label:'Override (auditor)', input:'select', options:opts }, { key:'comment', label:'Comment', input:'text', wide:true }];
      return [
        { type:'stats', items:[
          { label:'Lines', value: d.tb.lines }, { label:'Profit or loss lines', value: d.tb.plCount }, { label:'Overridden', value: d.tb.overridden },
          { label:'TB nets to', value: ctx.money(d.tb.net), cls: Math.abs(d.tb.net) > 1 ? 'bad' : 'ok' },
          { label:'Revenue', value: m0(d.tb.revenue) }, { label:'Profit / (loss) before tax', value: ctx.money(d.tb.pbt), cls: d.tb.pbt < 0 ? 'warn' : '' },
          { label:'Depreciation and amortisation', value: m0(r2(d.tb.depreciation + d.tb.amortisation)) }, { label:'Provisions / impairment', value: m0(d.tb.impairment) } ] },
        { type:'note', html:'Balances are shown debit positive. The override column stores the class id (e.g. <code>depreciation</code>, <code>otherExpense</code>, <code>bs</code>); an override is raised as EX-TAX-09 so the reviewer sees every judgement.' },
        { type:'table', title:'Profit or loss lines', columns: cols, rows: rows(d.plLines), maxHeight:'60vh', emptyText:'No profit or loss lines recognised — check the column mapping.' },
        { type:'table', title:'Balance sheet lines', columns: cols, rows: rows(d.bsLines), maxHeight:'50vh' }
      ];
    },
    flag(st, d) { return d.mode === 'tb' && d.tb && Math.abs(d.tb.net) > 1; } },

  { id:'lead', ref:'W3', title:'Lead schedule',
    objective:'To agree the tax expense, provision for taxation, deferred tax and indirect tax balances to the trial balance, compare them to the audited recomputation, and explain the movement against the prior year.',
    procedures:['Agreed each tax caption per the trial balance to the recomputed figure on the supporting working papers (W3.1 to W3.5).',
                'Compared closing balances to the prior year and explained the movements by reference to the charge, payments and assessments.'],
    render(st, ctx) {
      const d = ctx.d, money = ctx.money;
      return [
        { type:'note', html:`<b>Source: ${d.mode === 'tb' ? 'trial balance uploaded' : 'fixed asset register uploaded'}.</b> Tax captions ${d.mode === 'tb' ? 'are read from the trial balance and can be overridden below' : 'must be entered below'}. The "per audit" column is the recomputation on W3.1 (current tax), W3.3 (deferred tax), W3.4 (provision) and W3.5 (indirect tax).` },
        { type:'controls', items:[
          { key:'tbCurrentTax', label:'Current tax expense per TB (override)', kind:'number' },
          { key:'tbTaxProvision', label:'Provision for taxation per TB (override, liability positive)', kind:'number' },
          { key:'tbDeferredTax', label:'Deferred tax per TB (override, liability positive)', kind:'number' },
          { key:'tbGst', label:'Indirect tax payable per TB (override)', kind:'number' },
          { key:'castTol', label:'Tolerance', kind:'number' } ] },
        { type:'table', title:'Tax captions — per audit, per trial balance, prior year', columns:[
          { key:'label', label:'Caption', emphasis:true }, { key:'audit', label:'Per audit', type:'num' }, { key:'tb', label:'Per trial balance', type:'num' }, { key:'src', label:'Source' },
          { key:'diff', label:'Difference', type:'num', flag: flagDiff }, { key:'py', label:'Prior year', type:'num' }, { key:'movement', label:'Movement', type:'num' },
          { key:'explanation', label:'Explanation of movement', input:'text', wide:true } ],
          rows: d.lead.map(l => ({ __key:l.key, ...l, src: src({ src:l.src }), __cls: flagDiff(l.diff) ? 'flag' : '' })), totals:false,
          footnote:'Differences above the tolerance are raised as EX-TAX-01 (current tax), EX-TAX-02 (deferred tax) and EX-TAX-03 (provision).' },
        { type:'stats', items:[
          { label:'Profit / (loss) before tax', value: money(d.comp.pbt.v) }, { label:'Chargeable income', value: money(d.comp.ci) },
          { label:'Current tax per audit', value: money(d.comp.taxCharge) }, { label:'Effective rate on accounting profit', value: d.comp.effectiveRate == null ? '' : ctx.pct(d.comp.effectiveRate) },
          { label:'Deferred tax per audit', value: money(d.deferred.audit) }, { label:'Total tax expense per audit', value: money(r2(d.comp.taxCharge + d.deferred.movement)) } ] }
      ];
    },
    flag(st, d) { return d.lead.some(l => flagDiff(l.diff)); } },

  { id:'comp', ref:'W3.1', title:'Current tax computation',
    objective:'To recompute the current tax charge for the year from the accounting profit, adjusting for non-deductible expenses, exempt income, capital allowances, losses and the exemptions and rebates available, and to compare the result to the charge recorded.',
    procedures:['Started from the profit before tax per the trial balance and added back depreciation, amortisation, provisions and impairment, the non-deductible portion of entertainment, donations, fines and other adjustments identified.',
                'Deducted capital allowances per W3.2, exempt income and losses brought forward to arrive at chargeable income.',
                'Applied the partial exemption tiers and the corporate rate configured, deducted rebates, and compared the charge to the tax expense recorded.'],
    render(st, ctx) {
      const d = ctx.d, C = d.comp, money = ctx.money, cfg = ctx.cfg;
      const line = (label, v, s, cls) => ({ label, amount: v, source: s ? src(s) : '', __cls: cls || '' });
      const rows = [
        line('Profit / (loss) before tax', C.pbt.v, C.pbt, 'em'),
        line('Add: depreciation', C.dep.v, C.dep), line('Add: amortisation', C.amort.v, C.amort), line('Add: provisions, impairment and write-downs', C.prov.v, C.prov),
        line(`Add: entertainment ${money(C.entBase.v)} × ${C.entPct}% non-deductible`, C.entAdd, C.entBase), line('Add: donations', C.don.v, C.don), line('Add: fines and penalties', C.fin.v, C.fin),
        ...C.adj.map(a => line(`${a.amount >= 0 ? 'Add' : 'Less'}: ${a.desc || 'adjustment ' + a.i}${a.ref ? ' (' + a.ref + ')' : ''}`, a.amount, { src:'input' })),
        line('Less: exempt income', -C.exemptIncome, { src:'input' }), line('Less: capital allowances', -C.caUsed.v, C.caUsed),
        line('Adjusted profit / (loss)', C.adjustedProfit, null, 'em'), line('Less: unutilised losses brought forward utilised', -C.lossesUsed, { src:'input' }),
        line('Chargeable income', C.ci, null, 'em'),
        ...C.exemptRows.map(t => line(`Less: exemption — ${t.pct}% of the next ${money(t.band)} (${money(t.slice)})`, -t.exempt, null)),
        line('Taxable income after exemption', C.taxable, null, 'em'), line(`Tax at ${C.rate}%`, C.grossTax, null), line('Less: rebate', -C.rebate, null),
        line('Current tax charge per audit', C.taxCharge, null, 'em'), line('Current tax expense recorded', C.tbCurrentTax.v, C.tbCurrentTax), line('Difference', C.diff, null, flagDiff(C.diff) ? 'flag' : 'em')
      ];
      const adjRows = []; const n = Math.max(0, Math.min(30, Math.round(Number(cfg.adjRows) || 0)));
      for (let i = 1; i <= n; i++) adjRows.push({ __key:'adj' + i, line:i });
      return [
        { type:'controls', items:[
          { key:'taxRate', label:'Corporate tax rate %', kind:'number' },
          { key:'exemptTiers', label:'Partial exemption tiers (band:percent, cumulative)', kind:'text', help:'e.g. 10000:75,190000:50 — 75% of the first 10,000 and 50% of the next 190,000. Blank for none.' },
          { key:'rebatePct', label:'Tax rebate % of tax payable', kind:'number' }, { key:'rebateCap', label:'Rebate cap (0 = none)', kind:'number' },
          { key:'entPct', label:'Non-deductible % of entertainment', kind:'number' },
          { key:'pbtOverride', label:'Profit before tax (override TB)', kind:'number' },
          { key:'addDepreciation', label:'Depreciation (override TB)', kind:'number' }, { key:'addAmortisation', label:'Amortisation (override TB)', kind:'number' },
          { key:'addProvisions', label:'Provisions / impairment (override TB)', kind:'number' }, { key:'addEntertainment', label:'Entertainment expense (override TB)', kind:'number' },
          { key:'addDonations', label:'Donations (override TB)', kind:'number' }, { key:'addFines', label:'Fines and penalties (override TB)', kind:'number' },
          { key:'exemptIncome', label:'Exempt / non-taxable income', kind:'number' }, { key:'caOverride', label:'Capital allowances (override W3.2)', kind:'number' },
          { key:'lossesBF', label:'Unutilised losses brought forward', kind:'number' }, { key:'tbCurrentTax', label:'Current tax expense recorded (override TB)', kind:'number' },
          { key:'adjRows', label:'Further adjustment lines', kind:'number' } ] },
        { type:'table', title:'Further adjustments (positive = add back, negative = deduct)', columns:[
          { key:'line', label:'#', type:'int' }, { key:'adjDesc', label:'Description', input:'text', wide:true }, { key:'adjAmount', label:'Amount', input:'number' }, { key:'adjRef', label:'Reference / basis', input:'text', wide:true } ],
          rows: adjRows, totals:false },
        { type:'table', title:'Computation', columns:[
          { key:'label', label:'', emphasis:true, wrap:true }, { key:'amount', label:'Amount', type:'num', flag:(v, row) => row.__cls === 'flag' }, { key:'source', label:'Source' } ], rows, totals:false,
          footnote:'Every figure marked "Per trial balance" is the sum of the lines classified on W3.0c; override it above where the tax base differs from the ledger. Loss carried forward after this year: ' + money(C.lossesCF) + '.' },
        { type:'stats', items:[
          { label:'Chargeable income', value: money(C.ci) }, { label:'Exemption', value: money(C.exempt) }, { label:'Current tax per audit', value: money(C.taxCharge) },
          { label:'Recorded', value: C.tbCurrentTax.src === 'not entered' ? 'Not entered' : money(C.tbCurrentTax.v) },
          { label:'Difference', value: money(C.diff), cls: flagDiff(C.diff) ? 'bad' : 'ok' }, { label:'Losses carried forward', value: money(C.lossesCF) } ] }
      ];
    },
    flag(st, d) { return d.comp.tbCurrentTax.src !== 'not entered' && flagDiff(d.comp.diff); } },

  { id:'ca', ref:'W3.2', title:'Capital allowances',
    objective:'To compute the capital allowances claimable on qualifying plant and machinery by category, on the claim basis selected for each category, and to carry the tax written-down values into the deferred tax working.',
    procedures:['Summarised qualifying additions and cost by category from the fixed asset register (or entered them from E3.1 where the trial balance was uploaded).',
                'Selected the claim basis per category (1-year, 3-year straight line, working life or not qualifying) and recomputed the current year allowance, adding allowances brought forward on earlier additions and any balancing allowance or charge.',
                'Rolled the tax written-down value forward from the opening value entered.'],
    render(st, ctx) {
      const d = ctx.d, A = d.ca, m0 = ctx.money0, cfg = ctx.cfg;
      const out = [
        { type:'controls', items:[
          { key:'caDefaultBasis', label:'Default claim basis where none selected', kind:'select', options: CA_BASES },
          ...(A.mode === 'register' ? [{ key:'lifeUnit', label:'Useful life column is in', kind:'select', options:[['auto', `Auto (read as ${A.lifeUnit})`], ['years', 'Years'], ['months', 'Months']] }] : [{ key:'caRows', label:'Category lines available', kind:'number' }]) ] } ];
      if (A.mode !== 'register') {
        const rows = []; const n = Math.max(0, Math.min(30, Math.round(Number(cfg.caRows) || 0)));
        for (let i = 1; i <= n; i++) rows.push({ __key:'ca' + i, line:i });
        out.push({ type:'note', html:'<b>Trial balance uploaded.</b> Enter the qualifying additions, cost brought forward and carrying amount by category from the fixed asset movement schedule (E3.1); the claim basis and allowances are computed below.' });
        out.push({ type:'table', title:'Categories entered from the fixed asset schedule', columns:[
          { key:'line', label:'#', type:'int' }, { key:'caCategory', label:'Category', input:'text', wide:true }, { key:'caAdditions', label:'Qualifying additions', input:'number' },
          { key:'caCostBF', label:'Cost b/f', input:'number' }, { key:'caNBV', label:'Carrying amount c/f', input:'number' } ], rows, totals:false });
      }
      out.push({ type:'stats', items:[
        { label:'Categories', value: A.rows.length }, { label:'Qualifying additions', value: m0(A.additions) }, { label:'Current year allowance', value: m0(A.cyAllowance) },
        { label:'Allowances b/f on earlier additions', value: m0(A.bf) }, { label:'Balancing allowance / (charge)', value: ctx.money(A.balancing) }, { label:'Total capital allowances', value: m0(A.total) } ] });
      out.push({ type:'table', title:'Capital allowance schedule by category', columns:[
        { key:'category', label:'Category' }, { key:'count', label:'Assets', type:'int' }, { key:'costOpen', label:'Cost b/f', type:'num', sum:true }, { key:'additions', label:'Qualifying additions', type:'num', sum:true },
        { key:'caBasis', label:'Claim basis', input:'select', options: CA_BASES.map(b => b[0]) }, { key:'basis', label:'Basis applied' },
        { key:'caLife', label:'Prescribed life (years)', input:'number' }, { key:'life', label:'Life used', type:'num', dp:1 },
        { key:'cyAllowance', label:'Allowance on additions', type:'num', sum:true }, { key:'caBF', label:'Allowance b/f on earlier additions', input:'number' },
        { key:'caBalancing', label:'Balancing allowance / (charge)', input:'number' }, { key:'total', label:'Total allowance', type:'num', sum:true, emphasis:true },
        { key:'caWDVOpen', label:'Tax WDV b/f', input:'number' }, { key:'wdvClose', label:'Tax WDV c/f', type:'num' }, { key:'nbv', label:'Carrying amount c/f', type:'num' },
        { key:'caComment', label:'Comment', input:'text', wide:true } ],
        rows: A.rows.map(c => ({ __key:c.key, ...c, __cls: c.noBasisLife ? 'flag' : '' })),
        emptyText: A.mode === 'register' ? 'No categories in the register.' : 'Enter at least one category above.',
        footnote:'1-year: 100% of additions. 3-year: one third of additions this year (enter the second and third year claims on earlier additions under "allowance b/f"). Working life: additions ÷ prescribed life. Tax WDV c/f = WDV b/f + additions − allowances claimed; it drives W3.3.' });
      return out;
    },
    flag(st, d) { return d.ca.rows.some(c => c.noBasisLife); } },

  { id:'deferred', ref:'W3.3', title:'Deferred tax',
    objective:'To recompute deferred tax from the temporary differences between carrying amounts and tax written-down values, other temporary differences and unutilised losses, and to compare the balance and the movement to the amounts recorded.',
    procedures:['Compared the carrying amount of each asset category to its tax written-down value per W3.2 and applied the tax rate to the temporary difference.',
                'Added other temporary differences entered (provisions deductible when paid, unrealised exchange differences) and considered whether a deferred tax asset on unutilised losses is recognised.',
                'Compared the recomputed balance to the trial balance and derived the deferred tax charge or credit for the year.'],
    render(st, ctx) {
      const d = ctx.d, D = d.deferred, money = ctx.money, cfg = ctx.cfg;
      const rows = []; const n = Math.max(0, Math.min(20, Math.round(Number(cfg.dtRows) || 0)));
      for (let i = 1; i <= n; i++) { const it = D.other.find(x => x.i === i); rows.push({ __key:'dt' + i, line:i, dt: it ? it.dt : null }); }
      return [
        { type:'controls', items:[
          { key:'dtRows', label:'Other temporary difference lines', kind:'number' },
          { key:'recogniseLossDTA', label:'Recognise deferred tax asset on unutilised losses', kind:'select', options:[['N', 'No'], ['Y', 'Yes — probable future taxable profits']] },
          { key:'dtPY', label:'Deferred tax per prior year audited (override TB, liability positive)', kind:'number' },
          { key:'tbDeferredTax', label:'Deferred tax per TB (override, liability positive)', kind:'number' } ] },
        { type:'table', title:'Temporary differences on fixed assets (from W3.2)', columns:[
          { key:'label', label:'Category' }, { key:'tempDiff', label:'Carrying amount − tax WDV', type:'num', sum:true }, { key:'dt', label:`Deferred tax at ${d.comp.rate}%`, type:'num', sum:true } ],
          rows: D.cats.map(c => ({ ...c })), emptyText:'Enter the tax written-down value brought forward on W3.2 for each category to compute the temporary difference.' },
        { type:'table', title:'Other temporary differences (taxable positive, deductible negative)', columns:[
          { key:'line', label:'#', type:'int' }, { key:'dtDesc', label:'Description', input:'text', wide:true }, { key:'dtAmount', label:'Temporary difference', input:'number' },
          { key:'dt', label:`Deferred tax at ${d.comp.rate}%`, type:'num', sum:true }, { key:'dtBasis', label:'Basis / evidence', input:'text', wide:true } ], rows },
        { type:'table', title:'Deferred tax — per audit vs recorded', columns:[
          { key:'label', label:'', emphasis:true }, { key:'amount', label:'Amount', type:'num', flag:(v, row) => row.__cls === 'flag' }, { key:'source', label:'Source' } ],
          rows: [
            { label:'Deferred tax on fixed asset temporary differences', amount: r2(D.cats.reduce((s, x) => s + x.dt, 0)), source:'W3.2' },
            { label:'Deferred tax on other temporary differences', amount: r2(D.other.reduce((s, x) => s + x.dt, 0)), source:'Auditor input' },
            { label:`Deferred tax asset on losses carried forward (${money(D.lossesCF)})`, amount: D.lossDTA, source: cfg.recogniseLossDTA === 'Y' ? 'Recognised' : 'Not recognised' },
            { label:'Deferred tax liability / (asset) per audit', amount: D.audit, source:'', __cls:'em' },
            { label:'Per trial balance', amount: D.tb.v, source: src(D.tb) },
            { label:'Difference', amount: D.diff, source:'', __cls: flagDiff(D.diff) ? 'flag' : 'em' },
            { label:'Prior year audited', amount: D.py.v, source: src(D.py) },
            { label:'Deferred tax charge / (credit) for the year per audit', amount: D.movement, source:'', __cls:'em' } ], totals:false,
          footnote:'A liability is positive; an asset negative. The movement is the deferred tax expense expected in the income statement (EX-TAX-02 on a balance difference).' }
      ];
    },
    flag(st, d) { return d.deferred.tb.src !== 'not entered' && (d.deferred.cats.length || d.deferred.other.length) && flagDiff(d.deferred.diff); } },

  { id:'payable', ref:'W3.4', title:'Tax payable roll-forward',
    objective:'To roll the provision for taxation forward from the opening balance through the current year charge, prior year adjustments and payments to the closing balance, and to vouch payments made in the year.',
    procedures:['Agreed the opening provision to the prior year audited financial statements.',
                'Added the current tax charge per W3.1 and the prior year under / over provision per W3.6; deducted payments made in the year, each vouched to the tax authority receipt or bank statement.',
                'Compared the closing provision per audit to the trial balance.'],
    render(st, ctx) {
      const d = ctx.d, P = d.payable, money = ctx.money, cfg = ctx.cfg;
      const rows = []; const n = Math.max(0, Math.min(30, Math.round(Number(cfg.payRows) || 0)));
      for (let i = 1; i <= n; i++) { const it = P.pays.find(x => x.i === i); rows.push({ __key:'pay' + i, line:i, status: it ? (it.vouched === 'Y' ? 'Vouched' : 'Not vouched') : '', __cls: it && it.vouched !== 'Y' ? 'flag' : '' }); }
      return [
        { type:'controls', items:[
          { key:'taxPayableOpen', label:'Provision for taxation brought forward (override TB prior year)', kind:'number' },
          { key:'tbTaxProvision', label:'Provision per TB at year end (override)', kind:'number' }, { key:'payRows', label:'Payment lines', kind:'number' } ] },
        { type:'table', title:'Payments in the year', columns:[
          { key:'line', label:'#', type:'int' }, { key:'payDate', label:'Date paid', input:'text' }, { key:'payYA', label:'Year of assessment / period', input:'text' }, { key:'payRef', label:'Reference', input:'text' },
          { key:'payAmount', label:'Amount', input:'number' }, { key:'payVouched', label:'Vouched to receipt / bank (Y/N)', input:'select', options:YN },
          { key:'status', label:'Status', type:'chip', chipClass: v => v === 'Vouched' ? 'ok' : 'warn' }, { key:'payComment', label:'Comment', input:'text', wide:true } ], rows,
          footnote:'Payments not marked vouched are listed as EX-TAX-06 (informational).' },
        { type:'table', title:'Roll-forward', columns:[
          { key:'label', label:'', emphasis:true }, { key:'amount', label:'Amount', type:'num', flag:(v, row) => row.__cls === 'flag' }, { key:'source', label:'Source' } ],
          rows: [
            { label:'Provision brought forward', amount: P.open.v, source: src(P.open) },
            { label:'Add: current tax charge for the year (W3.1)', amount: P.charge, source:'W3.1' },
            { label:'Add / (less): prior year under / (over) provision recorded (W3.6)', amount: P.pyAdj, source: d.prior.recorded === 'Y' ? 'W3.6' : 'Not recorded' },
            { label:'Less: payments in the year', amount: -P.paid, source: `${P.pays.length} payment(s)` },
            { label:'Provision carried forward per audit', amount: P.closeAudit, source:'', __cls:'em' },
            { label:'Per trial balance', amount: P.tb.v, source: src(P.tb) },
            { label:'Difference', amount: P.diff, source:'', __cls: flagDiff(P.diff) ? 'flag' : 'em' } ], totals:false,
          footnote:'A difference above the tolerance is raised as EX-TAX-03.' }
      ];
    },
    flag(st, d) { return (d.payable.tb.src !== 'not entered' && d.payable.open.src !== 'not entered' && flagDiff(d.payable.diff)) || d.payable.unvouched.length > 0; } },

  { id:'indirect', ref:'W3.5', title:'Indirect tax reasonableness',
    objective:'To test the reasonableness of output and input tax declared against revenue and purchases per the ledger at the configured rate, and to agree the net position to the indirect tax payable in the trial balance.',
    procedures:['Applied the indirect tax rate to revenue (standard-rated proportion) and to taxable purchases (claimable proportion) per the trial balance to derive expected output and input tax.',
                'Compared the expected figures to the totals per the returns filed for the year and investigated variances above the threshold set.',
                'Agreed the net payable per the returns to the trial balance.'],
    render(st, ctx) {
      const d = ctx.d, I = d.indirect, money = ctx.money;
      return [
        { type:'controls', items:[
          { key:'gstRate', label:'Indirect tax rate %', kind:'number' }, { key:'stdRatedPct', label:'Standard-rated % of revenue', kind:'number', help:'Exclude zero-rated exports and exempt supplies.' },
          { key:'claimablePct', label:'Claimable % of purchases', kind:'number' }, { key:'gstVarPct', label:'Variance threshold %', kind:'number' },
          { key:'tbRevenue', label:'Revenue (override TB)', kind:'number' }, { key:'purchasesOverride', label:'Taxable purchases and expenses (override TB)', kind:'number' },
          { key:'outputTaxClient', label:'Output tax per returns filed', kind:'number' }, { key:'inputTaxClient', label:'Input tax per returns filed', kind:'number' },
          { key:'tbGst', label:'Indirect tax payable per TB (override)', kind:'number' } ] },
        { type:'table', title:'Expected vs declared', columns:[
          { key:'label', label:'', emphasis:true }, { key:'base', label:'Base', type:'num' }, { key:'source', label:'Base source' }, { key:'expected', label:`Expected at ${I.rate}%`, type:'num' },
          { key:'client', label:'Per returns', type:'num' }, { key:'diff', label:'Difference', type:'num', flag:(v, row) => row.__flag }, { key:'varPct', label:'Variance %', type:'pct' } ],
          rows: [
            { label:'Output tax on revenue', base: I.revenue.v, source: src(I.revenue), expected: I.expOut, client: I.outC, diff: I.outDiff, varPct: I.outVarPct != null ? I.outVarPct / 100 : null, __flag: I.outFlag, __cls: I.outFlag ? 'flag' : '' },
            { label:'Input tax on purchases and expenses', base: I.purchases.v, source: I.purchases.src === 'input' ? 'Auditor input' : I.purchases.src, expected: I.expIn, client: I.inC, diff: I.inDiff, varPct: I.inVarPct != null ? I.inVarPct / 100 : null, __flag: I.inFlag, __cls: I.inFlag ? 'flag' : '' },
            { label:'Net payable / (refundable)', base: null, source:'', expected: I.netExpected, client: I.netClient, diff: I.netClient != null ? r2(I.netClient - I.netExpected) : null, varPct: null, __flag:false, __cls:'em' } ], totals:false,
          footnote:`Variances above ${I.threshold}% and above the trivial threshold are raised as EX-TAX-04.` },
        { type:'stats', items:[
          { label:'Net per returns', value: I.netClient == null ? 'Enter output and input tax' : money(I.netClient) }, { label:'Per trial balance', value: I.tb.src === 'not entered' ? 'Not entered' : money(I.tb.v) },
          { label:'Returns − TB', value: I.netDiff == null ? '' : money(I.netDiff), cls: I.netDiff == null ? '' : flagDiff(I.netDiff) ? 'bad' : 'ok' } ] },
        { type:'note', html:'Timing differences between the returns and the ledger (the last period\'s return filed after the year end) explain a difference between the net per returns and the trial balance; record the reconciliation in the conclusion.' }
      ];
    },
    flag(st, d) { return d.indirect.outFlag || d.indirect.inFlag; } },

  { id:'prior', ref:'W3.6', title:'Prior year assessment',
    objective:'To agree the prior year tax provision to the notice of assessment received, and to verify that any under or over provision has been recorded in the current year.',
    procedures:['Sighted the notice of assessment (or the return filed and acknowledged) for the prior year of assessment and compared the tax assessed to the provision brought forward.',
                'Verified that the under or over provision was recorded in the current year tax expense and reflected in the tax payable roll-forward (W3.4).'],
    render(st, ctx) {
      const d = ctx.d, P = d.prior, money = ctx.money;
      return [
        { type:'controls', items:[
          { key:'pyProvision', label:'Provision for taxation per prior year audited (override TB)', kind:'number' },
          { key:'noaAmount', label:'Tax assessed per notice of assessment', kind:'number' }, { key:'noaDate', label:'Date of notice of assessment', kind:'text' },
          { key:'noaSighted', label:'Notice of assessment sighted', kind:'select', options:[['', '—'], ['Y', 'Yes'], ['N', 'No — return filed, assessment pending']] },
          { key:'pyAdjRecorded', label:'Under / over provision recorded in current year', kind:'select', options:[['', '—'], ['Y', 'Yes'], ['N', 'No']] },
          { key:'pyAdjBooked', label:'Amount recorded as prior year adjustment', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Provision brought forward', value: P.provision.v == null ? 'Not entered' : money(P.provision.v) }, { label:'Assessed', value: P.noa == null ? 'Not entered' : money(P.noa) },
          { label:'Under / (over) provision', value: P.diff == null ? '' : money(P.diff), cls: P.diff == null ? '' : Math.abs(P.diff) > 0.01 ? 'warn' : 'ok' },
          { label:'Recorded in current year', value: P.recorded || '—', cls: P.unrecorded ? 'bad' : '' },
          { label:'Recorded vs computed', value: P.bookedDiff == null ? '' : money(P.bookedDiff), cls: P.bookedDiff == null ? '' : flagDiff(P.bookedDiff) ? 'bad' : 'ok' } ] },
        { type:'note', tone: P.unrecorded ? 'bad' : 'info', html: P.diff == null ? 'Enter the assessed amount to complete the comparison.' : P.unrecorded ? `<b>The prior year ${P.diff > 0 ? 'under' : 'over'} provision of ${money(Math.abs(P.diff))} has not been recorded.</b> Raised as EX-TAX-05.` : Math.abs(P.diff) > 0.01 ? `The prior year ${P.diff > 0 ? 'under' : 'over'} provision of ${money(Math.abs(P.diff))} is recorded in the current year and carried to W3.4.` : 'The prior year provision agrees to the assessment.' }
      ];
    },
    flag(st, d) { return d.prior.unrecorded; } },

  { id:'conclusion', ref:'W3.9', title:'Exceptions & conclusion', kind:'conclusion' }
];

function suggestConclusion(st, ctx) {
  const d = ctx.d, C = d.comp;
  const ex = (st.exceptions || []).filter(e => e.disposition === 'open');
  return [
    `The current tax charge was recomputed from a profit before tax of ${ctx.money(C.pbt.v)}: chargeable income ${ctx.money(C.ci)} less exemption ${ctx.money(C.exempt)} at ${C.rate}% gives ${ctx.money(C.taxCharge)}${C.tbCurrentTax.src === 'not entered' ? '' : Math.abs(C.diff) <= 0.01 ? ', agreeing to the charge recorded' : `, against ${ctx.money(C.tbCurrentTax.v)} recorded (difference ${ctx.money(C.diff)})`}.`,
    `Capital allowances of ${ctx.money(d.ca.total)} were computed across ${d.ca.rows.length} categories.`,
    `Deferred tax per audit is ${ctx.money(d.deferred.audit)}${d.deferred.tb.src === 'not entered' ? '' : Math.abs(d.deferred.diff) <= 0.01 ? ', agreeing to the trial balance' : ` against ${ctx.money(d.deferred.tb.v)} recorded`}.`,
    d.payable.pays.length ? `${d.payable.pays.length} tax payment(s) totalling ${ctx.money(d.payable.paid)} were traced; the provision rolls forward to ${ctx.money(d.payable.closeAudit)}.` : 'No tax payments were recorded in the year.',
    d.prior.diff == null ? 'The prior year assessment has not yet been agreed.' : `The prior year assessment gives ${d.prior.diff > 0 ? 'an under' : 'an over'} provision of ${ctx.money(Math.abs(d.prior.diff))}${d.prior.recorded === 'Y' ? ', recorded in the current year' : ''}.`,
    ex.length ? `${ex.length} exception(s) remain open in the register.` : 'No exceptions remain open.',
    'Subject to the above, taxation balances and the tax expense are fairly stated at the reporting date.'
  ].join(' ');
}

return {
  code:'TAX', name:'Taxation', group:'Liabilities & equity', accepts:'.xlsx,.xlsm,.csv',
  blurb:'The taxation audit file: current tax computation seeded from the trial balance, capital allowances from the asset register, deferred tax, tax payable roll-forward, indirect tax reasonableness and prior year assessment — with every rate and tier auditor-configurable.',
  objective:'To obtain sufficient appropriate audit evidence that the current and deferred tax expense, the provision for taxation, deferred tax balances and indirect tax payable are computed in accordance with the applicable tax legislation and financial reporting framework, and are completely and accurately recorded and disclosed.',
  fields, tests, compute, pages, defaultConfig, STANDARD_COLUMNS, CLASSES, CA_BASES, classify,
  procedures: pages.flatMap(p => p.procedures || []),
  columns: STANDARD_COLUMNS, suggestConclusion
};
})();

Modules.register(TaxModule);
