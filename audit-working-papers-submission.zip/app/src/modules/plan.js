/* ==========================================================================
   plan.js -- Planning & Materiality as an auditor actually works it.

   Working papers computed from the uploaded trial balance:
     A     Materiality                A3  Sampling parameters
     A1    Preliminary analytical review   A4  Planning memorandum
     A2    Risk assessment summary    A9  Exceptions & conclusion

   Every figure is reproducible from the trial balance and the auditor's
   own inputs. Nothing is drafted for the auditor: the module computes,
   the auditor decides.
   ========================================================================== */

const PLANModule = (() => {
const r2 = n => n == null || isNaN(n) ? null : Math.round(n * 100) / 100;
const num = v => (v === '' || v == null || isNaN(Number(v))) ? null : Number(v);
const lower = s => String(s == null ? '' : s).replace(/\s+/g, ' ').trim().toLowerCase();
const abs = n => Math.abs(n || 0);

/* ------------------------------------------------------- captions */
/* The standard captions every account is classified into. Used for the
   benchmark suggestions, the ratio set and the caption-level analytics.  */
const CAPTIONS = [
  { key:'cash',          label:'Cash and cash equivalents',      section:'BS', side:'asset',     current:true },
  { key:'trade_rec',     label:'Trade receivables (net)',        section:'BS', side:'asset',     current:true },
  { key:'other_rec',     label:'Other receivables and prepayments', section:'BS', side:'asset',  current:true },
  { key:'inventory',     label:'Inventories (net)',              section:'BS', side:'asset',     current:true },
  { key:'ppe',           label:'Property, plant and equipment',  section:'BS', side:'asset',     current:false },
  { key:'rou',           label:'Right-of-use assets',            section:'BS', side:'asset',     current:false },
  { key:'intangibles',   label:'Intangible assets and goodwill', section:'BS', side:'asset',     current:false },
  { key:'investments',   label:'Investments',                    section:'BS', side:'asset',     current:false },
  { key:'other_assets',  label:'Other assets',                   section:'BS', side:'asset',     current:false },
  { key:'trade_pay',     label:'Trade payables',                 section:'BS', side:'liability', current:true },
  { key:'other_pay',     label:'Other payables, accruals and provisions', section:'BS', side:'liability', current:true },
  { key:'borrowings_c',  label:'Borrowings — current',           section:'BS', side:'liability', current:true },
  { key:'borrowings_nc', label:'Borrowings — non-current',       section:'BS', side:'liability', current:false },
  { key:'lease_c',       label:'Lease liabilities — current',    section:'BS', side:'liability', current:true },
  { key:'lease_nc',      label:'Lease liabilities — non-current',section:'BS', side:'liability', current:false },
  { key:'tax_pay',       label:'Tax and duties payable',         section:'BS', side:'liability', current:true },
  { key:'deferred_tax',  label:'Deferred tax',                   section:'BS', side:'liability', current:false },
  { key:'other_liab',    label:'Other liabilities',              section:'BS', side:'liability', current:false },
  { key:'equity',        label:'Share capital and reserves',     section:'BS', side:'equity',    current:false },
  { key:'revenue',       label:'Revenue',                        section:'PL' },
  { key:'other_income',  label:'Other income',                   section:'PL' },
  { key:'cos',           label:'Cost of sales',                  section:'PL' },
  { key:'staff',         label:'Staff costs',                    section:'PL' },
  { key:'dna',           label:'Depreciation, amortisation and impairment', section:'PL' },
  { key:'other_opex',    label:'Other operating expenses',       section:'PL' },
  { key:'finance',       label:'Finance costs',                  section:'PL' },
  { key:'tax_exp',       label:'Income tax expense',             section:'PL' },
];
const CAP = Object.fromEntries(CAPTIONS.map(c => [c.key, c]));
const capByLabel = Object.fromEntries(CAPTIONS.map(c => [c.label, c.key]));

const PL_WORDS = /revenue|sales|turnover|income|cost of|expense|salar|wages|depreciation of|amortisation of|amortization of|fee|charges|interest (on|paid|expense)|written|loss|gain|remuneration|utilit|rental|insurance|repair|travel|advertis|commission|freight|welfare|subcontract|overhead|consumed|labour|labor/;

function classify(name, code, balance) {
  const nm = lower(name);
  const lead = String(code || '').trim().match(/^\D*(\d)/);
  let section = lead ? (/[123]/.test(lead[1]) ? 'BS' : 'PL') : null;
  if (!section) {
    if (/accumulated|allowance|provision|payable|receivable|capital|reserve|retained|bank|cash|inventor|stock/.test(nm) && !/expense|charge|written/.test(nm)) section = 'BS';
    else section = PL_WORDS.test(nm) ? 'PL' : 'BS';
  }
  if (section === 'BS') {
    if (/deferred tax/.test(nm)) return 'deferred_tax';
    if (/income tax|taxation|tax payable|gst|vat|sst|withholding/.test(nm)) return 'tax_pay';
    if (/lease liabilit/.test(nm)) return /non[- ]?current|long[- ]?term/.test(nm) ? 'lease_nc' : 'lease_c';
    if (/loan|borrowing|overdraft|hire purchase|debenture|bond|notes payable|financing/.test(nm) && !/due (from|to)|receivable/.test(nm))
      return /non[- ]?current|long[- ]?term/.test(nm) ? 'borrowings_nc' : 'borrowings_c';
    if (/right[- ]of[- ]use|\brou\b/.test(nm)) return 'rou';
    if (/goodwill|intangible|software|licen[cs]e|trademark|patent|development cost/.test(nm)) return 'intangibles';
    if (/investment|subsidiar|associate|joint venture/.test(nm)) return 'investments';
    if (/accumulated depreciation|property|plant|machinery|equipment|furniture|fitting|vehicle|computer|leasehold improvement|fixture|tools|building|land\b|capital work|construction in progress|renovation/.test(nm)) return 'ppe';
    if (/allowance for (expected credit|doubtful|impairment)|trade receivable|trade debtor|accounts receivable|debtors/.test(nm)) return 'trade_rec';
    /* cash before other receivables: a fixed deposit is cash and cash equivalents, not a deposit paid */
    if (/cash|bank|fixed deposit|petty|money market/.test(nm)) return 'cash';
    if (/receivable|prepayment|prepaid|deposit(?!s? received)|due from|advance to|accrued income|other debtor|amount owing by/.test(nm)) return 'other_rec';
    if (/inventor|stock|work[- ]in[- ]progress|finished goods|raw material|consumable|obsolescence/.test(nm)) return 'inventory';
    if (/trade payable|trade creditor|accounts payable|creditors/.test(nm)) return 'trade_pay';
    if (/payable|accrual|accrued|due to|deposits? received|provision|deferred (revenue|income)|contract liabilit|dividend payable|advance from|unearned|amount owing to/.test(nm)) return 'other_pay';
    if (/share capital|capital|retained|reserve|premium|equity|accumulated (profit|loss)|dividend/.test(nm)) return 'equity';
    return (balance || 0) >= 0 ? 'other_assets' : 'other_liab';
  }
  if (/cost of (sales|goods|materials|revenue)|cogs|direct (labour|labor|material|cost)|subcontract|factory overhead|purchases|freight inward|production cost|materials consumed/.test(nm)) return 'cos';
  if (/other income|interest income|income - interest|dividend income|gain|grant|rental income|sundry income|miscellaneous income|scrap/.test(nm)) return 'other_income';
  if (/revenue|sales|turnover|fees? earned|service income|contract income/.test(nm)) return 'revenue';
  if (/income tax|tax expense|taxation|deferred tax/.test(nm)) return 'tax_exp';
  if (/interest (on|paid|expense)|finance (cost|charge)|bank charges|loan interest|lease interest|interest expense/.test(nm)) return 'finance';
  if (/depreciation|amortisation|amortization|impairment/.test(nm)) return 'dna';
  if (/salar|wages|payroll|cpf|statutory contribution|remuneration|staff|bonus|employee|medical|training/.test(nm)) return 'staff';
  return 'other_opex';
}

/* ---------------------------------------------------------- fields */
const fields = [
  { key:'code', label:'Account code', role:'key', type:'text', required:true,
    synonyms:['Account','Account No','A/C Code','GL Code','Account Number','Nominal Code','Account Code','Acct','科目代码'] },
  { key:'name', label:'Account name', type:'text', required:true,
    synonyms:['Account Name','Description','Account Description','Name','Particulars','Text for B/S P&L item','Account Title','科目名称'] },
  /* balance is proposed before debit/credit so that an exact match on a single
     signed column (e.g. "余额 Amount") is not taken by the fuzzier debit synonyms */
  { key:'balance', label:'Balance', type:'number',
    synonyms:['Balance','Net Balance','Amount','Closing Balance','Balance at Year End','Current Year','CY','余额'] },
  { key:'debit', label:'Debit', type:'number',
    synonyms:['Debit','Dr','Debit (Dr)','Debit Amount','借方'] },
  { key:'credit', label:'Credit', type:'number',
    synonyms:['Credit','Cr','Credit (Cr)','Credit Amount','贷方'] },
  { key:'balance_py', label:'Prior year', type:'number',
    synonyms:['Prior Year','PY Balance','Comparative','Last Year','Balance b/f','PY','Prior Year Balance','上年'] },
  { key:'caption', label:'FS caption', type:'text',
    synonyms:['FS Line','Grouping','Map No.','FS Caption','L/S','Lead Schedule','Mapping'] }
];

const STANDARD_COLUMNS = [
  { key:'code', label:'Code' }, { key:'name', label:'Account name' },
  { key:'__captionLabel', label:'Standard caption' }, { key:'caption', label:'Client caption' },
  { key:'debit', label:'Debit', type:'num', edit:true }, { key:'credit', label:'Credit', type:'num', edit:true },
  { key:'__balance', label:'Balance', type:'num', emphasis:true },
  { key:'__py', label:'Prior year', type:'num' }, { key:'__variance', label:'Variance', type:'num' }
];

/* -------------------------------------------------------- constants */
const ENTITY_TYPES = [['Trading', 'Trading'], ['Asset-based', 'Asset-based'], ['Not-for-profit', 'Not-for-profit']];
const BASES = [
  { key:'turnover',    label:'Turnover',                        lo:1, hi:3, def:2, types:['Trading'] },
  { key:'pbt',         label:'Profit before tax',               lo:3, hi:7, def:5, types:['Trading'] },
  { key:'totalAssets', label:'Total assets',                    lo:1, hi:3, def:2, types:['Asset-based'] },
  { key:'netAssets',   label:'Net assets',                      lo:3, hi:5, def:4, types:['Asset-based'] },
  { key:'grossExp',    label:'Gross income or expenditure',     lo:1, hi:3, def:2, types:['Not-for-profit'] },
];
const VOCAB = {
  opt: [['Overall / Performance / SUD', 'Overall / Performance / SUD'], ['Planning / Tolerable / Trivial', 'Planning / Tolerable / Trivial']],
  labels: { 'Overall / Performance / SUD': ['Overall materiality', 'Performance materiality', 'SUD threshold'],
            'Planning / Tolerable / Trivial': ['Planning materiality', 'Tolerable misstatement', 'Trivial threshold'] }
};
const AREAS = [
  { id:'revenue',     label:'Revenue and revenue recognition', cap:'revenue',   note:'Presumed fraud risk (ISA 240 para 27). Rebuttal requires a documented reason.' },
  { id:'receivables', label:'Trade receivables and expected credit losses', cap:'trade_rec' },
  { id:'inventory',   label:'Inventories', cap:'inventory' },
  { id:'ppe',         label:'Property, plant and equipment', cap:'ppe' },
  { id:'payables',    label:'Trade payables and accruals', cap:'trade_pay' },
  { id:'payroll',     label:'Payroll and staff costs', cap:'staff' },
  { id:'cash',        label:'Cash and bank', cap:'cash' },
  { id:'tax',         label:'Taxation', cap:'tax_exp' },
  { id:'gc',          label:'Going concern', cap:null },
  { id:'rp',          label:'Related parties', cap:null },
  { id:'override',    label:'Management override of controls', cap:null, note:'Always a significant risk (ISA 240 para 32). Journal entry testing, estimates review and unusual transactions are mandatory responses.' },
];
const RATIO_INPUTS = [
  { key:'revenue',  label:'Revenue',                     caps:['revenue'],  sign:-1 },
  { key:'cos',      label:'Cost of sales',               caps:['cos'],      sign:1 },
  { key:'pbt',      label:'Profit before tax',           caps:'PBT' },
  { key:'pat',      label:'Profit after tax',            caps:'PAT' },
  { key:'pbit',     label:'Profit before interest and tax', caps:'PBIT' },
  { key:'finance',  label:'Finance costs',               caps:['finance'],  sign:1 },
  { key:'ca',       label:'Current assets',              caps:'CA' },
  { key:'cl',       label:'Current liabilities',         caps:'CL' },
  { key:'inventory',label:'Inventories',                 caps:['inventory'], sign:1 },
  { key:'trade_rec',label:'Trade receivables',           caps:['trade_rec'], sign:1 },
  { key:'trade_pay',label:'Trade payables',              caps:['trade_pay'], sign:-1 },
  { key:'borrowings',label:'Total borrowings',           caps:['borrowings_c','borrowings_nc'], sign:-1 },
  { key:'equity',   label:'Total equity (net assets)',   caps:'NA' },
];
const RATIOS = [
  { id:'gp',   label:'Gross profit margin',  fn:f => f.revenue ? (f.revenue - f.cos) / f.revenue : null, kind:'pct',  formula:'(Revenue − Cost of sales) ÷ Revenue' },
  { id:'np',   label:'Net profit margin',    fn:f => f.revenue ? f.pat / f.revenue : null, kind:'pct', formula:'Profit after tax ÷ Revenue' },
  { id:'cr',   label:'Current ratio',        fn:f => f.cl ? f.ca / f.cl : null, kind:'x', formula:'Current assets ÷ Current liabilities' },
  { id:'qr',   label:'Quick ratio',          fn:f => f.cl ? (f.ca - f.inventory) / f.cl : null, kind:'x', formula:'(Current assets − Inventories) ÷ Current liabilities' },
  { id:'rd',   label:'Receivable days',      fn:f => f.revenue ? f.trade_rec / f.revenue * 365 : null, kind:'days', formula:'Trade receivables ÷ Revenue × 365' },
  { id:'pd',   label:'Payable days',         fn:f => f.cos ? f.trade_pay / f.cos * 365 : null, kind:'days', formula:'Trade payables ÷ Cost of sales × 365' },
  { id:'id',   label:'Inventory days',       fn:f => f.cos ? f.inventory / f.cos * 365 : null, kind:'days', formula:'Inventories ÷ Cost of sales × 365' },
  { id:'gear', label:'Gearing',              fn:f => f.equity ? f.borrowings / f.equity : null, kind:'x', formula:'Total borrowings ÷ Total equity' },
  { id:'ic',   label:'Interest cover',       fn:f => f.finance ? f.pbit / f.finance : null, kind:'x', formula:'Profit before interest and tax ÷ Finance costs' },
];

const defaultConfig = () => ({
  entityType: 'Trading', benchmark: '', benchmarkOverride: '', rate: '', pmPct: 75, trivialPct: 5,
  vocab: 'Overall / Performance / SUD',
  pyOM: '', pyPM: '', pyTrivial: '',
  componentRows: 4,
  varPct: 10, castTol: 0.01,
  riskFactor: '1.8', teFactor: 1.333,
  understanding: '', keyChanges: '', team: '', timetable: '', experts: '', laws: '', controlsReliance: '',
});

/* ============================================================ COMPUTE */
function slidingRate(turnover) {
  const t = abs(turnover);
  if (t <= 5e6) return 3;
  if (t >= 10e6) return 1;
  return r2(3 - 2 * (t - 5e6) / 5e6);
}

function compute(recs, cfg, eng) {
  const capTot = {}, capPY = {};
  CAPTIONS.forEach(c => { capTot[c.key] = 0; capPY[c.key] = 0; });
  const clientCaps = {};
  let dr = 0, cr = 0, net = 0, hasDrCr = false, hasPY = false;

  for (const r of recs) {
    r.__displayKey = (r.code || '') + ' ' + (r.name || '');
    let bal = r.balance;
    if (bal == null && (r.debit != null || r.credit != null)) bal = (r.debit || 0) - (r.credit || 0);
    r.__balance = bal == null ? 0 : bal;
    r.__py = r.balance_py != null ? r.balance_py : null;
    if (r.__py != null) hasPY = true;
    const ov = r.__wp?.analytics?.captionOverride;
    r.__captionKey = (ov && capByLabel[ov]) || classify(r.name, r.code, r.__balance);
    r.__captionLabel = CAP[r.__captionKey].label;
    r.__section = CAP[r.__captionKey].section;
    r.__fsCaption = r.caption || r.__captionLabel;
    r.__variance = r.__py != null ? r2(r.__balance - r.__py) : null;
    r.__variancePct = (r.__py != null && r.__py !== 0) ? r.__variance / Math.abs(r.__py) : null;
    if (r.__excluded) continue;
    if (r.debit != null || r.credit != null) { hasDrCr = true; dr += r.debit || 0; cr += r.credit || 0; }
    net += r.__balance;
    capTot[r.__captionKey] += r.__balance;
    if (r.__py != null) capPY[r.__captionKey] += r.__py;
    const cc = clientCaps[r.__fsCaption] || (clientCaps[r.__fsCaption] = { caption: r.__fsCaption, cy: 0, py: 0, count: 0 });
    cc.cy += r.__balance; cc.py += r.__py || 0; cc.count++;
  }
  const outOfBalance = r2(hasDrCr && Math.abs(dr - cr) > 0.001 ? dr - cr : net);

  /* ---- benchmarks from the standard captions ------------------------ */
  const T = capTot, P = capPY;
  const sumOf = (src, keys) => keys.reduce((s, k) => s + (src[k] || 0), 0);
  const figures = src => {
    const assets = CAPTIONS.filter(c => c.side === 'asset').map(c => c.key);
    const liabs = CAPTIONS.filter(c => c.side === 'liability').map(c => c.key);
    const pl = CAPTIONS.filter(c => c.section === 'PL').map(c => c.key);
    const totalAssets = sumOf(src, assets);
    const totalLiabilities = -sumOf(src, liabs);
    const pat = -sumOf(src, pl);
    const pbt = -sumOf(src, pl.filter(k => k !== 'tax_exp'));
    const finance = src.finance || 0;
    return {
      turnover: -(src.revenue || 0), otherIncome: -(src.other_income || 0), cos: src.cos || 0,
      pbt, pat, pbit: pbt + finance, finance,
      totalAssets, totalLiabilities, netAssets: totalAssets - totalLiabilities,
      grossExp: sumOf(src, ['cos', 'staff', 'dna', 'other_opex', 'finance']),
      ca: sumOf(src, CAPTIONS.filter(c => c.side === 'asset' && c.current).map(c => c.key)),
      cl: -sumOf(src, CAPTIONS.filter(c => c.side === 'liability' && c.current).map(c => c.key)),
      inventory: src.inventory || 0, trade_rec: src.trade_rec || 0, trade_pay: -(src.trade_pay || 0),
      borrowings: -((src.borrowings_c || 0) + (src.borrowings_nc || 0)),
    };
  };
  const cy = figures(T), py = hasPY ? figures(P) : null;
  const bench = { turnover: cy.turnover, pbt: cy.pbt, totalAssets: cy.totalAssets, netAssets: cy.netAssets, grossExp: cy.grossExp };

  /* ---- materiality ---------------------------------------------------- */
  const type = cfg.entityType || 'Trading';
  const suggested = type === 'Asset-based' ? 'totalAssets' : type === 'Not-for-profit' ? 'grossExp'
                  : (cy.pbt > 0 && cy.turnover > 0 && cy.pbt / cy.turnover > 0.05 ? 'pbt' : 'turnover');
  const benchKey = BASES.some(b => b.key === cfg.benchmark) ? cfg.benchmark : suggested;
  const base = BASES.find(b => b.key === benchKey);
  const tbValue = bench[benchKey] || 0;
  const benchValue = num(cfg.benchmarkOverride) != null ? num(cfg.benchmarkOverride) : tbValue;
  const defRate = benchKey === 'turnover' ? slidingRate(benchValue) : base.def;
  const rate = num(cfg.rate) != null ? num(cfg.rate) : defRate;
  const om = r2(abs(benchValue) * rate / 100);
  const pmPct = num(cfg.pmPct) != null ? num(cfg.pmPct) : 75;
  const trivialPct = num(cfg.trivialPct) != null ? num(cfg.trivialPct) : 5;
  const pm = r2(om * pmPct / 100), trivial = r2(om * trivialPct / 100);
  const labels = VOCAB.labels[cfg.vocab] || VOCAB.labels['Overall / Performance / SUD'];
  const rateInBand = rate >= base.lo - 1e-9 && rate <= base.hi + 1e-9;
  const mat = { type, benchKey, base, suggested, tbValue: r2(tbValue), benchValue: r2(benchValue), rate, defRate, rateInBand,
    om, pm, trivial, pmPct, trivialPct, labels,
    pyOM: num(cfg.pyOM), pyPM: num(cfg.pyPM), pyTrivial: num(cfg.pyTrivial),
    engOM: eng.materiality?.om || 0, engPM: eng.materiality?.pm || 0 };
  mat.omChangePct = mat.pyOM ? r2((om - mat.pyOM) / mat.pyOM * 100) : null;
  mat.typeMismatch = !(base.types || []).includes(type);

  /* ---- component materiality ------------------------------------------ */
  const nComp = Math.max(0, Math.min(30, Number(cfg.componentRows) || 0));
  const components = [];
  for (let i = 1; i <= nComp; i++) {
    const name = cfg['component:' + i], b = num(cfg['compBenchmark:' + i]), a = num(cfg['compAlloc:' + i]);
    if (!name && b == null && a == null) continue;
    components.push({ i, name: name || ('Component ' + i), benchmark: b, allocated: a,
      pctOfGroup: a != null && om ? r2(a / om * 100) : null, exceeds: a != null && om > 0 && a > om + 0.005 });
  }
  const compAggregate = r2(components.reduce((s, c) => s + (c.allocated || 0), 0));

  /* ---- analytical review ---------------------------------------------- */
  const varPct = (num(cfg.varPct) != null ? num(cfg.varPct) : 10) / 100;
  const flagPM = pm || eng.materiality?.pm || 0;
  const isFlag = (v, p) => v != null && Math.abs(v) > flagPM && (p == null || Math.abs(p) > varPct);
  let flagged = 0, unexplained = 0;
  for (const r of recs) {
    r.__flagged = !r.__excluded && isFlag(r.__variance, r.__variancePct);
    r.__explained = !!(r.__wp?.analytics?.explanation || '').trim();
    if (r.__flagged) { flagged++; if (!r.__explained) unexplained++; }
  }
  const byCaption = CAPTIONS.map(c => {
    const v = hasPY ? r2(T[c.key] - P[c.key]) : null;
    const p = hasPY && P[c.key] ? v / Math.abs(P[c.key]) : null;
    return { key: c.key, caption: c.label, section: c.section, cy: r2(T[c.key]), py: hasPY ? r2(P[c.key]) : null, variance: v, pct: p, flagged: isFlag(v, p) };
  }).filter(x => x.cy !== 0 || x.py);
  const byClientCaption = Object.values(clientCaps).map(c => {
    const v = hasPY ? r2(c.cy - c.py) : null;
    return { ...c, cy: r2(c.cy), py: hasPY ? r2(c.py) : null, variance: v, pct: hasPY && c.py ? v / Math.abs(c.py) : null, flagged: isFlag(v, hasPY && c.py ? v / Math.abs(c.py) : null) };
  }).sort((a, b) => Math.abs(b.cy) - Math.abs(a.cy));

  /* ratio inputs: TB-derived, with the auditor's overrides */
  const derive = (ri, f) => {
    if (!f) return null;
    if (Array.isArray(ri.caps)) return r2(ri.caps.reduce((s, k) => s + (f === cy ? T[k] : P[k]), 0) * ri.sign);
    return r2({ PBT: f.pbt, PAT: f.pat, PBIT: f.pbit, CA: f.ca, CL: f.cl, NA: f.netAssets }[ri.caps]);
  };
  const ratioInputs = RATIO_INPUTS.map(ri => {
    const tbCY = derive(ri, cy), tbPY = derive(ri, py);
    const ovCY = num(cfg['ovCY:' + ri.key]), ovPY = num(cfg['ovPY:' + ri.key]);
    return { ...ri, tbCY, tbPY, cy: ovCY != null ? ovCY : tbCY, py: ovPY != null ? ovPY : tbPY, overridden: ovCY != null || ovPY != null,
      source: Array.isArray(ri.caps) ? ri.caps.map(k => CAP[k].label).join(' + ') : { PBT:'All P&L captions except tax', PAT:'All P&L captions', PBIT:'Profit before tax + finance costs', CA:'Current asset captions', CL:'Current liability captions', NA:'Total assets − total liabilities' }[ri.caps] };
  });
  const fCY = Object.fromEntries(ratioInputs.map(x => [x.key, x.cy || 0]));
  const fPY = hasPY ? Object.fromEntries(ratioInputs.map(x => [x.key, x.py || 0])) : null;
  const ratios = RATIOS.map(rt => {
    const c = rt.fn(fCY), p = fPY ? rt.fn(fPY) : null;
    return { id: rt.id, label: rt.label, formula: rt.formula, kind: rt.kind, cy: c == null ? null : r2(c * (rt.kind === 'pct' ? 100 : 1)), py: p == null ? null : r2(p * (rt.kind === 'pct' ? 100 : 1)),
      movement: c != null && p != null ? r2((c - p) * (rt.kind === 'pct' ? 100 : 1)) : null };
  });

  /* ---- risk assessment ------------------------------------------------ */
  const risks = AREAS.map(a => {
    const inh = cfg['inherent:' + a.id] || '', fraud = cfg['fraud:' + a.id] || '', sig = cfg['significant:' + a.id] || '';
    const reason = (cfg['rebuttal:' + a.id] || '').trim();
    const effFraud = a.id === 'revenue' ? (fraud || 'Y') : fraud;
    const effSig = a.id === 'override' ? 'Y' : (sig || (effFraud === 'Y' ? 'Y' : ''));
    return { ...a, inherent: inh, fraud, significant: sig, effFraud, effSig, reason,
      tbValue: a.cap ? r2(Math.abs(T[a.cap] || 0)) : null,
      rebuttedNoReason: a.id === 'revenue' && fraud === 'N' && !reason,
      response: cfg['response:' + a.id] || '' };
  });

  /* ---- sampling ------------------------------------------------------- */
  const riskFactor = Number(cfg.riskFactor) || 1.8;
  const teFactor = num(cfg.teFactor) || 1;
  const te = r2(om / teFactor);
  const sampling = byCaption.filter(c => Math.abs(c.cy) >= (pm || 1) && c.key !== 'equity').map(c => {
    const pop = Math.abs(c.cy);
    const above = num(cfg['aboveTE:' + c.key]) || 0, nature = num(cfg['byNature:' + c.key]) || 0;
    const residual = Math.max(0, pop - above - nature);
    return { key: c.key, caption: c.caption, section: c.section, population: r2(pop), above, nature, residual: r2(residual),
      sampleSize: te > 0 ? Math.ceil(residual / te * riskFactor) : null, coverage: pop ? r2((above + nature) / pop * 100) : null };
  }).sort((a, b) => b.population - a.population);

  return { rows: recs.length, debit: r2(dr), credit: r2(cr), net: r2(net), outOfBalance, hasDrCr, hasPY,
    cy, py, bench, mat, components, compAggregate, byCaption, byClientCaption, flagged, unexplained, varPct,
    ratioInputs, ratios, risks, sampling, te, riskFactor, teFactor };
}

/* ============================================================== TESTS */
const tests = [
  { id:'EX-PLAN-01', scope:'population', label:'Materiality rate outside the band for the benchmark', basis:'A', severity:'informational',
    fn:(recs, cfg, eng, d) => !d.mat.rateInBand && { key:d.mat.base.label, expected:`${d.mat.base.lo}%–${d.mat.base.hi}%`, actual:d.mat.rate + '%',
      detail:`Rate applied to ${d.mat.base.label.toLowerCase()} is outside the firm band. Document the rationale or bring the rate within the band.` } },
  { id:'EX-PLAN-02', scope:'population', label:'Component materiality exceeds group materiality', basis:'A', severity:'above-trivial',
    fn:(recs, cfg, eng, d) => d.components.filter(c => c.exceeds).map(c => ({ key:c.name, expected:d.mat.om, actual:c.allocated, difference:r2(c.allocated - d.mat.om),
      detail:'A component audited to a threshold above group materiality would let a group-material misstatement pass.' })) },
  { id:'EX-PLAN-03', scope:'population', label:'Trial balance does not balance', basis:'A1',
    fn:(recs, cfg, eng, d) => Math.abs(d.outOfBalance) > (num(cfg.castTol) ?? 0.01) &&
      { key:'Trial balance', actual:d.outOfBalance, difference:d.outOfBalance, detail:`Out of balance by ${d.outOfBalance.toFixed(2)}. Materiality and analytics rest on an unbalanced ledger.` } },
  { id:'EX-PLAN-04', scope:'population', label:'Revenue fraud presumption rebutted without a documented reason', basis:'A2', severity:'informational',
    fn:(recs, cfg, eng, d) => d.risks.some(x => x.rebuttedNoReason) &&
      { key:'Revenue recognition', expected:'Y (presumed)', actual:'N', detail:'ISA 240 para 47 requires the reasons for rebutting the presumption to be documented.' } },
  { id:'EX-PLAN-05', label:'Variance above performance materiality and 10% with no explanation', basis:'A1', severity:'informational',
    fn:(r) => r.__flagged && !r.__explained && { expected:r.__py, actual:r.__balance, difference:r.__variance, cell:r['__cell_balance'],
      detail:`Moved ${r.__variancePct != null ? (r.__variancePct * 100).toFixed(1) + '%' : ''} against prior year` } },
];

/* ============================================================== PAGES */
const yn = ['Y', 'N'];
const pctFmt = v => v == null ? '' : (v * 100).toFixed(1) + '%';

const pages = [
  { id:'source',  ref:'A.0',  title:'Source data',      kind:'source' },
  { id:'cleaned', ref:'A.0a', title:'Cleaned listing',  kind:'cleaned' },
  { id:'mapping', ref:'A.0b', title:'Column mapping',   kind:'mapping' },

  /* ------------------------------------------------------------- A */
  { id:'materiality', ref:'A', title:'Materiality',
    objective:'To determine overall materiality, performance materiality and the trivial threshold for the engagement on an appropriate benchmark, and to allocate materiality to components where the engagement is a group audit.',
    procedures:['Read the trial balance and classified every account into a standard caption to derive the candidate benchmarks.',
                'Selected the entity type and benchmark, applied a rate within the firm band (sliding scale by turnover band where turnover is the benchmark), and computed the three thresholds.',
                'Compared the thresholds to the prior year and to the figures carried in the engagement settings.',
                'Allocated materiality to in-scope components and confirmed no component exceeds group materiality.'],
    flag:(st, d) => !d.mat.rateInBand || d.components.some(c => c.exceeds),
    render(st, ctx) {
      const d = ctx.d, m = d.mat, cfg = ctx.cfg;
      const L = m.labels;
      const benchRows = BASES.map(b => ({ key:b.key, benchmark:b.label, tb:r2(d.bench[b.key]), band:`${b.lo}% – ${b.hi}%`, types:(b.types || []).join(', '),
        pick: b.key === m.benchKey ? 'Selected' : (b.key === m.suggested ? 'Suggested' : ''), __cls: b.key === m.benchKey ? 'yes' : '' }));
      const compRows = [];
      const n = Math.max(0, Math.min(30, Number(cfg.componentRows) || 0));
      for (let i = 1; i <= n; i++) {
        const c = d.components.find(x => x.i === i);
        compRows.push({ __key:i, n:i, pct: c && c.pctOfGroup != null ? c.pctOfGroup / 100 : null, check: c ? (c.exceeds ? 'Exceeds group' : (c.allocated != null ? 'Within group' : '')) : '' });
      }
      return [
        { type:'controls', items:[
          { key:'entityType', label:'Entity type', kind:'select', options:ENTITY_TYPES },
          { key:'benchmark', label:'Benchmark', kind:'select', options:[['', `Auto — ${BASES.find(b => b.key === m.suggested).label} (suggested from the trial balance)`], ...BASES.map(b => [b.key, b.label])] },
          { key:'benchmarkOverride', label:'Benchmark amount (blank = per trial balance)', kind:'number', help:`Trial balance gives ${ctx.money0(m.tbValue)}` },
          { key:'rate', label:'Rate % (blank = firm default)', kind:'number', help:`Band ${m.base.lo}%–${m.base.hi}%; default ${m.defRate}%${m.benchKey === 'turnover' ? ' (sliding scale: 3% below 5m, 1% above 10m)' : ''}` },
          { key:'pmPct', label:`${L[1]} as % of ${L[0].toLowerCase()}`, kind:'number' },
          { key:'trivialPct', label:`${L[2]} as % of ${L[0].toLowerCase()}`, kind:'number' },
          { key:'vocab', label:'Firm vocabulary', kind:'select', options:VOCAB.opt },
        ] },
        { type:'stats', items:[
          { label:`${L[0]} (${m.base.label} × ${m.rate}%)`, value:ctx.money0(m.om), cls:m.rateInBand ? 'ok' : 'bad' },
          { label:`${L[1]} (${m.pmPct}%)`, value:ctx.money0(m.pm) },
          { label:`${L[2]} (${m.trivialPct}%)`, value:ctx.money0(m.trivial) },
          { label:'Rate within band', value:m.rateInBand ? 'Yes' : 'No — document rationale', cls:m.rateInBand ? 'ok' : 'bad' },
          { label:'Benchmark suits entity type', value:m.typeMismatch ? 'No — ' + (m.base.types || []).join('/') + ' benchmark' : 'Yes', cls:m.typeMismatch ? 'warn' : 'ok' },
        ] },
        m.engOM && Math.abs(m.engOM - m.om) > 0.5 ? { type:'note', tone:'warn', html:`The engagement settings carry ${L[0].toLowerCase()} of <b>${ctx.money0(m.engOM)}</b>; this working paper computes <b>${ctx.money0(m.om)}</b>. Update the engagement settings once the benchmark and rate are concluded so every module's thresholds agree to this paper.` } : null,
        { type:'table', title:'Candidate benchmarks from the trial balance', columns:[
          { key:'benchmark', label:'Benchmark' }, { key:'tb', label:'Per trial balance', type:'num' }, { key:'band', label:'Firm band' }, { key:'types', label:'Entity type' },
          { key:'pick', label:'', type:'chip', chipClass:v => v === 'Selected' ? 'ok' : 'info' } ], rows:benchRows,
          footnote:'Profit before tax and net assets are derived before closing the current year result to equity. A loss-making or break-even entity should not use profit before tax.' },
        { type:'heading', text:'Prior year comparison' },
        { type:'controls', items:[
          { key:'pyOM', label:`Prior year ${L[0].toLowerCase()}`, kind:'number' },
          { key:'pyPM', label:`Prior year ${L[1].toLowerCase()}`, kind:'number' },
          { key:'pyTrivial', label:`Prior year ${L[2].toLowerCase()}`, kind:'number' } ] },
        { type:'table', title:'Current year against prior year', columns:[
          { key:'item', label:'Threshold' }, { key:'cy', label:'Current year', type:'num' }, { key:'py', label:'Prior year', type:'num' }, { key:'chg', label:'Change', type:'num' }, { key:'pct', label:'Change %', type:'pct' } ],
          rows:[ ['item', L[0], m.om, m.pyOM], ['item', L[1], m.pm, m.pyPM], ['item', L[2], m.trivial, m.pyTrivial] ].map(([, item, c, p]) =>
            ({ item, cy:c, py:p, chg:p != null ? r2(c - p) : null, pct:p ? (c - p) / Math.abs(p) : null })) },
        { type:'heading', text:'Component materiality allocation' },
        { type:'controls', items:[{ key:'componentRows', label:'Number of components', kind:'number', help:'Leave at 0 for a single-entity engagement' }] },
        n ? { type:'table', title:'Allocation', columns:[
          { key:'n', label:'#', type:'int' },
          { key:'component', label:'Component', input:'text', wide:true },
          { key:'compBenchmark', label:'Component benchmark', input:'number' },
          { key:'compAlloc', label:'Allocated materiality', input:'number' },
          { key:'pct', label:'% of group', type:'pct' },
          { key:'check', label:'Check', type:'chip', chipClass:v => v === 'Exceeds group' ? 'bad' : 'ok' } ], rows:compRows,
          footnote:`Aggregate allocated ${ctx.money0(d.compAggregate)} against group ${L[0].toLowerCase()} ${ctx.money0(m.om)}. The aggregate may exceed group materiality; no single component may.` } : null,
      ].filter(Boolean);
    } },

  /* ------------------------------------------------------------ A1 */
  { id:'analytics', ref:'A1', title:'Preliminary analytical review',
    objective:'To identify, from a comparison of the current year trial balance with the prior year and from key ratios, the areas where misstatement is more likely and to direct audit effort accordingly.',
    procedures:['Compared every account and every caption to the prior year and computed the variance in amount and percentage.',
                'Flagged variances above performance materiality and the percentage threshold for explanation.',
                'Computed the standard ratio set for the current and prior year from the standard captions, stating which captions fed each numerator and denominator.',
                'Obtained and recorded explanations for each flagged variance.'],
    flag:(st, d) => d.unexplained > 0,
    render(st, ctx) {
      const d = ctx.d, cfg = ctx.cfg;
      const capOpts = CAPTIONS.map(c => c.label);
      const accountRows = ctx.recs.map(r => ({ __rec:r, code:r.code, name:r.name, caption:r.__captionLabel, cy:r.__balance, py:r.__py, variance:r.__variance, pct:r.__variancePct,
        flag:r.__flagged ? (r.__explained ? 'Explained' : 'Explain') : (r.__variance != null ? 'i/m' : ''), __cls:r.__flagged && !r.__explained ? 'yes' : '' }));
      const capRows = d.byCaption.map(c => ({ ...c, flag:c.flagged ? 'Above threshold' : (c.variance != null ? 'i/m' : '') }));
      const ratioRows = d.ratios.map(r => ({ ...r, cyTxt: r.cy == null ? '' : (r.kind === 'pct' ? r.cy.toFixed(1) + '%' : r.kind === 'days' ? r.cy.toFixed(0) + ' days' : r.cy.toFixed(2) + 'x'),
        pyTxt: r.py == null ? '' : (r.kind === 'pct' ? r.py.toFixed(1) + '%' : r.kind === 'days' ? r.py.toFixed(0) + ' days' : r.py.toFixed(2) + 'x'),
        mvTxt: r.movement == null ? '' : (r.kind === 'pct' ? r.movement.toFixed(1) + ' pts' : r.kind === 'days' ? r.movement.toFixed(0) + ' days' : r.movement.toFixed(2) + 'x') }));
      return [
        { type:'stats', items:[
          { label:'Accounts', value:d.rows }, { label:'Out of balance', value:ctx.money(d.outOfBalance), cls:Math.abs(d.outOfBalance) > 0.01 ? 'bad' : 'ok' },
          { label:'Prior year available', value:d.hasPY ? 'Yes' : 'No — map a prior year column', cls:d.hasPY ? 'ok' : 'warn' },
          { label:'Flagged variances', value:d.flagged, cls:d.flagged ? 'warn' : 'ok' }, { label:'Unexplained', value:d.unexplained, cls:d.unexplained ? 'bad' : 'ok' } ] },
        { type:'controls', items:[
          { key:'varPct', label:'Percentage threshold for flagging (%)', kind:'number', help:`Flag where the movement exceeds performance materiality (${ctx.money0(d.mat.pm)}) and this percentage` },
          { key:'castTol', label:'Casting tolerance', kind:'number' } ] },
        { type:'table', title:'By account — current year against prior year', maxHeight:'520px', columns:[
          { key:'code', label:'Code' }, { key:'name', label:'Account name' },
          { key:'captionOverride', label:'Caption (override)', input:'select', options:capOpts },
          { key:'caption', label:'Standard caption' },
          { key:'cy', label:'Current year', type:'num', sum:true }, { key:'py', label:'Prior year', type:'num', sum:true },
          { key:'variance', label:'Variance', type:'num', flag:(v, row) => row.__rec.__flagged }, { key:'pct', label:'%', type:'pct' },
          { key:'flag', label:'', type:'chip', chipClass:v => v === 'Explain' ? 'bad' : v === 'Explained' ? 'ok' : 'grey' },
          { key:'explanation', label:'Explanation obtained', input:'text', wide:true } ], rows:accountRows,
          footnote:'Sign convention: debits positive, credits negative. Totals should net to nil for a balanced trial balance. Choose a caption override where the automatic classification is wrong; the ratios and benchmarks re-derive.' },
        { type:'table', title:'By standard caption', columns:[
          { key:'section', label:'' }, { key:'caption', label:'Caption' },
          { key:'cy', label:'Current year', type:'num' }, { key:'py', label:'Prior year', type:'num' },
          { key:'variance', label:'Variance', type:'num', flag:(v, row) => row.flagged }, { key:'pct', label:'%', type:'pct' },
          { key:'flag', label:'', type:'chip', chipClass:v => v === 'Above threshold' ? 'bad' : 'grey' } ], rows:capRows },
        d.byClientCaption.length && ctx.recs.some(r => r.caption) ? { type:'table', title:'By the client\'s own caption (as mapped)', columns:[
          { key:'caption', label:'Client caption' }, { key:'count', label:'Accounts', type:'int' }, { key:'cy', label:'Current year', type:'num' }, { key:'py', label:'Prior year', type:'num' },
          { key:'variance', label:'Variance', type:'num', flag:(v, row) => row.flagged }, { key:'pct', label:'%', type:'pct' } ], rows:d.byClientCaption } : null,
        { type:'heading', text:'Ratio analysis' },
        { type:'table', title:'Figures feeding the ratios — per trial balance, with overrides', columns:[
          { key:'label', label:'Figure' }, { key:'source', label:'Captions used', wrap:true },
          { key:'tbCY', label:'CY per TB', type:'num' }, { key:'tbPY', label:'PY per TB', type:'num' },
          { key:'ovCY', label:'CY override', input:'number' }, { key:'ovPY', label:'PY override', input:'number' },
          { key:'cy', label:'CY used', type:'num', emphasis:true }, { key:'py', label:'PY used', type:'num', emphasis:true } ],
          rows:d.ratioInputs.map(x => ({ ...x, __key:x.key })) },
        { type:'table', title:'Ratios', columns:[
          { key:'label', label:'Ratio' }, { key:'formula', label:'Computed as', wrap:true },
          { key:'cyTxt', label:'Current year' }, { key:'pyTxt', label:'Prior year' }, { key:'mvTxt', label:'Movement' },
          { key:'comment', label:'Auditor comment', input:'text', wide:true } ], rows:ratioRows.map(x => ({ ...x, __key:x.id })),
          footnote:'Payable days use cost of sales as the proxy for purchases. Gearing excludes lease liabilities. Interest cover uses profit before tax plus finance costs.' },
      ].filter(Boolean);
    } },

  /* ------------------------------------------------------------ A2 */
  { id:'risk', ref:'A2', title:'Risk assessment summary',
    objective:'To record the assessed inherent risk, fraud risk and significant risk for each audit area and the planned response, including the mandatory ISA 240 presumptions.',
    procedures:['Assessed inherent risk for each audit area on the understanding of the entity and the analytical review.',
                'Applied the ISA 240 presumption of fraud risk in revenue recognition, recording the reason where the presumption is rebutted.',
                'Treated management override of controls as a significant risk in every engagement.',
                'Recorded the planned audit response to each risk.'],
    flag:(st, d) => d.risks.some(x => x.rebuttedNoReason),
    render(st, ctx) {
      const d = ctx.d;
      const rows = d.risks.map(x => ({ __key:x.id, area:x.label, tbValue:x.tbValue, effective:
        x.id === 'override' ? 'Significant (mandatory)' : x.id === 'revenue' ? (x.effFraud === 'Y' ? 'Fraud risk presumed' : (x.reason ? 'Presumption rebutted' : 'Rebuttal — reason required')) : (x.effSig === 'Y' ? 'Significant' : ''),
        note:x.note || '' }));
      return [
        { type:'note', html:'Inherent risk, fraud risk and significant risk are the auditor\'s judgements. The module applies only the two mandatory ISA 240 positions: revenue recognition is a presumed fraud risk unless rebutted with a reason, and management override is always a significant risk.' },
        { type:'table', title:'Audit areas', columns:[
          { key:'area', label:'Audit area' }, { key:'tbValue', label:'Balance per TB', type:'num' },
          { key:'inherent', label:'Inherent risk', input:'select', options:['Low', 'Medium', 'High'] },
          { key:'fraud', label:'Fraud risk', input:'select', options:yn },
          { key:'significant', label:'Significant risk', input:'select', options:yn },
          { key:'effective', label:'Module position', type:'chip', chipClass:v => /required/.test(v) ? 'bad' : /Significant|presumed/.test(v) ? 'warn' : 'grey' },
          { key:'rebuttal', label:'Reason for rebuttal (revenue)', input:'text', wide:true },
          { key:'response', label:'Planned response', input:'text', wide:true } ], rows,
          footnote:'ISA 240 para 27: presume risks of fraud in revenue recognition; para 47: document the reasons where the presumption is not applicable. ISA 240 para 32: management override is a significant risk in all entities.' },
        { type:'stats', items:[
          { label:'Areas assessed High', value:d.risks.filter(x => x.inherent === 'High').length },
          { label:'Significant risks', value:d.risks.filter(x => x.effSig === 'Y').length },
          { label:'Fraud risks', value:d.risks.filter(x => x.effFraud === 'Y').length },
          { label:'Revenue presumption', value:d.risks.find(x => x.id === 'revenue').effFraud === 'Y' ? 'Applied' : 'Rebutted', cls:d.risks.some(x => x.rebuttedNoReason) ? 'bad' : 'ok' } ] },
      ];
    } },

  /* ------------------------------------------------------------ A3 */
  { id:'sampling', ref:'A3', title:'Sampling parameters',
    objective:'To set the sampling risk factor and tolerable error for the engagement and to demonstrate the resulting sample sizes for each significant caption after stratification.',
    procedures:['Selected the sampling risk factor: 1.8 where tests of detail are the only substantive evidence, 1.2 where combined with substantive analytics or tests of controls.',
                'Derived tolerable error from overall materiality and the risk assessment factor.',
                'For each significant caption, stratified the population into items tested separately by nature, items above tolerable error tested in full, and the residual; computed the residual sample size.'],
    render(st, ctx) {
      const d = ctx.d, L = d.mat.labels;
      const rows = d.sampling.map(s => ({ ...s, __key:s.key, cov:s.coverage != null ? s.coverage / 100 : null }));
      return [
        { type:'controls', items:[
          { key:'riskFactor', label:'Sampling risk factor', kind:'select', options:[['1.8', '1.8 — tests of detail only'], ['1.2', '1.2 — combined with substantive analytics or tests of controls']] },
          { key:'teFactor', label:`Risk assessment factor (tolerable error = ${L[0].toLowerCase()} ÷ factor)`, kind:'number', help:`1.333 gives tolerable error equal to ${L[1].toLowerCase()}` } ] },
        { type:'stats', items:[
          { label:L[0], value:ctx.money0(d.mat.om) }, { label:'Tolerable error', value:ctx.money0(d.te) }, { label:'Risk factor', value:d.riskFactor },
          { label:'Formula', value:'residual ÷ tolerable error × risk factor' } ] },
        { type:'table', title:`Significant captions (≥ ${L[1].toLowerCase()} ${ctx.money0(d.mat.pm)})`, columns:[
          { key:'section', label:'' }, { key:'caption', label:'Caption' }, { key:'population', label:'Population', type:'num' },
          { key:'byNature', label:'Tested by nature', input:'number' },
          { key:'aboveTE', label:'Items above tolerable error', input:'number' },
          { key:'residual', label:'Residual population', type:'num' },
          { key:'cov', label:'Covered 100%', type:'pct' },
          { key:'sampleSize', label:'Sample size', type:'int' },
          { key:'wpRef', label:'WP reference', input:'text' } ], rows,
          emptyText:'No caption reaches performance materiality. Lower the benchmark or check the mapping.',
          footnote:'Enter the value of items in each caption to be tested separately by nature (related party, unusual, legal and professional) and the value of items individually above tolerable error. The sample size applies to the residual only.' },
      ];
    } },

  /* ------------------------------------------------------------ A4 */
  { id:'memo', ref:'A4', title:'Planning memorandum',
    objective:'To record the understanding of the entity, the key changes in the year, the engagement team and timetable, the use of experts, relevant laws and regulations and the intended reliance on controls.',
    procedures:['Documented the understanding of the entity and its environment and the key changes since the prior year.',
                'Recorded the engagement team, timetable, planned use of experts and reliance on controls.',
                'Identified the laws and regulations with a direct effect on the financial statements.'],
    render(st, ctx) {
      const d = ctx.d, L = d.mat.labels;
      return [
        { type:'stats', items:[
          { label:L[0], value:ctx.money0(d.mat.om) }, { label:L[1], value:ctx.money0(d.mat.pm) }, { label:L[2], value:ctx.money0(d.mat.trivial) },
          { label:'Significant risks', value:d.risks.filter(x => x.effSig === 'Y').length }, { label:'Flagged variances', value:d.flagged } ] },
        { type:'controls', items:[
          { key:'understanding', label:'Understanding the entity and its environment', kind:'text' },
          { key:'keyChanges', label:'Key changes in the year', kind:'text' },
          { key:'team', label:'Engagement team and roles', kind:'text' },
          { key:'timetable', label:'Timetable (planning, interim, final, sign-off)', kind:'text' },
          { key:'experts', label:'Use of experts and specialists', kind:'text' },
          { key:'laws', label:'Laws and regulations with a direct effect', kind:'text' },
          { key:'controlsReliance', label:'Intended reliance on controls', kind:'text' } ] },
        { type:'note', html:'The memorandum summarises the auditor\'s own planning decisions. Materiality, risks and sampling parameters above are carried from A, A2 and A3 and are not restated here.' },
      ];
    } },

  { id:'conclusion', ref:'A9', title:'Exceptions & conclusion', kind:'conclusion' },
];

return {
  code:'PLAN', name:'Planning & Materiality', group:'Foundations', accepts:'.xlsx,.xlsm,.csv',
  blurb:'Materiality on a benchmark from the trial balance, preliminary analytics and ratios, the risk assessment summary, sampling parameters and the planning memorandum.',
  objective:'To plan the audit so that it is performed effectively: determine materiality, identify and assess the risks of material misstatement, and set the sampling parameters that follow from them.',
  fields, tests, compute, pages, defaultConfig, STANDARD_COLUMNS, CAPTIONS, BASES, AREAS, RATIOS,
  procedures: pages.flatMap(p => p.procedures || []),
  columns: STANDARD_COLUMNS
};
})();

Modules.register(PLANModule);
