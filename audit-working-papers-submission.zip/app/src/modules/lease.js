/* ==========================================================================
   lease.js -- Leases (lessee, FRS 116 / IFRS 16) as an auditor actually works it.

   One uploaded lease schedule (one line per lease) feeds:
     Y3    Lead schedule                       Y3.4  Current / non-current split
     Y3.1  Lease liability rebuild             Y3.5  Maturity analysis
     Y3.2  Right-of-use depreciation           Y3.6  Agreement vouching
     Y3.3  (folded into Y3.1: cast)            Y3.7  Short-term / low-value exemptions
   ========================================================================== */

const LEASEModule = (() => {
const r2 = n => n == null || isNaN(n) ? null : Math.round(n * 100) / 100;
const num = v => (v === '' || v == null || isNaN(Number(v))) ? null : Number(v);
const inp = (cfg, key, k) => num(cfg[key + ':' + k]);
const txt = (cfg, key, k) => { const v = cfg[key + ':' + k]; return v == null ? '' : String(v); };
const monthDiff = (a, b) => (a && b) ? (b.getUTCFullYear() - a.getUTCFullYear()) * 12 + (b.getUTCMonth() - a.getUTCMonth()) : null;
const addMonths = (d, n) => d ? new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + n, Math.min(d.getUTCDate(), 28))) : null;
const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

/* Present value of `n` level monthly payments of `pmt` at annual rate r% (arrears; advance multiplies by 1+m). */
function pvAnnuity(pmt, ratePct, n, advance) {
  if (!(pmt > 0) || !(n > 0)) return 0;
  const m = (ratePct || 0) / 1200;
  const pv = m === 0 ? pmt * n : pmt * (1 - Math.pow(1 + m, -n)) / m;
  return advance ? pv * (1 + m) : pv;
}

/* Effective-interest amortisation of a lease liability: `months` periods of interest at r%/12 and a level payment. */
function amortise(balance, ratePct, pmt, months, advance) {
  let bal = Math.max(0, balance || 0), interest = 0, principal = 0, paid = 0, run = 0;
  const m = (ratePct || 0) / 1200;
  for (let i = 0; i < months; i++) {
    if (bal <= 0.005) break;
    let iv, pv, p;
    if (advance) { p = Math.min(bal, pmt); pv = p; bal -= p; iv = bal * m; bal += iv; }
    else { iv = bal * m; p = Math.min(bal + iv, pmt); pv = p - iv; bal = bal + iv - p; }
    interest += iv; principal += pv; paid += p; run++;
  }
  return { interest: r2(interest), principal: r2(principal), paid: r2(paid), closing: r2(Math.max(0, bal)), months: run };
}

const CONVENTIONS = [
  { key:'auto',       label:'Auto — the convention that reproduces the payments per the schedule' },
  { key:'month-incl', label:'Monthly — a payment falls in the month of commencement and every month after' },
  { key:'month-next', label:'Monthly — the first payment falls in the month after commencement' }
];

/* Months of the lease before the financial year, in it, and after the reporting date. */
function timing(r, fys, ye, incl) {
  const T = r.__termMonths;
  let elapsed = 0, months = Math.min(12, T);
  if (r.commence && ye) {
    if (r.__afterYE) { elapsed = 0; months = 0; }
    else if (r.__inYear) { elapsed = 0; months = clamp(monthDiff(r.commence, ye) + (incl ? 1 : 0), 0, Math.min(12, T)); }
    else { elapsed = clamp(monthDiff(r.commence, fys) - (incl ? 0 : 1), 0, T); months = clamp(T - elapsed, 0, 12); }
  }
  return { elapsed, months };
}
const EXEMPTION_TYPES = ['Short-term (12 months or less)', 'Low-value underlying asset'];

/* ---------------------------------------------------------------- fields */
const fields = [
  { key:'lease', label:'Leased asset / lease', role:'key', type:'text', required:true, dupKey:true,
    synonyms:['Leased Asset','Lease','Asset','Description','Lease Description','Premises','Property','Underlying Asset','Contract','Lease Ref','Lease Name','Asset Leased','Nature of Lease','Right-of-use Asset','ROU Asset','租赁资产','租赁','租赁物'] },
  { key:'lessor', label:'Lessor', type:'text',
    synonyms:['Lessor','Landlord','Counterparty','Lessor Name','Owner','出租人','出租方'] },
  { key:'contract_no', label:'Contract / agreement number', type:'text', dupKey:true,
    synonyms:['Contract No','Agreement No','Lease No','Contract Number','Agreement Reference','Reference','Ref No','Lease Number','合同编号','合同号'] },
  { key:'commence', label:'Commencement date', type:'date', required:true,
    synonyms:['Commencement','Commencement Date','Start Date','Lease Start','Inception Date','Date of Commencement','Start','Lease Commencement','Effective Date','From','起始日期','租赁开始日','开始日期'] },
  { key:'end', label:'Expiry date', type:'date',
    synonyms:['Expiry','Expiry Date','End Date','Lease End','Termination Date','Maturity','Maturity Date','To','Lease Expiry','到期日','结束日期'] },
  { key:'term', label:'Lease term (months)', type:'number', required:true,
    synonyms:['Term (Months)','Term','Lease Term','Tenure','Period (Months)','Term in Months','No. of Months','Lease Term (Months)','Duration','Lease Period','Months','Term (Yrs)','Lease Term (Years)','租期','租赁期'] },
  { key:'rate', label:'Discount rate % p.a.', type:'number', required:true,
    synonyms:['Discount Rate %','Discount Rate','IBR','Incremental Borrowing Rate','Rate','Interest Rate','Rate %','Discount Rate (%)','Effective Rate','IBR %','Borrowing Rate','Rate p.a.','折现率','利率','增量借款利率'] },
  { key:'payment', label:'Monthly payment', type:'number', required:true,
    synonyms:['Monthly Payment','Monthly Rental','Rental','Monthly Rent','Rent per Month','Lease Payment','Instalment','Payment per Month','Monthly Instalment','Fixed Payment','Rent','Periodic Payment','每月租金','月租','月付款'] },
  { key:'initial', label:'Initial lease liability', type:'number',
    synonyms:['Initial Liability','Initial Measurement','PV of Payments','Present Value','Initial Recognition','Liability at Commencement','Initial Lease Liability','PV','Present Value of Payments','Initial Amount','初始确认','初始计量'] },
  { key:'rou_open', label:'ROU asset b/f', type:'number', required:true, block:'ROU',
    synonyms:['ROU B/F','ROU Asset B/F','Right-of-use Asset B/F','ROU Opening','Opening ROU','ROU Brought Forward','ROU at 1 Jan','Right of Use B/F','ROU Asset Opening','Carrying Amount B/F','ROU NBV B/F','使用权资产期初','期初使用权资产'] },
  { key:'rou_add', label:'ROU additions / remeasurement', type:'number', block:'ROU',
    synonyms:['ROU Additions','Additions','New Leases','Additions to ROU','Modifications','Remeasurement','ROU Recognised','Additions (ROU)','本期增加'] },
  { key:'rou_dep', label:'ROU depreciation for the year', type:'number', required:true, block:'ROU',
    synonyms:['ROU Depreciation','Depreciation','Depreciation for the Year','Depreciation Charge','ROU Amortisation','Amortisation','Depreciation of ROU','Depn','Depreciation - ROU','Charge for the Year','本期折旧','折旧'] },
  { key:'rou_close', label:'ROU asset c/f', type:'number', block:'ROU',
    synonyms:['ROU C/F','ROU Asset C/F','Right-of-use Asset C/F','ROU Closing','Closing ROU','ROU Carried Forward','ROU at Year End','Right of Use C/F','ROU Asset Closing','Carrying Amount C/F','Carrying Amount','NBV','ROU NBV','使用权资产期末','期末使用权资产'] },
  { key:'liab_open', label:'Lease liability b/f', type:'number', required:true, block:'Liability',
    synonyms:['Liability B/F','Lease Liability B/F','Opening Liability','Liability Brought Forward','Opening Balance','Liability at 1 Jan','Lease Liability Opening','Liability Opening','Opening Lease Liability','Balance B/F','租赁负债期初','期初租赁负债'] },
  { key:'liab_add', label:'Liability additions / remeasurement', type:'number', block:'Liability',
    synonyms:['Liability Additions','Additions (Liability)','Remeasurement of Liability','New Lease Liabilities','Liability Recognised','Modifications (Liability)'] },
  { key:'interest', label:'Interest for the year', type:'number', required:true, block:'Liability',
    synonyms:['Interest','Interest Expense','Finance Cost','Unwinding of Discount','Interest on Lease Liabilities','Accretion','Interest Charge','Finance Charge','Interest Accrued','Unwinding','利息','利息费用'] },
  { key:'payments', label:'Payments in the year', type:'number', required:true, block:'Liability',
    synonyms:['Payments','Lease Payments','Repayments','Payments Made','Cash Paid','Rental Paid','Payments in the Year','Principal and Interest Paid','Less: Payments','Paid','Cash Payments','本期支付','支付','已付'] },
  { key:'liab_close', label:'Lease liability c/f', type:'number', required:true, block:'Liability',
    synonyms:['Liability C/F','Lease Liability C/F','Closing Liability','Liability Carried Forward','Closing Balance','Liability at Year End','Lease Liability Closing','Liability Closing','Closing Lease Liability','Balance C/F','租赁负债期末','期末租赁负债'] },
  { key:'current', label:'Current portion per client', type:'number',
    synonyms:['Current','Current Portion','Within 1 Year','Due Within One Year','Current Liability','Due < 1 Yr','Within One Year','一年内到期'] },
  { key:'noncurrent', label:'Non-current portion per client', type:'number',
    synonyms:['Non-Current','Non-Current Portion','After 1 Year','Due After One Year','Non-Current Liability','Due > 1 Yr','After One Year','一年以上'] },
  { key:'life', label:'Useful life of underlying asset (years)', type:'number',
    synonyms:['Useful Life','Useful Life (Yrs)','Economic Life','Useful Life of Asset','Asset Life','使用年限','使用寿命'] }
];

const STANDARD_COLUMNS = [
  { key:'lease', label:'Leased asset' }, { key:'lessor', label:'Lessor' }, { key:'contract_no', label:'Contract' },
  { key:'commence', label:'Commencement', type:'date', edit:true }, { key:'__termMonths', label:'Term (m)', type:'num', dp:0 },
  { key:'__ratePct', label:'Rate %', type:'num', dp:2 }, { key:'payment', label:'Monthly payment', type:'num', edit:true },
  { key:'initial', label:'Initial liability', type:'num', edit:true },
  { key:'rou_open', label:'ROU b/f', type:'num', edit:true }, { key:'__dep', label:'ROU depreciation', type:'num' }, { key:'rou_close', label:'ROU c/f', type:'num', edit:true },
  { key:'liab_open', label:'Liability b/f', type:'num', edit:true }, { key:'__int', label:'Interest', type:'num' }, { key:'__pay', label:'Payments', type:'num' },
  { key:'liab_close', label:'Liability c/f', type:'num', edit:true, emphasis:true }
];

const defaultConfig = () => ({
  castTol: 0.01,
  recTol: '',                    // blank = clearly trivial threshold
  recTolPct: 0,                  // % of the audit figure; a line is flagged when the difference exceeds the greater of the two
  convention: 'auto',            // auto | month-incl | month-next
  payTiming: 'arrears',          // arrears | advance
  termUnit: 'auto',              // auto | months | years
  rebuildBasis: 'audit',         // audit: roll from commencement; client: roll the year from the client's opening liability
  rouLife: 'shorter',            // shorter of lease term and useful life | term
  splitBasis: 'client',          // amortise the next twelve months from the client's closing or the audited closing
  tbRou: '', tbLiab: '', tbCurrent: '', tbNonCurrent: '',
  pnlInterest: '', pnlDepreciation: '', pnlExempt: '',
  exRows: 4, lowValueThreshold: 5000
});

/* ============================================================ COMPUTE */
function compute(recs, cfg, eng) {
  const ye = eng.yearEndDate, fys = eng.fyStartDate;
  const pm = eng.materiality?.pm || 0, trivial = eng.materiality?.trivial || 0;
  const tol = Number(cfg.castTol) || 0.01;
  const recTol = cfg.recTol !== '' && cfg.recTol != null ? Number(cfg.recTol) : trivial;
  const recPct = Number(cfg.recTolPct) >= 0 ? Number(cfg.recTolPct) : 0;
  const advance = cfg.payTiming === 'advance';
  const live = recs.filter(r => !r.__excluded);

  /* term unit and rate scale */
  let unit = cfg.termUnit;
  if (unit === 'auto') { const v = live.map(r => r.term).filter(x => x > 0); unit = v.length && v.filter(x => x > 15).length / v.length >= 0.5 ? 'months' : 'years'; }
  const rates = live.map(r => r.rate).filter(x => x != null && x !== 0);
  const rateIsFraction = rates.length > 0 && rates.every(x => Math.abs(x) < 0.5);

  for (const r of recs) {
    r.__displayKey = r.lease || r.contract_no || ('row ' + r.__srcRow);
    r.__key = Core.keyify((r.lease || '') + '|' + (r.contract_no || '')) || ('row' + r.__srcRow);
    r.__termMonths = r.term > 0 ? Math.round(unit === 'years' ? r.term * 12 : r.term) : 0;
    r.__ratePct = r.rate == null ? null : (rateIsFraction ? r.rate * 100 : r.rate);
    r.__dep = Math.abs(r.rou_dep || 0);
    r.__pay = Math.abs(r.payments || 0);
    r.__int = Math.abs(r.interest || 0);
    r.__rouAdd = Math.abs(r.rou_add || 0);
    r.__afterYE = !!(r.commence && ye && r.commence > ye);
    r.__inYear = !!(r.commence && fys && r.commence >= fys && !r.__afterYE);
  }

  /* payment convention: auto picks the one whose contractual payments best reproduce the payments per the schedule */
  let convention = cfg.convention || 'auto';
  if (convention === 'auto') {
    const miss = incl => live.reduce((s, r) => s + Math.abs(r.__pay - (r.payment || 0) * timing(r, fys, ye, incl).months), 0);
    const a = miss(true), b = miss(false);
    convention = b < a - 0.005 ? 'month-next' : 'month-incl';
  }
  const incl = convention !== 'month-next';

  for (const r of live) {
    const T = r.__termMonths, pmt = r.payment || 0, rate = r.__ratePct || 0;
    const w = r.__wp || {};
    /* ---- timing ----------------------------------------------------- */
    const { elapsed, months } = timing(r, fys, ye, incl);
    r.__elapsed = elapsed; r.__months = months;
    r.__remainingAtYE = Math.max(0, T - elapsed - months);
    r.__expiry = r.end || (r.commence && T ? addMonths(r.commence, T) : null);

    /* ---- Y3.1 liability rebuild ------------------------------------- */
    r.__initAudit = r2(pvAnnuity(pmt, rate, T, advance));
    r.__initClient = r.initial;
    r.__initDiff = r.initial != null ? r2(r.initial - r.__initAudit) : null;
    const initBasis = r.initial != null && cfg.rebuildBasis === 'client' ? r.initial : r.__initAudit;
    const pre = amortise(initBasis, rate, pmt, elapsed, advance);
    r.__openAudit = r.__inYear || r.__afterYE ? 0 : pre.closing;
    r.__openDiff = r2((r.liab_open || 0) - r.__openAudit);
    r.__liabAdd = r.liab_add != null ? Math.abs(r.liab_add) : (r.__inYear ? (r.initial != null ? r.initial : r.__initAudit) : 0);
    const openBasis = cfg.rebuildBasis === 'client' ? (r.liab_open || 0) + r.__liabAdd : r.__openAudit + (r.__inYear ? initBasis : 0);
    const yr = amortise(openBasis, rate, pmt, months, advance);
    r.__intAudit = yr.interest; r.__payAudit = r2(pmt * months); r.__principalAudit = yr.principal; r.__closeAudit = yr.closing;
    r.__intDiff = r2(r.__int - r.__intAudit);
    r.__payDiff = r2(r.__pay - r.__payAudit);
    r.__closeDiff = r.liab_close != null ? r2(r.liab_close - r.__closeAudit) : null;
    r.__castCalc = r2((r.liab_open || 0) + r.__liabAdd + r.__int - r.__pay);
    r.__castDiff = r.liab_close != null ? r2(r.liab_close - r.__castCalc) : null;
    r.__closeExplainedByCast = r.__closeDiff != null && r.__castDiff != null && Math.abs(r.__closeDiff - r.__castDiff) <= tol;
    r.__effRate = (r.liab_open > 0 && months > 0) ? r2(r.__int / ((r.liab_open + (r.liab_close || 0)) / 2) * 12 / months * 100) : null;
    const line = a => Math.max(recTol, Math.abs(a || 0) * recPct / 100);
    r.__initBreak = r.__initDiff != null && Math.abs(r.__initDiff) > line(r.__initAudit);
    r.__openBreak = !r.__inYear && !r.__afterYE && Math.abs(r.__openDiff) > line(r.__openAudit);
    r.__intBreak = Math.abs(r.__intDiff) > line(r.__intAudit);
    r.__payBreak = Math.abs(r.__payDiff) > line(r.__payAudit);
    r.__closeBreak = r.__closeDiff != null && Math.abs(r.__closeDiff) > line(r.__closeAudit) && !r.__closeExplainedByCast;
    r.__negative = (r.liab_close != null && r.liab_close < -0.005) || (r.rou_close != null && r.rou_close < -0.005);

    /* ---- Y3.2 right-of-use depreciation ------------------------------ */
    const idc = num(w.rou?.idc) || 0, incentives = num(w.rou?.incentives) || 0;
    r.__rouInitial = r2(initBasis + idc - incentives);
    const lifeMonths = r.life > 0 ? Math.round(r.life * 12) : 0;
    r.__depMonths = cfg.rouLife === 'shorter' && lifeMonths > 0 ? Math.min(T, lifeMonths) : T;
    const monthly = r.__depMonths > 0 ? r.__rouInitial / r.__depMonths : 0;
    r.__rouOpenAudit = r2(r.__inYear || r.__afterYE ? 0 : Math.max(0, r.__rouInitial - monthly * elapsed));
    r.__rouOpenDiff = r2((r.rou_open || 0) - r.__rouOpenAudit);
    const rouBase = (r.rou_open || 0) + r.__rouAdd + (r.__inYear && !r.__rouAdd && !(r.rou_open > 0) ? r.__rouInitial : 0);
    r.__depAudit = r2(Math.min(monthly * months, Math.max(0, rouBase)));
    r.__depDiff = r2(r.__dep - r.__depAudit);
    r.__depBreak = Math.abs(r.__depDiff) > line(r.__depAudit);
    r.__impliedTerm = r.__dep > 0 && months > 0 && r.__rouInitial > 0 ? r2(r.__rouInitial / r.__dep * months) : null;
    r.__rouCloseCalc = r2(rouBase - r.__dep);
    r.__rouCast = r.rou_close != null ? r2(r.rou_close - r.__rouCloseCalc) : null;
    r.__rouCloseAudit = r2(rouBase - r.__depAudit);

    /* ---- Y3.4 split ------------------------------------------------- */
    const closeBasis = cfg.splitBasis === 'audit' ? r.__closeAudit : (r.liab_close ?? r.__closeAudit);
    r.__splitBase = closeBasis;
    const nxt = amortise(closeBasis, rate, pmt, Math.min(12, r.__remainingAtYE), advance);
    r.__curAudit = r2(r.__remainingAtYE <= 12 ? Math.max(0, closeBasis || 0) : Math.min(Math.max(0, closeBasis || 0), nxt.principal));
    r.__ncAudit = r2(Math.max(0, closeBasis || 0) - r.__curAudit);
    r.__intNext = nxt.interest;
    r.__curClient = r.current != null ? r.current : num(w.split?.clientCurrent);
    r.__ncClient = r.noncurrent != null ? r.noncurrent : num(w.split?.clientNonCurrent);
    r.__splitSum = (r.__curClient != null || r.__ncClient != null) ? r2((r.__curClient || 0) + (r.__ncClient || 0)) : null;
    r.__splitCast = (r.__splitSum != null && r.liab_close != null) ? r2(r.__splitSum - r.liab_close) : null;
    r.__curDiff = r.__curClient != null ? r2(r.__curClient - r.__curAudit) : null;
    r.__curBreak = r.__curDiff != null && Math.abs(r.__curDiff) > recTol;

    /* ---- Y3.5 maturity (undiscounted) ------------------------------- */
    const rem = r.__remainingAtYE;
    r.__m1 = r2(pmt * Math.min(12, rem));
    r.__m2to5 = r2(pmt * clamp(rem - 12, 0, 48));
    r.__m5 = r2(pmt * Math.max(0, rem - 60));
    r.__undiscounted = r2(r.__m1 + r.__m2to5 + r.__m5);
    r.__unearned = r2(r.__undiscounted - (closeBasis || 0));

    /* ---- Y3.6 agreement vouching ------------------------------------ */
    const a = w.agree || {};
    r.__agr = a;
    r.__notAgreed = ['agrCommence', 'agrTerm', 'agrPayment', 'agrRate'].filter(k => a[k] === 'N');
    r.__modified = a.modified === 'Y';
    r.__vouched = ['agrCommence', 'agrTerm', 'agrPayment', 'agrRate'].every(k => a[k] === 'Y');

    /* ---- Y3 lead ---------------------------------------------------- */
    const L = w.lead || {};
    r.__pyRou = num(L.pyRou); r.__pyLiab = num(L.pyLiab);
    r.__pyRouDiff = r.__pyRou != null ? r2((r.rou_open || 0) - r.__pyRou) : null;
    r.__pyLiabDiff = r.__pyLiab != null ? r2((r.liab_open || 0) - r.__pyLiab) : null;
    r.__badRate = !(rate > 0) && (r.__initAudit > 0 || (r.liab_close || 0) > 0);
  }

  const sum = f => r2(live.reduce((s, r) => s + (f(r) || 0), 0));
  const totals = {
    initClient: sum(r => r.initial), initAudit: sum(r => r.__initAudit),
    rouOpen: sum(r => r.rou_open), rouAdd: sum(r => r.__rouAdd), dep: sum(r => r.__dep), depAudit: sum(r => r.__depAudit), rouClose: sum(r => r.rou_close), rouCloseCalc: sum(r => r.__rouCloseCalc),
    liabOpen: sum(r => r.liab_open), liabAdd: sum(r => r.__liabAdd), interest: sum(r => r.__int), intAudit: sum(r => r.__intAudit), pay: sum(r => r.__pay), payAudit: sum(r => r.__payAudit),
    liabClose: sum(r => r.liab_close), closeAudit: sum(r => r.__closeAudit), castCalc: sum(r => r.__castCalc), openAudit: sum(r => r.__openAudit),
    curClient: sum(r => r.__curClient), ncClient: sum(r => r.__ncClient), curAudit: sum(r => r.__curAudit), ncAudit: sum(r => r.__ncAudit),
    m1: sum(r => r.__m1), m2to5: sum(r => r.__m2to5), m5: sum(r => r.__m5), undiscounted: sum(r => r.__undiscounted), unearned: sum(r => r.__unearned),
    pyRou: sum(r => r.__pyRou), pyLiab: sum(r => r.__pyLiab)
  };
  totals.castDiff = r2(totals.liabClose - totals.castCalc);
  totals.depDiff = r2(totals.dep - totals.depAudit);
  totals.intDiff = r2(totals.interest - totals.intAudit);
  totals.rouCast = r2(totals.rouClose - totals.rouCloseCalc);

  const tbRou = num(cfg.tbRou), tbLiab = num(cfg.tbLiab), tbCur = num(cfg.tbCurrent), tbNC = num(cfg.tbNonCurrent);
  const pnlInt = num(cfg.pnlInterest), pnlDep = num(cfg.pnlDepreciation);
  const lead = { tbRou, tbLiab, tbCur, tbNC, tbRouDiff: tbRou != null ? r2(totals.rouClose - tbRou) : null, tbLiabDiff: tbLiab != null ? r2(totals.liabClose - tbLiab) : null,
    tbCurDiff: tbCur != null ? r2(totals.curAudit - tbCur) : null, tbNCDiff: tbNC != null ? r2(totals.ncAudit - tbNC) : null,
    pnlInt, pnlDep, pnlIntDiff: pnlInt != null ? r2(totals.interest - pnlInt) : null, pnlDepDiff: pnlDep != null ? r2(totals.dep - pnlDep) : null,
    pyBreaks: live.filter(r => (r.__pyRouDiff != null && Math.abs(r.__pyRouDiff) > tol) || (r.__pyLiabDiff != null && Math.abs(r.__pyLiabDiff) > tol)),
    pyEntered: live.filter(r => r.__pyRou != null || r.__pyLiab != null).length,
    active: live.filter(r => (r.liab_close || 0) > 0.005 || (r.rou_close || 0) > 0.005).length,
    expired: live.filter(r => r.__remainingAtYE === 0 && !r.__afterYE).length };

  const liability = { tol: recTol, pct: recPct, castBreaks: live.filter(r => r.__castDiff != null && Math.abs(r.__castDiff) > tol),
    initBreaks: live.filter(r => r.__initBreak), openBreaks: live.filter(r => r.__openBreak), intBreaks: live.filter(r => r.__intBreak),
    payBreaks: live.filter(r => r.__payBreak), closeBreaks: live.filter(r => r.__closeBreak), negative: live.filter(r => r.__negative) };
  const rou = { breaks: live.filter(r => r.__depBreak), castBreaks: live.filter(r => r.__rouCast != null && Math.abs(r.__rouCast) > tol), unit,
    openBreaks: live.filter(r => !r.__inYear && !r.__afterYE && Math.abs(r.__rouOpenDiff) > Math.max(recTol, Math.abs(r.__rouOpenAudit) * recPct / 100)) };
  const split = { basis: cfg.splitBasis, tol: recTol, castBreaks: live.filter(r => r.__splitCast != null && Math.abs(r.__splitCast) > tol), curBreaks: live.filter(r => r.__curBreak),
    entered: live.filter(r => r.__curClient != null).length, allCurrent: live.filter(r => r.__remainingAtYE > 0 && r.__remainingAtYE <= 12) };
  const maturity = { totals, reconciles: Math.abs(r2(totals.undiscounted - totals.unearned) - (cfg.splitBasis === 'audit' ? totals.closeAudit : totals.liabClose)) <= 0.05 };
  const agreement = { vouched: live.filter(r => r.__vouched).length, notAgreed: live.filter(r => r.__notAgreed.length), modified: live.filter(r => r.__modified),
    sighted: live.filter(r => r.__agr.agrSighted === 'Y').length, ibr: live.filter(r => r.__agr.ibrSupport === 'Y').length, afterYE: live.filter(r => r.__afterYE), badRate: live.filter(r => r.__badRate) };

  /* ---- Y3.7 exemptions -------------------------------------------- */
  const lowValue = Number(cfg.lowValueThreshold) || 0;
  const nEx = clamp(Math.round(Number(cfg.exRows) || 0), 0, 40);
  const exRows = [];
  for (let i = 1; i <= nEx; i++) {
    const k = 'ex' + i;
    const desc = txt(cfg, 'exDesc', k), type = txt(cfg, 'exType', k), term = inp(cfg, 'exTerm', k), value = inp(cfg, 'exValue', k), expense = inp(cfg, 'exExpense', k), option = txt(cfg, 'exOption', k);
    if (!desc && term == null && value == null && expense == null && !type) continue;
    let status = 'Not assessed', why = '';
    if (type === EXEMPTION_TYPES[0]) {
      if (term == null) { status = 'Not assessed'; why = 'Enter the lease term'; }
      else if (term <= 12 && option !== 'Y') { status = 'Qualifies'; why = 'Term of twelve months or less with no purchase option'; }
      else { status = 'Does not qualify'; why = term > 12 ? `Term of ${term} months exceeds twelve months` : 'A lease containing a purchase option is not short-term (FRS 116 App A)'; }
    } else if (type === EXEMPTION_TYPES[1]) {
      if (value == null) { status = 'Not assessed'; why = 'Enter the value of the underlying asset when new'; }
      else if (value <= lowValue) { status = 'Qualifies'; why = `Value when new at or below the ${lowValue.toLocaleString()} threshold`; }
      else { status = 'Does not qualify'; why = `Value when new ${value.toLocaleString()} exceeds the threshold` };
    }
    exRows.push({ key:k, i, desc, type, term, value, expense, option, status, why });
  }
  const pnlEx = num(cfg.pnlExempt);
  const exemptions = { rows: exRows, fails: exRows.filter(x => x.status === 'Does not qualify'), qualifies: exRows.filter(x => x.status === 'Qualifies').length,
    expense: r2(exRows.reduce((s, x) => s + (x.expense || 0), 0)), pnl: pnlEx, threshold: lowValue };
  exemptions.pnlDiff = pnlEx != null ? r2(exemptions.expense - pnlEx) : null;

  return { totals, lead, liability, rou, split, maturity, agreement, exemptions, leases: live, pm, trivial, tol, convention, conventionAuto: (cfg.convention || 'auto') === 'auto', advance, termUnit: unit, rateIsFraction };
}

/* ============================================================== TESTS */
const tests = [
  { id:'EX-LSE-01', label:'Lease liability movement does not cast', basis:'Y3.1',
    fn:(r, cfg) => r.__castDiff != null && Math.abs(r.__castDiff) > (Number(cfg.castTol) || 0.01) &&
      { expected: r.__castCalc, actual: r.liab_close, difference: r.__castDiff, cell: r['__cell_liab_close'],
        detail:`Opening ${(r.liab_open || 0).toFixed(2)} + additions ${r.__liabAdd.toFixed(2)} + interest ${r.__int.toFixed(2)} − payments ${r.__pay.toFixed(2)} = ${r.__castCalc.toFixed(2)}; closing per schedule ${r.liab_close.toFixed(2)}. Obtain the client's lease workings and identify the unrecorded movement.` } },
  { id:'EX-LSE-02', label:'Right-of-use depreciation inconsistent with the lease term', basis:'Y3.2',
    fn:(r) => r.__depBreak && { expected: r.__depAudit, actual: r.__dep, difference: r.__depDiff, cell: r['__cell_rou_dep'],
      detail:`Straight line over ${r.__depMonths} months on an initial right-of-use asset of ${r.__rouInitial.toFixed(2)} gives ${r.__depAudit.toFixed(2)} for ${r.__months} month(s)${r.__impliedTerm ? `; the charge recorded implies a term of ${Math.round(r.__impliedTerm)} months against ${r.__termMonths}` : ''}.` } },
  { id:'EX-LSE-03', label:'Initial lease liability differs from the present value of the payments', basis:'Y3.1',
    fn:(r) => r.__initBreak && { expected: r.__initAudit, actual: r.initial, difference: r.__initDiff, cell: r['__cell_initial'],
      detail:`Present value of ${r.__termMonths} monthly payments of ${(r.payment || 0).toFixed(2)} at ${r.__ratePct}% is ${r.__initAudit.toFixed(2)}. Check the payment profile, rate and timing in the agreement.` } },
  { id:'EX-LSE-04', label:'Opening lease liability differs from the rebuilt amortisation', basis:'Y3.1',
    fn:(r) => r.__openBreak && { expected: r.__openAudit, actual: r.liab_open, difference: r.__openDiff, cell: r['__cell_liab_open'],
      detail:`Liability after ${r.__elapsed} payment(s) from commencement per audit ${r.__openAudit.toFixed(2)}` } },
  { id:'EX-LSE-05', label:'Interest on the lease liability differs from the effective-interest recalculation', basis:'Y3.1',
    fn:(r) => r.__intBreak && { expected: r.__intAudit, actual: r.__int, difference: r.__intDiff, cell: r['__cell_interest'],
      detail:`Recomputed at ${r.__ratePct}% over ${r.__months} month(s): ${r.__intAudit.toFixed(2)}${r.__effRate != null ? `; rate implied by the charge ${r.__effRate.toFixed(2)}%` : ''}` } },
  { id:'EX-LSE-06', label:'Payments in the year differ from the contractual payments', basis:'Y3.1',
    fn:(r) => r.__payBreak && { expected: r.__payAudit, actual: r.__pay, difference: r.__payDiff, cell: r['__cell_payments'],
      detail:`${r.__months} month(s) × ${(r.payment || 0).toFixed(2)} = ${r.__payAudit.toFixed(2)}. Agree payments to the bank statements and consider whether a rent-free period, escalation or modification applies.` } },
  { id:'EX-LSE-07', label:'Closing lease liability differs from the rebuilt amortisation', basis:'Y3.1',
    fn:(r) => r.__closeBreak && { expected: r.__closeAudit, actual: r.liab_close, difference: r.__closeDiff, cell: r['__cell_liab_close'],
      detail:'Closing liability per audit rebuilt from commencement at the stated rate and payment' } },
  { id:'EX-LSE-08', label:'Right-of-use asset roll-forward does not cast', basis:'Y3.2',
    fn:(r, cfg) => r.__rouCast != null && Math.abs(r.__rouCast) > (Number(cfg.castTol) || 0.01) &&
      { expected: r.__rouCloseCalc, actual: r.rou_close, difference: r.__rouCast, cell: r['__cell_rou_close'],
        detail:`ROU b/f ${(r.rou_open || 0).toFixed(2)} + additions ${r.__rouAdd.toFixed(2)} − depreciation ${r.__dep.toFixed(2)} = ${r.__rouCloseCalc.toFixed(2)}; c/f per schedule ${r.rou_close.toFixed(2)}` } },
  { id:'EX-LSE-09', label:'Current portion differs from the principal falling due in the next twelve months', basis:'Y3.4', severity:'informational',
    fn:(r) => r.__curBreak && { expected: r.__curAudit, actual: r.__curClient, difference: r.__curDiff, cell: r['__cell_current'],
      detail:`Principal repayable in the twelve months after the reporting date per the amortisation is ${r.__curAudit.toFixed(2)}` } },
  { id:'EX-LSE-10', label:'Current and non-current portions do not cast to the closing liability', basis:'Y3.4',
    fn:(r, cfg) => r.__splitCast != null && Math.abs(r.__splitCast) > (Number(cfg.castTol) || 0.01) &&
      { expected: r.liab_close, actual: r.__splitSum, difference: r.__splitCast, cell: r['__cell_current'] } },
  { id:'EX-LSE-11', scope:'population', label:'Recognition exemption claimed for a lease that does not qualify', basis:'Y3.7', severity:'above-trivial',
    fn:(recs, cfg, eng, d) => d.exemptions.fails.map(x => ({ key: x.desc || ('Exemption line ' + x.i), actual: x.type === EXEMPTION_TYPES[0] ? x.term : x.value, difference: x.expense,
      detail:`${x.why}. The lease should be recognised on balance sheet (FRS 116 para 22).` })) },
  { id:'EX-LSE-12', label:'Lease terms per the schedule not agreed to the lease agreement', basis:'Y3.6', severity:'above-trivial',
    fn:(r) => r.__notAgreed.length > 0 && { actual: r.__notAgreed.map(k => ({ agrCommence:'commencement', agrTerm:'term', agrPayment:'payment', agrRate:'discount rate' })[k]).join(', '), difference: r.liab_close, cell: r['__cell_lease'],
      detail:'One or more inputs to the lease calculation do not agree to the signed agreement. Recompute the liability on the agreed terms.' } },
  { id:'EX-LSE-13', label:'Lease modified in the year — remeasurement to be verified', basis:'Y3.6', severity:'informational',
    fn:(r) => r.__modified && { difference: r.liab_close, cell: r['__cell_lease'], detail:'A modification requires the liability to be remeasured at a revised discount rate with a corresponding adjustment to the right-of-use asset (FRS 116 para 44–46).' } },
  { id:'EX-LSE-14', label:'No discount rate, or lease commencing after the reporting date', basis:'Y3.1', severity:'above-trivial',
    fn:(r) => (r.__badRate || r.__afterYE) && { actual: r.__afterYE ? Core.fmtDate(r.commence) : r.rate, difference: r.liab_close, cell: r.__afterYE ? r['__cell_commence'] : r['__cell_rate'],
      detail: r.__afterYE ? 'Commencement falls after the reporting date; no right-of-use asset or liability should be recognised yet' : 'A discount rate is required to measure the liability (FRS 116 para 26)' } },
  { id:'EX-LSE-15', label:'Negative closing liability or right-of-use asset', basis:'Y3.1',
    fn:(r) => r.__negative && { actual: r.liab_close, difference: Math.min(r.liab_close || 0, r.rou_close || 0), cell: r['__cell_liab_close'] } },
  { id:'EX-LSE-20', scope:'population', label:'Schedule does not agree to the trial balance', basis:'Y3',
    fn:(recs, cfg, eng, d) => { const out = [], t = Number(cfg.castTol) || 0.01;
      if (d.lead.tbRouDiff != null && Math.abs(d.lead.tbRouDiff) > t) out.push({ key:'Right-of-use assets', expected: d.lead.tbRou, actual: d.totals.rouClose, difference: d.lead.tbRouDiff });
      if (d.lead.tbLiabDiff != null && Math.abs(d.lead.tbLiabDiff) > t) out.push({ key:'Lease liabilities', expected: d.lead.tbLiab, actual: d.totals.liabClose, difference: d.lead.tbLiabDiff });
      return out; } },
  { id:'EX-LSE-21', scope:'population', label:'Interest per schedule does not agree to finance cost in the profit or loss', basis:'Y3',
    fn:(recs, cfg, eng, d) => d.lead.pnlIntDiff != null && Math.abs(d.lead.pnlIntDiff) > (Number(cfg.castTol) || 0.01) &&
      { key:'Interest on lease liabilities', expected: d.lead.pnlInt, actual: d.totals.interest, difference: d.lead.pnlIntDiff } },
  { id:'EX-LSE-22', scope:'population', label:'Depreciation per schedule does not agree to the profit or loss', basis:'Y3',
    fn:(recs, cfg, eng, d) => d.lead.pnlDepDiff != null && Math.abs(d.lead.pnlDepDiff) > (Number(cfg.castTol) || 0.01) &&
      { key:'Depreciation of right-of-use assets', expected: d.lead.pnlDep, actual: d.totals.dep, difference: d.lead.pnlDepDiff } },
  { id:'EX-LSE-23', scope:'population', label:'Opening balances do not agree to the prior year audited figures', basis:'Y3',
    fn:(recs, cfg, eng, d) => d.lead.pyBreaks.map(r => ({ key: r.__displayKey, expected: r.__pyLiab ?? r.__pyRou, actual: r.__pyLiab != null ? r.liab_open : r.rou_open,
      difference: r2((r.__pyLiabDiff || 0) + (r.__pyRouDiff || 0)), detail:`ROU b/f − PY ${r.__pyRouDiff != null ? r.__pyRouDiff.toFixed(2) : 'n/a'}; liability b/f − PY ${r.__pyLiabDiff != null ? r.__pyLiabDiff.toFixed(2) : 'n/a'}` })) },
  { id:'EX-LSE-24', scope:'population', label:'Short-term / low-value lease expense does not agree to the profit or loss', basis:'Y3.7', severity:'informational',
    fn:(recs, cfg, eng, d) => d.exemptions.pnlDiff != null && Math.abs(d.exemptions.pnlDiff) > (Number(cfg.castTol) || 0.01) &&
      { key:'Exempt lease expense', expected: d.exemptions.pnl, actual: d.exemptions.expense, difference: d.exemptions.pnlDiff } }
];

/* ============================================================== PAGES */
const yn = ['Y', 'N'];
const flagAbs = (v, t = 0.01) => v != null && Math.abs(v) > t;
const leaseRow = r => ({ __rec:r, __key:r.__key, lease:r.lease, lessor:r.lessor, contract:r.contract_no, commence:r.commence, term:r.__termMonths, rate:r.__ratePct != null ? r.__ratePct / 100 : null, payment:r.payment,
  months:r.__months, elapsed:r.__elapsed, remaining:r.__remainingAtYE });
const LEASE_COLS = [{ key:'lease', label:'Leased asset', emphasis:true }, { key:'lessor', label:'Lessor' }, { key:'contract', label:'Contract' }];
const cls = brk => brk ? 'flag' : '';

const pages = [
  { id:'source',  ref:'Y3.0',  title:'Source data',     kind:'source' },
  { id:'cleaned', ref:'Y3.0a', title:'Cleaned listing', kind:'cleaned' },
  { id:'mapping', ref:'Y3.0b', title:'Column mapping',  kind:'mapping' },

  { id:'lead', ref:'Y3', title:'Lead schedule',
    objective:'To agree right-of-use assets and lease liabilities per the lease schedule to the trial balance and to the prior year audited figures for every lease, and to agree interest and depreciation to the profit or loss.',
    procedures:['Cast the lease schedule and agreed total right-of-use assets and lease liabilities to the trial balance.',
                'Agreed the opening right-of-use asset and lease liability of each lease to the prior year audited closing balances.',
                'Agreed interest on lease liabilities and depreciation of right-of-use assets per the schedule to the profit or loss.'],
    render(st, ctx) {
      const d = ctx.d, T = d.totals, L = d.lead, m0 = ctx.money0, money = ctx.money;
      const st_ = (v, t) => v == null ? '' : Math.abs(v) > (t || 0.01) ? 'bad' : 'ok';
      return [
        { type:'controls', items:[
          { key:'tbRou', label:'Right-of-use assets per trial balance (carrying amount)', kind:'number' },
          { key:'tbLiab', label:'Lease liabilities per trial balance (total)', kind:'number' },
          { key:'tbCurrent', label:'Lease liabilities — current per trial balance', kind:'number' },
          { key:'tbNonCurrent', label:'Lease liabilities — non-current per trial balance', kind:'number' },
          { key:'pnlInterest', label:'Interest on lease liabilities per profit or loss', kind:'number' },
          { key:'pnlDepreciation', label:'Depreciation of right-of-use assets per profit or loss', kind:'number' },
          { key:'castTol', label:'Tolerance for differences', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Leases', value: `${d.leases.length} (${L.active} active, ${L.expired} expired in or before the year)` },
          { label:'ROU assets c/f', value: m0(T.rouClose) }, { label:'ROU − TB', value: L.tbRouDiff == null ? '— enter —' : money(L.tbRouDiff), cls: st_(L.tbRouDiff) },
          { label:'Lease liabilities c/f', value: m0(T.liabClose) }, { label:'Liabilities − TB', value: L.tbLiabDiff == null ? '— enter —' : money(L.tbLiabDiff), cls: st_(L.tbLiabDiff) },
          { label:'Interest − P&L', value: L.pnlIntDiff == null ? '— enter —' : money(L.pnlIntDiff), cls: st_(L.pnlIntDiff) },
          { label:'Depreciation − P&L', value: L.pnlDepDiff == null ? '— enter —' : money(L.pnlDepDiff), cls: st_(L.pnlDepDiff) },
          { label:'Current per audit − TB', value: L.tbCurDiff == null ? '— enter —' : money(L.tbCurDiff), cls: st_(L.tbCurDiff, d.split.tol) } ] },
        { type:'table', title:'Leases — schedule vs prior year', columns:[...LEASE_COLS,
          { key:'commence', label:'Commencement', type:'date' }, { key:'term', label:'Term (m)', type:'int' },
          { key:'pyRou', label:'PY audited ROU c/f', input:'number' }, { key:'rouOpen', label:'ROU b/f per schedule', type:'num', sum:true }, { key:'pyRouDiff', label:'ROU b/f − PY', type:'num', flag: v => flagAbs(v) },
          { key:'rouClose', label:'ROU c/f per schedule', type:'num', sum:true },
          { key:'pyLiab', label:'PY audited liability c/f', input:'number' }, { key:'liabOpen', label:'Liability b/f per schedule', type:'num', sum:true }, { key:'pyLiabDiff', label:'Liability b/f − PY', type:'num', flag: v => flagAbs(v) },
          { key:'liabClose', label:'Liability c/f per schedule', type:'num', sum:true },
          { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: d.leases.map(r => ({ ...leaseRow(r), rouOpen:r.rou_open, rouClose:r.rou_close, liabOpen:r.liab_open, liabClose:r.liab_close, pyRouDiff:r.__pyRouDiff, pyLiabDiff:r.__pyLiabDiff,
            __cls: cls(flagAbs(r.__pyRouDiff) || flagAbs(r.__pyLiabDiff)) })),
          footnote:'Differences to the trial balance are raised as EX-LSE-20, to the profit or loss as EX-LSE-21 and EX-LSE-22, and opening balances not agreeing to the prior year as EX-LSE-23.' },
        { type:'table', title:'Summary of movements', columns:[{ key:'item', label:'' }, { key:'open', label:'Opening', type:'num' }, { key:'add', label:'Additions', type:'num' }, { key:'charge', label:'Interest / depreciation', type:'num' }, { key:'pay', label:'Payments', type:'num' }, { key:'close', label:'Closing per schedule', type:'num' }, { key:'calc', label:'Closing recomputed', type:'num' }, { key:'diff', label:'Difference', type:'num', flag: v => flagAbs(v) }],
          rows:[{ item:'Lease liabilities', open:T.liabOpen, add:T.liabAdd, charge:T.interest, pay:-T.pay, close:T.liabClose, calc:T.castCalc, diff:T.castDiff },
                { item:'Right-of-use assets', open:T.rouOpen, add:T.rouAdd, charge:-T.dep, pay:null, close:T.rouClose, calc:T.rouCloseCalc, diff:T.rouCast }], totals:false }
      ];
    },
    flag(st, d) { return flagAbs(d.lead.tbRouDiff) || flagAbs(d.lead.tbLiabDiff) || flagAbs(d.lead.pnlIntDiff) || flagAbs(d.lead.pnlDepDiff) || d.lead.pyBreaks.length > 0; } },

  { id:'liability', ref:'Y3.1', title:'Lease liability rebuild',
    objective:'To recompute each lease liability from the agreement terms — the present value of the payments at the discount rate over the term, amortised month by month on the effective-interest method — and to compare the opening balance, interest, payments and closing balance with the client\'s schedule, and to prove the schedule casts.',
    procedures:['Recomputed the initial liability as the present value of the monthly payments at the discount rate over the lease term and compared it with the initial liability per the schedule.',
                'Rolled the liability month by month from commencement to the start of the year to obtain the opening balance, then through the year accumulating interest and payments.',
                'Compared opening, interest, payments and closing per audit with the schedule and cast the client\'s movement for every lease.'],
    render(st, ctx) {
      const d = ctx.d, T = d.totals, Lb = d.liability, money = ctx.money, m0 = ctx.money0;
      return [
        { type:'controls', items:[
          { key:'convention', label:'Payment convention', kind:'select', options: CONVENTIONS.map(c => [c.key, c.key === 'auto' ? `${c.label} (currently ${d.convention})` : c.label]),
            help: d.conventionAuto ? `Auto-detected: ${CONVENTIONS.find(c => c.key === d.convention)?.label}. Confirm against the payment dates in the agreements.` : '' },
          { key:'payTiming', label:'Payment timing', kind:'select', options:[['arrears', 'In arrears (end of each month)'], ['advance', 'In advance (start of each month)']] },
          { key:'termUnit', label:'Lease term stated in', kind:'select', options:[['auto', `Auto-detect (currently ${d.termUnit})`], ['months', 'Months'], ['years', 'Years']] },
          { key:'rebuildBasis', label:'Rebuild the year from', kind:'select', options:[['audit', 'Commencement — full rebuild at the recomputed initial liability'], ['client', 'The client\'s opening liability and initial liability']] },
          { key:'recTol', label:'Tolerance — absolute (blank = clearly trivial threshold)', kind:'number', help:`In use: ${m0(Lb.tol)}` },
          { key:'recTolPct', label:'Tolerance — % of the audit figure', kind:'number', help:'A line is flagged when the difference exceeds the greater of the two.' } ] },
        { type:'stats', items:[
          { label:'Opening per schedule', value: m0(T.liabOpen) }, { label:'Opening per audit', value: m0(T.openAudit) },
          { label:'Interest per schedule', value: m0(T.interest) }, { label:'Interest per audit', value: m0(T.intAudit) }, { label:'Difference', value: money(T.intDiff), cls: Math.abs(T.intDiff || 0) > Lb.tol ? 'bad' : 'ok' },
          { label:'Payments per schedule', value: m0(T.pay) }, { label:'Payments per audit', value: m0(T.payAudit) },
          { label:'Closing per schedule', value: m0(T.liabClose) }, { label:'Closing per audit', value: m0(T.closeAudit) },
          { label:'Movement cast difference', value: money(T.castDiff), cls: flagAbs(T.castDiff) ? 'bad' : 'ok' },
          { label:'Leases not casting', value: Lb.castBreaks.length, cls: Lb.castBreaks.length ? 'bad' : 'ok' } ] },
        ...(d.rateIsFraction ? [{ type:'note', tone:'warn', html:'Discount rates in the schedule are stated as fractions (e.g. 0.045) and were read as percentages (4.5%).' }] : []),
        { type:'table', title:'Initial measurement — present value of the lease payments', columns:[...LEASE_COLS,
          { key:'commence', label:'Commencement', type:'date' }, { key:'expiry', label:'Expiry (derived)', type:'date' }, { key:'term', label:'Term (months)', type:'int' }, { key:'rate', label:'Discount rate', type:'pct', dp:2 }, { key:'payment', label:'Monthly payment', type:'num' },
          { key:'initAudit', label:'PV per audit', type:'num', sum:true }, { key:'initClient', label:'Initial liability per schedule', type:'num', sum:true }, { key:'initDiff', label:'Difference', type:'num', sum:true, flag: (v, row) => row.__brk },
          { key:'elapsed', label:'Months before the year', type:'int' }, { key:'months', label:'Months in the year', type:'int' }, { key:'remaining', label:'Months after year end', type:'int' } ],
          rows: d.leases.map(r => ({ ...leaseRow(r), expiry:r.__expiry, initAudit:r.__initAudit, initClient:r.initial, initDiff:r.__initDiff, __brk:r.__initBreak, __cls: cls(r.__initBreak) })),
          footnote:'A difference beyond the tolerance is raised as EX-LSE-03. The present value uses level monthly payments; leases with escalations, rent-free periods or variable payments need a bespoke rebuild recorded in the comment column below.' },
        { type:'table', title:'Liability for the year — schedule vs audit', columns:[...LEASE_COLS,
          { key:'liabOpen', label:'Opening per schedule', type:'num', sum:true }, { key:'openAudit', label:'Opening per audit', type:'num', sum:true }, { key:'openDiff', label:'Diff', type:'num', flag: (v, row) => row.__openBrk },
          { key:'liabAdd', label:'Additions', type:'num', sum:true },
          { key:'interest', label:'Interest per schedule', type:'num', sum:true }, { key:'intAudit', label:'Interest per audit', type:'num', sum:true }, { key:'intDiff', label:'Diff', type:'num', sum:true, flag: (v, row) => row.__intBrk },
          { key:'pay', label:'Payments per schedule', type:'num', sum:true }, { key:'payAudit', label:'Payments per audit', type:'num', sum:true }, { key:'payDiff', label:'Diff', type:'num', flag: (v, row) => row.__payBrk },
          { key:'liabClose', label:'Closing per schedule', type:'num', sum:true }, { key:'closeAudit', label:'Closing per audit', type:'num', sum:true }, { key:'closeDiff', label:'Diff', type:'num', flag: (v, row) => row.__closeBrk },
          { key:'castCalc', label:'Closing recomputed from the schedule', type:'num', sum:true, formula:(row, C) => `${C(3)}${row}+${C(6)}${row}+${C(7)}${row}-${C(10)}${row}` }, { key:'castDiff', label:'Cast difference', type:'num', sum:true, flag: v => flagAbs(v) },
          { key:'bank', label:'Payments agreed to bank (Y/N)', input:'select', options:yn }, { key:'comment', label:'Explanation', input:'text', wide:true } ],
          rows: d.leases.map(r => ({ ...leaseRow(r), liabOpen:r.liab_open, openAudit:r.__openAudit, openDiff:r.__openDiff, liabAdd:r.__liabAdd || null, interest:r.__int, intAudit:r.__intAudit, intDiff:r.__intDiff, pay:r.__pay, payAudit:r.__payAudit, payDiff:r.__payDiff,
            liabClose:r.liab_close, closeAudit:r.__closeAudit, closeDiff:r.__closeDiff, castCalc:r.__castCalc, castDiff:r.__castDiff,
            __openBrk:r.__openBreak, __intBrk:r.__intBreak, __payBrk:r.__payBreak, __closeBrk:r.__closeBreak, __cls: cls(flagAbs(r.__castDiff) || r.__intBreak || r.__openBreak) })),
          footnote:'A movement that does not cast is raised as EX-LSE-01; opening, interest, payment and closing differences beyond the tolerance as EX-LSE-04 to EX-LSE-07 (a closing difference already explained by the cast difference is not raised twice). Payments and depreciation are taken at absolute value whether the schedule shows them negative or positive.' }
      ];
    },
    flag(st, d) { return d.liability.castBreaks.length > 0 || d.liability.intBreaks.length > 0 || d.liability.initBreaks.length > 0 || d.liability.negative.length > 0; } },

  { id:'rou', ref:'Y3.2', title:'Right-of-use depreciation',
    objective:'To recalculate depreciation of each right-of-use asset on a straight-line basis over the shorter of the lease term and the useful life of the underlying asset (FRS 116 para 32), compare it with the charge recorded, and prove the right-of-use roll-forward casts.',
    procedures:['Determined the initial right-of-use asset as the initial liability adjusted for initial direct costs and lease incentives entered.',
                'Recalculated the depreciation for the year over the shorter of the lease term and the useful life, pro-rated for the months in the year and capped at the opening carrying amount.',
                'Compared the recalculated charge with the charge recorded and cast the client\'s right-of-use roll-forward for every lease.'],
    render(st, ctx) {
      const d = ctx.d, T = d.totals, R = d.rou, money = ctx.money, m0 = ctx.money0;
      return [
        { type:'controls', items:[
          { key:'rouLife', label:'Depreciate over', kind:'select', options:[['shorter', 'Shorter of lease term and useful life (where a useful life is given)'], ['term', 'Lease term only']] } ] },
        { type:'stats', items:[
          { label:'ROU b/f', value: m0(T.rouOpen) }, { label:'Depreciation per schedule', value: m0(T.dep) }, { label:'Depreciation per audit', value: m0(T.depAudit) },
          { label:'Difference', value: money(T.depDiff), cls: Math.abs(T.depDiff || 0) > d.liability.tol ? 'bad' : 'ok' },
          { label:'Leases outside tolerance', value: R.breaks.length, cls: R.breaks.length ? 'bad' : 'ok' },
          { label:'ROU c/f per schedule', value: m0(T.rouClose) }, { label:'Roll-forward cast difference', value: money(T.rouCast), cls: flagAbs(T.rouCast) ? 'bad' : 'ok' } ] },
        { type:'table', title:'Right-of-use asset — depreciation recalculation', columns:[...LEASE_COLS,
          { key:'initLiab', label:'Initial liability (basis)', type:'num' }, { key:'idc', label:'Initial direct costs / prepaid', input:'number' }, { key:'incentives', label:'Lease incentives received', input:'number' },
          { key:'rouInitial', label:'Initial ROU per audit', type:'num' }, { key:'term', label:'Term (m)', type:'int' }, { key:'life', label:'Useful life (m)', type:'int' }, { key:'depMonths', label:'Depreciated over (m)', type:'int' }, { key:'months', label:'Months in year', type:'int' },
          { key:'rouOpen', label:'ROU b/f per schedule', type:'num', sum:true }, { key:'rouOpenAudit', label:'ROU b/f per audit', type:'num', sum:true }, { key:'rouAdd', label:'Additions', type:'num', sum:true },
          { key:'dep', label:'Depreciation per schedule', type:'num', sum:true }, { key:'depAudit', label:'Depreciation per audit', type:'num', sum:true }, { key:'depDiff', label:'Difference', type:'num', sum:true, flag: (v, row) => row.__brk },
          { key:'impliedTerm', label:'Term implied by the charge (m)', type:'int' },
          { key:'rouClose', label:'ROU c/f per schedule', type:'num', sum:true }, { key:'rouCloseCalc', label:'ROU c/f recomputed', type:'num', sum:true, formula:(row, C) => `${C(11)}${row}+${C(13)}${row}-${C(14)}${row}` }, { key:'rouCast', label:'Cast difference', type:'num', flag: v => flagAbs(v) },
          { key:'comment', label:'Explanation', input:'text', wide:true } ],
          rows: d.leases.map(r => ({ ...leaseRow(r), initLiab: r.initial != null && ctx.cfg.rebuildBasis === 'client' ? r.initial : r.__initAudit, rouInitial:r.__rouInitial, life: r.life > 0 ? Math.round(r.life * 12) : null, depMonths:r.__depMonths,
            rouOpen:r.rou_open, rouOpenAudit:r.__rouOpenAudit, rouAdd:r.__rouAdd || null, dep:r.__dep, depAudit:r.__depAudit, depDiff:r.__depDiff, impliedTerm:r.__impliedTerm, rouClose:r.rou_close, rouCloseCalc:r.__rouCloseCalc, rouCast:r.__rouCast,
            __brk:r.__depBreak, __cls: cls(r.__depBreak || flagAbs(r.__rouCast)) })),
          footnote:'A charge outside the tolerance is raised as EX-LSE-02; a right-of-use roll-forward that does not cast as EX-LSE-08. Where ownership transfers or a purchase option is reasonably certain, the asset is depreciated over the useful life instead — record this in the comment.' }
      ];
    },
    flag(st, d) { return d.rou.breaks.length > 0 || d.rou.castBreaks.length > 0; } },

  { id:'split', ref:'Y3.4', title:'Current / non-current split',
    objective:'To recompute the portion of each lease liability repayable within twelve months of the reporting date from the amortisation profile and compare it with the split presented by the client.',
    procedures:['Amortised each liability for the twelve months after the reporting date at the discount rate and monthly payment to obtain the principal falling due — the current portion per audit.',
                'Compared the current and non-current portions per the client (from the schedule or entered from the financial statements) with the recomputation and checked the client split casts to the closing liability.'],
    render(st, ctx) {
      const d = ctx.d, S = d.split, T = d.totals, money = ctx.money, m0 = ctx.money0;
      return [
        { type:'controls', items:[
          { key:'splitBasis', label:'Amortise the next twelve months from', kind:'select', options:[['client', 'Closing liability per the schedule'], ['audit', 'Closing liability rebuilt on Y3.1']] } ] },
        { type:'stats', items:[
          { label:'Current per audit', value: m0(T.curAudit) }, { label:'Non-current per audit', value: m0(T.ncAudit) },
          { label:'Current per client', value: S.entered ? m0(T.curClient) : '— enter —' }, { label:'Difference', value: S.entered ? money(r2(T.curClient - T.curAudit)) : '', cls: S.entered ? (Math.abs(T.curClient - T.curAudit) > S.tol ? 'bad' : 'ok') : '' },
          { label:'Current per TB − audit', value: d.lead.tbCurDiff == null ? '— enter on Y3 —' : money(-d.lead.tbCurDiff), cls: d.lead.tbCurDiff == null ? '' : Math.abs(d.lead.tbCurDiff) > S.tol ? 'bad' : 'ok' },
          { label:'Leases wholly current (expire within a year)', value: S.allCurrent.length },
          { label:'Splits not casting', value: S.castBreaks.length, cls: S.castBreaks.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Split by lease', columns:[...LEASE_COLS,
          { key:'remaining', label:'Months remaining at YE', type:'int' }, { key:'close', label:'Closing liability (basis)', type:'num', sum:true },
          { key:'curAudit', label:'Current per audit', type:'num', sum:true }, { key:'ncAudit', label:'Non-current per audit', type:'num', sum:true }, { key:'intNext', label:'Interest in the next 12 months', type:'num', sum:true },
          { key:'curSched', label:'Current per schedule', type:'num' }, { key:'clientCurrent', label:'Current per client (enter if not in schedule)', input:'number' }, { key:'clientNonCurrent', label:'Non-current per client', input:'number' },
          { key:'splitCast', label:'Client split − closing', type:'num', flag: v => flagAbs(v) }, { key:'curDiff', label:'Current: client − audit', type:'num', flag: (v, row) => row.__brk },
          { key:'status', label:'Status', type:'chip', chipClass: v => v === 'Agrees' ? 'ok' : v === 'Does not cast' ? 'bad' : v === 'Differs' ? 'warn' : 'grey' },
          { key:'comment', label:'Comment / reclassification proposed', input:'text', wide:true } ],
          rows: d.leases.map(r => ({ ...leaseRow(r), close:r.__splitBase, curAudit:r.__curAudit, ncAudit:r.__ncAudit, intNext:r.__intNext, curSched:r.current, splitCast:r.__splitCast, curDiff:r.__curDiff, __brk:r.__curBreak,
            status: flagAbs(r.__splitCast) ? 'Does not cast' : r.__curClient == null ? 'Not entered' : r.__curBreak ? 'Differs' : 'Agrees', __cls: cls(flagAbs(r.__splitCast) || r.__curBreak) })),
          footnote:'A client split that does not cast is raised as EX-LSE-10; a current portion differing from the amortisation beyond the tolerance as EX-LSE-09. Enter the TB current and non-current figures on Y3 to tie the totals.' }
      ];
    },
    flag(st, d) { return d.split.castBreaks.length > 0 || d.split.curBreaks.length > 0; } },

  { id:'maturity', ref:'Y3.5', title:'Maturity analysis',
    objective:'To prepare the contractual undiscounted maturity analysis of lease liabilities required by FRS 107 para 39 and FRS 116 para 58, and to reconcile it to the carrying amount.',
    procedures:['Computed the remaining contractual payments of each lease after the reporting date and allocated them to within one year, one to five years and beyond five years, undiscounted.',
                'Reconciled total undiscounted payments less future interest to the carrying amount of the liabilities.'],
    render(st, ctx) {
      const d = ctx.d, T = d.totals, m0 = ctx.money0, money = ctx.money;
      const basisClose = ctx.cfg.splitBasis === 'audit' ? T.closeAudit : T.liabClose;
      return [
        { type:'stats', items:[
          { label:'Within 1 year', value: m0(T.m1) }, { label:'1 to 5 years', value: m0(T.m2to5) }, { label:'Over 5 years', value: m0(T.m5) },
          { label:'Total undiscounted', value: m0(T.undiscounted) }, { label:'Less: future interest', value: m0(T.unearned) },
          { label:'Carrying amount', value: m0(basisClose) }, { label:'Reconciles', value: d.maturity.reconciles ? 'Yes' : 'No', cls: d.maturity.reconciles ? 'ok' : 'bad' } ] },
        { type:'table', title:'Contractual undiscounted payments by lease', columns:[...LEASE_COLS,
          { key:'payment', label:'Monthly payment', type:'num' }, { key:'remaining', label:'Months remaining', type:'int' }, { key:'expiry', label:'Expiry', type:'date' },
          { key:'m1', label:'Within 1 year', type:'num', sum:true }, { key:'m2to5', label:'1–5 years', type:'num', sum:true }, { key:'m5', label:'Over 5 years', type:'num', sum:true },
          { key:'undiscounted', label:'Total undiscounted', type:'num', sum:true, formula:(row, C) => `${C(6)}${row}+${C(7)}${row}+${C(8)}${row}` }, { key:'unearned', label:'Future interest', type:'num', sum:true }, { key:'close', label:'Carrying amount', type:'num', sum:true },
          { key:'disclosed', label:'Agreed to draft disclosure (Y/N)', input:'select', options:yn }, { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: d.leases.map(r => ({ ...leaseRow(r), expiry:r.__expiry, m1:r.__m1, m2to5:r.__m2to5, m5:r.__m5, undiscounted:r.__undiscounted, unearned:r.__unearned, close:r.__splitBase })),
          footnote:'Undiscounted payments assume the level monthly payment continues to the end of the term. Add extension periods reasonably certain to be exercised and variable payments separately in the disclosure.' },
        { type:'note', html:`Total undiscounted ${money(T.undiscounted)} less future interest ${money(T.unearned)} = ${money(r2(T.undiscounted - T.unearned))} against carrying amount ${money(basisClose)}.` }
      ];
    } },

  { id:'agree', ref:'Y3.6', title:'Agreement vouching',
    objective:'To agree the inputs to each lease calculation — commencement date, term, payments and discount rate — to the signed lease agreement, and to identify modifications, options and the support for the incremental borrowing rate.',
    procedures:['Sighted the signed lease agreement for every lease and agreed commencement date, term, monthly payment and any escalation to the schedule.',
                'Assessed whether the discount rate is the rate implicit in the lease or the incremental borrowing rate, and inspected the support for the rate used.',
                'Enquired of management and inspected agreements for modifications, extension, termination and purchase options and whether their exercise is reasonably certain.'],
    render(st, ctx) {
      const d = ctx.d, A = d.agreement;
      return [
        { type:'stats', items:[
          { label:'Leases', value: d.leases.length }, { label:'Agreements sighted', value: `${A.sighted} of ${d.leases.length}`, cls: A.sighted === d.leases.length ? 'ok' : 'warn' },
          { label:'All four inputs agreed', value: A.vouched, cls: A.vouched === d.leases.length ? 'ok' : 'warn' }, { label:'Inputs not agreeing', value: A.notAgreed.length, cls: A.notAgreed.length ? 'bad' : 'ok' },
          { label:'IBR support sighted', value: A.ibr }, { label:'Modified in the year', value: A.modified.length, cls: A.modified.length ? 'warn' : 'ok' },
          { label:'Commencing after year end', value: A.afterYE.length, cls: A.afterYE.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Agreement vouching by lease', columns:[...LEASE_COLS,
          { key:'commence', label:'Commencement per schedule', type:'date' }, { key:'term', label:'Term (m)', type:'int' }, { key:'payment', label:'Monthly payment', type:'num' }, { key:'rate', label:'Discount rate', type:'pct', dp:2 },
          { key:'agrSighted', label:'Signed agreement sighted (Y/N)', input:'select', options:yn },
          { key:'agrCommence', label:'Commencement agreed (Y/N)', input:'select', options:yn }, { key:'agrTerm', label:'Term agreed (Y/N)', input:'select', options:yn },
          { key:'agrPayment', label:'Payment agreed (Y/N)', input:'select', options:yn }, { key:'agrRate', label:'Discount rate agreed / appropriate (Y/N)', input:'select', options:yn },
          { key:'ibrSupport', label:'IBR support sighted (Y/N)', input:'select', options:yn }, { key:'modified', label:'Modified in year (Y/N)', input:'select', options:yn },
          { key:'options', label:'Extension / termination / purchase options', input:'text', wide:true }, { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: d.leases.map(r => ({ ...leaseRow(r), __cls: cls(r.__notAgreed.length || r.__afterYE) })),
          footnote:'An input answered N is raised as EX-LSE-12; a modification as EX-LSE-13 (remeasurement to be verified); a lease commencing after the reporting date or with no discount rate as EX-LSE-14.' },
        { type:'note', html:'The lease term includes periods covered by an extension option the lessee is reasonably certain to exercise and excludes periods covered by a termination option it is reasonably certain to exercise (FRS 116 para 18). Where the term used in the schedule differs from the non-cancellable period, record the basis in the options column.' }
      ];
    },
    flag(st, d) { return d.agreement.notAgreed.length > 0 || d.agreement.afterYE.length > 0 || d.agreement.badRate.length > 0; } },

  { id:'exempt', ref:'Y3.7', title:'Short-term and low-value exemptions',
    objective:'To verify that leases kept off balance sheet under the short-term and low-value recognition exemptions (FRS 116 para 5–8) qualify, and that the expense recognised agrees to the profit or loss.',
    procedures:['Obtained the list of leases expensed as incurred and recorded each with its term, the value of the underlying asset when new and the expense for the year.',
                'Tested each against the exemption claimed: a term of twelve months or less with no purchase option, or a low-value underlying asset.',
                'Agreed total exempt lease expense to the profit or loss and the disclosure.'],
    render(st, ctx) {
      const E = ctx.d.exemptions, cfg = ctx.cfg, money = ctx.money, m0 = ctx.money0;
      const n = clamp(Math.round(Number(cfg.exRows) || 0), 0, 40);
      const rows = [];
      for (let i = 1; i <= n; i++) { const x = E.rows.find(e => e.i === i); rows.push({ __key:'ex' + i, line:i, status: x ? x.status : '', why: x ? x.why : '', __cls: x?.status === 'Does not qualify' ? 'flag' : '' }); }
      return [
        { type:'controls', items:[
          { key:'exRows', label:'Exempt lease lines', kind:'number' },
          { key:'lowValueThreshold', label:'Low-value threshold (value of the underlying asset when new)', kind:'number', help:'The Basis for Conclusions to IFRS 16 contemplates about USD 5,000.' },
          { key:'pnlExempt', label:'Short-term and low-value lease expense per profit or loss', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Exempt leases entered', value: E.rows.length }, { label:'Qualify', value: E.qualifies }, { label:'Do not qualify', value: E.fails.length, cls: E.fails.length ? 'bad' : E.rows.length ? 'ok' : '' },
          { label:'Expense entered', value: m0(E.expense) }, { label:'Expense − P&L', value: E.pnlDiff == null ? '— enter —' : money(E.pnlDiff), cls: E.pnlDiff == null ? '' : flagAbs(E.pnlDiff) ? 'bad' : 'ok' } ] },
        { type:'table', title:'Leases expensed as incurred', columns:[
          { key:'line', label:'#', type:'int' }, { key:'exDesc', label:'Lease / underlying asset', input:'text', wide:true }, { key:'exType', label:'Exemption claimed', input:'select', options:EXEMPTION_TYPES },
          { key:'exTerm', label:'Term (months)', input:'number' }, { key:'exOption', label:'Purchase option (Y/N)', input:'select', options:yn }, { key:'exValue', label:'Value of asset when new', input:'number' }, { key:'exExpense', label:'Expense for the year', input:'number' },
          { key:'status', label:'Status', type:'chip', chipClass: v => v === 'Qualifies' ? 'ok' : v === 'Does not qualify' ? 'bad' : 'grey' }, { key:'why', label:'Basis', wrap:true },
          { key:'exAgreed', label:'Agreed to agreement / invoices (Y/N)', input:'select', options:yn }, { key:'exComment', label:'Comment', input:'text', wide:true } ], rows,
          footnote:'A lease that does not qualify for the exemption claimed is raised as EX-LSE-11. The short-term election is made by class of underlying asset; the low-value election lease by lease.' }
      ];
    },
    flag(st, d) { return d.exemptions.fails.length > 0 || flagAbs(d.exemptions.pnlDiff); } },

  { id:'conclusion', ref:'Y3.9', title:'Exceptions & conclusion', kind:'conclusion' }
];

function suggestConclusion(st, ctx) {
  const d = ctx.d, T = d.totals, n = d.leases.length;
  const ex = (st.exceptions || []).filter(e => e.disposition === 'open');
  const pl = (k, s = 's') => k === 1 ? '' : s;
  return [
    `The lease schedule carries ${n} lease${pl(n)} with right-of-use assets of ${ctx.money(T.rouClose)} and lease liabilities of ${ctx.money(T.liabClose)} at the reporting date${d.lead.tbLiabDiff != null ? (flagAbs(d.lead.tbLiabDiff) ? `; the liabilities differ from the trial balance by ${ctx.money(d.lead.tbLiabDiff)}` : ', agreeing to the trial balance') : ''}.`,
    d.liability.castBreaks.length ? `The liability movement does not cast for ${d.liability.castBreaks.length} lease${pl(d.liability.castBreaks.length)} (net difference ${ctx.money(T.castDiff)}).` : 'Opening plus interest less payments casts to closing for every lease.',
    `Each liability was rebuilt from commencement at the discount rate: interest per audit ${ctx.money(T.intAudit)} against ${ctx.money(T.interest)} charged${d.liability.intBreaks.length ? `; ${d.liability.intBreaks.length} lease${pl(d.liability.intBreaks.length)} outside tolerance` : ''}.`,
    `Depreciation of right-of-use assets per audit is ${ctx.money(T.depAudit)} against ${ctx.money(T.dep)} recorded${d.rou.breaks.length ? `; ${d.rou.breaks.length} lease${pl(d.rou.breaks.length)} outside tolerance` : ''}.`,
    `The current portion per audit is ${ctx.money(T.curAudit)}${d.split.entered ? ` against ${ctx.money(T.curClient)} per the client` : ''}; undiscounted contractual payments total ${ctx.money(T.undiscounted)}.`,
    `${d.agreement.sighted} of ${n} lease agreements were sighted${d.agreement.notAgreed.length ? `; inputs did not agree for ${d.agreement.notAgreed.length}` : ''}.`,
    d.exemptions.rows.length ? (d.exemptions.fails.length ? `${d.exemptions.fails.length} lease${pl(d.exemptions.fails.length)} expensed under an exemption ${d.exemptions.fails.length === 1 ? 'does' : 'do'} not qualify.` : 'All leases expensed under the recognition exemptions qualify.') : 'Leases expensed under the recognition exemptions have not yet been entered on Y3.7.',
    ex.length ? `${ex.length} exception${pl(ex.length)} remain${ex.length === 1 ? 's' : ''} open in the register.` : 'No exceptions remain open.',
    'Subject to the above, right-of-use assets and lease liabilities are complete, accurately measured and appropriately classified and disclosed at the reporting date.'
  ].join(' ');
}

return {
  code:'LEASE', name:'Leases (lessee)', group:'Liabilities & equity', accepts:'.xlsx,.xlsm,.csv',
  blurb:'The lessee audit file: lead, lease liability rebuild from the agreement terms, right-of-use depreciation, current / non-current split, maturity analysis, agreement vouching and recognition exemptions — from one uploaded lease schedule.',
  objective:'To obtain sufficient appropriate audit evidence that right-of-use assets and lease liabilities are complete, exist, are measured in accordance with FRS 116 from the terms of the lease agreements, and are appropriately classified and disclosed at the reporting date.',
  fields, tests, compute, pages, defaultConfig, STANDARD_COLUMNS, CONVENTIONS, EXEMPTION_TYPES,
  procedures: pages.flatMap(p => p.procedures || []),
  columns: STANDARD_COLUMNS, suggestConclusion
};
})();

Modules.register(LEASEModule);
