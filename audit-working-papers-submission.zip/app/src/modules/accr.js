/* ==========================================================================
   accr.js -- Accruals and other payables as an auditor actually works it.

   One uploaded accruals schedule (opening, provided, utilised, closing) feeds:
     U4    Lead schedule                  U4.3  Reasonableness against expense
     U4.1  Movement and casting           U4.4  Completeness (post year-end review)
     U4.2  Basis and support testing
   ========================================================================== */

const AccrModule = (() => {
const r2 = n => n == null || isNaN(n) ? null : Math.round(n * 100) / 100;
const num = v => (v === '' || v == null || isNaN(Number(v))) ? null : Number(v);
const inp = (cfg, key, k) => num(cfg[key + ':' + k]);
const txt = (cfg, key, k) => { const v = cfg[key + ':' + k]; return v == null ? '' : String(v); };

function mulberry32(seed) {
  let a = (seed >>> 0) || 1;
  return () => {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function sampleN(items, n, seed) {
  const rnd = mulberry32(seed);
  const pool = items.slice();
  const out = [];
  while (out.length < n && pool.length) out.push(pool.splice(Math.floor(rnd() * pool.length), 1)[0]);
  return out;
}

/* ---------------------------------------------------------------- fields */
const fields = [
  { key:'description', label:'Description', role:'key', type:'text', required:true, dupKey:true,
    synonyms:['Description','Particulars','Nature of Accrual','Details','Accrual','Item','Narrative','Nature','Expense Type','摘要','项目','费用项目'] },
  { key:'account_code', label:'GL account', type:'text',
    synonyms:['GL Code','Account','A/C','Account Code','GL Account','Nominal Code','Account No','G/L','科目代码','科目'] },
  { key:'bal_open', label:'Opening balance', type:'number', required:true,
    synonyms:['Opening Balance','Balance B/F','Bal 1 Jan','Opening','B/F','Brought Forward','Balance Brought Forward','Op Bal','Prior Year','期初余额','期初'] },
  { key:'charge', label:'Provided in the year', type:'number', required:true,
    synonyms:['Provided During Year','Charge','Additions','Accrued','Provided','Charge for the Year','Provision','Increase','Accrued During Year','Charged to P&L','本期增加','本期计提'] },
  { key:'utilised', label:'Utilised / reversed', type:'number', required:true,
    synonyms:['Utilised / Reversed','Payments','Reversals','Utilisation','Utilised','Released','Paid','Reversed','Decrease','Utilized','Used','Settled','本期减少','本期支付'] },
  { key:'bal_close', label:'Closing balance', type:'number', required:true,
    synonyms:['Closing Balance','Balance C/F','Bal at Year End','Closing','C/F','Carried Forward','Balance Carried Forward','Year End Balance','Cl Bal','期末余额','期末'] },
  { key:'expense', label:'Related expense for the year', type:'number',
    synonyms:['P&L Expense','Expense for the Year','Related Expense','Annual Expense','Total Expense'] },
  { key:'basis', label:'Basis of accrual (per client)', type:'text',
    synonyms:['Basis','Basis of Accrual','Computation','Method','Remarks','Comments'] }
];

const STANDARD_COLUMNS = [
  { key:'description', label:'Description' }, { key:'account_code', label:'GL' },
  { key:'bal_open', label:'Opening', type:'num', edit:true }, { key:'charge', label:'Provided', type:'num', edit:true },
  { key:'utilised', label:'Utilised / reversed', type:'num', edit:true }, { key:'__computedClose', label:'Closing recomputed', type:'num' },
  { key:'bal_close', label:'Closing per client', type:'num', edit:true, emphasis:true }, { key:'__castDiff', label:'Cast difference', type:'num' }
];

const defaultConfig = () => ({
  castTol: 0.01,
  utilisedSign: 'auto',          // 'auto' | 'signed' (negative = reduction) | 'positive' (positive = reduction)
  tbBalance: '', pyBalance: '',
  supThreshold: '', supSampleN: 3, supSeed: 20250228,
  maxPct: 50,                    // accrual above this % of the related expense is flagged
  changePct: 50,                 // year-on-year change above this % is highlighted
  compRows: 10
});

/* ============================================================ COMPUTE */
function compute(recs, cfg, eng) {
  const pm = eng.materiality?.pm || 0, trivial = eng.materiality?.trivial || 0;
  const tol = Number(cfg.castTol) || 0.01;
  const live = recs.filter(r => !r.__excluded);

  /* utilisation sign: the schedule may carry payments as negatives (signed) or positives */
  let sign = cfg.utilisedSign;
  if (sign === 'auto') {
    const nz = live.map(r => r.utilised).filter(v => v != null && Math.abs(v) > 0.005);
    sign = nz.length && nz.filter(v => v < 0).length / nz.length > 0.5 ? 'signed' : 'positive';
  }
  const T = { open:0, charge:0, utilised:0, close:0, computed:0, castDiff:0, count:0 };
  for (const r of live) {
    r.__displayKey = r.description || (r.account_code ? 'GL ' + r.account_code : 'row ' + r.__srcRow);
    const u = r.utilised || 0;
    r.__reduction = sign === 'signed' ? -u : u;                       // positive = reduces the accrual
    r.__computedClose = r2((r.bal_open || 0) + (r.charge || 0) - r.__reduction);
    r.__castDiff = r.bal_close != null ? r2(r.bal_close - r.__computedClose) : null;
    r.__notUtilised = (r.bal_open || 0) > 0.005 && Math.abs(u) < 0.005;
    r.__negative = (r.bal_close || 0) < -0.005;
    r.__nil = Math.abs(r.bal_open || 0) < 0.005 && Math.abs(r.charge || 0) < 0.005 && Math.abs(u) < 0.005 && Math.abs(r.bal_close || 0) < 0.005;
    r.__change = r.bal_close != null ? r2((r.bal_close || 0) - (r.bal_open || 0)) : null;
    r.__changePct = (r.bal_open && r.__change != null) ? r2(r.__change / Math.abs(r.bal_open) * 100) : null;
    /* U4.3 reasonableness — expense entered by the auditor (or supplied in the schedule) */
    const exp = num(r.__wp?.reason?.expense) ?? (r.expense != null ? r.expense : null);
    r.__expense = exp;
    r.__pctOfExpense = (exp && exp > 0 && r.bal_close != null) ? r2(r.bal_close / exp * 100) : null;
    r.__highPct = r.__pctOfExpense != null && r.__pctOfExpense > (Number(cfg.maxPct) || 50);
    r.__impliedMonths = r.__pctOfExpense != null ? r2(r.__pctOfExpense / 100 * 12) : null;
    /* U4.2 support — per support figure entered by the auditor */
    const sup = num(r.__wp?.support?.perSupport);
    r.__perSupport = sup;
    r.__supportDiff = (sup != null && r.bal_close != null) ? r2(r.bal_close - sup) : null;
    T.open += r.bal_open || 0; T.charge += r.charge || 0; T.utilised += r.__reduction; T.close += r.bal_close || 0;
    T.computed += r.__computedClose || 0; T.castDiff += r.__castDiff || 0; T.count++;
  }
  for (const k of Object.keys(T)) T[k] = r2(T[k]);

  /* ---- U4 lead ------------------------------------------------------- */
  const tb = num(cfg.tbBalance), py = num(cfg.pyBalance);
  const lead = { total: T.close, tb, py, tbDiff: tb != null ? r2(T.close - tb) : null,
    pyDiff: py != null ? r2(T.open - py) : null,                       // opening per schedule vs prior year closing
    variance: py != null ? r2(T.close - py) : null, variancePct: (py != null && py) ? r2((T.close - py) / Math.abs(py) * 100) : null,
    openingMovementPct: T.open ? r2((T.close - T.open) / Math.abs(T.open) * 100) : null };

  /* ---- U4.2 support testing selection -------------------------------- */
  const threshold = cfg.supThreshold !== '' && cfg.supThreshold != null ? Number(cfg.supThreshold) : trivial;
  const key = live.filter(r => Math.abs(r.bal_close || 0) >= threshold && !r.__nil);
  const residual = live.filter(r => !key.includes(r) && !r.__nil);
  const nS = Math.min(Number(cfg.supSampleN) || 0, residual.length);
  const sample = sampleN(residual, nS, Number(cfg.supSeed) || 1);
  for (const r of live) r.__supSelected = key.includes(r) ? 'key' : sample.includes(r) ? 'sample' : null;
  const selected = [...key, ...sample].sort((a, b) => Math.abs(b.bal_close || 0) - Math.abs(a.bal_close || 0));
  const selValue = r2(selected.reduce((s, r) => s + Math.abs(r.bal_close || 0), 0));
  const absTotal = r2(live.reduce((s, r) => s + Math.abs(r.bal_close || 0), 0));
  const support = { threshold, seed: Number(cfg.supSeed) || 1, key, residual, sample, selected, selValue, absTotal,
    coverage: absTotal ? r2(selValue / absTotal * 100) : 0,
    supported: selected.filter(r => r.__wp?.support?.reasonable === 'Y').length,
    differences: selected.filter(r => r.__supportDiff != null && Math.abs(r.__supportDiff) > tol) };

  /* ---- U4.3 reasonableness ------------------------------------------- */
  const reason = { entered: live.filter(r => r.__expense != null).length, high: live.filter(r => r.__highPct),
    bigChange: live.filter(r => r.__changePct != null && Math.abs(r.__changePct) > (Number(cfg.changePct) || 50)) };

  /* ---- U4.4 completeness --------------------------------------------- */
  const nRows = Math.max(0, Math.min(60, Math.round(Number(cfg.compRows) || 0)));
  const items = [];
  for (let i = 1; i <= nRows; i++) {
    const k = 'cp' + i;
    const amount = inp(cfg, 'cpAmount', k), supplier = txt(cfg, 'cpSupplier', k);
    if (amount == null && !supplier && !txt(cfg, 'cpDesc', k)) continue;
    const relates = txt(cfg, 'cpRelates', k), accrued = txt(cfg, 'cpAccrued', k);
    items.push({ key:k, i, supplier, date: txt(cfg, 'cpDate', k), amount, desc: txt(cfg, 'cpDesc', k), relates, accrued,
      required: relates === 'Y' && accrued === 'N' ? r2(amount || 0) : 0 });
  }
  const completeness = { items, examined: r2(items.reduce((s, x) => s + (x.amount || 0), 0)),
    unaccrued: items.filter(x => x.required > 0), unaccruedValue: r2(items.reduce((s, x) => s + x.required, 0)) };

  return { sign, totals: T, lead, support, reason, completeness,
    castFails: live.filter(r => r.__castDiff != null && Math.abs(r.__castDiff) > tol),
    notUtilised: live.filter(r => r.__notUtilised), negatives: live.filter(r => r.__negative), nils: live.filter(r => r.__nil), pm, trivial };
}

/* ============================================================== TESTS */
const tests = [
  { id:'EX-ACC-01', label:'Accrual movement does not cast', basis:'U4.1',
    fn:(r, cfg) => r.__castDiff != null && Math.abs(r.__castDiff) > (Number(cfg.castTol) || 0.01) &&
      { expected:r.__computedClose, actual:r.bal_close, difference:r.__castDiff, cell:r['__cell_bal_close'],
        detail:`Opening ${(r.bal_open || 0).toFixed(2)} + provided ${(r.charge || 0).toFixed(2)} − utilised ${r.__reduction.toFixed(2)} = ${r.__computedClose.toFixed(2)}, not ${(r.bal_close || 0).toFixed(2)}` } },
  { id:'EX-ACC-02', label:'Prior-year accrual neither utilised nor released', basis:'U4.1',
    fn:(r) => r.__notUtilised && { actual:r.bal_open, difference:r.bal_open, cell:r['__cell_utilised'],
      detail:'Opening balance carried forward with no payment or reversal in the year — challenge whether the obligation still exists (FRS 37 para 59)' } },
  { id:'EX-ACC-03', label:'Negative (debit) accrual balance', basis:'U4.1', severity:'above-trivial',
    fn:(r) => r.__negative && { actual:r.bal_close, difference:r.bal_close, cell:r['__cell_bal_close'], detail:'Debit balance in accruals — over-utilised or misposted; consider reclassification to prepayments or receivables' } },
  { id:'EX-ACC-04', label:'Accrual high relative to the related expense', basis:'U4.3', severity:'informational',
    fn:(r, cfg) => r.__highPct && { actual:r.__pctOfExpense, expected:Number(cfg.maxPct) || 50, difference:r.bal_close, cell:r['__cell_bal_close'],
      detail:`Accrual is ${r.__pctOfExpense.toFixed(1)}% of the expense for the year (about ${r.__impliedMonths} months) — above the ${Number(cfg.maxPct) || 50}% threshold set` } },
  { id:'EX-ACC-05', scope:'population', label:'Opening balance per schedule does not agree to the prior year closing balance', basis:'U4',
    fn:(recs, cfg, eng, d) => d.lead.pyDiff != null && Math.abs(d.lead.pyDiff) > (Number(cfg.castTol) || 0.01) &&
      { key:'Opening balance', expected:d.lead.py, actual:d.totals.open, difference:d.lead.pyDiff, detail:'Opening accruals per the schedule against the prior year audited closing balance' } },
  { id:'EX-ACC-06', label:'Accrual differs from the supporting evidence', basis:'U4.2',
    fn:(r, cfg) => r.__supportDiff != null && Math.abs(r.__supportDiff) > (Number(cfg.castTol) || 0.01) &&
      { expected:r.__perSupport, actual:r.bal_close, difference:r.__supportDiff, cell:r['__cell_bal_close'], detail:`Recorded ${r.__supportDiff > 0 ? 'above' : 'below'} the amount per the supporting document or subsequent invoice` } },
  { id:'EX-ACC-07', scope:'population', label:'Unrecorded accrual identified from post year-end review', basis:'U4.4',
    fn:(recs, cfg, eng, d) => d.completeness.unaccrued.map(x => ({ key:x.supplier || 'Item ' + x.i, actual:x.required, difference:x.required,
      detail:`${x.desc || 'Post year-end item'} relates to the year under audit and was not accrued` })) },
  { id:'EX-ACC-08', label:'Nil line on the schedule', basis:'U4.1', severity:'informational',
    fn:(r) => r.__nil && { detail:'Line carries no balance or movement — remove from the schedule' } },
  { id:'EX-TIE-01', scope:'population', label:'Accruals schedule does not agree to the trial balance', basis:'U4',
    fn:(recs, cfg, eng, d) => d.lead.tbDiff != null && Math.abs(d.lead.tbDiff) > (Number(cfg.castTol) || 0.01) &&
      { key:'Accruals', expected:d.lead.tb, actual:d.totals.close, difference:d.lead.tbDiff, detail:'Schedule total against the accruals and other payables captions in the trial balance' } }
];

/* ============================================================== PAGES */
const yn = ['Y', 'N'];
const lineRow = r => ({ __rec:r, description:r.description, gl:r.account_code, open:r.bal_open, charge:r.charge, utilised:r.__reduction, computed:r.__computedClose, close:r.bal_close, castDiff:r.__castDiff });

const pages = [
  { id:'source',  ref:'U4.0',  title:'Source data',      kind:'source' },
  { id:'cleaned', ref:'U4.0a', title:'Cleaned schedule', kind:'cleaned' },
  { id:'mapping', ref:'U4.0b', title:'Column mapping',   kind:'mapping' },

  { id:'lead', ref:'U4', title:'Lead schedule',
    objective:'To agree accruals and other payables per the schedule to the trial balance and the prior year audited figure, and to explain the movement in the year.',
    procedures:['Cast the accruals schedule and agreed the closing total to the accruals captions in the trial balance.',
                'Agreed the opening balances to the prior year audited closing balance.',
                'Compared the closing balance to the prior year and explained the movement.'],
    render(st, ctx) {
      const d = ctx.d, T = d.totals, Lz = d.lead, m0 = ctx.money0, money = ctx.money, pct = ctx.pct;
      return [
        { type:'controls', items:[
          { key:'tbBalance', label:'Accruals and other payables per trial balance', kind:'number' },
          { key:'pyBalance', label:'Accruals per prior year audited financial statements', kind:'number', help:'Compared to the opening balance per the schedule and to the closing balance for the movement.' },
          { key:'castTol', label:'Tolerance', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Lines on the schedule', value: T.count },
          { label:'Opening', value: m0(T.open) }, { label:'Provided in the year', value: m0(T.charge) }, { label:'Utilised / reversed', value: m0(T.utilised) },
          { label:'Closing per schedule', value: m0(T.close) },
          { label:'Closing recomputed', value: m0(T.computed) },
          { label:'Cast difference', value: money(T.castDiff), cls: Math.abs(T.castDiff) > 0.01 ? 'bad' : 'ok' },
          { label:'Per trial balance', value: Lz.tb == null ? '— enter —' : m0(Lz.tb) },
          { label:'Schedule − TB', value: Lz.tbDiff == null ? '' : money(Lz.tbDiff), cls: Lz.tbDiff == null ? '' : Math.abs(Lz.tbDiff) > 0.01 ? 'bad' : 'ok' },
          { label:'Opening − prior year closing', value: Lz.pyDiff == null ? '' : money(Lz.pyDiff), cls: Lz.pyDiff == null ? '' : Math.abs(Lz.pyDiff) > 0.01 ? 'bad' : 'ok' },
          { label:'Movement vs prior year', value: Lz.variance == null ? `${money(r2(T.close - T.open))} (${pct(Lz.openingMovementPct)}) vs opening` : `${money(Lz.variance)} (${pct(Lz.variancePct)})`, cls: Math.abs(Lz.variance ?? (T.close - T.open)) > ctx.pm ? 'warn' : '' } ] },
        { type:'table', title:'Summary of accruals', columns:[
          { key:'description', label:'Description' }, { key:'gl', label:'GL' },
          { key:'open', label:'Opening', type:'num', sum:true }, { key:'close', label:'Closing', type:'num', sum:true, emphasis:true },
          { key:'change', label:'Movement', type:'num', sum:true, formula:(row, C) => `${C(3)}${row}-${C(2)}${row}` },
          { key:'changePct', label:'Movement %', type:'pct' },
          { key:'explanation', label:'Explanation of movement', input:'text', wide:true } ],
          rows: ctx.recs.map(r => ({ __rec:r, description:r.description, gl:r.account_code, open:r.bal_open, close:r.bal_close, change:r.__change, changePct: r.__changePct != null ? r.__changePct / 100 : null,
            __cls: d.reason.bigChange.includes(r) ? 'flag' : '' })),
          footnote:`Rows painted red move by more than ${Number(ctx.cfg.changePct) || 50}% against the opening balance.` },
        { type:'note', tone: Lz.tbDiff != null && Math.abs(Lz.tbDiff) > 0.01 ? 'bad' : 'info',
          html: Lz.tb == null ? 'Enter the trial balance figure to complete the tie (EX-TIE-01 fires on a difference).' : Math.abs(Lz.tbDiff) > 0.01 ? `<b>The schedule does not agree to the trial balance</b> by ${money(Lz.tbDiff)}.` : 'The schedule agrees to the trial balance.' }
      ];
    },
    flag(st, d) { return (d.lead.tbDiff != null && Math.abs(d.lead.tbDiff) > 0.01) || (d.lead.pyDiff != null && Math.abs(d.lead.pyDiff) > 0.01); } },

  { id:'movement', ref:'U4.1', title:'Movement and casting',
    objective:'To verify that each accrual rolls forward arithmetically from opening balance through amounts provided and utilised to the closing balance, and to identify stale, negative and nil lines.',
    procedures:['Recomputed the closing balance of every line as opening + provided − utilised and compared it to the closing balance per the schedule.',
                'Identified prior-year accruals with no utilisation or release in the year, negative (debit) balances and nil lines.'],
    render(st, ctx) {
      const d = ctx.d, m0 = ctx.money0, money = ctx.money;
      return [
        { type:'controls', items:[{ key:'utilisedSign', label:'Sign of the utilised / reversed column', kind:'select',
          options:[['auto', `Detect from the data (currently: ${d.sign === 'signed' ? 'negative = reduction' : 'positive = reduction'})`], ['signed', 'Negative amounts reduce the accrual'], ['positive', 'Positive amounts reduce the accrual']] }] },
        { type:'stats', items:[
          { label:'Lines that do not cast', value: d.castFails.length, cls: d.castFails.length ? 'bad' : 'ok' },
          { label:'Total cast difference', value: money(d.totals.castDiff), cls: Math.abs(d.totals.castDiff) > 0.01 ? 'bad' : 'ok' },
          { label:'Prior-year accruals not utilised or released', value: `${d.notUtilised.length} · ${m0(d.notUtilised.reduce((s, r) => s + r.bal_open, 0))}`, cls: d.notUtilised.length ? 'warn' : 'ok' },
          { label:'Negative balances', value: d.negatives.length, cls: d.negatives.length ? 'bad' : 'ok' },
          { label:'Nil lines', value: d.nils.length } ] },
        { type:'table', title:'Roll-forward by line', columns:[
          { key:'description', label:'Description' }, { key:'gl', label:'GL' },
          { key:'open', label:'Opening', type:'num', sum:true }, { key:'charge', label:'Provided', type:'num', sum:true },
          { key:'utilised', label:'Utilised / reversed', type:'num', sum:true },
          { key:'computed', label:'Closing recomputed', type:'num', sum:true, formula:(row, C) => `${C(2)}${row}+${C(3)}${row}-${C(4)}${row}` },
          { key:'close', label:'Closing per schedule', type:'num', sum:true, emphasis:true },
          { key:'castDiff', label:'Cast difference', type:'num', sum:true, flag: v => v != null && Math.abs(v) > 0.01, formula:(row, C) => `${C(6)}${row}-${C(5)}${row}` },
          { key:'status', label:'Flags', type:'chip', chipClass: v => /cast|Negative/.test(v) ? 'bad' : 'warn' },
          { key:'comment', label:'Auditor comment', input:'text', wide:true } ],
          rows: ctx.recs.map(r => ({ ...lineRow(r), status: [r.__castDiff != null && Math.abs(r.__castDiff) > 0.01 ? 'Does not cast' : '', r.__negative ? 'Negative' : '', r.__notUtilised ? 'Not utilised' : '', r.__nil ? 'Nil' : ''].filter(Boolean).join(', ') || null,
            __cls: (r.__castDiff != null && Math.abs(r.__castDiff) > 0.01) || r.__negative ? 'flag' : '' })) },
        { type:'table', title:'Prior-year accruals neither utilised nor released', columns:[
          { key:'description', label:'Description' }, { key:'open', label:'Opening', type:'num', sum:true }, { key:'charge', label:'Provided', type:'num' }, { key:'close', label:'Closing', type:'num', sum:true },
          { key:'stillValid', label:'Obligation still exists (Y/N)', input:'select', options:yn },
          { key:'evidence', label:'Evidence obtained', input:'text', wide:true } ],
          rows: d.notUtilised.map(lineRow), emptyText:'Every prior-year accrual was utilised or released in the year.' }
      ];
    },
    flag(st, d) { return d.castFails.length > 0 || d.negatives.length > 0 || d.notUtilised.length > 0; } },

  { id:'support', ref:'U4.2', title:'Basis and support testing',
    objective:'To verify that each significant accrual represents a present obligation at the reporting date, is computed on a reasonable basis and is supported by evidence such as subsequent invoices, contracts or computations.',
    procedures:['Selected every line at or above the testing threshold as a key item and a random sample of the remainder using a recorded seed.',
                'For each selected accrual, documented the basis of the estimate, agreed the amount to the supporting document or subsequent invoice or payment, and assessed whether the estimate is reasonable.'],
    render(st, ctx) {
      const S = ctx.d.support, m0 = ctx.money0, pct = ctx.pct;
      return [
        { type:'controls', items:[
          { key:'supThreshold', label:'Testing threshold — every line at or above is tested', kind:'number', help:`Blank = trivial threshold (${m0(ctx.trivial)}). Currently ${m0(S.threshold)}.` },
          { key:'supSampleN', label:'Random sample from the remaining lines', kind:'number', help:`${S.residual.length} lines below the threshold` },
          { key:'supSeed', label:'Random seed', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Key items', value: S.key.length }, { label:'Random sample', value: S.sample.length },
          { label:'Coverage of closing balance', value: pct(S.coverage), cls: S.coverage >= 80 ? 'ok' : 'warn' },
          { label:'Assessed reasonable', value: `${S.supported} of ${S.selected.length}`, cls: S.supported === S.selected.length && S.selected.length ? 'ok' : 'warn' },
          { label:'Differences to support', value: S.differences.length, cls: S.differences.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Accruals selected for testing', columns:[
          { key:'description', label:'Description' }, { key:'gl', label:'GL' },
          { key:'basisSel', label:'Selection', type:'chip', chipClass: v => v === 'Key item' ? 'info' : 'grey' },
          { key:'close', label:'Closing per schedule', type:'num', sum:true },
          { key:'basis', label:'Basis of accrual (estimate, contract, invoice, formula)', input:'text', wide:true },
          { key:'doc', label:'Supporting document seen', input:'text', wide:true },
          { key:'perSupport', label:'Amount per support', input:'number' },
          { key:'supportDiff', label:'Schedule − support', type:'num', flag: v => v != null && Math.abs(v) > 0.01 },
          { key:'subDate', label:'Subsequent invoice / payment date', input:'text' },
          { key:'reasonable', label:'Reasonable (Y/N)', input:'select', options:yn },
          { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: S.selected.map(r => ({ __rec:r, description:r.description, gl:r.account_code, basisSel: r.__supSelected === 'key' ? 'Key item' : 'Random sample', close:r.bal_close, supportDiff:r.__supportDiff,
            __cls: r.__supportDiff != null && Math.abs(r.__supportDiff) > 0.01 ? 'flag' : '' })),
          emptyText:'Nothing selected — lower the threshold or increase the sample.',
          footnote:`Seed ${S.seed}. A difference between the schedule and the support is raised as EX-ACC-06.` }
      ];
    },
    flag(st, d) { return d.support.differences.length > 0; } },

  { id:'reason', ref:'U4.3', title:'Reasonableness against expense',
    objective:'To assess whether each accrual is reasonable in relation to the related expense for the year and the prior-year balance.',
    procedures:['Entered the related expense for the year for each accrual and expressed the accrual as a percentage of the expense and in months of expense.',
                'Flagged accruals above the percentage threshold set and lines with a large change against the opening balance for enquiry.'],
    render(st, ctx) {
      const d = ctx.d, R = d.reason;
      return [
        { type:'controls', items:[
          { key:'maxPct', label:'Flag accruals above this % of the related expense', kind:'number' },
          { key:'changePct', label:'Highlight movement against opening above this %', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Expense entered', value: `${R.entered} of ${d.totals.count}` },
          { label:'Above % threshold', value: R.high.length, cls: R.high.length ? 'warn' : 'ok' },
          { label:'Large movement vs opening', value: R.bigChange.length, cls: R.bigChange.length ? 'warn' : '' } ] },
        { type:'table', title:'Accrual as a proportion of the related expense', columns:[
          { key:'description', label:'Description' }, { key:'gl', label:'GL' },
          { key:'open', label:'Opening', type:'num', sum:true }, { key:'close', label:'Closing', type:'num', sum:true },
          { key:'changePct', label:'Change vs opening', type:'pct' },
          { key:'expense', label:'Related expense for the year (P&L)', input:'number' },
          { key:'pctOfExpense', label:'Accrual as % of expense', type:'pct', flag: (v, row) => row.__high },
          { key:'months', label:'Months of expense accrued', type:'num', dp:1 },
          { key:'expected', label:'Expected accrual (auditor)', input:'number' },
          { key:'comment', label:'Assessment', input:'text', wide:true } ],
          rows: ctx.recs.map(r => ({ __rec:r, description:r.description, gl:r.account_code, open:r.bal_open, close:r.bal_close, changePct: r.__changePct != null ? r.__changePct / 100 : null,
            pctOfExpense: r.__pctOfExpense != null ? r.__pctOfExpense / 100 : null, months:r.__impliedMonths, __high: r.__highPct, __cls: r.__highPct ? 'flag' : '' })),
          footnote:'An accrual above the % threshold is raised as EX-ACC-04 (informational). Bonus, audit fee and leave provisions legitimately approach a full year of expense; utilities and freight normally represent one to two months.' }
      ];
    },
    flag(st, d) { return d.reason.high.length > 0; } },

  { id:'completeness', ref:'U4.4', title:'Completeness — post year-end review',
    objective:'To identify expenses relating to the year under audit that were invoiced or paid after the reporting date and were not accrued.',
    procedures:['Reviewed invoices received and payments made after the year end above the threshold and recorded each item examined.',
                'For each item, determined whether it relates to the year under audit and whether it was accrued; summarised unaccrued amounts for the summary of unadjusted differences.'],
    render(st, ctx) {
      const Cm = ctx.d.completeness, m0 = ctx.money0;
      const rows = [];
      const n = Math.max(0, Math.min(60, Math.round(Number(ctx.cfg.compRows) || 0)));
      for (let i = 1; i <= n; i++) { const it = Cm.items.find(x => x.i === i); rows.push({ __key:'cp' + i, line:i, required: it ? it.required || null : null, __cls: it?.required ? 'flag' : '' }); }
      return [
        { type:'controls', items:[{ key:'compRows', label:'Lines available for post year-end items examined', kind:'number' }] },
        { type:'stats', items:[
          { label:'Items examined', value: `${Cm.items.length} · ${m0(Cm.examined)}` },
          { label:'Unaccrued', value: `${Cm.unaccrued.length} · ${m0(Cm.unaccruedValue)}`, cls: Cm.unaccrued.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Post year-end invoices and payments examined', columns:[
          { key:'line', label:'#', type:'int' },
          { key:'cpSupplier', label:'Supplier / payee', input:'text', wide:true },
          { key:'cpDate', label:'Invoice / payment date', input:'text' },
          { key:'cpDesc', label:'Nature of expense and period covered', input:'text', wide:true },
          { key:'cpAmount', label:'Amount', input:'number' },
          { key:'cpRelates', label:'Relates to year under audit (Y/N)', input:'select', options:yn },
          { key:'cpAccrued', label:'Accrued at year end (Y/N)', input:'select', options:yn },
          { key:'required', label:'Unaccrued amount', type:'num', sum:true },
          { key:'cpComment', label:'Comment', input:'text', wide:true } ], rows,
          footnote:'An item relating to the year that was not accrued is raised as EX-ACC-07.' }
      ];
    },
    flag(st, d) { return d.completeness.unaccrued.length > 0; } },

  { id:'conclusion', ref:'U4.9', title:'Exceptions & conclusion', kind:'conclusion' }
];

function suggestConclusion(st, ctx) {
  const d = ctx.d, T = d.totals, Lz = d.lead, S = d.support;
  const ex = (st.exceptions || []).filter(e => e.disposition === 'open');
  return [
    `Accruals per the schedule total ${ctx.money(T.close)} across ${T.count} lines${Lz.tbDiff == null ? '' : Math.abs(Lz.tbDiff) <= 0.01 ? ', agreeing to the trial balance' : `, differing from the trial balance by ${ctx.money(Lz.tbDiff)}`}.`,
    d.castFails.length ? `${d.castFails.length} line(s) do not cast (total difference ${ctx.money(T.castDiff)}).` : 'Every line rolls forward arithmetically.',
    d.notUtilised.length ? `${d.notUtilised.length} prior-year accrual(s) were neither utilised nor released.` : '',
    d.negatives.length ? `${d.negatives.length} line(s) carry a debit balance.` : '',
    `${S.selected.length} accruals (${ctx.pct(S.coverage)} of the balance) were tested to supporting evidence; ${S.supported} assessed reasonable.`,
    d.completeness.unaccrued.length ? `The post year-end review identified ${d.completeness.unaccrued.length} unaccrued item(s) totalling ${ctx.money(d.completeness.unaccruedValue)}.` : 'The post year-end review identified no unaccrued items.',
    ex.length ? `${ex.length} exception(s) remain open in the register.` : 'No exceptions remain open.',
    'Subject to the above, accruals and other payables are complete and fairly stated at the reporting date.'
  ].filter(Boolean).join(' ');
}

return {
  code:'ACCR', name:'Accruals & Other Payables', group:'Liabilities & equity', accepts:'.xlsx,.xlsm,.csv',
  blurb:'The accruals audit file: lead, movement and casting, basis and support testing, reasonableness against expense and post year-end completeness — from one uploaded accruals schedule.',
  objective:'To obtain sufficient appropriate audit evidence that accruals and other payables are complete, represent present obligations at the reporting date, are measured on a reasonable basis and are appropriately presented.',
  fields, tests, compute, pages, defaultConfig, STANDARD_COLUMNS,
  procedures: pages.flatMap(p => p.procedures || []),
  columns: STANDARD_COLUMNS, suggestConclusion
};
})();

Modules.register(AccrModule);
