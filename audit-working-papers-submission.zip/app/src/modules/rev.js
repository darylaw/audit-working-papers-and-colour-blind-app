/* ==========================================================================
   rev.js -- Revenue as an auditor actually works it.

   One uploaded sales listing (invoices and credit notes) feeds:
     Z1    Lead schedule                    Z1.4  Post year-end credit notes
     Z1.1  Monthly revenue analysis         Z1.5  Substantive sample and vouching
     Z1.2  Price x quantity and tax check   Z1.6  Customer concentration
     Z1.3  Cut-off testing
   ========================================================================== */

const REVModule = (() => {
const r2 = n => n == null || isNaN(n) ? null : Math.round(n * 100) / 100;
const days = (a, b) => (a && b) ? Math.round((a - b) / 86400000) : null;
const num = v => (v === '' || v == null || isNaN(Number(v))) ? null : Number(v);
const inp = (cfg, key, k) => num(cfg[key + ':' + k]);
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const isoMonth = d => d ? `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}` : null;
const monthLabel = k => `${MONTHS[Number(k.slice(5, 7)) - 1]} ${k.slice(0, 4)}`;

/* Seeded PRNG so a random sample is reproducible from its recorded seed. */
function mulberry32(seed) {
  let a = (seed >>> 0) || 1;
  return () => {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function sampleN(items, n, seed) {
  const rnd = mulberry32(seed);
  const pool = items.slice();
  const out = [];
  while (out.length < n && pool.length) out.push(pool.splice(Math.floor(rnd() * pool.length), 1)[0]);
  return out;
}

const CN_RE = /^\s*(CN|CR|CRN|CM)\b|credit\s*note|credit\s*memo/i;

/* ---------------------------------------------------------------- fields */
const fields = [
  { key:'invoice_no', label:'Invoice number', type:'text', required:true, role:'key',
    synonyms:['Invoice No','Doc No','Sales Invoice','Inv #','Reference','Invoice Number','Inv No','Inv No.','Document No','Tax Invoice No','Bill No','Invoice','Document Number','Sales Invoice No','Inv Number','发票号','发票号码','单据号'] },
  { key:'invoice_date', label:'Invoice date', type:'date', required:true,
    synonyms:['Invoice Date','Date','Sales Date','Doc Date','Inv Date','Inv. Date','Transaction Date','Posting Date','Document Date','Tax Point','Billing Date','发票日期','日期','开票日期'] },
  { key:'customer', label:'Customer', type:'text', required:true,
    synonyms:['Customer','Customer Name','Sold To','Debtor','Debtor Name','Client','Bill To','Buyer','Account Name','Customer / Client','Sold-To Party','客户名称','客户'] },
  { key:'amount', label:'Net amount (revenue)', type:'number', required:true,
    synonyms:['Amount','Net Amount','Revenue','Sales Value','Net Sales','Sales','Net','Amount (Excl. GST)','Amount Excl Tax','Net Revenue','Sales Amount','Ex GST','Amount ex GST','Net Value','金额','不含税金额','销售额'] },
  { key:'product', label:'Product / revenue stream', type:'text',
    synonyms:['Product','Item','Description','Service','Revenue Stream','Item Description','Product / Service','Particulars','Stream','Product Line','Goods / Services','产品','摘要','品名'] },
  { key:'qty', label:'Quantity', type:'number',
    synonyms:['Qty','Quantity','Units','Qty Sold','Volume','Hours','No. of Units','Quantity Sold','数量'] },
  { key:'unit_price', label:'Unit price', type:'number',
    synonyms:['Unit Price','Price','Rate','Selling Price','Unit Rate','Price per Unit','Unit Selling Price','Price/Unit','单价'] },
  { key:'tax', label:'Output tax (GST / VAT)', type:'number',
    synonyms:['GST','Tax','VAT','GST Amount','Output Tax','Tax Amount','Sales Tax','GST 9%','GST 8%','Output GST','税额','增值税'] },
  { key:'gross', label:'Gross amount (incl. tax)', type:'number',
    synonyms:['Total','Gross Amount','Invoice Total','Amount Inc. GST','Gross','Total Amount','Amount Incl Tax','Invoice Amount','Amount Inc GST','Total Inc. GST','含税金额','合计','价税合计'] },
  { key:'do_date', label:'Delivery / service date', type:'date',
    synonyms:['Delivery Date','DO Date','Despatch Date','Shipment Date','Dispatch Date','Ship Date','Date Delivered','Service Date','Completion Date','Delivery','GRN Date','Performance Date','发货日期','交货日期'] },
  { key:'segment', label:'Segment', type:'text', role:'category', satisfiedByGroup:true,
    synonyms:['Segment','Business Line','Division','Geography','Region','Market','Country','Channel','Business Unit','Sector','Territory','部门','地区','业务板块'] },
  { key:'currency', label:'Currency', type:'text', synonyms:['Currency','Cur','Curr','CCY','Txn Ccy','币种'] },
  { key:'doc_type', label:'Document type', type:'text', synonyms:['Type','Doc Type','Document Type','Transaction Type','Txn Type','单据类型'] },
  { key:'do_no', label:'Delivery order number', type:'text', synonyms:['DO No','Delivery Order','DO Number','Delivery Note','GRN No','Shipment No','送货单号'] }
];

const STANDARD_COLUMNS = [
  { key:'invoice_no', label:'Invoice' }, { key:'invoice_date', label:'Invoice date', type:'date', edit:true }, { key:'customer', label:'Customer' },
  { key:'product', label:'Product / stream' }, { key:'segment', label:'Segment' }, { key:'qty', label:'Qty', type:'num', dp:0, edit:true },
  { key:'unit_price', label:'Unit price', type:'num', edit:true }, { key:'__ext', label:'Qty × price', type:'num' },
  { key:'amount', label:'Net amount', type:'num', edit:true, emphasis:true }, { key:'tax', label:'Tax', type:'num', edit:true },
  { key:'gross', label:'Gross', type:'num', edit:true }, { key:'do_date', label:'Delivered', type:'date', edit:true }, { key:'__kind', label:'Type' }
];

const defaultConfig = () => ({
  castTol: 0.01,
  tbRevenue: '', pyRevenue: '',
  momThreshold: 30,                 // month-on-month movement % beyond which a month is flagged
  recalcTol: 1,                     // qty × price vs amount, and net + tax vs gross
  domesticPattern: 'domestic|local|singapore|\\bSG\\b|home',
  taxRate: '',                      // optional standard rate % to recompute expected tax
  cutoffDays: 14,
  roundSum: 10000,
  sampleThreshold: '', sampleN: 10, sampleSeed: 20250228,
  topN: 10, concThreshold: 10
});

/* ============================================================ COMPUTE */
function compute(recs, cfg, eng) {
  const ye = eng.yearEndDate, fys = eng.fyStartDate;
  const pm = eng.materiality?.pm || 0, trivial = eng.materiality?.trivial || 0;
  const tol = Number(cfg.recalcTol) >= 0 ? Number(cfg.recalcTol) : 1;
  const round = Number(cfg.roundSum) || 0;
  const cw = Number(cfg.cutoffDays) || 0;
  const domRe = (() => { try { return new RegExp(cfg.domesticPattern || 'domestic|local', 'i'); } catch (e) { return /domestic|local/i; } })();
  const taxRate = num(cfg.taxRate);
  const live = recs.filter(r => !r.__excluded);

  /* duplicates by invoice number (not credit notes) */
  const seen = new Map();
  for (const r of recs) {
    r.__displayKey = r.invoice_no || ('row ' + r.__srcRow);
    r.__isCN = (r.amount != null && r.amount < -0.005) || CN_RE.test(String(r.invoice_no || '')) || CN_RE.test(String(r.doc_type || ''));
    r.__kind = r.__isCN ? 'Credit note' : 'Invoice';
    r.__dupOf = null;
    if (r.__excluded || r.__isCN) continue;
    const k = Core.keyify(r.invoice_no || '');
    if (!k) continue;
    if (seen.has(k)) r.__dupOf = seen.get(k); else seen.set(k, r.__srcRow);
  }
  const byInv = new Map();
  for (const r of live) if (!r.__isCN && r.invoice_no) { const k = Core.keyify(r.invoice_no); if (!byInv.has(k)) byInv.set(k, r); }

  const anyDomesticTax = live.some(r => !r.__isCN && domRe.test(String(r.segment || '')) && (r.tax || 0) > 0.005);
  let total = 0, inPeriod = 0, afterYE = 0, beforeFY = 0, cnTotal = 0, undated = 0;
  const segs = {}, streams = {}, custs = {}, months = {};
  for (const r of live) {
    const a = r.amount || 0;
    r.__afterYE = !!(r.invoice_date && ye && r.invoice_date > ye);
    r.__beforeFY = !!(r.invoice_date && fys && r.invoice_date < fys);
    r.__inPeriod = !!r.invoice_date && !r.__afterYE && !r.__beforeFY;
    r.__daysToYE = r.invoice_date && ye ? days(ye, r.invoice_date) : null;
    r.__ext = (r.qty != null && r.unit_price != null) ? r2(r.qty * r.unit_price) : null;
    r.__extDiff = r.__ext != null && r.amount != null ? r2(r.amount - r.__ext) : null;
    r.__grossCalc = r.amount != null ? r2(r.amount + (r.tax || 0)) : null;
    r.__grossDiff = (r.gross != null && r.__grossCalc != null) ? r2(r.gross - r.__grossCalc) : null;
    r.__expTax = (taxRate != null && r.amount != null) ? r2(r.amount * taxRate / 100) : null;
    r.__taxDiff = (r.__expTax != null && r.tax != null) ? r2(r.tax - r.__expTax) : null;
    r.__domestic = domRe.test(String(r.segment || ''));
    r.__noTax = !r.__isCN && r.__domestic && a > 0.005 && !((r.tax || 0) > 0.005) && anyDomesticTax;
    r.__negPrice = r.unit_price != null && r.unit_price < 0 && !r.__isCN;
    r.__noCustomer = !String(r.customer || '').trim();
    r.__round = round > 0 && Math.abs(a) >= round && Math.abs(a % round) < 0.005;
    r.__nearYEBefore = r.__daysToYE != null && r.__daysToYE >= 0 && r.__daysToYE <= cw;
    r.__roundNearYE = r.__round && r.__nearYEBefore && !r.__isCN;
    r.__deliveredAfterYE = !r.__isCN && !!(r.do_date && ye && r.do_date > ye) && !r.__afterYE && !!r.invoice_date;
    r.__deliveredBeforeInvoicedAfter = !r.__isCN && r.__afterYE && !!(r.do_date && r.do_date <= ye);
    r.__postYECN = r.__isCN && r.__afterYE;
    r.__cnOriginal = null;
    if (r.__isCN) {
      const base = Core.keyify(String(r.invoice_no || '').replace(/^\s*(CN|CR|CRN|CM)[-_ /]*/i, ''));
      const o = base ? byInv.get(base) : null;
      if (o && o !== r) r.__cnOriginal = o;
      else { const m = live.find(x => !x.__isCN && x.customer && r.customer && Core.keyify(x.customer) === Core.keyify(r.customer) && Math.abs((x.amount || 0) + a) < 0.01); if (m) r.__cnOriginal = m; }
    }
    /* cut-off window: either date within N days of the year end */
    const dInv = r.__daysToYE, dDO = r.do_date && ye ? days(ye, r.do_date) : null;
    r.__inCutoffWindow = cw > 0 && ((dInv != null && Math.abs(dInv) <= cw) || (dDO != null && Math.abs(dDO) <= cw)) && !r.__isCN;
    r.__cutoffSide = r.__afterYE ? 'Invoiced after year end' : 'Invoiced before year end';
    r.__cutoffView = r.__deliveredAfterYE ? 'Delivered after year end — revenue recognised early'
      : r.__deliveredBeforeInvoicedAfter ? 'Delivered before year end, invoiced after — possible unrecorded revenue'
      : r.__afterYE ? 'Invoiced and delivered after year end — exclude from the year' : (r.do_date ? 'Invoice and delivery in the same period' : 'No delivery date — vouch to delivery evidence');

    total += a;
    if (r.__isCN) cnTotal += a;
    if (!r.invoice_date) undated += a; else if (r.__afterYE) afterYE += a; else if (r.__beforeFY) beforeFY += a; else inPeriod += a;
    const sk = r.segment || '(not stated)', s = segs[sk] || (segs[sk] = { key: Core.keyify(sk) || 'none', segment:sk, count:0, amount:0, cn:0 });
    s.count++; s.amount += a; if (r.__isCN) s.cn += a;
    const pk = r.product || '(not stated)', p = streams[pk] || (streams[pk] = { key: Core.keyify(pk) || 'none', stream:pk, count:0, amount:0 });
    p.count++; p.amount += a;
    /* every invoice belongs to a customer row — an invoice with no customer is
       still revenue, so it goes to a visible "(not stated)" bucket rather than
       silently dropping out of the concentration table */
    if (!r.__isCN) { const nm = String(r.customer || '').trim();
      const ck = nm ? (Core.keyify(nm).replace(/\b(pte|ltd|private|limited|llp|inc|co|sdn|bhd)\b/g, '').replace(/[^a-z0-9]/g, '') || Core.keyify(nm)) : '__notstated';
      const c = custs[ck] || (custs[ck] = { key:ck, customer: nm || '(not stated)', count:0, amount:0, noCustomer: !nm }); c.count++; c.amount += a; }
    if (r.__inPeriod) { const mk = isoMonth(r.invoice_date); const m = months[mk] || (months[mk] = { month:mk, count:0, amount:0, invoices:0, cns:0 }); m.count++; m.amount += a; if (r.__isCN) m.cns += a; else m.invoices += a; }
  }

  /* ---- Z1 lead ------------------------------------------------------- */
  const tb = num(cfg.tbRevenue), py = num(cfg.pyRevenue);
  const bySegment = Object.values(segs).map(s => {
    const stb = inp(cfg, 'tbSeg', s.key), spy = inp(cfg, 'pySeg', s.key);
    const variance = spy != null ? r2(s.amount - spy) : null;
    return { ...s, amount: r2(s.amount), cn: r2(s.cn), share: total ? r2(s.amount / total * 100) : 0, tb: stb, tbDiff: stb != null ? r2(s.amount - stb) : null,
      py: spy, variance, variancePct: (variance != null && spy) ? r2(variance / Math.abs(spy) * 100) : null, material: variance != null && Math.abs(variance) > pm };
  }).sort((a, b) => b.amount - a.amount);
  const byStream = Object.values(streams).map(p => ({ ...p, amount: r2(p.amount), share: total ? r2(p.amount / total * 100) : 0 })).sort((a, b) => b.amount - a.amount);
  const segTBEntered = bySegment.some(s => s.tb != null);
  const tbRef = segTBEntered ? r2(bySegment.reduce((s, x) => s + (x.tb || 0), 0)) : tb;
  const lead = { total: r2(total), inPeriod: r2(inPeriod), afterYE: r2(afterYE), beforeFY: r2(beforeFY), undated: r2(undated), cnTotal: r2(cnTotal),
    count: live.length, invoices: live.filter(r => !r.__isCN).length, cns: live.filter(r => r.__isCN).length,
    tb: tbRef, tbDiff: tbRef != null ? r2(total - tbRef) : null, py, variance: py != null ? r2(total - py) : null,
    variancePct: (py != null && py) ? r2((total - py) / Math.abs(py) * 100) : null, segTBEntered };

  /* ---- Z1.1 monthly ------------------------------------------------- */
  const monthly = [];
  if (fys && ye) {
    const d = new Date(Date.UTC(fys.getUTCFullYear(), fys.getUTCMonth(), 1));
    while (d <= ye && monthly.length < 24) {
      const k = isoMonth(d), m = months[k] || { month:k, count:0, amount:0, invoices:0, cns:0 };
      monthly.push({ month:k, label: monthLabel(k), count:m.count, amount: r2(m.amount), invoices: r2(m.invoices), cns: r2(m.cns) });
      d.setUTCMonth(d.getUTCMonth() + 1);
    }
  }
  const avg = monthly.length ? inPeriod / monthly.length : 0;
  const momT = Number(cfg.momThreshold) || 0;
  monthly.forEach((m, i) => {
    const prev = i ? monthly[i - 1].amount : null;
    m.mom = prev != null ? r2(m.amount - prev) : null;
    m.momPct = prev != null && Math.abs(prev) > 0.005 ? r2((m.amount - prev) / Math.abs(prev) * 100) : null;
    m.vsAvg = avg ? r2((m.amount - avg) / Math.abs(avg) * 100) : null;
    m.share = inPeriod ? r2(m.amount / inPeriod * 100) : 0;
    m.flag = momT > 0 && ((m.momPct != null && Math.abs(m.momPct) > momT) || (m.vsAvg != null && Math.abs(m.vsAvg) > momT)) && Math.abs(m.amount - (prev ?? avg)) > trivial;
  });
  const monthlyStats = { avg: r2(avg), max: monthly.reduce((b, m) => !b || m.amount > b.amount ? m : b, null), min: monthly.reduce((b, m) => !b || m.amount < b.amount ? m : b, null),
    flagged: monthly.filter(m => m.flag), monthsWithSales: monthly.filter(m => m.count > 0).length };

  /* ---- Z1.2 recalculation ------------------------------------------- */
  const recalc = { rows: live.filter(r => r.__ext != null || r.__grossDiff != null || r.__expTax != null).sort((a, b) => Math.abs(b.__extDiff || 0) + Math.abs(b.__grossDiff || 0) - Math.abs(a.__extDiff || 0) - Math.abs(a.__grossDiff || 0)),
    extErrors: live.filter(r => r.__extDiff != null && Math.abs(r.__extDiff) > tol),
    grossErrors: live.filter(r => r.__grossDiff != null && Math.abs(r.__grossDiff) > tol),
    taxErrors: live.filter(r => r.__taxDiff != null && Math.abs(r.__taxDiff) > tol),
    noTax: live.filter(r => r.__noTax), negPrice: live.filter(r => r.__negPrice), noCustomer: live.filter(r => r.__noCustomer),
    dups: live.filter(r => r.__dupOf), tol, anyDomesticTax,
    extTotal: r2(live.reduce((s, r) => s + (r.__ext || 0), 0)), amountTotal: r2(live.filter(r => r.__ext != null).reduce((s, r) => s + (r.amount || 0), 0)) };

  /* ---- Z1.3 cut-off ------------------------------------------------- */
  const cutRows = live.filter(r => r.__inCutoffWindow || r.__deliveredAfterYE || r.__deliveredBeforeInvoicedAfter || (r.__afterYE && !r.__isCN)).sort((a, b) => (a.invoice_date || 0) - (b.invoice_date || 0));
  const cutoff = { rows: cutRows, days: cw,
    before: cutRows.filter(r => !r.__afterYE), after: cutRows.filter(r => r.__afterYE),
    early: live.filter(r => r.__deliveredAfterYE), unrecorded: live.filter(r => r.__deliveredBeforeInvoicedAfter), afterYE: live.filter(r => r.__afterYE && !r.__isCN),
    roundNearYE: live.filter(r => r.__roundNearYE),
    tested: cutRows.filter(r => r.__wp?.cutoff?.correct).length, wrong: cutRows.filter(r => r.__wp?.cutoff?.correct === 'N') };

  /* ---- Z1.4 credit notes -------------------------------------------- */
  const cns = live.filter(r => r.__isCN).sort((a, b) => (a.invoice_date || 0) - (b.invoice_date || 0));
  const creditNotes = { rows: cns, total: r2(cns.reduce((s, r) => s + (r.amount || 0), 0)),
    postYE: cns.filter(r => r.__postYECN), postYEValue: r2(cns.filter(r => r.__postYECN).reduce((s, r) => s + (r.amount || 0), 0)),
    linked: cns.filter(r => r.__cnOriginal).length,
    adjust: cns.filter(r => r.__wp?.cn?.adjust === 'Y') };

  /* ---- Z1.5 sample -------------------------------------------------- */
  const threshold = cfg.sampleThreshold !== '' && cfg.sampleThreshold != null ? Number(cfg.sampleThreshold) : pm;
  const pop = live.filter(r => !r.__isCN && (r.amount || 0) > 0.005 && !r.__afterYE);
  const key = pop.filter(r => r.amount >= threshold);
  const residual = pop.filter(r => r.amount < threshold);
  const n = Math.min(Number(cfg.sampleN) || 0, residual.length);
  const seed = Number(cfg.sampleSeed) || 1;
  const sample = sampleN(residual, n, seed);
  const sampleSet = new Set(sample.map(r => r.__i));
  for (const r of recs) r.__selected = key.includes(r) ? 'Key item' : sampleSet.has(r.__i) ? 'Random sample' : null;
  const selected = [...key, ...sample].sort((a, b) => (b.amount || 0) - (a.amount || 0));
  const popValue = r2(pop.reduce((s, r) => s + r.amount, 0)), keyValue = r2(key.reduce((s, r) => s + r.amount, 0)), sampleValue = r2(sample.reduce((s, r) => s + r.amount, 0));
  const vouched = selected.filter(r => r.__wp?.sample?.amountAgreed === 'Y').length;
  const sampling = { threshold, seed, pop, key, residual, sample, selected, popValue, keyValue, sampleValue,
    coverage: popValue ? r2((keyValue + sampleValue) / popValue * 100) : 0, keyCoverage: popValue ? r2(keyValue / popValue * 100) : 0,
    untested: r2(popValue - keyValue - sampleValue), vouched,
    exceptions: selected.filter(r => ['invoice', 'delivery', 'amountAgreed', 'period'].some(k => r.__wp?.sample?.[k] === 'N')) };

  /* ---- Z1.6 concentration ------------------------------------------- */
  const invTotal = live.filter(r => !r.__isCN).reduce((s, r) => s + (r.amount || 0), 0);
  const customers = Object.values(custs).map(c => ({ ...c, amount: r2(c.amount), share: invTotal ? r2(c.amount / invTotal * 100) : 0 })).sort((a, b) => b.amount - a.amount);
  let cum = 0; customers.forEach(c => { cum += c.share; c.cumulative = r2(cum); });
  const topN = Math.max(1, Number(cfg.topN) || 10), concT = Number(cfg.concThreshold) || 0;
  const concentration = { customers, top: customers.slice(0, topN), topN, count: customers.length, invTotal: r2(invTotal),
    topShare: r2(customers.slice(0, topN).reduce((s, c) => s + c.share, 0)),
    significant: customers.filter(c => concT > 0 && c.share >= concT), concThreshold: concT,
    hhi: r2(customers.reduce((s, c) => s + Math.pow(c.share, 2), 0)) };

  return { lead, bySegment, byStream, monthly, monthlyStats, recalc, cutoff, creditNotes, sampling, concentration, pm, trivial };
}

/* ============================================================== TESTS */
const tests = [
  { id:'EX-REV-01', label:'Invoice dated after the year end included in revenue', basis:'Z1.3',
    fn:(r) => r.__afterYE && !r.__isCN && { actual:Core.fmtDate(r.invoice_date), difference:r.amount, cell:r['__cell_invoice_date'],
      detail:`Invoice dated ${-r.__daysToYE} day(s) after the reporting date${r.__deliveredBeforeInvoicedAfter ? '; goods delivered before the year end — consider whether the revenue belongs in the year' : ' — exclude from the year\'s revenue'}` } },
  { id:'EX-REV-02', label:'Goods delivered after the year end — revenue recognised early', basis:'Z1.3',
    fn:(r) => r.__deliveredAfterYE && { actual:Core.fmtDate(r.do_date), expected:Core.fmtDate(r.invoice_date), difference:r.amount, cell:r['__cell_do_date'],
      detail:`Invoiced ${Core.fmtDate(r.invoice_date)} but delivered ${Core.fmtDate(r.do_date)}, after the reporting date. Control of the goods had not passed at the year end.` } },
  { id:'EX-REV-03', label:'Post year-end credit note reversing recognised revenue', basis:'Z1.4',
    fn:(r) => r.__postYECN && { actual:r.amount, difference:r.amount, cell:r['__cell_amount'],
      detail: r.__cnOriginal ? `Reverses invoice ${r.__cnOriginal.invoice_no} dated ${Core.fmtDate(r.__cnOriginal.invoice_date)} for ${(r.__cnOriginal.amount || 0).toFixed(2)} — assess whether the original sale was valid at the year end` : 'Credit note issued after the year end; original invoice not matched in the listing — obtain the reason for the credit' } },
  { id:'EX-REV-04', label:'Extension error — quantity × unit price differs from the amount', basis:'Z1.2',
    fn:(r, cfg) => r.__extDiff != null && Math.abs(r.__extDiff) > (Number(cfg.recalcTol) >= 0 ? Number(cfg.recalcTol) : 1) &&
      { expected:r.__ext, actual:r.amount, difference:r.__extDiff, cell:r['__cell_amount'], detail:`${r.qty} × ${r.unit_price} = ${r.__ext.toFixed(2)} against ${(r.amount || 0).toFixed(2)} recorded` } },
  { id:'EX-REV-04b', label:'Net amount plus tax differs from the gross amount', basis:'Z1.2',
    fn:(r, cfg) => r.__grossDiff != null && Math.abs(r.__grossDiff) > (Number(cfg.recalcTol) >= 0 ? Number(cfg.recalcTol) : 1) &&
      { expected:r.__grossCalc, actual:r.gross, difference:r.__grossDiff, cell:r['__cell_gross'], detail:'Net + tax does not cast to the invoice total' } },
  { id:'EX-REV-04c', label:'Output tax differs from the standard rate applied to the net amount', basis:'Z1.2', severity:'informational',
    fn:(r, cfg) => r.__taxDiff != null && Math.abs(r.__taxDiff) > (Number(cfg.recalcTol) >= 0 ? Number(cfg.recalcTol) : 1) && !r.__noTax &&
      { expected:r.__expTax, actual:r.tax, difference:r.__taxDiff, cell:r['__cell_tax'], detail:`Tax at ${cfg.taxRate}% would be ${r.__expTax.toFixed(2)}` } },
  { id:'EX-REV-05', label:'No output tax on a domestic sale', basis:'Z1.2',
    fn:(r) => r.__noTax && { actual:r.tax ?? 0, difference:r.amount, cell:r['__cell_tax'], detail:`Segment "${r.segment}" is domestic and other domestic sales carry output tax; this invoice carries none — check the tax treatment` } },
  { id:'EX-REV-06', label:'Duplicate invoice number', basis:'Z1.2',
    fn:(r) => r.__dupOf && { actual:r.invoice_no, difference:r.amount, cell:r['__cell_invoice_no'], detail:`Invoice number also appears on row ${r.__dupOf} — possible double recording of revenue` } },
  { id:'EX-REV-07', label:'Large round-sum sale immediately before the year end', basis:'Z1.3',
    fn:(r, cfg) => r.__roundNearYE && { actual:r.amount, difference:r.amount, cell:r['__cell_amount'],
      detail:`Round sum of ${(r.amount || 0).toFixed(2)} dated ${r.__daysToYE} day(s) before the year end${r.__extDiff != null && Math.abs(r.__extDiff) > 1 ? '; does not agree to quantity × price' : ''} — vouch to contract and delivery evidence` } },
  { id:'EX-REV-08', label:'Negative unit price', basis:'Z1.2',
    fn:(r) => r.__negPrice && { actual:r.unit_price, difference:r.amount, cell:r['__cell_unit_price'], detail:'Unit price is negative on an invoice — data entry error or a credit disguised as a sale' } },
  { id:'EX-REV-09', label:'Customer not stated on the invoice', basis:'Z1.2',
    fn:(r) => r.__noCustomer && { difference:r.amount, cell:r['__cell_customer'], detail:'No customer on the sales invoice — existence of the sale and recoverability cannot be established' } },
  { id:'EX-REV-10', label:'Invoice dated before the start of the financial year', basis:'Z1', severity:'informational',
    fn:(r) => r.__beforeFY && { actual:Core.fmtDate(r.invoice_date), difference:r.amount, cell:r['__cell_invoice_date'], detail:'Dated in the prior period — confirm the listing covers only the year under audit' } },
  { id:'EX-REV-11', label:'Sample item not yet agreed to supporting documents', basis:'Z1.5', severity:'informational',
    fn:(r) => r.__selected === 'Key item' && r.__wp?.sample?.amountAgreed !== 'Y' && { actual:r.amount, difference:r.amount, detail:'Key item selected on Z1.5; invoice and delivery evidence not yet recorded as agreed' } },
  { id:'EX-REV-12', scope:'population', label:'Month-on-month revenue movement beyond the threshold', basis:'Z1.1', severity:'informational',
    fn:(recs, cfg, eng, d) => d.monthlyStats.flagged.map(m => ({ key:m.label, actual:m.amount, expected:d.monthlyStats.avg, difference:m.mom ?? r2(m.amount - d.monthlyStats.avg),
      detail:`${m.momPct != null ? m.momPct.toFixed(1) + '% against the prior month; ' : ''}${m.vsAvg != null ? m.vsAvg.toFixed(1) + '% against the monthly average' : ''} — obtain the business reason` })) },
  { id:'EX-REV-13', scope:'population', label:'Customer concentration above the threshold', basis:'Z1.6', severity:'informational',
    fn:(recs, cfg, eng, d) => d.concentration.significant.map(c => ({ key:c.customer, actual:c.amount, difference:c.amount, detail:`${c.share.toFixed(1)}% of invoiced revenue — consider dependence, recoverability and disclosure` })) },
  { id:'EX-REV-20', scope:'population', label:'Sales listing does not agree to revenue per the trial balance', basis:'Z1',
    fn:(recs, cfg, eng, d) => {
      const tol = Number(cfg.castTol) || 0.01;
      const seg = d.bySegment.filter(s => s.tbDiff != null && Math.abs(s.tbDiff) > tol).map(s => ({ key:s.segment, expected:s.tb, actual:s.amount, difference:s.tbDiff, detail:'Listing total for the segment against the trial balance figure entered' }));
      if (seg.length) return seg;
      return !d.lead.segTBEntered && d.lead.tbDiff != null && Math.abs(d.lead.tbDiff) > tol &&
        { key:'Revenue', expected:d.lead.tb, actual:d.lead.total, difference:d.lead.tbDiff, detail:'Listing total (invoices less credit notes) against revenue per the trial balance' };
    } }
];

/* ============================================================== PAGES */
const yn = ['Y', 'N'];
const invRow = r => ({ __rec:r, invoice:r.invoice_no, invDate:r.invoice_date, customer:r.customer, product:r.product, segment:r.segment, amount:r.amount, doDate:r.do_date });
const INV_COLS = [
  { key:'invoice', label:'Invoice' }, { key:'invDate', label:'Invoice date', type:'date' }, { key:'customer', label:'Customer' },
  { key:'product', label:'Product / stream' }, { key:'amount', label:'Net amount', type:'num', sum:true }
];

const pages = [
  { id:'source',  ref:'Z1.0',  title:'Source data',     kind:'source' },
  { id:'cleaned', ref:'Z1.0a', title:'Cleaned listing', kind:'cleaned' },
  { id:'mapping', ref:'Z1.0b', title:'Column mapping',  kind:'mapping' },

  { id:'lead', ref:'Z1', title:'Lead schedule',
    objective:'To agree revenue per the sales listing to the trial balance and the prior year audited figure, by segment and revenue stream, and to explain material movements.',
    procedures:['Cast the sales listing, separating invoices from credit notes and items dated outside the financial year.',
                'Agreed the listing total to revenue per the trial balance, in total and by segment where entered.',
                'Compared revenue to the prior year and investigated movements above performance materiality.'],
    render(st, ctx) {
      const d = ctx.d, Lz = d.lead, m0 = ctx.money0, money = ctx.money, pct = ctx.pct;
      return [
        { type:'controls', items:[
          { key:'tbRevenue', label:'Revenue per trial balance (if not entered by segment below)', kind:'number' },
          { key:'pyRevenue', label:'Revenue per prior year audited financial statements', kind:'number' },
          { key:'castTol', label:'Tolerance', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Listing total (invoices less credit notes)', value: m0(Lz.total) },
          { label:'Documents', value: `${Lz.invoices} invoices · ${Lz.cns} credit notes` },
          { label:'Dated within the year', value: m0(Lz.inPeriod) },
          { label:'Dated after year end', value: money(Lz.afterYE), cls: Math.abs(Lz.afterYE) > 0.005 ? 'bad' : 'ok' },
          { label:'Dated before the year', value: money(Lz.beforeFY), cls: Math.abs(Lz.beforeFY) > 0.005 ? 'warn' : 'ok' },
          { label:'Undated', value: money(Lz.undated), cls: Math.abs(Lz.undated) > 0.005 ? 'warn' : 'ok' },
          { label:'Credit notes', value: money(Lz.cnTotal) },
          { label:'Per trial balance', value: Lz.tb == null ? '— enter —' : m0(Lz.tb) },
          { label:'Listing − TB', value: Lz.tbDiff == null ? '' : money(Lz.tbDiff), cls: Lz.tbDiff == null ? '' : Math.abs(Lz.tbDiff) > 0.01 ? 'bad' : 'ok' },
          { label:'Movement vs PY', value: Lz.variance == null ? '— enter PY —' : `${money(Lz.variance)} (${pct(Lz.variancePct)})`, cls: Lz.variance != null && Math.abs(Lz.variance) > ctx.pm ? 'warn' : '' } ] },
        { type:'table', title:'Revenue by segment — listing vs trial balance vs prior year', columns:[
          { key:'segment', label:'Segment' }, { key:'count', label:'Documents', type:'int' },
          { key:'amount', label:'Per listing', type:'num', sum:true, emphasis:true }, { key:'cn', label:'of which credit notes', type:'num', sum:true }, { key:'share', label:'Share', type:'pct' },
          { key:'tbSeg', label:'Per trial balance', input:'number' }, { key:'tbDiff', label:'Listing − TB', type:'num', flag: v => v != null && Math.abs(v) > 0.01 },
          { key:'pySeg', label:'Prior year', input:'number' }, { key:'variance', label:'Movement', type:'num', flag: (v, row) => row.__cls === 'flag' }, { key:'variancePct', label:'Movement %', type:'pct' },
          { key:'comment', label:'Explanation of movement', input:'text', wide:true } ],
          rows: d.bySegment.map(s => ({ __key:s.key, ...s, share: s.share / 100, variancePct: s.variancePct != null ? s.variancePct / 100 : null, __cls: s.material ? 'flag' : '' })),
          footnote:'Segment differences above the tolerance are raised as EX-REV-20.' },
        { type:'table', title:'Revenue by product / revenue stream', columns:[
          { key:'stream', label:'Product / stream' }, { key:'count', label:'Documents', type:'int' },
          { key:'amount', label:'Per listing', type:'num', sum:true }, { key:'share', label:'Share', type:'pct' },
          { key:'comment', label:'Auditor comment (recognition point, pattern)', input:'text', wide:true } ],
          rows: d.byStream.map(p => ({ __key:p.key, ...p, share: p.share / 100 })) }
      ];
    },
    flag(st, d) { return (d.lead.tbDiff != null && Math.abs(d.lead.tbDiff) > 0.01) || Math.abs(d.lead.afterYE) > 0.005; } },

  { id:'monthly', ref:'Z1.1', title:'Monthly revenue analysis',
    objective:'To analyse revenue by month for the year, identify months whose movement against the prior month or the monthly average exceeds the threshold, and obtain explanations.',
    procedures:['Summarised revenue by month of invoice for the twelve months of the financial year.',
                'Computed the month-on-month movement and the deviation from the monthly average and flagged months beyond the threshold set.',
                'Obtained and corroborated management\'s explanation for each flagged month.'],
    render(st, ctx) {
      const d = ctx.d, S = d.monthlyStats, m0 = ctx.money0;
      return [
        { type:'controls', items:[{ key:'momThreshold', label:'Flag months moving more than (%)', kind:'number', help:'Applied to the month-on-month movement and to the deviation from the monthly average; a month is flagged only where the movement also exceeds the trivial threshold.' }] },
        { type:'stats', items:[
          { label:'Months with sales', value: `${S.monthsWithSales} of ${d.monthly.length}` }, { label:'Monthly average', value: m0(S.avg) },
          { label:'Highest month', value: S.max ? `${S.max.label} · ${m0(S.max.amount)}` : '' }, { label:'Lowest month', value: S.min ? `${S.min.label} · ${m0(S.min.amount)}` : '' },
          { label:'Months flagged', value: S.flagged.length, cls: S.flagged.length ? 'warn' : 'ok' } ] },
        { type:'table', title:'Revenue by month', columns:[
          { key:'label', label:'Month' }, { key:'count', label:'Documents', type:'int' },
          { key:'invoices', label:'Invoices', type:'num', sum:true }, { key:'cns', label:'Credit notes', type:'num', sum:true },
          { key:'amount', label:'Net revenue', type:'num', sum:true, emphasis:true, formula:(row, C) => `${C(2)}${row}+${C(3)}${row}` },
          { key:'share', label:'Share of year', type:'pct' },
          { key:'mom', label:'Movement vs prior month', type:'num', flag: (v, row) => row.__cls === 'flag' }, { key:'momPct', label:'Movement %', type:'pct' },
          { key:'vsAvg', label:'vs average %', type:'pct' },
          { key:'explanation', label:'Explanation obtained', input:'text', wide:true },
          { key:'corroborated', label:'Corroborated (Y/N)', input:'select', options:yn } ],
          rows: d.monthly.map(m => ({ __key:m.month, ...m, share: m.share / 100, momPct: m.momPct != null ? m.momPct / 100 : null, vsAvg: m.vsAvg != null ? m.vsAvg / 100 : null, __cls: m.flag ? 'flag' : '' })),
          emptyText:'No dated invoices fall within the financial year.',
          footnote:'Flagged months are raised as EX-REV-12 (informational) until explained.' }
      ];
    },
    flag(st, d) { return d.monthlyStats.flagged.length > 0; } },

  { id:'recalc', ref:'Z1.2', title:'Price × quantity and tax check',
    objective:'To recalculate each invoice from quantity and unit price, prove net plus tax to the gross amount, and identify invoices with no output tax, negative prices, missing customers or duplicated numbers.',
    procedures:['Recalculated quantity × unit price for every line and compared it to the net amount recorded.',
                'Proved net amount plus output tax to the gross invoice total.',
                'Identified domestic sales with no output tax, negative unit prices, invoices without a customer and duplicated invoice numbers.'],
    render(st, ctx) {
      const R = ctx.d.recalc, m0 = ctx.money0, money = ctx.money;
      const rows = R.rows.map(r => ({ ...invRow(r), qty:r.qty, price:r.unit_price, ext:r.__ext, extDiff:r.__extDiff, tax:r.tax, expTax:r.__expTax, gross:r.gross, grossCalc:r.__grossCalc, grossDiff:r.__grossDiff,
        issues: [r.__extDiff != null && Math.abs(r.__extDiff) > R.tol ? 'Extension' : null, r.__grossDiff != null && Math.abs(r.__grossDiff) > R.tol ? 'Gross cast' : null, r.__noTax ? 'No tax' : null, r.__negPrice ? 'Negative price' : null, r.__noCustomer ? 'No customer' : null, r.__dupOf ? 'Duplicate no.' : null].filter(Boolean).join('; '),
        __cls: [r.__extDiff != null && Math.abs(r.__extDiff) > R.tol, r.__grossDiff != null && Math.abs(r.__grossDiff) > R.tol, r.__noTax, r.__negPrice, r.__noCustomer, r.__dupOf].some(Boolean) ? 'flag' : '' }));
      return [
        { type:'controls', items:[
          { key:'recalcTol', label:'Tolerance for recalculation differences', kind:'number' },
          { key:'taxRate', label:'Standard output tax rate % (optional, recomputes expected tax)', kind:'number' },
          { key:'domesticPattern', label:'Segment pattern treated as domestic (regular expression)', kind:'text' } ] },
        { type:'stats', items:[
          { label:'Lines recalculated', value: R.rows.length },
          { label:'Qty × price total vs amount', value: `${m0(R.extTotal)} vs ${m0(R.amountTotal)}` },
          { label:'Extension errors', value: R.extErrors.length, cls: R.extErrors.length ? 'bad' : 'ok' },
          { label:'Gross does not cast', value: R.grossErrors.length, cls: R.grossErrors.length ? 'bad' : 'ok' },
          { label:'Tax rate differences', value: R.taxErrors.length, cls: R.taxErrors.length ? 'warn' : 'ok' },
          { label:'Domestic sales with no output tax', value: R.noTax.length, cls: R.noTax.length ? 'bad' : (R.anyDomesticTax ? 'ok' : '') },
          { label:'Negative unit prices', value: R.negPrice.length, cls: R.negPrice.length ? 'bad' : 'ok' },
          { label:'No customer', value: R.noCustomer.length, cls: R.noCustomer.length ? 'bad' : 'ok' },
          { label:'Duplicate invoice numbers', value: R.dups.length, cls: R.dups.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Recalculation by invoice', columns:[
          { key:'invoice', label:'Invoice' }, { key:'invDate', label:'Date', type:'date' }, { key:'customer', label:'Customer' }, { key:'segment', label:'Segment' },
          { key:'qty', label:'Qty', type:'num', dp:0 }, { key:'price', label:'Unit price', type:'num', flag: v => v != null && v < 0 },
          { key:'ext', label:'Qty × price (audit)', type:'num', sum:true }, { key:'amount', label:'Net per client', type:'num', sum:true, emphasis:true },
          { key:'extDiff', label:'Difference', type:'num', flag: v => v != null && Math.abs(v) > R.tol },
          { key:'tax', label:'Tax per client', type:'num', sum:true, flag: (v, row) => row.__rec.__noTax }, { key:'expTax', label:'Tax per audit', type:'num' },
          { key:'grossCalc', label:'Net + tax (audit)', type:'num', sum:true }, { key:'gross', label:'Gross per client', type:'num', sum:true },
          { key:'grossDiff', label:'Difference', type:'num', flag: v => v != null && Math.abs(v) > R.tol },
          { key:'issues', label:'Issues', wrap:true },
          { key:'explanation', label:'Explanation / document seen', input:'text', wide:true },
          { key:'resolved', label:'Resolved (Y/N)', input:'select', options:yn } ], rows, maxHeight:'70vh',
          emptyText:'No quantity, price or gross columns were mapped — the recalculation cannot be performed.',
          footnote:`Differences above ${money(R.tol)} are raised as EX-REV-04 (extension) and EX-REV-04b (gross). No-tax domestic sales are EX-REV-05, negative prices EX-REV-08, missing customers EX-REV-09 and duplicated numbers EX-REV-06.${R.anyDomesticTax ? '' : ' No domestic invoice in the listing carries output tax, so the no-tax test is dormant — confirm the entity\'s registration status.'}` }
      ];
    },
    flag(st, d) { const R = d.recalc; return R.extErrors.length + R.grossErrors.length + R.noTax.length + R.negPrice.length + R.noCustomer.length + R.dups.length > 0; } },

  { id:'cutoff', ref:'Z1.3', title:'Cut-off testing',
    objective:'To verify that sales invoiced around the year end are recorded in the period in which control of the goods or services passed to the customer.',
    procedures:['Listed every invoice and delivery dated within the cut-off window either side of the year end, and every invoice dated after the year end.',
                'Compared the invoice date to the delivery date and identified sales delivered after the year end but invoiced before it, and sales delivered before the year end but invoiced after it.',
                'Identified large round-sum sales in the days immediately before the year end.',
                'Vouched each item to the delivery order or proof of service and recorded whether it is in the correct period.'],
    render(st, ctx) {
      const C = ctx.d.cutoff, m0 = ctx.money0;
      return [
        { type:'controls', items:[
          { key:'cutoffDays', label:'Cut-off window (days either side of the year end)', kind:'number' },
          { key:'roundSum', label:'Round-sum flag: multiple of', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Items in the window', value: `${C.rows.length} · ${m0(C.rows.reduce((s, r) => s + (r.amount || 0), 0))}` },
          { label:'Invoiced before year end', value: C.before.length }, { label:'Invoiced after year end', value: C.afterYE.length, cls: C.afterYE.length ? 'bad' : 'ok' },
          { label:'Delivered after year end, invoiced before', value: `${C.early.length} · ${m0(C.early.reduce((s, r) => s + (r.amount || 0), 0))}`, cls: C.early.length ? 'bad' : 'ok' },
          { label:'Delivered before, invoiced after', value: C.unrecorded.length, cls: C.unrecorded.length ? 'warn' : 'ok' },
          { label:'Round sums before year end', value: C.roundNearYE.length, cls: C.roundNearYE.length ? 'warn' : 'ok' },
          { label:'Tested', value: `${C.tested} of ${C.rows.length}`, cls: C.tested === C.rows.length && C.rows.length ? 'ok' : 'warn' },
          { label:'Wrong period', value: C.wrong.length, cls: C.wrong.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Invoices around the year end', columns:[
          ...INV_COLS, { key:'doDate', label:'Delivery date', type:'date', flag: (v, row) => row.__rec.__deliveredAfterYE },
          { key:'daysToYE', label:'Days before YE', type:'int' },
          { key:'side', label:'Side', type:'chip', chipClass: v => v === 'Invoiced after year end' ? 'info' : 'grey' },
          { key:'view', label:'Assessment per audit', wrap:true },
          { key:'doSighted', label:'DO / proof of delivery sighted (Y/N)', input:'select', options:yn },
          { key:'deliveryPerDO', label:'Delivery date per DO', input:'text' },
          { key:'correct', label:'Correct period (Y/N)', input:'select', options:yn },
          { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: C.rows.map(r => ({ ...invRow(r), daysToYE:r.__daysToYE, side:r.__cutoffSide, view:r.__cutoffView, __cls: r.__deliveredAfterYE || r.__afterYE || r.__roundNearYE ? 'flag' : '' })), maxHeight:'70vh',
          emptyText:'No invoices fall within the cut-off window. Widen the window or confirm the listing covers the year end.',
          footnote:'Invoices dated after the year end are EX-REV-01; deliveries after the year end on pre year-end invoices are EX-REV-02; round sums immediately before the year end are EX-REV-07.' }
      ];
    },
    flag(st, d) { return d.cutoff.early.length > 0 || d.cutoff.afterYE.length > 0 || d.cutoff.wrong.length > 0; } },

  { id:'cn', ref:'Z1.4', title:'Post year-end credit notes',
    objective:'To identify credit notes issued after the year end that reverse revenue recognised in the year, and to assess whether the original sale was valid at the reporting date.',
    procedures:['Listed every credit note in the listing and matched it to the original invoice by number or by customer and amount.',
                'For credit notes issued after the year end, obtained the reason for the credit and assessed whether the revenue was validly recognised.',
                'Proposed an adjustment where the credit indicates the sale should not have been recognised.'],
    render(st, ctx) {
      const N = ctx.d.creditNotes, m0 = ctx.money0;
      return [
        { type:'stats', items:[
          { label:'Credit notes', value: `${N.rows.length} · ${m0(N.total)}` },
          { label:'Issued after year end', value: `${N.postYE.length} · ${m0(N.postYEValue)}`, cls: N.postYE.length ? 'bad' : 'ok' },
          { label:'Matched to original invoice', value: `${N.linked} of ${N.rows.length}` },
          { label:'Adjustments proposed', value: N.adjust.length } ] },
        { type:'table', title:'Credit notes and the invoices they reverse', columns:[
          { key:'invoice', label:'Credit note' }, { key:'invDate', label:'Date', type:'date' }, { key:'customer', label:'Customer' },
          { key:'amount', label:'Amount', type:'num', sum:true },
          { key:'timing', label:'Timing', type:'chip', chipClass: v => v === 'After year end' ? 'bad' : 'grey' },
          { key:'origNo', label:'Original invoice' }, { key:'origDate', label:'Original date', type:'date' }, { key:'origAmount', label:'Original amount', type:'num' },
          { key:'reason', label:'Reason for credit', input:'text', wide:true },
          { key:'preYE', label:'Sale invalid at year end (Y/N)', input:'select', options:yn },
          { key:'adjust', label:'Adjust (Y/N)', input:'select', options:yn },
          { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: N.rows.map(r => ({ ...invRow(r), timing: r.__postYECN ? 'After year end' : 'Within year', origNo: r.__cnOriginal?.invoice_no || '', origDate: r.__cnOriginal?.invoice_date || null, origAmount: r.__cnOriginal?.amount ?? null, __cls: r.__postYECN ? 'flag' : '' })),
          emptyText:'No credit notes in the listing. Obtain the post year-end credit note register separately and record any reversals here.',
          footnote:'Credit notes dated after the year end are raised as EX-REV-03.' }
      ];
    },
    flag(st, d) { return d.creditNotes.postYE.length > 0; } },

  { id:'sample', ref:'Z1.5', title:'Substantive sample and vouching',
    objective:'To obtain evidence of the occurrence, accuracy and cut-off of recorded revenue by vouching a sample of invoices to the sales invoice, delivery evidence and cash receipt.',
    procedures:['Selected every invoice at or above the testing threshold as a key item.',
                'Drew a random sample from the remaining invoices using a recorded seed so the selection is reproducible.',
                'For each selected invoice, sighted the invoice, the delivery order or proof of service, agreed the amount and confirmed the period of recognition.'],
    render(st, ctx) {
      const S = ctx.d.sampling, m0 = ctx.money0, pct = ctx.pct;
      return [
        { type:'controls', items:[
          { key:'sampleThreshold', label:'Testing threshold — every invoice at or above is a key item', kind:'number', help:`Blank = performance materiality (${m0(ctx.pm)}). Currently ${m0(S.threshold)}.` },
          { key:'sampleN', label:'Random sample from the remaining invoices', kind:'number', help:`${S.residual.length} invoices below the threshold` },
          { key:'sampleSeed', label:'Random seed', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Population (invoices dated in the year)', value: `${S.pop.length} · ${m0(S.popValue)}` },
          { label:'Key items', value: `${S.key.length} · ${m0(S.keyValue)}` }, { label:'Random sample', value: `${S.sample.length} · ${m0(S.sampleValue)}` },
          { label:'Coverage', value: pct(S.coverage), cls: S.coverage >= 60 ? 'ok' : 'warn' }, { label:'Untested value', value: m0(S.untested) },
          { label:'Agreed to supporting documents', value: `${S.vouched} of ${S.selected.length}`, cls: S.vouched === S.selected.length && S.selected.length ? 'ok' : 'warn' },
          { label:'Exceptions noted', value: S.exceptions.length, cls: S.exceptions.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Invoices selected for vouching', columns:[
          ...INV_COLS, { key:'doDate', label:'Delivery date', type:'date' },
          { key:'basis', label:'Basis', type:'chip', chipClass: v => v === 'Key item' ? 'info' : 'grey' },
          { key:'invoice', label:'Invoice sighted (Y/N)', input:'select', options:yn },
          { key:'delivery', label:'DO / proof of delivery sighted (Y/N)', input:'select', options:yn },
          { key:'amountAgreed', label:'Amount agreed (Y/N)', input:'select', options:yn },
          { key:'period', label:'Period correct (Y/N)', input:'select', options:yn },
          { key:'receipt', label:'Traced to cash receipt (date / ref)', input:'text' },
          { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: S.selected.map(r => ({ ...invRow(r), basis:r.__selected, __cls: ['invoice', 'delivery', 'amountAgreed', 'period'].some(k => r.__wp?.sample?.[k] === 'N') ? 'flag' : '' })), maxHeight:'70vh',
          emptyText:'No invoices selected — lower the threshold or increase the sample size.',
          footnote:`Seed ${S.seed}. Key items not yet agreed are listed as EX-REV-11 until vouched.` }
      ];
    },
    flag(st, d) { return d.sampling.exceptions.length > 0; } },

  { id:'conc', ref:'Z1.6', title:'Customer concentration',
    objective:'To identify the principal customers and the degree of dependence on them, as a basis for recoverability, going concern and disclosure considerations.',
    procedures:['Summarised invoiced revenue by customer, normalising minor variations in the customer name.',
                'Listed the largest customers with their share and cumulative share of invoiced revenue and flagged customers above the concentration threshold.'],
    render(st, ctx) {
      const K = ctx.d.concentration, m0 = ctx.money0, pct = ctx.pct;
      return [
        { type:'controls', items:[
          { key:'topN', label:'Customers to list', kind:'number' },
          { key:'concThreshold', label:'Concentration threshold (% of invoiced revenue)', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Distinct customers', value: K.count }, { label:'Invoiced revenue', value: m0(K.invTotal) },
          { label:`Top ${K.topN} share`, value: pct(K.topShare), cls: K.topShare >= 80 ? 'warn' : '' },
          { label:'Customers above threshold', value: K.significant.length, cls: K.significant.length ? 'warn' : 'ok' },
          { label:'Concentration index (HHI)', value: K.hhi } ] },
        { type:'table', title:'Largest customers', columns:[
          { key:'customer', label:'Customer' }, { key:'count', label:'Invoices', type:'int' },
          { key:'amount', label:'Invoiced revenue', type:'num', sum:true }, { key:'share', label:'Share', type:'pct' }, { key:'cumulative', label:'Cumulative', type:'pct' },
          { key:'related', label:'Related party (Y/N)', input:'select', options:yn },
          { key:'comment', label:'Auditor comment', input:'text', wide:true } ],
          rows: K.top.map(c => ({ __key:c.key || 'blank', ...c, share: c.share / 100, cumulative: c.cumulative / 100, __cls: K.concThreshold > 0 && c.share >= K.concThreshold ? 'flag' : '' })),
          emptyText:'No invoices with a customer name.',
          footnote:'Customer names are grouped after removing legal suffixes and punctuation so that variants of the same name fall together. Customers above the threshold are raised as EX-REV-13 (informational).' }
      ];
    } },

  { id:'conclusion', ref:'Z1.9', title:'Exceptions & conclusion', kind:'conclusion' }
];

function suggestConclusion(st, ctx) {
  const d = ctx.d, Lz = d.lead, S = d.sampling, C = d.cutoff;
  const ex = (st.exceptions || []).filter(e => e.disposition === 'open');
  return [
    `Revenue per the sales listing totals ${ctx.money(Lz.total)} across ${Lz.invoices} invoices and ${Lz.cns} credit notes${Lz.tbDiff == null ? '' : Math.abs(Lz.tbDiff) <= 0.01 ? ', agreeing to the trial balance' : `, differing from the trial balance by ${ctx.money(Lz.tbDiff)}`}.`,
    d.monthlyStats.flagged.length ? `${d.monthlyStats.flagged.length} month(s) moved beyond the analytical threshold and were explained.` : 'No month moved beyond the analytical threshold.',
    `${S.selected.length} invoices (${ctx.pct(S.coverage)} of the population) were selected for vouching; ${S.vouched} agreed to supporting documents.`,
    C.early.length || C.afterYE.length ? `Cut-off testing identified ${C.early.length} sale(s) delivered after the year end and ${C.afterYE.length} invoice(s) dated after the year end.` : 'Cut-off testing identified no sales recorded in the wrong period.',
    d.creditNotes.postYE.length ? `${d.creditNotes.postYE.length} credit note(s) totalling ${ctx.money(d.creditNotes.postYEValue)} were issued after the year end.` : '',
    ex.length ? `${ex.length} exception(s) remain open in the register.` : 'No exceptions remain open.',
    'Subject to the above, revenue is fairly stated for the year.'
  ].filter(Boolean).join(' ');
}

return {
  code:'REV', name:'Revenue', group:'Profit or loss', accepts:'.xlsx,.xlsm,.csv',
  blurb:'The revenue audit file: lead by segment and stream, monthly analysis, price × quantity and tax recalculation, cut-off, post year-end credit notes, substantive sample and customer concentration — from one uploaded sales listing.',
  objective:'To obtain sufficient appropriate audit evidence that recorded revenue occurred, is complete, is accurately measured and is recognised in the correct period, and that it is appropriately presented and disclosed.',
  fields, tests, compute, pages, defaultConfig, STANDARD_COLUMNS,
  procedures: pages.flatMap(p => p.procedures || []),
  columns: STANDARD_COLUMNS, suggestConclusion
};
})();

Modules.register(REVModule);
