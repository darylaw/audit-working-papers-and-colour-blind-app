/* ==========================================================================
   imp.js -- Impairment of non-financial assets (FRS 36) as an auditor works it.

   The uploaded sheet is the client's cash-generating unit register (carrying
   amount built up by asset class, goodwill, tested-annually answer and last
   test date). The client's indicator assessment and value-in-use model are
   transcribed by the auditor onto their own working papers and recomputed:
     IMP    Lead schedule                     IMP-06  Sensitivity and break-even
     IMP-01 CGU register                      IMP-07  Allocation of impairment loss
     IMP-02 Indicator checklist (paras 12-14) IMP-10  Use of a specialist
     IMP-03 Value in use model

   Everything is arithmetic: value in use, headroom, the break-even value of
   each key assumption by bisection, and the para 105 allocation. The auditor
   answers the declarations and concludes.
   ========================================================================== */

const IMPModule = (() => {
const r2 = n => n == null || isNaN(n) ? null : Math.round(n * 100) / 100;
const r4 = n => n == null || isNaN(n) ? null : Math.round(n * 10000) / 10000;
const num = v => (v === '' || v == null || isNaN(Number(v))) ? null : Number(v);
const inp = (cfg, key, k) => num(cfg[key + ':' + k]);
const txt = (cfg, key, k) => { const v = cfg[key + ':' + k]; return v == null ? '' : String(v).trim(); };
const ckey = name => Core.keyify(name) || 'blank';
const yn = ['Y', 'N'];
const MAXY = 30;

/* FRS 36 para 12 -- the minimum indicators (as in the PPE file). Answered Y/N by the auditor. */
const INDICATORS = [
  { id:'12a', src:'External', text:'Significant decline in market value of assets, beyond the passage of time or normal use' },
  { id:'12b', src:'External', text:'Adverse change in the technological, market, economic or legal environment in which the entity operates' },
  { id:'12c', src:'External', text:'Market interest rates or other market rates of return have increased, likely to reduce recoverable amount materially' },
  { id:'12d', src:'External', text:'Carrying amount of the entity\'s net assets exceeds its market capitalisation (listed entities)' },
  { id:'12e', src:'Internal', text:'Evidence of obsolescence or physical damage' },
  { id:'12f', src:'Internal', text:'Asset idle, plans to discontinue or restructure the operation, plans to dispose earlier than expected, or useful life reassessed as finite' },
  { id:'12g', src:'Internal', text:'Internal reporting indicates economic performance of an asset is, or will be, worse than expected' },
  { id:'14',  src:'Internal', text:'Cash flows to acquire or operate the asset significantly above budget; actual results or budgeted cash flows significantly worse than expected' },
];
const SPECIALIST_ITEMS = [
  { id:'S1', text:'The valuation was prepared by an external specialist for the current year (record who prepared the prior year model on this page)' },
  { id:'S2', text:'Competence: the preparer holds relevant professional qualifications and experience in valuing this class of asset or business' },
  { id:'S3', text:'Capability: the preparer had access to the data, time and resources needed, and used a recognised methodology' },
  { id:'S4', text:'Objectivity: relationships, fee arrangements and other threats to the preparer\'s objectivity were evaluated' },
  { id:'S5', text:'Scope: the engagement or terms of reference cover value in use as defined in FRS 36 paras 30-57, not fair value or another basis' },
  { id:'S6', text:'The preparer worked to the requirements of the financial reporting framework (pre-tax rate, no financing or tax flows, no uncommitted expansion)' },
  { id:'S7', text:'Source data used by the preparer was tested and agreed to the approved budget and to audited figures' },
  { id:'S8', text:'The auditor evaluated the reasonableness of the specialist\'s assumptions and methods (ISA 500 para 8 / ISA 620 para 12)' },
  { id:'S9', text:'Where preparation moved from an external specialist to the client\'s own team, the reason was obtained and the assumptions compared to the specialist\'s prior year model' },
];
const ASSET_CLASSES = [
  { key:'ppe', label:'Property, plant and equipment' }, { key:'rou', label:'Right-of-use assets' },
  { key:'intang_finite', label:'Intangibles (finite life)' }, { key:'intang_indef', label:'Intangibles (indefinite life)' },
  { key:'goodwill', label:'Goodwill' }, { key:'other', label:'Other assets less liabilities' }
];
const RA_BASES = ['Value in use', 'Fair value less costs of disposal', 'Higher of both', 'Not estimated'];
const PREPARERS = ['Internal (client)', 'External specialist'];
const VS_PY = ['More favourable', 'Unchanged', 'Less favourable', 'Not comparable'];

/* ---------------------------------------------------------------- fields */
const fields = [
  { key:'cgu', label:'Cash-generating unit', role:'key', type:'text', required:true, dupKey:true,
    synonyms:['CGU','Cash-generating unit','Cash generating unit','Unit','CGU name','Business unit','Division','Segment / CGU','现金产出单元'] },
  { key:'segment', label:'Operating segment', type:'text', synonyms:['Operating segment','Segment','Reportable segment','业务分部'] },
  { key:'basis', label:'Basis of identification', type:'text', synonyms:['Basis of identification','Basis','Identification basis','Rationale'] },
  { key:'ppe', label:'PPE', type:'number', required:true, synonyms:['PPE','Property, plant and equipment','Property plant and equipment','Fixed assets','固定资产'] },
  { key:'rou', label:'Right-of-use assets', type:'number', synonyms:['Right-of-use assets','ROU','ROU assets','Right of use','使用权资产'] },
  { key:'intang_finite', label:'Intangibles (finite life)', type:'number', synonyms:['Intangibles (finite life)','Finite life intangibles','Intangibles - finite','Intangible assets (finite)','Other intangibles'] },
  { key:'intang_indef', label:'Intangibles (indefinite life)', type:'number', synonyms:['Intangibles (indefinite life)','Indefinite life intangibles','Intangibles - indefinite','Indefinite-life intangibles','Brands','Trademarks'] },
  { key:'goodwill', label:'Goodwill', type:'number', required:true, synonyms:['Goodwill','GW','Allocated goodwill','商誉'] },
  { key:'other', label:'Other assets less liabilities', type:'number', synonyms:['Other assets less liabilities','Other net assets','Working capital','Corporate assets','Other assets','Net other'] },
  { key:'carrying', label:'Carrying amount', type:'number', required:true, synonyms:['Carrying amount','Carrying value','Total carrying amount','NBV','Net book value','账面价值'] },
  { key:'tested_annually', label:'Tested annually?', type:'text', synonyms:['Tested annually?','Tested annually','Annual test','Annual impairment test','Tested'] },
  { key:'last_tested', label:'Date last tested', type:'date', synonyms:['Date last tested','Last tested','Last test date','Date of last impairment test','Last impairment test'] },
  { key:'py_carrying', label:'Carrying amount — prior year', type:'number', synonyms:['Prior year carrying amount','PY carrying amount','Carrying amount PY','Prior year'] },
];

const STANDARD_COLUMNS = [
  { key:'cgu', label:'CGU' }, { key:'segment', label:'Segment' },
  { key:'ppe', label:'PPE', type:'num', edit:true }, { key:'rou', label:'ROU', type:'num', edit:true },
  { key:'intang_finite', label:'Intang. (finite)', type:'num', edit:true }, { key:'intang_indef', label:'Intang. (indefinite)', type:'num', edit:true },
  { key:'goodwill', label:'Goodwill', type:'num', edit:true }, { key:'other', label:'Other net', type:'num', edit:true },
  { key:'__carryingAudit', label:'Carrying per audit', type:'num' }, { key:'carrying', label:'Carrying per client', type:'num', edit:true, emphasis:true },
  { key:'tested_annually', label:'Tested annually?' }, { key:'last_tested', label:'Last tested', type:'date', edit:true }
];

const defaultConfig = () => ({
  castTol: 0.01,
  annualTestMonths: 12,
  impairmentPerClient: '', impairmentPY: '',        // lead: charge recognised per client, prior year charge
  /* IMP-03 value in use — the client's model transcribed and recomputed */
  viuCgu: '',                 // CGU the model relates to (blank = the CGU with the largest goodwill)
  viuYears: 5,
  viuRate: '', viuRateBasis: '', viuGrowth: '', viuBenchmark: '',
  viuYearsJustification: '', viuGrowthJustification: '',
  declTax: '', declFinancing: '', declExpansion: '', declRisk: '',
  clientVIU: '', clientTV: '',
  /* IMP-06 */
  sensPrepared: '', sensDisclosed: '',
  rpRateBps: 100, rpGrowthBps: 100, rpCashPct: 10,
  /* IMP-07 */
  allocLoss: '',
  /* IMP-10 */
  preparedByCY: '', preparedByPY: '', assumptionsVsPY: '',
  impSpecialist: {}
});

/* ============================================================ COMPUTE */
const monthsBetween = (a, b) => (a && b) ? (b.getUTCFullYear() - a.getUTCFullYear()) * 12 + (b.getUTCMonth() - a.getUTCMonth()) - (b.getUTCDate() < a.getUTCDate() ? 1 : 0) : null;

/* value in use for N years of cash flows at rate r with terminal growth g */
function viuOf(cf, r, g, opts = {}) {
  const N = cf.length; const k = opts.cfMult ?? 1;
  let pv = 0; const years = [];
  for (let t = 1; t <= N; t++) {
    const df = 1 / Math.pow(1 + r, t), flow = (cf[t - 1] || 0) * k, p = flow * df;
    pv += p; years.push({ t, flow, df, pv: p });
  }
  const last = (cf[N - 1] || 0) * k;
  const tv = (g != null && r > g) ? last * (1 + g) / (r - g) : null;
  const dfN = N ? 1 / Math.pow(1 + r, N) : 0;
  const pvTV = tv != null ? tv * dfN : 0;
  return { years, sumPV: pv, tv, dfN, pvTV, viu: pv + pvTV, tvValid: tv != null };
}
/* f monotone on [lo, hi]; returns x with f(x) = 0, or null when no root in the interval */
function bisect(f, lo, hi, iters = 80) {
  let flo = f(lo), fhi = f(hi);
  if (flo == null || fhi == null || isNaN(flo) || isNaN(fhi)) return null;
  if (Math.abs(flo) < 1e-9) return lo; if (Math.abs(fhi) < 1e-9) return hi;
  if ((flo > 0) === (fhi > 0)) return null;
  for (let i = 0; i < iters; i++) { const mid = (lo + hi) / 2, fm = f(mid); if ((fm > 0) === (flo > 0)) { lo = mid; flo = fm; } else hi = mid; }
  return (lo + hi) / 2;
}

function compute(recs, cfg, eng) {
  const ye = eng.yearEndDate;
  const pm = eng.materiality?.pm || 0, trivial = eng.materiality?.trivial || 0;
  const tol = Number(cfg.castTol) || 0.01;
  const testMonths = Number(cfg.annualTestMonths) || 12;

  /* ---- IMP-01 register ------------------------------------------------- */
  for (const r of recs) {
    r.__displayKey = r.cgu || ('row ' + r.__srcRow);
    r.__key = ckey(r.cgu);
    r.__carryingAudit = r2(ASSET_CLASSES.reduce((s, c) => s + (r[c.key] || 0), 0));
    r.__castDiff = r.carrying != null ? r2(r.carrying - r.__carryingAudit) : null;
    r.__carrying = r.carrying != null ? r.carrying : r.__carryingAudit;
    r.__hasGoodwill = (r.goodwill || 0) > 0.005;
    r.__hasIndefinite = (r.intang_indef || 0) > 0.005;
    r.__annualRequired = r.__hasGoodwill || r.__hasIndefinite;
    r.__clientTestedAnnually = /^\s*y/i.test(String(r.tested_annually || ''));
    r.__monthsSinceTest = r.last_tested && ye ? monthsBetween(r.last_tested, ye) : null;
    r.__testOverdue = r.__annualRequired && (r.__monthsSinceTest == null || r.__monthsSinceTest > testMonths);
    r.__annualGap = r.__annualRequired && (!r.__clientTestedAnnually || r.__testOverdue);
    r.__raBasis = txt(cfg, 'raBasis', r.__key);
    r.__raClient = inp(cfg, 'raAmount', r.__key);
    r.__pyCarrying = r.py_carrying != null ? r.py_carrying : inp(cfg, 'pyCarrying', r.__key);
    r.__pyChange = r.__pyCarrying != null ? r2(r.__carrying - r.__pyCarrying) : null;
    r.__pyChangePct = r.__pyCarrying ? r2(r.__pyChange / Math.abs(r.__pyCarrying) * 100) : null;
  }
  const live = recs.filter(r => !r.__excluded);
  const totals = { count: live.length, carrying: r2(live.reduce((s, r) => s + (r.__carrying || 0), 0)), goodwill: r2(live.reduce((s, r) => s + (r.goodwill || 0), 0)),
    indefinite: r2(live.reduce((s, r) => s + (r.intang_indef || 0), 0)), annualRequired: live.filter(r => r.__annualRequired).length, annualGaps: live.filter(r => r.__annualGap).length,
    castBreaks: live.filter(r => r.__castDiff != null && Math.abs(r.__castDiff) > tol).length };
  for (const c of ASSET_CLASSES) totals[c.key] = r2(live.reduce((s, r) => s + (r[c.key] || 0), 0));
  const cguNames = live.map(r => r.cgu).filter(Boolean);

  /* ---- IMP-02 indicators ----------------------------------------------- */
  const indicators = INDICATORS.map(it => {
    const present = txt(cfg, 'indPresent', it.id), ra = txt(cfg, 'indRA', it.id), cgu = txt(cfg, 'indCgu', it.id);
    return { ...it, present, cgu, commentary: txt(cfg, 'indComment', it.id), evidence: txt(cfg, 'indEvidence', it.id), ra,
      gap: present === 'Y' && /^n/i.test(ra), unanswered: !present };
  });
  const indSummary = { present: indicators.filter(i => i.present === 'Y').length, gaps: indicators.filter(i => i.gap), unanswered: indicators.filter(i => i.unanswered).length,
    cgusAffected: [...new Set(indicators.filter(i => i.present === 'Y' && i.cgu).map(i => i.cgu))] };

  /* ---- IMP-03 value in use --------------------------------------------- */
  let model = live.find(r => r.cgu === cfg.viuCgu) || null;
  if (!model && live.length) model = live.slice().sort((a, b) => (b.goodwill || 0) - (a.goodwill || 0) || (b.__carrying || 0) - (a.__carrying || 0))[0];
  const N = Math.max(1, Math.min(MAXY, Math.round(Number(cfg.viuYears) || 5)));
  const rate = num(cfg.viuRate), growth = num(cfg.viuGrowth), bench = num(cfg.viuBenchmark);
  const r = rate != null ? rate / 100 : null, g = growth != null ? growth / 100 : null;
  const cf = Array.from({ length: N }, (_, i) => inp(cfg, 'cf', 'y' + (i + 1)));
  const cfEntered = cf.filter(v => v != null).length;
  const ready = model && r != null && cfEntered > 0;
  const carrying = model ? model.__carrying : null;
  const V = ready ? viuOf(cf.map(v => v || 0), r, g) : null;
  const years = Array.from({ length: N }, (_, i) => {
    const t = i + 1, y = V ? V.years[i] : null;
    const clientDF = inp(cfg, 'clientDF', 'y' + t), clientPV = inp(cfg, 'clientPV', 'y' + t);
    const prev = i > 0 ? cf[i - 1] : null;
    return { t, key:'y' + t, cf: cf[i], df: y ? r4(y.df) : null, pv: y ? r2(y.pv) : null, clientDF, clientPV, pvDiff: y && clientPV != null ? r2(clientPV - y.pv) : null,
      growthYoY: (prev && cf[i] != null) ? r2((cf[i] - prev) / Math.abs(prev) * 100) : null };
  });
  const clientTVpv = inp(cfg, 'clientPV', 'tv'), clientVIU = num(cfg.clientVIU);
  const growthProfile = years.map(y => y.growthYoY).filter(v => v != null);
  const increasingGrowth = growthProfile.length >= 2 && growthProfile.every((v, i, a) => i === 0 || v > a[i - 1] + 0.05);
  const viu = {
    model, cgu: model ? model.cgu : '', carrying, N, rate, growth, bench, r, g, cf, cfEntered, ready, years,
    rateBasis: cfg.viuRateBasis || '', postTax: /post/i.test(cfg.viuRateBasis || ''),
    sumPV: V ? r2(V.sumPV) : null, tv: V ? r2(V.tv) : null, dfN: V ? r4(V.dfN) : null, pvTV: V ? r2(V.pvTV) : null, tvValid: V ? V.tvValid : null,
    viu: V ? r2(V.viu) : null, clientTVpv, clientVIU, clientTV: num(cfg.clientTV),
    tvDiff: V && clientTVpv != null ? r2(clientTVpv - V.pvTV) : null, viuDiff: V && clientVIU != null ? r2(clientVIU - V.viu) : null,
    headroom: V && carrying != null ? r2(V.viu - carrying) : null, clientHeadroom: clientVIU != null && carrying != null ? r2(clientVIU - carrying) : null,
    headroomPct: V && carrying ? r2((V.viu - carrying) / Math.abs(carrying) * 100) : null,
    impairment: V && carrying != null ? r2(Math.max(0, carrying - V.viu)) : null,
    overFive: N > 5, yearsJustified: !!String(cfg.viuYearsJustification || '').trim(), growthJustified: !!String(cfg.viuGrowthJustification || '').trim(),
    growthAboveBench: growth != null && bench != null && growth > bench + 1e-9, increasingGrowth,
    decl: { tax: cfg.declTax || '', financing: cfg.declFinancing || '', expansion: cfg.declExpansion || '', risk: cfg.declRisk || '' },
    flags: []
  };
  if (viu.overFive && !viu.yearsJustified) viu.flags.push('EX-IMP-02');
  if ((viu.growthAboveBench && !viu.growthJustified) || viu.increasingGrowth) viu.flags.push('EX-IMP-03');
  if (viu.postTax) viu.flags.push('EX-IMP-04');
  if (viu.decl.tax === 'Y') viu.flags.push('EX-IMP-05');
  if (viu.decl.financing === 'Y') viu.flags.push('EX-IMP-06');
  if (viu.decl.expansion === 'Y') viu.flags.push('EX-IMP-07');
  if (viu.decl.risk === 'Y') viu.flags.push('EX-IMP-08');

  /* ---- IMP-06 sensitivity / break-even --------------------------------- */
  const rpRate = num(cfg.rpRateBps) ?? 100, rpGrowth = num(cfg.rpGrowthBps) ?? 100, rpCash = num(cfg.rpCashPct) ?? 10;
  const sens = { ready: !!(V && carrying != null), prepared: cfg.sensPrepared || '', disclosed: cfg.sensDisclosed || '', rpRate, rpGrowth, rpCash, items: [], required: false };
  if (sens.ready) {
    const flows = cf.map(v => v || 0);
    const gg = g != null ? g : -1;
    const fRate = x => viuOf(flows, x, g, {}).viu - carrying;
    const beRate = bisect(fRate, Math.max(gg + 1e-6, 1e-6), 5);
    const beRateBps = beRate != null ? (beRate - r) * 10000 : null;
    let beGrowth = null, beGrowthBps = null;
    if (g != null) { const fG = x => viuOf(flows, r, x).viu - carrying; beGrowth = bisect(fG, -0.99, r - 1e-6); beGrowthBps = beGrowth != null ? (beGrowth - g) * 10000 : null; }
    const fCash = x => viuOf(flows, r, g, { cfMult: x }).viu - carrying;
    const beCash = bisect(fCash, 0, 10);
    const beCashPct = beCash != null ? (beCash - 1) * 100 : null;
    const headroomPositive = V.viu > carrying;
    sens.items = [
      { key:'rate', assumption:'Pre-tax discount rate', value: r * 100, unit:'%', breakEven: beRate != null ? beRate * 100 : null, change: beRateBps != null ? r2(beRateBps) : null, changeUnit:'bps', band: rpRate, bandUnit:'bps',
        within: headroomPositive && beRateBps != null && beRateBps > 0 && beRateBps <= rpRate, direction:'increase' },
      { key:'growth', assumption:'Terminal growth rate', value: g != null ? g * 100 : null, unit:'%', breakEven: beGrowth != null ? beGrowth * 100 : null, change: beGrowthBps != null ? r2(beGrowthBps) : null, changeUnit:'bps', band: rpGrowth, bandUnit:'bps',
        within: headroomPositive && beGrowthBps != null && beGrowthBps < 0 && -beGrowthBps <= rpGrowth, direction:'decrease' },
      { key:'cash', assumption:'Forecast cash flows (all years)', value: 100, unit:'% of forecast', breakEven: beCash != null ? r2(beCash * 100) : null, change: beCashPct != null ? r2(beCashPct) : null, changeUnit:'%', band: rpCash, bandUnit:'%',
        within: headroomPositive && beCashPct != null && beCashPct < 0 && -beCashPct <= rpCash, direction:'decrease' },
    ].map(it => ({ ...it, breakEvenRaw: it.breakEven, breakEven: it.breakEven != null ? r4(it.breakEven) : null, valueR: it.value != null ? r4(it.value) : null }));
    sens.headroomPositive = headroomPositive;
    sens.required = headroomPositive && sens.items.some(it => it.within);
    /* the impairment a reasonably possible change would produce */
    sens.impairmentAtBand = headroomPositive ? r2(Math.max(0, carrying - viuOf(flows, r + rpRate / 10000, g).viu)) : null;
    sens.gap = sens.required && sens.disclosed !== 'Y';
  }

  /* ---- IMP-07 allocation ----------------------------------------------- */
  const override = num(cfg.allocLoss);
  const recoverable = V ? (model && /fair value|higher/i.test(model.__raBasis) && model.__raClient != null ? Math.max(V.viu, model.__raClient) : V.viu) : null;
  const lossComputed = recoverable != null && carrying != null ? r2(Math.max(0, carrying - recoverable)) : null;
  const loss = override != null ? override : (lossComputed || 0);
  const alloc = { model, loss, lossComputed, override, recoverable: recoverable != null ? r2(recoverable) : null, rows: [], unallocated: 0, goodwillFirst: 0 };
  if (model) {
    const classes = ASSET_CLASSES.map(c => ({ key:c.key, label:c.label, carrying: Math.max(0, model[c.key] || 0), floor: inp(cfg, 'floor', c.key) }));
    let R = loss;
    const gw = classes.find(c => c.key === 'goodwill');
    gw.alloc = Math.min(R, gw.carrying); R = r2(R - gw.alloc); alloc.goodwillFirst = r2(gw.alloc);
    const others = classes.filter(c => c.key !== 'goodwill');
    others.forEach(c => { c.alloc = 0; c.cap = Math.max(0, c.carrying - Math.max(0, c.floor ?? 0)); });
    for (let iter = 0; iter < 20 && R > 0.005; iter++) {
      const eligible = others.filter(c => c.alloc < c.cap - 0.005 && c.carrying > 0);
      const base = eligible.reduce((s, c) => s + c.carrying, 0);
      if (!eligible.length || base <= 0) break;
      let placed = 0;
      for (const c of eligible) { const share = Math.min(R * c.carrying / base, c.cap - c.alloc); c.alloc += share; placed += share; }
      R = r2(R - placed);
      if (placed < 0.005) break;
    }
    alloc.unallocated = r2(Math.max(0, R));
    alloc.rows = classes.map(c => ({ ...c, alloc: r2(c.alloc), after: r2(c.carrying - c.alloc), floorApplied: c.floor != null && c.alloc >= (c.cap ?? Infinity) - 0.005 && c.cap < c.carrying }));
    alloc.allocated = r2(loss - alloc.unallocated);
  }

  /* ---- IMP-10 specialist ----------------------------------------------- */
  const specialist = { cy: cfg.preparedByCY || '', py: cfg.preparedByPY || '', vsPY: cfg.assumptionsVsPY || '',
    movedInternal: /external/i.test(cfg.preparedByPY || '') && /internal/i.test(cfg.preparedByCY || ''),
    checklist: SPECIALIST_ITEMS.map(it => ({ ...it, answer: (cfg.impSpecialist || {})[it.id]?.answer || '', comment: (cfg.impSpecialist || {})[it.id]?.comment || '' })) };
  specialist.ex11 = specialist.movedInternal && (/unchanged|more favourable/i.test(specialist.vsPY) || !specialist.vsPY);

  /* ---- lead ------------------------------------------------------------ */
  const lead = live.map(x => {
    const isModel = model && x === model;
    const ra = isModel && V ? V.viu : (x.__raClient != null ? x.__raClient : null);
    return { r:x, cgu:x.cgu, carrying:x.__carrying, raBasis: isModel ? 'Value in use (IMP-03)' : (x.__raBasis || 'Not estimated'), raClient: x.__raClient, raAudit: isModel && V ? r2(V.viu) : null,
      recoverable: ra != null ? r2(ra) : null, headroom: ra != null ? r2(ra - x.__carrying) : null, impairmentAudit: ra != null ? r2(Math.max(0, x.__carrying - ra)) : null,
      indicatorPresent: indicators.some(i => i.present === 'Y' && (i.cgu === x.cgu || /^all/i.test(i.cgu))),
      indicatorNoRA: indicators.some(i => i.gap && (i.cgu === x.cgu || /^all/i.test(i.cgu))), isModel };
  });
  const impairmentAudit = r2(lead.reduce((s, l) => s + (l.impairmentAudit || 0), 0));
  const impClient = num(cfg.impairmentPerClient), impPY = num(cfg.impairmentPY);
  const leadTotals = { carrying: totals.carrying, recoverable: r2(lead.reduce((s, l) => s + (l.recoverable || 0), 0)), impairmentAudit, impClient, impPY,
    impDiff: impClient != null ? r2(impClient - impairmentAudit) : null, notEstimated: lead.filter(l => l.recoverable == null).length,
    indicatorNoRA: lead.filter(l => l.indicatorNoRA).length };

  return { totals, cguNames, indicators, indSummary, viu, sens, alloc, specialist, lead, leadTotals, pm, trivial, tol, testMonths };
}

/* ============================================================== TESTS */
const fmt = n => n == null ? 'n/a' : Number(n).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const pctS = v => v == null ? 'n/a' : Number(v).toFixed(2) + '%';
const viuHit = (d, id) => d.viu.flags.includes(id);
const tests = [
  { id:'EX-IMP-01', label:'CGU carrying goodwill or indefinite-life intangibles not tested annually', basis:'IMP-01', severity:'above-pm',
    fn:(r, cfg, eng, d) => r.__annualGap && { expected:'Tested annually (FRS 36 paras 10, 90)', actual: r.tested_annually || 'not stated', difference: r2((r.goodwill || 0) + (r.intang_indef || 0)), cell:r['__cell_tested_annually'],
      detail:`Goodwill ${fmt(r.goodwill)} and indefinite-life intangibles ${fmt(r.intang_indef)} allocated; client answer "${r.tested_annually || ''}"; last tested ${r.last_tested ? Core.fmtDate(r.last_tested) : 'not recorded'}${r.__monthsSinceTest != null ? ' (' + r.__monthsSinceTest + ' months before the reporting date)' : ''}. An annual test is required irrespective of indicators.` } },
  { id:'EX-IMP-02', scope:'population', label:'Forecast period exceeds five years without justification', basis:'IMP-03', severity:'above-trivial',
    fn:(recs, cfg, eng, d) => viuHit(d, 'EX-IMP-02') && { key:d.viu.cgu, expected:'≤ 5 years or justified (para 33(b))', actual:`${d.viu.N} years`, detail:'Projections beyond five years are permitted only where management can demonstrate its ability to forecast accurately over the longer period; no justification is recorded.' } },
  { id:'EX-IMP-03', scope:'population', label:'Terminal growth rate exceeds the long-term average', basis:'IMP-03', severity:'above-trivial',
    fn:(recs, cfg, eng, d) => viuHit(d, 'EX-IMP-03') && { key:d.viu.cgu, expected: d.viu.bench != null ? pctS(d.viu.bench) : 'stable or declining growth', actual: pctS(d.viu.growth), difference: d.viu.tv,
      detail:`${d.viu.growthAboveBench ? `Terminal growth ${pctS(d.viu.growth)} exceeds the long-term average ${pctS(d.viu.bench)} with no justification recorded (para 33(c)); terminal value ${fmt(d.viu.pvTV)} is ${d.viu.viu ? Math.round(d.viu.pvTV / d.viu.viu * 100) : ''}% of value in use.` : ''}${d.viu.increasingGrowth ? ' Year-on-year growth in the forecast increases each year, contrary to the steady or declining profile para 33(c) requires.' : ''}` } },
  { id:'EX-IMP-04', scope:'population', label:'Post-tax discount rate applied', basis:'IMP-03', severity:'above-trivial',
    fn:(recs, cfg, eng, d) => viuHit(d, 'EX-IMP-04') && { key:d.viu.cgu, expected:'Pre-tax rate (para 55)', actual:d.viu.rateBasis,
      detail: d.viu.decl.tax === 'Y' ? 'A post-tax rate has been used with post-tax cash flows. FRS 36 para 55 requires value in use on a pre-tax basis; a post-tax computation gives the same answer only in restricted cases (BCZ85) and the pre-tax rate must be disclosed (para 134(d)(v)).' : 'A post-tax discount rate has been applied to pre-tax cash flows, overstating value in use (paras 50, 55).' } },
  { id:'EX-IMP-05', scope:'population', label:'Income tax cash flows included in value in use', basis:'IMP-03', severity:'above-trivial',
    fn:(recs, cfg, eng, d) => viuHit(d, 'EX-IMP-05') && { key:d.viu.cgu, expected:'Excluded (para 50(b))', actual:'Included', detail:'Management declares that income tax payments are included in the forecast cash flows. Value in use excludes income tax receipts and payments.' } },
  { id:'EX-IMP-06', scope:'population', label:'Financing cash flows included in value in use', basis:'IMP-03', severity:'above-trivial',
    fn:(recs, cfg, eng, d) => viuHit(d, 'EX-IMP-06') && { key:d.viu.cgu, expected:'Excluded (para 50(a))', actual:'Included', detail:'Management declares that interest on borrowings is included in the forecast cash flows. Financing flows are reflected in the discount rate and must not be deducted from the cash flows.' } },
  { id:'EX-IMP-07', scope:'population', label:'Cash flows from uncommitted expansion included', basis:'IMP-03', severity:'above-trivial',
    fn:(recs, cfg, eng, d) => viuHit(d, 'EX-IMP-07') && { key:d.viu.cgu, expected:'Asset in its current condition (paras 33(b), 44)', actual:'Uncommitted expansion included', detail:'Cash flows expected from a future restructuring or from improving or enhancing the asset\'s performance are excluded until the entity is committed.' } },
  { id:'EX-IMP-08', scope:'population', label:'Risk reflected in both cash flows and the discount rate', basis:'IMP-03', severity:'above-trivial',
    fn:(recs, cfg, eng, d) => viuHit(d, 'EX-IMP-08') && { key:d.viu.cgu, expected:'Risk in cash flows or rate, not both (paras 55-56)', actual:'Both', detail:'A risk premium has been added to the cash flows and to the discount rate; the effect of the risk is double counted.' } },
  { id:'EX-IMP-09', scope:'population', label:'Indicator present with no recoverable amount estimated', basis:'IMP-02', severity:'above-pm',
    fn:(recs, cfg, eng, d) => d.indSummary.gaps.map(i => ({ key: i.cgu || ('Indicator ' + i.id), expected:'Recoverable amount estimated (para 9)', actual:`Indicator ${i.id} present; recoverable amount ${i.ra || 'not estimated'}`,
      detail:`${i.text}. Management commentary: ${i.commentary || 'none'}. Evidence: ${i.evidence || 'none'}.` })) },
  { id:'EX-IMP-10', scope:'population', label:'Sensitivity disclosure required but not made', basis:'IMP-06', severity:'above-pm',
    fn:(recs, cfg, eng, d) => d.sens.gap && { key:d.viu.cgu, expected:'Para 134(f) disclosure', actual: d.sens.disclosed === 'N' ? 'Not disclosed' : 'Disclosure not confirmed', difference:d.sens.impairmentAtBand,
      detail:`Headroom ${fmt(d.viu.headroom)} (${pctS(d.viu.headroomPct)} of carrying amount) is eliminated by ${d.sens.items.filter(i => i.within).map(i => `a ${Math.abs(i.change)} ${i.changeUnit} ${i.direction} in the ${i.assumption.toLowerCase()} (break-even ${i.breakEven}${i.unit.startsWith('%') ? '%' : ''})`).join(' or ')}, within the reasonably possible band. Management ${d.sens.prepared === 'Y' ? 'prepared' : 'did not prepare'} a sensitivity analysis. A ${d.sens.rpRate} bps rise in the rate would produce an impairment of ${fmt(d.sens.impairmentAtBand)}.` } },
  { id:'EX-IMP-11', scope:'population', label:'Valuation moved from external specialist to internal preparation', basis:'IMP-10', severity:'above-trivial',
    fn:(recs, cfg, eng, d) => d.specialist.ex11 && { key:d.viu.cgu, expected:'Assumptions re-examined on the change of preparer', actual:`Prior year: ${d.specialist.py}; current year: ${d.specialist.cy}; assumptions ${d.specialist.vsPY || 'not compared'}`,
      detail:'The model was prepared by an external valuation specialist in the prior year and by the client\'s own team this year with assumptions unchanged or more favourable. Evaluate the reason for the change and the competence and objectivity of the preparer (ISA 500 para 8, ISA 540).' } },
  { id:'EX-IMP-20', label:'Carrying amount build-up does not cast', basis:'IMP-01',
    fn:(r, cfg) => r.__castDiff != null && Math.abs(r.__castDiff) > (Number(cfg.castTol) || 0.01) && { expected:r.__carryingAudit, actual:r.carrying, difference:r.__castDiff, cell:r['__cell_carrying'] } },
  { id:'EX-IMP-21', scope:'population', label:'Value in use per client differs from the recalculation', basis:'IMP-03',
    fn:(recs, cfg, eng, d) => d.viu.viuDiff != null && Math.abs(d.viu.viuDiff) > Math.max(d.tol, 1) && { key:d.viu.cgu, expected:d.viu.viu, actual:d.viu.clientVIU, difference:d.viu.viuDiff, detail:'The client\'s value in use does not agree to the recalculation from the forecast cash flows, discount rate and terminal growth entered.' } },
  { id:'EX-IMP-22', scope:'population', label:'Impairment recognised differs from the impairment per audit', basis:'IMP',
    fn:(recs, cfg, eng, d) => d.leadTotals.impDiff != null && Math.abs(d.leadTotals.impDiff) > d.tol && { key:'Impairment charge', expected:d.leadTotals.impairmentAudit, actual:d.leadTotals.impClient, difference:d.leadTotals.impDiff } },
];

/* ============================================================== PAGES */
const pages = [
  { id:'source',  ref:'IMP.0',  title:'Source data',     kind:'source' },
  { id:'cleaned', ref:'IMP.0a', title:'Cleaned listing', kind:'cleaned' },
  { id:'mapping', ref:'IMP.0b', title:'Column mapping',  kind:'mapping' },

  { id:'lead', ref:'IMP', title:'Lead schedule',
    objective:'To summarise, by cash-generating unit, the carrying amount, the recoverable amount and basis, the headroom or impairment per audit, and to agree the impairment charge recognised to the amount per audit.',
    procedures:['Listed every CGU with its carrying amount per the register and the recoverable amount per the client, taking value in use from the recalculated model on IMP-03 where the CGU is modelled.',
                'Computed headroom and impairment per audit for each CGU and compared the total to the impairment charge recognised by the client.'],
    flag:(st, d) => (d.leadTotals.impDiff != null && Math.abs(d.leadTotals.impDiff) > d.tol) || d.leadTotals.indicatorNoRA > 0,
    render(st, ctx) {
      const d = ctx.d, money = ctx.money;
      const rows = d.lead.map(l => ({ __key:l.r.__key, cgu:l.cgu, carrying:l.carrying, basis:l.raBasis, raClient:l.raClient, raAudit:l.raAudit, recoverable:l.recoverable, headroom:l.headroom, impairment:l.impairmentAudit,
        indicator: l.indicatorPresent ? 'Indicator present' : '', status: l.indicatorNoRA ? 'Indicator, no estimate' : l.recoverable == null ? 'Not estimated' : l.impairmentAudit > 0 ? 'Impaired' : 'Headroom', __cls: l.indicatorNoRA ? 'flag' : '' }));
      return [
        { type:'controls', items:[
          { key:'impairmentPerClient', label:'Impairment charge recognised per client (current year)', kind:'number' },
          { key:'impairmentPY', label:'Impairment charge — prior year', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Cash-generating units', value:d.totals.count }, { label:'Carrying amount', value:money(d.totals.carrying) },
          { label:'Goodwill allocated', value:money(d.totals.goodwill) },
          { label:'Impairment per audit', value:money(d.leadTotals.impairmentAudit), cls: d.leadTotals.impairmentAudit > 0 ? 'warn' : 'ok' },
          { label:'Impairment per client', value: d.leadTotals.impClient == null ? '— enter —' : money(d.leadTotals.impClient) },
          { label:'Difference', value: d.leadTotals.impDiff == null ? '' : money(d.leadTotals.impDiff), cls: d.leadTotals.impDiff == null ? '' : Math.abs(d.leadTotals.impDiff) > d.tol ? 'bad' : 'ok' },
          { label:'Prior year charge', value: d.leadTotals.impPY == null ? '' : money(d.leadTotals.impPY) },
          { label:'CGUs with an indicator and no estimate', value:d.leadTotals.indicatorNoRA, cls: d.leadTotals.indicatorNoRA ? 'bad' : 'ok' } ] },
        { type:'table', title:'Recoverable amount by CGU', columns:[
          { key:'cgu', label:'Cash-generating unit', emphasis:true }, { key:'carrying', label:'Carrying amount', type:'num', sum:true },
          { key:'basis', label:'Basis of recoverable amount' },
          { key:'raBasis', label:'Basis per client', input:'select', options:RA_BASES },
          { key:'raAmount', label:'Recoverable amount per client', input:'number' },
          { key:'raAudit', label:'Value in use per audit (IMP-03)', type:'num' },
          { key:'recoverable', label:'Recoverable amount used', type:'num', sum:true },
          { key:'headroom', label:'Headroom / (shortfall)', type:'num', flag:v => v != null && v < 0 },
          { key:'impairment', label:'Impairment per audit', type:'num', sum:true },
          { key:'indicator', label:'IMP-02', type:'chip', chipClass:() => 'warn' },
          { key:'status', label:'Status', type:'chip', chipClass:v => /no estimate/.test(v) ? 'bad' : v === 'Impaired' ? 'bad' : v === 'Headroom' ? 'ok' : 'grey' },
          { key:'leadComment', label:'Comment', input:'text', wide:true } ], rows,
          footnote:'For the modelled CGU the recoverable amount is the recalculated value in use from IMP-03 (or fair value less costs of disposal where the client\'s basis is higher). For other CGUs enter the client\'s figure; a CGU for which IMP-02 records an indicator present and recoverable amount not estimated is painted red.' }
      ];
    } },

  { id:'register', ref:'IMP-01', title:'CGU register and asset allocation',
    objective:'To identify the cash-generating units to which assets and goodwill are allocated, to prove the carrying amount of each from its components, and to confirm that every CGU carrying goodwill or indefinite-life intangibles is tested annually (FRS 36 paras 6, 66-73, 80, 90).',
    procedures:['Recomputed the carrying amount of every CGU as the sum of PPE, right-of-use assets, intangibles, goodwill and other net assets allocated, and compared it to the carrying amount per the register.',
                'Derived whether an annual test is required from the presence of goodwill or indefinite-life intangibles and compared the requirement to the client\'s answer and the date of the last test.',
                'Compared the carrying amount to the prior year to detect a change in CGU composition.'],
    flag:(st, d) => d.totals.annualGaps > 0 || d.totals.castBreaks > 0,
    render(st, ctx) {
      const d = ctx.d, money = ctx.money;
      const rows = ctx.recs.map(r => ({ __rec:r, cgu:r.cgu, segment:r.segment, basis:r.basis, ppe:r.ppe, rou:r.rou, fin:r.intang_finite, ind:r.intang_indef, gw:r.goodwill, other:r.other, audit:r.__carryingAudit, client:r.carrying, cast:r.__castDiff,
        required: r.__annualRequired ? 'Annual test required' : 'Indicator-based', answer:r.tested_annually, last:r.last_tested, months:r.__monthsSinceTest,
        status: r.__annualGap ? 'Not tested annually' : r.__annualRequired ? 'Tested' : '', __cls: r.__annualGap ? 'flag' : '' }));
      const pyRows = ctx.recs.map(r => ({ __rec:r, cgu:r.cgu, carrying:r.__carrying, py:r.__pyCarrying, change:r.__pyChange, changePct: r.__pyChangePct != null ? r.__pyChangePct / 100 : null }));
      return [
        { type:'controls', items:[
          { key:'castTol', label:'Casting tolerance', kind:'number' },
          { key:'annualTestMonths', label:'Annual test: maximum months since the last test', kind:'number' } ] },
        { type:'stats', items:[
          { label:'CGUs', value:d.totals.count }, { label:'Carrying amount', value:money(d.totals.carrying) },
          { label:'Build-ups that cast', value:`${d.totals.count - d.totals.castBreaks} of ${d.totals.count}`, cls: d.totals.castBreaks ? 'bad' : 'ok' },
          { label:'CGUs requiring an annual test', value:d.totals.annualRequired },
          { label:'Not tested annually', value:d.totals.annualGaps, cls: d.totals.annualGaps ? 'bad' : 'ok' },
          { label:'Goodwill', value:money(d.totals.goodwill) }, { label:'Indefinite-life intangibles', value:money(d.totals.indefinite) } ] },
        { type:'table', title:'Carrying amount build-up by CGU', columns:[
          { key:'cgu', label:'CGU', emphasis:true }, { key:'segment', label:'Segment' }, { key:'basis', label:'Basis of identification', wrap:true },
          { key:'ppe', label:'PPE', type:'num', sum:true }, { key:'rou', label:'ROU assets', type:'num', sum:true },
          { key:'fin', label:'Intangibles (finite)', type:'num', sum:true }, { key:'ind', label:'Intangibles (indefinite)', type:'num', sum:true },
          { key:'gw', label:'Goodwill', type:'num', sum:true }, { key:'other', label:'Other net assets', type:'num', sum:true },
          { key:'audit', label:'Carrying per audit', type:'num', sum:true, formula:(row, C) => `SUM(${C(3)}${row}:${C(8)}${row})` },
          { key:'client', label:'Carrying per register', type:'num', sum:true },
          { key:'cast', label:'Difference', type:'num', flag:v => v != null && Math.abs(v) > d.tol },
          { key:'segmentOK', label:'Not larger than a segment (Y/N)', input:'select', options:yn } ], rows,
          footnote:'Goodwill is allocated to the lowest level at which it is monitored and not larger than an operating segment (para 80). Differences beyond the tolerance are raised as EX-IMP-20.' },
        { type:'table', title:'Annual test requirement (paras 10, 90)', columns:[
          { key:'cgu', label:'CGU', emphasis:true }, { key:'gw', label:'Goodwill', type:'num' }, { key:'ind', label:'Indefinite-life intangibles', type:'num' },
          { key:'required', label:'Requirement per audit', type:'chip', chipClass:v => /required/.test(v) ? 'info' : 'grey' },
          { key:'answer', label:'Tested annually per client' }, { key:'last', label:'Date last tested', type:'date' }, { key:'months', label:'Months before year end', type:'int' },
          { key:'status', label:'Conclusion', type:'chip', chipClass:v => /Not tested/.test(v) ? 'bad' : v ? 'ok' : 'grey' },
          { key:'testRef', label:'Test working paper reference', input:'text' },
          { key:'comment', label:'Comment', input:'text', wide:true } ], rows,
          footnote:`A CGU carrying goodwill or an indefinite-life intangible must be tested annually irrespective of indicators; the test is overdue when the last test is more than ${d.testMonths} months before the reporting date. Gaps are raised as EX-IMP-01.` },
        { type:'table', title:'Change in CGU composition against prior year (para 73, 130(d))', columns:[
          { key:'cgu', label:'CGU', emphasis:true }, { key:'carrying', label:'Carrying amount', type:'num', sum:true },
          { key:'pyCarrying', label:'Prior year carrying amount (enter if not in register)', input:'number' },
          { key:'py', label:'Prior year used', type:'num', sum:true }, { key:'change', label:'Change', type:'num', sum:true }, { key:'changePct', label:'Change %', type:'pct' },
          { key:'compChanged', label:'Composition changed (Y/N)', input:'select', options:yn },
          { key:'compReason', label:'Reason documented', input:'text', wide:true } ], rows:pyRows }
      ];
    } },

  { id:'indicators', ref:'IMP-02', title:'Indicator assessment (FRS 36 paras 9-14)',
    objective:'To assess at the reporting date whether there is any indication that an asset or CGU may be impaired (para 9), using the minimum indicators in paras 12 and 14, and to confirm that recoverable amount has been estimated wherever an indication exists.',
    procedures:['Completed the para 12/14 indicator checklist with management, recording the commentary, the evidence obtained and the CGU affected for each indicator.',
                'For every indicator marked present, confirmed whether recoverable amount was estimated and raised the CGU where it was not.'],
    flag:(st, d) => d.indSummary.gaps.length > 0,
    render(st, ctx) {
      const d = ctx.d;
      const opts = ['All CGUs', ...d.cguNames];
      const rows = d.indicators.map(i => ({ __key:i.id, id:i.id, src:i.src, text:i.text, status: i.gap ? 'Present — no estimate' : i.present === 'Y' ? 'Present' : i.present === 'N' ? 'Not present' : 'Not answered', __cls: i.gap ? 'flag' : i.present === 'Y' ? 'yes' : '' }));
      return [
        { type:'stats', items:[
          { label:'Indicators present', value:`${d.indSummary.present} of ${d.indicators.length}`, cls: d.indSummary.present ? 'warn' : 'ok' },
          { label:'Present with no recoverable amount estimated', value:d.indSummary.gaps.length, cls: d.indSummary.gaps.length ? 'bad' : 'ok' },
          { label:'Not yet answered', value:d.indSummary.unanswered, cls: d.indSummary.unanswered ? 'warn' : 'ok' },
          { label:'CGUs affected', value:d.indSummary.cgusAffected.join('; ') || '—' } ] },
        { type:'table', title:'Minimum indicators — FRS 36 paras 12 and 14', columns:[
          { key:'id', label:'Para' }, { key:'src', label:'Source', type:'chip', chipClass:v => v === 'External' ? 'info' : 'grey' }, { key:'text', label:'Indicator', wrap:true },
          { key:'indPresent', label:'Present (Y/N)', input:'select', options:yn },
          { key:'indCgu', label:'CGU affected', input:'select', options:opts },
          { key:'indComment', label:'Management commentary', input:'text', wide:true },
          { key:'indEvidence', label:'Evidence obtained', input:'text', wide:true },
          { key:'indRA', label:'Recoverable amount estimated?', input:'select', options:['Yes', 'No', 'n/a'] },
          { key:'status', label:'Conclusion', type:'chip', chipClass:v => /no estimate/.test(v) ? 'bad' : v === 'Present' ? 'warn' : v === 'Not present' ? 'ok' : 'grey' } ], rows,
          footnote:'The para 12 list is a minimum, not exhaustive (para 13). An indicator marked present with recoverable amount not estimated is raised as EX-IMP-09 against the CGU affected.' },
        { type:'note', html:'Where any indicator is present for a CGU that is not the one modelled on IMP-03, enter the client\'s recoverable amount for that CGU on the lead schedule or record why none was estimated.' }
      ];
    } },

  { id:'viu', ref:'IMP-03', title:'Value in use model',
    objective:'To recalculate the value in use of the CGU from the forecast cash flows, discount rate and terminal growth in management\'s model (FRS 36 paras 30-57), to compare it to the client\'s figure, and to test the model against the requirements on forecast period, growth, tax, financing, uncommitted expansion and risk.',
    procedures:['Transcribed the forecast cash flows by year, the discount rate and its basis, the terminal growth rate and the long-term average growth rate from the client\'s model.',
                'Recomputed the discount factor and present value of each year, the terminal value and its present value, and value in use; compared each to the client\'s figures.',
                'Obtained management\'s declarations on the inclusion of tax, financing and uncommitted expansion cash flows and on the treatment of risk, and tested the forecast period and terminal growth against paras 33 and 55.'],
    flag:(st, d) => d.viu.flags.length > 0 || (d.viu.headroom != null && d.viu.headroom < 0),
    render(st, ctx) {
      const d = ctx.d, V = d.viu, money = ctx.money;
      const rows = V.years.map(y => ({ __key:y.key, year:`Year ${y.t}`, growth: y.growthYoY != null ? y.growthYoY / 100 : null, df:y.df, pv:y.pv, pvDiff:y.pvDiff }));
      rows.push({ __key:'tv', year:`Terminal value (year ${V.N} × (1+g) ÷ (r−g))`, tvAmt:V.tv, df:V.dfN, pv:V.pvTV, pvDiff:V.tvDiff, __cls:'em' });
      const declRows = [
        { key:'declTax', label:'Cash flows include income tax payments or receipts?', para:'50(b)', ex:'EX-IMP-05' },
        { key:'declFinancing', label:'Cash flows include interest or other financing flows?', para:'50(a)', ex:'EX-IMP-06' },
        { key:'declExpansion', label:'Cash flows include uncommitted expansion, restructuring or enhancement?', para:'33(b), 44', ex:'EX-IMP-07' },
        { key:'declRisk', label:'Risk premium added to the cash flows as well as to the discount rate?', para:'55-56', ex:'EX-IMP-08' } ];
      return [
        { type:'controls', items:[
          { key:'viuCgu', label:'CGU modelled', kind:'select', options: d.cguNames.map(n => [n, n]), help: V.model ? `Carrying amount ${money(V.carrying)}` : 'Upload the CGU register first.' },
          { key:'viuYears', label:'Forecast period (years)', kind:'number', help:'More than five years requires justification (para 33(b)).' },
          { key:'viuYearsJustification', label:'Justification for a period beyond five years', kind:'text' },
          { key:'viuRate', label:'Discount rate applied (%)', kind:'number' },
          { key:'viuRateBasis', label:'Basis of discount rate', kind:'select', options:[['', '—'], ['Pre-tax', 'Pre-tax'], ['Post-tax', 'Post-tax (WACC)']] },
          { key:'viuGrowth', label:'Terminal growth rate (%)', kind:'number' },
          { key:'viuBenchmark', label:'Long-term average growth rate — industry / economy (%)', kind:'number', help:'Auditor\'s benchmark; terminal growth above it needs justification (para 33(c)).' },
          { key:'viuGrowthJustification', label:'Justification for terminal growth above the benchmark', kind:'text' },
          { key:'clientVIU', label:'Value in use per client', kind:'number' } ] },
        { type:'table', title:`Forecast cash flows and present values — ${V.cgu || 'CGU'}`, columns:[
          { key:'year', label:'Year', emphasis:true },
          { key:'cf', label:'Forecast net cash flow (per client)', input:'number' },
          { key:'growth', label:'Growth on prior year', type:'pct' },
          { key:'tvAmt', label:'Terminal value', type:'num' },
          { key:'df', label:'Discount factor per audit', type:'num', dp:4 },
          { key:'clientDF', label:'Discount factor per client', input:'number' },
          { key:'pv', label:'Present value per audit', type:'num', sum:true },
          { key:'clientPV', label:'Present value per client', input:'number' },
          { key:'pvDiff', label:'Difference', type:'num', sum:true, flag:v => v != null && Math.abs(v) > 1 } ], rows,
          footnote:`Discount factor = 1 ÷ (1 + r)^t with r = ${V.rate != null ? V.rate + '%' : '—'}; terminal value = year ${V.N} cash flow × (1 + g) ÷ (r − g) with g = ${V.growth != null ? V.growth + '%' : '—'}, discounted at the year ${V.N} factor.` },
        { type:'stats', items:[
          { label:'Sum of discounted cash flows', value: money(V.sumPV) }, { label:'Present value of terminal value', value: money(V.pvTV), cls: V.viu && V.pvTV / V.viu > 0.7 ? 'warn' : '' },
          { label:'Value in use per audit', value: money(V.viu) }, { label:'Value in use per client', value: V.clientVIU == null ? '— enter —' : money(V.clientVIU) },
          { label:'Difference', value: V.viuDiff == null ? '' : money(V.viuDiff), cls: V.viuDiff == null ? '' : Math.abs(V.viuDiff) > 1 ? 'bad' : 'ok' },
          { label:'Carrying amount of CGU', value: money(V.carrying) },
          { label:'Headroom / (impairment) per audit', value: money(V.headroom), cls: V.headroom == null ? '' : V.headroom < 0 ? 'bad' : V.headroomPct < 10 ? 'warn' : 'ok' },
          { label:'Headroom as % of carrying amount', value: V.headroomPct == null ? '' : V.headroomPct.toFixed(1) + '%' },
          { label:'Terminal value valid (r > g)', value: V.tvValid == null ? '' : V.tvValid ? 'Yes' : 'No — rate not above growth', cls: V.tvValid === false ? 'bad' : '' } ] },
        { type:'table', title:'Declarations by management (FRS 36 paras 33, 44, 50, 55)', columns:[
          { key:'label', label:'Declaration', wrap:true }, { key:'para', label:'Para' },
          { key:'answer', label:'Answer', type:'chip', chipClass:v => v === 'Y' ? 'bad' : v === 'N' ? 'ok' : 'grey' },
          { key:'ex', label:'Exception if Yes' },
          { key:'declEvidence', label:'Evidence / management explanation', input:'text', wide:true } ],
          rows: declRows.map(x => ({ __key:x.key, label:x.label, para:x.para, ex:x.ex, answer: ctx.cfg[x.key] || '' })),
          footnote:'Answer the declarations with the controls below; an answer of Yes raises the exception shown.' },
        { type:'controls', items:[
          { key:'declTax', label:'Income tax cash flows included?', kind:'select', options:[['', '—'], ['Y', 'Yes'], ['N', 'No']] },
          { key:'declFinancing', label:'Financing cash flows included?', kind:'select', options:[['', '—'], ['Y', 'Yes'], ['N', 'No']] },
          { key:'declExpansion', label:'Uncommitted expansion included?', kind:'select', options:[['', '—'], ['Y', 'Yes'], ['N', 'No']] },
          { key:'declRisk', label:'Risk in both cash flows and rate?', kind:'select', options:[['', '—'], ['Y', 'Yes'], ['N', 'No']] } ] },
        { type:'stats', items:[
          { label:'Forecast period', value:`${V.N} years${V.overFive ? (V.yearsJustified ? ' — justified' : ' — no justification (EX-IMP-02)') : ''}`, cls: V.overFive && !V.yearsJustified ? 'bad' : 'ok' },
          { label:'Terminal growth vs benchmark', value: V.growth == null ? '' : `${V.growth}% vs ${V.bench != null ? V.bench + '%' : 'no benchmark'}${V.growthAboveBench ? (V.growthJustified ? ' — justified' : ' — exceeds (EX-IMP-03)') : ''}`, cls: V.growthAboveBench && !V.growthJustified ? 'bad' : 'ok' },
          { label:'Growth profile', value: V.increasingGrowth ? 'Increasing year on year (EX-IMP-03)' : 'Steady or declining', cls: V.increasingGrowth ? 'bad' : 'ok' },
          { label:'Discount rate basis', value: V.rateBasis ? `${V.rateBasis}${V.postTax ? ' (EX-IMP-04)' : ''}` : 'Not stated', cls: V.postTax ? 'bad' : V.rateBasis ? 'ok' : 'warn' },
          { label:'Model exceptions', value: V.flags.join(', ') || 'None', cls: V.flags.length ? 'bad' : 'ok' } ] }
      ];
    } },

  { id:'sensitivity', ref:'IMP-06', title:'Sensitivity and break-even analysis',
    objective:'To determine, for each key assumption, the value at which recoverable amount equals carrying amount and the change required to reach it, and to conclude whether a reasonably possible change would eliminate the headroom such that FRS 36 para 134(f) disclosure is required.',
    procedures:['Solved by bisection for the discount rate, the terminal growth rate and the uniform change in forecast cash flows at which value in use equals the carrying amount, holding the other assumptions at management\'s values.',
                'Compared the change required to the reasonably possible band set by the auditor for each assumption and concluded whether para 134(f) disclosure is required.',
                'Recorded whether management prepared a sensitivity analysis and whether the financial statements disclose it.'],
    flag:(st, d) => d.sens.gap || (d.sens.ready && !d.sens.headroomPositive),
    render(st, ctx) {
      const d = ctx.d, S = d.sens, V = d.viu, money = ctx.money;
      const rows = S.items.map(it => ({ __key:it.key, assumption:it.assumption, value: it.value != null ? `${r4(it.value)}${it.unit.startsWith('%') ? '%' : ''}` : '', breakEven: it.breakEven != null ? `${it.breakEven}${it.unit.startsWith('%') ? '%' : ''}` : 'Not reached', change: it.change != null ? `${it.change > 0 ? '+' : ''}${it.change} ${it.changeUnit}` : '', band:`${it.band} ${it.bandUnit}`,
        conclusion: it.within ? 'Within band — disclose' : it.breakEven == null ? 'No break-even' : 'Outside band', __cls: it.within ? 'flag' : '' }));
      return [
        { type:'controls', items:[
          { key:'rpRateBps', label:'Reasonably possible change — discount rate (bps)', kind:'number' },
          { key:'rpGrowthBps', label:'Reasonably possible change — terminal growth (bps)', kind:'number' },
          { key:'rpCashPct', label:'Reasonably possible change — forecast cash flows (%)', kind:'number' },
          { key:'sensPrepared', label:'Sensitivity analysis prepared by management?', kind:'select', options:[['', '—'], ['Y', 'Yes'], ['N', 'No']] },
          { key:'sensDisclosed', label:'Para 134(f) sensitivity disclosed in the financial statements?', kind:'select', options:[['', '—'], ['Y', 'Yes'], ['N', 'No']] } ] },
        S.ready ? { type:'stats', items:[
          { label:'Value in use per audit', value:money(V.viu) }, { label:'Carrying amount', value:money(V.carrying) },
          { label:'Headroom', value:`${money(V.headroom)} (${V.headroomPct?.toFixed(1)}%)`, cls: V.headroom < 0 ? 'bad' : V.headroomPct < 10 ? 'warn' : 'ok' },
          { label:'Para 134(f) disclosure', value: !S.headroomPositive ? 'Impairment — para 130 disclosures apply' : S.required ? 'Required — a reasonably possible change eliminates headroom' : 'Not required on the bands set', cls: S.required ? 'bad' : 'ok' },
          { label:`Impairment if the rate rises ${S.rpRate} bps`, value:money(S.impairmentAtBand), cls: S.impairmentAtBand > 0 ? 'bad' : 'ok' },
          { label:'Disclosed', value: S.disclosed === 'Y' ? 'Yes' : S.disclosed === 'N' ? 'No' : 'Not confirmed', cls: S.gap ? 'bad' : 'ok' } ] }
          : { type:'note', tone:'warn', html:'Complete the value in use model on IMP-03 (discount rate and at least one year of cash flows) to run the break-even analysis.' },
        { type:'table', title:'Break-even value of each key assumption (para 134(f)(i)-(iii))', columns:[
          { key:'assumption', label:'Key assumption', emphasis:true }, { key:'value', label:'Value assigned by management' },
          { key:'breakEven', label:'Value at which headroom is nil' }, { key:'change', label:'Change required' }, { key:'band', label:'Reasonably possible band' },
          { key:'conclusion', label:'Conclusion', type:'chip', chipClass:v => /disclose/.test(v) ? 'bad' : /Outside/.test(v) ? 'ok' : 'grey' },
          { key:'mgmtSens', label:'Management\'s sensitivity (if any)', input:'text', wide:true },
          { key:'sensComment', label:'Basis for the band / comment', input:'text', wide:true } ], rows,
          emptyText:'No model to analyse yet.',
          footnote:'Each break-even is solved by bisection on value in use = carrying amount, holding the other assumptions at management\'s values. Where the change required is within the band, para 134(f) requires disclosure of the headroom, the value assigned and the change required; absence of disclosure is raised as EX-IMP-10.' }
      ];
    } },

  { id:'allocation', ref:'IMP-07', title:'Allocation of impairment loss',
    objective:'To allocate an impairment loss for the CGU first to goodwill and then pro rata to the other assets on the basis of their carrying amounts, without reducing any asset below the highest of its fair value less costs of disposal, its value in use and zero (FRS 36 paras 104-105).',
    procedures:['Took the impairment loss from the recalculated value in use (or the amount entered) and allocated it to goodwill first.',
                'Allocated the remainder pro rata to the other assets of the CGU by carrying amount, applied the para 105 floor entered for each asset class and redistributed any excess to the remaining assets.',
                'Reported any amount that could not be allocated for consideration as a liability only where another Standard requires it (para 108).'],
    flag:(st, d) => d.alloc.loss > 0,
    render(st, ctx) {
      const d = ctx.d, A = d.alloc, money = ctx.money;
      const rows = A.rows.map(c => ({ __key:c.key, label:c.label, carrying:c.carrying, floor:c.floor, alloc:c.alloc, after:c.after, note: c.key === 'goodwill' ? 'First (para 104(a))' : c.floorApplied ? 'Floor applied (para 105)' : c.alloc > 0 ? 'Pro rata (para 104(b))' : '' }));
      return [
        { type:'controls', items:[{ key:'allocLoss', label:'Impairment loss to allocate (blank = per the IMP-03 recalculation)', kind:'number' }] },
        { type:'stats', items:[
          { label:'CGU', value:A.model ? A.model.cgu : '' }, { label:'Carrying amount', value:money(A.model ? A.model.__carrying : null) },
          { label:'Recoverable amount per audit', value:money(A.recoverable) },
          { label:'Impairment loss per audit', value:money(A.lossComputed), cls: A.lossComputed > 0 ? 'bad' : 'ok' },
          { label:'Loss allocated', value:money(A.loss), cls: A.override != null ? 'warn' : '' },
          { label:'Allocated to goodwill first', value:money(A.goodwillFirst) },
          { label:'Unallocated (para 105 floors)', value:money(A.unallocated), cls: A.unallocated > 0 ? 'bad' : 'ok' } ] },
        { type:'table', title:'Allocation by asset class', columns:[
          { key:'label', label:'Asset class', emphasis:true }, { key:'carrying', label:'Carrying amount before', type:'num', sum:true },
          { key:'floor', label:'Floor — higher of FVLCD, VIU and nil (para 105)', input:'number' },
          { key:'alloc', label:'Impairment allocated', type:'num', sum:true }, { key:'after', label:'Carrying amount after', type:'num', sum:true, formula:(row, C) => `${C(1)}${row}-${C(3)}${row}` },
          { key:'note', label:'Basis' },
          { key:'allocComment', label:'Comment / journal reference', input:'text', wide:true } ], rows,
          emptyText:'Upload the CGU register to allocate.',
          footnote:'An impairment loss recognised for goodwill is not reversed in a later period (para 124). The allocation feeds the PPE, intangibles and goodwill files.' },
        A.loss > 0 ? { type:'note', tone:'bad', html:`An impairment loss of <b>${money(A.loss)}</b> arises for ${Core.escapeHTML(A.model?.cgu || 'the CGU')}. Propose the adjustment and consider the para 126 and 130 disclosures.` } : { type:'note', html:'No impairment loss arises on the recalculated model; the allocation is shown for completeness and updates if the model or the loss entered changes.' }
      ];
    } },

  { id:'specialist', ref:'IMP-10', title:'Use of a specialist',
    objective:'To evaluate the competence, capability and objectivity of the preparer of the valuation, whether the work was performed to the requirements of FRS 36, and — where preparation has moved from an external specialist to the client\'s own team — whether the assumptions were re-examined (ISA 500 para 8, ISA 620).',
    procedures:['Recorded who prepared the value in use model in the current and prior year and how the current assumptions compare to the prior year model.',
                'Completed the specialist evaluation checklist and documented the evidence supporting each conclusion.'],
    flag:(st, d) => d.specialist.ex11,
    render(st, ctx) {
      const S = ctx.d.specialist;
      return [
        { type:'controls', items:[
          { key:'preparedByCY', label:'Model prepared by — current year', kind:'select', options:[['', '—'], ...PREPARERS.map(x => [x, x])] },
          { key:'preparedByPY', label:'Model prepared by — prior year', kind:'select', options:[['', '—'], ...PREPARERS.map(x => [x, x])] },
          { key:'assumptionsVsPY', label:'Current year assumptions compared to the prior year model', kind:'select', options:[['', '—'], ...VS_PY.map(x => [x, x])] } ] },
        { type:'stats', items:[
          { label:'Preparer — current year', value:S.cy || 'Not recorded' }, { label:'Preparer — prior year', value:S.py || 'Not recorded' },
          { label:'Moved from external to internal', value: S.movedInternal ? 'Yes' : 'No', cls: S.movedInternal ? 'warn' : 'ok' },
          { label:'Assumptions vs prior year', value:S.vsPY || 'Not compared', cls: S.ex11 ? 'bad' : 'ok' },
          { label:'EX-IMP-11', value: S.ex11 ? 'Raised — assumptions unchanged or more favourable after the change of preparer' : 'Not raised', cls: S.ex11 ? 'bad' : 'ok' } ] },
        { type:'checklist', store:'impSpecialist', items: SPECIALIST_ITEMS.map(it => ({ id:it.id, text:it.text })), answers:['Y', 'N', 'n/a'] },
        { type:'note', html:'The regulator\'s finding: after an external specialist valued the assets at acquisition, the client\'s own team took over the projections with more aggressive assumptions and the same discount rate. Compare the current assumptions line by line to the specialist\'s prior year model and record the comparison on IMP-03.' }
      ];
    } },

  { id:'conclusion', ref:'IMP.9', title:'Exceptions & conclusion', kind:'conclusion' }
];

function suggestConclusion(st, ctx) {
  const d = ctx.d, V = d.viu, ex = (st.exceptions || []).filter(e => e.disposition === 'open');
  return [
    `${d.totals.count} cash-generating units with a total carrying amount of ${ctx.money(d.totals.carrying)} were identified from the client's register${d.totals.castBreaks ? `; ${d.totals.castBreaks} build-up(s) did not cast` : ' and each build-up casts'}.`,
    d.totals.annualGaps ? `${d.totals.annualGaps} CGU(s) carrying goodwill or indefinite-life intangibles were not tested annually.` : '',
    d.indSummary.gaps.length ? `${d.indSummary.gaps.length} indicator(s) are present with no recoverable amount estimated.` : '',
    V.ready ? `Value in use of ${V.cgu} was recalculated at ${ctx.money(V.viu)} against a carrying amount of ${ctx.money(V.carrying)}, giving ${V.headroom >= 0 ? 'headroom' : 'an impairment'} of ${ctx.money(Math.abs(V.headroom))}${V.flags.length ? `; the model breaches ${V.flags.join(', ')}` : ''}.` : 'The value in use model has not yet been recomputed.',
    d.sens.required ? `A reasonably possible change in a key assumption eliminates the headroom; para 134(f) disclosure is ${d.sens.disclosed === 'Y' ? 'made' : 'required and not yet confirmed'}.` : '',
    ex.length ? `${ex.length} exception(s) remain open in the register.` : 'No exceptions remain open.',
    'Subject to the above, the carrying amounts of non-financial assets do not exceed their recoverable amounts and the FRS 36 disclosures are adequate.'
  ].filter(Boolean).join(' ');
}

return {
  code:'IMP', name:'Impairment (FRS 36)', group:'Assets', accepts:'.xlsx,.xlsm,.csv',
  blurb:'The impairment file: CGU register, indicator checklist, recalculated value in use, break-even sensitivity, loss allocation and specialist evaluation — from the client\'s CGU register.',
  objective:'To obtain sufficient appropriate audit evidence that non-financial assets are carried at no more than their recoverable amount, that impairment testing complies with FRS 36, and that the disclosures required by paras 126-137 are made.',
  fields, tests, compute, pages, defaultConfig, STANDARD_COLUMNS, INDICATORS, SPECIALIST_ITEMS, ASSET_CLASSES,
  procedures: pages.flatMap(p => p.procedures || []),
  columns: STANDARD_COLUMNS, suggestConclusion, viuOf, bisect
};
})();

Modules.register(IMPModule);
