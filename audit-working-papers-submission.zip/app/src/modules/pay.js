/* ==========================================================================
   pay.js -- Payroll as an auditor actually works it.

   One uploaded payroll listing (one line per employee per month) feeds:
     U5    Lead schedule                      U5.4  Joiners and leavers
     U5.1  Headcount reconciliation           U5.5  Duplicate and unnamed employees
     U5.2  Month-on-month movement            U5.6  Test of details
     U5.3  Statutory contribution recalc.     U5.7  Key management remuneration
   ========================================================================== */

const PAYModule = (() => {
const r2 = n => n == null || isNaN(n) ? null : Math.round(n * 100) / 100;
const num = v => (v === '' || v == null || isNaN(Number(v))) ? null : Number(v);
const inp = (cfg, key, k) => num(cfg[key + ':' + k]);
const txt = (cfg, key, k) => { const v = cfg[key + ':' + k]; return v == null ? '' : String(v); };
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const monthStart = d => d ? new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1)) : null;
const monthKey = d => d ? `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}` : '';
const monthLabel = k => k ? `${MONTHS[Number(k.slice(5, 7)) - 1]} ${k.slice(0, 4)}` : '';
const addMonths = (d, n) => new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + n, 1));

/* Seeded PRNG so a random sample is reproducible from its recorded seed. */
function mulberry32(seed) {
  let a = (seed >>> 0) || 1;
  return () => {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function sampleN(items, n, seed) {
  const rnd = mulberry32(seed);
  const pool = items.slice();
  const out = [];
  while (out.length < n && pool.length) out.push(pool.splice(Math.floor(rnd() * pool.length), 1)[0]);
  return out;
}

/* Statutory regimes. Rates in %, wage floor / cap per month. Blank overrides on the page fall back to these. */
const REGIMES = {
  sg:     { label:'Singapore CPF (employer 17% / employee 20%, ordinary wage ceiling)', er:17, ee:20, cap:6800, floor:0,
            note:'Rates for employees aged 55 and below; ordinary wage ceiling 6,800 (2024) rising to 7,400 (2025) and 8,000 (2026). Adjust the cap and rates for the year audited and for older employees.' },
  prc:    { label:'PRC social insurance + housing fund (employer 40.7% / employee 17.5%, base floor and ceiling)', er:40.7, ee:17.5, cap:19800, floor:3740,
            note:'Employer: pension 16%, medical 9%, unemployment 0.5%, work injury 0.4%, maternity 0.8%, housing fund 7%. Employee: pension 8%, medical 2%, unemployment 0.5%, housing fund 7%. Floor and ceiling vary by city and reset each social-insurance year — enter the local figures.' },
  my:     { label:'Malaysia EPF (employer 13% / employee 11%)', er:13, ee:11, cap:null, floor:0,
            note:'Employer 13% where wages are 5,000 or below, otherwise 12%. SOCSO and EIS are excluded from this recomputation.' },
  custom: { label:'Custom — enter rates, floor and cap', er:null, ee:null, cap:null, floor:0, note:'Enter the employer and employee rates, the wage floor and the wage cap that apply.' },
  none:   { label:'No statutory recomputation', er:0, ee:0, cap:null, floor:0, note:'Statutory contributions are not recomputed.' }
};

/* ---------------------------------------------------------------- fields */
const fields = [
  { key:'employee_id', label:'Employee ID', role:'key', type:'text', required:true, dupKey:true,
    synonyms:['Employee ID','Emp No','Staff No','Employee Code','ID','Emp ID','Staff ID','Employee No','Employee Number','Personnel No','Staff Code','Emp Code','Payroll No','工号','员工编号'] },
  { key:'employee_name', label:'Employee name', type:'text', required:true,
    synonyms:['Employee Name','Name','Staff Name','Employee','Full Name','Employee Full Name','Staff','Name of Employee','姓名','员工姓名'] },
  { key:'department', label:'Department', type:'text', role:'category', satisfiedByGroup:true,
    synonyms:['Department','Dept','Cost Centre','Cost Center','Division','Section','Unit','Team','Business Unit','部门'] },
  { key:'designation', label:'Designation', type:'text',
    synonyms:['Designation','Position','Title','Job Title','Grade','Role','职位','岗位'] },
  { key:'pay_month', label:'Pay month', type:'date', required:true, dupKey:true,
    synonyms:['Month','Pay Month','Period','Pay Period','Payroll Month','Salary Month','Month Ended','Payroll Period','Pay Date','Payment Month','Payroll Date','月份','工资月份'] },
  { key:'basic', label:'Basic salary', type:'number', required:true,
    synonyms:['Gross Pay','Basic Salary','Gross','Total Gross','Salary','Basic','Basic Pay','Monthly Salary','Base Salary','Gross Salary','Ordinary Wages','Basic Wage','应发工资','基本工资'] },
  { key:'allowances', label:'Allowances', type:'number',
    synonyms:['Allowances','Allowance','Other Allowances','Fixed Allowance','Transport Allowance','Overtime','OT','Allowances & OT','Total Allowances','津贴','补贴'] },
  { key:'bonus', label:'Bonus', type:'number',
    synonyms:['Bonus','AWS / Bonus','Incentive','Variable Pay','AWS','Commission','Additional Wages','Performance Bonus','Variable Bonus','奖金'] },
  { key:'employer_stat', label:'Employer statutory contribution', type:'number',
    synonyms:['Employer CPF','CPF (Er)','Employer Contribution','CPF Employer','Statutory - Er','Employer SSI','SSI - Employer Portion','Employer EPF','EPF Employer','Employer Pension','Employer Social Insurance','单位社保','单位缴纳'] },
  { key:'employee_stat', label:'Employee statutory contribution', type:'number',
    synonyms:['Employee CPF','CPF (Ee)','Employee Contribution','CPF Employee','Statutory - Ee','Employee SSI','SSI - Employee Portion','Employee EPF','EPF Employee','Employee Social Insurance','个人社保','个人缴纳'] },
  { key:'hf_er', label:'Employer housing fund', type:'number',
    synonyms:['Employer Housing Fund','Housing Fund - Employer','HF Employer','住房公积金 Housing Fund','住房公积金','单位公积金'] },
  { key:'hf_ee', label:'Employee housing fund', type:'number',
    synonyms:['Employee Housing Fund','Housing Fund - Employee','HF Employee','个人公积金'] },
  { key:'stat_base', label:'Contribution base per client', type:'number',
    synonyms:['SSI Base','Contribution Base','Social Insurance Base','缴费基数 Contribution Base','缴费基数','CPF Wages','Wages Subject to CPF'] },
  { key:'tax', label:'Tax withheld', type:'number',
    synonyms:['Individual Income Tax','IIT','Individual Tax','Tax Withheld','PAYE','Withholding Tax','Income Tax','个人所得税 IIT','个人所得税'] },
  { key:'net', label:'Net pay', type:'number',
    synonyms:['Net Pay','Net','Take Home','Net Salary','Net Amount','Amount Paid','Bank Transfer','实发工资 Take Home','实发工资'] },
  { key:'join_date', label:'Date joined', type:'date',
    synonyms:['Date Joined','Join Date','Hire Date','Commencement Date','Date of Joining','Employment Start','Start of Employment','Date of Hire','入职日期'] },
  { key:'leave_date', label:'Date left', type:'date',
    synonyms:['Date Left','Resignation Date','Last Day','Termination Date','Leaving Date','Date of Leaving','Exit Date','Cessation Date','Last Working Day','离职日期'] }
];

const STANDARD_COLUMNS = [
  { key:'employee_id', label:'ID' }, { key:'employee_name', label:'Employee' }, { key:'department', label:'Department' },
  { key:'__month', label:'Pay month', type:'date' }, { key:'basic', label:'Basic', type:'num', edit:true },
  { key:'allowances', label:'Allowances', type:'num', edit:true }, { key:'bonus', label:'Bonus', type:'num', edit:true },
  { key:'__gross', label:'Gross', type:'num', emphasis:true }, { key:'employer_stat', label:'Employer statutory', type:'num', edit:true },
  { key:'employee_stat', label:'Employee statutory', type:'num', edit:true }, { key:'net', label:'Net pay', type:'num', edit:true },
  { key:'join_date', label:'Joined', type:'date', edit:true }, { key:'leave_date', label:'Left', type:'date', edit:true }
];

const defaultConfig = () => ({
  castTol: 0.01,
  salaryIs: 'basic',              // 'basic' = salary column excludes allowances and bonus; 'gross' = it already includes them
  monthOrder: 'auto',             // pay-month column read as dd/mm vs mm/dd: auto | keep | swap
  pnlBasic: '', pnlAllowances: '', pnlBonus: '', pnlEmployer: '',   // (legacy single inputs, superseded by the table inputs)
  momThreshold: 20,               // % month-on-month movement in basic salary flagged
  regime: 'sg', erRate: '', eeRate: '', wageCap: '', wageFloor: '',   // blank = regime default
  statBase: 'basic',              // wages subject to contribution: basic | basic_allow | gross
  statTol: 1,                     // rounding tolerance per line
  todThreshold: '', todSampleN: 10, todSeed: 20250228,
  netTol: 1
});

/* ============================================================ COMPUTE */
function regimeOf(cfg) {
  const R = REGIMES[cfg.regime] || REGIMES.sg;
  const pick = (v, d) => (v === '' || v == null || isNaN(Number(v))) ? d : Number(v);
  return { key: cfg.regime in REGIMES ? cfg.regime : 'sg', label: R.label, note: R.note,
    er: pick(cfg.erRate, R.er), ee: pick(cfg.eeRate, R.ee), cap: pick(cfg.wageCap, R.cap), floor: pick(cfg.wageFloor, R.floor) };
}

function compute(recs, cfg, eng) {
  const ye = eng.yearEndDate, fys = eng.fyStartDate;
  const pm = eng.materiality?.pm || 0, trivial = eng.materiality?.trivial || 0;
  const tol = Number(cfg.castTol) || 0.01;
  const live = recs.filter(r => !r.__excluded);

  /* ---- pay month: settle dd/mm vs mm/dd where every day is the 1st ------ */
  const swapOf = d => (d && d.getUTCDate() <= 12) ? new Date(Date.UTC(d.getUTCFullYear(), d.getUTCDate() - 1, d.getUTCMonth() + 1)) : null;
  let keepFirst = 0, swapFirst = 0;
  for (const r of live) { if (!r.pay_month) continue; if (r.pay_month.getUTCDate() === 1) keepFirst++; const s = swapOf(r.pay_month); if (s && s.getUTCDate() === 1) swapFirst++; }
  const swapping = cfg.monthOrder === 'swap' || (cfg.monthOrder !== 'keep' && swapFirst > keepFirst);
  for (const r of recs) {
    const m = r.pay_month ? (swapping ? (swapOf(r.pay_month) || r.pay_month) : r.pay_month) : null;
    r.__month = monthStart(m); r.__monthKey = monthKey(r.__month);
    r.__gross = cfg.salaryIs === 'gross' ? r2(r.basic || 0) : r2((r.basic || 0) + (r.allowances || 0) + (r.bonus || 0));
    r.__basicOnly = cfg.salaryIs === 'gross' ? r2((r.basic || 0) - (r.allowances || 0) - (r.bonus || 0)) : r2(r.basic || 0);
    r.__erRecorded = r2((r.employer_stat || 0) + (r.hf_er || 0));
    r.__eeRecorded = r2((r.employee_stat || 0) + (r.hf_ee || 0));
    r.__empKey = Core.keyify(r.employee_id || '') || ('name:' + Core.keyify(r.employee_name || '')) || ('row' + r.__srcRow);
    r.__displayKey = `${r.employee_id || '(no ID)'} · ${r.employee_name || '(no name)'} · ${monthLabel(r.__monthKey) || 'undated'}`;
    r.__dupLine = r.__flags.find(x => x.rule === 'DQ-10') || null;
  }

  /* ---- statutory recomputation per line -------------------------------- */
  const R = regimeOf(cfg);
  const baseOf = r => cfg.statBase === 'gross' ? r.__gross : cfg.statBase === 'basic_allow' ? r2(r.__basicOnly + (r.allowances || 0)) : r.__basicOnly;
  const statTol = Number(cfg.statTol) >= 0 ? Number(cfg.statTol) : 1;
  for (const r of live) {
    const w = Math.max(0, baseOf(r) || 0);
    let base = w;
    if (R.floor > 0 && w > 0 && w < R.floor) base = R.floor;
    if (R.cap != null && R.cap > 0) base = Math.min(base, R.cap);
    r.__statWages = r2(w); r.__statBase = r2(base);
    r.__erExpected = R.er != null && R.key !== 'none' ? r2(base * R.er / 100) : null;
    r.__eeExpected = R.ee != null && R.key !== 'none' ? r2(base * R.ee / 100) : null;
    r.__erDiff = r.__erExpected != null ? r2(r.__erRecorded - r.__erExpected) : null;
    r.__eeDiff = r.__eeExpected != null ? r2(r.__eeRecorded - r.__eeExpected) : null;
    r.__erNil = r.__erExpected > 0 && Math.abs(r.__erRecorded) < 0.005;
    r.__baseBelowFloor = r.stat_base != null && R.floor > 0 && w >= R.floor && r.stat_base < R.floor - 0.005;
    r.__baseDiff = r.stat_base != null ? r2(r.stat_base - base) : null;
    const deductions = r.__eeRecorded + (r.tax || 0);
    r.__netExpected = r2(r.__gross - deductions);
    r.__netDiff = r.net != null ? r2(r.net - r.__netExpected) : null;
  }

  /* ---- months and employees ------------------------------------------- */
  const monthKeys = [...new Set(live.map(r => r.__monthKey).filter(Boolean))].sort();
  const firstKey = monthKeys[0] || null, lastKey = monthKeys[monthKeys.length - 1] || null;
  const firstMonth = firstKey ? new Date(Date.UTC(+firstKey.slice(0, 4), +firstKey.slice(5, 7) - 1, 1)) : null;
  const lastMonth = lastKey ? new Date(Date.UTC(+lastKey.slice(0, 4), +lastKey.slice(5, 7) - 1, 1)) : null;
  const periodEnd = lastMonth ? new Date(addMonths(lastMonth, 1).getTime() - 86400000) : null;

  const emps = {};
  for (const r of live) {
    const e = emps[r.__empKey] || (emps[r.__empKey] = { key:r.__empKey, id:r.employee_id || '', name:r.employee_name || '', dept:r.department || '', designation:r.designation || '',
      join:null, leave:null, lines:0, months:new Set(), basic:0, allowances:0, bonus:0, gross:0, er:0, ee:0, net:0, erExpected:0, eeExpected:0, recs:[], ids:new Set(), names:new Set() });
    e.lines++; e.recs.push(r);
    if (r.__monthKey) e.months.add(r.__monthKey);
    if (!e.name && r.employee_name) e.name = r.employee_name;
    if (!e.dept && r.department) e.dept = r.department;
    if (r.employee_id) e.ids.add(r.employee_id);
    if (r.employee_name) e.names.add(Core.keyify(r.employee_name));
    if (r.join_date && (!e.join || r.join_date < e.join)) e.join = r.join_date;
    if (r.leave_date && (!e.leave || r.leave_date > e.leave)) e.leave = r.leave_date;
    e.basic += r.__basicOnly || 0; e.allowances += r.allowances || 0; e.bonus += r.bonus || 0; e.gross += r.__gross || 0;
    e.er += r.__erRecorded || 0; e.ee += r.__eeRecorded || 0; e.net += r.net || 0; e.erExpected += r.__erExpected || 0; e.eeExpected += r.__eeExpected || 0;
  }
  for (const r of live) {
    const e = emps[r.__empKey];
    r.__afterLeave = !!(e.leave && r.__month && r.__month > monthStart(e.leave));
    r.__beforeJoin = !!(e.join && r.__month && r.__month < monthStart(e.join));
  }
  const momThr = Number(cfg.momThreshold) > 0 ? Number(cfg.momThreshold) : 20;
  const employees = Object.values(emps).map(e => {
    e.recs.sort((a, b) => (a.__month || 0) - (b.__month || 0));
    e.monthList = [...e.months].sort(); e.firstPaid = e.monthList[0] || null; e.lastPaid = e.monthList[e.monthList.length - 1] || null;
    e.paidFirst = e.firstPaid === firstKey; e.paidLast = e.lastPaid === lastKey;
    /* month-on-month in basic */
    let prev = null; e.maxMom = null; e.minBasic = null; e.maxBasic = null; e.momFlags = 0;
    for (const r of e.recs) {
      r.__momPct = null;
      const b = r.__basicOnly || 0;
      if (e.minBasic == null || b < e.minBasic) e.minBasic = b;
      if (e.maxBasic == null || b > e.maxBasic) e.maxBasic = b;
      if (prev && prev.__monthKey !== r.__monthKey && Math.abs(prev.__basicOnly || 0) > 0.005) {
        r.__momPct = r2((b - prev.__basicOnly) / Math.abs(prev.__basicOnly) * 100);
        r.__momPrev = prev.__basicOnly; r.__momPrevMonth = prev.__monthKey;
        if (Math.abs(r.__momPct) >= momThr) { e.momFlags++; }
        if (e.maxMom == null || Math.abs(r.__momPct) > Math.abs(e.maxMom)) e.maxMom = r.__momPct;
      }
      if (prev == null || prev.__monthKey !== r.__monthKey) prev = r;
    }
    e.afterLeaveLines = e.recs.filter(r => r.__afterLeave); e.beforeJoinLines = e.recs.filter(r => r.__beforeJoin);
    e.erNil = e.erExpected > 0.005 && Math.abs(e.er) < 0.005;
    e.erDiff = r2(e.er - e.erExpected); e.eeDiff = r2(e.ee - e.eeExpected);
    e.unnamed = !e.name; e.noId = !e.id;
    e.kmp = txt(cfg, 'kmp', e.key) === 'Y'; e.role = txt(cfg, 'kmpRole', e.key);
    e.joinedInPeriod = !!(e.join && firstMonth && periodEnd && e.join >= firstMonth && e.join <= periodEnd);
    e.leftBeforeLast = !!(e.leave && lastMonth && e.leave < lastMonth);
    e.leftInLast = !!(e.leave && lastMonth && periodEnd && e.leave >= lastMonth && e.leave <= periodEnd);
    e.leftInPeriod = e.leftBeforeLast || e.leftInLast;
    for (const k of ['basic', 'allowances', 'bonus', 'gross', 'er', 'ee', 'net', 'erExpected', 'eeExpected']) e[k] = r2(e[k]);
    return e;
  }).sort((a, b) => (a.id || '').localeCompare(b.id || '') || a.name.localeCompare(b.name));

  /* duplicate names across IDs; multiple names under one ID */
  const byName = {};
  for (const e of employees) if (e.name) (byName[Core.keyify(e.name)] = byName[Core.keyify(e.name)] || []).push(e);
  const dupNameGroups = Object.values(byName).filter(g => g.length > 1);
  for (const e of employees) e.dupName = dupNameGroups.some(g => g.includes(e));
  const multiName = employees.filter(e => e.names.size > 1);
  const dupLines = live.filter(r => r.__dupLine);

  /* ---- headcount reconciliation --------------------------------------- */
  const opening = employees.filter(e => e.paidFirst && !(e.join && firstMonth && e.join >= firstMonth));
  const joiners = employees.filter(e => e.joinedInPeriod);
  const leavers = employees.filter(e => e.leftBeforeLast);
  const leavingLast = employees.filter(e => e.leftInLast);
  const closing = employees.filter(e => e.paidLast);
  const expectedClosing = opening.length + joiners.length - leavers.length;
  const headcount = { months: monthKeys, firstKey, lastKey, opening, joiners, leavers, leavingLast, closing, expectedClosing,
    diff: closing.length - expectedClosing,
    joinersByActivity: employees.filter(e => e.firstPaid && e.firstPaid !== firstKey),
    leaversByActivity: employees.filter(e => e.lastPaid && e.lastPaid !== lastKey),
    paidAfterLeaving: employees.filter(e => e.afterLeaveLines.length),
    paidBeforeJoining: employees.filter(e => e.beforeJoinLines.length),
    joinedNeverPaid: [],   // cannot be seen from a paid listing; kept for the auditor's HR-list comparison
    monthly: monthKeys.map(k => { const rs = live.filter(r => r.__monthKey === k); return { key:k, label: monthLabel(k), heads: new Set(rs.map(r => r.__empKey)).size, lines: rs.length,
      basic: r2(rs.reduce((s, r) => s + (r.__basicOnly || 0), 0)), allowances: r2(rs.reduce((s, r) => s + (r.allowances || 0), 0)), bonus: r2(rs.reduce((s, r) => s + (r.bonus || 0), 0)),
      gross: r2(rs.reduce((s, r) => s + (r.__gross || 0), 0)), er: r2(rs.reduce((s, r) => s + (r.__erRecorded || 0), 0)), net: r2(rs.reduce((s, r) => s + (r.net || 0), 0)) }; }) };

  /* ---- lead: cost lines vs TB vs PY ----------------------------------- */
  const sum = f => r2(live.reduce((s, r) => s + (f(r) || 0), 0));
  const totals = { basic: sum(r => r.__basicOnly), allowances: sum(r => r.allowances), bonus: sum(r => r.bonus), gross: sum(r => r.__gross),
    er: sum(r => r.__erRecorded), ee: sum(r => r.__eeRecorded), hf: sum(r => r.hf_er), tax: sum(r => r.tax), net: sum(r => r.net), erExpected: sum(r => r.__erExpected), eeExpected: sum(r => r.__eeExpected) };
  totals.cost = r2(totals.gross + totals.er);
  const LINES = [
    { key:'basic', label:'Basic salary', value: totals.basic }, { key:'allowances', label:'Allowances and overtime', value: totals.allowances },
    { key:'bonus', label:'Bonus and additional wages', value: totals.bonus }, { key:'gross', label:'Gross remuneration', value: totals.gross, sub:true },
    { key:'er', label:'Employer statutory contributions', value: totals.er }, { key:'cost', label:'Total staff cost', value: totals.cost, sub:true }
  ];
  const lead = LINES.map(l => {
    const tb = inp(cfg, 'tb', l.key), py = inp(cfg, 'py', l.key);
    const variance = py != null ? r2(l.value - py) : null;
    return { ...l, tb, py, tbDiff: tb != null ? r2(l.value - tb) : null, variance, variancePct: (variance != null && py) ? r2(variance / Math.abs(py) * 100) : null,
      material: variance != null && Math.abs(variance) > pm };
  });
  const depts = {};
  for (const r of live) { const k = r.department || '(not stated)'; const d = depts[k] || (depts[k] = { dept:k, heads:new Set(), lines:0, gross:0, er:0 }); d.heads.add(r.__empKey); d.lines++; d.gross += r.__gross || 0; d.er += r.__erRecorded || 0; }
  const byDept = Object.values(depts).map(d => ({ dept:d.dept, heads:d.heads.size, lines:d.lines, gross:r2(d.gross), er:r2(d.er), cost:r2(d.gross + d.er), share: totals.cost ? r2((d.gross + d.er) / totals.cost * 100) : 0 })).sort((a, b) => b.cost - a.cost);

  /* ---- statutory summary ---------------------------------------------- */
  const statLines = live.filter(r => r.__erDiff != null);
  const statutory = { regime: R, tol: statTol, lines: statLines.length,
    erRecorded: totals.er, erExpected: totals.erExpected, erDiff: r2(totals.er - totals.erExpected),
    eeRecorded: totals.ee, eeExpected: totals.eeExpected, eeDiff: r2(totals.ee - totals.eeExpected),
    erBreaks: statLines.filter(r => Math.abs(r.__erDiff) > statTol && !r.__erNil), eeBreaks: statLines.filter(r => r.__eeDiff != null && Math.abs(r.__eeDiff) > statTol),
    nilEmployees: employees.filter(e => e.erNil), nilLines: statLines.filter(r => r.__erNil),
    baseBelowFloor: live.filter(r => r.__baseBelowFloor), capped: statLines.filter(r => R.cap != null && r.__statWages > R.cap).length,
    byEmployee: employees.map(e => ({ ...e, __key:e.key })) };

  /* ---- month-on-month ------------------------------------------------- */
  const momLines = live.filter(r => r.__momPct != null && Math.abs(r.__momPct) >= momThr).sort((a, b) => Math.abs(b.__momPct) - Math.abs(a.__momPct));
  const movement = { threshold: momThr, lines: momLines, employees: employees.filter(e => e.momFlags > 0), bonusMonth: headcount.monthly.reduce((b, m) => !b || m.bonus > b.bonus ? m : b, null) };

  /* ---- test of details ------------------------------------------------ */
  const threshold = cfg.todThreshold !== '' && cfg.todThreshold != null ? Number(cfg.todThreshold) : pm;
  const pop = live.filter(r => (r.__gross || 0) > 0.005);
  const key = pop.filter(r => r.__gross >= threshold);
  const residual = pop.filter(r => r.__gross < threshold);
  const nS = Math.min(Number(cfg.todSampleN) || 0, residual.length);
  const sample = sampleN(residual, nS, Number(cfg.todSeed) || 1);
  const selSet = new Set([...key, ...sample].map(r => r.__i));
  for (const r of live) r.__todSelected = selSet.has(r.__i) ? (key.includes(r) ? 'key' : 'sample') : null;
  const selected = [...key, ...sample].sort((a, b) => (a.__empKey.localeCompare(b.__empKey)) || ((a.__month || 0) - (b.__month || 0)));
  const popValue = r2(pop.reduce((s, r) => s + r.__gross, 0)), selValue = r2(selected.reduce((s, r) => s + r.__gross, 0));
  const tod = { threshold, seed: Number(cfg.todSeed) || 1, key, residual, sample, selected, popValue, selValue, coverage: popValue ? r2(selValue / popValue * 100) : 0,
    employeesCovered: new Set(selected.map(r => r.__empKey)).size,
    agreed: selected.filter(r => r.__wp?.tod?.agreed === 'Y').length, notAgreed: selected.filter(r => r.__wp?.tod?.agreed === 'N') };

  /* ---- key management remuneration ------------------------------------ */
  const kmps = employees.filter(e => e.kmp);
  const kmp = { employees: kmps, salary: r2(kmps.reduce((s, e) => s + e.basic + e.allowances, 0)), bonus: r2(kmps.reduce((s, e) => s + e.bonus, 0)),
    er: r2(kmps.reduce((s, e) => s + e.er, 0)), total: r2(kmps.reduce((s, e) => s + e.gross + e.er, 0)), share: totals.cost ? r2(kmps.reduce((s, e) => s + e.gross + e.er, 0) / totals.cost * 100) : 0 };

  const netBreaks = live.filter(r => r.__netDiff != null && Math.abs(r.__netDiff) > (Number(cfg.netTol) >= 0 ? Number(cfg.netTol) : 1));

  return { swapping, monthKeys, firstKey, lastKey, employees, totals, lead, byDept, headcount, statutory, movement, tod, kmp,
    integrity: { dupNameGroups, multiName, unnamed: employees.filter(e => e.unnamed), noId: employees.filter(e => e.noId), dupLines, netBreaks },
    lineCount: live.length, pm, trivial };
}

/* ============================================================== TESTS */
const tests = [
  { id:'EX-PAY-01', label:'Salary paid after the leaving date', basis:'U5.4',
    fn:(r) => r.__afterLeave && { actual: Core.fmtDate(r.leave_date), difference: r.__gross, cell: r['__cell_pay_month'],
      detail:`Paid for ${monthLabel(r.__monthKey)} although the employee left on ${Core.fmtDate(r.leave_date)} — obtain the final-pay computation or confirm the leaving date` } },
  { id:'EX-PAY-02', scope:'population', label:'No employer statutory contribution for an employee with contributable wages', basis:'U5.3',
    fn:(recs, cfg, eng, d) => d.statutory.nilEmployees.map(e => ({ key:`${e.id || '(no ID)'} · ${e.name || '(no name)'}`, expected:e.erExpected, actual:e.er, difference: r2(-e.erExpected),
      detail:`Expected ${e.erExpected.toFixed(2)} employer contribution for the year under the ${d.statutory.regime.label.split(' (')[0]} regime; nil recorded. Confirm exemption status (e.g. foreign employee) or raise an under-accrual.` })) },
  { id:'EX-PAY-03', label:'Month-on-month movement in basic salary above the threshold', basis:'U5.2',
    fn:(r, cfg, eng, d) => r.__momPct != null && Math.abs(r.__momPct) >= d.movement.threshold &&
      { expected: r.__momPrev, actual: r.__basicOnly, difference: r2(r.__basicOnly - r.__momPrev), cell: r['__cell_basic'],
        detail:`Basic ${r.__momPct > 0 ? 'increased' : 'decreased'} ${Math.abs(r.__momPct).toFixed(1)}% from ${monthLabel(r.__momPrevMonth)} to ${monthLabel(r.__monthKey)} (threshold ${d.movement.threshold}%). Agree to an approved increment letter or promotion.` } },
  { id:'EX-PAY-04', scope:'population', label:'Same employee name under more than one employee ID', basis:'U5.5', severity:'above-trivial',
    fn:(recs, cfg, eng, d) => d.integrity.dupNameGroups.map(g => ({ key: g.map(e => e.id || '(no ID)').join(' / ') + ' · ' + g[0].name, actual: g.length, difference: r2(g.reduce((s, e) => s + e.gross, 0)),
      detail:`"${g[0].name}" is paid under ${g.length} IDs (${g.map(e => e.id || '(no ID)').join(', ')}). Confirm with HR that these are different individuals; otherwise a duplicate or ghost employee.` })) },
  { id:'EX-PAY-05', scope:'population', label:'Employee with no name recorded', basis:'U5.5', severity:'above-trivial',
    fn:(recs, cfg, eng, d) => d.integrity.unnamed.map(e => ({ key: e.id || '(no ID)', actual: e.lines, difference: e.gross,
      detail:`${e.lines} payroll line(s) totalling ${e.gross.toFixed(2)} with no employee name — obtain the personnel file and bank payment evidence; possible ghost employee.` })) },
  { id:'EX-PAY-06', label:'Employer statutory contribution differs from the recalculation', basis:'U5.3',
    fn:(r, cfg, eng, d) => r.__erDiff != null && !r.__erNil && Math.abs(r.__erDiff) > d.statutory.tol &&
      { expected: r.__erExpected, actual: r.__erRecorded, difference: r.__erDiff, cell: r['__cell_employer_stat'],
        detail:`Recomputed on contributable wages ${r.__statBase.toFixed(2)} at ${d.statutory.regime.er}%` } },
  { id:'EX-PAY-07', label:'Salary paid before the joining date', basis:'U5.4',
    fn:(r) => r.__beforeJoin && { actual: Core.fmtDate(r.join_date), difference: r.__gross, cell: r['__cell_pay_month'],
      detail:`Paid for ${monthLabel(r.__monthKey)} although the employee joined on ${Core.fmtDate(r.join_date)}` } },
  { id:'EX-PAY-08', scope:'population', label:'Headcount does not reconcile from opening through joiners and leavers to closing', basis:'U5.1', severity:'informational',
    fn:(recs, cfg, eng, d) => d.headcount.diff !== 0 && { key:'Headcount', expected: d.headcount.expectedClosing, actual: d.headcount.closing.length, difference: null,
      detail:`Opening ${d.headcount.opening.length} + joiners ${d.headcount.joiners.length} − leavers ${d.headcount.leavers.length} = ${d.headcount.expectedClosing}; ${d.headcount.closing.length} employees paid in the final month. See the reconciling employees on U5.1.` } },
  { id:'EX-PAY-09', label:'Employee statutory contribution differs from the recalculation', basis:'U5.3', severity:'informational',
    fn:(r, cfg, eng, d) => r.__eeDiff != null && Math.abs(r.__eeDiff) > d.statutory.tol &&
      { expected: r.__eeExpected, actual: r.__eeRecorded, difference: r.__eeDiff, cell: r['__cell_employee_stat'] } },
  { id:'EX-PAY-10', label:'Employee paid twice in the same month', basis:'U5.5',
    fn:(r) => r.__dupLine && { difference: r.__gross, cell: r['__cell_pay_month'], detail:`Same employee ID and pay month — ${r.__dupLine.detail}` } },
  { id:'EX-PAY-11', label:'Net pay does not equal gross less employee deductions', basis:'U5', severity:'informational',
    fn:(r, cfg) => r.__netDiff != null && Math.abs(r.__netDiff) > (Number(cfg.netTol) >= 0 ? Number(cfg.netTol) : 1) &&
      { expected: r.__netExpected, actual: r.net, difference: r.__netDiff, cell: r['__cell_net'], detail:'Gross less employee statutory contribution and tax withheld does not arrive at net pay — other deductions not listed?' } },
  { id:'EX-PAY-12', label:'Contribution base below the statutory floor', basis:'U5.3',
    fn:(r, cfg, eng, d) => r.__baseBelowFloor && { expected: d.statutory.regime.floor, actual: r.stat_base, difference: r2(r.stat_base - d.statutory.regime.floor), cell: r['__cell_stat_base'],
      detail:'Contribution base declared to the authority is below the statutory floor while wages are at or above it' } },
  { id:'EX-PAY-20', scope:'population', label:'Payroll listing does not agree to the trial balance', basis:'U5',
    fn:(recs, cfg, eng, d) => d.lead.filter(l => l.tbDiff != null && Math.abs(l.tbDiff) > (Number(cfg.castTol) || 0.01))
      .map(l => ({ key:l.label, expected:l.tb, actual:l.value, difference:l.tbDiff, detail:'Per the payroll listing against the staff cost account(s) in the trial balance — obtain the reconciliation (accruals, reversals, capitalised labour)' })) }
];

/* ============================================================== PAGES */
const yn = ['Y', 'N'];
const empName = e => `${e.id || '(no ID)'} · ${e.name || '(no name)'}`;
const lineRow = r => ({ __rec:r, id:r.employee_id, name:r.employee_name, dept:r.department, month:r.__month, basic:r.__basicOnly, allowances:r.allowances, bonus:r.bonus, gross:r.__gross, er:r.__erRecorded, net:r.net });
const LINE_COLS = [
  { key:'id', label:'ID' }, { key:'name', label:'Employee' }, { key:'dept', label:'Department' }, { key:'month', label:'Pay month', type:'date' },
  { key:'basic', label:'Basic', type:'num', sum:true }, { key:'allowances', label:'Allowances', type:'num', sum:true }, { key:'bonus', label:'Bonus', type:'num', sum:true },
  { key:'gross', label:'Gross', type:'num', sum:true }, { key:'er', label:'Employer statutory', type:'num', sum:true }
];
const EMP_COLS = [
  { key:'id', label:'ID' }, { key:'name', label:'Employee' }, { key:'dept', label:'Department' },
  { key:'join', label:'Joined', type:'date' }, { key:'leave', label:'Left', type:'date' }, { key:'lines', label:'Months paid', type:'int' }
];
const empRow = e => ({ __key:e.key, id:e.id, name:e.name, dept:e.dept, join:e.join, leave:e.leave, lines:e.lines, basic:e.basic, allowances:e.allowances, bonus:e.bonus, gross:e.gross, er:e.er });

const pages = [
  { id:'source',  ref:'U5.0',  title:'Source data',     kind:'source' },
  { id:'cleaned', ref:'U5.0a', title:'Cleaned listing', kind:'cleaned' },
  { id:'mapping', ref:'U5.0b', title:'Column mapping',  kind:'mapping' },

  { id:'lead', ref:'U5', title:'Lead schedule',
    objective:'To agree staff costs per the payroll listing to the trial balance by cost line, to compare with the prior year, and to understand the composition of the cost by department.',
    procedures:['Cast the payroll listing by cost line (basic, allowances, bonus, employer statutory contributions) and by month.',
                'Agreed each cost line to the corresponding staff cost account(s) in the trial balance and obtained explanations for differences.',
                'Compared each cost line with the prior year audited figure and investigated movements above performance materiality.',
                'Analysed staff cost by department and proved net pay arithmetically from gross less deductions.'],
    render(st, ctx) {
      const d = ctx.d, T = d.totals, m0 = ctx.money0, money = ctx.money, cfg = ctx.cfg;
      return [
        { type:'controls', items:[
          { key:'salaryIs', label:'The salary column represents', kind:'select', options:[['basic', 'Basic salary — allowances and bonus are separate columns'], ['gross', 'Gross pay — already includes allowances and bonus']] },
          { key:'monthOrder', label:'Pay month column read as', kind:'select', options:[['auto', 'Automatic — prefer the reading that gives first-of-month dates'], ['keep', 'As parsed (dd/mm)'], ['swap', 'Swap day and month (mm/dd)']],
            help: d.swapping ? 'The pay-month column was read as mm/dd: every value falls on the 1st under that reading.' : 'Read as dd/mm.' },
          { key:'castTol', label:'Tolerance for differences', kind:'number' },
          { key:'netTol', label:'Net pay proof tolerance per line', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Employees', value: d.employees.length }, { label:'Payroll lines', value: d.lineCount },
          { label:'Months covered', value: d.monthKeys.length ? `${d.monthKeys.length} · ${monthLabel(d.firstKey)} – ${monthLabel(d.lastKey)}` : '' },
          { label:'Gross remuneration', value: m0(T.gross) }, { label:'Employer statutory', value: m0(T.er) }, { label:'Total staff cost', value: m0(T.cost) },
          { label:'Net pay', value: m0(T.net) }, { label:'Lines where net pay does not prove', value: d.integrity.netBreaks.length, cls: d.integrity.netBreaks.length ? 'warn' : 'ok' } ] },
        { type:'table', title:'Staff cost by line — listing vs trial balance vs prior year', columns:[
          { key:'label', label:'Cost line', emphasis:true }, { key:'value', label:'Per payroll listing', type:'num' },
          { key:'tb', label:'Per trial balance', input:'number' }, { key:'tbDiff', label:'Listing − TB', type:'num', flag: v => v != null && Math.abs(v) > (Number(cfg.castTol) || 0.01) },
          { key:'py', label:'Prior year audited', input:'number' }, { key:'variance', label:'Movement vs PY', type:'num', flag: (v, row) => row.__cls === 'flag' }, { key:'variancePct', label:'Movement %', type:'pct' },
          { key:'explanation', label:'Explanation of movement / reconciling items', input:'text', wide:true } ],
          rows: d.lead.map(l => ({ __key:l.key, ...l, variancePct: l.variancePct != null ? l.variancePct / 100 : null, __cls: l.material ? 'flag' : '' })), totals:false,
          footnote:'Gross remuneration and total staff cost are subtotals. Differences to the trial balance above the tolerance are raised as EX-PAY-20; movements above performance materiality are painted red.' },
        { type:'table', title:'Staff cost by month', columns:[
          { key:'label', label:'Month' }, { key:'heads', label:'Employees paid', type:'int' },
          { key:'basic', label:'Basic', type:'num', sum:true }, { key:'allowances', label:'Allowances', type:'num', sum:true }, { key:'bonus', label:'Bonus', type:'num', sum:true },
          { key:'gross', label:'Gross', type:'num', sum:true }, { key:'er', label:'Employer statutory', type:'num', sum:true }, { key:'net', label:'Net pay', type:'num', sum:true } ],
          rows: d.headcount.monthly },
        { type:'table', title:'Staff cost by department', columns:[
          { key:'dept', label:'Department' }, { key:'heads', label:'Employees', type:'int' }, { key:'gross', label:'Gross', type:'num', sum:true },
          { key:'er', label:'Employer statutory', type:'num', sum:true }, { key:'cost', label:'Total cost', type:'num', sum:true }, { key:'share', label:'Share', type:'pct' },
          { key:'comment', label:'Auditor comment', input:'text', wide:true } ],
          rows: d.byDept.map(x => ({ __key: Core.keyify(x.dept) || 'none', ...x, share: x.share / 100 })) },
        { type:'table', title:'Lines where net pay does not prove (gross − employee statutory − tax ≠ net)', columns:[...LINE_COLS,
          { key:'netExp', label:'Net expected', type:'num' }, { key:'net', label:'Net per listing', type:'num' }, { key:'netDiff', label:'Difference', type:'num' },
          { key:'comment', label:'Other deductions identified', input:'text', wide:true } ],
          rows: d.integrity.netBreaks.map(r => ({ ...lineRow(r), netExp: r.__netExpected, netDiff: r.__netDiff })), emptyText:'Net pay proves on every line.', maxHeight:'50vh' }
      ];
    },
    flag(st, d) { return d.lead.some(l => l.tbDiff != null && Math.abs(l.tbDiff) > 0.01); } },

  { id:'headcount', ref:'U5.1', title:'Headcount reconciliation',
    objective:'To reconcile the number of employees from the first payroll month through joiners and leavers to the final payroll month, and to identify employees paid outside their period of employment.',
    procedures:['Determined opening headcount as employees paid in the first month who joined before it, and closing headcount as employees paid in the final month.',
                'Identified joiners and leavers from the joining and leaving dates in the listing and reconciled opening + joiners − leavers to closing.',
                'Listed the reconciling employees and agreed joiners and leavers to the HR movement report.'],
    render(st, ctx) {
      const H = ctx.d.headcount;
      const recon = [
        { __key:'open', item:'Opening headcount (paid in ' + monthLabel(H.firstKey) + ', joined before it)', n: H.opening.length },
        { __key:'join', item:'Add: joiners (joining date within the period)', n: H.joiners.length },
        { __key:'leave', item:'Less: leavers (leaving date before ' + monthLabel(H.lastKey) + ')', n: -H.leavers.length },
        { __key:'exp', item:'Expected closing headcount', n: H.expectedClosing },
        { __key:'close', item:'Closing headcount per listing (paid in ' + monthLabel(H.lastKey) + ')', n: H.closing.length },
        { __key:'diff', item:'Difference', n: H.diff }
      ];
      return [
        { type:'stats', items:[
          { label:'Opening', value: H.opening.length }, { label:'Joiners', value: H.joiners.length }, { label:'Leavers', value: H.leavers.length },
          { label:'Leaving in the final month', value: H.leavingLast.length }, { label:'Closing per listing', value: H.closing.length },
          { label:'Difference', value: H.diff, cls: H.diff === 0 ? 'ok' : 'bad' },
          { label:'Paid after leaving', value: H.paidAfterLeaving.length, cls: H.paidAfterLeaving.length ? 'bad' : 'ok' },
          { label:'Paid before joining', value: H.paidBeforeJoining.length, cls: H.paidBeforeJoining.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Headcount roll-forward', columns:[
          { key:'item', label:'Item', emphasis:true }, { key:'n', label:'Employees', type:'int' }, { key:'hr', label:'Per HR movement report', input:'number' }, { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: recon.map(x => ({ ...x, __cls: x.__key === 'diff' && x.n !== 0 ? 'flag' : '' })), totals:false,
          footnote:'A non-zero difference is raised as EX-PAY-08. Typical reconciling employees: leavers still paid after their leaving date, employees paid before their joining date, and employees with no joining date recorded.' },
        { type:'table', title:'Employees paid per month', columns:[{ key:'label', label:'Month' }, { key:'heads', label:'Employees paid', type:'int' }, { key:'lines', label:'Lines', type:'int' }, { key:'gross', label:'Gross', type:'num', sum:true }], rows: H.monthly },
        { type:'table', title:'Joiners in the period', columns:[...EMP_COLS, { key:'firstPaid', label:'First month paid' },
          { key:'contract', label:'Employment contract sighted (Y/N)', input:'select', options:yn }, { key:'hrList', label:'On HR joiner list (Y/N)', input:'select', options:yn }, { key:'comment', label:'Comment', input:'text', wide:true }],
          rows: H.joiners.map(e => ({ ...empRow(e), firstPaid: monthLabel(e.firstPaid), __cls: e.beforeJoinLines.length ? 'flag' : '' })), emptyText:'No joining dates fall within the period.' },
        { type:'table', title:'Leavers in the period', columns:[...EMP_COLS, { key:'lastPaid', label:'Last month paid' }, { key:'status', label:'Status', type:'chip', chipClass: v => v === 'Paid after leaving' ? 'bad' : v === 'Left in final month' ? 'info' : 'ok' },
          { key:'letter', label:'Resignation / termination letter sighted (Y/N)', input:'select', options:yn }, { key:'finalPay', label:'Final pay recomputed (Y/N)', input:'select', options:yn }, { key:'comment', label:'Comment', input:'text', wide:true }],
          rows: [...H.leavers, ...H.leavingLast].map(e => ({ ...empRow(e), lastPaid: monthLabel(e.lastPaid), status: e.afterLeaveLines.length ? 'Paid after leaving' : e.leftInLast ? 'Left in final month' : 'Ceased', __cls: e.afterLeaveLines.length ? 'flag' : '' })),
          emptyText:'No leaving dates fall within the period.' },
        { type:'table', title:'Employees paid in the final month with no joining date, or whose first paid month is after the first month without a joining date in the period', columns:[...EMP_COLS, { key:'firstPaid', label:'First month paid' }, { key:'comment', label:'Comment', input:'text', wide:true }],
          rows: ctx.d.employees.filter(e => (!e.join && e.firstPaid && e.firstPaid !== H.firstKey) || (!e.join && e.paidLast && !e.paidFirst)).map(e => ({ ...empRow(e), firstPaid: monthLabel(e.firstPaid) })),
          emptyText:'None.' }
      ];
    },
    flag(st, d) { return d.headcount.diff !== 0 || d.headcount.paidAfterLeaving.length > 0; } },

  { id:'movement', ref:'U5.2', title:'Month-on-month movement',
    objective:'To identify unusual movements in basic salary by employee from month to month and to agree each to an authorised increment, promotion or correction.',
    procedures:['Compared basic salary for each employee with the preceding month paid and computed the percentage movement.',
                'Listed every movement at or above the threshold set and agreed it to an approved increment letter or HR record.',
                'Summarised the range of basic salary paid to each employee over the year.'],
    render(st, ctx) {
      const M = ctx.d.movement, pct = ctx.pct;
      return [
        { type:'controls', items:[{ key:'momThreshold', label:'Flag month-on-month movement in basic salary at or above (%)', kind:'number' }] },
        { type:'stats', items:[
          { label:'Movements flagged', value: M.lines.length, cls: M.lines.length ? 'warn' : 'ok' }, { label:'Employees affected', value: M.employees.length },
          { label:'Bonus month', value: M.bonusMonth ? `${M.bonusMonth.label} · ${ctx.money0(M.bonusMonth.bonus)}` : '' } ] },
        { type:'table', title:'Movements in basic salary at or above the threshold', columns:[
          { key:'id', label:'ID' }, { key:'name', label:'Employee' }, { key:'dept', label:'Department' },
          { key:'prevMonth', label:'From' }, { key:'prev', label:'Basic before', type:'num' }, { key:'month', label:'To', type:'date' }, { key:'basic', label:'Basic after', type:'num' },
          { key:'pct', label:'Movement', type:'pct' },
          { key:'letter', label:'Increment / promotion letter sighted (Y/N)', input:'select', options:yn }, { key:'approved', label:'Approved by', input:'text' }, { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: M.lines.map(r => ({ __rec:r, id:r.employee_id, name:r.employee_name, dept:r.department, prevMonth: monthLabel(r.__momPrevMonth), prev: r.__momPrev, month: r.__month, basic: r.__basicOnly, pct: r.__momPct / 100, __cls: 'flag' })),
          emptyText:'No month-on-month movement reaches the threshold.', footnote:'Each flagged movement is raised as EX-PAY-03. Bonus and allowances are excluded from the comparison.' },
        { type:'table', title:'Range of basic salary by employee', columns:[
          { key:'id', label:'ID' }, { key:'name', label:'Employee' }, { key:'dept', label:'Department' }, { key:'lines', label:'Months paid', type:'int' },
          { key:'minBasic', label:'Lowest basic', type:'num' }, { key:'maxBasic', label:'Highest basic', type:'num' }, { key:'maxMom', label:'Largest movement', type:'pct' }, { key:'annual', label:'Basic for the year', type:'num', sum:true } ],
          rows: ctx.d.employees.map(e => ({ id:e.id, name:e.name, dept:e.dept, lines:e.lines, minBasic:e.minBasic, maxBasic:e.maxBasic, maxMom: e.maxMom != null ? e.maxMom / 100 : null, annual:e.basic, __cls: e.momFlags ? 'flag' : '' })), maxHeight:'60vh' }
      ];
    },
    flag(st, d) { return d.movement.lines.length > 0; } },

  { id:'statutory', ref:'U5.3', title:'Statutory contribution recalculation',
    objective:'To recompute employer and employee statutory contributions for every payroll line on the contributable wages at the statutory rates, subject to the wage floor and ceiling, and to compare with the amounts recorded.',
    procedures:['Selected the statutory regime and confirmed the rates, wage floor and wage ceiling applicable to the year.',
                'Recomputed the employer and employee contribution for every line and compared it with the contribution recorded.',
                'Listed employees with no employer contribution despite contributable wages, and lines differing from the recalculation beyond the tolerance.'],
    render(st, ctx) {
      const S = ctx.d.statutory, R = S.regime, m0 = ctx.money0, money = ctx.money;
      const showLines = [...S.nilLines, ...S.erBreaks, ...S.eeBreaks.filter(r => !S.erBreaks.includes(r) && !S.nilLines.includes(r))];
      return [
        { type:'controls', items:[
          { key:'regime', label:'Statutory regime', kind:'select', options: Object.entries(REGIMES).map(([k, v]) => [k, v.label]), help: R.note },
          { key:'erRate', label:'Employer rate % (blank = regime default)', kind:'number', help:`In use: ${R.er ?? '—'}%` },
          { key:'eeRate', label:'Employee rate % (blank = regime default)', kind:'number', help:`In use: ${R.ee ?? '—'}%` },
          { key:'wageCap', label:'Monthly wage ceiling (blank = regime default)', kind:'number', help:`In use: ${R.cap != null ? m0(R.cap) : 'no ceiling'}` },
          { key:'wageFloor', label:'Monthly wage floor (blank = regime default)', kind:'number', help:`In use: ${R.floor ? m0(R.floor) : 'none'}` },
          { key:'statBase', label:'Wages subject to contribution', kind:'select', options:[['basic', 'Basic salary only'], ['basic_allow', 'Basic salary and allowances'], ['gross', 'Gross including bonus']] },
          { key:'statTol', label:'Tolerance per line', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Employer — recorded', value: m0(S.erRecorded) }, { label:'Employer — per audit', value: m0(S.erExpected) },
          { label:'Employer — difference', value: money(S.erDiff), cls: Math.abs(S.erDiff || 0) > ctx.trivial ? 'bad' : Math.abs(S.erDiff || 0) > S.tol ? 'warn' : 'ok' },
          { label:'Employee — recorded', value: m0(S.eeRecorded) }, { label:'Employee — per audit', value: m0(S.eeExpected) },
          { label:'Employee — difference', value: money(S.eeDiff), cls: Math.abs(S.eeDiff || 0) > S.tol ? 'warn' : 'ok' },
          { label:'Employees with nil employer contribution', value: S.nilEmployees.length, cls: S.nilEmployees.length ? 'bad' : 'ok' },
          { label:'Lines above tolerance (employer)', value: S.erBreaks.length, cls: S.erBreaks.length ? 'warn' : 'ok' },
          { label:'Lines at the wage ceiling', value: S.capped }, { label:'Contribution base below floor', value: S.baseBelowFloor.length, cls: S.baseBelowFloor.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Recalculation by employee', columns:[
          { key:'id', label:'ID' }, { key:'name', label:'Employee' }, { key:'lines', label:'Months', type:'int' }, { key:'basic', label:'Basic for the year', type:'num', sum:true },
          { key:'erExpected', label:'Employer per audit', type:'num', sum:true }, { key:'er', label:'Employer recorded', type:'num', sum:true }, { key:'erDiff', label:'Difference', type:'num', sum:true, flag: (v, row) => row.__nil || Math.abs(v || 0) > S.tol * (row.lines || 1) },
          { key:'eeExpected', label:'Employee per audit', type:'num', sum:true }, { key:'ee', label:'Employee recorded', type:'num', sum:true }, { key:'eeDiff', label:'Difference', type:'num', sum:true, flag: v => Math.abs(v || 0) > S.tol * 12 },
          { key:'status', label:'Status', type:'chip', chipClass: v => v === 'Nil contribution' ? 'bad' : v === 'Differs' ? 'warn' : 'ok' },
          { key:'exempt', label:'Exempt / reason (e.g. foreign employee, above age band)', input:'text', wide:true } ],
          rows: S.byEmployee.map(e => ({ ...e, __nil: e.erNil, status: e.erNil ? 'Nil contribution' : Math.abs(e.erDiff || 0) > S.tol * e.lines ? 'Differs' : 'Agrees', __cls: e.erNil ? 'flag' : '' })), maxHeight:'60vh' },
        { type:'table', title:'Lines differing from the recalculation', columns:[...LINE_COLS.filter(c => c.key !== 'er'),
          { key:'base', label:'Contributable wages (capped)', type:'num' }, { key:'erExp', label:'Employer per audit', type:'num', sum:true }, { key:'erRec', label:'Employer recorded', type:'num', sum:true }, { key:'erDiff', label:'Difference', type:'num', sum:true },
          { key:'eeExp', label:'Employee per audit', type:'num' }, { key:'eeRec', label:'Employee recorded', type:'num' }, { key:'eeDiff', label:'Difference', type:'num' },
          { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: showLines.map(r => ({ ...lineRow(r), base:r.__statBase, erExp:r.__erExpected, erRec:r.__erRecorded, erDiff:r.__erDiff, eeExp:r.__eeExpected, eeRec:r.__eeRecorded, eeDiff:r.__eeDiff, __cls: r.__erNil ? 'flag' : '' })),
          emptyText:'Every line agrees to the recalculation within the tolerance.', maxHeight:'60vh',
          footnote:'Nil employer contributions are raised per employee as EX-PAY-02; other differences per line as EX-PAY-06 (employer) and EX-PAY-09 (employee).' }
      ];
    },
    flag(st, d) { return d.statutory.nilEmployees.length > 0 || d.statutory.erBreaks.length > 0; } },

  { id:'joinleave', ref:'U5.4', title:'Joiners and leavers testing',
    objective:'To verify that employees are paid only for their period of employment: no salary after the leaving date and none before the joining date, with final pay and first pay agreed to HR records.',
    procedures:['Compared every pay month to the joining and leaving dates of the employee and listed lines paid after the leaving month or before the joining month.',
                'For each exception, obtained the HR record and the bank payment to determine whether the payment was valid (e.g. pay in lieu of notice) or an overpayment.'],
    render(st, ctx) {
      const H = ctx.d.headcount;
      const after = H.paidAfterLeaving.flatMap(e => e.afterLeaveLines), before = H.paidBeforeJoining.flatMap(e => e.beforeJoinLines);
      const cols = [...LINE_COLS, { key:'join', label:'Joined', type:'date' }, { key:'leave', label:'Left', type:'date' },
        { key:'hr', label:'HR record sighted (Y/N)', input:'select', options:yn }, { key:'bank', label:'Bank payment sighted (Y/N)', input:'select', options:yn },
        { key:'valid', label:'Payment valid (Y/N)', input:'select', options:yn }, { key:'comment', label:'Nature (notice pay, error, recovered)', input:'text', wide:true }];
      const row = r => ({ ...lineRow(r), join:r.join_date, leave:r.leave_date, __cls:'flag' });
      return [
        { type:'stats', items:[
          { label:'Lines paid after leaving date', value: `${after.length} · ${ctx.money0(after.reduce((s, r) => s + r.__gross, 0))}`, cls: after.length ? 'bad' : 'ok' },
          { label:'Employees', value: H.paidAfterLeaving.length },
          { label:'Lines paid before joining date', value: `${before.length} · ${ctx.money0(before.reduce((s, r) => s + r.__gross, 0))}`, cls: before.length ? 'bad' : 'ok' },
          { label:'Lines marked invalid', value: [...after, ...before].filter(r => r.__wp?.joinleave?.valid === 'N').length } ] },
        { type:'table', title:'Salary paid after the leaving date', columns: cols, rows: after.map(row), emptyText:'No payments after the leaving month.', footnote:'Raised as EX-PAY-01 per line.' },
        { type:'table', title:'Salary paid before the joining date', columns: cols, rows: before.map(row), emptyText:'No payments before the joining month.', footnote:'Raised as EX-PAY-07 per line.' }
      ];
    },
    flag(st, d) { return d.headcount.paidAfterLeaving.length > 0 || d.headcount.paidBeforeJoining.length > 0; } },

  { id:'integrity', ref:'U5.5', title:'Duplicate and unnamed employees',
    objective:'To identify possible ghost or duplicate employees: the same name under more than one ID, one ID carrying more than one name, lines with no employee name or ID, and employees paid twice in a month.',
    procedures:['Grouped the listing by employee name and by employee ID and listed the conflicts.',
                'Listed lines with no employee name or no employee ID and lines duplicating an employee and pay month.',
                'For each, obtained the personnel file, identity document and bank account evidence to establish the employee exists and is paid once.'],
    render(st, ctx) {
      const I = ctx.d.integrity, m0 = ctx.money0;
      const inputs = [{ key:'file', label:'Personnel file sighted (Y/N)', input:'select', options:yn }, { key:'bank', label:'Distinct bank account confirmed (Y/N)', input:'select', options:yn },
        { key:'genuine', label:'Genuine employee (Y/N)', input:'select', options:yn }, { key:'comment', label:'Comment', input:'text', wide:true }];
      const PAY_COLS = [{ key:'basic', label:'Basic', type:'num', sum:true }, { key:'bonus', label:'Bonus', type:'num', sum:true }, { key:'gross', label:'Gross for the year', type:'num', sum:true }];
      return [
        { type:'stats', items:[
          { label:'Names under more than one ID', value: I.dupNameGroups.length, cls: I.dupNameGroups.length ? 'bad' : 'ok' },
          { label:'IDs carrying more than one name', value: I.multiName.length, cls: I.multiName.length ? 'warn' : 'ok' },
          { label:'Employees with no name', value: I.unnamed.length, cls: I.unnamed.length ? 'bad' : 'ok' },
          { label:'Lines with no ID', value: I.noId.length, cls: I.noId.length ? 'warn' : 'ok' },
          { label:'Duplicate employee-month lines', value: I.dupLines.length, cls: I.dupLines.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Same name under more than one employee ID', columns:[...EMP_COLS, ...PAY_COLS, ...inputs],
          rows: I.dupNameGroups.flat().map(e => ({ ...empRow(e), __cls:'flag' })), emptyText:'No duplicated names.', footnote:'Raised as EX-PAY-04 per name.' },
        { type:'table', title:'Employees with no name recorded', columns:[...EMP_COLS, ...PAY_COLS, ...inputs],
          rows: I.unnamed.map(e => ({ ...empRow(e), __cls:'flag' })), emptyText:'Every line carries an employee name.', footnote:'Raised as EX-PAY-05 per employee.' },
        { type:'table', title:'One employee ID carrying more than one name', columns:[...EMP_COLS, { key:'names', label:'Names seen', wrap:true }, ...PAY_COLS, ...inputs],
          rows: I.multiName.map(e => ({ ...empRow(e), names: e.recs.map(r => r.employee_name).filter((v, i, a) => v && a.indexOf(v) === i).join(' / ') })), emptyText:'None.' },
        { type:'table', title:'Employee paid twice in the same month', columns:[...LINE_COLS, { key:'dupOf', label:'Duplicate of' }, { key:'genuine', label:'Genuine second payment (Y/N)', input:'select', options:yn }, { key:'comment', label:'Comment', input:'text', wide:true }],
          rows: I.dupLines.map(r => ({ ...lineRow(r), dupOf: r.__dupLine.detail })), emptyText:'None.', footnote:'Raised as EX-PAY-10 per line.' }
      ];
    },
    flag(st, d) { return d.integrity.dupNameGroups.length > 0 || d.integrity.unnamed.length > 0 || d.integrity.dupLines.length > 0; } },

  { id:'tod', ref:'U5.6', title:'Test of details',
    objective:'To verify, for a selection of payroll lines, that the employee exists and the amount paid is authorised and accurately computed, by vouching to the employment contract or latest increment letter and to the bank payment.',
    procedures:['Selected every payroll line with gross remuneration at or above the testing threshold as a key item.',
                'Selected a random sample from the remaining lines using a recorded seed so the selection is reproducible.',
                'For each selected line, agreed basic salary to the employment contract or increment letter, agreed net pay to the bank payment, and recomputed gross to net.'],
    render(st, ctx) {
      const T = ctx.d.tod, m0 = ctx.money0, pct = ctx.pct;
      return [
        { type:'controls', items:[
          { key:'todThreshold', label:'Testing threshold — every line with gross at or above is selected', kind:'number', help:`Blank = performance materiality (${m0(ctx.pm)}). Currently ${m0(T.threshold)}.` },
          { key:'todSampleN', label:'Random sample from the remaining lines', kind:'number', help:`${T.residual.length} lines below the threshold` },
          { key:'todSeed', label:'Random seed', kind:'number' } ] },
        { type:'stats', items:[
          { label:'Population', value: `${T.key.length + T.residual.length} lines · ${m0(T.popValue)}` },
          { label:'Key items', value: T.key.length }, { label:'Random sample', value: T.sample.length }, { label:'Employees covered', value: T.employeesCovered },
          { label:'Coverage of gross remuneration', value: pct(T.coverage), cls: T.coverage >= 25 ? 'ok' : 'warn' },
          { label:'Agreed', value: `${T.agreed} of ${T.selected.length}`, cls: T.agreed === T.selected.length && T.selected.length ? 'ok' : 'warn' },
          { label:'Not agreed', value: T.notAgreed.length, cls: T.notAgreed.length ? 'bad' : 'ok' } ] },
        { type:'table', title:'Lines selected for vouching', columns:[...LINE_COLS, { key:'net', label:'Net pay', type:'num', sum:true },
          { key:'basis', label:'Basis', type:'chip', chipClass: v => v === 'Key item' ? 'info' : 'grey' },
          { key:'contract', label:'Contract / increment letter sighted (Y/N)', input:'select', options:yn }, { key:'contractBasic', label:'Basic per contract', input:'number' },
          { key:'bank', label:'Bank payment sighted (Y/N)', input:'select', options:yn }, { key:'bankAmount', label:'Amount per bank', input:'number' },
          { key:'agreed', label:'Amount agreed (Y/N)', input:'select', options:yn }, { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: T.selected.map(r => ({ ...lineRow(r), basis: r.__todSelected === 'key' ? 'Key item' : 'Random sample', __cls: r.__wp?.tod?.agreed === 'N' ? 'flag' : '' })),
          emptyText:'No lines selected — lower the threshold or increase the sample.', maxHeight:'70vh', footnote:`Seed ${T.seed}. Record the figure per contract and per bank so the difference is evident in the file.` }
      ];
    },
    flag(st, d) { return d.tod.notAgreed.length > 0; } },

  { id:'kmp', ref:'U5.7', title:'Key management remuneration',
    objective:'To identify directors and key management personnel among the employees and to accumulate their remuneration by component for the related-party disclosure (FRS 24 para 17).',
    procedures:['Marked each director and member of key management personnel against the employee list, with their role.',
                'Accumulated short-term employee benefits and post-employment (statutory) contributions for the persons marked, for the disclosure note.',
                'Agreed directors\' remuneration to board or remuneration committee approval.'],
    render(st, ctx) {
      const K = ctx.d.kmp, m0 = ctx.money0;
      return [
        { type:'stats', items:[
          { label:'Persons marked as KMP', value: K.employees.length, cls: K.employees.length ? 'ok' : 'warn' },
          { label:'Salary and allowances', value: m0(K.salary) }, { label:'Bonus', value: m0(K.bonus) }, { label:'Employer statutory contributions', value: m0(K.er) },
          { label:'Total KMP remuneration', value: m0(K.total) }, { label:'Share of total staff cost', value: ctx.pct(K.share) } ] },
        { type:'table', title:'Employee list — mark directors and key management', columns:[
          { key:'id', label:'ID' }, { key:'name', label:'Employee' }, { key:'dept', label:'Department' }, { key:'designation', label:'Designation' },
          { key:'kmp', label:'Director / KMP (Y/N)', input:'select', options:yn }, { key:'kmpRole', label:'Role (e.g. Executive director, CFO)', input:'text', wide:true },
          { key:'salaryAllow', label:'Salary and allowances', type:'num', sum:true }, { key:'bonus', label:'Bonus', type:'num', sum:true }, { key:'er', label:'Employer statutory', type:'num', sum:true }, { key:'total', label:'Total', type:'num', sum:true } ],
          rows: ctx.d.employees.map(e => ({ __key:e.key, id:e.id, name:e.name, dept:e.dept, designation:e.designation, salaryAllow: r2(e.basic + e.allowances), bonus:e.bonus, er:e.er, total: r2(e.gross + e.er), __cls: e.kmp ? 'yes' : '' })), maxHeight:'60vh' },
        { type:'table', title:'Key management personnel compensation — for disclosure', columns:[
          { key:'name', label:'Person' }, { key:'role', label:'Role' }, { key:'salaryAllow', label:'Short-term benefits — salary and allowances', type:'num', sum:true },
          { key:'bonus', label:'Short-term benefits — bonus', type:'num', sum:true }, { key:'er', label:'Post-employment benefits — statutory contributions', type:'num', sum:true }, { key:'total', label:'Total', type:'num', sum:true },
          { key:'approval', label:'Board / RC approval sighted (Y/N)', input:'select', options:yn }, { key:'comment', label:'Comment', input:'text', wide:true } ],
          rows: K.employees.map(e => ({ __key:e.key, name: empName(e), role:e.role, salaryAllow: r2(e.basic + e.allowances), bonus:e.bonus, er:e.er, total: r2(e.gross + e.er) })),
          emptyText:'Mark at least one director or key management person in the table above.', footnote:'Directors\' fees paid outside the payroll are added separately in the disclosure.' }
      ];
    } },

  { id:'conclusion', ref:'U5.9', title:'Exceptions & conclusion', kind:'conclusion' }
];

function suggestConclusion(st, ctx) {
  const d = ctx.d, T = d.totals, S = d.statutory, H = d.headcount;
  const ex = (st.exceptions || []).filter(e => e.disposition === 'open');
  const tbLine = d.lead.find(l => l.key === 'cost');
  return [
    `Staff costs per the payroll listing total ${ctx.money(T.cost)} (gross remuneration ${ctx.money(T.gross)} and employer statutory contributions ${ctx.money(T.er)}) for ${d.employees.length} employees over ${d.monthKeys.length} months${tbLine?.tbDiff == null ? '' : Math.abs(tbLine.tbDiff) <= 0.01 ? ', agreeing to the trial balance' : `, differing from the trial balance by ${ctx.money(tbLine.tbDiff)}`}.`,
    `Headcount reconciled from ${H.opening.length} opening through ${H.joiners.length} joiners and ${H.leavers.length} leavers to ${H.closing.length} closing${H.diff === 0 ? '.' : ` with a difference of ${H.diff}.`}`,
    `Employer statutory contributions were recomputed under the ${S.regime.label.split(' (')[0]} regime: recorded ${ctx.money(S.erRecorded)} against ${ctx.money(S.erExpected)} per audit${S.nilEmployees.length ? `; ${S.nilEmployees.length} employee(s) carry nil contributions` : ''}.`,
    `${d.tod.selected.length} payroll lines (${ctx.pct(d.tod.coverage)} of gross remuneration) were vouched to contracts and bank payments; ${d.tod.agreed} agreed.`,
    d.kmp.employees.length ? `Key management remuneration of ${ctx.money(d.kmp.total)} was accumulated for disclosure.` : 'Key management personnel have not yet been marked on U5.7.',
    ex.length ? `${ex.length} exception(s) remain open in the register.` : 'No exceptions remain open.',
    'Subject to the above, staff costs are complete, accurately computed and fairly stated for the year.'
  ].join(' ');
}

return {
  code:'PAY', name:'Payroll', group:'Profit or loss', accepts:'.xlsx,.xlsm,.csv',
  blurb:'The payroll audit file: lead by cost line, headcount reconciliation, month-on-month movement, statutory contribution recalculation under a configurable regime, joiners and leavers, duplicate and unnamed employees, test of details and key management remuneration — from one uploaded payroll listing.',
  objective:'To obtain sufficient appropriate audit evidence that staff costs are complete, relate to genuine employees for their period of employment, are accurately computed including statutory contributions, and that key management remuneration is properly disclosed.',
  fields, tests, compute, pages, defaultConfig, STANDARD_COLUMNS, REGIMES,
  procedures: pages.flatMap(p => p.procedures || []),
  columns: STANDARD_COLUMNS, suggestConclusion
};
})();

Modules.register(PAYModule);
