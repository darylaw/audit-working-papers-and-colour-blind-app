/* ==========================================================================
   core.js -- ingest, clean, map, test.
   Nothing here knows about any particular audit area. Modules supply the
   field dictionary and the rules; this file supplies the machinery.
   ========================================================================== */

const Core = (() => {

/* ---------------------------------------------------------------- utils */
const isBlank = v => v === null || v === undefined ||
  (typeof v === 'string' && v.trim() === '');
const norm = s => String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
const lower = s => norm(s).toLowerCase();
const keyify = s => lower(s).replace(/[^a-z0-9]+/g, '');

/* Stable non-cryptographic hash, for the source-file audit trail. */
function hash(buf) {
  const b = new Uint8Array(buf);
  let h1 = 0xdeadbeef, h2 = 0x41c6ce57;
  for (let i = 0; i < b.length; i++) {
    h1 = Math.imul(h1 ^ b[i], 2654435761);
    h2 = Math.imul(h2 ^ b[i], 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16).padStart(12, '0');
}

/* ------------------------------------------------------- number parsing */
/* DQ-06 / DQ-21: thousands separators, () negatives, trailing minus,
   currency prefixes, a lone dash for nil, blank vs zero preserved.        */
function parseNumber(v) {
  if (v === null || v === undefined || v === '') return { ok: false, blank: true };
  if (typeof v === 'number') return { ok: true, value: v };
  let s = String(v).trim();
  if (s === '') return { ok: false, blank: true };
  if (/^[-–—]$/.test(s)) return { ok: true, value: 0, wasDash: true };
  let neg = false;
  if (/^\(.*\)$/.test(s)) { neg = true; s = s.slice(1, -1); }
  if (/-$/.test(s)) { neg = true; s = s.slice(0, -1); }
  // Strip currency symbols and recognised currency codes only. Stripping arbitrary letters
  // turned month headings such as "Mar 25" into the number 25 and broke header detection.
  s = s.replace(/[$€£¥₹]/g, '');
  s = s.replace(/^(?:USD|SGD|MYR|HKD|CNY|RMB|EUR|GBP|JPY|AUD|INR|IDR|THB|PHP|VND|NZD|CAD|CHF|TWD|KRW|S|US|HK|RM|Rp)\s*(?=[-\d.(])/i, '');
  s = s.replace(/(?<=[\d.)])\s*(?:USD|SGD|MYR|HKD|CNY|RMB|EUR|GBP|JPY|AUD|INR|IDR|THB|PHP|VND|NZD|CAD|CHF|TWD|KRW|Dr|Cr)$/i, '');
  s = s.replace(/\s/g, '');
  s = s.replace(/,/g, '');
  if (s === '' || !/^-?\d*\.?\d+$/.test(s)) return { ok: false, raw: v };
  let n = parseFloat(s);
  if (isNaN(n)) return { ok: false, raw: v };
  if (neg) n = -Math.abs(n);
  return { ok: true, value: n, coerced: true };
}

/* --------------------------------------------------------- date parsing */
const EXCEL_EPOCH = Date.UTC(1899, 11, 30);
const MONTHS = { jan:0,feb:1,mar:2,apr:3,may:4,jun:5,jul:6,aug:7,sep:8,sept:8,oct:9,nov:10,dec:11 };

function fromSerial(n) {
  if (n < 20 || n > 80000) return null;
  return new Date(EXCEL_EPOCH + Math.round(n) * 86400000);
}
function mkDate(y, m, d) {
  if (y < 100) y += y < 70 ? 2000 : 1900;
  if (m < 0 || m > 11 || d < 1 || d > 31) return null;
  const dt = new Date(Date.UTC(y, m, d));
  return dt.getUTCMonth() === m && dt.getUTCDate() === d ? dt : null;
}

/* Every interpretation a single cell admits. The column vote picks between them. */
function dateCandidates(v) {
  const out = [];
  if (v instanceof Date && !isNaN(v)) { out.push({ style: 'native', date: v }); return out; }
  if (typeof v === 'number') {
    const d = fromSerial(v);
    if (d) out.push({ style: 'serial', date: d });
    if (v >= 1900 && v <= 2100) out.push({ style: 'year_only', date: mkDate(v, 0, 1), imprecise: true });
    return out;
  }
  const s = norm(v);
  if (!s) return out;
  let m;
  if ((m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/))) {
    const d = mkDate(+m[1], +m[2] - 1, +m[3]); if (d) out.push({ style: 'iso', date: d });
    return out;
  }
  if ((m = s.match(/^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{2,4})$/))) {
    const a = +m[1], b = +m[2], y = +m[3];
    const dmy = mkDate(y, b - 1, a); if (dmy) out.push({ style: 'dmy', date: dmy, a, b });
    const mdy = mkDate(y, a - 1, b); if (mdy) out.push({ style: 'mdy', date: mdy, a, b });
    return out;
  }
  if ((m = s.match(/^(\d{1,2})[\-\s]([A-Za-z]{3,9})[\-\s](\d{2,4})$/))) {
    const mo = MONTHS[m[2].slice(0, 4).toLowerCase()] ?? MONTHS[m[2].slice(0, 3).toLowerCase()];
    if (mo !== undefined) { const d = mkDate(+m[3], mo, +m[1]); if (d) out.push({ style: 'dmon', date: d }); }
    return out;
  }
  if ((m = s.match(/^([A-Za-z]{3,9})[\-\s](\d{2,4})$/))) {
    const mo = MONTHS[m[1].slice(0, 4).toLowerCase()] ?? MONTHS[m[1].slice(0, 3).toLowerCase()];
    if (mo !== undefined) { const d = mkDate(+m[2], mo, 1); if (d) out.push({ style: 'mon_yy', date: d, imprecise: true }); }
    return out;
  }
  if ((m = s.match(/^(\d{4})$/))) {
    const d = mkDate(+m[1], 0, 1); if (d) out.push({ style: 'year_only', date: d, imprecise: true });
  }
  return out;
}

/* DQ-05: decide dd/mm vs mm/dd once for the whole column, on evidence.
   If nothing in the column settles it, we say so rather than guessing.   */
function resolveDateColumn(values) {
  let dmyOnly = 0, mdyOnly = 0, parsed = 0, unparsed = 0, imprecise = 0, bothWays = 0;
  for (const v of values) {
    if (isBlank(v)) continue;
    const c = dateCandidates(v);
    if (!c.length) { unparsed++; continue; }
    parsed++;
    if (c.some(x => x.imprecise)) imprecise++;
    const hasD = c.some(x => x.style === 'dmy'), hasM = c.some(x => x.style === 'mdy');
    if (hasD && !hasM) dmyOnly++;
    if (hasM && !hasD) mdyOnly++;
    if (hasD && hasM) bothWays++;
  }
  let order = null, ambiguous = false;
  if (dmyOnly && !mdyOnly) order = 'dmy';
  else if (mdyOnly && !dmyOnly) order = 'mdy';
  else if (dmyOnly && mdyOnly) ambiguous = true;   // the column contradicts itself
  else if (bothWays) ambiguous = true;             // nothing in the column settles it
  return { order, ambiguous, parsed, unparsed, imprecise,
           parseRate: parsed / Math.max(1, parsed + unparsed) };
}

function parseDateWith(v, order) {
  const c = dateCandidates(v);
  if (!c.length) return { ok: false, raw: v };
  if (c.length === 1) return { ok: true, date: c[0].date, style: c[0].style, imprecise: !!c[0].imprecise };
  const pick = c.find(x => x.style === order) || c[0];
  return { ok: true, date: pick.date, style: pick.style, imprecise: !!pick.imprecise,
           ambiguous: c.some(x => x.style === 'dmy') && c.some(x => x.style === 'mdy') && !order };
}

const fmtDate = d => !d ? '' :
  `${String(d.getUTCDate()).padStart(2,'0')}/${String(d.getUTCMonth()+1).padStart(2,'0')}/${d.getUTCFullYear()}`;
const toISO = d => !d ? '' : d.toISOString().slice(0, 10);

/* ============================================================== INGEST */
/* Read a workbook, keep every sheet verbatim, and score them so the most
   table-like is proposed. Hidden sheets stay selectable (DQ-18).         */
function readWorkbook(arrayBuffer, fileName) {
  const wb = XLSX.read(arrayBuffer, { type: 'array', cellDates: true, cellNF: false, cellText: false });
  const sheets = wb.SheetNames.map(name => {
    const ws = wb.Sheets[name];
    const rows = XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: null, blankrows: true });
    const hidden = (wb.Workbook?.Sheets || []).find(s => s.name === name)?.Hidden > 0;
    return { name, rows, hidden, score: scoreSheet(rows) };
  });
  sheets.sort((a, b) => b.score - a.score);
  return { fileName, hash: hash(arrayBuffer), sheets, uploadedAt: new Date().toISOString() };
}

function scoreSheet(rows) {
  if (!rows || !rows.length) return 0;
  let populated = 0, cells = 0, numericCells = 0, maxRun = 0;
  for (const r of rows) {
    let run = 0;
    for (const c of (r || [])) {
      cells++;
      if (!isBlank(c)) {
        populated++; run++;
        if (typeof c === 'number' || parseNumber(c).ok) numericCells++;
        if (run > maxRun) maxRun = run;
      } else run = 0;
    }
  }
  if (!populated) return 0;
  return Math.log1p(rows.length) * 3 + maxRun * 2 + (numericCells / populated) * 10
       + (populated / Math.max(1, cells)) * 5;
}

/* Score each candidate row as the header. Title rows lose on the numeric
   test below them; a merged one-cell row loses on cell count.            */
function detectHeader(rows, maxScan = 30) {
  const limit = Math.min(maxScan, rows.length);
  let best = { row: 0, score: -1 };
  for (let i = 0; i < limit; i++) {
    const r = rows[i] || [];
    const filled = r.filter(c => !isBlank(c));
    if (filled.length < 2) continue;
    const textish = filled.filter(c => typeof c === 'string' && !parseNumber(c).ok).length;
    const uniq = new Set(filled.map(c => lower(c))).size;
    const longProse = filled.filter(c => String(c).length > 60).length;
    let below = 0, belowCells = 0;
    for (let j = i + 1; j < Math.min(i + 12, rows.length); j++) {
      for (const c of (rows[j] || [])) {
        if (isBlank(c)) continue;
        belowCells++;
        if (typeof c === 'number' || parseNumber(c).ok || c instanceof Date) below++;
      }
    }
    const numericBelow = belowCells ? below / belowCells : 0;
    const score = (textish / filled.length) * 22 + (uniq / filled.length) * 12
                + Math.min(filled.length, 14) * 1.6 + numericBelow * 26
                - longProse * 9 - i * 0.45;
    if (score > best.score) best = { row: i, score, cols: filled.length };
  }
  return best.row;
}

/* DQ-17: a merged span above the header row is a block header. This is
   what resolves the Additions-under-Cost / Additions-under-Depreciation
   collision that heading text alone cannot.                              */
/* ------------------------------------------------------- multi-row headers
   Real audit schedules rarely put a heading on one row.  A fixed asset movement
   is typically three rows deep --

       |        COST            |   ACC DEPRECIATION    | NET BOOK |
       | AT 1.1.22 | ADDITIONS  | AT 1.1.22 | CHARGE    | VALUE    |

   -- and a column is often just "COSTS AT" above "1.1.2022".  Reading one row
   loses either the block or half of every label, so find the whole run of
   header rows and stitch each column down the run.

   A row joins the run when it reads like a heading (two or more cells, hardly
   any of them numeric) and what follows still looks like data.  The run stops
   at the first row that is mostly figures -- that row is the first asset.   */
/* A heading row carries no figures.  That single test is what separates a
   second row of headings from the first row of the listing: "AT 1.1.22" and
   "31.12.2022" are labels, 125,000.00 is an opening balance.  Bare years are
   allowed through, because a comparative schedule heads its columns with them. */
const isYear = n => Number.isInteger(n) && n >= 1900 && n <= 2100;
function carriesFigures(row) {
  return (row || []).some(c => {
    if (typeof c === 'number') return !isYear(c);
    if (typeof c !== 'string') return false;
    const p = parseNumber(c);
    return p.ok && !isYear(p.value);
  });
}
function headerLike(row) {
  const filled = (row || []).filter(c => !isBlank(c));
  if (filled.length < 2) return false;
  if (carriesFigures(row)) return false;
  if (filled.some(c => typeof c === 'string' && c.length > 90)) return false;   /* prose */
  return true;
}
function dataLike(row) {
  const filled = (row || []).filter(c => !isBlank(c));
  if (!filled.length) return false;
  const numeric = filled.filter(c => typeof c === 'number' || c instanceof Date ||
    (typeof c === 'string' && parseNumber(c).ok)).length;
  return numeric / filled.length >= 0.3;
}

/* Carrying no figures is necessary but not sufficient: a related party listing
   opens with a text-only row of party and relationship, and that is a record,
   not a heading.  A row is only absorbed when it visibly completes the row
   above it -- by labelling columns the row above left blank, by sitting under a
   block row that spans several columns, or by telling apart two columns the row
   above gave the same name ("COSTS AT" twice, dated 1.1.22 and 31.12.22).   */
function completesHeader(above, below) {
  const A = above || [], B = below || [];
  const fa = A.filter(c => !isBlank(c)).length, fb = B.filter(c => !isBlank(c)).length;
  if (fa >= 2 && fa <= fb * 0.6) return 'block';                 /* sparse spanning row */
  let complementary = 0;
  for (let j = 0; j < Math.max(A.length, B.length); j++) if (isBlank(A[j]) && !isBlank(B[j])) complementary++;
  if (complementary >= 2) return 'fills gaps';
  const labels = A.map(c => lower(c)).filter(Boolean);
  const dupes = new Set(labels.filter((l, i) => labels.indexOf(l) !== i));
  if (dupes.size) {
    let disambiguated = 0;
    for (let j = 0; j < A.length; j++) if (dupes.has(lower(A[j])) && !isBlank(B[j])) disambiguated++;
    if (disambiguated >= 2) return 'separates repeated labels';
  }
  return null;
}

function headerSpan(rows, headerRow, maxRows = 3) {
  const span = [headerRow];
  for (let i = headerRow + 1; i < Math.min(headerRow + maxRows, rows.length); i++) {
    if (!headerLike(rows[i])) break;
    if (!completesHeader(rows[i - 1], rows[i])) break;
    /* Only absorb the row if something below it still reads like data -- else
       a two-row listing of text would swallow its own first record.          */
    let seen = false;
    for (let j = i + 1; j < Math.min(i + 6, rows.length); j++) if (dataLike(rows[j])) { seen = true; break; }
    if (!seen) break;
    span.push(i);
  }
  return span;
}

/* Stitch the run into one heading per column, top to bottom, skipping repeats.
   Where the top row of the run is much sparser than the rest it is a block row
   -- "COST" spanning four columns -- and is kept out of the heading so that
   block-qualified mapping can still tell one "Additions" from the other.    */
function stitchHeaders(rows, span) {
  const rowsIn = span.map(i => rows[i] || []);
  const counts = rowsIn.map(r => r.filter(c => !isBlank(c)).length);
  const densest = Math.max(...counts);
  const blockRowIdx = (span.length > 1 && counts[0] <= densest * 0.6) ? span[0] : -1;
  const use = span.filter(i => i !== blockRowIdx);
  let width = 0;
  for (const i of span) width = Math.max(width, (rows[i] || []).length);
  const headings = [];
  for (let j = 0; j < width; j++) {
    const parts = [];
    for (const i of use) {
      const v = norm((rows[i] || [])[j]);
      if (v && !parts.some(p => lower(p) === lower(v))) parts.push(v);
    }
    headings.push(parts.join(' '));
  }
  return { headings, blockRow: blockRowIdx, lastRow: span[span.length - 1] };
}

function detectBlocks(rows, headerRow, blockRow) {
  const src = blockRow != null && blockRow >= 0 ? blockRow : headerRow - 1;
  if (src < 0) return null;
  const above = rows[src] || [];
  const filled = above.map((c, i) => ({ c, i })).filter(x => !isBlank(x.c));
  if (filled.length < 2 || filled.length > 8) return null;
  const hdr = rows[headerRow] || [];
  if (filled.length >= hdr.filter(c => !isBlank(c)).length) return null;
  if (src !== headerRow - 1 && src >= headerRow) return null;
  const blocks = [];
  for (let k = 0; k < filled.length; k++) {
    const start = filled[k].i;
    const end = (k + 1 < filled.length ? filled[k + 1].i : hdr.length) - 1;
    blocks.push({ label: norm(filled[k].c), start, end });
  }
  return blocks;
}

/* ============================================================== CLEAN */
function cleanTable(rows, headerRow, opts = {}) {
  const log = [];
  const span = opts.headerSpan || headerSpan(rows, headerRow);
  const stitched = stitchHeaders(rows, span);
  const headers = stitched.headings;
  headerRow = stitched.lastRow;                    /* data begins after the run */
  if (span.length > 1)
    log.push({ rule: 'DQ-30', detail: `Heading read from ${span.length} rows (${span.map(i => i + 1).join(', ')}); labels stitched down the columns` });
  const blocks = detectBlocks(rows, headerRow, stitched.blockRow);
  if (blocks) log.push({ rule: 'DQ-17', detail: `Block headers detected: ${blocks.map(b => b.label).join(', ')}` });

  /* DQ-03: columns empty in the header and in every data row */
  let width = headers.length;                       /* a reduce, not a spread: a
     100,000-row sheet overflows the call stack when spread into Math.max. */
  for (let i = headerRow + 1; i < rows.length; i++) { const n = (rows[i] || []).length; if (n > width) width = n; }
  const colUsed = new Array(width).fill(false);
  for (let i = headerRow + 1; i < rows.length; i++)
    for (let j = 0; j < width; j++) if (!isBlank((rows[i] || [])[j])) colUsed[j] = true;
  const keepCols = [];
  for (let j = 0; j < width; j++) if (colUsed[j] || !isBlank(headers[j])) keepCols.push(j);
  const dropped = width - keepCols.length;
  if (dropped > 0) log.push({ rule: 'DQ-03', detail: `${dropped} blank column(s) removed` });

  const outHeaders = keepCols.map(j => ({
    index: j, letter: XLSX.utils.encode_col(j), heading: headers[j] || '',
    block: blocks ? (blocks.find(b => j >= b.start && j <= b.end)?.label || '') : ''
  }));

  const body = [];
  let currentGroup = null, blankRows = 0, subtotals = 0, groupHeaders = 0, footnotes = 0;
  let seenData = false, trailingBlanks = 0;

  for (let i = headerRow + 1; i < rows.length; i++) {
    const raw = rows[i] || [];
    const cells = keepCols.map(j => raw[j]);
    const filled = cells.filter(c => !isBlank(c));

    if (!filled.length) { blankRows++; trailingBlanks++; continue; }
    trailingBlanks = 0;

    const textCells = filled.filter(c => typeof c === 'string' && !parseNumber(c).ok);
    const numCells = filled.filter(c => typeof c === 'number' || parseNumber(c).ok);

    /* DQ-08 first: a subtotal row whose formula cells carry no cached value
       is a lone text label, and would otherwise look like a group header. */
    const label = norm(cells.find(c => typeof c === 'string') || '');
    const isTotalLabel = /^(sub[\s-]?total|total|grand[\s-]?total|sum)\b/i.test(label);
    /* DQ-09: a lone text cell on its own row is a category header */
    if (!isTotalLabel && filled.length === 1 && textCells.length === 1 && String(filled[0]).length < 70) {
      currentGroup = norm(filled[0]); groupHeaders++;
      log.push({ rule: 'DQ-09', row: i + 1, detail: `Group header: ${currentGroup}` });
      continue;
    }
    if (isTotalLabel) {
      subtotals++;
      log.push({ rule: 'DQ-08', row: i + 1, detail: `Subtotal row excluded: ${label}` });
      body.push({ __kind: 'subtotal', __srcRow: i + 1, __group: currentGroup, cells });
      continue;
    }
    /* DQ-22: commentary below the data */
    if (seenData && filled.length <= 2 && textCells.length === filled.length &&
        String(filled[0]).length > 40) {
      footnotes++;
      log.push({ rule: 'DQ-22', row: i + 1, detail: 'Footnote row captured' });
      body.push({ __kind: 'footnote', __srcRow: i + 1, cells });
      continue;
    }
    seenData = true;
    body.push({ __kind: 'data', __srcRow: i + 1, __group: currentGroup, cells });
  }
  if (blankRows) log.push({ rule: 'DQ-02', detail: `${blankRows} blank row(s) skipped` });
  if (groupHeaders) log.push({ rule: 'DQ-09', detail: `${groupHeaders} group header row(s) forward-filled into a category column` });
  if (subtotals) log.push({ rule: 'DQ-08', detail: `${subtotals} subtotal row(s) held out of the population` });
  if (footnotes) log.push({ rule: 'DQ-22', detail: `${footnotes} footnote row(s) captured as source notes` });

  return { headers: outHeaders, rows: body, log, blocks, hasGroups: groupHeaders > 0 };
}

/* ============================================================ MAPPING */
function tokens(s) { return lower(s).split(/[^a-z0-9]+/).filter(Boolean); }

function similarity(a, b) {
  const ka = keyify(a), kb = keyify(b);
  if (!ka || !kb) return 0;
  if (ka === kb) return 1;
  const ta = tokens(a), tb = tokens(b);
  if (!ta.length || !tb.length) return 0;
  const setB = new Set(tb);
  const overlap = ta.filter(t => setB.has(t)).length;
  const jac = overlap / (new Set([...ta, ...tb]).size);
  let sub = 0;
  if (ka.includes(kb) || kb.includes(ka)) sub = 0.55;
  return Math.max(jac, sub);
}

/* DQ-26: split a bilingual heading and match on either half. */
function headingVariants(h) {
  const v = [h];
  const cjk = h.match(/[㐀-鿿豈-﫿]+/g);
  if (cjk) {
    v.push(h.replace(/[㐀-鿿豈-﫿]+/g, ' ').trim());
    cjk.forEach(x => v.push(x));
  }
  return v.filter(Boolean);
}

/* A column holds dates when it holds dates -- not when its numbers happen to
   fall in Excel's serial range.  194.25 is an interest charge, not 12 July 1900. */
const DATEISH = /^\s*(\d{1,4}[-\/.]\d{1,2}[-\/.]\d{1,4}|\d{1,2}\s*[-\/ ]\s*[A-Za-z]{3,9}\s*[-\/ ]\s*\d{2,4}|[A-Za-z]{3,9}\s+\d{1,2},?\s*\d{2,4})\s*$/;
function looksDated(vals) {
  if (!vals.length) return false;
  const good = vals.filter(v => v instanceof Date || (typeof v === 'string' && DATEISH.test(v))).length;
  return good / vals.length >= 0.8;
}

function proposeMapping(headers, fields, sampleRows) {
  const mapping = {};
  const rows = sampleRows || [];

  /* Headings that mean this field: what we call it, plus everything we have
     seen it called.  keyify() in similarity() takes care of case, spacing,
     punctuation and any decoration such as a trailing "*" or "(SGD)".       */
  const names = f => [f.label, ...(f.synonyms || [])].filter(Boolean);

  const valuesOf = col => {
    const at = headers.indexOf(col);
    return rows.map(r => r.cells[at]).filter(v => !isBlank(v));
  };

  /* Does the column actually contain what the field says it holds?  A heading
     alone is not enough: on a real receivables ageing, "Invoice Amount" fuzzy-
     matches the invoice date field, and without this test the amounts are read
     as Excel serial dates and the audit is quietly wrong.  Fill matters too --
     a summary block pasted beside the listing populates a handful of rows and
     must never satisfy a required column.                                    */
  const fitCache = new Map();
  const fitness = (f, col) => {
    const key = f.type + '|' + col.index;
    if (fitCache.has(key)) return fitCache.get(key);
    const vals = valuesOf(col);
    const fill = rows.length ? vals.length / rows.length : 1;
    let fit = 0.5;                                   /* nothing to judge on */
    if (vals.length) {
      if (f.type === 'number') fit = vals.filter(v => typeof v === 'number' || parseNumber(v).ok).length / vals.length;
      else if (f.type === 'date') fit = resolveDateColumn(vals).parseRate;
      else {                                         /* text: an all-numeric column is not a description */
        const num = vals.filter(v => typeof v === 'number' || (typeof v === 'string' && parseNumber(v).ok)).length;
        fit = 1 - 0.75 * (num / vals.length);
      }
    }
    const out = { fit, fill };
    fitCache.set(key, out);
    return out;
  };

  /* Every field against every column, scored once. */
  const cands = [];
  for (const f of fields) {
    for (const col of headers) {
      let score = 0, basis = '';
      for (const variant of headingVariants(col.heading)) {
        for (const syn of names(f)) {
          const sim = similarity(variant, syn);
          if (sim > score) { score = sim; basis = sim === 1 ? (variant === col.heading ? 'exact' : 'bilingual') : 'fuzzy'; }
        }
      }
      /* block-qualified: the two-tier header disambiguates repeated words */
      if (f.block && col.block) {
        const bs = similarity(col.block, f.block);
        if (bs > 0.5) { score = Math.min(1, score + 0.45); basis = score >= 1 ? 'block+exact' : 'block-qualified'; }
        else if (score >= 0.99) { score = 0.55; basis = 'heading matches, block does not'; }
      }
      const exact = score >= 0.99;
      const { fit, fill } = fitness(f, col);

      if (!exact) {
        if (score < 0.4) {
          /* No heading worth the name.  The content can still speak for itself,
             but only for a column nothing else explains.                      */
          if (f.type === 'date' && fit >= 0.9 && fill >= 0.6 && looksDated(valuesOf(col))) {
            cands.push({ f, col, score: 0.42, fit, fill, basis: 'content inference (the column holds dates)', inferred: true });
          }
          /* Numbers are never inferred from content alone: on a receivables
             ageing, "Interest" and "Days Past Due" are as numeric as the
             amount, and a silent wrong guess is worse than no column.      */
          continue;
        }
        if (fit < 0.6) continue;                     /* heading hints, content disagrees: not this column */
      }
      let s = score * (0.55 + 0.45 * fit);
      if (fill < 0.15) s *= 0.35;                    /* a mostly empty column explains nothing */
      cands.push({ f, col, score: s, raw: score, fit, fill, basis: exact && fit < 0.5 ? basis + ' (content does not look like ' + f.type + ')' : basis });
    }
  }

  /* Assign best pair first, not field-declaration order: whichever field and
     column agree most strongly gets to claim each other, so a fuzzy match on a
     field declared early can no longer take a column a later field names.   */
  cands.sort((a, b) => b.score - a.score || (b.fit - a.fit) || (b.fill - a.fill));
  const usedCols = new Set(), done = new Set();
  for (const c of cands) {
    if (done.has(c.f.key) || usedCols.has(c.col.index)) continue;
    if (c.score < 0.3) continue;
    usedCols.add(c.col.index); done.add(c.f.key);
    mapping[c.f.key] = {
      colIndex: c.col.index, letter: c.col.letter, heading: c.col.heading, block: c.col.block,
      basis: c.basis, fit: Math.round(c.fit * 100) / 100, fill: Math.round(c.fill * 100) / 100,
      confidence: (c.raw >= 0.99 && c.fit >= 0.5) ? 'high' : c.score >= 0.6 ? 'medium' : 'low',
      confirmed: false
    };
  }
  for (const f of fields) if (!mapping[f.key]) mapping[f.key] = null;
  return mapping;
}

/* ============================================ TYPED RECORD CONSTRUCTION */
function buildRecords(clean, fields, mapping) {
  const hIdx = new Map(clean.headers.map((h, i) => [h.index, i]));
  const dataRows = clean.rows.filter(r => r.__kind === 'data');
  const colInfo = {}, issues = [];

  for (const f of fields) {
    const m = mapping[f.key];
    if (!m) continue;
    const pos = hIdx.get(m.colIndex);
    const vals = dataRows.map(r => r.cells[pos]);
    if (f.type === 'date') {
      const info = resolveDateColumn(vals);
      colInfo[f.key] = info;
      if (info.ambiguous) issues.push({ rule: 'DQ-05', field: f.key,
        detail: `Column "${m.heading}" is ambiguous between dd/mm and mm/dd. Confirm the order before relying on date-based tests.` });
      if (info.imprecise) issues.push({ rule: 'DQ-05', field: f.key,
        detail: `${info.imprecise} value(s) in "${m.heading}" carry no day or month and were taken as the first of the period.` });
    }
  }

  const records = dataRows.map((r, n) => {
    const rec = { __srcRow: r.__srcRow, __i: n, __group: r.__group, __flags: [] };
    for (const f of fields) {
      const m = mapping[f.key];
      if (!m) { rec[f.key] = null; continue; }
      const pos = hIdx.get(m.colIndex);
      let v = r.cells[pos];
      rec['__cell_' + f.key] = m.letter + r.__srcRow;
      if (f.type === 'number') {
        const p = parseNumber(v);
        rec[f.key] = p.ok ? p.value : null;
        if (!p.ok && !p.blank) { rec.__flags.push({ rule: 'DQ-21', field: f.key, raw: v }); }
        else if (p.coerced) rec.__flags.push({ rule: 'DQ-06', field: f.key, raw: v });
      } else if (f.type === 'date') {
        const order = colInfo[f.key]?.order;
        const p = parseDateWith(v, order);
        rec[f.key] = p.ok ? p.date : null;
        if (!p.ok && !isBlank(v)) rec.__flags.push({ rule: 'DQ-21', field: f.key, raw: v });
        if (p.imprecise) rec.__flags.push({ rule: 'DQ-05', field: f.key, raw: v });
      } else {
        const s = norm(v);
        rec[f.key] = s === '' ? null : s;
        if (typeof v === 'string' && v !== s) rec.__flags.push({ rule: 'DQ-04', field: f.key, raw: v });
      }
      if (f.required && isBlank(rec[f.key]) && !(f.satisfiedByGroup && clean.hasGroups))
        rec.__flags.push({ rule: 'DQ-11', field: f.key });
    }
    /* DQ-09: category came from a group header row */
    if (rec.__group) {
      const catField = fields.find(f => f.role === 'category');
      if (catField && !rec[catField.key]) {
        rec[catField.key] = rec.__group;
        rec.__flags.push({ rule: 'DQ-09', field: catField.key });
      }
    }
    return rec;
  });

  /* DQ-10: exact and near duplicates on the module's duplicate key */
  const dupFields = fields.filter(f => f.dupKey).map(f => f.key);
  if (dupFields.length) {
    const seen = new Map();
    for (const rec of records) {
      const k = dupFields.map(f => keyify(rec[f] instanceof Date ? toISO(rec[f]) : rec[f])).join('|');
      if (!k.replace(/\|/g, '')) continue;
      if (seen.has(k)) { rec.__flags.push({ rule: 'DQ-10', detail: 'duplicate of row ' + seen.get(k) }); }
      else seen.set(k, rec.__srcRow);
    }
  }
  return { records, colInfo, issues };
}

/* ========================================================= TEST RUNNER */
function runTests(module, records, cfg, eng, ctx = {}) {
  const exceptions = [];
  const derived = module.compute ? module.compute(records, cfg, eng, ctx) : {};
  for (const t of module.tests) {
    if (t.scope === 'population') {
      const hit = t.fn(records, cfg, eng, derived);
      if (hit) {
        (Array.isArray(hit) ? hit : [hit]).forEach(h => exceptions.push(mkExc(t, h, eng, cfg, null)));
      }
      continue;
    }
    for (const rec of records) {
      if (rec.__excluded) continue;
      const hit = t.fn(rec, cfg, eng, derived);
      if (hit) exceptions.push(mkExc(t, hit === true ? {} : hit, eng, cfg, rec));
    }
  }
  return { exceptions, derived };
}

function mkExc(t, h, eng, cfg, rec) {
  const amt = h.difference != null ? Math.abs(h.difference) : (h.amount != null ? Math.abs(h.amount) : null);
  return {
    id: t.id, label: t.label, basis: t.basis || '',
    recordKey: h.key ?? (rec ? (rec.__displayKey || rec.__srcRow) : null),
    srcRow: rec ? rec.__srcRow : null,
    cell: h.cell || null,
    expected: h.expected ?? null, actual: h.actual ?? null, difference: h.difference ?? null,
    detail: h.detail || '',
    severity: severityOf(amt, eng, t),
    disposition: 'open', reason: ''
  };
}

function severityOf(amount, eng, t) {
  if (t.severity) return t.severity;
  const m = eng.materiality || {};
  if (amount == null) return 'informational';
  if (m.pm && amount >= m.pm) return 'above-pm';
  if (m.trivial && amount >= m.trivial) return 'above-trivial';
  return 'below-trivial';
}

/* ====================================================== MATERIALITY */
const MAT_BASES = [
  { key: 'turnover',   label: 'Turnover',              lo: 0.01, hi: 0.03, def: 0.02 },
  { key: 'pbt',        label: 'Profit before tax',     lo: 0.03, hi: 0.07, def: 0.05 },
  { key: 'totalAssets',label: 'Total assets',          lo: 0.01, hi: 0.03, def: 0.02 },
  { key: 'netAssets',  label: 'Net assets',            lo: 0.03, hi: 0.05, def: 0.04 },
  { key: 'grossExp',   label: 'Gross income/expenditure', lo: 0.01, hi: 0.03, def: 0.02 }
];
function computeMateriality(m) {
  const benchmark = Number(m.benchmark) || 0;
  const rate = Number(m.rate) || 0;
  const om = Math.abs(benchmark * rate);
  const pm = om * (Number(m.pmPct) || 0.75);
  const trivial = om * (Number(m.trivialPct) || 0.05);
  return { ...m, om, pm, trivial };
}

/* ------------------------------------------------------- numeric input box
   Auditors sit in these boxes all day, so they must behave like a spreadsheet
   cell.  A plain <input type=number> bound to a re-render does not: committing
   Number(value) on every keystroke rewrites the box, so a half-typed "4." loses
   its decimal point and a lone "-" becomes NaN, and re-rendering a 350-row
   working paper on each character makes typing feel like wading.

   So: keep the raw string while the box has focus (a re-render never overwrites
   what is being typed), commit the parsed number immediately so dependent
   figures stay right, and debounce the re-render until typing pauses.  Accepts
   what a client's schedule would contain -- 4,440.50, (1,200), 1 200.        */
const NumBox = (() => {
  const raw = new Map();                       // data-k -> string mid-typing
  const timers = new Map();
  const show = (k, v) => raw.has(k) ? raw.get(k)
    : (v === null || v === undefined || v === '' || (typeof v === 'number' && isNaN(v)) ? '' : String(v));

  /* o = { k, value, commit(numberOr''), refresh?, placeholder?, cls?, style?, title? } */
  function make(o) {
    const k = o.k, n = document.createElement('input');
    n.type = 'text'; n.inputMode = 'decimal'; n.autocomplete = 'off'; n.spellcheck = false;
    n.className = 'numbox' + (o.cls ? ' ' + o.cls : '');
    n.setAttribute('data-k', k);
    if (o.style) n.setAttribute('style', o.style);
    if (o.placeholder != null) n.placeholder = String(o.placeholder);
    if (o.title) n.title = o.title;
    n.value = show(k, o.value);
    const settle = () => { raw.delete(k); clearTimeout(timers.get(k)); timers.delete(k); if (o.refresh) o.refresh(); };
    n.addEventListener('input', () => {
      raw.set(k, n.value);
      const s = n.value.trim();
      if (s === '') o.commit('');
      else { const p = parseNumber(s); if (p.ok) o.commit(p.value); }   // unparseable = mid-typing, keep the last committed figure
      if (o.refresh) {
        clearTimeout(timers.get(k));
        timers.set(k, setTimeout(() => { timers.delete(k); o.refresh(); }, 350));
      }
    });
    n.addEventListener('blur', settle);
    n.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); settle(); } });
    return n;
  }
  /* A re-render mid-typing must not resurrect a stale string in a box the
     auditor has since left, so drop anything not currently focused.          */
  function sweep() {
    const live = document.activeElement && document.activeElement.dataset && document.activeElement.dataset.k;
    for (const k of [...raw.keys()]) if (k !== live) raw.delete(k);
  }
  function clear() { for (const timer of timers.values()) clearTimeout(timer); timers.clear(); raw.clear(); }
  return { make, sweep, clear, typing: () => raw.size > 0 };
})();

const escapeHTML = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
const decodeText = s => s.replace(/&(amp|lt|gt|quot|#39|nbsp);/g, (_, k) => ({ amp:'&', lt:'<', gt:'>', quot:'"', '#39':"'", nbsp:'\u00a0' }[k]));
// Render our small formatting vocabulary without ever parsing source text as HTML.
const richTokens = s => String(s ?? '').split(/(<\/?(?:b|strong|i|em|code|br|span)(?: class="(?:miss|mono|req)")?\s*\/?>)/gi);
const richTag = s => s.match(/^<(\/?)(b|strong|i|em|code|br|span)(?: class="(miss|mono|req)")?\s*\/?>$/i);
function richText(host, html) {
  const stack = [host];
  for (const token of richTokens(html)) {
    const tag = richTag(token);
    if (!tag) { stack[stack.length - 1].append(decodeText(token)); continue; }
    const name = tag[2].toLowerCase();
    if (tag[1]) { if (stack.length > 1 && stack[stack.length - 1].tagName.toLowerCase() === name) stack.pop(); }
    else {
      const node = document.createElement(name);
      if (tag[3]) node.className = tag[3];
      stack[stack.length - 1].append(node);
      if (name !== 'br') stack.push(node);
    }
  }
  return host;
}
const plainText = html => richTokens(html).map(t => richTag(t) ? (/^<br/i.test(t) ? '\n' : '') : decodeText(t)).join('');

return { isBlank, norm, lower, keyify, hash, parseNumber, parseDateWith, resolveDateColumn,
         dateCandidates, fmtDate, toISO, readWorkbook, scoreSheet, detectHeader, detectBlocks,
         cleanTable, proposeMapping, buildRecords, runTests, severityOf, similarity, NumBox, headerSpan,
         MAT_BASES, computeMateriality, escapeHTML, richText, plainText };
})();
