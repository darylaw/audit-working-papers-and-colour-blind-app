/* ==========================================================================
   xlsxout.js -- the working paper workbook.

   Formula policy: a live Excel formula wherever Excel can reproduce the
   calculation, so a reviewer can change an input and watch the working
   paper respond. Values only where a formula would misrepresent -- source
   data, logs, AI text and anything with no honest Excel equivalent.
   ========================================================================== */

const Exporter = (() => {
const C = XLSX.utils.encode_col;
const A = (c, r) => C(c) + (r + 1);          // 0-based -> A1

function sheetFrom(aoa, opts = {}) {
  const ws = XLSX.utils.aoa_to_sheet(aoa, { cellDates: true });
  if (opts.merges) ws['!merges'] = opts.merges;
  if (opts.freeze) ws['!freeze'] = opts.freeze;
  return ws;
}
function putFormula(ws, col, row, f, numFmt) {
  const ref = A(col, row);
  ws[ref] = { t: 'n', f };
  if (numFmt) ws[ref].z = numFmt;
  const rng = XLSX.utils.decode_range(ws['!ref'] || 'A1');
  rng.e.c = Math.max(rng.e.c, col); rng.e.r = Math.max(rng.e.r, row);
  ws['!ref'] = XLSX.utils.encode_range(rng);
}
const MONEY = '#,##0.00;[Red](#,##0.00)';
const PCT = '0.00%';
const DATE = 'dd/mm/yyyy';

function fmtCell(v) {
  if (v instanceof Date) return Core.fmtDate(v);
  return v;
}

function build(state, moduleCode) {
  return WPStyle.applyWorkbook(buildRaw(state, moduleCode));   /* dress it once everything is written */
}
function buildRaw(state, moduleCode) {
  const M = Modules.byCode[moduleCode];
  if (M.pages) return FileExporter.build(state, moduleCode);   // audit-file layout
  const st = state.modules[moduleCode];
  const eng = state.engagement;
  const wb = XLSX.utils.book_new();
  const stamp = new Date().toISOString().replace('T', ' ').slice(0, 19);
  const hdr = () => ([
    ['Module', `${M.code} — ${M.name}`],
    ['Entity', eng.client || '(not entered)'],
    ['Financial year end', eng.yearEnd || '(not entered)'],
    ['Audit firm / file reference', eng.firmRef || '(not entered)'],
    ['Exported', stamp],
    []
  ]);

  /* ---------------------------------------------------- 00 Summary ---- */
  {
    const a = [
      ['WORKING PAPER'], [],
      ['Working paper title', M.name],
      ['Audit area', `${M.code}${eng.indexRef?.[M.code] ? '  (file ref ' + eng.indexRef[M.code] + ')' : ''}`],
      ['Entity', eng.client || ''],
      ['Financial year end', eng.yearEnd || ''],
      ['Prepared by', eng.preparedBy || ''], ['Date prepared', eng.datePrepared || ''],
      ['Reviewed by', eng.reviewedBy || ''], ['Date reviewed', eng.dateReviewed || ''],
      [],
      ['Audit objective'], [M.objective], [],
      ['Materiality applied'],
      ['Basis', `${eng.materiality.basisLabel || ''} × ${((eng.materiality.rate||0)*100).toFixed(2)}%`],
      ['Overall materiality', eng.materiality.om || 0],
      ['Performance materiality', eng.materiality.pm || 0],
      ['Trivial threshold', eng.materiality.trivial || 0],
      [],
      ['Audit procedures performed'],
      ...M.procedures.map((p, i) => [i + 1, p]),
      [],
      ['Source documents used'],
      ['File', 'Sheet', 'Rows read', 'Hash', 'Uploaded'],
      ...(st.sources || []).map(s => [s.fileName, s.sheetName, s.rowCount, s.hash, s.uploadedAt]),
      [],
      ['Results'],
      ['Records in population', st.records?.length || 0],
      ['Records excluded by the auditor', (st.records || []).filter(r => r.__excluded).length],
      ['Exceptions raised', st.exceptions?.length || 0],
      ['— above performance materiality', (st.exceptions||[]).filter(e => e.severity==='above-pm').length],
      ['— above trivial threshold', (st.exceptions||[]).filter(e => e.severity==='above-trivial').length],
      ['— below trivial / informational', (st.exceptions||[]).filter(e => e.severity==='below-trivial'||e.severity==='informational').length],
      [],
      ['Auditor comments'], [st.comments || ''], [],
      ['Auditor conclusion'], [st.conclusion || ''], [],
      ['Tickmark legend'],
      ['TB', 'Agreed to trial balance'], ['PY', 'Agreed to prior year audited financial statements'],
      ['^', 'Casting checked'], ['vINV', 'Vouched to invoice'],
      ['i/m', 'Immaterial — no further work'], ['<ref>', 'Cross-reference']
    ];
    const ws = sheetFrom(a, { widths: [42, 62, 16, 20, 22] });
    XLSX.utils.book_append_sheet(wb, ws, '00 Summary');
  }

  /* ------------------------------------------------ 01 Source Data ---- */
  (st.sources || []).forEach((s, i) => {
    const a = [
      ['SOURCE DATA — PRESERVED AS RECEIVED. Values only; do not edit.'],
      ['File', s.fileName], ['Sheet', s.sheetName], ['Hash', s.hash],
      ['Uploaded', s.uploadedAt], ['Header row detected', s.headerRow + 1], [],
      ...s.rawRows.map(r => (r || []).map(fmtCell))
    ];
    XLSX.utils.book_append_sheet(wb, sheetFrom(a, { widths: new Array(20).fill(18) }),
      ('01 Source ' + (i + 1)).slice(0, 31));
  });

  /* ----------------------------------------------- 02 Cleaned Data ---- */
  let cleanedRowOf = new Map();
  {
    const cols = M.fields.filter(f => st.mapping[f.key]);
    const head = ['Src row', 'Category from group header', ...cols.map(f => f.label), 'Excluded', 'Data quality flags'];
    const a = [...hdr(), ['CLEANED DATA'], [], head];
    const firstDataRow = a.length;
    (st.records || []).forEach((rec, i) => {
      cleanedRowOf.set(rec.__i, a.length);
      a.push([
        rec.__srcRow, rec.__group || '',
        ...cols.map(f => rec[f.key] instanceof Date ? Core.fmtDate(rec[f.key]) : rec[f.key]),
        rec.__excluded ? 'Excluded: ' + (rec.__excludeReason || '') : '',
        (rec.__flags || []).map(f => f.rule + (f.field ? ':' + f.field : '')).join(' ')
      ]);
    });
    const ws = sheetFrom(a, { widths: [10, 26, ...cols.map(() => 18), 28, 26] });
    XLSX.utils.book_append_sheet(wb, ws, '02 Cleaned Data');
    st.__cleanFirstRow = firstDataRow;
    st.__cleanCols = cols;
  }

  /* --------------------------------------------------- 03 Mapping ---- */
  {
    const a = [...hdr(), ['COLUMN MAPPING'], [],
      ['Canonical field', 'Required', 'Source column', 'Source heading', 'Block header',
       'Match basis', 'Confidence', 'Auditor confirmed', 'Derived']];
    M.fields.forEach(f => {
      const m = st.mapping[f.key];
      a.push([f.label, f.required ? 'Yes' : 'No', m ? m.letter : '— not mapped —',
              m ? m.heading : '', m ? m.block : '', m ? m.basis : '',
              m ? m.confidence : '', m && m.confirmed ? 'Yes' : 'No',
              f.derivedFrom ? 'Derived' : '']);
    });
    XLSX.utils.book_append_sheet(wb, sheetFrom(a, { widths: [34, 12, 15, 34, 20, 26, 14, 18, 12] }), '03 Mapping');
  }

  /* ---------------------------------------------- 04 Cleaning Log ---- */
  {
    const a = [...hdr(), ['CLEANING LOG'], [], ['Rule', 'Source row', 'Detail']];
    (st.cleanLog || []).forEach(l => a.push([l.rule, l.row || '', l.detail]));
    (st.mapIssues || []).forEach(l => a.push([l.rule, '', l.detail]));
    XLSX.utils.book_append_sheet(wb, sheetFrom(a, { widths: [12, 12, 110] }), '04 Cleaning Log');
  }

  /* --------------------------------------------- 05 Audit Testing ---- */
  {
    const a = [...hdr(), ['AUDIT TESTING'], [],
      ['Formulae in this sheet are live and reference 02 Cleaned Data. Change an input there and this sheet recalculates.'], []];
    const ws = buildTestingSheet(M, st, eng, a);
    XLSX.utils.book_append_sheet(wb, ws, '05 Audit Testing');
  }

  /* ------------------------------------------------ 06 Exceptions ---- */
  {
    const a = [...hdr(), ['EXCEPTION REGISTER'], [],
      ['ID', 'Exception', 'Record', 'Src row', 'Cell', 'Expected', 'Actual', 'Difference',
       'Severity', 'Basis', 'Detail', 'Disposition', 'Reason']];
    const first = a.length;
    (st.exceptions || []).forEach(e => a.push([
      e.id, e.label, String(e.recordKey ?? ''), e.srcRow || '', e.cell || '',
      typeof e.expected === 'number' ? e.expected : (e.expected ?? ''),
      typeof e.actual === 'number' ? e.actual : (e.actual ?? ''),
      e.difference ?? '', sevLabel(e.severity), e.basis, e.detail,
      e.disposition, e.reason || ''
    ]));
    const last = a.length - 1;
    a.push([]);
    const ws = sheetFrom(a, { widths: [14, 46, 32, 9, 9, 15, 15, 15, 20, 40, 46, 14, 30] });
    if (last >= first) {
      const tot = a.length;
      ws[A(1, tot)] = { t: 's', v: 'Total difference on open exceptions' };
      putFormula(ws, 7, tot, `SUMIF(L${first + 1}:L${last + 1},"open",H${first + 1}:H${last + 1})`, MONEY);
      ws[A(1, tot + 1)] = { t: 's', v: 'Count above performance materiality' };
      putFormula(ws, 7, tot + 1, `COUNTIF(I${first + 1}:I${last + 1},"Above performance materiality")`);
    }
    XLSX.utils.book_append_sheet(wb, ws, '06 Exceptions');
  }

  /* --------------------------------------- 07 Supporting Workings ---- */
  if (moduleCode === 'AR' && st.derived?.matrix) {
    const a = [...hdr(), ['PROVISION MATRIX — FRS 109'], [],
      ['Ageing bucket', 'Items', 'Gross carrying amount', 'Loss rate applied',
       'Forward-looking multiplier', 'Adjusted rate', 'Expected credit loss']];
    const first = a.length;
    st.derived.matrix.forEach(m => a.push([m.label, m.count, m.gross, m.rate,
      Number(st.config.fwdMultiplier) || 0, null, null]));
    const last = a.length - 1;
    a.push([]);
    const ws = sheetFrom(a, { widths: [24, 10, 26, 18, 26, 18, 24] });
    for (let r = first; r <= last; r++) {
      putFormula(ws, 5, r, `D${r + 1}*E${r + 1}`, PCT);
      putFormula(ws, 6, r, `C${r + 1}*F${r + 1}`, MONEY);
      const c = ws[A(3, r)]; if (c) c.z = PCT;
      const g = ws[A(2, r)]; if (g) g.z = MONEY;
    }
    const tr = last + 1;
    ws[A(0, tr)] = { t: 's', v: 'TOTAL' };
    putFormula(ws, 2, tr, `SUM(C${first + 1}:C${last + 1})`, MONEY);
    putFormula(ws, 6, tr, `SUM(G${first + 1}:G${last + 1})`, MONEY);
    ws[A(0, tr + 2)] = { t: 's', v: 'Loss allowance per the trial balance' };
    ws[A(6, tr + 2)] = { t: 'n', v: Number(st.config.recordedAllowance) || 0, z: MONEY };
    ws[A(0, tr + 3)] = { t: 's', v: 'Difference — matrix against the ledger' };
    putFormula(ws, 6, tr + 3, `G${tr + 1}-G${tr + 3}`, MONEY);
    ws[A(0, tr + 5)] = { t: 's', v:
      'FRS 109 para B5.5.35 requires loss rates derived from observed history and adjusted for forward-looking information. Record the derivation and the scenarios supporting the multiplier above.' };
    XLSX.utils.book_append_sheet(wb, ws, '07 Supporting Workings');
  }
  if (moduleCode === 'PPE' && st.derived?.totals) {
    const t = st.derived.totals;
    const a = [...hdr(), ['ROLL-FORWARD SUMMARY'], [],
      ['', 'Cost', 'Accumulated depreciation', 'Net book value'],
      ['Opening', t.cost_open, t.accdep_open, null],
      ['Additions / charge for the year', t.additions, t.dep_charge, null],
      ['Disposals', -Math.abs(t.disposals), -Math.abs(t.accdep_disp), null],
      ['Closing', null, null, null], [],
      ['Depreciation per audit', t.expected], ['Depreciation per client', t.dep_charge],
      ['Difference', null]];
    const ws = sheetFrom(a, { widths: [40, 20, 28, 20] });
    const base = 9;  // 0-based row of 'Opening'
    putFormula(ws, 1, base + 3, `SUM(B${base + 1}:B${base + 3})`, MONEY);
    putFormula(ws, 2, base + 3, `SUM(C${base + 1}:C${base + 3})`, MONEY);
    putFormula(ws, 3, base + 3, `B${base + 4}-C${base + 4}`, MONEY);
    for (let r = base; r <= base + 3; r++)
      for (let c = 1; c <= 2; c++) { const x = ws[A(c, r)]; if (x && x.t === 'n') x.z = MONEY; }
    putFormula(ws, 1, base + 7, `B${base + 6}-B${base + 7}`, MONEY);
    XLSX.utils.book_append_sheet(wb, ws, '07 Supporting Workings');
  }

  /* ----------------------------------------------- 08 Adjustments ---- */
  {
    const a = [...hdr(), ['ADJUSTMENTS RAISED'], [],
      ['Ref', 'Account', 'Description', 'Debit', 'Credit', 'From exception']];
    const first = a.length;
    (st.adjustments || []).forEach((j, i) =>
      a.push([j.ref || 'AJE ' + (i + 1), j.account, j.description, j.debit || null, j.credit || null, j.fromException || '']));
    const last = a.length - 1;
    const ws = sheetFrom(a, { widths: [12, 28, 60, 16, 16, 20] });
    if (last >= first) {
      const tr = last + 1;
      ws[A(2, tr)] = { t: 's', v: 'TOTAL' };
      putFormula(ws, 3, tr, `SUM(D${first + 1}:D${last + 1})`, MONEY);
      putFormula(ws, 4, tr, `SUM(E${first + 1}:E${last + 1})`, MONEY);
      ws[A(2, tr + 1)] = { t: 's', v: 'Balance check — must be nil' };
      putFormula(ws, 3, tr + 1, `D${tr + 1}-E${tr + 1}`, MONEY);
    }
    XLSX.utils.book_append_sheet(wb, ws, '08 Adjustments');
  }

  /* --------------------------------------------- 09 AI Analysis ------ */
  {
    const reviewed = (st.aiBlocks || []).filter(b => b.reviewed);
    const a = [...hdr(), ['AI GENERATED ANALYSIS'], [],
      ['Only content the auditor has reviewed and accepted is exported. AI generated content is not audit evidence and is not a conclusion.'], []];
    if (!reviewed.length) a.push(['No reviewed AI analysis for this working paper.']);
    reviewed.forEach(b => {
      a.push([], ['Prompt topic', b.topic], ['Model', b.model],
             ['Generated', b.generatedAt], ['Reviewed by', b.reviewedBy || ''],
             ['AI Generated Analysis. Auditor review and professional judgement required.'],
             ['Original generated text'], [b.original], ['Auditor edited text'], [b.text]);
    });
    XLSX.utils.book_append_sheet(wb, sheetFrom(a, { widths: [30, 110] }), '09 AI Analysis');
  }

  /* ------------------------------------------------ 10 Conclusion ---- */
  {
    const a = [...hdr(), ['CONCLUSION'], [],
      ['Auditor comments'], [st.comments || ''], [],
      ['Conclusion'], [st.conclusion || ''], [],
      ['Matters for the file / points forward'], [st.matters || ''], [],
      ['Cross references out'], [(M.crossRefs || []).join(', ') || ''], [],
      ['Prepared by', eng.preparedBy || '', 'Date', eng.datePrepared || ''],
      ['Reviewed by', eng.reviewedBy || '', 'Date', eng.dateReviewed || '']];
    XLSX.utils.book_append_sheet(wb, sheetFrom(a, { widths: [34, 96, 14, 18] }), '10 Conclusion');
  }

  /* ----------------------------------------------- 11 Audit Trail ---- */
  {
    const a = [...hdr(), ['AUDIT TRAIL'], [], ['Time', 'Event', 'Detail']];
    (st.trail || []).forEach(t => a.push([t.at, t.event, t.detail]));
    XLSX.utils.book_append_sheet(wb, sheetFrom(a, { widths: [24, 34, 110] }), '11 Audit Trail');
  }

  return wb;
}

/* The testing sheet is where the formula policy earns its keep. */
function buildTestingSheet(M, st, eng, prefix) {
  const recs = st.records || [];
  const cleanFirst = st.__cleanFirstRow;                 // 0-based row in 02
  const cols = st.__cleanCols || [];
  const colOf = key => {
    const i = cols.findIndex(f => f.key === key);
    return i < 0 ? null : C(i + 2);                      // +2 for Src row, Category
  };
  const a = [...prefix];

  if (M.code === 'PPE') {
    a.push(['Src row', 'Asset code', 'Description', 'Cost', 'Life (yrs)', 'Months in use',
            'Depreciation per audit', 'Depreciation per client', 'Difference',
            'Threshold', 'Result']);
    const first = a.length;
    recs.forEach(r => a.push([r.__srcRow, r.asset_id, r.description, r.__cost,
      r.__lifeYears, r.__months, null, r.dep_charge, null, null, null]));
    const last = a.length - 1;
    const ws = sheetFrom(a, { widths: [10, 18, 44, 16, 12, 14, 22, 22, 16, 14, 26] });
    const tol = st.config.depTol > 0 ? st.config.depTol : (eng.materiality?.trivial || 1);
    for (let i = 0; i < recs.length; i++) {
      const r = first + i, x = r + 1;
      /* cost / life x months / 12, capped at cost less accumulated depreciation */
      putFormula(ws, 6, r, `IF(E${x}=0,0,MIN(D${x}/E${x}*F${x}/12,D${x}))`, MONEY);
      putFormula(ws, 8, r, `H${x}-G${x}`, MONEY);
      ws[A(9, r)] = { t: 'n', v: tol, z: MONEY };
      ws[A(10, r)] = { t: 's', f: `IF(ABS(I${x})>J${x},"Exception","Within threshold")` };
      [3, 7].forEach(c => { const cc = ws[A(c, r)]; if (cc && cc.t === 'n') cc.z = MONEY; });
    }
    const tr = last + 1;
    ws[A(2, tr)] = { t: 's', v: 'TOTAL' };
    [3, 6, 7, 8].forEach(c => putFormula(ws, c, tr, `SUM(${C(c)}${first + 1}:${C(c)}${last + 1})`, MONEY));
    ws[A(2, tr + 2)] = { t: 's', v: 'Exceptions raised' };
    putFormula(ws, 3, tr + 2, `COUNTIF(K${first + 1}:K${last + 1},"Exception")`);
    return ws;
  }

  if (M.code === 'AR') {
    a.push(['Src row', 'Customer', 'Invoice', 'Invoice date', 'Due date', 'Days overdue',
            'Bucket', 'Amount', 'ECL rate', 'Expected credit loss']);
    const first = a.length;
    recs.forEach(r => a.push([r.__srcRow, r.cust_name, r.invoice_no,
      r.invoice_date ? Core.fmtDate(r.invoice_date) : '', r.__due ? Core.fmtDate(r.__due) : '',
      r.__daysOverdue, r.__bucketLabel, r.amount, r.__eclRate, null]));
    const last = a.length - 1;
    const ws = sheetFrom(a, { widths: [10, 40, 18, 14, 14, 14, 18, 18, 12, 22] });
    for (let i = 0; i < recs.length; i++) {
      const r = first + i, x = r + 1;
      putFormula(ws, 9, r, `H${x}*I${x}`, MONEY);
      const am = ws[A(7, r)]; if (am && am.t === 'n') am.z = MONEY;
      const rt = ws[A(8, r)]; if (rt && rt.t === 'n') rt.z = PCT;
    }
    const tr = last + 1;
    ws[A(1, tr)] = { t: 's', v: 'TOTAL' };
    putFormula(ws, 7, tr, `SUM(H${first + 1}:H${last + 1})`, MONEY);
    putFormula(ws, 9, tr, `SUM(J${first + 1}:J${last + 1})`, MONEY);
    ws[A(1, tr + 2)] = { t: 's', v: 'Loss allowance per the trial balance' };
    ws[A(9, tr + 2)] = { t: 'n', v: Number(st.config.recordedAllowance) || 0, z: MONEY };
    ws[A(1, tr + 3)] = { t: 's', v: 'Difference' };
    putFormula(ws, 9, tr + 3, `J${tr + 1}-J${tr + 3}`, MONEY);
    return ws;
  }

  /* generic: mapped fields with a cast on the numeric columns */
  const flds = M.fields.filter(f => st.mapping[f.key]);
  a.push(['Src row', ...flds.map(f => f.label)]);
  const first = a.length;
  recs.forEach(r => a.push([r.__srcRow, ...flds.map(f =>
    r[f.key] instanceof Date ? Core.fmtDate(r[f.key]) : r[f.key])]));
  const last = a.length - 1;
  const ws = sheetFrom(a, { widths: [10, ...flds.map(() => 20)] });
  const tr = last + 1;
  ws[A(0, tr)] = { t: 's', v: 'TOTAL' };
  flds.forEach((f, i) => { if (f.type === 'number')
    putFormula(ws, i + 1, tr, `SUM(${C(i + 1)}${first + 1}:${C(i + 1)}${last + 1})`, MONEY); });
  return ws;
}

function sevLabel(s) {
  return { 'above-pm':'Above performance materiality', 'above-trivial':'Above trivial threshold',
           'below-trivial':'Below trivial threshold', 'informational':'Informational' }[s] || s;
}

function download(state, moduleCode) {
  const wb = build(state, moduleCode);
  const eng = state.engagement;
  const safe = s => (s || '').replace(/[^\w\- ]+/g, '').trim().slice(0, 40) || 'Engagement';
  const name = `${moduleCode} Working Paper — ${safe(eng.client)} — ${safe(eng.yearEnd)}.xlsx`;
  StyledXLSX.writeFile(wb, name);      /* our own writer: SheetJS's free build drops every style */
  return name;
}

return { build, download, sevLabel };
})();
