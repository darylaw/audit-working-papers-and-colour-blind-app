/* ==========================================================================
   xlsxfile.js -- the audit-file workbook: one sheet per working paper.

   Every schedule references the cleaned listing sheet by SUMIF on category,
   and every per-asset recalculation is a live formula, so a reviewer who
   changes a useful life or a cost on '02 Cleaned listing' watches E3, E3.1
   and E3.2 move.
   ========================================================================== */

const FileExporter = (() => {
const C = XLSX.utils.encode_col;
const A = (c, r) => C(c) + (r + 1);
const MONEY = '#,##0.00;[Red](#,##0.00)';
const PCT = '0.00%';

function sheetFrom(aoa, opts = {}) {
  const ws = XLSX.utils.aoa_to_sheet(aoa, { cellDates: true });
  if (opts.merges) ws['!merges'] = opts.merges;
  return ws;
}
function putFormula(ws, col, row, f, numFmt) {
  const ref = A(col, row);
  ws[ref] = { t: 'n', f };
  if (numFmt) ws[ref].z = numFmt;
  const rng = XLSX.utils.decode_range(ws['!ref'] || 'A1');
  rng.e.c = Math.max(rng.e.c, col); rng.e.r = Math.max(rng.e.r, row);
  ws['!ref'] = XLSX.utils.encode_range(rng);
}
function putText(ws, col, row, v) {
  ws[A(col, row)] = { t: 's', v };
  const rng = XLSX.utils.decode_range(ws['!ref'] || 'A1');
  rng.e.c = Math.max(rng.e.c, col); rng.e.r = Math.max(rng.e.r, row);
  ws['!ref'] = XLSX.utils.encode_range(rng);
}
const moneyFmt = c => { if (c && c.t === 'n') c.z = MONEY; };
const sevLabel = s => ({ 'above-pm':'Above performance materiality', 'above-trivial':'Above trivial threshold',
  'below-trivial':'Below trivial threshold', 'informational':'Informational' }[s] || s);

function build(state, moduleCode) {
  const M = Modules.byCode[moduleCode];
  if (M.pages.some(p => p.render)) return buildSpecFile(state, moduleCode);
  const st = state.modules[moduleCode];
  const eng = state.engagement;
  const d = st.derived || {};
  const cfg = st.config;
  const wb = XLSX.utils.book_new();
  const stamp = new Date().toISOString().replace('T', ' ').slice(0, 19);
  const recs = (st.records || []).filter(r => !r.__excluded);
  const D = v => v instanceof Date ? Core.fmtDate(v) : v;
  const pn = id => st.pageNotes?.[id] || {};
  const page = id => M.pages.find(p => p.id === id);

  /* Standard header block on every working paper. */
  const head = (a, pg) => {
    a.push(['Client', eng.client || '', '', 'Prepared by', eng.preparedBy || '', 'Date', eng.datePrepared || '']);
    a.push(['Year end', eng.yearEnd || '', '', 'Reviewed by', eng.reviewedBy || '', 'Date', eng.dateReviewed || '']);
    a.push(['WP ref', pg.ref, '', 'Subject', `${M.name} — ${pg.title}`]);
    a.push([]);
    if (pg.objective) a.push(['Objective', pg.objective]);
    (pg.procedures || []).forEach((p, i) => a.push([i === 0 ? 'Procedures' : '', `${i + 1}. ${p}`]));
    a.push([]);
  };
  const foot = (a, id) => {
    a.push([]);
    a.push(['Tickmarks', 'TB agreed to trial balance · PY agreed to prior year audited · ^ cast · vINV vouched to invoice · R recalculated · i/m immaterial']);
    a.push([]); a.push(['Findings and notes', pn(id).notes || '']); a.push(['Conclusion', pn(id).conclusion || '']);
  };

  /* ---------------------------------------------------------- 00 Index */
  {
    const a = [['PROPERTY, PLANT AND EQUIPMENT — AUDIT FILE INDEX'], [],
      ['Client', eng.client || ''], ['Year end', eng.yearEnd || ''], ['File reference', eng.indexRef?.PPE || 'E3'], ['Exported', stamp], [],
      ['Materiality'], ['Overall', eng.materiality.om || 0], ['Performance', eng.materiality.pm || 0], ['Trivial', eng.materiality.trivial || 0], [],
      ['Ref', 'Working paper', 'Status', 'Conclusion']];
    M.pages.forEach(p => a.push([p.ref, p.title, pn(p.id).conclusion ? 'Concluded' : 'Open', pn(p.id).conclusion || '']));
    a.push([], ['Overall conclusion', st.conclusion || ''], ['Auditor comments', st.comments || '']);
    XLSX.utils.book_append_sheet(wb, sheetFrom(a, { widths: [16, 40, 14, 90] }), '00 Index');
  }

  /* ---------------------------------------------------- 02 Cleaned listing
     Written first: every other sheet's formulas point here.               */
  const L = {};
  let listFirst, listLast;
  {
    const cols = ['Src row', 'Asset code', 'Category', 'Description', 'Acquired', 'Life (yrs)', 'Method',
      'Cost b/f', 'Additions', 'Disposals', 'Cost c/f', 'Acc dep b/f', 'Charge', 'Acc dep disposals', 'Acc dep c/f',
      'NBV b/f', 'NBV c/f', 'Months in use', 'Life used (yrs)', 'Depn per audit', 'Difference', 'Supplier', 'Excluded', 'Flags'];
    ['src','id','cat','desc','acq','life','method','co','add','disp','cc','do','chg','dd','dc','nbvo','nbvc','months','lifeUsed','exp','diff','sup','excl','flags']
      .forEach((k, i) => L[k] = C(i));
    const a = [['CLEANED LISTING — STANDARD FORMAT'], ['Client', eng.client || '', '', 'Life column read as', d.lifeUnit || ''], [], cols];
    listFirst = a.length;
    (st.records || []).forEach(r => a.push([r.__srcRow, r.asset_id, r.category, r.description, D(r.acq_date), r.__lifeYears || null, r.method,
      r.cost_open, r.additions, r.disposals, null, r.accdep_open, r.dep_charge, r.accdep_disp, null, null, null,
      r.__months, r.__lifeUsed || null, null, null, r.supplier, r.__excluded ? 'Excluded: ' + (r.__excludeReason || '') : '',
      (r.__flags || []).map(f => f.rule).join(' ')]));
    listLast = a.length - 1;
    const ws = sheetFrom(a, { widths: [8, 14, 22, 40, 12, 9, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 9, 9, 14, 14, 26, 22, 18] });
    for (let r = listFirst; r <= listLast; r++) {
      const x = r + 1;
      putFormula(ws, 10, r, `${L.co}${x}+${L.add}${x}-${L.disp}${x}`, MONEY);
      putFormula(ws, 14, r, `${L.do}${x}+${L.chg}${x}-${L.dd}${x}`, MONEY);
      putFormula(ws, 15, r, `${L.co}${x}-${L.do}${x}`, MONEY);
      putFormula(ws, 16, r, `${L.cc}${x}-${L.dc}${x}`, MONEY);
      putFormula(ws, 19, r,
        `IF(OR(${L.lifeUsed}${x}=0,${L.lifeUsed}${x}=""),0,MIN((${L.co}${x}+${L.add}${x})/${L.lifeUsed}${x}*${L.months}${x}/12,MAX(0,${L.co}${x}+${L.add}${x}-${L.do}${x})))`, MONEY);
      putFormula(ws, 20, r, `${L.chg}${x}-${L.exp}${x}`, MONEY);
      [7, 8, 9, 11, 12, 13].forEach(c => moneyFmt(ws[A(c, r)]));
    }
    const tr = listLast + 1;
    putText(ws, 3, tr, 'TOTAL');
    [7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 19, 20].forEach(c => putFormula(ws, c, tr, `SUM(${C(c)}${listFirst + 1}:${C(c)}${listLast + 1})`, MONEY));
    XLSX.utils.book_append_sheet(wb, ws, '02 Cleaned listing');
  }
  const LIST = `'02 Cleaned listing'`;
  const rng = k => `${LIST}!$${L[k]}$${listFirst + 1}:$${L[k]}$${listLast + 1}`;
  const catRng = rng('cat');

  /* ------------------------------------------------------------ E3 Lead */
  {
    const a = []; head(a, page('lead'));
    a.push(['', 'Per listing', '', '', 'Per trial balance', '', '', 'Difference', '', 'Prior year audited', '', '', 'Movement', '']);
    a.push(['Category', 'Cost', 'Acc dep', 'NBV', 'Cost', 'Acc dep', 'NBV', 'Cost', 'Acc dep', 'Cost', 'Acc dep', 'NBV', 'Variance', '%']);
    const first = a.length;
    (d.lead || []).forEach(l => {
      const py = cfg.py[l.category] || {};
      a.push([l.category, null, null, null, l.tbCost, l.tbDep, null, null, null,
        py.cost !== '' && py.cost != null ? Number(py.cost) : null,
        py.accdep !== '' && py.accdep != null ? Math.abs(Number(py.accdep)) : null, null, null, null]);
    });
    const last = a.length - 1;
    const ws = sheetFrom(a, { widths: [26, 16, 16, 16, 16, 16, 16, 14, 14, 16, 16, 16, 16, 9] });
    for (let r = first; r <= last; r++) {
      const x = r + 1;
      putFormula(ws, 1, r, `SUMIF(${catRng},$A${x},${rng('cc')})`, MONEY);
      putFormula(ws, 2, r, `SUMIF(${catRng},$A${x},${rng('dc')})`, MONEY);
      putFormula(ws, 3, r, `B${x}-C${x}`, MONEY);
      putFormula(ws, 6, r, `IF(AND(E${x}="",F${x}=""),"",E${x}-F${x})`, MONEY);
      putFormula(ws, 7, r, `IF(E${x}="","",B${x}-E${x})`, MONEY);
      putFormula(ws, 8, r, `IF(F${x}="","",C${x}-F${x})`, MONEY);
      putFormula(ws, 11, r, `IF(AND(J${x}="",K${x}=""),"",J${x}-K${x})`, MONEY);
      putFormula(ws, 12, r, `IF(L${x}="","",D${x}-L${x})`, MONEY);
      putFormula(ws, 13, r, `IF(OR(L${x}="",L${x}=0),"",M${x}/ABS(L${x}))`, PCT);
      [4, 5, 9, 10].forEach(c => moneyFmt(ws[A(c, r)]));
    }
    const tr = last + 1;
    putText(ws, 0, tr, 'TOTAL');
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].forEach(c => putFormula(ws, c, tr, `SUM(${C(c)}${first + 1}:${C(c)}${last + 1})`, MONEY));
    const a2 = [[], ['Variances are reported where they exceed performance materiality of', eng.materiality.pm || 0, 'and 10%']];
    foot(a2, 'lead');
    XLSX.utils.sheet_add_aoa(ws, a2, { origin: tr + 1 });
    XLSX.utils.book_append_sheet(wb, ws, 'E3 Lead');
  }

  /* ----------------------------------------------------- E3.1 Movement */
  {
    const cats = (d.byCategory || []).map(c => c.category);
    const n = cats.length;
    const a = []; head(a, page('movement'));
    a.push(['', ...cats, 'Total']);
    const hdrRow = a.length - 1;
    const lines = [['Cost', null], ['Balance brought forward', 'co'], ['Additions', 'add'], ['Disposals', 'disp', -1], ['Balance carried forward', 'sum:cost'],
      ['Accumulated depreciation', null], ['Balance brought forward', 'do'], ['Charge for the year', 'chg'], ['Disposals', 'dd', -1], ['Balance carried forward', 'sum:dep'],
      ['Net book value', null], ['At beginning of year', 'nbv:o'], ['At end of year', 'nbv:c']];
    const rowOf = {};
    lines.forEach(([label, key]) => { if (key) rowOf[key] = a.length; a.push([label]); });
    const ws = sheetFrom(a, { widths: [34, ...cats.map(() => 18), 18] });
    lines.forEach(([label, key, sign]) => {
      if (!key) return;
      const r = rowOf[key];
      cats.forEach((cat, i) => {
        const col = i + 1, catCell = `${C(col)}$${hdrRow + 1}`;
        let f;
        if (key === 'sum:cost') f = `${C(col)}${rowOf.co + 1}+${C(col)}${rowOf.add + 1}+${C(col)}${rowOf.disp + 1}`;
        else if (key === 'sum:dep') f = `${C(col)}${rowOf.do + 1}+${C(col)}${rowOf.chg + 1}+${C(col)}${rowOf.dd + 1}`;
        else if (key === 'nbv:o') f = `${C(col)}${rowOf.co + 1}-${C(col)}${rowOf.do + 1}`;
        else if (key === 'nbv:c') f = `${C(col)}${rowOf['sum:cost'] + 1}-${C(col)}${rowOf['sum:dep'] + 1}`;
        else f = `${sign === -1 ? '-' : ''}SUMIF(${catRng},${catCell},${rng(key)})`;
        putFormula(ws, col, r, f, MONEY);
      });
      putFormula(ws, n + 1, r, `SUM(B${r + 1}:${C(n)}${r + 1})`, MONEY);
    });
    let r0 = a.length + 1;
    putText(ws, 0, r0, 'Cast check — cost c/f per listing less roll-forward');
    putFormula(ws, n + 1, r0, `SUM(${rng('cc')})-${C(n + 1)}${rowOf['sum:cost'] + 1}`, MONEY);
    putText(ws, 0, r0 + 1, 'Cast check — acc dep c/f per listing less roll-forward');
    putFormula(ws, n + 1, r0 + 1, `SUM(${rng('dc')})-${C(n + 1)}${rowOf['sum:dep'] + 1}`, MONEY);
    const a2 = []; foot(a2, 'movement');
    XLSX.utils.sheet_add_aoa(ws, a2, { origin: r0 + 3 });
    XLSX.utils.book_append_sheet(wb, ws, 'E3.1 Movement');
  }

  /* ------------------------------------------------- E3.2 Depreciation */
  {
    const a = []; head(a, page('depreciation'));
    const tol = cfg.depTol > 0 ? cfg.depTol : (eng.materiality.trivial || 0);
    a.push(['Convention', (M.CONVENTIONS.find(c => c.key === cfg.convention) || {}).label || cfg.convention]);
    a.push(['Recalculated using', cfg.recalcBasis === 'policy' ? 'Category policy life' : 'Each asset\'s stated life']);
    a.push(['Threshold per asset', tol]);
    const pnlRow = a.length;
    a.push(['Depreciation per P&L', d.pnlDepreciation ?? '']);
    a.push([]);
    a.push(['By category']);
    a.push(['Category', 'Assets', 'Cost c/f', 'Policy life (yrs)', 'Depreciation per audit', 'Depreciation per client', 'Difference', 'Result']);
    const first = a.length;
    (d.byCategory || []).forEach(c => a.push([c.category, null, null, cfg.lifePolicy[c.category] ?? '', null, null, null, null]));
    const last = a.length - 1;
    const ws = sheetFrom(a, { widths: [28, 10, 18, 16, 22, 22, 18, 20] });
    for (let r = first; r <= last; r++) {
      const x = r + 1;
      putFormula(ws, 1, r, `COUNTIF(${catRng},$A${x})`);
      putFormula(ws, 2, r, `SUMIF(${catRng},$A${x},${rng('cc')})`, MONEY);
      putFormula(ws, 4, r, `SUMIF(${catRng},$A${x},${rng('exp')})`, MONEY);
      putFormula(ws, 5, r, `SUMIF(${catRng},$A${x},${rng('chg')})`, MONEY);
      putFormula(ws, 6, r, `F${x}-E${x}`, MONEY);
      ws[A(7, r)] = { t: 's', f: `IF(ABS(G${x})>${tol},"Investigate","i/m")` };
    }
    const tr = last + 1;
    putText(ws, 0, tr, 'TOTAL');
    putFormula(ws, 1, tr, `SUM(B${first + 1}:B${last + 1})`);
    [2, 4, 5, 6].forEach(c => putFormula(ws, c, tr, `SUM(${C(c)}${first + 1}:${C(c)}${last + 1})`, MONEY));
    putText(ws, 0, tr + 2, 'Listing vs P&L');
    putFormula(ws, 6, tr + 2, `IF(B${pnlRow + 1}="","",F${tr + 1}-B${pnlRow + 1})`, MONEY);
    const a2 = [[], ['Per-asset recalculation is on 02 Cleaned listing. Assets above the threshold:'], [],
      ['Asset', 'Description', 'Category', 'Life used', 'Months', 'Per audit', 'Per client', 'Difference']];
    recs.filter(r => Math.abs(r.__depDiff || 0) > tol).sort((x, y) => Math.abs(y.__depDiff) - Math.abs(x.__depDiff))
      .forEach(r => a2.push([r.asset_id, r.description, r.category, r.__lifeUsed, r.__months, r.__expectedDep, r.dep_charge, r.__depDiff]));
    foot(a2, 'depreciation');
    XLSX.utils.sheet_add_aoa(ws, a2, { origin: tr + 4 });
    XLSX.utils.book_append_sheet(wb, ws, 'E3.2 Depreciation');
  }

  /* ---------------------------------------------------- E3.3 Additions */
  {
    const Ad = d.additions || { key: [], sample: [], residual: [], all: [] };
    const a = []; head(a, page('additions'));
    a.push(['Testing threshold', Ad.threshold], ['Random sample size', cfg.addSampleN || 0], ['Sample seed', Ad.seed],
      ['Additions in year', Ad.all.length, Ad.total], ['Key items at or above threshold', Ad.key.length, Ad.keyValue],
      ['Random sample', Ad.sample.length, Ad.sampleValue], ['Coverage', (Ad.coverage || 0) / 100], []);
    a.push(['Basis', 'Asset', 'Description', 'Category', 'Date per listing', 'Amount per listing', 'Invoice no', 'Invoice date', 'Supplier per invoice', 'Amount per invoice', 'Difference', 'Capitalise?', 'Right period?', 'Comment', 'Tickmark']);
    const first = a.length;
    const sel = recs.filter(r => r.__addSelected).sort((x, y) => (x.__addSelected === y.__addSelected ? 0 : x.__addSelected === 'key' ? -1 : 1) || (y.additions - x.additions));
    sel.forEach(r => { const v = r.__vouch || {};
      a.push([r.__addSelected === 'key' ? 'Key item' : 'Sample', r.asset_id, r.description, r.category, D(r.acq_date), r.additions,
        v.invNo || '', v.invDate || '', v.supplier || '', v.amtInv !== '' && v.amtInv != null ? Number(v.amtInv) : null, null, v.capOk || '', v.periodOk || '', v.note || '', null]); });
    const last = a.length - 1;
    const ws = sheetFrom(a, { widths: [10, 14, 40, 22, 14, 16, 16, 14, 30, 16, 14, 12, 12, 30, 10] });
    for (let r = first; r <= last; r++) {
      const x = r + 1;
      putFormula(ws, 10, r, `IF(J${x}="","",F${x}-J${x})`, MONEY);
      ws[A(14, r)] = { t: 's', f: `IF(AND(J${x}<>"",ABS(K${x})<0.01,L${x}="Y",M${x}="Y"),"vINV","")` };
      moneyFmt(ws[A(5, r)]); moneyFmt(ws[A(9, r)]);
    }
    let next = first;
    if (last >= first) { next = last + 1; putText(ws, 2, next, 'TOTAL tested'); putFormula(ws, 5, next, `SUM(F${first + 1}:F${last + 1})`, MONEY); putFormula(ws, 9, next, `SUM(J${first + 1}:J${last + 1})`, MONEY); next += 2; }
    const a2 = [['Untested additions below the threshold'], ['Asset', 'Description', 'Category', 'Date', 'Amount']];
    Ad.residual.filter(r => !Ad.sample.includes(r)).forEach(r => a2.push([r.asset_id, r.description, r.category, D(r.acq_date), r.additions]));
    foot(a2, 'additions');
    XLSX.utils.sheet_add_aoa(ws, a2, { origin: next });
    XLSX.utils.book_append_sheet(wb, ws, 'E3.3 Additions');
  }

  /* ---------------------------------------------------- E3.4 Disposals */
  {
    const a = []; head(a, page('disposals'));
    a.push(['Asset', 'Description', 'Category', 'Acquired', 'Cost disposed', 'Acc dep written back', 'NBV disposed', 'Proceeds', 'Gain / (loss) per audit', 'Per client', 'Difference', 'Authorised?', 'Comment']);
    const first = a.length;
    (d.disposals || []).forEach(x => { const r = x.r, v = r.__disp || {};
      a.push([r.asset_id, r.description, r.category, D(r.acq_date), r.disposals, r.accdep_disp, null,
        v.proceeds !== '' && v.proceeds != null ? Number(v.proceeds) : null, null,
        v.perClient !== '' && v.perClient != null ? Number(v.perClient) : null, null, v.auth || '', v.note || '']); });
    const last = a.length - 1;
    const ws = sheetFrom(a, { widths: [14, 40, 22, 12, 16, 18, 16, 16, 20, 16, 14, 12, 30] });
    for (let r = first; r <= last; r++) {
      const x = r + 1;
      putFormula(ws, 6, r, `E${x}-F${x}`, MONEY);
      putFormula(ws, 8, r, `IF(H${x}="","",H${x}-G${x})`, MONEY);
      putFormula(ws, 10, r, `IF(OR(H${x}="",J${x}=""),"",I${x}-J${x})`, MONEY);
      [4, 5, 7, 9].forEach(c => moneyFmt(ws[A(c, r)]));
    }
    let next;
    if (last >= first) { next = last + 1; putText(ws, 0, next, 'TOTAL'); [4, 5, 6, 7, 8].forEach(c => putFormula(ws, c, next, `SUM(${C(c)}${first + 1}:${C(c)}${last + 1})`, MONEY)); next += 2; }
    else { putText(ws, 0, first, 'No disposals in the year per the listing. Management enquiry documented in the notes.'); next = first + 2; }
    const a2 = []; foot(a2, 'disposals');
    XLSX.utils.sheet_add_aoa(ws, a2, { origin: next });
    XLSX.utils.book_append_sheet(wb, ws, 'E3.4 Disposals');
  }

  /* --------------------------------------------------- E3.5 Impairment */
  {
    const I = d.impairment || { candidates: [] };
    const a = []; head(a, page('impairment'));
    a.push(['A. Indicator assessment — FRS 36 paragraph 12'], ['Ref', 'Source', 'Indicator', 'Present?', 'Categories affected', 'Management response / evidence']);
    M.INDICATORS.forEach(ind => { const ans = cfg.indicators[ind.id] || {};
      a.push([ind.id, ind.src, ind.text, ans.answer || '', (ans.categories || []).join(', ') || (ans.answer === 'Y' ? 'All' : ''), ans.comment || '']); });
    a.push([], ['B. Candidate identification rules applied'], ['Rule', 'Enabled', 'Description']);
    M.CANDIDATE_RULES.forEach(r => a.push([r.id, cfg.rules[r.id] !== false ? 'Yes' : 'No', r.label + ' — ' + r.why]));
    a.push([], ['C. Assets requiring assessment'], ['Candidates', I.candidates.length, 'Carrying amount in scope', I.candidateValue, 'Share of NBV', (I.coverage || 0) / 100]);
    a.push(['Asset', 'Description', 'Category', 'NBV', 'Identified by', 'Work done', 'Work to be done', 'Status', 'Auditor notes', 'Conclusion']);
    I.candidates.forEach(c => { const r = c.r, v = r.__imp || {};
      const defs = c.rules.map(id => M.CANDIDATE_RULES.find(x => x.id === id));
      a.push([r.asset_id, r.description, r.category, r.__nbv_close, c.rules.join(', '),
        'Identified from the cleaned listing: ' + defs.map(x => x.label).join('; ') + '. Carrying amount, age and charge recalculated (E3.2).',
        defs.map(x => x.todo).join(' | '), v.status || '', v.note || '', v.conclusion || '']); });
    foot(a, 'impairment');
    XLSX.utils.book_append_sheet(wb, sheetFrom(a, { widths: [14, 40, 22, 16, 14, 60, 70, 18, 40, 22] }), 'E3.5 Impairment');
  }

  /* --------------------------------------------------- E3.9 Exceptions */
  {
    const a = [['EXCEPTION REGISTER AND CONCLUSION'], [],
      ['ID', 'Exception', 'Record', 'Src row', 'Cell', 'Expected', 'Actual', 'Difference', 'Severity', 'WP', 'Detail', 'Disposition', 'Reason']];
    const first = a.length;
    (st.exceptions || []).forEach(e => a.push([e.id, e.label, String(e.recordKey ?? ''), e.srcRow || '', e.cell || '',
      typeof e.expected === 'number' ? e.expected : (e.expected ?? ''), typeof e.actual === 'number' ? e.actual : (e.actual ?? ''),
      e.difference ?? '', sevLabel(e.severity), e.basis, e.detail, e.disposition, e.reason || '']));
    const last = a.length - 1;
    a.push([], ['Auditor comments', st.comments || ''], ['Overall conclusion', st.conclusion || '']);
    const ws = sheetFrom(a, { widths: [14, 46, 30, 8, 8, 15, 15, 15, 24, 8, 46, 14, 30] });
    if (last >= first) { putText(ws, 1, last + 1, 'Total difference on open exceptions'); putFormula(ws, 7, last + 1, `SUMIF(L${first + 1}:L${last + 1},"open",H${first + 1}:H${last + 1})`, MONEY); }
    XLSX.utils.book_append_sheet(wb, ws, 'E3.9 Exceptions');
  }

  /* -------------------------------------------------------- 01 Source */
  (st.sources || []).forEach((s, i) => {
    const a = [['SOURCE DATA — PRESERVED AS RECEIVED. Values only.'], ['File', s.fileName], ['Sheet', s.sheetName], ['Hash', s.hash],
      ['Uploaded', s.uploadedAt], ['Header row detected', s.headerRow + 1], [], ...s.rawRows.map(r => (r || []).map(D))];
    XLSX.utils.book_append_sheet(wb, sheetFrom(a, { widths: new Array(20).fill(16) }), ('01 Source ' + (i + 1)).slice(0, 31));
  });

  /* ------------------------------------------------- 03..06 supporting */
  {
    const a = [['COLUMN MAPPING'], [], ['Field', 'Required', 'Source column', 'Source heading', 'Block', 'Match basis', 'Confidence']];
    M.fields.forEach(f => { const m = st.mapping[f.key];
      a.push([f.label, f.required ? 'Yes' : 'No', m ? m.letter : '— not mapped —',
        m ? m.heading : (f.satisfiedByGroup && st.clean?.hasGroups ? '(from group header rows)' : ''), m ? m.block : '', m ? m.basis : '', m ? m.confidence : '']); });
    XLSX.utils.book_append_sheet(wb, sheetFrom(a, { widths: [30, 10, 14, 36, 16, 26, 12] }), '03 Mapping');
    const b = [['CLEANING LOG'], [], ['Rule', 'Source row', 'Detail']];
    (st.cleanLog || []).forEach(l => b.push([l.rule, l.row || '', l.detail]));
    (st.mapIssues || []).forEach(l => b.push([l.rule, '', l.detail]));
    XLSX.utils.book_append_sheet(wb, sheetFrom(b, { widths: [10, 10, 110] }), '04 Cleaning log');
    const c = [['AUDITOR CORRECTIONS TO THE LISTING'], [], ['Source row', 'Field', 'From', 'To', 'Reason']];
    (st.edits || []).forEach(e => c.push([e.srcRow, e.field, D(e.from), D(e.to), e.reason]));
    if (!(st.edits || []).length) c.push(['No corrections made.']);
    XLSX.utils.book_append_sheet(wb, sheetFrom(c, { widths: [10, 16, 18, 18, 60] }), '05 Corrections');
    const t = [['AUDIT TRAIL'], [], ['Time', 'Event', 'Detail']];
    (st.trail || []).forEach(x => t.push([x.at, x.event, x.detail]));
    XLSX.utils.book_append_sheet(wb, sheetFrom(t, { widths: [22, 30, 110] }), '06 Audit trail');
  }
  return wb;
}

/* ====================================================================== */
/* Generic audit file for declarative modules: one sheet per spec page.   */
function buildSpecFile(state, moduleCode) {
  const M = Modules.byCode[moduleCode];
  const st = state.modules[moduleCode];
  const eng = state.engagement;
  const wb = XLSX.utils.book_new();
  const stamp = new Date().toISOString().replace('T', ' ').slice(0, 19);
  const D = v => v instanceof Date ? Core.fmtDate(v) : v;
  const pn = id => st.pageNotes?.[id] || {};
  const ctx = { eng, cfg: st.config, d: st.derived, recs: (st.records || []).filter(r => !r.__excluded), all: st.records || [],
    money: n => n, money0: n => n, pct: n => n, fmtDate: Core.fmtDate, r2: n => n == null ? null : Math.round(n * 100) / 100,
    pm: eng.materiality.pm || 0, trivial: eng.materiality.trivial || 0, M };
  const head = (a, pg) => {
    a.push(['Client', eng.client || '', '', 'Prepared by', eng.preparedBy || '', 'Date', eng.datePrepared || '']);
    a.push(['Year end', eng.yearEnd || '', '', 'Reviewed by', eng.reviewedBy || '', 'Date', eng.dateReviewed || '']);
    a.push(['WP ref', pg.ref, '', 'Subject', `${M.name} — ${pg.title}`]); a.push([]);
    if (pg.objective) a.push(['Objective', pg.objective]);
    (pg.procedures || []).forEach((p, i) => a.push([i === 0 ? 'Procedures' : '', `${i + 1}. ${p}`])); a.push([]);
  };
  const foot = (a, id) => { a.push([]); a.push(['Tickmarks', 'TB agreed to trial balance · PY agreed to prior year audited · ^ cast · v vouched · R recalculated · i/m immaterial']);
    a.push([]); a.push(['Findings and notes', pn(id).notes || '']); a.push(['Conclusion', pn(id).conclusion || '']); };

  const idx = [[`${M.name.toUpperCase()} — AUDIT FILE INDEX`], [], ['Client', eng.client || ''], ['Year end', eng.yearEnd || ''],
    ['File reference', eng.indexRef?.[M.code] || M.code], ['Exported', stamp], [], ['Materiality'], ['Overall', eng.materiality.om || 0],
    ['Performance', eng.materiality.pm || 0], ['Trivial', eng.materiality.trivial || 0], [], ['Ref', 'Working paper', 'Status', 'Conclusion']];
  M.pages.forEach(p => idx.push([p.ref, p.title, pn(p.id).conclusion ? 'Concluded' : 'Open', pn(p.id).conclusion || '']));
  idx.push([], ['Overall conclusion', st.conclusion || ''], ['Auditor comments', st.comments || '']);
  XLSX.utils.book_append_sheet(wb, sheetFrom(idx, { widths: [16, 40, 14, 90] }), '00 Index');

  const used = new Set(['00 Index']);
  const name = s => { let n = s.replace(/[\[\]\*\?\/\\:]/g, '').slice(0, 31); let i = 2; while (used.has(n)) n = (s.slice(0, 28) + ' ' + i++).slice(0, 31); used.add(n); return n; };

  for (const pg of M.pages) {
    if (!pg.render) continue;
    const a = []; head(a, pg);
    let specs = [];
    try { specs = pg.render(st, ctx); } catch (e) { specs = [{ type: 'note', html: 'Could not render: ' + e.message }]; }
    const offset = a.length;
    // Generate references at their final worksheet rows, after the paper header.
    const { a: rows, ops } = SpecXL.toRows(specs, pg.id, st, offset);
    a.push(...rows); foot(a, pg.id);
    const ws = sheetFrom(a, { widths: [26, 34, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18] });
    SpecXL.apply(ws, ops, offset);
    XLSX.utils.book_append_sheet(wb, ws, name(`${pg.ref} ${pg.title}`));
  }

  { const a = [['EXCEPTION REGISTER'], [], ['ID', 'Exception', 'Record', 'Src row', 'Cell', 'Expected', 'Actual', 'Difference', 'Severity', 'WP', 'Detail', 'Disposition', 'Reason']];
    (st.exceptions || []).forEach(e => a.push([e.id, e.label, String(e.recordKey ?? ''), e.srcRow || '', e.cell || '', typeof e.expected === 'number' ? e.expected : (e.expected ?? ''), typeof e.actual === 'number' ? e.actual : (e.actual ?? ''), e.difference ?? '', sevLabel(e.severity), e.basis, e.detail, e.disposition, e.reason || '']));
    a.push([], ['Auditor comments', st.comments || ''], ['Overall conclusion', st.conclusion || '']);
    XLSX.utils.book_append_sheet(wb, sheetFrom(a, { widths: [14, 46, 30, 8, 8, 15, 15, 15, 24, 8, 46, 14, 30] }), name('Exceptions')); }
  (st.sources || []).forEach((s, i) => XLSX.utils.book_append_sheet(wb, sheetFrom([['SOURCE DATA — PRESERVED AS RECEIVED. Values only.'], ['File', s.fileName], ['Sheet', s.sheetName], ['Hash', s.hash], ['Uploaded', s.uploadedAt], ['Header row detected', s.headerRow + 1], [], ...s.rawRows.map(r => (r || []).map(D))], { widths: new Array(20).fill(16) }), name('01 Source ' + (i + 1))));
  { const cols = M.fields.filter(f => st.mapping[f.key]); const a = [['CLEANED DATA — STANDARD FORMAT'], [], ['Src row', ...cols.map(f => f.label), 'Excluded', 'Flags']];
    (st.records || []).forEach(r => a.push([r.__srcRow, ...cols.map(f => D(r[f.key])), r.__excluded ? 'Excluded: ' + (r.__excludeReason || '') : '', (r.__flags || []).map(f => f.rule).join(' ')]));
    XLSX.utils.book_append_sheet(wb, sheetFrom(a, { widths: [8, ...cols.map(() => 18), 22, 18] }), name('02 Cleaned data')); }
  { const a = [['COLUMN MAPPING'], [], ['Field', 'Required', 'Source column', 'Source heading', 'Block', 'Match basis', 'Confidence']];
    M.fields.forEach(f => { const m = st.mapping[f.key]; a.push([f.label, f.required ? 'Yes' : 'No', m ? m.letter : '— not mapped —', m ? m.heading : '', m ? m.block : '', m ? m.basis : '', m ? m.confidence : '']); });
    XLSX.utils.book_append_sheet(wb, sheetFrom(a, { widths: [30, 10, 14, 36, 16, 26, 12] }), name('03 Mapping'));
    const b = [['CLEANING LOG'], [], ['Rule', 'Source row', 'Detail']]; (st.cleanLog || []).forEach(l => b.push([l.rule, l.row || '', l.detail])); (st.mapIssues || []).forEach(l => b.push([l.rule, '', l.detail]));
    XLSX.utils.book_append_sheet(wb, sheetFrom(b, { widths: [10, 10, 110] }), name('04 Cleaning log'));
    const c = [['AUDITOR CORRECTIONS'], [], ['Source row', 'Field', 'From', 'To', 'Reason']]; (st.edits || []).forEach(e => c.push([e.srcRow, e.field, D(e.from), D(e.to), e.reason])); if (!(st.edits || []).length) c.push(['No corrections made.']);
    XLSX.utils.book_append_sheet(wb, sheetFrom(c, { widths: [10, 16, 18, 18, 60] }), name('05 Corrections'));
    const t = [['AUDIT TRAIL'], [], ['Time', 'Event', 'Detail']]; (st.trail || []).forEach(x => t.push([x.at, x.event, x.detail]));
    XLSX.utils.book_append_sheet(wb, sheetFrom(t, { widths: [22, 30, 110] }), name('06 Audit trail')); }
  return wb;
}

return { build };
})();
