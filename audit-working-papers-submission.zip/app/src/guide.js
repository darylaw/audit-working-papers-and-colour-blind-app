/* ===========================================================================
   guide.js  —  "what do I do?"  The in-app guide.
   ---------------------------------------------------------------------------
   Written for the auditor opening the file for the first time, and for the
   partner who wants to know what the app did before signing.  Plain steps in
   the order the work actually happens, then the questions people ask.
   =========================================================================== */
const Guide = (() => {

const el = (t, a = {}, kids = []) => {
  const n = document.createElement(t);
  for (const [k, v] of Object.entries(a)) {
    if (k === 'class') n.className = v; else if (k === 'html') Core.richText(n, v); else if (k === 'text') n.textContent = v;
    else if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
    else if (v !== null && v !== undefined && v !== false) n.setAttribute(k, v);
  }
  (Array.isArray(kids) ? kids : [kids]).forEach(c => c && n.append(c));
  return n;
};

const STEPS = [
  ['Set up the engagement', 'Top right, <b>Engagement settings</b>: entity, year end, currency, who prepares and reviews, and materiality. Overall materiality is benchmark × rate; performance materiality and the trivial threshold follow from it. Every threshold in the file is derived from these three figures, so set them first. <b>Fill demo details</b> gives you a fictitious entity with a 31 December year end to explore with.'],
  ['Pick the audit area', 'The ribbon groups the sections the way a file index does — foundations, assets, liabilities and equity, profit or loss, other, completion. Each section is a complete audit file: a lead schedule, the supporting working papers, the tests, and a conclusion.'],
  ['Look at the sample, then upload', 'Every section opens with <b>what the schedule should look like</b>: the columns it reads and a few illustrative rows. Download it to send to the client, or just check the shape. Then drop the client\'s file on the upload box. Their own headings are fine — the app maps them.'],
  ['Check the worksheet and header row', 'The app scores every sheet and every row to find the listing and its header. It is usually right; if the client put the table somewhere odd, pick the sheet and header row yourself. The raw data is shown exactly as received and is exported unchanged on sheet 01.'],
  ['Read the cleaning log', 'Blank rows and columns, repeated headings, group headings, subtotal rows, footnotes and duplicates are removed or held out, and every action is logged with the rule that fired (DQ-01 to DQ-29). Nothing is silently discarded — the log is part of the working paper.'],
  ['Confirm the column mapping', 'Each column the section needs is matched to a heading, with a confidence level. High-confidence matches need only a glance; anything medium or low is yours to confirm or change from the dropdown. Required columns are marked; without them the dependent procedures do not run.'],
  ['Set the auditor controls', 'The controls on each working paper are the judgements a reviewer expects to see made: depreciation convention, testing threshold and sample size, ECL rates, discount rate bands, the date the financial statements are approved. Defaults are sensible; changing one recalculates the page at once.'],
  ['Work through the working papers', 'Left to right along the file index. Each page shows the objective, the procedures, the workings, and the exceptions it raised, with input columns for the evidence you obtain — invoice numbers, confirmation results, explanations. The status dot on each page turns as you go.'],
  ['Clear the exceptions and conclude', 'The last page of each section lists every exception with its severity against materiality, and a drafted conclusion you edit. An exception is cleared by recording what you did about it, not by deleting it.'],
  ['Download the Excel working paper', 'One workbook per section: a sheet per working paper, plus the source data verbatim, the cleaned listing, the mapping, the cleaning log, corrections, the audit trail and the exceptions. Totals and recalculations are live formulas so a reviewer can trace them in Excel.'],
];

const FAQ = [
  ['Does anything leave my computer?', 'No. The file runs entirely in your browser. Nothing is uploaded anywhere. All engagement details, mapping profiles and audit records stay in this tab\'s memory. Export every section before reloading, closing or ending the session. Earlier browser-saved engagement data is cleared when the app opens.'],
  ['The client\'s headings are different from the sample. Does it matter?', 'No. The sample shows the shape, not a required format. The mapper recognises the common alternatives — hover a column in the sample to see them — and anything it cannot place you map by hand once. Remember the layout for this session to reuse its mapping while the tab stays open.'],
  ['What does the AI do?', 'AI assistance is unavailable in this release. No client data or auditor narrative is sent to AI. Every figure, test and exception is rule-based and reproducible. Judgement areas are completed by the auditor. ChatGPT sign-in on the hosted website identifies you; it does not share your audit work with ChatGPT.'],
  ['Why is a dropdown, not a column, used for the depreciation method?', 'Because it is the auditor\'s conclusion about the policy, not a fact copied from the register. The register may state a method; the recalculation uses the method you select, per category, and reports where the register disagrees.'],
  ['How are samples selected?', 'Key items are every item at or above the threshold you set (default: performance materiality). The random sample from the remainder uses a seeded generator, and the seed is recorded on the working paper, so the selection can be reproduced exactly at review.'],
  ['What is the difference between the severities?', 'Each exception is graded against the materiality you set: above performance materiality, above the trivial threshold, below trivial, or informational. The grading is shown on the exceptions page and in the export so a reviewer can see what was material at the time.'],
  ['Can I use this for an ACRA inspection?', 'It produces the schedules, tests and documentation an inspector expects to see for each area, with the procedure, evidence and conclusion recorded together. It does not perform the audit for you: the evidence you obtain, the judgements you make and the sign-offs are still yours, and the file-level items — risk assessment, fraud, EQR, independence — live in the planning and completion sections and in your firm\'s methodology.'],
  ['Where do I start on a new client?', 'Planning & materiality with the trial balance, then the sections in file-index order. The trial balance feeds the benchmark suggestion and the captions every section ties back to.'],
];

function open() {
  const steps = el('ol', { class: 'guide-steps' }, STEPS.map(([h, b]) => el('li', {}, [el('b', { text: h }), el('p', { html: b })])));
  const faq = el('div', { class: 'guide-faq' }, FAQ.map(([q, a]) => el('details', {}, [el('summary', { text: q }), el('p', { html: a })])));
  const sections = el('div', { class: 'guide-sections' }, (typeof Modules !== 'undefined' ? Modules.ALL : []).map(M =>
    el('button', { class: 'chip', onclick: () => { modal.remove(); if (typeof App !== 'undefined') { App.state.active = M.code; App.render(); } },
      text: `${M.code} · ${M.name}` })));
  const body = el('div', { class: 'bd' }, [
    el('p', { class: 'guide-lede', html: 'This file works the way an audit file is worked: <b>see what the client sent, clean it, map it, set your judgements, review each working paper, conclude, download.</b> Ten steps, in order.' }),
    steps,
    el('h4', { style: 'margin:26px 0 10px', text: 'Questions people ask' }), faq,
    el('h4', { style: 'margin:26px 0 10px', text: 'Go to a section' }), sections,
  ]);
  const modal = el('div', { class: 'modal', onclick: ev => { if (ev.target === modal) modal.remove(); } },
    el('div', { class: 'box guide' }, [
      el('h3', {}, [el('span', { text: 'How to use this file' }), el('button', { class: 'btn ghost sm', onclick: () => modal.remove(), text: 'Close' })]),
      body]));
  document.body.append(modal);
}

return { open, STEPS, FAQ };
})();
