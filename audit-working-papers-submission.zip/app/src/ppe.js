/* ==========================================================================
   ppe.js -- Property, plant and equipment as an auditor actually works it.

   A set of working papers, each computed from the same cleaned listing:
     E3    Lead schedule            E3.3  Additions testing
     E3.1  PPE movement schedule    E3.4  Disposals testing
     E3.2  Depreciation             E3.5  Impairment assessment (FRS 36)
   ========================================================================== */

const PPEModule = (() => {
const r2 = n => n == null || isNaN(n) ? null : Math.round(n * 100) / 100;
const days = (a, b) => (a && b) ? Math.round((a - b) / 86400000) : null;

/* Seeded PRNG so a random sample is reproducible from its recorded seed. */
function mulberry32(seed) {
  let a = (seed >>> 0) || 1;
  return () => {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function sampleN(items, n, seed) {
  const rnd = mulberry32(seed);
  const pool = items.slice();
  const out = [];
  while (out.length < n && pool.length) out.push(pool.splice(Math.floor(rnd() * pool.length), 1)[0]);
  return out;
}

/* FRS 36 para 12 -- the minimum indicators. Answered Y/N by the auditor. */
const INDICATORS = [
  { id:'12a', src:'External', text:'Significant decline in market value of assets, beyond the passage of time or normal use' },
  { id:'12b', src:'External', text:'Adverse change in the technological, market, economic or legal environment in which the entity operates' },
  { id:'12c', src:'External', text:'Market interest rates or other market rates of return have increased, likely to reduce recoverable amount materially' },
  { id:'12d', src:'External', text:'Carrying amount of the entity\'s net assets exceeds its market capitalisation (listed entities)' },
  { id:'12e', src:'Internal', text:'Evidence of obsolescence or physical damage' },
  { id:'12f', src:'Internal', text:'Asset idle, plans to discontinue or restructure the operation, plans to dispose earlier than expected, or useful life reassessed as finite' },
  { id:'12g', src:'Internal', text:'Internal reporting indicates economic performance of an asset is, or will be, worse than expected' },
  { id:'14',  src:'Internal', text:'Cash flows to acquire or operate the asset significantly above budget; actual results or budgeted cash flows significantly worse than expected' },
];

/* Candidate rules: how the module decides which assets to put in front of the auditor. */
const CANDIDATE_RULES = [
  { id:'C1', label:'Fully depreciated but still held', def:true,
    why:'Nil carrying amount with the asset still in the register. Either the useful life was too short (FRS 16 para 51 requires annual review) or the asset is no longer in use and should be derecognised.',
    todo:'Confirm with management whether the asset is still in use. If in use, consider whether the useful life policy is appropriate. If not in use, derecognise.' },
  { id:'C2', label:'Negative carrying amount', def:true,
    why:'Accumulated depreciation exceeds cost. Arithmetically impossible under the cost model; indicates an error in the register.',
    todo:'Obtain the asset\'s depreciation history from the client and identify where the over-depreciation arose. Propose an adjustment.' },
  { id:'C3', label:'Idle asset — no depreciation charged in the year', def:true,
    why:'A carrying amount with no charge suggests the asset is idle or depreciation has been suspended. FRS 36 para 12(f) treats an idle asset as an indicator.',
    todo:'Inspect or enquire whether the asset is idle. If idle with no plan to return to use, assess recoverable amount (higher of FVLCD and VIU).' },
  { id:'C4', label:'Age exceeds stated useful life, not fully depreciated', def:true,
    why:'The asset has been held longer than its stated life yet still carries a balance. Life, date or depreciation is inconsistent.',
    todo:'Reconcile acquisition date and useful life to supporting documents. Recompute accumulated depreciation.' },
  { id:'C5', label:'Carrying amount at or above performance materiality', def:true,
    why:'An individually material asset. FRS 36 para 9 requires an indicator assessment at each reporting date; for material items the assessment should be specific rather than portfolio-level.',
    todo:'Enquire of management about the asset\'s condition, utilisation and expected future use. Corroborate to production records or physical inspection. Document the indicator assessment for this asset.' },
  { id:'C6', label:'Disposal in the year at a loss', def:true,
    why:'A loss on disposal is evidence that carrying amounts in that category may exceed recoverable amount (FRS 36 para 12(a)).',
    todo:'Consider whether the loss indicates impairment of remaining assets in the same category. Enquire about their recoverability.' },
  { id:'C7', label:'Category with an indicator answered Yes', def:true,
    why:'Where an FRS 36 para 12 indicator is present for a category, every asset in it with a carrying amount above the trivial threshold must have recoverable amount estimated (para 9).',
    todo:'Estimate recoverable amount for the affected assets or CGU. Refer to the IMP module for the value-in-use model where a CGU is involved.' },
];

/* ---------------------------------------------------------------- fields */
const fields = [
  { key:'asset_id',    label:'Asset code',   role:'key', type:'text', required:true,
    synonyms:['Asset Code','Asset No.','Asset No','FA ID','Tag Number','Asset Ref','Asset Number','资产编号'] },
  { key:'category',    label:'Category',     role:'category', type:'text', required:true, satisfiedByGroup:true,
    synonyms:['Category','Asset Class','Asset Group','FA Type','Class','Type','资产类别'] },
  { key:'description', label:'Description',  type:'text', required:true, dupKey:true,
    synonyms:['Description','Asset Description','Asset Name','Particulars','Item','Details','资产名称'] },
  { key:'acq_date',    label:'Acquisition date', type:'date', required:true, dupKey:true,
    synonyms:['Purchase Date','Acquisition Date','Date Acquired','Capitalisation Date','Capitalization Date',
              'Asset Date','In-Service Date','Date of Purchase','Cap. Date','购置日期'] },
  { key:'life',        label:'Useful life',  type:'number', required:true,
    synonyms:['Useful Life (Yrs)','Useful Life','Life','UL','Est. Useful Life','Dep. Life (Months)','Useful Life (Mths)'] },
  { key:'method',      label:'Depreciation method', type:'text',
    synonyms:['Depreciation Method','Dep Method','Method','Depn Basis','Basis'] },
  { key:'rate',        label:'Depreciation rate %', type:'number',
    synonyms:['Dep Rate %','Rate','Depn Rate','Annual Rate %'] },
  { key:'cost_open',   label:'Cost b/f',     type:'number', required:true, block:'Cost',
    synonyms:['Cost B/F','Opening Cost','Op Bal','Cost Brought Forward','Cost at 1 Jan','期初原值'] },
  { key:'additions',   label:'Additions',    type:'number', required:true, block:'Cost', dupKey:true,
    synonyms:['Additions','Add’ns','Add\'ns','Acquisitions','Purchases','Addition','本期增加'] },
  { key:'disposals',   label:'Disposals',    type:'number', required:true, block:'Cost',
    synonyms:['Disposals','Disposal / Write-off','Deletions','Retirements','Disposal','本期减少'] },
  { key:'cost_close',  label:'Cost c/f',     type:'number', block:'Cost',
    synonyms:['Cost C/F','Closing Cost','End Bal','Cost at Year End','Total Cost'] },
  { key:'accdep_open', label:'Acc dep b/f',  type:'number', required:true, block:'Depreciation',
    synonyms:['Acc Dep B/F','Opening Accumulated Depreciation','Accum. Depn B/F','Op Bal','A/Depn Brought Forward'] },
  { key:'dep_charge',  label:'Depreciation charge', type:'number', required:true, block:'Depreciation',
    synonyms:['Depreciation for the Year','Current Year Depreciation','Depn Charge','Charge for the Year','Dep - CY','Additions','本期折旧'] },
  { key:'accdep_disp', label:'Acc dep on disposals', type:'number', block:'Depreciation',
    synonyms:['Acc Dep on Disposal','Depn on Disposals','Write-back on Disposal','Disposals'] },
  { key:'accdep_close',label:'Acc dep c/f',  type:'number', block:'Depreciation',
    synonyms:['Acc Dep C/F','Closing Accumulated Depreciation','Accum. Depn C/F','End Bal'] },
  { key:'nbv_close',   label:'NBV c/f',      type:'number', block:'NBV',
    synonyms:['NBV','Net Book Value','Carrying Amount','WDV','Net Book Value at Year End'] },
  { key:'supplier',    label:'Supplier',     type:'text', synonyms:['Supplier','Vendor','Purchased From','Supplier Name'] },
  { key:'location',    label:'Location',     type:'text', synonyms:['Location','Site','Cost Centre','Cost Center','Dept'] }
];

/* The standard cleaned format every client's listing is normalised into. */
const STANDARD_COLUMNS = [
  { key:'asset_id', label:'Asset code' }, { key:'category', label:'Category' },
  { key:'description', label:'Description' }, { key:'acq_date', label:'Acquired', type:'date', edit:true },
  { key:'__lifeYears', label:'Life (yrs)', type:'num', dp:1, edit:'life' },
  { key:'method', label:'Method' },
  { key:'cost_open', label:'Cost b/f', type:'num', edit:true }, { key:'additions', label:'Additions', type:'num', edit:true },
  { key:'disposals', label:'Disposals', type:'num', edit:true }, { key:'__cost_close', label:'Cost c/f', type:'num' },
  { key:'accdep_open', label:'Acc dep b/f', type:'num', edit:true }, { key:'dep_charge', label:'Charge', type:'num', edit:true },
  { key:'accdep_disp', label:'Acc dep disp.', type:'num', edit:true }, { key:'__accdep_close', label:'Acc dep c/f', type:'num' },
  { key:'__nbv_open', label:'NBV b/f', type:'num' }, { key:'__nbv_close', label:'NBV c/f', type:'num', emphasis:true },
  { key:'supplier', label:'Supplier' }
];

const CONVENTIONS = [
  { key:'month-incl',  label:'Monthly — from the month of acquisition (inclusive)' },
  { key:'month-next',  label:'Monthly — from the month after acquisition' },
  { key:'daily',       label:'Daily pro-rata from acquisition date' },
  { key:'half-year',   label:'Half year in the year of acquisition' },
  { key:'full-year',   label:'Full year in the year of acquisition' },
  { key:'none-first',  label:'No depreciation in the year of acquisition' },
];

/* The depreciation method is the auditor's conclusion about the entity's policy,
   not a fact to be copied out of the register.  A register may state a method,
   may state it inconsistently, or may not state it at all -- so it is chosen
   here, per category, and the register is then compared against the choice.

   `rate` is the declining-balance rate as a multiple of the straight-line rate:
   200% is the double-declining method, 150% the one-and-a-half.  A method that
   needs a rate the register does not give falls back to the policy rate entered
   on E3.2, and reports that it did.                                          */
const METHODS = [
  { key:'sl',    label:'Straight line',                       needsRate:false },
  { key:'rb',    label:'Reducing balance (at the stated rate)', needsRate:true },
  { key:'ddb',   label:'Double declining balance (200% of straight line)', factor:2, needsRate:false },
  { key:'db150', label:'Declining balance (150% of straight line)',        factor:1.5, needsRate:false },
  { key:'syd',   label:'Sum of the years\' digits',           needsRate:false },
  { key:'none',  label:'Not depreciated (freehold land, assets under construction)', needsRate:false },
];
const METHOD_LABEL = k => (METHODS.find(m => m.key === k) || METHODS[0]).label;

/* What the register says, normalised onto the same keys, so the two can be
   compared.  Anything unrecognised returns null and is reported, not guessed. */
function readMethod(text) {
  const t = Core.lower(text || '');
  if (!t) return null;
  if (/(^|\b)(sl|straight[\s-]?line|s\/?l|直线)/.test(t)) return 'sl';
  if (/double[\s-]?declin|200\s*%|ddb/.test(t)) return 'ddb';
  if (/150\s*%/.test(t)) return 'db150';
  if (/sum[\s-]?of[\s-]?(the[\s-]?)?year|syd|数字总和/.test(t)) return 'syd';
  if (/reducing|declin|diminish|wdv|written[\s-]?down|余额递减/.test(t)) return 'rb';
  if (/not depreciated|no depreciation|nil|n\/?a|land/.test(t)) return 'none';
  return null;
}

/* One asset's charge for the year under the chosen method.
   base    cost the charge is computed on (opening cost plus additions)
   opened  accumulated depreciation brought forward
   life    useful life in years the auditor is recalculating on
   months  months in use this year, from the convention
   rate    declining-balance rate in %, where the method needs one           */
function charge(method, { base, opened, life, months, rate, residual = 0, age = 0 }) {
  const part = months / 12;
  const depreciable = Math.max(0, base - residual);
  const nbv = Math.max(0, base - opened);
  switch (method) {
    case 'none': return 0;
    case 'rb':   return rate > 0 ? nbv * (rate / 100) * part : null;
    case 'ddb':
    case 'db150': {
      if (!(life > 0)) return null;
      const f = method === 'ddb' ? 2 : 1.5;
      return Math.max(0, Math.min(nbv * (f / life) * part, Math.max(0, nbv - residual)));
    }
    case 'syd': {
      if (!(life > 0)) return null;
      const n = Math.ceil(life);
      const sum = n * (n + 1) / 2;
      const yearIndex = Math.min(n, Math.floor(age) + 1);          /* 1-based year of use */
      const remaining = Math.max(0, n - yearIndex + 1);
      return depreciable * (remaining / sum) * part;
    }
    case 'sl':
    default:     return life > 0 ? depreciable / life * part : null;
  }
}

const defaultConfig = () => ({
  lifeUnit: 'auto', convention: 'month-incl', recalcBasis: 'asset',
  method: 'sl',                   // entity default, overridden per category below
  methodPolicy: {},               // category -> method key, auditor-entered
  ratePolicy: {},                 // category -> reducing-balance rate %, auditor-entered
  lifePolicy: {},                 // category -> years, auditor-entered
  depTol: 0, castTol: 0.01, capThreshold: 1000,
  addThreshold: null, addSampleN: 0, addSeed: 20250228,
  indicators: {},                 // id -> { answer:'Y'|'N'|'', comment, categories }
  rules: Object.fromEntries(CANDIDATE_RULES.map(r => [r.id, r.def])),
  tb: {},                         // category -> { cost, accdep }  (auditor / TB link)
  py: {},                         // category -> { cost, accdep }  (prior year)
  pnlDepreciation: null,          // depreciation charge per the P&L, for the tie
});

/* ========================================================== COMPUTE */
function monthsInUse(acq, fys, ye, convention) {
  if (!acq || !ye) return 12;
  if (acq > ye) return 0;
  if (fys && acq < fys) return 12;                 // held all year
  const m = (ye.getUTCFullYear() - acq.getUTCFullYear()) * 12 + (ye.getUTCMonth() - acq.getUTCMonth());
  switch (convention) {
    case 'month-incl': return Math.min(12, Math.max(0, m + 1));
    case 'month-next': return Math.min(12, Math.max(0, m));
    case 'daily':      return Math.min(12, Math.max(0, (days(ye, acq) + 1) / 365 * 12));
    case 'half-year':  return 6;
    case 'full-year':  return 12;
    case 'none-first': return 0;
    default:           return Math.min(12, Math.max(0, m + 1));
  }
}

function compute(recs, cfg, eng) {
  const ye = eng.yearEndDate, fys = eng.fyStartDate;
  const pm = eng.materiality?.pm || 0, trivial = eng.materiality?.trivial || 0;

  /* DQ-24: life unit */
  let unit = cfg.lifeUnit;
  if (unit === 'auto') {
    const vals = recs.map(r => r.life).filter(v => v > 0);
    unit = vals.length && vals.filter(v => v > 30).length / vals.length > 0.5 ? 'months' : 'years';
  }

  const cats = {};
  const catOf = r => r.category || '(uncategorised)';
  for (const r of recs) {
    r.__displayKey = r.asset_id || r.description || ('row ' + r.__srcRow);
    const lifeMonths = unit === 'months' ? (r.life || 0) : (r.life || 0) * 12;
    r.__lifeYears = lifeMonths ? lifeMonths / 12 : 0;
    const policy = cfg.lifePolicy[catOf(r)];
    r.__policyLife = policy > 0 ? Number(policy) : null;
    const lifeForCalc = (cfg.recalcBasis === 'policy' && r.__policyLife) ? r.__policyLife : r.__lifeYears;
    r.__lifeUsed = lifeForCalc;

    r.__cost_close = r.cost_close != null ? r.cost_close
                   : r2((r.cost_open || 0) + (r.additions || 0) - (r.disposals || 0));
    r.__accdep_close = r.accdep_close != null ? r.accdep_close
                     : r2((r.accdep_open || 0) + (r.dep_charge || 0) - (r.accdep_disp || 0));
    r.__nbv_open = r2((r.cost_open || 0) - (r.accdep_open || 0));
    r.__nbv_close = r2(r.__cost_close - r.__accdep_close);

    r.__isAddition = (r.additions || 0) > 0.005 || (r.acq_date && fys && r.acq_date >= fys && r.acq_date <= ye);
    r.__isDisposal = (r.disposals || 0) > 0.005;
    r.__months = monthsInUse(r.acq_date, fys, ye, cfg.convention);
    if (r.__isDisposal && (r.__cost_close || 0) < 0.005) r.__months = Math.min(r.__months, 12);

    /* The method the auditor has concluded on for this category, and what the
       register says, so E3.2 can report where the two disagree.              */
    const catMethod = cfg.methodPolicy[catOf(r)] || cfg.method || 'sl';
    r.__method = catMethod;
    r.__methodStated = readMethod(r.method);
    r.__methodRaw = r.method || '';
    r.__methodDiffers = !!(r.__methodStated && r.__methodStated !== catMethod);
    r.__methodUnreadable = !!(r.__methodRaw && !r.__methodStated);

    r.__ageYears = (r.acq_date && ye) ? days(ye, r.acq_date) / 365.25 : null;
    const base = r.__isAddition && !r.cost_open ? (r.additions || 0) : (r.cost_open || 0) + (r.__isAddition ? (r.additions || 0) : 0);
    const rateUsed = r.rate > 0 ? r.rate : (Number(cfg.ratePolicy[catOf(r)]) || 0);
    r.__rateUsed = rateUsed;
    let expected = 0;
    if (base > 0) {
      const c = charge(catMethod, { base, opened: r.accdep_open || 0, life: lifeForCalc,
        months: r.__months, rate: rateUsed, age: r.__ageYears || 0 });
      if (c == null) { r.__noBasis = true; expected = 0; }      /* method needs a rate or a life we do not have */
      else expected = Math.min(c, Math.max(0, base - (r.accdep_open || 0)));
    }
    if (r.__isDisposal && (r.__cost_close || 0) < 0.005) expected = Math.min(expected, r.dep_charge || 0);
    r.__expectedDep = r2(expected);
    r.__depDiff = r2((r.dep_charge || 0) - expected);
    r.__fullyDepOpen = (r.cost_open || 0) > 0 && (r.accdep_open || 0) >= (r.cost_open || 0) - 0.01;

    const c = cats[catOf(r)] || (cats[catOf(r)] = {
      category: catOf(r), count: 0, cost_open:0, additions:0, disposals:0, cost_close:0,
      accdep_open:0, dep_charge:0, accdep_disp:0, accdep_close:0, nbv_open:0, nbv_close:0,
      expected:0, depDiff:0, lives: [] });
    if (r.__excluded) continue;
    c.count++;
    c.cost_open += r.cost_open || 0; c.additions += r.additions || 0; c.disposals += r.disposals || 0;
    c.cost_close += r.__cost_close || 0; c.accdep_open += r.accdep_open || 0;
    c.dep_charge += r.dep_charge || 0; c.accdep_disp += r.accdep_disp || 0;
    c.accdep_close += r.__accdep_close || 0; c.nbv_open += r.__nbv_open || 0;
    c.nbv_close += r.__nbv_close || 0; c.expected += expected; c.depDiff += r.__depDiff || 0;
    if (r.__lifeYears > 0) c.lives.push(r.__lifeYears);
    c.method = r.__method;
    (c.stated = c.stated || {})[r.__methodStated || (r.__methodRaw ? 'unreadable' : 'not stated')] =
      (c.stated[r.__methodStated || (r.__methodRaw ? 'unreadable' : 'not stated')] || 0) + 1;
    if (r.__methodDiffers) c.methodDiffers = (c.methodDiffers || 0) + 1;
    if (r.__noBasis) c.noBasis = (c.noBasis || 0) + 1;
  }
  const byCategory = Object.values(cats).sort((a, b) => a.category.localeCompare(b.category));
  const totals = { category:'TOTAL', count:0, cost_open:0, additions:0, disposals:0, cost_close:0,
    accdep_open:0, dep_charge:0, accdep_disp:0, accdep_close:0, nbv_open:0, nbv_close:0, expected:0, depDiff:0 };
  for (const c of byCategory) {
    for (const k of Object.keys(totals)) if (typeof c[k] === 'number') totals[k] += c[k];
    c.modeLife = c.lives.length ? mode(c.lives) : null;
    c.minLife = c.lives.length ? Math.min(...c.lives) : null;
    c.maxLife = c.lives.length ? Math.max(...c.lives) : null;
    for (const k of Object.keys(c)) if (typeof c[k] === 'number') c[k] = r2(c[k]);
  }
  for (const k of Object.keys(totals)) if (typeof totals[k] === 'number') totals[k] = r2(totals[k]);

  /* ---- lead schedule: listing vs TB vs prior year --------------------- */
  const lead = byCategory.map(c => {
    const tb = cfg.tb[c.category] || {}, py = cfg.py[c.category] || {};
    const tbCost = tb.cost != null && tb.cost !== '' ? Number(tb.cost) : null;
    const tbDep = tb.accdep != null && tb.accdep !== '' ? Math.abs(Number(tb.accdep)) : null;
    const nbvTB = tbCost != null && tbDep != null ? r2(tbCost - tbDep) : null;
    const nbvPY = py.cost != null && py.cost !== '' && py.accdep != null && py.accdep !== ''
      ? r2(Number(py.cost) - Math.abs(Number(py.accdep))) : null;
    const variance = nbvPY != null ? r2(c.nbv_close - nbvPY) : null;
    return { category:c.category, listCost:c.cost_close, listDep:c.accdep_close, listNBV:c.nbv_close,
      tbCost, tbDep, nbvTB, diffCost: tbCost != null ? r2(c.cost_close - tbCost) : null,
      diffDep: tbDep != null ? r2(c.accdep_close - tbDep) : null,
      nbvPY, variance, variancePct: nbvPY ? r2(variance / Math.abs(nbvPY) * 100) : null,
      material: variance != null && Math.abs(variance) > pm && nbvPY && Math.abs(variance / nbvPY) > 0.10 };
  });

  /* ---- additions testing: key items above threshold + random sample --- */
  const threshold = cfg.addThreshold != null && cfg.addThreshold !== '' ? Number(cfg.addThreshold) : pm;
  const adds = recs.filter(r => !r.__excluded && (r.additions || 0) > 0.005);
  const key = adds.filter(r => r.additions >= threshold);
  const residual = adds.filter(r => r.additions < threshold);
  const n = Math.min(Number(cfg.addSampleN) || 0, residual.length);
  const sample = sampleN(residual, n, Number(cfg.addSeed) || 1);
  const selected = new Set([...key, ...sample].map(r => r.__i));
  for (const r of recs) r.__addSelected = selected.has(r.__i) ? (key.includes(r) ? 'key' : 'sample') : null;
  const addTotal = r2(adds.reduce((s, r) => s + r.additions, 0));
  const keyVal = r2(key.reduce((s, r) => s + r.additions, 0));
  const sampleVal = r2(sample.reduce((s, r) => s + r.additions, 0));
  const additions = { threshold, all: adds, key, residual, sample, seed: Number(cfg.addSeed) || 1,
    total: addTotal, keyValue: keyVal, sampleValue: sampleVal,
    coverage: addTotal ? r2((keyVal + sampleVal) / addTotal * 100) : 0,
    residualValue: r2(addTotal - keyVal), untestedValue: r2(addTotal - keyVal - sampleVal) };

  /* ---- disposals ----------------------------------------------------- */
  const disposals = recs.filter(r => !r.__excluded && r.__isDisposal).map(r => {
    const v = r.__disp || {};
    const nbvDisposed = r2((r.disposals || 0) - (r.accdep_disp || 0));
    const proceeds = v.proceeds != null && v.proceeds !== '' ? Number(v.proceeds) : null;
    return { r, nbvDisposed, proceeds, gainLoss: proceeds != null ? r2(proceeds - nbvDisposed) : null,
      noWriteBack: Math.abs(r.accdep_disp || 0) < 0.005 && (r.disposals || 0) > 0.005 };
  });

  /* ---- impairment: indicators and candidates ------------------------- */
  const yesCats = new Set();
  let anyYes = false;
  for (const ind of INDICATORS) {
    const a = cfg.indicators[ind.id];
    if (a?.answer === 'Y') { anyYes = true; (a.categories || []).forEach(c => yesCats.add(c)); if (!(a.categories||[]).length) yesCats.add('*'); }
  }
  const lossCats = new Set(disposals.filter(d => d.gainLoss != null && d.gainLoss < 0).map(d => catOf(d.r)));
  const candidates = [];
  for (const r of recs) {
    if (r.__excluded) continue;
    const hits = [];
    const on = id => cfg.rules[id] !== false;
    if (on('C1') && (r.__cost_close || 0) > 0.005 && Math.abs(r.__nbv_close || 0) < 0.01) hits.push('C1');
    if (on('C2') && (r.__nbv_close || 0) < -0.01) hits.push('C2');
    if (on('C3') && (r.__nbv_open || 0) > trivial && Math.abs(r.dep_charge || 0) < 0.005 && !r.__isDisposal && !r.__fullyDepOpen) hits.push('C3');
    if (on('C4') && r.__ageYears != null && r.__lifeYears > 0 && r.__ageYears > r.__lifeYears + 0.5 && (r.__nbv_close || 0) > trivial) hits.push('C4');
    if (on('C5') && pm > 0 && (r.__nbv_close || 0) >= pm) hits.push('C5');
    if (on('C6') && lossCats.has(catOf(r)) && !r.__isDisposal && (r.__nbv_close || 0) > trivial) hits.push('C6');
    if (on('C7') && anyYes && (yesCats.has('*') || yesCats.has(catOf(r))) && (r.__nbv_close || 0) > trivial) hits.push('C7');
    if (hits.length) candidates.push({ r, rules: hits });
  }
  candidates.sort((a, b) => (b.r.__nbv_close || 0) - (a.r.__nbv_close || 0));
  const impairment = { indicators: INDICATORS, anyYes, candidates,
    candidateValue: r2(candidates.reduce((s, c) => s + Math.max(0, c.r.__nbv_close || 0), 0)),
    coverage: totals.nbv_close ? r2(candidates.reduce((s, c) => s + Math.max(0, c.r.__nbv_close || 0), 0) / totals.nbv_close * 100) : 0 };

  /* ---- P&L tie ------------------------------------------------------- */
  const pnl = cfg.pnlDepreciation != null && cfg.pnlDepreciation !== '' ? Number(cfg.pnlDepreciation) : null;

  return { lifeUnit: unit, byCategory, totals, lead, additions, disposals, impairment,
    pnlDepreciation: pnl, pnlDiff: pnl != null ? r2(totals.dep_charge - pnl) : null,
    castCost: r2(totals.cost_open + totals.additions - totals.disposals - totals.cost_close),
    castDep: r2(totals.accdep_open + totals.dep_charge - totals.accdep_disp - totals.accdep_close) };
}

function mode(arr) {
  const m = new Map(); let best = arr[0], bc = 0;
  for (const v of arr) { const c = (m.get(v) || 0) + 1; m.set(v, c); if (c > bc) { bc = c; best = v; } }
  return best;
}

/* ============================================================== TESTS */
const tests = [
  { id:'EX-PPE-01', label:'Depreciation charge differs from the recalculation', basis:'E3.2',
    fn:(r,cfg,eng) => { const tol = cfg.depTol > 0 ? cfg.depTol : (eng.materiality?.trivial || 1);
      return r.__depDiff != null && Math.abs(r.__depDiff) > tol &&
        { expected:r.__expectedDep, actual:r.dep_charge, difference:r.__depDiff, cell:r['__cell_dep_charge'],
          detail:`${r.__depDiff < 0 ? 'Under' : 'Over'}-depreciated by ${Math.abs(r.__depDiff).toFixed(2)} on ${r.__months} months over ${r.__lifeUsed} years` }; } },
  { id:'EX-PPE-03', label:'Negative carrying amount', basis:'E3.5 C2', severity:'above-trivial',
    fn:(r) => (r.__nbv_close || 0) < -0.01 && { actual:r.__nbv_close, difference:r.__nbv_close, cell:r['__cell_nbv_close'] } },
  { id:'EX-PPE-04', label:'Depreciation charged on a fully depreciated asset', basis:'E3.2',
    fn:(r) => r.__fullyDepOpen && (r.dep_charge || 0) > 0.01 && { actual:r.dep_charge, difference:r.dep_charge, cell:r['__cell_dep_charge'] } },
  { id:'EX-PPE-22', label:'Depreciation method per the register differs from the policy applied', basis:'E3.2', severity:'informational',
    why:'The recalculation uses the method concluded on for the category. Where the register states a different method, either the register or the policy is wrong and the difference must be resolved.',
    fn:(r) => r.__methodDiffers && { actual:r.__methodRaw, expected:METHOD_LABEL(r.__method), cell:r['__cell_method'],
      detail:`Register states "${r.__methodRaw}"; recalculated on ${METHOD_LABEL(r.__method)}` } },
  { id:'EX-PPE-23', label:'Depreciation method stated in the register is not recognised', basis:'E3.2', severity:'informational',
    why:'A method that cannot be read cannot be compared to the policy. Confirm what the entry means and set the category policy on E3.2.',
    fn:(r) => r.__methodUnreadable && { actual:r.__methodRaw, cell:r['__cell_method'] } },
  { id:'EX-PPE-24', label:'Method needs a rate or a life that the register does not provide', basis:'E3.2',
    why:'A reducing balance method needs a rate, and every other method needs a useful life. Without one the charge cannot be recalculated, so the asset is untested.',
    fn:(r) => r.__noBasis && (r.dep_charge || 0) !== 0 && { actual:r.dep_charge, difference:r.dep_charge, cell:r['__cell_life'],
      detail:`No ${r.__method === 'rb' ? 'depreciation rate' : 'useful life'} for this asset; charge of ${r.dep_charge} not recalculated` } },
  { id:'EX-PPE-05', label:'Useful life differs from the category policy', basis:'E3.2', severity:'informational',
    fn:(r) => r.__policyLife && r.__lifeYears > 0 && Math.abs(r.__lifeYears - r.__policyLife) > 0.01 &&
      { actual:r.__lifeYears, expected:r.__policyLife, cell:r['__cell_life'], detail:`Stated ${r.__lifeYears} years; policy ${r.__policyLife} years` } },
  { id:'EX-PPE-06', label:'No useful life or rate but depreciation charged', basis:'E3.2',
    fn:(r) => !r.__lifeYears && !(r.rate > 0) && (r.dep_charge || 0) > 0.01 && { actual:r.dep_charge, difference:r.dep_charge, cell:r['__cell_life'] } },
  { id:'EX-PPE-07', label:'Acquisition dated after the year end', basis:'E3.3', severity:'above-trivial',
    fn:(r,cfg,eng) => r.acq_date && eng.yearEndDate && r.acq_date > eng.yearEndDate &&
      { actual:Core.fmtDate(r.acq_date), difference:r.additions, cell:r['__cell_acq_date'] } },
  { id:'EX-PPE-08', label:'Cost roll-forward does not cast', basis:'E3.1',
    fn:(r,cfg) => { if (r.cost_close == null) return false;
      const d = r2(r.cost_close - ((r.cost_open||0) + (r.additions||0) - (r.disposals||0)));
      return Math.abs(d) > cfg.castTol && { expected:r2(r.cost_close - d), actual:r.cost_close, difference:d, cell:r['__cell_cost_close'] }; } },
  { id:'EX-PPE-08b', label:'Accumulated depreciation roll-forward does not cast', basis:'E3.1',
    fn:(r,cfg) => { if (r.accdep_close == null) return false;
      const calc = r2((r.accdep_open||0) + (r.dep_charge||0) - (r.accdep_disp||0));
      const d = r2(r.accdep_close - calc);
      return Math.abs(d) > cfg.castTol && { expected:calc, actual:r.accdep_close, difference:d, cell:r['__cell_accdep_close'] }; } },
  { id:'EX-PPE-09', label:'Disposal with no accumulated depreciation written back', basis:'E3.4',
    fn:(r) => r.__isDisposal && Math.abs(r.accdep_disp || 0) < 0.005 && { actual:r.disposals, difference:r.disposals, cell:r['__cell_accdep_disp'] } },
  { id:'EX-PPE-10', label:'Negative addition', basis:'E3.3',
    fn:(r) => (r.additions || 0) < -0.01 && { actual:r.additions, difference:r.additions, cell:r['__cell_additions'] } },
  { id:'EX-PPE-11', label:'Addition below the capitalisation threshold', basis:'E3.3', severity:'informational',
    fn:(r,cfg) => (r.additions || 0) > 0.005 && r.additions < cfg.capThreshold && { actual:r.additions, difference:r.additions, cell:r['__cell_additions'] } },
  { id:'EX-PPE-12', label:'Possible duplicate asset', basis:'E3.0a', severity:'informational',
    fn:(r) => { const f = r.__flags.find(x => x.rule === 'DQ-10'); return f && { detail:f.detail, difference:r.additions || r.cost_open }; } },
  { id:'EX-PPE-20', scope:'population', label:'Listing does not agree to the trial balance', basis:'E3',
    fn:(recs,cfg,eng,d) => d.lead.filter(l => (l.diffCost != null && Math.abs(l.diffCost) > cfg.castTol) || (l.diffDep != null && Math.abs(l.diffDep) > cfg.castTol))
      .map(l => ({ key:l.category, expected:l.nbvTB, actual:l.listNBV, difference: r2((l.diffCost||0) - (l.diffDep||0)),
                   detail:`Cost ${l.diffCost != null ? l.diffCost.toFixed(2) : 'n/a'}, acc dep ${l.diffDep != null ? l.diffDep.toFixed(2) : 'n/a'}` })) },
  { id:'EX-PPE-21', scope:'population', label:'Depreciation per listing does not agree to the P&L', basis:'E3.2',
    fn:(recs,cfg,eng,d) => d.pnlDiff != null && Math.abs(d.pnlDiff) > cfg.castTol &&
      { key:'Depreciation charge', expected:d.pnlDepreciation, actual:d.totals.dep_charge, difference:d.pnlDiff } },
];

/* ============================================================== PAGES */
const pages = [
  { id:'source',       ref:'E3.0',  title:'Source data',           kind:'source' },
  { id:'cleaned',      ref:'E3.0a', title:'Cleaned listing',       kind:'cleaned' },
  { id:'mapping',      ref:'E3.0b', title:'Column mapping',        kind:'mapping' },
  { id:'lead',         ref:'E3',    title:'Lead schedule',         kind:'lead',
    objective:'To agree property, plant and equipment per the fixed asset listing to the trial balance and prior year audited figures, and to explain material movements.',
    procedures:['Agreed cost and accumulated depreciation per the listing to the trial balance by category.',
                'Compared closing net book value to the prior year audited figure and investigated variances above performance materiality and 10%.'] },
  { id:'movement',     ref:'E3.1',  title:'PPE movement schedule', kind:'movement',
    objective:'To prepare the movement in cost, accumulated depreciation and net book value by category for the year, and confirm it casts and cross-casts.',
    procedures:['Prepared the roll-forward of cost and accumulated depreciation by category from the cleaned listing.',
                'Cast each column and cross-cast each row. Agreed opening balances to prior year closing.'] },
  { id:'depreciation', ref:'E3.2',  title:'Depreciation reasonableness', kind:'depreciation',
    objective:'To recalculate the depreciation charge for the year and assess whether the method and useful lives applied are consistent with the stated accounting policy.',
    procedures:['Recalculated the charge for each asset under the depreciation method concluded on for its category, over the useful life and applying the convention selected.',
                'Compared the method applied to the method stated in the register and investigated differences.',
                'Compared the recalculated charge to the charge recorded, by asset and by category.',
                'Compared stated useful lives to the accounting policy for each category.',
                'Agreed the total charge per the listing to the depreciation expense in the profit or loss.'] },
  { id:'additions',    ref:'E3.3',  title:'Additions testing',     kind:'additions',
    objective:'To verify that additions in the year exist, are recorded at cost, are correctly classified and capitalised, and are recorded in the correct period.',
    procedures:['Selected every addition at or above the testing threshold as a key item.',
                'Selected a random sample from the remaining additions, using a recorded seed so the selection is reproducible.',
                'For each selected item, vouched to the supplier invoice for description, date, amount and capitalisation.'] },
  { id:'disposals',    ref:'E3.4',  title:'Disposals testing',     kind:'disposals',
    objective:'To verify that disposals are authorised, that cost and accumulated depreciation are both removed, and that the gain or loss on disposal is correctly computed.',
    procedures:['Listed every disposal in the year with cost, accumulated depreciation written back and carrying amount.',
                'Obtained proceeds and recalculated the gain or loss. Agreed to the profit or loss.',
                'Vouched to disposal authorisation and sales documentation.'] },
  { id:'impairment',   ref:'E3.5',  title:'Impairment assessment', kind:'impairment',
    objective:'To assess, at the reporting date, whether there is any indication that property, plant and equipment may be impaired (FRS 36 para 9), and where an indication exists to identify the assets for which recoverable amount must be estimated.',
    procedures:['Completed the FRS 36 para 12 indicator assessment with management, by category.',
                'Applied the candidate rules to the cleaned listing to identify assets requiring individual assessment.',
                'For each candidate, documented the work performed and the work remaining.'] },
  { id:'conclusion',   ref:'E3.9',  title:'Exceptions & conclusion', kind:'conclusion' },
];

return {
  code:'PPE', name:'Property, Plant & Equipment', group:'Assets', accepts:'.xlsx,.xlsm,.csv',
  blurb:'The PPE audit file: lead, movement schedule, depreciation, additions, disposals and impairment — from one uploaded listing.',
  objective:'To obtain sufficient appropriate audit evidence over the existence, completeness, valuation and presentation of property, plant and equipment.',
  fields, tests, compute, pages, defaultConfig, STANDARD_COLUMNS, CONVENTIONS, METHODS, METHOD_LABEL, readMethod, charge, INDICATORS, CANDIDATE_RULES,
  procedures: pages.flatMap(p => p.procedures || []),
  columns: STANDARD_COLUMNS
};
})();
