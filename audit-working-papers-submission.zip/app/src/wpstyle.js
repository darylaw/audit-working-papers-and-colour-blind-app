/* ===========================================================================
   wpstyle.js  —  how a working paper looks in Excel
   ---------------------------------------------------------------------------
   The schedules are built as arrays of rows by xlsxfile.js, xlsxout.js and
   SpecXL; this decides how they are dressed. It runs over the finished sheet
   and recognises the parts of a working paper by their shape, so one set of
   rules covers every module -- including the ones not written yet.

   The conventions are the ones an audit file has used since carbon paper:

     · the engagement block at the top, labels quiet, values bold
     · objective and procedures as wrapped prose, not spilling across columns
     · column headings reversed out of navy, frozen so they stay in view
     · figures right-aligned, two decimals, negatives red in brackets
     · totals ruled off: a line above, a double line below
     · anything the auditor typed shaded, so a reviewer can see at a glance
       what was entered by hand and what the file computed
     · gridlines off, printing set up landscape with the heading repeated

   Colours are the Skybots palette, muted for paper.
   =========================================================================== */
const WPStyle = (() => {

const NAVY = '#152238', NAVY2 = '#1e3055', INK = '#16202e', MUTED = '#65738c';
const RULE = '#dde3ed', WASH = '#f3f5f9', GOLDWASH = '#fdf6e3', GOLD = '#c9a227';
const MONEY = '#,##0.00;[Red](#,##0.00)';
const DATE = 'dd/mm/yyyy';

const S = {
  wpLabel:  { bold: true, size: 9, color: MUTED, align: { v: 'center' } },
  wpValue:  { bold: true, size: 11, color: INK, align: { v: 'center' } },
  wpRule:   { border: { bottom: { style: 'medium', color: NAVY } } },
  sectionLabel: { bold: true, size: 10, color: NAVY2, align: { v: 'top' } },
  prose:    { size: 10, color: INK, align: { wrap: true, v: 'top' } },
  title:    { bold: true, size: 12, color: NAVY },
  head:     { bold: true, size: 10, color: '#ffffff', fill: NAVY2,
              align: { h: 'center', v: 'center', wrap: true },
              border: { all: { style: 'thin', color: NAVY } } },
  total:    { bold: true, border: { top: { style: 'thin', color: NAVY }, bottom: { style: 'double', color: NAVY } } },
  input:    { fill: GOLDWASH, border: { all: { style: 'hair', color: GOLD } } },
  cell:     { border: { bottom: { style: 'hair', color: RULE } } },
  band:     { fill: WASH },
  tickmark: { size: 9, color: MUTED, align: { wrap: true } },
};

const merge = (...xs) => {
  const out = {};
  for (const x of xs) {
    if (!x) continue;
    for (const [k, v] of Object.entries(x)) {
      out[k] = (v && typeof v === 'object' && !Array.isArray(v)) ? { ...(out[k] || {}), ...v } : v;
    }
  }
  return out;
};

const norm = v => String(v == null ? '' : v).trim();
const lower = v => norm(v).toLowerCase();
const isNum = c => c && c.t === 'n';
const isFigure = v => typeof v === 'number' || (v && v.__f === true);

/* The engagement block, the prose rows and the sign-off wording are all keyed
   off the label in the first column, which every exporter writes the same way. */
const WP_LABELS = new Set(['client', 'year end', 'wp ref', 'prepared by', 'reviewed by', 'date', 'subject']);
const PROSE_LABELS = new Set(['objective', 'procedures', 'source', 'basis', 'tickmarks', 'findings and notes',
  'conclusion', 'overall conclusion', 'auditor comments', 'note', 'notes', 'work to be done', 'work done']);
const TOTAL_RE = /^(sub[\s-]?total|total|grand[\s-]?total|net|balance (at|c\/f)|closing balance)\b/i;

/* A heading row: several text cells, nothing numeric, and figures underneath. */
function headingRow(aoa, r) {
  const row = aoa[r] || [];
  const filled = row.filter(c => c !== null && norm(c) !== '');
  /* Three labels or more. Two is a control -- "Convention | Monthly from the
     month of acquisition" -- and dressing those as a header looks absurd. */
  if (filled.length < 3) return false;
  if (filled.some(isFigure)) return false;
  if (filled.some(c => norm(c).length > 60)) return false;
  if (WP_LABELS.has(lower(row[0])) || PROSE_LABELS.has(lower(row[0]))) return false;
  for (let i = r + 1; i < Math.min(r + 6, aoa.length); i++) {
    const next = (aoa[i] || []).filter(c => c !== null && norm(c) !== '');
    if (!next.length) continue;
    if (next.some(isFigure)) return true;                 /* figures underneath */
    if (next.length < filled.length) return true;         /* a label and blanks to be filled */
    return false;
  }
  return false;
}

/* Read the sheet back as a grid. This runs after the formulas and number
   formats have been written, so a cell carrying only `f` still counts as
   occupied -- reading the array the rows were built from would show a schedule
   of blanks and find no headings at all.                                     */
function gridOf(ws) {
  const rng = XLSX.utils.decode_range(ws['!ref'] || 'A1');
  const g = [];
  for (let r = rng.s.r; r <= rng.e.r; r++) {
    const row = [];
    for (let c = rng.s.c; c <= rng.e.c; c++) {
      const cell = ws[XLSX.utils.encode_cell({ r, c })];
      row.push(!cell ? null : cell.v !== undefined ? cell.v : (cell.f ? { __f: true } : null));
    }
    g.push(row);
  }
  return g;
}

/* opts.inputCols  column indices the auditor fills in, per heading row
   opts.headRows   heading rows the caller already knows about
   opts.widths     column widths the caller has chosen                        */
function apply(ws, aoa, opts = {}) {
  if (!ws || !ws['!ref']) return ws;
  aoa = gridOf(ws);
  const width = Math.max(...aoa.map(r => (r || []).length), 1);
  const put = (r, c, style) => {
    const ref = XLSX.utils.encode_cell({ r, c });
    const cell = ws[ref];
    if (!cell) return;
    cell.s = merge(cell.s, style);
  };

  const heads = new Set(opts.headRows || []);
  for (let r = 0; r < aoa.length; r++) if (!heads.has(r) && headingRow(aoa, r, width)) heads.add(r);

  const merges = ws['!merges'] || (ws['!merges'] = []);
  let firstHead = null, lastRow = aoa.length - 1;

  for (let r = 0; r < aoa.length; r++) {
    const row = aoa[r] || [];
    const label = lower(row[0]);
    const filled = row.filter(c => norm(c) !== '').length;

    /* the engagement block at the top of every working paper */
    if (WP_LABELS.has(label) && r < 8) {
      for (let c = 0; c < width; c++) {
        const v = norm(row[c]);
        if (!v) continue;
        put(r, c, WP_LABELS.has(lower(v)) ? S.wpLabel : S.wpValue);
      }
      if (!aoa[r + 1] || !WP_LABELS.has(lower((aoa[r + 1] || [])[0]))) for (let c = 0; c < width; c++) put(r, c, S.wpRule);
      continue;
    }

    /* objective, procedures, tickmarks, findings, conclusion: prose that must
       wrap inside its own space rather than run across the schedule */
    if (PROSE_LABELS.has(label) || (label === '' && norm(row[1]).length > 90)) {
      put(r, 0, S.sectionLabel);
      const text = norm(row[1]);
      if (text) {
        put(r, 1, merge(S.prose, label === 'tickmarks' ? S.tickmark : null));
        const span = Math.min(width - 1, Math.max(6, Math.ceil(text.length / 16)));
        if (span > 1 && !merges.some(m => m.s.r === r && m.s.c === 1))
          merges.push({ s: { r, c: 1 }, e: { r, c: Math.min(width - 1, span) } });
        if (!ws['!rows']) ws['!rows'] = [];
        ws['!rows'][r] = { hpt: Math.min(90, 15 * Math.max(1, Math.ceil(text.length / (span * 12)))) };
      }
      continue;
    }

    /* a lone line of capitals or a single label above a table is its title */
    if (filled === 1 && norm(row[0]) && !heads.has(r) && norm(row[0]).length < 60 && !TOTAL_RE.test(norm(row[0]))) {
      put(r, 0, S.title);
      continue;
    }

    if (heads.has(r)) {
      if (firstHead === null) firstHead = r;
      for (let c = 0; c < width; c++) if (norm(row[c]) !== '') put(r, c, S.head);
      if (!ws['!rows']) ws['!rows'] = [];
      ws['!rows'][r] = { hpt: 30 };
      continue;
    }

    /* totals: ruled off above and below */
    const isTotal = TOTAL_RE.test(norm(row[0])) || TOTAL_RE.test(norm(row[1]));
    for (let c = 0; c < width; c++) {
      const ref = XLSX.utils.encode_cell({ r, c });
      const cell = ws[ref];
      if (!cell) continue;
      if ((isNum(cell) || cell.f) && !cell.z && !/^(row|ref|#|src row|cell)$/i.test(norm(row[c]))) cell.z = MONEY;
      if (cell.t === 'd' && !cell.z) cell.z = DATE;
      put(r, c, isTotal ? merge(S.cell, S.total) : S.cell);
      if (isNum(cell) || cell.f) put(r, c, { align: { h: 'right' } });
    }
  }

  /* columns the auditor fills in, shaded down the body of the table */
  if (opts.inputCols && opts.inputCols.length && firstHead !== null) {
    for (let r = firstHead + 1; r <= lastRow; r++) {
      if (heads.has(r)) continue;
      const row = aoa[r] || [];
      if (!row.filter(c => norm(c) !== '').length) continue;
      for (const c of opts.inputCols) put(r, c, S.input);
    }
  }

  /* widths: what the caller asked for, else fitted to the content */
  if (opts.widths) ws['!cols'] = opts.widths.map(w => ({ wch: w }));
  else if (!ws['!cols']) {
    const w = new Array(width).fill(10);
    for (const row of aoa) for (let c = 0; c < width; c++) {
      const v = norm((row || [])[c]);
      if (v) w[c] = Math.max(w[c], Math.min(46, v.length + 3));
    }
    ws['!cols'] = w.map(x => ({ wch: x }));
  }

  /* keep the headings in view, and give the page to the printer landscape with
     the engagement block repeated on every sheet of paper */
  ws['!view'] = { gridlines: false, ...(firstHead !== null ? { freeze: { r: firstHead + 1, c: 0 } } : {}) };
  ws['!printSetup'] = { landscape: true, fitToWidth: 1, fitToHeight: 0,
    ...(firstHead !== null && firstHead > 0 ? { repeatRows: [0, firstHead] } : {}) };
  return ws;
}

/* One pass over a finished workbook. Called at the end of the export, when
   every formula, format and merge is in place.                              */
function applyWorkbook(wb, opts = {}) {
  for (const name of wb.SheetNames || []) {
    const ws = wb.Sheets[name];
    if (ws) try { apply(ws, null, opts[name] || {}); } catch (e) { /* a sheet we cannot dress is still a sheet */ }
  }
  return wb;
}

return { apply, applyWorkbook, S, MONEY, DATE };
})();
