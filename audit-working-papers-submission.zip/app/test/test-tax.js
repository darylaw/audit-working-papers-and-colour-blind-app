/* Headless test of the TAX audit file: the trial balance drives the computation; the fixed asset
   register drives the capital allowance schedule.
   Run:  node test/test-tax.js                                                                   */
const { load, counter, money, engagement, pipeline, OUT, path, fs } = require('./spec-lib');
const L = load(['tax.js']);
const t = counter();
const CODE = 'TAX';
const M = L.Modules.byCode.TAX;

const CLIENTS = [
  { c: 'client-a', ye: '2025-02-28', tb: 'PBC-TB-01 Trial balance 2025-02-28.xlsx', fa: 'PBC-PPE-01 Fixed asset register 2025-02-28.xlsx' },
  { c: 'client-b', ye: '2025-09-30', tb: 'PBC-TB-01 Trial balance 2025-09-30.xlsx', fa: 'PBC-PPE-01 Fixed asset register 2025-09-30.xlsx' },
  { c: 'client-d', ye: '2025-09-30', tb: 'PBC-TB-01 Trial balance 2025-09-30.xlsx', fa: 'PBC-PPE-01 Fixed asset register 2025-09-30.xlsx' }
];
/* figures common to every synthetic trial balance */
const REVENUE = 4284600 + 562664 - 41280, DEP = 71292 + 77169, AMORT = 517, PROV = 96400 + 18640 + 118240, ENT = 46820, DT = 9928;

console.log('\n=== TAX — module registration and classifier ===');
t.ok(M && M.name === 'Taxation' && M.group === 'Liabilities & equity', 'TAX registered via Modules.register');
t.ok(M.pages.filter(p => p.render).length === 8, 'eight rendered working papers (W3, W3.0c, W3.1–W3.6)');
t.ok(L.Modules.byCode.TB && L.Modules.byCode.PPE && L.Modules.byCode.TB.code === 'TB', 'TB and PPE modules untouched');
[['Revenue - product sales', -1, 'revenue'], ['Sales returns and allowances', 1, 'revenue'], ['Other income - interest', -1, 'otherIncome'], ['Cost of materials consumed', 1, 'cogs'],
 ['Depreciation of property, plant and equipment', 1, 'depreciation'], ['Plant and machinery - accumulated depreciation', -1, 'bs'], ['Amortisation of intangible assets', 1, 'amortisation'],
 ['Allowance for expected credit losses', 96400, 'impairment'], ['Allowance for expected credit losses', -96400, 'bs'], ['Provision for inventory obsolescence', -118240, 'bs'], ['Inventory written down', 1, 'impairment'], ['Bad debts written off', 1, 'impairment'],
 ['Travel and entertainment', 1, 'entertainment'], ['Interest on term loans', 1, 'interest'], ['Salaries and wages', 1, 'staff'], ["Directors' remuneration", 1, 'staff'], ['Freight and delivery', 1, 'otherExpense'],
 ['Income tax expense', 0, 'taxExpense'], ['Provision for taxation', 0, 'taxProvision'], ['Deferred tax liabilities', -1, 'deferredTax'], ['GST payable', -1, 'gst'], ['Trade payables', -1, 'bs'], ['Amount due from related parties', 1, 'bs'], ['Retained earnings', -1, 'bs']]
  .forEach(([name, bal, exp]) => t.ok(M.classify(name, bal) === exp, `classify("${name}"${bal < 0 ? ', credit' : ''}) → ${exp}`, M.classify(name, bal)));

for (const { c, ye, tb, fa } of CLIENTS) {
  const eng = engagement(L.Core, ye, 145000);
  const label = c;
  const fTB = path.join(OUT, c, tb), fFA = path.join(OUT, c, fa);
  console.log(`\n=== TAX — ${c} — trial balance mode ===`);
  const p = pipeline(L, fTB, CODE, eng);
  const d = p.derived, T = d.tb;
  console.log(`  header row ${p.headerRow + 1}; ${p.records.length} lines; P&L lines ${T.plCount}; revenue ${money(T.revenue)}; PBT ${money(T.pbt)}; dep ${money(T.depreciation)}; provisions ${money(T.impairment)}; DT ${money(T.deferredTax)}; GST ${money(T.gst)}; net ${money(T.net)}`);
  t.ok(d.mode === 'tb', `${label}: trial balance recognised (mode ${d.mode})`);
  t.ok(!!p.mapping.code && !!p.mapping.name && (!!p.mapping.balance || (!!p.mapping.debit && !!p.mapping.credit)), `${label}: code "${p.mapping.code?.heading}", name "${p.mapping.name?.heading}", balance "${p.mapping.balance?.heading || (p.mapping.debit?.heading + '/' + p.mapping.credit?.heading)}" mapped`);
  t.ok(!p.mapping.asset_id && !p.mapping.additions, `${label}: register fields not mapped on a trial balance`);
  t.ok(p.records.length === 83 && Math.abs(T.net) < 1, `${label}: 83 lines read and the TB nets to ${money(T.net)}`);
  /* independent P&L sum: every synthetic TB codes P&L accounts 4xxx–7xxx */
  const codeDigit = r => Number(String(r.code || '').replace(/\D/g, '').charAt(0));
  const plByCode = p.records.filter(r => codeDigit(r) >= 4 && codeDigit(r) <= 6);
  const pbtByCode = -plByCode.reduce((s, r) => s + r.__bal, 0);
  t.ok(p.records.every(r => (codeDigit(r) >= 4 && codeDigit(r) <= 7) === (r.__side === 'pl')), `${label}: every P&L account (codes 4–7) classified to profit or loss and no balance sheet account is`, p.records.filter(r => (codeDigit(r) >= 4 && codeDigit(r) <= 7) !== (r.__side === 'pl')).map(r => r.name).join(' ; '));
  t.ok(Math.abs(T.pbt - pbtByCode) < 0.05, `${label}: profit before tax ${money(T.pbt)} equals the algebraic P&L sum by account code`);
  t.ok(T.revenue === REVENUE && T.depreciation === DEP && T.amortisation === AMORT && T.impairment === PROV && T.entertainment === ENT, `${label}: revenue ${money(T.revenue)}, depreciation ${money(T.depreciation)}, amortisation ${money(T.amortisation)}, provisions ${money(T.impairment)}, entertainment ${money(T.entertainment)}`);
  t.ok(T.deferredTax === DT && T.taxExpense === 0 && T.taxProvision === 0 && Math.abs(T.gst - 63180) < 1, `${label}: tax captions read (DT ${money(T.deferredTax)}, tax expense ${money(T.taxExpense)}, provision ${money(T.taxProvision)}, GST ${money(T.gst)})`);
  if (p.mapping.balance_py) t.ok(T.hasPY === true && T.deferredTaxPY > 0, `${label}: prior year column read (DT PY ${money(T.deferredTaxPY)})`);
  else t.ok(T.hasPY === false && d.payable.open.src === 'not entered' && d.deferred.py.src === 'not entered', `${label}: no prior year column → opening figures must be entered`);

  /* default computation: loss → nil chargeable income, nothing raised */
  const C = d.comp;
  t.ok(C.pbt.src === 'TB' && C.pbt.v === T.pbt && C.dep.v === DEP && C.prov.v === PROV && C.entAdd === r2(ENT * 0.5), `${label}: computation seeded from the TB (PBT ${money(C.pbt.v)}, entertainment add-back ${money(C.entAdd)} at 50%)`);
  t.ok(C.ci === 0 && C.taxCharge === 0 && C.lossesCF > 0 && C.diff === 0, `${label}: loss year → chargeable income nil, losses carried forward ${money(C.lossesCF)}`);
  t.ok(!p.exceptions.some(e => /^EX-TAX-0[1-7]/.test(e.id)), `${label}: no exceptions before inputs (${p.exceptions.map(e => e.id).join(', ') || 'none'})`);
  t.ok(d.lead.length === 5 && d.lead.find(l => l.key === 'deferred').tb === DT && (!p.mapping.balance_py || d.lead.find(l => l.key === 'deferred').movement != null), `${label}: W3 lead shows deferred tax per TB${p.mapping.balance_py ? ' with PY movement' : ''}`);

  /* profit year: exercise the tiers, rate and the tie */
  const pP = pipeline(L, fTB, CODE, eng, { pbtOverride: 1000000 });
  const Cp = pP.derived.comp;
  const adjusted = 1000000 + DEP + AMORT + PROV + ENT * 0.5;
  const exempt = 10000 * 0.75 + 190000 * 0.5, tax = r2((adjusted - exempt) * 0.17);
  console.log(`  W3.1 with PBT 1,000,000: adjusted ${money(Cp.adjustedProfit)}, CI ${money(Cp.ci)}, exempt ${money(Cp.exempt)}, tax ${money(Cp.taxCharge)}`);
  t.ok(Math.abs(Cp.adjustedProfit - adjusted) < 0.01 && Cp.ci === Cp.adjustedProfit, `${label}: add-backs applied (adjusted profit ${money(Cp.adjustedProfit)})`);
  t.ok(Cp.exempt === exempt && Cp.exemptRows.length === 2 && Cp.exemptRows[0].slice === 10000 && Cp.exemptRows[1].slice === 190000, `${label}: partial exemption tiers 75% × 10,000 + 50% × 190,000 = ${money(Cp.exempt)}`);
  t.ok(Math.abs(Cp.taxCharge - tax) < 0.01 && Cp.rate === 17, `${label}: tax at 17% = ${money(Cp.taxCharge)}`);
  const e01 = pP.exceptions.find(e => e.id === 'EX-TAX-01');
  t.ok(e01 && Math.abs(Math.abs(e01.difference) - tax) < 0.01 && e01.severity === 'above-pm', `${label}: EX-TAX-01 raised — computed ${money(tax)} vs nil recorded, above PM`);
  const pP2 = pipeline(L, fTB, CODE, eng, { pbtOverride: 1000000, tbCurrentTax: tax });
  t.ok(!pP2.exceptions.some(e => e.id === 'EX-TAX-01') && pP2.derived.comp.diff === 0, `${label}: EX-TAX-01 clears when the recorded charge agrees`);
  const pR = pipeline(L, fTB, CODE, eng, { pbtOverride: 1000000, taxRate: 25, exemptTiers: '', entPct: 0 });
  t.ok(pR.derived.comp.exempt === 0 && pR.derived.comp.entAdd === 0 && Math.abs(pR.derived.comp.taxCharge - (1000000 + DEP + AMORT + PROV) * 0.25) < 0.01, `${label}: rate, tiers and entertainment % are configurable (25%, no tiers → ${money(pR.derived.comp.taxCharge)})`);
  const pReb = pipeline(L, fTB, CODE, eng, { pbtOverride: 1000000, rebatePct: 50, rebateCap: 20000 });
  t.ok(pReb.derived.comp.rebate === 20000 && Math.abs(pReb.derived.comp.taxCharge - (tax - 20000)) < 0.01, `${label}: rebate capped at 20,000`);
  const pAdj = pipeline(L, fTB, CODE, eng, { pbtOverride: 1000000, 'adjDesc:adj1': 'Private car expenses', 'adjAmount:adj1': 12000, 'adjDesc:adj2': 'Further deduction on R&D', 'adjAmount:adj2': -30000, lossesBF: 500000, exemptIncome: 100000 });
  const Ca = pAdj.derived.comp;
  t.ok(Ca.adj.length === 2 && Ca.adjTotal === -18000 && Math.abs(Ca.adjustedProfit - (adjusted - 18000 - 100000)) < 0.01 && Ca.lossesUsed === 500000 && Math.abs(Ca.ci - (adjusted - 18000 - 100000 - 500000)) < 0.01 && Ca.lossesCF === 0, `${label}: adjustment lines, exempt income and losses b/f flow through (CI ${money(Ca.ci)})`);

  /* W3.2 / W3.3 in TB mode: categories entered */
  const cfgCA = { pbtOverride: 1000000, caRows: 3, 'caCategory:ca1': 'Plant and machinery', 'caAdditions:ca1': 300000, 'caCostBF:ca1': 1200000, 'caNBV:ca1': 650000, 'caWDVOpen:plantandmachinery_1': 500000,
    'caCategory:ca2': 'Computers', 'caAdditions:ca2': 60000, 'caNBV:ca2': 90000, 'caBasis:computers_2': '1-year', 'caWDVOpen:computers_2': 40000, 'caBF:computers_2': 15000 };
  const pCA = pipeline(L, fTB, CODE, eng, cfgCA);
  const A = pCA.derived.ca;
  console.log(`  W3.2 (entered): ${A.rows.map(r => `${r.category} ${r.basis} → ${money(r.total)} (WDV c/f ${money(r.wdvClose)})`).join(' | ')}; total ${money(A.total)}`);
  t.ok(A.mode === 'tb' && A.rows.length === 2, `${label}: two categories entered on W3.2`);
  const pl = A.rows.find(r => r.category === 'Plant and machinery'), cp = A.rows.find(r => r.category === 'Computers');
  t.ok(pl.basis === '3-year' && pl.cyAllowance === 100000 && pl.total === 100000 && pl.wdvClose === 700000 && pl.tempDiff === -50000, `${label}: 3-year basis → 100,000; WDV c/f 700,000; temporary difference −50,000`);
  t.ok(cp.basis === '1-year' && cp.cyAllowance === 60000 && cp.bf === 15000 && cp.total === 75000 && cp.wdvClose === 25000 && cp.tempDiff === 65000, `${label}: 1-year basis with allowances b/f → 75,000; WDV c/f 25,000`);
  t.ok(A.total === 175000 && pCA.derived.comp.caUsed.v === 175000 && pCA.derived.comp.caUsed.src === 'W3.2', `${label}: total capital allowances ${money(A.total)} deducted in W3.1`);
  const Dd = pCA.derived.deferred;
  t.ok(Dd.cats.length === 2 && Dd.tempDiffTotal === 15000 && Dd.audit === 2550 && Dd.tb.v === DT && Math.abs(Dd.diff - (2550 - DT)) < 0.01, `${label}: W3.3 deferred tax ${money(Dd.audit)} on temporary differences ${money(Dd.tempDiffTotal)} vs TB ${money(Dd.tb.v)}`);
  const e02 = pCA.exceptions.find(e => e.id === 'EX-TAX-02');
  t.ok(e02 && Math.abs(Math.abs(e02.difference) - Math.abs(2550 - DT)) < 0.01, `${label}: EX-TAX-02 raised on the deferred tax difference`);
  const pWL = pipeline(L, fTB, CODE, eng, { ...cfgCA, 'caBasis:plantandmachinery_1': 'working life' });
  t.ok(pWL.derived.ca.rows.find(r => r.category === 'Plant and machinery').noBasisLife && pWL.exceptions.some(e => e.id === 'EX-TAX-07'), `${label}: working-life basis without a life → EX-TAX-07`);
  const pWL2 = pipeline(L, fTB, CODE, eng, { ...cfgCA, 'caBasis:plantandmachinery_1': 'working life', 'caLife:plantandmachinery_1': 6 });
  t.ok(pWL2.derived.ca.rows.find(r => r.category === 'Plant and machinery').cyAllowance === 50000 && !pWL2.exceptions.some(e => e.id === 'EX-TAX-07'), `${label}: working life 6 years → 50,000`);
  const pDT = pipeline(L, fTB, CODE, eng, { ...cfgCA, 'dtDesc:dt1': 'Provision for warranty (deductible when paid)', 'dtAmount:dt1': -40000, recogniseLossDTA: 'Y', tbDeferredTax: 2550 - 6800 });
  t.ok(pDT.derived.deferred.other.length === 1 && pDT.derived.deferred.other[0].dt === -6800 && pDT.derived.deferred.audit === 2550 - 6800 && !pDT.exceptions.some(e => e.id === 'EX-TAX-02'), `${label}: other temporary differences and the recorded balance override clear EX-TAX-02`);

  /* W3.4 roll-forward, W3.6 prior year */
  const cfgPay = { pbtOverride: 1000000, tbCurrentTax: tax, payRows: 3, taxPayableOpen: 0, 'payDate:pay1': '15/06/2025', 'payRef:pay1': 'IRAS receipt 1', 'payAmount:pay1': 100000, 'payVouched:pay1': 'Y', 'payDate:pay2': '15/09/2025', 'payRef:pay2': 'GIRO', 'payAmount:pay2': 25000, 'payVouched:pay2': 'N' };
  const pPay = pipeline(L, fTB, CODE, eng, cfgPay);
  const Pp = pPay.derived.payable;
  t.ok(Pp.open.src === 'input' && Pp.open.v === 0 && Pp.paid === 125000 && Math.abs(Pp.closeAudit - (tax - 125000)) < 0.01, `${label}: W3.4 rolls forward: 0 + ${money(tax)} − 125,000 = ${money(Pp.closeAudit)}`);
  const e03 = pPay.exceptions.find(e => e.id === 'EX-TAX-03'), e06 = pPay.exceptions.filter(e => e.id === 'EX-TAX-06');
  t.ok(e03 && Math.abs(Math.abs(e03.difference) - Math.abs(tax - 125000)) < 0.01, `${label}: EX-TAX-03 provision per audit vs nil per TB`);
  t.ok(e06.length === 1 && /GIRO/.test(e06[0].recordKey) && e06[0].severity === 'informational', `${label}: EX-TAX-06 lists only the unvouched payment`);
  const pPay2 = pipeline(L, fTB, CODE, eng, { ...cfgPay, tbTaxProvision: tax - 125000, 'payVouched:pay2': 'Y' });
  t.ok(!pPay2.exceptions.some(e => e.id === 'EX-TAX-03' || e.id === 'EX-TAX-06'), `${label}: EX-TAX-03/06 clear once the TB provision agrees and payments are vouched`);
  const pPY = pipeline(L, fTB, CODE, eng, { ...cfgPay, pyProvision: 50000, noaAmount: 58000, noaSighted: 'Y', pyAdjRecorded: 'N' });
  const e05 = pPY.exceptions.find(e => e.id === 'EX-TAX-05');
  t.ok(pPY.derived.prior.diff === 8000 && e05 && e05.difference === 8000 && /under-provision/.test(e05.detail), `${label}: EX-TAX-05 prior year under-provision of 8,000 not recorded`);
  const pPY2 = pipeline(L, fTB, CODE, eng, { ...cfgPay, pyProvision: 50000, noaAmount: 58000, pyAdjRecorded: 'Y', pyAdjBooked: 8000 });
  t.ok(!pPY2.exceptions.some(e => e.id === 'EX-TAX-05') && pPY2.derived.payable.pyAdj === 8000 && Math.abs(pPY2.derived.payable.closeAudit - (tax + 8000 - 125000)) < 0.01 && pPY2.derived.prior.bookedDiff === 0, `${label}: recorded under-provision flows into the W3.4 roll-forward`);

  /* W3.5 indirect tax */
  const expOut = r2(REVENUE * 0.09);
  const pG = pipeline(L, fTB, CODE, eng, { outputTaxClient: expOut, inputTaxClient: 100 });
  const I = pG.derived.indirect;
  t.ok(I.rate === 9 && I.expOut === expOut && I.outDiff === 0 && I.outVarPct === 0 && !I.outFlag, `${label}: output tax at 9% on revenue ${money(REVENUE)} = ${money(I.expOut)} agrees`);
  t.ok(I.purchases.v === r2(T.cogs + T.otherExpense) && I.expIn === r2(I.purchases.v * 0.09) && I.inFlag && I.inVarPct < -90, `${label}: input tax expected ${money(I.expIn)} vs 100 declared → flagged`);
  const e04 = pG.exceptions.filter(e => e.id === 'EX-TAX-04');
  t.ok(e04.length === 1 && e04[0].recordKey === 'Input tax', `${label}: EX-TAX-04 raised once, on input tax only`);
  t.ok(I.netClient === r2(expOut - 100) && I.netDiff === r2(I.netClient - T.gst), `${label}: net per returns compared to GST payable per TB`);
  const pG2 = pipeline(L, fTB, CODE, eng, { gstRate: 7, stdRatedPct: 80, outputTaxClient: r2(REVENUE * 0.8 * 0.07), inputTaxClient: r2((T.cogs + T.otherExpense) * 0.07 * 1.05) });
  t.ok(pG2.derived.indirect.outDiff === 0 && Math.abs(pG2.derived.indirect.inVarPct - 5) < 0.01 && !pG2.exceptions.some(e => e.id === 'EX-TAX-04'), `${label}: rate and standard-rated % configurable; a 5% variance stays under the 10% threshold`);

  /* W3.0c override */
  const pOv = pipeline(L, fTB, CODE, eng, { pbtOverride: 1000000 }, recs => { recs.find(r => /entertainment/i.test(r.name)).__wp = { classify: { cls: 'bs' } }; });
  t.ok(pOv.derived.tb.entertainment === 0 && pOv.derived.tb.overridden === 1 && pOv.derived.comp.entAdd === 0, `${label}: an auditor override on W3.0c removes the line from the computation`);
  const e09 = pOv.exceptions.filter(e => e.id === 'EX-TAX-09');
  t.ok(e09.length === 1 && e09[0].severity === 'informational' && /entertainment/i.test(e09[0].recordKey), `${label}: EX-TAX-09 records the override (informational)`);

  p.renderAll(t, label + ' TB');
  pCA.renderAll(t, label + ' TB with inputs');
  const wb = pPY2.exportCheck(t, label + ' TB');
  const wsP = wb.Sheets[Object.keys(wb.Sheets).find(n => n.startsWith('W3.4'))];
  t.ok(wsP && Object.values(wsP).some(c => c && c.v === 'IRAS receipt 1'), `${label}: W3.4 export carries the payments entered`);

  /* ---------------- register mode: capital allowances from the asset register */
  console.log(`=== TAX — ${c} — fixed asset register mode ===`);
  const q = pipeline(L, fFA, CODE, eng);
  const qd = q.derived, QA = qd.ca;
  console.log(`  header row ${q.headerRow + 1}; ${q.records.length} assets; ${QA.rows.length} categories; additions ${money(QA.additions)}; CA (3-year default) ${money(QA.total)}; life unit ${QA.lifeUnit}`);
  t.ok(qd.mode === 'register' && qd.tb == null, `${label}: register recognised (mode ${qd.mode})`);
  t.ok(!!q.mapping.asset_id && !!q.mapping.additions && (!!q.mapping.category || q.clean.hasGroups), `${label}: asset "${q.mapping.asset_id?.heading}", category "${q.mapping.category?.heading || '(group headers)'}", additions "${q.mapping.additions?.heading}" mapped`);
  t.ok(q.records.every(r => r.category), `${label}: every asset carries a category (column or forward-filled group header)`);
  t.ok(!q.mapping.balance && !q.mapping.debit, `${label}: trial balance amount fields not mapped on a register`);
  t.ok(QA.rows.length >= 5 && QA.rows.every(r => r.source === 'register' && r.count > 0), `${label}: ${QA.rows.length} categories built from the register`);
  const addSum = q.records.filter(r => !r.__excluded).reduce((s, r) => s + Math.max(0, r.additions || 0), 0);
  t.ok(Math.abs(QA.additions - addSum) < 0.05 && Math.abs(QA.rows.reduce((s, r) => s + r.additions, 0) - addSum) < 0.05, `${label}: qualifying additions ${money(QA.additions)} cross-cast to the register (negative additions excluded)`);
  t.ok(Math.abs(QA.total - addSum / 3) < 0.05 && QA.rows.every(r => r.basis === '3-year'), `${label}: default 3-year basis → ${money(QA.total)}`);
  t.ok(QA.rows.every(r => r.nbv != null) && Math.abs(QA.nbv - q.records.filter(r => !r.__excluded).reduce((s, r) => s + (r.__nbv || 0), 0)) < 0.05, `${label}: carrying amounts by category from the register (${money(QA.nbv)})`);
  const q1 = pipeline(L, fFA, CODE, eng, { caDefaultBasis: '1-year' });
  t.ok(Math.abs(q1.derived.ca.total - addSum) < 0.05, `${label}: 1-year default → full additions ${money(q1.derived.ca.total)}`);
  const big = QA.rows.slice().sort((a, b) => b.additions - a.additions)[0];
  const q2 = pipeline(L, fFA, CODE, eng, { ['caBasis:' + big.key]: 'not qualifying', ['caWDVOpen:' + big.key]: 0, pbtOverride: 500000 });
  const bigRow = q2.derived.ca.rows.find(r => r.key === big.key);
  t.ok(bigRow.total === 0 && Math.abs(q2.derived.ca.total - (QA.total - big.total)) < 0.05, `${label}: "${big.category}" set to not qualifying → allowance removed (${money(q2.derived.ca.total)})`);
  t.ok(bigRow.wdvClose === bigRow.additions && bigRow.tempDiff === r2(bigRow.nbv - bigRow.additions) && q2.derived.deferred.cats.length === 1, `${label}: WDV rolls forward per category and feeds W3.3`);
  t.ok(q2.derived.comp.pbt.src === 'input' && q2.derived.comp.caUsed.v === q2.derived.ca.total && q2.derived.comp.dep.src === 'not entered', `${label}: in register mode the computation runs on inputs and W3.2`);
  t.ok(q.exceptions.filter(e => !/^EX-TAX-0[78]/.test(e.id)).length === 0, `${label}: no computation exceptions in register mode before inputs`);
  q.renderAll(t, label + ' register');
  q.exportCheck(t, label + ' register');
}

/* ---------------------------------------------------------------------- */
console.log('\n=== TAX — export round-trip and conclusion (client-a) ===');
{
  const eng = engagement(L.Core, '2025-02-28', 145000);
  const f = path.join(OUT, 'client-a', 'PBC-TB-01 Trial balance 2025-02-28.xlsx');
  const p = pipeline(L, f, CODE, eng, { pbtOverride: 1000000, caRows: 1, 'caCategory:ca1': 'Plant', 'caAdditions:ca1': 90000, 'noaAmount': 0, pyProvision: 0 });
  const wb = p.exportCheck(t, 'client-a');
  const out = path.join(__dirname, 'out-TAX-file.xlsx');
  L.XLSX.writeFile(wb, out);
  const re = L.XLSX.readFile(out);
  t.ok(re.SheetNames.length === wb.SheetNames.length, 'workbook survives the Excel round-trip');
  fs.unlinkSync(out);
  const wsC = wb.Sheets[Object.keys(wb.Sheets).find(n => n.startsWith('W3.1'))];
  const vals = Object.values(wsC).filter(c => c && typeof c === 'object' && 'v' in c).map(c => c.v);
  /* the computation shows the allowance as a deduction — "Less: capital allowances (30,000)" — so accept either sign */
  t.ok(vals.includes('Chargeable income') && vals.some(v => Math.abs(v) === 30000), 'W3.1 export carries the computation lines and the capital allowance (90,000 / 3, shown as a deduction)');
  const st = p.state().modules.TAX;
  const text = M.suggestConclusion(st, p.ctx());
  t.ok(typeof text === 'string' && text.length > 100 && /Capital allowances of 30000/.test(text), 'suggestConclusion produces text');
}

t.done();

function r2(n) { return Math.round(n * 100) / 100; }
