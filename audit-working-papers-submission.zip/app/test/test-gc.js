/* Headless test of the GC (Going concern) audit file against the synthetic going concern workbooks.
   Run:  node test/test-gc.js

   The uploaded sheet is management's monthly cash flow forecast. Its month headings ("Mar 25") coerce
   to numbers in Core.parseNumber, so Core.detectHeader prefers the metadata row above the table; in the
   shell the auditor corrects this with the header picker. This test reproduces that by falling back to
   the first row on which the module's required fields map.                                              */
const { load, counter, money, engagement, OUT, path, fs } = require('./spec-lib');
const L = load(['gc.js']);
const t = counter();
const CODE = 'GC';
const { Core, Modules } = L;

function pipeline(file, eng, cfgOverride = {}, prep) {
  const M = Modules.byCode[CODE];
  const buf = fs.readFileSync(file);
  const wbData = Core.readWorkbook(buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength), path.basename(file));
  const sheet = wbData.sheets[0];
  const tryRow = hr => { const clean = Core.cleanTable(sheet.rows, hr); const mapping = Core.proposeMapping(clean.headers, M.fields, clean.rows.filter(r => r.__kind === 'data').slice(0, 40)); return { hr, clean, mapping }; };
  let pick = tryRow(Core.detectHeader(sheet.rows));
  pick.fallback = false;
  const ok = p => M.fields.filter(f => f.required).every(f => p.mapping[f.key]) && Object.keys(p.mapping).filter(k => /^m\d+$/.test(k) && p.mapping[k]).length >= 6;
  if (!ok(pick)) { for (let i = 0; i < Math.min(30, sheet.rows.length); i++) { const p = tryRow(i); if (ok(p)) { pick = p; pick.fallback = true; break; } } }
  const { hr: headerRow, clean, mapping } = pick;
  const built = Core.buildRecords(clean, M.fields, mapping);
  const cfg = M.defaultConfig(); Object.assign(cfg, cfgOverride);
  if (prep) prep(built.records, cfg);
  const res = Core.runTests(M, built.records, cfg, eng);
  return { M, headerRow, fallback: pick.fallback, clean, mapping, built, cfg, res, records: built.records, exceptions: res.exceptions, derived: res.derived, eng,
    missingRequired() { return M.fields.filter(f => f.required && !mapping[f.key]).map(f => f.key); },
    ctx() { return { eng, cfg, d: res.derived, recs: built.records.filter(r => !r.__excluded), all: built.records, money: x => x, money0: x => x, pct: x => x, fmtDate: Core.fmtDate, r2: n => n == null ? null : Math.round(n * 100) / 100, pm: eng.materiality.pm, trivial: eng.materiality.trivial, M }; },
    state() { return { engagement: eng, modules: { [CODE]: { code: CODE, records: built.records, exceptions: res.exceptions, derived: res.derived, mapping,
      sources: [{ fileName: path.basename(file), hash: wbData.hash, sheetName: sheet.name, headerRow, rowCount: built.records.length, uploadedAt: wbData.uploadedAt, rawRows: sheet.rows }],
      config: cfg, cleanLog: clean.log, mapIssues: built.issues, edits: [], adjustments: [], aiBlocks: [], pageNotes: {}, trail: [], comments: '', conclusion: '' } } }; },
    renderAll(t, label) {
      const st = this.state().modules[CODE], c = this.ctx();
      for (const pg of M.pages.filter(p => p.render)) {
        let specs = null, err = null;
        try { specs = pg.render(st, c); } catch (e) { err = e; }
        t.ok(Array.isArray(specs) && specs.length > 0 && !err, `${label}: ${pg.ref} ${pg.title} renders ${specs ? specs.length + ' specs' : ''}`, err && (err.stack || err.message));
        if (specs) { let tErr = null; try { L.SpecXL.toRows(specs, pg.id, st); } catch (e) { tErr = e; } t.ok(!tErr, `${label}: ${pg.ref} converts to worksheet rows`, tErr && tErr.message); }
        if (pg.flag) { let fErr = null; try { pg.flag(st, res.derived); } catch (e) { fErr = e; } t.ok(!fErr, `${label}: ${pg.ref} flag() does not throw`, fErr && fErr.message); }
      }
    },
    exportCheck(t, label) {
      const wb = L.Exporter.build(this.state(), CODE);
      const rendered = M.pages.filter(p => p.render);
      const expected = rendered.map(p => `${p.ref} ${p.title}`.replace(/[\[\]\*\?\/\\:]/g, '').slice(0, 31));
      const missing = expected.filter(n => !wb.SheetNames.includes(n));
      t.ok(missing.length === 0, `${label}: one sheet per rendered page (${rendered.length} pages)`, missing.join(', '));
      ['00 Index', 'Exceptions', '01 Source 1', '02 Cleaned data', '03 Mapping'].forEach(n => t.ok(wb.SheetNames.includes(n), `${label}: sheet "${n}"`));
      return wb;
    }
  };
}

/* The three clients share one forecast shape: 12 months from the reporting date, approved ~8 months in,
   two uncommitted inflows (1.5m placement in month 5, 0.6m shareholder loan in month 8).                */
const CLIENTS = [
  { c: 'client-a', ye: '2025-02-28', file: 'PBC-GC-01 Going concern assessment 2025-02-28.xlsx', approval: '20/06/2025', firstNegGross: 7, months: ['Mar 2025', 'Feb 2026'] },
  { c: 'client-b', ye: '2025-09-30', file: 'PBC-GC-01 Going concern assessment 2025-09-30.xlsx', approval: '20/01/2026', firstNegGross: 5, months: ['Oct 2025', 'Sep 2026'] },
  { c: 'client-d', ye: '2025-09-30', file: 'PBC-GC-01 Going concern assessment 2025-09-30.xlsx', approval: '2026-01-20', firstNegGross: 7, months: ['Oct 2025', 'Sep 2026'] }
];
/* firstNegGross is the first month (index 0 = first forecast month) in which GROSS LIQUIDITY — cash before the uncommitted
   inflows PLUS the undrawn facility headroom line — is negative. Gross cash alone turns negative earlier (client-b Jan 2026,
   client-d Mar 2026); the headroom of 250,000 less 9,000 a month carries it two more months.                              */
/* auditor-entered schedules, transcribed from the client's other three sheets */
const COVENANTS = { covenantRows: 4,
  'covFacility:c1': 'Term loan - equipment', 'covName:c1': 'Net gearing', 'covOp:c1': '<=', 'covThreshold:c1': 1.5, 'covFreq:c1': 'Half-yearly', 'covActual:c1': 1.18, 'covForecast:c1': 1.41, 'covConsequence:c1': 'Immediately repayable on demand', 'covCurrent:c1': 'N',
  'covFacility:c2': 'Working capital facility', 'covName:c2': 'Interest cover', 'covOp:c2': '>=', 'covThreshold:c2': 3, 'covFreq:c2': 'Quarterly', 'covActual:c2': 3.42, 'covForecast:c2': 2.61, 'covConsequence:c2': 'Immediately repayable on demand', 'covCurrent:c2': 'N',
  'covFacility:c3': 'Property mortgage', 'covName:c3': 'Debt service cover', 'covOp:c3': '>=', 'covThreshold:c3': 1.25, 'covFreq:c3': 'Annually', 'covActual:c3': 1.31, 'covForecast:c3': 1.27, 'covConsequence:c3': 'Step-up margin', 'covCurrent:c3': 'N',
  'covFacility:c4': 'Bridging loan', 'covName:c4': 'Minimum tangible net worth', 'covOp:c4': '>=', 'covThreshold:c4': 2000000, 'covFreq:c4': 'Annually', 'covActual:c4': 2400080.35, 'covForecast:c4': 1920000, 'covConsequence:c4': 'Immediately repayable on demand', 'covCurrent:c4': 'N' };
const facilities = (m1, m2, m3, m4) => ({ facilityRows: 4,
  'facName:f1': 'Term loan - equipment', 'facLender:f1': 'Bank A', 'facLimit:f1': 480000, 'facDrawn:f1': 279297, 'facMaturity:f1': m1, 'facClientMonths:f1': 14, 'facRenewal:f1': 'n/a', 'facEvidence:f1': 'Facility letter',
  'facName:f2': 'Working capital facility', 'facLender:f2': 'Bank B', 'facLimit:f2': 300000, 'facDrawn:f2': 0, 'facMaturity:f2': m2, 'facClientMonths:f2': 0, 'facRenewal:f2': 'N', 'facEvidence:f2': 'Verbal indication only',
  'facName:f3': 'Property mortgage', 'facLender:f3': 'Bank C', 'facLimit:f3': 1200000, 'facDrawn:f3': 0, 'facMaturity:f3': m3, 'facClientMonths:f3': 80, 'facRenewal:f3': 'n/a', 'facEvidence:f3': 'Facility letter',
  'facName:f4': 'Bridging loan', 'facLender:f4': 'Bank A', 'facLimit:f4': 250000, 'facDrawn:f4': 0, 'facMaturity:f4': m4, 'facClientMonths:f4': 3, 'facRenewal:f4': 'N', 'facEvidence:f4': 'Under negotiation' });
const FACILITIES = { 'client-a': facilities('22/08/2026', '03/06/2025', '29/10/2032', '26/09/2025'), 'client-b': facilities('24/03/2027', '03/01/2026', '31/05/2033', '28/04/2026'), 'client-d': facilities('24/03/2027', '03/01/2026', '31/05/2033', '28/04/2026') };
const PLANS = { planRows: 5,
  'planName:p1': 'Equity placement to new institutional investor', 'planCash:p1': 1500000, 'planTiming:p1': 'Month 5', 'planStatus:p1': 'Term sheet signed, subject to due diligence', 'planCommitted:p1': 'Uncommitted', 'planEvidence:p1': 'Non-binding term sheet', 'planControl:p1': 'N',
  'planName:p2': 'Further shareholder loan', 'planCash:p2': 600000, 'planTiming:p2': 'Month 8', 'planStatus:p2': 'Discussed verbally with controlling shareholder', 'planCommitted:p2': 'Uncommitted', 'planEvidence:p2': 'None', 'planControl:p2': 'N',
  'planName:p3': 'Renewal of working capital facility', 'planCash:p3': 300000, 'planTiming:p3': 'Month 3 onwards', 'planStatus:p3': 'Application submitted', 'planCommitted:p3': 'Uncommitted', 'planEvidence:p3': 'Verbal indication from relationship manager', 'planControl:p3': 'N',
  'planName:p4': 'Deferral of discretionary capital expenditure', 'planCash:p4': 180000, 'planTiming:p4': 'Months 1-12', 'planStatus:p4': 'Board approved', 'planCommitted:p4': 'Committed', 'planEvidence:p4': 'Board minutes dated within the period', 'planControl:p4': 'Y',
  'planName:p5': 'Headcount reduction in the export division', 'planCash:p5': 240000, 'planTiming:p5': 'Months 2-12', 'planStatus:p5': 'Announced to staff', 'planCommitted:p5': 'Committed', 'planEvidence:p5': 'Restructuring plan and notices', 'planControl:p5': 'Y' };
const TB = { tbTotalAssets: 10666056.81, tbTotalLiabilities: 3354576.88, tbCurrentAssets: 5276535, tbCurrentLiabilities: 3083885.88, tbPbtCY: -1250650, tbPbtPY: -1075000, tbOperatingCF: -420000 };

console.log('\n=== GC — module registration ===');
const M = Modules.byCode.GC;
t.ok(M && M.name === 'Going Concern', 'GC registered via Modules.register');
t.ok(M.pages.filter(p => p.render).length === 7, 'seven rendered working papers (GC, GC1–GC6)');
t.ok(!M.suggestConclusion, 'no conclusion drafting helper — the going concern conclusion is the auditor\'s alone');
t.ok(M.tests.map(x => x.id).filter(id => /^EX-GC-0[1-9]$/.test(id)).length === 9, 'EX-GC-01..09 defined');

for (const { c, ye, file, approval, firstNegGross, months } of CLIENTS) {
  const eng = engagement(L.Core, ye, 145000);
  const f = path.join(OUT, c, file);
  const label = c;
  console.log(`\n=== ${label} / ${file} ===`);
  const full = { approvalDate: approval, auditedCash: 341486, sensitivityPrepared: 'N', ...COVENANTS, ...FACILITIES[c], ...PLANS, ...TB };
  const p = pipeline(f, eng, full);
  const d = p.derived, F = d.forecast, P = d.period;
  console.log(`  header row ${p.headerRow + 1}${p.fallback ? ' (fallback scan; detectHeader chose the metadata row)' : ''}; ${p.records.length} lines; ${F.N} months ${F.months[0]?.label} – ${F.months[F.N - 1]?.label}`);
  console.log(`  period: ${P.monthsFromReporting} months from reporting date, ${P.monthsFromApproval} from approval; min gross liquidity ${money(F.minGross?.grossLiq)} in ${F.minGross?.label}; min mitigated ${money(F.minMit?.mitLiq)}; uncommitted inflows ${money(F.totals.uncommitted)}`);
  console.log(`  stress: break-even receipts shortfall ${(d.stress.beReceipts * 100).toFixed(2)}%, payments +${(d.stress.bePayments * 100).toFixed(2)}%; delays ${JSON.stringify(d.stress.delays.map(x => [x.delay, x.firstNeg]))}`);
  console.log(`  exceptions: ${p.exceptions.map(e => e.id).sort().join(', ')}`);

  /* mapping and classification */
  t.ok(p.missingRequired().length === 0, `${label}: required fields mapped (line, month 1)`, p.missingRequired().join(', '));
  t.ok(F.N === 12 && Object.keys(p.mapping).filter(k => /^m\d+$/.test(k) && p.mapping[k]).length === 12 && !p.mapping.m13, `${label}: twelve month columns mapped in order, the total column not taken as a month`);
  t.ok(p.mapping.total && p.mapping.total.heading === 'Total', `${label}: total column mapped`);
  t.ok(F.months[0].label === months[0] && F.months[11].label === months[1], `${label}: month sequence ${months[0]} – ${months[1]} derived from the reporting date`);
  t.ok(p.mapping.m1.heading.replace(/\s+/g, ' ').slice(0, 3).toLowerCase() === months[0].slice(0, 3).toLowerCase(), `${label}: client's first month heading "${p.mapping.m1.heading}" agrees to the assumed start`);
  const kinds = Object.fromEntries(p.records.map(r => [r.line, r.__kind]));
  t.ok(kinds['Receipts from customers'] === 'Operating' && kinds['Payments to suppliers'] === 'Operating' && kinds['Payroll and statutory'] === 'Operating', `${label}: operating lines classified`);
  t.ok(kinds['Loan principal repayments'] === 'Debt service' && kinds['Interest paid'] === 'Debt service' && kinds['Capital expenditure'] === 'Capital expenditure', `${label}: debt service and capex classified`);
  t.ok(kinds['Proceeds from proposed share placement'] === 'Uncommitted mitigating action' && kinds['Shareholder loan (uncommitted)'] === 'Uncommitted mitigating action', `${label}: the two mitigating inflows classified uncommitted`);
  t.ok(['Net cash flow for the month', 'Opening cash', 'Closing cash', 'Undrawn facility headroom'].every(k => kinds[k] === 'Summary line (excluded)'), `${label}: summary lines recognised and excluded from the flows`);
  t.ok(F.hasOpening && F.hasClosing && F.hasHeadroom, `${label}: opening, closing and headroom lines found`);

  /* arithmetic proves the client's forecast */
  t.ok(F.clientOpening === 341486 && F.openingDiff === 0 && !p.exceptions.some(e => e.id === 'EX-GC-09'), `${label}: opening cash 341,486 agrees to the audited cash entered; EX-GC-09 silent`);
  t.ok(F.monthly.every(m => Math.abs(m.closingDiff) <= 0.02), `${label}: recomputed mitigated closing cash agrees to the client's closing cash every month`, F.monthly.map(m => m.closingDiff).join(','));
  t.ok(F.monthly.every(m => m.netDiff != null && Math.abs(m.netDiff) <= 0.02), `${label}: recomputed net flow agrees to the client's net cash flow line`);
  t.ok(Math.abs(F.totals.uncommitted - 2100000) < 0.01, `${label}: uncommitted inflows in the forecast total 2,100,000`);
  t.ok(F.monthly.every(m => Math.abs(m.grossLiq - (m.grossCash + m.headroom)) < 0.01 && Math.abs(m.mitCash - (m.grossCash + F.monthly.slice(0, m.i + 1).reduce((s, x) => s + x.uncommitted, 0))) < 0.05), `${label}: gross and mitigated series reconcile`);
  t.ok(F.negGross.length > 0 && F.firstNegGross === firstNegGross && F.minGross.grossLiq < 0, `${label}: gross liquidity turns negative first in ${F.months[firstNegGross].label} (month ${firstNegGross + 1})`, `first negative month index ${F.firstNegGross}`);
  t.ok(F.minMit.mitLiq > 0 || c === 'client-b', `${label}: mitigated liquidity ${F.minMit.mitLiq >= 0 ? 'stays positive — the uncommitted inflows are what rescues the forecast' : 'also negative (client-b closing cash is negative in month 4)'}`);
  const e07 = p.exceptions.find(e => e.id === 'EX-GC-07');
  t.ok(e07 && e07.recordKey === 'forecast' && Math.abs(e07.difference - F.minGross.grossLiq) < 0.01 && e07.severity === 'above-pm', `${label}: EX-GC-07 negative gross liquidity raised with the minimum month figure`);
  t.ok(!p.exceptions.some(e => e.id === 'EX-GC-20'), `${label}: every forecast line casts to the client's total column`);

  /* assessment period */
  t.ok(P.monthsFromReporting === 12 && P.monthsFromApproval === 8, `${label}: 12 months from the reporting date, 8 from approval (client's own figure 8)`);
  t.ok(P.deficient2024 && !P.deficient2022 && P.deficient && P.shortfall === 4, `${label}: compliant on the 2022 reading, deficient on the 2024 basis by 4 months`);
  const e01 = p.exceptions.find(e => e.id === 'EX-GC-01');
  t.ok(e01 && e01.actual === 8 && e01.expected === 12 && /extension/.test(e01.detail), `${label}: EX-GC-01 assessment period too short (${e01 && e01.detail.slice(0, 60)}…)`);
  const p22 = pipeline(f, eng, { ...full, periodBasis: '2022' });
  t.ok(!p22.exceptions.some(e => e.id === 'EX-GC-01') && p22.derived.period.monthsSelected === 12, `${label}: on the 2022 basis the period test passes`);
  const pNoApp = pipeline(f, eng, { ...full, approvalDate: '' });
  t.ok(pNoApp.derived.period.monthsFromApproval == null && !pNoApp.exceptions.some(e => e.id === 'EX-GC-01'), `${label}: without an approval date the 2024 test is not assessable (no false exception)`);

  /* GC2 covenants */
  t.ok(d.covenants.length === 4 && d.covenants.every(x => x.actualOK === true), `${label}: all four covenants compliant at the year end`);
  const breaches = d.covenants.filter(x => x.breachForecast).map(x => x.name);
  t.ok(breaches.length === 2 && breaches.includes('Interest cover') && breaches.includes('Minimum tangible net worth'), `${label}: interest cover and tangible net worth forecast to breach`, breaches.join(', '));
  const e02 = p.exceptions.filter(e => e.id === 'EX-GC-02'), e03 = p.exceptions.filter(e => e.id === 'EX-GC-03');
  t.ok(e02.length === 2 && e03.length === 2 && e03.every(e => /repayable/i.test(e.detail)), `${label}: EX-GC-02 ×2 and EX-GC-03 ×2 (both breaching facilities repayable on demand, not classified current)`);
  const pCur = pipeline(f, eng, { ...full, 'covCurrent:c2': 'Y', 'covCurrent:c4': 'Y' });
  t.ok(pCur.exceptions.filter(e => e.id === 'EX-GC-03').length === 0 && pCur.exceptions.filter(e => e.id === 'EX-GC-02').length === 2, `${label}: classifying the borrowings current clears EX-GC-03, not EX-GC-02`);
  t.ok(Math.abs(d.covenants[3].headroom - (-80000)) < 0.01 && Math.abs(d.covenants[0].headroom - 0.09) < 0.001, `${label}: headroom to threshold computed on both test directions`);

  /* GC3 facilities */
  const fac = Object.fromEntries(d.facilities.map(x => [x.name, x]));
  t.ok(d.facilities.length === 4 && fac['Working capital facility'].monthsToMaturity === 0 && fac['Bridging loan'].monthsToMaturity === 3 && fac['Term loan - equipment'].monthsToMaturity === 14, `${label}: months to maturity from the approval date recomputed (0, 3, 14)`);
  t.ok(fac['Property mortgage'].monthsDiff != null && fac['Property mortgage'].monthsDiff !== 0 && fac['Bridging loan'].monthsDiff === 0, `${label}: client's months-to-maturity compared; property mortgage differs (client ${fac['Property mortgage'].clientMonths} vs ${fac['Property mortgage'].monthsToMaturity})`);
  const e04 = p.exceptions.filter(e => e.id === 'EX-GC-04').map(e => e.recordKey);
  t.ok(e04.length === 2 && e04.includes('Working capital facility') && e04.includes('Bridging loan'), `${label}: EX-GC-04 for the two facilities maturing in the period with no written renewal`, e04.join(', '));
  /* limit − drawn on every line: 200,703 + 300,000 + 1,200,000 + 250,000 (the client shows nil undrawn on the two term facilities) */
  t.ok(Math.abs(d.facTotals.undrawn - 1950703) < 0.01 && Math.abs(fac['Term loan - equipment'].undrawn - 200703) < 0.01, `${label}: undrawn recomputed from limit less drawn`);
  const pRen = pipeline(f, eng, { ...full, 'facRenewal:f2': 'Y' });
  t.ok(pRen.exceptions.filter(e => e.id === 'EX-GC-04').length === 1, `${label}: written renewal on one facility clears its EX-GC-04`);

  /* GC4 plans */
  t.ok(d.plans.length === 5 && Math.abs(d.planTotals.reliance - 2400000) < 0.01 && Math.abs(d.planTotals.committed - 420000) < 0.01, `${label}: 2,400,000 of plans uncommitted / outside management's control; 420,000 committed`);
  const e05 = p.exceptions.find(e => e.id === 'EX-GC-05'), e06 = p.exceptions.filter(e => e.id === 'EX-GC-06');
  t.ok(e05 && e05.recordKey === 'plans' && d.reliance.minGrossHeadroom === 0 && e05.actual === 2400000, `${label}: EX-GC-05 — gross headroom is exhausted so all uncommitted funding is relied upon`);
  t.ok(e06.length === 1 && e06[0].recordKey === 'Further shareholder loan' && e06[0].difference === 600000, `${label}: EX-GC-06 only for the shareholder loan with no evidence`);
  const pEv = pipeline(f, eng, { ...full, 'planEvidence:p2': 'Signed loan agreement dated within the period' });
  t.ok(!pEv.exceptions.some(e => e.id === 'EX-GC-06'), `${label}: recording evidence clears EX-GC-06`);

  /* GC indicators */
  const I = d.indicators, byId = Object.fromEntries(I.computed.map(x => [x.id, x]));
  t.ok(byId.C1.effective === false && byId.C2.effective === false && byId.C3.effective === true && byId.C4.effective === true, `${label}: computed indicators — net assets positive, negative operating cash flow and recurring losses present`);
  t.ok(byId.C5.effective === true && byId.C6.effective === true && byId.C7.effective === true && byId.C8.effective === true, `${label}: covenant, facility, liquidity and reliance indicators derived from GC1–GC4`);
  t.ok(I.presentComputed === 6 && I.anyPresent, `${label}: six computed indicators present`);
  const pOv = pipeline(f, eng, { ...full, 'indOverride:C3': 'N' });
  t.ok(pOv.derived.indicators.presentComputed === 5, `${label}: auditor override flips a computed indicator`);

  /* GC5 stress */
  const S = d.stress;
  t.ok(S.basis === 'mitigated' && S.beReceipts > 0 && S.beReceipts < 0.5, `${label}: break-even receipts shortfall ${(S.beReceipts * 100).toFixed(2)}% on the mitigated basis`);
  {  /* verify the bisection: applying the break-even cut gives min liquidity ~0 */
    const cut = S.beReceipts; let cash = F.openingUsed, mn = Infinity;
    F.monthly.forEach(m => { cash += m.receipts * (1 - cut) + m.payments + m.debt + m.capex + m.committed + m.uncommitted; mn = Math.min(mn, cash + m.headroom); });
    t.ok(Math.abs(mn) < 0.5, `${label}: at the break-even shortfall the minimum liquidity is nil (${mn.toFixed(4)})`);
  }
  t.ok(S.delays.length === 3 && S.delays[0].firstNeg != null && S.delays[0].min < 0, `${label}: a one-month collection delay exhausts liquidity`);
  const pG = pipeline(f, eng, { ...full, stressBasis: 'gross' });
  t.ok(pG.derived.stress.alreadyExhausted && pG.derived.stress.beReceipts === 0, `${label}: on the gross basis liquidity is already exhausted (break-even 0%)`);
  const e08 = p.exceptions.find(e => e.id === 'EX-GC-08');
  t.ok(e08 && e08.recordKey === 'forecast' && /shortfall in receipts/.test(e08.detail), `${label}: EX-GC-08 no downside scenario prepared by management`);
  t.ok(!pipeline(f, eng, { ...full, sensitivityPrepared: 'Y' }).exceptions.some(e => e.id === 'EX-GC-08'), `${label}: EX-GC-08 silent once management's downside scenario is recorded`);

  /* planted set */
  const planted = ['EX-GC-01', 'EX-GC-02', 'EX-GC-03', 'EX-GC-04', 'EX-GC-05', 'EX-GC-06', 'EX-GC-07', 'EX-GC-08'];
  const got = new Set(p.exceptions.map(e => e.id));
  t.ok(planted.every(id => got.has(id)), `${label}: all planted exceptions EX-GC-01..08 raised`, planted.filter(id => !got.has(id)).join(', '));

  p.renderAll(t, label);
  p.exportCheck(t, label);
}

/* ---------------------------------------------------------------------- */
console.log('\n=== GC — reporting decision, disclosure, reclassification and opening cash (client-a) ===');
{
  const eng = engagement(L.Core, '2025-02-28', 145000);
  const f = path.join(OUT, 'client-a', 'PBC-GC-01 Going concern assessment 2025-02-28.xlsx');
  const base = { approvalDate: '20/06/2025', auditedCash: 341486 };

  /* EX-GC-09: opening cash vs audited cash (the TB carries 861,930 of cash) */
  const p09 = pipeline(f, eng, { ...base, auditedCash: 861930 });
  const e09 = p09.exceptions.find(e => e.id === 'EX-GC-09');
  t.ok(e09 && Math.abs(e09.difference - (341486 - 861930)) < 0.01 && e09.severity === 'above-pm', 'EX-GC-09 raised when forecast opening cash differs from audited cash');

  /* reclassifying the placement as committed changes the gross position */
  const pRe = pipeline(f, eng, base, recs => recs.forEach(r => { if (/placement/i.test(r.line)) r.__wp = { forecast: { kind: 'Committed mitigating action' } }; }));
  t.ok(pRe.records.find(r => /placement/i.test(r.line)).__kind === 'Committed mitigating action' && Math.abs(pRe.derived.forecast.totals.uncommitted - 600000) < 0.01, 'auditor reclassification on GC1 is honoured');
  t.ok(pRe.derived.forecast.minGross.grossLiq > pipeline(f, eng, base).derived.forecast.minGross.grossLiq, 'committed inflow lifts the gross liquidity floor');
  const pEx = pipeline(f, eng, base, recs => recs.forEach(r => { if (/placement|shareholder/i.test(r.line)) r.__wp = { forecast: { kind: 'Committed mitigating action' } }; }));
  t.ok(!pEx.exceptions.some(e => e.id === 'EX-GC-07') && pEx.derived.forecast.negGross.length === 0, 'with both inflows treated as committed, gross liquidity stays positive and EX-GC-07 clears');
  const pHead = pipeline(f, eng, { ...base, includeHeadroom: false });
  t.ok(pHead.derived.forecast.monthly.every(m => m.headroom === 0) && pHead.derived.forecast.minGross.grossLiq < pipeline(f, eng, base).derived.forecast.minGross.grossLiq, 'excluding undrawn facilities lowers liquidity');
  const pStart = pipeline(f, eng, { ...base, forecastStart: 'Apr 2025' });
  t.ok(pStart.derived.forecast.months[0].label === 'Apr 2025' && pStart.derived.period.monthsFromApproval === 9, 'first forecast month override shifts the period arithmetic');

  /* tampering with a line total surfaces EX-GC-20 */
  /* the client's Total column is a formula with no cached value, so seed a client total 1,000 above the sum of the months */
  const pCast = pipeline(f, eng, base, recs => { const r = recs.find(x => /receipts/i.test(x.line)); r.total = Object.keys(r).filter(k => /^m\d+$/.test(k)).reduce((s, k) => s + (Number(r[k]) || 0), 0) + 1000; });
  t.ok(pCast.exceptions.some(e => e.id === 'EX-GC-20' && Math.abs(e.difference - 1000) < 0.01), 'EX-GC-20 raised when a line does not cast to the client\'s total');

  /* GC6 reporting decision table */
  const rep = cfg => pipeline(f, eng, { ...base, ...cfg }).derived.reporting;
  t.ok(rep({ mgmtAssessment: 'Y', basisAppropriate: 'Y', materialUncertainty: 'N' }).opinion === 'Unmodified', 'decision table: basis Y, no MU → unmodified');
  t.ok(/Unmodified with Material Uncertainty/.test(rep({ mgmtAssessment: 'Y', basisAppropriate: 'Y', materialUncertainty: 'Y', disclosureAdequate: 'Y' }).opinion), 'decision table: MU adequately disclosed → unmodified with MURGC section');
  t.ok(/Qualified or adverse/.test(rep({ mgmtAssessment: 'Y', basisAppropriate: 'Y', materialUncertainty: 'Y', disclosureAdequate: 'N' }).opinion), 'decision table: MU inadequately disclosed → qualified or adverse');
  t.ok(rep({ mgmtAssessment: 'Y', basisAppropriate: 'N' }).opinion === 'Adverse', 'decision table: basis inappropriate → adverse regardless of disclosure');
  t.ok(/disclaimer/.test(rep({ mgmtAssessment: 'N' }).opinion), 'fifth path: management unwilling to assess → consider qualified / disclaimer');
  t.ok(rep({}).opinion === '' && rep({}).complete === false, 'no opinion derived until the conclusions are entered');
  const p11 = pipeline(f, eng, { ...base, mgmtAssessment: 'Y', basisAppropriate: 'Y', materialUncertainty: 'Y', disclosureAdequate: 'N' });
  t.ok(p11.exceptions.some(e => e.id === 'EX-GC-11'), 'EX-GC-11 material uncertainty with inadequate disclosure');
  const p13 = pipeline(f, eng, { ...base, mgmtAssessment: 'Y', basisAppropriate: 'Y', materialUncertainty: 'Y', disclosureAdequate: 'Y', gcDisclosure: { D3: { answer: 'N', comment: '' } } });
  t.ok(p13.exceptions.some(e => e.id === 'EX-GC-11') && p13.exceptions.some(e => e.id === 'EX-GC-13'), 'checklist gap contradicts "disclosure adequate" → EX-GC-11 and EX-GC-13');

  /* export carries the auditor's schedules */
  const pAll = pipeline(f, eng, { ...base, ...COVENANTS, ...FACILITIES['client-a'], ...PLANS, ...TB, sensitivityPrepared: 'N', mgmtAssessment: 'Y', basisAppropriate: 'Y', materialUncertainty: 'Y', disclosureAdequate: 'Y' });
  const wb = pAll.exportCheck(t, 'client-a with inputs');
  const cells = ws => Object.values(ws).filter(c => c && typeof c === 'object' && 'v' in c).map(c => c.v);
  t.ok(cells(wb.Sheets['GC2 Covenant compliance']).includes('Minimum tangible net worth'), 'GC2 export carries the covenants entered');
  t.ok(cells(wb.Sheets['GC4 Management\'s plans']).includes('Further shareholder loan'), 'GC4 export carries the plans entered');
  t.ok(cells(wb.Sheets['GC6 Reporting decision']).some(v => /Material Uncertainty Related to Going Concern/.test(String(v))), 'GC6 export shows the derived opinion');
  const out = path.join(__dirname, 'out-GC-file.xlsx');
  L.XLSX.writeFile(wb, out);
  const re = L.XLSX.readFile(out);
  t.ok(re.SheetNames.length === wb.SheetNames.length, 'workbook survives the Excel round-trip');
  fs.unlinkSync(out);
}

t.done();
