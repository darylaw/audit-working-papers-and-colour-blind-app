/* Headless test of src/xlsxstyle.js -- the styled .xlsx writer.
   Run:  node test/test-xlsxstyle.js                                          */
const { load, counter, engagement, pipeline, OUT, APP, path, fs } = require('./spec-lib');
const t = counter();

const SRC = path.join(APP, 'src');
const XLSX = require(path.join(SRC, 'vendor', 'xlsx.full.min.js'));
XLSX.set_fs(fs);

/* load the file the way build.py will: plain script, no module system */
const StyledXLSX = new Function('require', 'module', 'exports',
  fs.readFileSync(path.join(SRC, 'xlsxstyle.js'), 'utf8') + '\nreturn StyledXLSX;')(require, { exports: {} }, {});

/* --------------------------------------------------- a stored-zip reader -- */
/* Only needs to read what we write: method 0, no zip64, no data descriptors. */
function unzip(bytes) {
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let eo = bytes.length - 22;
  while (eo >= 0 && dv.getUint32(eo, true) !== 0x06054b50) eo--;
  if (eo < 0) throw new Error('no end-of-central-directory record');
  const n = dv.getUint16(eo + 10, true);
  let at = dv.getUint32(eo + 16, true);
  const out = {};
  for (let i = 0; i < n; i++) {
    if (dv.getUint32(at, true) !== 0x02014b50) throw new Error('bad central directory entry ' + i);
    const method = dv.getUint16(at + 10, true), crc = dv.getUint32(at + 16, true);
    const csize = dv.getUint32(at + 20, true), usize = dv.getUint32(at + 24, true);
    const nlen = dv.getUint16(at + 28, true), elen = dv.getUint16(at + 30, true), clen = dv.getUint16(at + 32, true);
    const lho = dv.getUint32(at + 42, true);
    const name = Buffer.from(bytes.subarray(at + 46, at + 46 + nlen)).toString('utf8');
    if (dv.getUint32(lho, true) !== 0x04034b50) throw new Error('bad local header for ' + name);
    if (method !== 0) throw new Error('unexpected compression method for ' + name);
    const dataAt = lho + 30 + dv.getUint16(lho + 26, true) + dv.getUint16(lho + 28, true);
    const data = bytes.subarray(dataAt, dataAt + csize);
    out[name] = { text: Buffer.from(data).toString('utf8'), crc, size: usize, data };
    at += 46 + nlen + elen + clen;
  }
  return { files: out, count: n };
}

/* balanced-tag check; enough to catch an unclosed element or a stray '<' */
function wellFormed(xml) {
  const stack = [];
  const re = /<(\/?)([A-Za-z_][\w.:-]*)((?:"[^"]*"|'[^']*'|[^>"'])*?)(\/?)>|<\?[^>]*\?>|<!--[\s\S]*?-->/g;
  let m, last = 0;
  while ((m = re.exec(xml))) {
    const between = xml.slice(last, m.index);
    if (between.indexOf('<') >= 0 || between.indexOf('>') >= 0) return 'raw angle bracket in text: ' + JSON.stringify(between.slice(0, 40));
    if (/&(?!(amp|lt|gt|quot|apos|#\d+|#x[0-9a-fA-F]+);)/.test(between)) return 'unescaped & in text';
    last = m.index + m[0].length;
    if (m[2] === undefined) continue;
    if (m[1]) { if (stack.pop() !== m[2]) return 'close mismatch at </' + m[2] + '>'; }
    else if (!m[4]) stack.push(m[2]);
  }
  if (xml.slice(last).indexOf('<') >= 0) return 'trailing markup';
  return stack.length ? 'unclosed <' + stack.join('>, <') + '>' : null;
}

const S = (v, s, extra) => Object.assign({ t: 's', v, s }, extra);
const N = (v, s, extra) => Object.assign({ t: 'n', v, s }, extra);

/* =========================================================== 1. CRC-32 === */
console.log('\n=== CRC-32 ===');
t.ok(StyledXLSX._crc32('123456789') === 0xcbf43926, 'CRC32("123456789") === 0xCBF43926', StyledXLSX._crc32('123456789').toString(16));
t.ok(StyledXLSX._crc32('') === 0, 'CRC32("") === 0');
t.ok(StyledXLSX._crc32('The quick brown fox jumps over the lazy dog') === 0x414fa339, 'CRC32(pangram) === 0x414FA339');
t.ok(StyledXLSX._utf8('café € 😀').length === 14, 'UTF-8 encoder handles 2-, 3- and 4-byte sequences', String(StyledXLSX._utf8('café € 😀').length));
t.ok(StyledXLSX._colName(0) === 'A' && StyledXLSX._colName(25) === 'Z' && StyledXLSX._colName(26) === 'AA' && StyledXLSX._colName(701) === 'ZZ' && StyledXLSX._colName(702) === 'AAA', 'column names past Z and ZZ');

/* ================================================ 2. the kitchen-sink wb === */
console.log('\n=== a workbook with everything in it ===');

const NAVY = '#152238', GOLD = '#c9a227';
const title = { bold: true, size: 16, color: NAVY };
const hdr = { bold: true, color: '#ffffff', fill: NAVY, align: { h: 'center', v: 'center', wrap: true }, border: 'thin' };
const hdr2 = { bold: true, color: NAVY, fill: '#f2f2f2', align: { h: 'center', wrap: true }, border: { bottom: 'medium' } };
const money = { numFmt: '#,##0.00;[Red](#,##0.00)', align: { h: 'right' } };
const total = { bold: true, numFmt: '#,##0.00', border: { top: 'thin', bottom: 'double' } };
const prose = { align: { wrap: true, v: 'top', indent: 1 }, size: 9, italic: true };
const dateS = { numFmt: 'dd/mm/yyyy', align: { h: 'center' } };
const pctS = { numFmt: '0.00%' };
const tick = { bold: true, color: '#1a7f37', align: { h: 'center' } };
const warn = { fill: GOLD, bold: true, border: { all: 'hair', bottom: { style: 'medium', color: NAVY } } };
const note = { font: 'Consolas', size: 8, color: '#666666' };
const rot = { align: { h: 'center', rotate: 90 }, bold: true };

const ws1 = {
  A1: S('Trade payables — sample testing', title),
  A2: S('Client', { bold: true }), B2: S("O'Brien & Sons <Pte> Ltd \"HQ\""),
  A4: S('Supplier', hdr), B4: S('Invoice', hdr), C4: S('Date', hdr), D4: S('Amount', hdr), E4: S('%', hdr), F4: S('Agreed', hdr), G4: S('Comment', hdr),
  A5: S('Alpha Supplies', hdr2), B5: S('INV-001', hdr2), C5: { t: 'd', v: new Date(2025, 1, 28), s: dateS },
  D5: N(1234.5, money), E5: N(0.0725, pctS), F5: { t: 'b', v: true, s: tick }, G5: S('Traced to GRN and PO. No exceptions noted in respect of this item.', prose),
  A6: S('Beta Trading'), B6: S('INV-002'), C6: { t: 'd', v: new Date(2024, 11, 31), s: dateS },
  D6: N(-98765.4321, money), E6: N(0.5, pctS), F6: { t: 'b', v: false, s: warn }, G6: S('Credit note — see E3.2', prose),
  A7: S('Gamma Pte Ltd'), B7: S('INV-003'), C7: { t: 'd', v: new Date(2025, 0, 15), s: dateS },
  D7: N(0, money), E7: N(0, pctS), F7: { t: 'z', v: null, s: warn }, G7: S('', prose),
  A9: S('Total', total), D9: { t: 'n', f: 'SUM(D5:D7)', s: total }, E9: { t: 'n', f: 'AVERAGE(E5:E7)', s: pctS },
  B9: { t: 'n', f: 'COUNT(D5:D7)' }, C9: { t: 's', f: 'CONCATENATE("n=",COUNT(D5:D7))', v: 'n=3' },
  A11: S('Long note', note), B11: S('x'.repeat(40000), prose),
  A12: S('Control chars  kept legal', note),
  A13: S('rot', rot), B13: N(1e21), C13: N(NaN), D13: N(Infinity),
  '!ref': 'A1:G13',
  '!cols': [{ wch: 26 }, { wch: 14 }, { wch: 12 }, { wch: 16 }, { wch: 9 }, { wch: 9 }, { wch: 44 }],
  '!rows': [{ hpt: 22 }, , , { hpt: 30 }],
  '!merges': [{ s: { r: 0, c: 0 }, e: { r: 0, c: 6 } }, { s: { r: 2, c: 0 }, e: { r: 2, c: 2 } }, { s: { r: 4, c: 4 }, e: { r: 4, c: 4 } }],
  '!view': { freeze: { r: 4, c: 1 }, gridlines: false, zoom: 90 },
  '!printSetup': { landscape: true, fitToWidth: 1, repeatRows: [3, 3], paper: 9 }
};

/* a second sheet with a stale !ref and an unlisted column, to prove recovery */
const ws2 = { A1: S('stale ref sheet'), C5: N(42), E9: S('beyond the ref'), '!ref': 'A1:B2', '!view': { freeze: { r: 1, c: 0 } } };

const wbDemo = {
  SheetNames: ['E3 Payables — sample & "notes"', 'Second/Sheet[1]:*?', 'Second/Sheet[1]:*?', 'A very long working paper name that runs well past thirty-one'],
  Sheets: { 'E3 Payables — sample & "notes"': ws1, 'Second/Sheet[1]:*?': ws2, 'A very long working paper name that runs well past thirty-one': { A1: S('third', { bold: true }) } }
};

let bytes = null, err = null;
try { bytes = StyledXLSX.write(wbDemo); } catch (e) { err = e; }
t.ok(!err && bytes && bytes.length > 0, 'write() returns bytes without throwing', err && (err.stack || err.message));
if (!bytes) t.done();
t.ok(bytes[0] === 0x50 && bytes[1] === 0x4b && bytes[2] === 3 && bytes[3] === 4, 'output starts with a PK local file header');

/* ============================================ 3. the zip and its parts === */
console.log('\n=== zip container ===');
const z = unzip(bytes);
t.ok(z.count === Object.keys(z.files).length, 'central directory entry count matches EOCD');
for (const need of ['[Content_Types].xml', '_rels/.rels', 'xl/workbook.xml', 'xl/_rels/workbook.xml.rels', 'xl/styles.xml', 'xl/sharedStrings.xml', 'xl/worksheets/sheet1.xml', 'xl/worksheets/sheet2.xml', 'xl/worksheets/sheet3.xml'])
  t.ok(!!z.files[need], 'part present: ' + need);
t.ok(Object.keys(z.files).every(k => z.files[k].crc === StyledXLSX._crc32(z.files[k].data) && z.files[k].size === z.files[k].data.length),
  'every entry CRC and uncompressed size match the stored bytes');
t.ok('[Content_Types].xml' === Object.keys(z.files)[0], '[Content_Types].xml is the first entry');

console.log('\n=== XML well-formedness ===');
for (const k of Object.keys(z.files)) { const bad = wellFormed(z.files[k].text); t.ok(!bad, `${k} is well formed`, bad); }
t.ok(Object.keys(z.files).every(k => !/[\x00-\x08\x0B\x0C\x0E-\x1F]/.test(z.files[k].text)), 'no illegal control characters survive into any part');

/* ==================================================== 4. style de-dup === */
console.log('\n=== style de-duplication ===');
const styles = z.files['xl/styles.xml'].text;
const cellXfs = /<cellXfs count="(\d+)">([\s\S]*?)<\/cellXfs>/.exec(styles);
t.ok(!!cellXfs, 'styles.xml has a cellXfs block');
const xfCount = +cellXfs[1], xfActual = (cellXfs[2].match(/<xf /g) || []).length;
t.ok(xfCount === xfActual, `cellXfs count attribute (${xfCount}) matches the number of <xf> children (${xfActual})`);
t.ok(/<cellXfs[^>]*><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"\/>/.test(styles), 'cellXfs[0] is the single unformatted style');
t.ok(/<fill><patternFill patternType="none"\/><\/fill><fill><patternFill patternType="gray125"\/><\/fill>/.test(styles), 'fills 0 and 1 are none + gray125 as Excel demands');
t.ok(/<font><sz val="11"\/><color rgb="FF000000"\/><name val="Calibri"\/>/.test(styles), 'font 0 is Calibri 11');
t.ok(!/numFmtId="1[0-5]\d"|numFmtId="16[0-3]"/.test(styles.replace(/numFmtId="0"/g, '')) && /<numFmt numFmtId="164"/.test(styles), 'custom number formats start at 164');
t.ok(!/theme=|scheme /.test(styles), 'no theme references (the package carries no theme part)');

/* 400 cells, four distinct descriptors written four different ways */
const bulk = { '!ref': 'A1:D100' };
const A = { bold: true, fill: NAVY, color: '#ffffff' };
for (let r = 0; r < 100; r++) {
  bulk['A' + (r + 1)] = S('r' + r, { bold: true, fill: NAVY, color: '#FFFFFF' });
  bulk['B' + (r + 1)] = S('r' + r, A);
  bulk['C' + (r + 1)] = N(r, { numFmt: '#,##0.00' });
  bulk['D' + (r + 1)] = N(r, {}, { z: '#,##0.00' });
}
const bulkStyles = StyledXLSX._parts({ SheetNames: ['B'], Sheets: { B: bulk } });
t.ok(bulkStyles.styleCounts.xfs === 3, `400 cells over 2 distinct descriptors collapse to 3 cellXfs (plain + 2), got ${bulkStyles.styleCounts.xfs}`);
t.ok(bulkStyles.styleCounts.fonts === 2, `one extra font, got ${bulkStyles.styleCounts.fonts}`);
t.ok(bulkStyles.styleCounts.fills === 3, `two built-in fills plus one navy, got ${bulkStyles.styleCounts.fills}`);
t.ok(bulkStyles.styleCounts.numFmts === 1, `one custom number format, got ${bulkStyles.styleCounts.numFmts}`);
t.ok(bulkStyles.stringCount === 100, `shared strings de-duplicate too (${bulkStyles.stringCount})`);
t.ok(xfActual > 12 && xfActual < 30, `the kitchen-sink sheet keeps its dozen-plus distinct styles (${xfActual})`);

/* ========================================== 5. worksheet element order === */
console.log('\n=== worksheet structure ===');
const s1 = z.files['xl/worksheets/sheet1.xml'].text;
const order = ['<sheetPr>', '<dimension', '<sheetViews>', '<sheetFormatPr', '<cols>', '<sheetData>', '<mergeCells', '<pageMargins', '<pageSetup'];
let at = 0, orderOK = true, where = '';
for (const tag of order) { const i = s1.indexOf(tag); if (i < 0 || i < at) { orderOK = false; where = tag; break; } at = i; }
t.ok(orderOK, 'worksheet children appear in schema order', where);
t.ok(/<pane xSplit="1" ySplit="4" topLeftCell="B5" activePane="bottomRight" state="frozen"\/>/.test(s1), 'freeze panes emitted at B5');
t.ok(/showGridLines="0"/.test(s1) && /zoomScale="90"/.test(s1), 'gridlines off and zoom honoured');
t.ok(/<mergeCells count="2">/.test(s1), 'degenerate single-cell merges are dropped (2 of 3 kept)');
t.ok(/<col min="7" max="7" width="44\.71[0-9]*" customWidth="1"\/>/.test(s1), 'column width converted from wch', (s1.match(/<col min="7"[^>]*>/) || [''])[0]);
t.ok(/<row r="4" ht="30" customHeight="1">/.test(s1), 'row height from !rows hpt');
t.ok(/<f>SUM\(D5:D7\)<\/f><v>0<\/v>/.test(s1), 'formula written without the leading = and with a cached value');
t.ok(!/<v>NaN<\/v>|<v>Infinity<\/v>/.test(s1), 'NaN and Infinity never reach the XML');
t.ok(/<c r="F5"[^>]* t="b"><v>1<\/v><\/c>/.test(s1) && /t="b"><v>0<\/v>/.test(s1), 'booleans written as t="b"');
t.ok(/<definedName name="_xlnm.Print_Titles" localSheetId="0">&apos;E3 Payables — sample &amp; &quot;notes&quot;&apos;!\$4:\$4<\/definedName>/.test(z.files['xl/workbook.xml'].text),
  'print titles emitted as a per-sheet defined name');
t.ok(/<sheetPr><pageSetUpPr fitToPage="1"\/><\/sheetPr>/.test(s1) && /orientation="landscape"/.test(s1) && /fitToWidth="1"/.test(s1), 'landscape + fit to width');
const s2 = z.files['xl/worksheets/sheet2.xml'].text;
t.ok(/<dimension ref="A1:E9"\/>/.test(s2), 'a stale !ref is recomputed from the cells', (s2.match(/<dimension[^>]*>/) || [''])[0]);

/* ============================================ 6. round trip via SheetJS === */
console.log('\n=== round trip through SheetJS ===');
const back = XLSX.read(Buffer.from(bytes), { type: 'buffer', cellStyles: true, cellFormula: true, cellDates: true });
const names = StyledXLSX._parts(wbDemo).names;
t.ok(names.length === 4 && names[0] === 'E3 Payables — sample & "notes"', 'sheet name keeps its legal punctuation', names[0]);
t.ok(names[1] === 'SecondSheet1' && names[2] === 'SecondSheet1 (2)', 'illegal characters stripped and duplicates made unique', names.join(' | '));
t.ok(names[3].length <= 31 && names[3] === 'A very long working paper name', 'over-long sheet names clipped to 31 characters', names[3]);
t.ok(JSON.stringify(back.SheetNames) === JSON.stringify(names), 'SheetJS reads back exactly those sheet names', back.SheetNames.join(' | '));

const r1 = back.Sheets[names[0]];
t.ok(r1.B2.v === 'O\'Brien & Sons <Pte> Ltd "HQ"', '&, <, >, " and \' survive the trip', r1.B2.v);
t.ok(r1.A5.v === 'Alpha Supplies' && r1.D5.v === 1234.5 && r1.D6.v === -98765.4321, 'strings and numbers unchanged');
t.ok(r1.B11.v.length === 32767, 'a 40 000-character string is clipped to Excel\'s 32 767 limit', String(r1.B11.v.length));
t.ok(r1.A12.v === 'Control chars  kept legal', 'control characters stripped from cell text', JSON.stringify(r1.A12.v));
t.ok(r1.F5.t === 'b' && r1.F5.v === true && r1.F6.v === false, 'booleans round-trip as booleans');
t.ok(r1.C5.v instanceof Date && r1.C5.v.getFullYear() === 2025 && r1.C5.v.getMonth() === 1 && r1.C5.v.getDate() === 28, 'a Date round-trips to the same day', String(r1.C5.v));
t.ok(/^28\/02\/2025$/.test(XLSX.SSF.format(r1.C5.z || 'dd/mm/yyyy', XLSX.SSF ? 45716 : 0) ? '28/02/2025' : ''), 'dates carry a dd/mm/yyyy number format', r1.C5.z);
t.ok(r1.C5.z === 'dd/mm/yyyy', 'date number format is dd/mm/yyyy', r1.C5.z);
t.ok(r1.D5.z === '#,##0.00;[Red](#,##0.00)', 'money number format survives', r1.D5.z);
t.ok(r1.D9.f === 'SUM(D5:D7)' && r1.E9.f === 'AVERAGE(E5:E7)' && r1.B9.f === 'COUNT(D5:D7)', 'formulas come back without a leading =', r1.D9.f);
t.ok(r1.C9.f === 'CONCATENATE("n=",COUNT(D5:D7))', 'a string-result formula keeps its quotes', r1.C9.f);
const m = back.Sheets[names[0]]['!merges'] || [];
t.ok(m.length === 2 && m[0].s.r === 0 && m[0].e.c === 6, 'merges round-trip', JSON.stringify(m));
const cols = r1['!cols'] || [];
t.ok(cols[0] && Math.round(cols[0].wch) === 26 && Math.round(cols[6].wch) === 44, 'column widths round-trip', JSON.stringify(cols.map(c => c && Math.round(c.wch))));
t.ok(back.Sheets[names[1]]['!ref'] === 'A1:E9', 'the recomputed ref reaches SheetJS', back.Sheets[names[1]]['!ref']);

/* ================================= 7. every real working paper exports === */
console.log('\n=== real working papers ===');
const L = load(['cash.js', 'ap.js', 'inv.js']);
const eng = engagement(L.Core, '2025-02-28', 145000);
const CASES = [
  { code: 'CASH', file: 'PBC-BANK-01 Bank statement Operating account 2025-02.xlsx', cfg: { scrSampleN: 5 } },
  { code: 'AP', file: 'PBC-AP-01 Trade payables listing 2025-02-28.xlsx', cfg: {} },
  { code: 'INV', file: 'PBC-INV-01 Inventory listing 2025-02-28.xlsx', cfg: {} }
];
const countF = wb => wb.SheetNames.reduce((s, n) => s + Object.keys(wb.Sheets[n]).filter(k => k[0] !== '!' && wb.Sheets[n][k] && wb.Sheets[n][k].f).length, 0);
let lastBytes = null;

for (const { code, file, cfg } of CASES) {
  const full = path.join(OUT, 'client-a', file);
  if (!fs.existsSync(full)) { console.log('  skip (missing) ' + file); continue; }
  let wb = null, b = null, e = null;
  try {
    const p = pipeline(L, full, code, eng, cfg);
    wb = L.Exporter.build(p.state(), code);
    b = StyledXLSX.write(wb);
  } catch (ex) { e = ex; }
  t.ok(!e && b && b.length > 0, `${code}: Exporter.build → StyledXLSX.write without throwing`, e && (e.stack || e.message).split('\n').slice(0, 3).join(' | '));
  if (!b) continue;
  lastBytes = b;
  const want = StyledXLSX._parts(wb).names;
  const got = XLSX.read(Buffer.from(b), { type: 'buffer', cellStyles: true, cellFormula: true });
  const missing = want.filter(n => got.SheetNames.indexOf(n) < 0);
  t.ok(missing.length === 0, `${code}: all ${want.length} sheets read back`, missing.join(', '));
  const fBefore = countF(wb), fAfter = countF(got);
  t.ok(fBefore > 0 && fBefore === fAfter, `${code}: ${fBefore} formula cells preserved`, `${fBefore} → ${fAfter}`);
  const zz = unzip(b);
  const bad = Object.keys(zz.files).map(k => [k, wellFormed(zz.files[k].text)]).filter(x => x[1]);
  t.ok(bad.length === 0, `${code}: every part of the real export is well formed`, bad.map(x => x.join(': ')).join('; '));
  console.log(`  ${code}: ${want.length} sheets, ${fBefore} formulas, ${(b.length / 1024).toFixed(0)} KB, ${StyledXLSX._parts(wb).styleCounts.xfs} cellXfs`);
}

/* ==================================================== 8. writeFile to disk */
console.log('\n=== writeFile ===');
const outPath = path.join(__dirname, 'out-styled.xlsx');
let wfErr = null;
try { StyledXLSX.writeFile(wbDemo, outPath); } catch (e) { wfErr = e; }
t.ok(!wfErr && fs.existsSync(outPath) && fs.statSync(outPath).size === bytes.length, 'writeFile() writes the workbook to disk under Node', wfErr && wfErr.message);
if (lastBytes) fs.writeFileSync(path.join(__dirname, 'out-styled-wp.xlsx'), lastBytes);
let noWb = null;
try { StyledXLSX.write(null); } catch (e) { noWb = e; }
t.ok(!!noWb, 'write(null) throws rather than producing a broken file');

t.done();
