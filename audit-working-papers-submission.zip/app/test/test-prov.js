/* Headless test of the PROV (provisions and contingencies, FRS 37) audit file
   against the synthetic schedules.
   Run:  node test/test-prov.js                                               */
const { load, counter, money, engagement, pipeline, expectedExceptions, OUT, path, fs } = require('./spec-lib');
const L = load(['prov.js']);
const t = counter();
const CODE = 'PROV';
const r2 = n => n == null ? null : Math.round(n * 100) / 100;
const near = (a, b, tol = 0.005) => a != null && b != null && Math.abs(a - b) <= tol;

const CLIENTS = [
  { c: 'client-a', ye: '2025-02-28', file: 'PBC-PROV-01 Provisions and contingencies 2025-02-28.xlsx' },
  { c: 'client-b', ye: '2025-09-30', file: 'PBC-PROV-01 Provisions and contingencies 2025-09-30.xlsx' },
  { c: 'client-d', ye: '2025-09-30', file: 'PBC-PROV-01 Provisions and contingencies 2025-09-30.xlsx' }
];

/* Every planted defect, the record it sits on and what the module must say. */
const PLANTED = [
  ['EX-PROV-01', 'Warranty provision - product warranties'],
  ['EX-PROV-02', 'Site restoration - closed depot'],
  ['EX-PROV-06', 'Reinstatement of leased premises'],
  ['EX-PROV-08', 'Decommissioning of coating plant'],
  ['EX-PROV-11', 'Insurance claim - fire damage recovery'],
  ['EX-PROV-12', 'Legal claim - employment tribunal'],
  ['EX-PROV-14', 'Provision for future operating losses - coating line'],
  ['EX-PROV-18', 'Restructuring provision - logistics reorganisation'],
  ['EX-PROV-19', 'Onerous contract - fixed-price supply contract']
];
/* raised only once the auditor has entered evidence */
const INPUT_DRIVEN = ['EX-PROV-03', 'EX-PROV-04', 'EX-PROV-05', 'EX-PROV-07', 'EX-PROV-09',
  'EX-PROV-10', 'EX-PROV-13', 'EX-PROV-15', 'EX-PROV-16', 'EX-PROV-17', 'EX-PROV-20', 'EX-TIE-01'];

const REFS = ['U7', 'U7.1', 'U7.2', 'U7.3', 'U7.4', 'U7.5', 'U7.6', 'U7.7', 'U7.8'];

/* ====================================================== registration */
console.log('\n=== PROV — module registration ===');
{
  const M = L.Modules.byCode.PROV;
  t.ok(!!M, 'PROV registered via Modules.register');
  t.ok(M.name === 'Provisions & Contingencies' && M.group === 'Liabilities & equity', 'name and group');
  t.ok(/FRS 37/.test(M.objective) || /1-37/.test(M.objective), 'objective cites FRS 37 / SFRS(I) 1-37');
  t.ok(M.pages.filter(p => p.render).length === 9, `nine rendered working papers (U7, U7.1–U7.8) (${M.pages.filter(p => p.render).length})`);
  t.ok(M.pages.filter(p => p.kind).map(p => p.kind).sort().join() === 'cleaned,conclusion,mapping,source', 'four shell pages present');
  t.ok(M.pages.filter(p => p.render).map(p => p.ref).join(',') === REFS.join(','), 'working paper refs are U7 … U7.8 in order', M.pages.filter(p => p.render).map(p => p.ref).join(','));
  t.ok(M.pages.every(p => /^U7(\.\d|\.0[ab])?$/.test(p.ref)), 'every ref sits in the U7 family (no collision with U3 AP, U4 ACCR, U5 PAY)');
  t.ok(new Set(M.pages.map(p => p.id)).size === M.pages.length, 'page ids unique');
  t.ok(new Set(M.pages.map(p => p.ref)).size === M.pages.length, 'page refs unique');
  const ids = M.tests.map(x => x.id);
  t.ok(new Set(ids).size === ids.length, 'exception ids unique');
  t.ok(ids.filter(i => /^EX-PROV-\d\d$/.test(i)).length === 20, `twenty EX-PROV rules (${ids.filter(i => /^EX-PROV-/.test(i)).length})`);
  for (let i = 1; i <= 20; i++) t.ok(ids.includes('EX-PROV-' + String(i).padStart(2, '0')), `EX-PROV-${String(i).padStart(2, '0')} defined`);
  t.ok(ids.includes('EX-TIE-01'), 'trial balance tie test present');
  t.ok(M.tests.every(x => x.basis && REFS.includes(x.basis)), 'every rule cites a working paper as its basis',
    M.tests.filter(x => !REFS.includes(x.basis)).map(x => x.id + '→' + x.basis).join(', '));
  t.ok(M.tests.every(x => typeof x.label === 'string' && x.label.length > 10), 'every rule has a partner-readable label');
  t.ok(M.fields.filter(f => f.required).length === 7, `seven required fields (${M.fields.filter(f => f.required).length})`);
  t.ok(M.fields.find(f => f.role === 'category').key === 'class' && M.fields.find(f => f.key === 'class').satisfiedByGroup, 'class of provision is the category and may arrive as group headings');
  t.ok(M.fields.every(f => (f.synonyms || []).length >= 5), 'every field carries at least five heading synonyms');
  t.ok(M.fields.some(f => (f.synonyms || []).some(s => /[一-鿿]/.test(s))), 'Chinese headings are in the dictionary');
  t.ok(typeof M.compute === 'function' && typeof M.suggestConclusion === 'function' && Array.isArray(M.STANDARD_COLUMNS), 'compute, suggestConclusion and STANDARD_COLUMNS present');
  t.ok(M.procedures.length >= 25, `procedures collected from the pages (${M.procedures.length})`);
  const flat = JSON.stringify(M.pages.map(p => [p.title, p.objective, p.procedures]));
  t.ok(/para 14/.test(flat) && /paras 45-47/.test(flat) && /paras 66-69/.test(flat) && /paras 70-83/.test(flat) && /paras 63-65/.test(flat) && /paras 53-58/.test(flat) && /SSA 540/.test(flat) && /SSA 501/.test(flat),
    'the pages cite the paragraphs the standard actually turns on');
}

/* ====================================================== per client ==== */
for (const { c, ye, file } of CLIENTS) {
  const eng = engagement(L.Core, ye, 145000);
  const f = path.join(OUT, c, file);
  const label = c;
  console.log(`\n=== PROV — ${c} ===`);
  const p = pipeline(L, f, CODE, eng);
  const d = p.derived, T = d.totals;
  console.log(`  header row ${p.headerRow + 1}; ${p.records.length} items (${d.provisions.length} provisions, ${d.contLiabs.length} contingent liabilities, ${d.contAssets.length} contingent assets); sign ${d.sign}`);
  console.log(`  opening ${money(T.open)} + additional ${money(T.additional)} − utilised ${money(T.utilised)} − released ${money(T.released)} + unwind ${money(T.unwind)} = ${money(T.computed)} vs closing ${money(T.close)} (cast diff ${money(T.castDiff)})`);

  /* ---- ingest and mapping ------------------------------------------- */
  t.ok(p.missingRequired().length === 0, `${label}: every required field maps`, p.missingRequired().join(', '));
  ['description', 'bal_open', 'additional', 'utilised', 'released', 'bal_close', 'status',
   'current', 'noncurrent', 'timing', 'undiscounted', 'unwind'].forEach(k =>
    t.ok(!!p.mapping[k], `${label}: "${k}" mapped from "${p.mapping[k] && p.mapping[k].heading}"`));
  t.ok(p.records.length === 12, `${label}: twelve items read; title block, group headings, sub-totals and the TOTAL row held out (${p.records.length})`);
  t.ok(p.clean.rows.some(r => r.__kind === 'subtotal'), `${label}: a sub-total row was recognised and held out of the population`);
  t.ok(p.clean.rows.some(r => r.__kind === 'footnote'), `${label}: the footnote below the data block was captured`);
  t.ok(p.clean.log.some(x => x.rule === 'DQ-03'), `${label}: the blank column was dropped`);
  t.ok(p.clean.log.some(x => x.rule === 'DQ-02'), `${label}: blank rows skipped`);
  const cls = new Set(p.records.map(r => r.__class));
  t.ok(cls.size === 7 && cls.has('Warranties') && cls.has('Restructuring') && cls.has('Contingencies'),
    `${label}: seven classes resolved across provisions and contingencies (${[...cls].join(', ')})`);
  t.ok(d.byClass.length === 6 && !d.byClass.some(g => g.class === 'Contingencies'),
    `${label}: the class analysis on the lead covers the six provision classes only (${d.byClass.map(g => g.class).join(', ')})`);
  if (c === 'client-a') {
    t.ok(p.clean.hasGroups && !p.mapping.class, 'client-a: class of provision arrives as group headings, not a column');
    t.ok(p.clean.blocks && p.clean.blocks.length >= 2, 'client-a: the two-tier block header row was detected', p.clean.blocks && p.clean.blocks.map(b => b.label).join(' | '));
    t.ok(p.records.every(r => r.__flags.some(x => x.rule === 'DQ-09')), 'client-a: every record picked its class up from the group heading');
  } else {
    t.ok(!!p.mapping.class, `${label}: class of provision arrives as a column`);
  }
  if (c === 'client-d') {
    t.ok(/[一-鿿]/.test(p.mapping.bal_open.heading) && /[一-鿿]/.test(p.mapping.bal_close.heading), 'client-d: bilingual headings mapped');
    t.ok(p.built.colInfo.timing && p.built.colInfo.timing.order === 'mdy', 'client-d: the mm/dd date column resolved as mm/dd, not guessed', p.built.colInfo.timing && p.built.colInfo.timing.order);
  }
  if (c === 'client-a') t.ok(p.built.colInfo.timing.order === 'dmy', 'client-a: dd/mm date column resolved');

  /* ---- recomputation, to the cent ----------------------------------- */
  t.ok(d.sign === 'signed', `${label}: the utilised and released columns auto-detected as negative = reduction`);
  t.ok(p.records.every(r => near(r.__used, -(r.utilised || 0)) && near(r.__rel, -(r.released || 0))), `${label}: sign applied to both reduction columns`);
  t.ok(p.records.every(r => near(r.__computedClose, r2((r.bal_open || 0) + (r.additional || 0) - r.__used - r.__rel + r.__unwind))),
    `${label}: every line recomputed as opening + additional − utilised − released + unwind`);
  t.ok(p.records.every(r => r.bal_close == null ? r.__castDiff === null : near(r.__castDiff, r2(r.bal_close - r.__computedClose))),
    `${label}: cast difference is closing per schedule − recomputed, and null where there is no closing balance`);
  t.ok(near(T.computed, r2(T.open + T.additional - T.utilised - T.released + T.unwind), 0.05), `${label}: the movement columns cast down to the recomputed total`);
  t.ok(near(T.castDiff, r2(T.close - T.computed), 0.05), `${label}: total cast difference = closing per schedule − recomputed`);
  t.ok(near(T.castDiff, 2450, 0.005), `${label}: the total cast difference is the planted 2,450.00 (${money(T.castDiff)})`);
  t.ok(near(T.close, r2(d.provisions.reduce((s, r) => s + (r.bal_close || 0), 0)), 0.05), `${label}: lead total casts to the provisions`);
  t.ok(near(T.close, r2(d.byClass.reduce((s, g) => s + g.close, 0)), 0.05), `${label}: the class analysis cross-casts to the lead total`);
  t.ok(near(T.open, r2(d.byClass.reduce((s, g) => s + g.open, 0)), 0.05), `${label}: the class analysis cross-casts on the opening balance too`);
  t.ok(d.byClass.reduce((s, g) => s + g.count, 0) === d.provisions.length, `${label}: every provision falls into exactly one class`);
  t.ok(near(d.lead.splitDiff, r2(T.current + T.noncurrent - T.close), 0.05) && near(d.lead.splitDiff, -5000, 0.005),
    `${label}: the current / non-current analysis is short by the planted 5,000.00 (${money(d.lead.splitDiff)})`);
  t.ok(T.count === 9 && d.contLiabs.length === 2 && d.contAssets.length === 1, `${label}: nine provisions, two contingent liabilities, one contingent asset`);
  t.ok(p.records.every(r => ['Provision', 'Contingent liability', 'Contingent asset'].includes(r.__status)), `${label}: every item classified`);
  t.ok(p.records.every(r => r.__displayKey === r.description), `${label}: display key is the description`);
  t.ok(d.contingent.clTotal > 0 && near(d.contingent.clTotal, r2(d.contLiabs.reduce((s, r) => s + (r.undiscounted || 0), 0))),
    `${label}: contingent liabilities carried at the disclosed estimate of financial effect (${money(d.contingent.clTotal)})`);
  t.ok(!d.contLiabs.some(r => r.bal_close != null), `${label}: nothing is recognised for the contingent liabilities`);

  /* ---- the planted defects ------------------------------------------ */
  const planted = expectedExceptions('Provisions', c);
  const ids = [...new Set(p.exceptions.map(e => e.id))].sort();
  console.log(`  exceptions: ${p.exceptions.length} → ${ids.join(', ')}`);
  t.ok(planted.length === 9, `${label}: nine planted provisions exceptions in the expectation file (${planted.length})`);
  for (const [id, key] of PLANTED) {
    const pl = planted.find(x => x.exception.startsWith(id));
    t.ok(!!pl && pl.record_key === key, `${label}: ${id} is planted on "${key}" in the expectation file`, pl && pl.record_key);
    const hits = p.exceptions.filter(e => e.id === id);
    t.ok(hits.length === 1, `${label}: ${id} raised exactly once (${hits.length})`, hits.map(e => e.recordKey).join(' ; '));
    t.ok(hits.length === 1 && hits[0].recordKey === key, `${label}: ${id} raised on "${key}"`, hits.map(e => e.recordKey).join(' ; '));
  }
  t.ok(p.exceptions.length === 9, `${label}: nine exceptions and no more before any auditor input (${p.exceptions.length})`, ids.join(', '));
  t.ok(!p.exceptions.some(e => INPUT_DRIVEN.includes(e.id)), `${label}: the input-driven rules are silent before the auditor enters anything`);

  const e01 = p.exceptions.find(e => e.id === 'EX-PROV-01');
  t.ok(near(e01.difference, 2450) && near(e01.expected, e01.actual - 2450) && /^I\d+$/.test(e01.cell || '') === /^I\d+$/.test(e01.cell || ''),
    `${label}: EX-PROV-01 difference is the planted 2,450.00 with a cell reference (${money(e01.difference)}, ${e01.cell})`);
  t.ok(!!e01.cell && /^[A-Z]+\d+$/.test(e01.cell), `${label}: EX-PROV-01 points at the closing balance cell (${e01.cell})`);
  const e02 = p.exceptions.find(e => e.id === 'EX-PROV-02');
  t.ok(near(e02.difference, -5000) && near(e02.actual, e02.expected - 5000), `${label}: EX-PROV-02 difference is the planted −5,000.00 (${money(e02.difference)})`);
  const e06 = p.exceptions.find(e => e.id === 'EX-PROV-06');
  const rein = p.records.find(r => r.description === 'Reinstatement of leased premises');
  t.ok(e06.severity === 'above-pm' && near(e06.actual, rein.bal_close), `${label}: EX-PROV-06 is above performance materiality and carries the provision`);
  t.ok(rein.__months > 90 && rein.__ratePct === null && rein.bal_close >= eng.materiality.pm, `${label}: the reinstatement obligation settles in ${Math.round(rein.__months)} months, is above PM and carries no discount rate`);
  t.ok(/paras 45-47/.test(e06.detail), `${label}: EX-PROV-06 cites FRS 37 paras 45-47`);
  const dec = p.records.find(r => r.description === 'Decommissioning of coating plant');
  const e08 = p.exceptions.find(e => e.id === 'EX-PROV-08');
  t.ok(near(dec.__expectedUnwind, r2(dec.bal_open * 0.05)), `${label}: the unwind is recomputed as the opening provision at the 5% rate on the schedule (${money(dec.__expectedUnwind)})`);
  t.ok(near(e08.difference, -4880) && near(e08.actual, dec.__unwind) && near(e08.expected, dec.__expectedUnwind),
    `${label}: EX-PROV-08 difference is the planted −4,880.00 (${money(e08.difference)})`);
  t.ok(near(dec.__castDiff, 0), `${label}: the decommissioning line still casts — only the unwind is wrong`);
  const ca = p.records.find(r => r.description === 'Insurance claim - fire damage recovery');
  const e11 = p.exceptions.find(e => e.id === 'EX-PROV-11');
  t.ok(ca.__isCA && near(e11.difference, ca.bal_close) && e11.severity === 'above-pm', `${label}: EX-PROV-11 carries the amount wrongly recognised (${money(e11.difference)})`);
  t.ok(/para 31/.test(e11.detail), `${label}: EX-PROV-11 cites FRS 37 para 31`);
  t.ok(d.contingent.recognisedAssets.length === 1, `${label}: exactly one recognised contingent asset in the derived data`);
  const emp = p.records.find(r => r.description === 'Legal claim - employment tribunal');
  const e12 = p.exceptions.find(e => e.id === 'EX-PROV-12');
  t.ok(near(e12.difference, r2(emp.reimbursement - emp.bal_close)) && near(e12.expected, emp.bal_close) && near(e12.actual, emp.reimbursement),
    `${label}: EX-PROV-12 difference is the reimbursement above the provision (${money(e12.difference)})`);
  t.ok(/para 53/.test(e12.detail), `${label}: EX-PROV-12 cites the FRS 37 para 53 cap`);
  const fol = p.records.find(r => /future operating losses/.test(r.description));
  t.ok(fol.__futureOpLoss && d.types.futureOpLosses.length === 1, `${label}: exactly one provision for future operating losses identified`);
  t.ok(/para 63/.test(p.exceptions.find(e => e.id === 'EX-PROV-14').detail), `${label}: EX-PROV-14 cites FRS 37 para 63`);
  const rest = p.records.find(r => /Restructuring provision/.test(r.description));
  t.ok(rest.__releasedInFull && !rest.__reCreated && d.releasedInFull.length === 1, `${label}: the restructuring provision was released in full and nothing else was`);
  t.ok(p.exceptions.find(e => e.id === 'EX-PROV-18').severity === 'informational', `${label}: EX-PROV-18 is an informational bias indicator, not a misstatement`);
  const one = p.records.find(r => /Onerous contract/.test(r.description));
  t.ok(one.__reCreated && !one.__releasedInFull && d.reCreated.length === 1, `${label}: the onerous contract provision was released and re-created, and nothing else was`);
  t.ok(near(p.exceptions.find(e => e.id === 'EX-PROV-19').difference, one.additional), `${label}: EX-PROV-19 carries the amount re-charged (${money(one.additional)})`);
  t.ok(d.castFails.length === 1 && d.splitFails.length === 1 && d.measurement.needDiscount.length === 1 && d.measurement.unwindFails.length === 1,
    `${label}: derived lists (cast fails ${d.castFails.length}, split fails ${d.splitFails.length}, undiscounted ${d.measurement.needDiscount.length}, unwind fails ${d.measurement.unwindFails.length})`);

  /* ---- the controls are live ---------------------------------------- */
  const pTight = pipeline(L, f, CODE, eng, { unwindTolPct: 200 });
  t.ok(!pTight.exceptions.some(e => e.id === 'EX-PROV-08'), `${label}: widening the unwind tolerance silences EX-PROV-08`);
  const pDisc = pipeline(L, f, CODE, eng, { discThreshold: 10_000_000 });
  t.ok(!pDisc.exceptions.some(e => e.id === 'EX-PROV-06'), `${label}: raising the discounting threshold above every provision silences EX-PROV-06`);
  const pMonths = pipeline(L, f, CODE, eng, { discMonths: 1 });
  t.ok(pMonths.derived.measurement.needDiscount.length > 1, `${label}: dropping the discounting horizon to one month catches more provisions (${pMonths.derived.measurement.needDiscount.length})`);
  const pPos = pipeline(L, f, CODE, eng, { movementSign: 'positive' });
  t.ok(pPos.derived.sign === 'positive' && pPos.derived.castFails.length > d.castFails.length,
    `${label}: forcing positive = reduction breaks the casts — the control is live (${pPos.derived.castFails.length} fail)`);
  const pTol = pipeline(L, f, CODE, eng, { castTol: 10000 });
  t.ok(!pTol.exceptions.some(e => e.id === 'EX-PROV-01' || e.id === 'EX-PROV-02'), `${label}: a 10,000 casting tolerance silences the casting and split rules`);

  /* ---- pages and export --------------------------------------------- */
  p.renderAll(t, label);
  p.exportCheck(t, label);
}

/* ============================================ auditor inputs (client-a) */
console.log('\n=== PROV — auditor inputs drive the tests (client-a) ===');
const eng = engagement(L.Core, '2025-02-28', 145000);
const file = path.join(OUT, 'client-a', 'PBC-PROV-01 Provisions and contingencies 2025-02-28.xlsx');
const base = pipeline(L, file, CODE, eng);
const T0 = base.derived.totals;
const find = (recs, re) => recs.find(r => re.test(r.description));

/* ---- U7 lead: the trial balance and prior year ties ------------------ */
{
  const pTB = pipeline(L, file, CODE, eng, { tbProvisions: T0.close, pyProvisions: T0.open, tbCurrent: T0.current, tbNonCurrent: T0.noncurrent });
  t.ok(pTB.derived.lead.tbDiff === 0 && pTB.derived.lead.pyDiff === 0, 'U7: schedule agrees to the trial balance and opening agrees to the prior year when the figures are entered');
  t.ok(!pTB.exceptions.some(e => e.id === 'EX-TIE-01'), 'EX-TIE-01 silent when the balances agree');
  const pTB2 = pipeline(L, file, CODE, eng, { tbProvisions: T0.close - 900, pyProvisions: T0.open + 400 });
  const tie = pTB2.exceptions.find(e => e.id === 'EX-TIE-01');
  t.ok(tie && near(tie.difference, 900) && near(tie.expected, T0.close - 900), 'EX-TIE-01 raised with the difference to the trial balance figure entered', tie && tie.difference);
  t.ok(near(pTB2.derived.lead.pyDiff, -400), 'U7: opening against the prior year audited closing balance computed');
  t.ok(near(pTB2.derived.lead.variance, r2(T0.close - (T0.open + 400))) && pTB2.derived.lead.variancePct != null, 'U7: movement against the prior year computed');
  t.ok(near(pTB.derived.lead.tbSplitDiff, r2(T0.current + T0.noncurrent - T0.close)), 'U7: the trial balance current / non-current split is compared to the closing balance');
}

/* ---- U7.2 recognition ------------------------------------------------ */
{
  const pRec = pipeline(L, file, CODE, eng, {}, recs => {
    find(recs, /Warranty provision/).__wp = { recognition: { obligation: 'Y', probable: 'Y', reliable: 'Y' } };
    find(recs, /employment tribunal/).__wp = { recognition: { obligation: 'Y', probable: 'N', reliable: 'Y' } };
    find(recs, /future operating losses/).__wp = { recognition: { obligation: 'N', probable: 'Y', reliable: 'Y' } };
    find(recs, /Tax assessment/).__wp = { recognition: { obligation: 'Y', probable: 'Y', reliable: 'Y' } };
  });
  const R = pRec.derived.recognition;
  t.ok(R.complete === 4 && R.supported === 1, `U7.2: four items assessed, one provision supported by all three criteria (${R.complete}, ${R.supported})`);
  const e03 = pRec.exceptions.filter(e => e.id === 'EX-PROV-03');
  t.ok(e03.length === 2, `EX-PROV-03 raised on both provisions failing a criterion (${e03.length})`, e03.map(e => e.recordKey).join(' ; '));
  t.ok(e03.some(e => /employment tribunal/.test(e.recordKey) && /probable outflow/.test(e.detail)), 'EX-PROV-03 names the criterion that failed (probable outflow)');
  t.ok(e03.some(e => /future operating losses/.test(e.recordKey) && /present obligation/.test(e.detail)), 'EX-PROV-03 names the criterion that failed (present obligation)');
  t.ok(e03.every(e => /para 14/.test(e.detail)), 'EX-PROV-03 cites FRS 37 para 14');
  const e04 = pRec.exceptions.filter(e => e.id === 'EX-PROV-04');
  t.ok(e04.length === 1 && e04[0].recordKey === 'Tax assessment under appeal', 'EX-PROV-04 raised where a contingent liability meets all three criteria', e04.map(e => e.recordKey).join(' ; '));
  t.ok(/paras 27-28/.test(e04[0].detail), 'EX-PROV-04 cites FRS 37 paras 27-28');
  t.ok(R.shouldRecognise.length === 1 && R.failed.length === 2, 'U7.2 derived lists reflect the answers');
  t.ok(!pRec.exceptions.some(e => e.id === 'EX-PROV-03' && /Warranty/.test(e.recordKey)), 'a provision meeting all three criteria raises nothing');
  /* a partly answered row raises nothing */
  const pPart = pipeline(L, file, CODE, eng, {}, recs => { find(recs, /Warranty provision/).__wp = { recognition: { obligation: 'Y' } }; });
  t.ok(!pPart.exceptions.some(e => e.id === 'EX-PROV-03' || e.id === 'EX-PROV-04'), 'a partly answered recognition test raises nothing');
  t.ok(pPart.derived.recognition.answered === 1 && pPart.derived.recognition.complete === 0, 'U7.2 counts answered and complete separately');
}

/* ---- U7.3 measurement, discounting and reimbursements ---------------- */
{
  const pM = pipeline(L, file, CODE, eng, {}, recs => {
    find(recs, /Warranty provision/).__wp = { measurement: { population: 'Large population', method: 'Most likely outcome', evidence: 'Claims history' } };
    find(recs, /contract dispute/).__wp = { measurement: { population: 'Single obligation', method: 'Most likely outcome' } };
    find(recs, /Site restoration/).__wp = { measurement: { population: 'Single obligation', method: 'Most likely outcome', evidence: 'Contractor quotation' } };
  });
  const e05 = pM.exceptions.filter(e => e.id === 'EX-PROV-05');
  t.ok(e05.length === 2, `EX-PROV-05 raised twice — a method inconsistent with the population and a method with no evidence (${e05.length})`, e05.map(e => e.recordKey).join(' ; '));
  t.ok(e05.some(e => /Warranty/.test(e.recordKey) && /expected value/.test(e.detail)), 'EX-PROV-05 explains that a large population is measured at expected value (paras 39-40)');
  t.ok(e05.some(e => /contract dispute/.test(e.recordKey) && /No evidence/.test(e.detail)), 'EX-PROV-05 raised where no evidence has been recorded for the method');
  t.ok(!e05.some(e => /Site restoration/.test(e.recordKey)), 'a single obligation measured at the most likely outcome with evidence raises nothing');
  t.ok(pM.derived.measurement.entered === 3 && pM.derived.measurement.unsupported.length === 2, 'U7.3 stats reflect the methods entered');

  /* discounting recomputed from the auditor's rate and settlement date */
  const pD = pipeline(L, file, CODE, eng, {}, recs => {
    find(recs, /Reinstatement/).__wp = { measurement: { rate: 5, settle: '2033-02-28', undisc: 366003 } };
  });
  const rein = find(pD.records, /Reinstatement/);
  t.ok(near(rein.__years, 8, 0.01), `U7.3: eight years to settlement derived from the year end and the settlement date (${rein.__years})`);
  t.ok(near(rein.__pvAudit, 247725.24), `U7.3: 366,003.00 discounted at 5% over 8 years is 247,725.24 (${money(rein.__pvAudit)})`);
  t.ok(near(rein.__pvDiff, 18458.76), `U7.3: the provision exceeds the discounted amount by 18,458.76 (${money(rein.__pvDiff)})`);
  const e07 = pD.exceptions.filter(e => e.id === 'EX-PROV-07');
  t.ok(e07.length === 1 && e07[0].recordKey === 'Reinstatement of leased premises' && near(e07[0].difference, 18458.76) && near(e07[0].expected, 247725.24),
    'EX-PROV-07 raised with the recomputed present value as the expected figure');
  t.ok(pD.exceptions.some(e => e.id === 'EX-PROV-06'), 'EX-PROV-06 still stands — the client applied no rate at all');
  const pD2 = pipeline(L, file, CODE, eng, { measTolPct: 20 }, recs => {
    find(recs, /Reinstatement/).__wp = { measurement: { rate: 5, settle: '2033-02-28', undisc: 366003 } };
  });
  t.ok(!pD2.exceptions.some(e => e.id === 'EX-PROV-07'), 'widening the measurement tolerance to 20% silences EX-PROV-07');
  const pD3 = pipeline(L, file, CODE, eng, {}, recs => {
    const r = find(recs, /Reinstatement/); r.__wp = { measurement: { rate: 5, settle: '2033-02-28', undisc: r2(r.bal_close * Math.pow(1.05, 8)) } };
  });
  t.ok(!pD3.exceptions.some(e => e.id === 'EX-PROV-07'), 'an undiscounted estimate that discounts back to the provision raises nothing');

  /* unwind agreed to the finance cost */
  const pU = pipeline(L, file, CODE, eng, { financeCost: base.derived.measurement.unwindTotal });
  t.ok(pU.derived.measurement.financeDiff === 0, 'U7.3: the unwind per the schedule agrees to the finance cost entered');
  const pU2 = pipeline(L, file, CODE, eng, { financeCost: base.derived.measurement.unwindTotal - 250 });
  t.ok(near(pU2.derived.measurement.financeDiff, 250), 'U7.3: a difference to the finance cost note is computed');

  /* reimbursements */
  const pR = pipeline(L, file, CODE, eng, {}, recs => {
    find(recs, /employment tribunal/).__wp = { measurement: { reimbVC: 'Y', reimbSep: 'Y' } };
  });
  t.ok(pR.exceptions.some(e => e.id === 'EX-PROV-12' && /caps the reimbursement/.test(e.detail)), 'the para 53 cap still bites even when the reimbursement is virtually certain');
  const pR2 = pipeline(L, file, CODE, eng, {}, recs => {
    const r = find(recs, /employment tribunal/); r.reimbursement = r2(r.bal_close - 1000); r.__wp = { measurement: { reimbVC: 'N' } };
  });
  const e12b = pR2.exceptions.filter(e => e.id === 'EX-PROV-12');
  t.ok(e12b.length === 1 && /virtually certain/.test(e12b[0].detail), 'EX-PROV-12 raised on a reimbursement within the cap that is not virtually certain');
  const pR3 = pipeline(L, file, CODE, eng, {}, recs => {
    const r = find(recs, /employment tribunal/); r.reimbursement = r2(r.bal_close - 1000); r.__wp = { measurement: { reimbVC: 'Y' } };
  });
  t.ok(!pR3.exceptions.some(e => e.id === 'EX-PROV-12'), 'a virtually certain reimbursement within the cap raises nothing');

  /* paras 42 and 51 */
  const pG = pipeline(L, file, CODE, eng, {}, recs => {
    find(recs, /Warranty provision/).__wp = { measurement: { gains: 'Y', risks: 'N' } };
  });
  t.ok(pG.derived.measurement.gainsIncluded.length === 1 && pG.derived.measurement.risksNotConsidered.length === 1,
    'U7.3 records gains on expected disposal taken into account (para 51) and risks not considered (para 42)');
}

/* ---- U7.4 specific provision types ----------------------------------- */
{
  const cfgOC = { ocRows: 3,
    'ocContract:oc1': 'Fixed-price supply contract', 'ocCost:oc1': 120000, 'ocBenefit:oc1': 90000, 'ocPenalty:oc1': 22000, 'ocProvided:oc1': 5000,
    'ocContract:oc2': 'Warehouse sub-lease', 'ocCost:oc2': 50000, 'ocBenefit:oc2': 80000, 'ocProvided:oc2': 0,
    'ocContract:oc3': 'Maintenance retainer', 'ocCost:oc3': 40000, 'ocBenefit:oc3': 10000, 'ocProvided:oc3': 30000 };
  const pOC = pipeline(L, file, CODE, eng, cfgOC);
  const OC = pOC.derived.types.onerous;
  t.ok(near(OC[0].net, 30000) && near(OC[0].required, 22000), 'U7.4: the onerous contract is provided at the lower of the cost of fulfilling (30,000) and the penalty (22,000)');
  t.ok(near(OC[0].shortfall, 17000), `U7.4: shortfall on the onerous contract is 17,000.00 (${money(OC[0].shortfall)})`);
  t.ok(near(OC[1].net, -30000) && OC[1].required === 0 && !OC[1].onerous, 'U7.4: a contract whose benefits exceed its costs is not onerous and needs no provision');
  t.ok(near(OC[2].required, 30000) && near(OC[2].shortfall, 0), 'U7.4: a fully provided onerous contract shows no shortfall');
  const e13 = pOC.exceptions.filter(e => e.id === 'EX-PROV-13');
  t.ok(e13.length === 1 && e13[0].recordKey === 'Fixed-price supply contract' && near(e13[0].difference, 17000) && near(e13[0].expected, 22000),
    'EX-PROV-13 raised only on the under-provided onerous contract', e13.map(e => e.recordKey).join(' ; '));
  t.ok(/paras 66-68/.test(e13[0].detail), 'EX-PROV-13 cites FRS 37 paras 66-68');

  const cfgRS = { rsRows: 3,
    'rsPlan:rs1': 'Logistics reorganisation', 'rsApproved:rs1': '2025-02-10', 'rsAnnounced:rs1': '2025-04-15', 'rsProvided:rs1': 96000,
    'rsPlan:rs2': 'Coating line closure', 'rsApproved:rs2': '2024-12-01', 'rsAnnounced:rs2': '2025-01-10', 'rsStart:rs2': '2025-02-01',
    'rsProvided:rs2': 40000, 'rsRetrain:rs2': 6000, 'rsMarketing:rs2': 4000,
    'rsPlan:rs3': 'Depot consolidation', 'rsAnnounced:rs3': '2025-01-20', 'rsProvided:rs3': 25000 };
  const pRS = pipeline(L, file, CODE, eng, cfgRS);
  const RS = pRS.derived.types.restructuring;
  t.ok(RS[0].notRaised && !RS[1].notRaised && !RS[2].notRaised, 'U7.4: only the plan announced after the year end lacks a valid expectation');
  t.ok(RS[1].valid && near(RS[1].excluded, 10000) && near(RS[1].direct, 30000), 'U7.4: excluded costs are stripped out to leave the supportable direct expenditure');
  const e09 = pRS.exceptions.filter(e => e.id === 'EX-PROV-09');
  t.ok(e09.length === 1 && e09[0].recordKey === 'Logistics reorganisation' && near(e09[0].difference, 96000), 'EX-PROV-09 raised on the restructuring announced after the year end');
  t.ok(/paras 72 and 75/.test(e09[0].detail), 'EX-PROV-09 cites FRS 37 paras 72 and 75 — board approval alone is not enough');
  const e10 = pRS.exceptions.filter(e => e.id === 'EX-PROV-10');
  t.ok(e10.length === 1 && e10[0].recordKey === 'Coating line closure' && near(e10[0].difference, 10000) && near(e10[0].expected, 30000),
    'EX-PROV-10 raised on the restructuring including retraining and marketing');
  t.ok(/retraining/.test(e10[0].detail) && /marketing/.test(e10[0].detail) && /paras 80-83/.test(e10[0].detail), 'EX-PROV-10 names the excluded costs and cites paras 80-83');
  const pRSb = pipeline(L, file, CODE, eng, { ...cfgRS, 'rsAnnounced:rs1': '2025-02-20' });
  t.ok(!pRSb.exceptions.some(e => e.id === 'EX-PROV-09'), 'announcing the plan before the year end silences EX-PROV-09');
  const pRSc = pipeline(L, file, CODE, eng, { ...cfgRS, 'rsAnnounced:rs1': '', 'rsStart:rs1': '2025-02-05' });
  t.ok(!pRSc.exceptions.some(e => e.id === 'EX-PROV-09'), 'starting to implement the plan before the year end also raises a valid expectation (para 72(b))');

  const cfgWT = { wtRows: 2, 'wtProduct:wt1': 'Coated sections', 'wtSales:wt1': 4000000, 'wtRate:wt1': 1.5, 'wtProvided:wt1': 55000 };
  const pWT = pipeline(L, file, CODE, eng, cfgWT);
  const WT = pWT.derived.types.warranty;
  t.ok(near(WT[0].expected, 60000) && near(WT[0].diff, -5000), 'U7.4: the warranty provision is recomputed as sales × the claims rate (60,000) and compared (−5,000)');

  const cfgDC = { dcRows: 2, 'dcAsset:dc1': 'Leased premises', 'dcEstimate:dc1': 330000, 'dcRate:dc1': 6, 'dcYears:dc1': 8, 'dcProvided:dc1': 266184, 'dcCapitalised:dc1': 'N' };
  const pDC = pipeline(L, file, CODE, eng, cfgDC);
  const DC = pDC.derived.types.decommissioning;
  t.ok(near(DC[0].pv, 207046.08), `U7.4: 330,000.00 at 6% over 8 years has a present value of 207,046.08 (${money(DC[0].pv)})`);
  t.ok(near(DC[0].diff, r2(266184 - 207046.08)), 'U7.4: the decommissioning provision is compared to the recomputed present value');

  /* the future operating loss flag can be overridden either way */
  const pFOL = pipeline(L, file, CODE, eng, {}, recs => { find(recs, /future operating losses/).__wp = { types: { folYN: 'N' } }; });
  t.ok(!pFOL.exceptions.some(e => e.id === 'EX-PROV-14'), 'answering "No" clears the future operating loss flag the description raised');
  const pFOL2 = pipeline(L, file, CODE, eng, {}, recs => { find(recs, /Site restoration/).__wp = { types: { folYN: 'Y' } }; });
  const e14 = pFOL2.exceptions.filter(e => e.id === 'EX-PROV-14');
  t.ok(e14.length === 2, 'answering "Yes" on another provision raises EX-PROV-14 there too', e14.map(e => e.recordKey).join(' ; '));
}

/* ---- U7.5 legal and claims ------------------------------------------- */
{
  const cfgLC = { legalRows: 4,
    'lcClaim:lc1': 'Contract dispute - supply shortfall', 'lcCounterparty:lc1': 'Counterparty A', 'lcAmount:lc1': 250000,
    'lcSolicitor:lc1': 'External counsel 1', 'lcMgmtAssess:lc1': 'Possible', 'lcProvided:lc1': 0,
    'lcClaim:lc2': 'Employment tribunal', 'lcCounterparty:lc2': 'Former employee', 'lcAmount:lc2': 90000,
    'lcSolicitor:lc2': 'External counsel 2', 'lcSent:lc2': '2025-03-05', 'lcReceived:lc2': '2025-03-20',
    'lcSolAssess:lc2': 'Probable', 'lcMgmtAssess:lc2': 'Possible', 'lcAuditConc:lc2': 'Probable', 'lcProvided:lc2': 42145.80,
    'lcClaim:lc3': 'Property damage claim', 'lcCounterparty:lc3': 'Neighbouring occupier', 'lcAmount:lc3': 30000,
    'lcSolicitor:lc3': 'External counsel 1', 'lcSent:lc3': '2025-03-05', 'lcReceived:lc3': '2025-03-18',
    'lcSolAssess:lc3': 'Remote', 'lcMgmtAssess:lc3': 'Remote', 'lcAuditConc:lc3': 'Remote', 'lcProvided:lc3': 0 };
  const pLC = pipeline(L, file, CODE, eng, cfgLC);
  const LG = pLC.derived.legal;
  t.ok(LG.items.length === 3 && near(LG.claimed, 370000), `U7.5: three claims controlled, 370,000.00 claimed (${money(LG.claimed)})`);
  t.ok(LG.replies === 2 && LG.missingConf.length === 1, 'U7.5: two confirmations replied, one outstanding');
  t.ok(near(LG.provided, 42145.80), 'U7.5: the amounts provided cast');
  const e15 = pLC.exceptions.filter(e => e.id === 'EX-PROV-15');
  t.ok(e15.length === 1 && e15[0].recordKey === 'Contract dispute - supply shortfall' && near(e15[0].difference, 250000),
    'EX-PROV-15 raised on the claim with no legal confirmation', e15.map(e => e.recordKey).join(' ; '));
  t.ok(/SSA 501/.test(e15[0].detail), 'EX-PROV-15 cites SSA 501 direct communication with external legal counsel');
  const e16 = pLC.exceptions.filter(e => e.id === 'EX-PROV-16');
  t.ok(e16.length === 1 && e16[0].recordKey === 'Employment tribunal' && e16[0].expected === 'Possible' && e16[0].actual === 'Probable',
    'EX-PROV-16 raised where the auditor concludes probable and management say possible', e16.map(e => e.recordKey).join(' ; '));
  t.ok(near(e16[0].difference, 90000), 'EX-PROV-16 carries the amount claimed so the register can size it');
  t.ok(!e16.some(e => /Property damage/.test(e.recordKey)), 'a claim where the auditor and management agree raises nothing');
  const pLC2 = pipeline(L, file, CODE, eng, { ...cfgLC, 'lcSent:lc1': '2025-03-05', 'lcReceived:lc1': '2025-03-25' });
  t.ok(!pLC2.exceptions.some(e => e.id === 'EX-PROV-15'), 'recording the reply silences EX-PROV-15');
  const pLC3 = pipeline(L, file, CODE, eng, { ...cfgLC, 'lcSent:lc1': '2025-03-05' });
  t.ok(pLC3.exceptions.some(e => e.id === 'EX-PROV-15' && /reply/.test(e.detail)), 'a letter sent with no reply is still an exception, and the detail says so');
}

/* ---- U7.6 contingencies ---------------------------------------------- */
{
  const pC = pipeline(L, file, CODE, eng, {}, recs => {
    find(recs, /Corporate guarantee/).__wp = { contingent: { disclosed: 'Y', likelihood: 'Possible' } };
  });
  t.ok(pC.derived.contingent.disclosed === 1, 'U7.6 counts the contingencies the auditor has agreed to the disclosure');
  const pC2 = pipeline(L, file, CODE, eng, {}, recs => { find(recs, /Insurance claim/).bal_close = 0; find(recs, /Insurance claim/).additional = 0; });
  t.ok(!pC2.exceptions.some(e => e.id === 'EX-PROV-11'), 'a contingent asset carried at nil raises nothing');
  t.ok(pC2.derived.contingent.assets.length === 1 && pC2.derived.contingent.recognisedAssets.length === 0, 'U7.6 still discloses the contingent asset when nothing is recognised');
}

/* ---- U7.7 completeness ----------------------------------------------- */
{
  const cfgCM = { 'cmDone:cm1': 'Y', 'cmEvidence:cm1': 'Enquiry notes',
    'cmDone:cm2': 'N', 'cmDone:cm3': 'n/a',
    'cmDone:cm4': 'Y', 'cmFrom:cm4': '2024-03-01', 'cmTo:cm4': '2025-04-30', 'cmEvidence:cm4': 'Solicitor correspondence file',
    'cmDone:cm5': 'N' };
  const pCM = pipeline(L, file, CODE, eng, cfgCM);
  const CM = pCM.derived.completeness;
  t.ok(CM.items.length === 8, `U7.7: eight completeness procedures (${CM.items.length})`);
  t.ok(CM.performed === 2 && CM.notPerformed.length === 2 && CM.outstanding === 3, `U7.7: 2 performed, 2 not performed, 1 n/a, 3 unanswered (${CM.performed}/${CM.notPerformed.length}/${CM.outstanding})`);
  const e17 = pCM.exceptions.filter(e => e.id === 'EX-PROV-17');
  t.ok(e17.length === 2 && e17.map(e => e.recordKey).sort().join() === 'CM2,CM5', 'EX-PROV-17 raised for each procedure recorded as not performed', e17.map(e => e.recordKey).join(' ; '));
  t.ok(/minutes/.test(e17.find(e => e.recordKey === 'CM2').detail), 'EX-PROV-17 quotes the procedure that was not performed');
  t.ok(!e17.some(e => e.recordKey === 'CM3'), 'a procedure marked not applicable is not an exception');
  t.ok(CM.items.find(x => x.key === 'cm4').from === '2024-03-01' && CM.items.find(x => x.key === 'cm4').to === '2025-04-30',
    'U7.7 records the date range the minutes review covered');
  const pCM2 = pipeline(L, file, CODE, eng, {});
  t.ok(!pCM2.exceptions.some(e => e.id === 'EX-PROV-17') && pCM2.derived.completeness.outstanding === 8, 'an untouched completeness page raises nothing but shows eight outstanding');
}

/* ---- U7.8 estimate evaluation (SSA 540) ------------------------------- */
{
  const pE = pipeline(L, file, CODE, eng, { sensPct: 10, methodChange: 'Changed', methodChangeReason: 'Claims history extended to three years', standBack: 'Estimates reasonable in aggregate.' }, recs => {
    find(recs, /Warranty provision/).__wp = { estimate: { pyProv: 100000, actual: 60000 } };
    find(recs, /contract dispute/).__wp = { estimate: { pyProv: 80000, actual: 45000 } };
    find(recs, /Site restoration/).__wp = { estimate: { pyProv: 40000, actual: 41000 } };
  });
  const E = pE.derived.estimate;
  t.ok(E.retro.length === 3 && E.over === 2 && E.under === 0, `U7.8: three prior-year estimates reviewed, two over-provided (${E.retro.length}, ${E.over}, ${E.under})`);
  t.ok(near(find(pE.records, /Warranty provision/).__retroDiff, -40000), 'U7.8: the retrospective difference is the outcome less the prior-year provision');
  t.ok(find(pE.records, /Site restoration/).__retroDir === 'In line', 'U7.8: a difference inside the tolerance is "in line", not a bias indicator');
  t.ok(E.biasIndicator && E.biasDirection === 'Over-provided', 'U7.8: consistent over-provision is flagged as an indicator of management bias');
  const e20 = pE.exceptions.filter(e => e.id === 'EX-PROV-20');
  t.ok(e20.length === 2 && near(e20.find(e => /Warranty/.test(e.recordKey)).difference, -40000), 'EX-PROV-20 raised for each prior-year estimate outside the tolerance', e20.map(e => e.recordKey).join(' ; '));
  t.ok(/SSA 540/.test(e20[0].detail), 'EX-PROV-20 cites SSA 540 (Revised)');
  t.ok(near(E.sensAmount, r2(T0.close * 0.1)) && E.sensAbovePm, `U7.8: a 10% sensitivity on the aggregate provision is ${money(E.sensAmount)}, above performance materiality`);
  t.ok(E.methodChange === 'Changed' && E.methodChangeReason.length > 10, 'U7.8 records a change in method and the reason for it');
  const pE2 = pipeline(L, file, CODE, eng, { retroTol: 100000 }, recs => {
    find(recs, /Warranty provision/).__wp = { estimate: { pyProv: 100000, actual: 60000 } };
  });
  t.ok(!pE2.exceptions.some(e => e.id === 'EX-PROV-20'), 'widening the retrospective tolerance silences EX-PROV-20');
  const pE3 = pipeline(L, file, CODE, eng, { sensPct: 1 });
  t.ok(!pE3.derived.estimate.sensAbovePm, 'a 1% sensitivity is below performance materiality');
  const pE4 = pipeline(L, file, CODE, eng, { estProcess: { ep1: { answer: 'Y', comment: 'Documented' }, ep7: { answer: 'N', comment: 'Not sought' } } });
  t.ok(pE4.derived.estimate.processAnswered === 2 && pE4.derived.estimate.processNo.length === 1, 'U7.8: the estimation-process checklist is read back from the configuration');
  const pE5 = pipeline(L, file, CODE, eng, { kaRows: 2, 'kaAssumption:ka1': 'Claims rate of 1.5%', 'kaSupporting:ka1': 'Three years of claims history',
    'kaContradictory:ka1': 'Claims rate in the last quarter was 2.4%', 'kaConclusion:ka1': 'Not reasonable' });
  t.ok(pE5.derived.estimate.used.length === 1 && pE5.derived.estimate.contradictory.length === 1 && pE5.derived.estimate.notReasonable.length === 1,
    'U7.8: the key-assumption table records the evidence for and against and the conclusion');
}

/* ---- everything at once: pages, export and the conclusion ------------- */
console.log('\n=== PROV — a completed file exports ===');
{
  const cfg = { tbProvisions: T0.close, pyProvisions: T0.open, financeCost: base.derived.measurement.unwindTotal,
    ocRows: 2, 'ocContract:oc1': 'Fixed-price supply contract', 'ocCost:oc1': 120000, 'ocBenefit:oc1': 90000, 'ocPenalty:oc1': 22000, 'ocProvided:oc1': 5000,
    rsRows: 2, 'rsPlan:rs1': 'Logistics reorganisation', 'rsAnnounced:rs1': '2025-04-15', 'rsProvided:rs1': 96000, 'rsRetrain:rs1': 6000,
    wtRows: 1, 'wtProduct:wt1': 'Coated sections', 'wtSales:wt1': 4000000, 'wtRate:wt1': 1.5, 'wtProvided:wt1': 55000,
    dcRows: 1, 'dcAsset:dc1': 'Leased premises', 'dcEstimate:dc1': 330000, 'dcRate:dc1': 6, 'dcYears:dc1': 8, 'dcProvided:dc1': 266184,
    legalRows: 2, 'lcClaim:lc1': 'Contract dispute - supply shortfall', 'lcAmount:lc1': 250000, 'lcSolicitor:lc1': 'External counsel 1',
    'cmDone:cm1': 'Y', 'cmDone:cm2': 'N',
    kaRows: 2, 'kaAssumption:ka1': 'Claims rate of 1.5%', 'kaConclusion:ka1': 'Reasonable',
    standBack: 'Estimates reasonable in aggregate.', estProcess: { ep1: { answer: 'Y', comment: 'Documented' } } };
  const pAll = pipeline(L, file, CODE, eng, cfg, recs => {
    find(recs, /Warranty provision/).__wp = { recognition: { obligation: 'Y', probable: 'Y', reliable: 'Y' },
      measurement: { population: 'Large population', method: 'Expected value', evidence: 'Claims history' },
      estimate: { pyProv: 100000, actual: 60000 } };
    find(recs, /Reinstatement/).__wp = { measurement: { rate: 5, settle: '2033-02-28', undisc: 366003 } };
  });
  const ids = [...new Set(pAll.exceptions.map(e => e.id))].sort();
  console.log('  exceptions with the file completed: ' + pAll.exceptions.length + ' → ' + ids.join(', '));
  ['EX-PROV-07', 'EX-PROV-09', 'EX-PROV-10', 'EX-PROV-13', 'EX-PROV-15', 'EX-PROV-17', 'EX-PROV-20'].forEach(id =>
    t.ok(ids.includes(id), `completed file: ${id} raised`));
  t.ok(!ids.includes('EX-TIE-01'), 'completed file: the trial balance ties');
  t.ok(pAll.exceptions.every(e => ['above-pm', 'above-trivial', 'below-trivial', 'informational'].includes(e.severity)), 'every exception carries a severity from the materiality scale');
  t.ok(pAll.exceptions.filter(e => e.severity === 'above-pm').length >= 2, 'the material ones are graded above performance materiality');
  t.ok(pAll.exceptions.every(e => e.basis && REFS.includes(e.basis)), 'every exception cites the working paper it came from');

  pAll.renderAll(t, 'completed file');
  const wb = pAll.exportCheck(t, 'completed file');
  console.log('  sheets: ' + wb.SheetNames.join(' | '));
  const sheet = n => wb.Sheets[n];
  const has = (n, v) => { const ws = sheet(n); return !!ws && Object.values(ws).some(c => c && typeof c === 'object' && c.v === v); };
  t.ok(has('U7 Lead schedule', T0.close), 'U7 export carries the trial balance figure entered');
  t.ok(has('U7.4 Specific provision types', 'Fixed-price supply contract'), 'U7.4 export carries the onerous contract entered');
  t.ok(has('U7.4 Specific provision types', 'Logistics reorganisation'), 'U7.4 export carries the restructuring entered');
  t.ok(has('U7.5 Legal and claims', 'Contract dispute - supply shortfall'), 'U7.5 export carries the claim entered');
  t.ok(has('U7.8 Estimate evaluation', 'Claims rate of 1.5%'), 'U7.8 export carries the key assumption entered');
  t.ok(has('U7.6 Contingencies', 'Corporate guarantee of subsidiary borrowings'), 'U7.6 export carries the contingent liabilities from the schedule');
  const countF = ws => Object.keys(ws).filter(k => k[0] !== '!' && ws[k].f).length;
  t.ok(countF(sheet('U7.1 Movement and casting')) > 20, `U7.1 export carries live roll-forward formulas (${countF(sheet('U7.1 Movement and casting'))})`);
  t.ok(countF(sheet('U7 Lead schedule')) > 10, `U7 export carries live formulas (${countF(sheet('U7 Lead schedule'))})`);
  const out = path.join(__dirname, 'out-PROV-file.xlsx');
  L.XLSX.writeFile(wb, out);
  const re = L.XLSX.readFile(out);
  t.ok(re.SheetNames.length === wb.SheetNames.length, 'workbook survives the Excel round-trip');
  fs.unlinkSync(out);

  const st = pAll.state().modules.PROV;
  const text = L.Modules.byCode.PROV.suggestConclusion(st, pAll.ctx());
  t.ok(typeof text === 'string' && text.length > 400, `suggestConclusion produces a conclusion (${text.length} characters)`);
  t.ok(/agreeing to the trial balance/.test(text), 'the conclusion reflects the trial balance tie');
  t.ok(/FRS 37/.test(text) && /contingent asset/.test(text), 'the conclusion covers contingencies and cites the standard');
  t.ok(/future operating losses/.test(text) && /para 63/.test(text), 'the conclusion reports the future operating loss provision');
  t.ok(/undiscounted/.test(text), 'the conclusion reports the undiscounted provision');

  /* every page reports a flag without throwing, and the pages with findings raise it */
  const M = L.Modules.byCode.PROV, d = pAll.derived;
  const flags = Object.fromEntries(M.pages.filter(p => p.flag).map(p => [p.ref, p.flag(st, d)]));
  console.log('  page flags: ' + Object.entries(flags).map(([k, v]) => k + (v ? '•' : '')).join(' '));
  ['U7.1', 'U7.3', 'U7.4', 'U7.5', 'U7.6', 'U7.7', 'U7.8'].forEach(r => t.ok(flags[r] === true, `${r} raises its flag in the file index`));
}

t.done();
