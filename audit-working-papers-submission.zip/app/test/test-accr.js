/* Headless test of the ACCR (accruals and other payables) audit file against the synthetic schedules.
   Run:  node test/test-accr.js                                                   */
const { load, counter, money, engagement, pipeline, expectedExceptions, OUT, path, fs } = require('./spec-lib');
const L = load(['accr.js']);
const t = counter();
const CODE = 'ACCR';

const CLIENTS = [
  { c: 'client-a', ye: '2025-02-28', file: 'PBC-ACC-01 Accruals schedule 2025-02-28.xlsx' },
  { c: 'client-b', ye: '2025-09-30', file: 'PBC-ACC-01 Accruals schedule 2025-09-30.xlsx' },
  { c: 'client-d', ye: '2025-09-30', file: 'PBC-ACC-01 Accruals schedule 2025-09-30.xlsx' }
];
const PLANTED = ['EX-ACC-01', 'EX-ACC-02', 'EX-ACC-03'];

console.log('\n=== ACCR — module registration ===');
t.ok(L.Modules.byCode.ACCR && L.Modules.byCode.ACCR.name === 'Accruals & Other Payables' && L.Modules.byCode.ACCR.group === 'Liabilities & equity', 'ACCR registered via Modules.register');
t.ok(L.Modules.byCode.ACCR.pages.filter(p => p.render).length === 5, 'five rendered working papers (U4, U4.1–U4.4)');
t.ok(L.Modules.byCode.ACCR.pages.filter(p => p.kind).map(p => p.kind).sort().join() === 'cleaned,conclusion,mapping,source', 'four shell pages present');
t.ok(L.Modules.byCode.ACCR.tests.some(x => x.id === 'EX-TIE-01'), 'trial balance tie test present');

for (const { c, ye, file } of CLIENTS) {
  const eng = engagement(L.Core, ye, 145000);
  const f = path.join(OUT, c, file);
  const label = c;
  console.log(`\n=== ACCR — ${c} ===`);
  const p = pipeline(L, f, CODE, eng, { supSampleN: 2 });
  const d = p.derived, T = d.totals;
  console.log(`  header row ${p.headerRow + 1}; ${p.records.length} lines; opening ${money(T.open)} + provided ${money(T.charge)} − utilised ${money(T.utilised)} = ${money(T.computed)} vs closing per schedule ${money(T.close)} (cast diff ${money(T.castDiff)}); sign ${d.sign}`);
  t.ok(p.missingRequired().length === 0, `${label}: required fields mapped (description, opening, provided, utilised, closing)`, p.missingRequired().join(', '));
  ['description', 'account_code', 'bal_open', 'charge', 'utilised', 'bal_close'].forEach(k => t.ok(!!p.mapping[k], `${label}: "${k}" mapped from "${p.mapping[k]?.heading}"`));
  t.ok(p.records.length === 11, `${label}: eleven accrual lines read; title block and TOTAL row held out (${p.records.length})`);
  t.ok(d.sign === 'signed', `${label}: utilisation sign auto-detected as negative = reduction`);
  t.ok(T.open > 400000 && T.close > 500000, `${label}: totals are sane (opening ${money(T.open)}, closing ${money(T.close)})`);
  t.ok(Math.abs(T.open + T.charge - T.utilised - T.computed) < 0.05, `${label}: recomputed closing total = opening + provided − utilised`);
  t.ok(Math.abs(T.castDiff - (T.close - T.computed)) < 0.05, `${label}: total cast difference = closing per schedule − recomputed`);
  t.ok(p.records.every(r => Math.abs(r.__computedClose - ((r.bal_open || 0) + (r.charge || 0) - r.__reduction)) < 0.005), `${label}: every line recomputed as opening + provided − utilised`);
  t.ok(p.records.every(r => r.__displayKey === r.description), `${label}: display key is the description`);

  /* planted exceptions */
  const planted = expectedExceptions('Accruals', c);
  const ids = [...new Set(p.exceptions.map(e => e.id))].sort();
  console.log(`  exceptions: ${p.exceptions.length} → ${ids.join(', ')}`);
  t.ok(planted.length === 3, `${label}: three planted accruals exceptions in the expectation file`);
  for (const id of PLANTED) {
    const pl = planted.find(x => x.exception.startsWith(id));
    if (!pl) continue;
    const hit = p.exceptions.find(e => e.id === id && String(e.recordKey) === pl.record_key);
    t.ok(!!hit, `${label}: ${pl.exception} raised on ${pl.record_key}`, `raised on: ${p.exceptions.filter(e => e.id === id).map(e => e.recordKey).join(' ; ') || 'nothing'}`);
  }
  const e01 = p.exceptions.find(e => e.id === 'EX-ACC-01' && e.recordKey === 'Audit fee');
  t.ok(e01 && Math.abs(e01.difference - 1200) < 0.005 && e01.cell && /^F\d+$/.test(e01.cell), `${label}: EX-ACC-01 difference is the planted 1,200.00 with a cell reference (${e01 && e01.difference}, ${e01 && e01.cell})`);
  const e02 = p.exceptions.filter(e => e.id === 'EX-ACC-02');
  t.ok(e02.length === 1 && e02[0].recordKey === 'Bonus provision' && Math.abs(e02[0].difference - e02[0].actual) < 0.005, `${label}: EX-ACC-02 fires only on the bonus provision (opening ${money(e02[0]?.actual)} carried with no utilisation)`);
  const e03 = p.exceptions.filter(e => e.id === 'EX-ACC-03');
  t.ok(e03.length === 1 && e03[0].recordKey === 'Professional fees' && e03[0].actual < 0 && e03[0].severity === 'above-trivial', `${label}: EX-ACC-03 fires only on the negative professional fees line, above-trivial`);
  t.ok(p.exceptions.filter(e => e.id === 'EX-ACC-01').every(e => ['Audit fee', 'Professional fees'].includes(e.recordKey)), `${label}: casting exceptions limited to the planted line and the sign-flipped line`);
  t.ok(!p.exceptions.some(e => ['EX-ACC-04', 'EX-ACC-05', 'EX-ACC-06', 'EX-ACC-07', 'EX-ACC-08', 'EX-TIE-01'].includes(e.id)), `${label}: input-driven tests silent before the auditor enters anything`);
  t.ok(d.negatives.length === 1 && d.notUtilised.length === 1 && d.castFails.length === 2 && d.nils.length === 0, `${label}: derived lists (negatives ${d.negatives.length}, not utilised ${d.notUtilised.length}, cast fails ${d.castFails.length}, nils ${d.nils.length})`);

  /* U4.2 support selection */
  const S = d.support;
  console.log(`  U4.2: threshold ${money(S.threshold)}; key ${S.key.length}, sample ${S.sample.length}, coverage ${S.coverage}%`);
  t.ok(S.threshold === eng.materiality.trivial, `${label}: support threshold defaults to the trivial threshold`);
  t.ok(S.key.every(r => Math.abs(r.bal_close) >= S.threshold) && S.sample.every(r => Math.abs(r.bal_close) < S.threshold), `${label}: key items at or above threshold; sample drawn below it`);
  t.ok(S.sample.length === Math.min(2, S.residual.length), `${label}: sample size honoured`);
  t.ok(S.coverage > 0 && S.coverage <= 100, `${label}: coverage computed (${S.coverage}%)`);
  const pHi = pipeline(L, f, CODE, eng, { supThreshold: 100000, supSampleN: 3 });
  t.ok(pHi.derived.support.key.length < S.key.length && pHi.derived.support.key.every(r => Math.abs(r.bal_close) >= 100000), `${label}: raising the threshold to 100,000 shrinks the key items (${pHi.derived.support.key.length})`);
  const pS1 = pipeline(L, f, CODE, eng, { supThreshold: 100000, supSampleN: 3 });
  t.ok(JSON.stringify(pS1.derived.support.sample.map(r => r.__srcRow)) === JSON.stringify(pHi.derived.support.sample.map(r => r.__srcRow)), `${label}: same seed → identical sample`);
  const pS2 = pipeline(L, f, CODE, eng, { supThreshold: 100000, supSampleN: 3, supSeed: 99 });
  t.ok(JSON.stringify(pS2.derived.support.sample.map(r => r.__srcRow)) !== JSON.stringify(pHi.derived.support.sample.map(r => r.__srcRow)), `${label}: different seed → different sample`);

  /* pages and export */
  p.renderAll(t, label);
  p.exportCheck(t, label);
}

/* ---------------------------------------------------------------------- */
console.log('\n=== ACCR — auditor inputs drive the tests (client-a) ===');
{
  const eng = engagement(L.Core, '2025-02-28', 145000);
  const file = path.join(OUT, 'client-a', 'PBC-ACC-01 Accruals schedule 2025-02-28.xlsx');
  const base = pipeline(L, file, CODE, eng);
  const T = base.derived.totals;

  /* U4 lead: TB and PY */
  const pTB = pipeline(L, file, CODE, eng, { tbBalance: T.close, pyBalance: T.open });
  t.ok(pTB.derived.lead.tbDiff === 0 && pTB.derived.lead.pyDiff === 0, 'U4: schedule agrees to TB and opening agrees to PY when the figures are entered');
  t.ok(!pTB.exceptions.some(e => e.id === 'EX-TIE-01' || e.id === 'EX-ACC-05'), 'EX-TIE-01 / EX-ACC-05 silent when balances agree');
  const pTB2 = pipeline(L, file, CODE, eng, { tbBalance: T.close - 500, pyBalance: T.open + 250 });
  const tie = pTB2.exceptions.find(e => e.id === 'EX-TIE-01'), e05 = pTB2.exceptions.find(e => e.id === 'EX-ACC-05');
  t.ok(tie && Math.abs(tie.difference - 500) < 0.005 && tie.expected === T.close - 500, 'EX-TIE-01 raised with the difference to the TB figure entered', tie && tie.difference);
  t.ok(e05 && Math.abs(e05.difference + 250) < 0.005, 'EX-ACC-05 raised when opening per schedule ≠ prior year closing', e05 && e05.difference);
  t.ok(pTB2.derived.lead.variancePct != null && Math.abs(pTB2.derived.lead.variance - (T.close - (T.open + 250))) < 0.005, 'U4: movement vs prior year computed');

  /* U4.2 support inputs: per-support figure and reasonable flag */
  const pSup = pipeline(L, file, CODE, eng, {}, recs => {
    const bonus = recs.find(r => r.description === 'Bonus provision');
    bonus.__wp = { support: { perSupport: bonus.bal_close - 1500, reasonable: 'Y', doc: 'Bonus computation' } };
    const audit = recs.find(r => r.description === 'Audit fee');
    audit.__wp = { support: { perSupport: audit.bal_close, reasonable: 'Y' } };
  });
  const e06 = pSup.exceptions.filter(e => e.id === 'EX-ACC-06');
  t.ok(e06.length === 1 && e06[0].recordKey === 'Bonus provision' && Math.abs(e06[0].difference - 1500) < 0.005, 'EX-ACC-06 raised only where the schedule differs from the support', JSON.stringify(e06.map(e => [e.recordKey, e.difference])));
  t.ok(pSup.derived.support.supported === 2 && pSup.derived.support.differences.length === 1, 'U4.2 stats reflect the auditor inputs (2 assessed reasonable, 1 difference)');

  /* U4.3 reasonableness: expense entered */
  const pReas = pipeline(L, file, CODE, eng, { maxPct: 50 }, recs => {
    const bonus = recs.find(r => r.description === 'Bonus provision');
    bonus.__wp = { reason: { expense: 300000 } };                    // 259,565.62 / 300,000 = 86.5%
    const util = recs.find(r => r.description === 'Utilities');
    util.__wp = { reason: { expense: 86240 } };                      // 20,817.85 / 86,240 = 24.1%
  });
  const e04 = pReas.exceptions.filter(e => e.id === 'EX-ACC-04');
  t.ok(e04.length === 1 && e04[0].recordKey === 'Bonus provision' && e04[0].severity === 'informational' && Math.abs(e04[0].actual - 86.52) < 0.05, 'EX-ACC-04 raised (informational) on the accrual above 50% of its expense', JSON.stringify(e04.map(e => [e.recordKey, e.actual])));
  const util = pReas.records.find(r => r.description === 'Utilities');
  t.ok(Math.abs(util.__pctOfExpense - 24.14) < 0.05 && Math.abs(util.__impliedMonths - 2.9) < 0.05, `U4.3 utilities: ${util.__pctOfExpense}% of expense ≈ ${util.__impliedMonths} months`);
  t.ok(pReas.derived.reason.entered === 2, 'U4.3 counts the expenses entered');
  const pReas2 = pipeline(L, file, CODE, eng, { maxPct: 90 }, recs => { recs.find(r => r.description === 'Bonus provision').__wp = { reason: { expense: 300000 } }; });
  t.ok(!pReas2.exceptions.some(e => e.id === 'EX-ACC-04'), 'raising the % threshold to 90 silences EX-ACC-04');

  /* U4.4 completeness */
  const cfgComp = { compRows: 5,
    'cpSupplier:cp1': 'Utility provider', 'cpDate:cp1': '15/03/2025', 'cpDesc:cp1': 'Electricity Feb 2025', 'cpAmount:cp1': 7200, 'cpRelates:cp1': 'Y', 'cpAccrued:cp1': 'N',
    'cpSupplier:cp2': 'Law firm', 'cpDate:cp2': '20/03/2025', 'cpDesc:cp2': 'Retainer Mar 2025', 'cpAmount:cp2': 5000, 'cpRelates:cp2': 'N', 'cpAccrued:cp2': 'N',
    'cpSupplier:cp3': 'Auditor', 'cpDate:cp3': '30/03/2025', 'cpDesc:cp3': 'Audit fee FY25', 'cpAmount:cp3': 25000, 'cpRelates:cp3': 'Y', 'cpAccrued:cp3': 'Y' };
  const pComp = pipeline(L, file, CODE, eng, cfgComp);
  const Cm = pComp.derived.completeness;
  t.ok(Cm.items.length === 3 && Math.abs(Cm.examined - 37200) < 0.005, `U4.4: three items examined totalling ${money(Cm.examined)}`);
  t.ok(Cm.unaccrued.length === 1 && Math.abs(Cm.unaccruedValue - 7200) < 0.005, 'U4.4: only the item relating to the year and not accrued is unaccrued');
  const e07 = pComp.exceptions.filter(e => e.id === 'EX-ACC-07');
  t.ok(e07.length === 1 && e07[0].recordKey === 'Utility provider' && Math.abs(e07[0].difference - 7200) < 0.005, 'EX-ACC-07 raised for the unaccrued utility invoice');

  /* utilisation sign override */
  const pPos = pipeline(L, file, CODE, eng, { utilisedSign: 'positive' });
  t.ok(pPos.derived.sign === 'positive' && pPos.derived.castFails.length === 10, 'forcing positive = reduction makes every utilised line fail the cast (the schedule is signed) — the control is live', pPos.derived.castFails.length);

  /* nil line detection */
  const pNil = pipeline(L, file, CODE, eng, {}, recs => { const r = recs.find(x => x.description === 'Repairs'); r.bal_open = 0; r.charge = 0; r.utilised = 0; r.bal_close = 0; });
  const e08 = pNil.exceptions.filter(e => e.id === 'EX-ACC-08');
  t.ok(e08.length === 1 && e08[0].recordKey === 'Repairs' && e08[0].severity === 'informational', 'EX-ACC-08 nil line raised as informational');
  t.ok(!pNil.derived.support.selected.includes(pNil.records.find(r => r.description === 'Repairs')), 'nil lines are excluded from the support selection');

  /* export carries the inputs */
  const pAll = pipeline(L, file, CODE, eng, { ...cfgComp, tbBalance: T.close });
  const wb = pAll.exportCheck(t, 'client-a with inputs');
  const wsC = wb.Sheets['U4.4 Completeness — post year-end review'.replace(/[\[\]\*\?\/\\:]/g, '').slice(0, 31)];
  t.ok(wsC && Object.values(wsC).some(c => c && c.v === 'Utility provider'), 'U4.4 export carries the post year-end items entered');
  const wsL = wb.Sheets['U4 Lead schedule'];
  t.ok(wsL && Object.values(wsL).some(c => c && typeof c === 'object' && c.v === T.close), 'U4 export carries the TB figure entered');
  const out = path.join(__dirname, 'out-ACCR-file.xlsx');
  L.XLSX.writeFile(wb, out);
  const re = L.XLSX.readFile(out);
  t.ok(re.SheetNames.length === wb.SheetNames.length, 'workbook survives the Excel round-trip');
  fs.unlinkSync(out);

  /* conclusion helper */
  const st = pAll.state().modules.ACCR;
  const text = L.Modules.byCode.ACCR.suggestConclusion(st, pAll.ctx());
  t.ok(typeof text === 'string' && text.length > 100 && /agreeing to the trial balance/.test(text), 'suggestConclusion produces text and reflects the TB tie');
}

t.done();
