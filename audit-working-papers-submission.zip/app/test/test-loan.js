/* Headless test of the LOAN audit file against the synthetic loan schedules.
   Run:  node test/test-loan.js                                                */
const { load, counter, money, engagement, pipeline, expectedExceptions, OUT, path, fs } = require('./spec-lib');
const L = load(['loan.js']);
const t = counter();
const CODE = 'LOAN';

const CLIENTS = [
  { c: 'client-a', ye: '2025-02-28', file: 'PBC-LOAN-01 Loan schedule 2025-02-28.xlsx', n: 2 },
  { c: 'client-b', ye: '2025-09-30', file: 'PBC-LOAN-01 Loan schedule 2025-09-30.xlsx', n: 4 },
  { c: 'client-d', ye: '2025-09-30', file: 'PBC-LOAN-01 Loan schedule 2025-09-30.xlsx', n: 2 }
];

console.log('\n=== LOAN — module registration ===');
t.ok(L.Modules.byCode.LOAN && L.Modules.byCode.LOAN.name === 'Borrowings', 'LOAN registered via Modules.register');
t.ok(L.Modules.byCode.LOAN.pages.filter(p => p.render).length === 7, 'seven rendered working papers (V3, V3.1–V3.6)');

for (const { c, ye, file: f, n } of CLIENTS) {
  const eng = engagement(L.Core, ye, 145000);
  const file = path.join(OUT, c, f);
  const label = c;
  console.log(`\n=== ${label} ===`);
  const p = pipeline(L, file, CODE, eng);
  const d = p.derived, T = d.totals;
  console.log(`  header row ${p.headerRow + 1}; ${p.records.length} facilities; opening ${money(T.open)} − repaid ${money(T.repay)} = ${money(T.closeCalc)} vs closing ${money(T.close)}; interest ${money(T.interest)} vs audit ${money(T.intAudit)}`);
  t.ok(p.missingRequired().length === 0, `${label}: required fields mapped`, p.missingRequired().join(', '));
  for (const k of ['facility', 'lender', 'account_no', 'principal', 'rate', 'start', 'tenor', 'instalment', 'bal_open', 'repaid', 'interest', 'bal_close', 'current', 'noncurrent'])
    t.ok(p.mapping[k], `${label}: ${k} mapped (${p.mapping[k]?.heading} ${p.mapping[k]?.letter})`);
  t.ok(p.mapping.instalment && p.mapping.repaid && p.mapping.instalment.colIndex < p.mapping.repaid.colIndex, `${label}: instalment column precedes repayment column (duplicate "Repayment" headings resolved)`);
  t.ok(p.records.length === n, `${label}: ${n} facilities read (TOTAL and footnotes held out)`);
  t.ok(p.records.every(r => r.instalment > 0 && r.__repay >= 0 && !r.__swapped), `${label}: instalments positive and repayments taken at absolute value without swapping`);
  t.ok(p.records.every(r => r.start instanceof Date && r.tenor > 0 && r.rate > 0), `${label}: drawdown dates, tenors and rates parsed`);

  /* planted exceptions */
  const exp = expectedExceptions('Borrowings', c);
  const has = (id, key) => p.exceptions.some(e => e.id === id && e.recordKey === key);
  for (const x of exp) {
    const id = x.exception.slice(0, 10);
    t.ok(has(id, x.record_key), `${label}: planted ${x.exception} raised for "${x.record_key}"`);
  }
  const e01 = p.exceptions.find(e => e.id === 'EX-LOAN-01');
  t.ok(e01 && Math.abs(e01.difference - 2400) < 0.005, `${label}: EX-LOAN-01 quantifies the 2,400 movement difference`, e01 && e01.difference);
  t.ok(p.exceptions.filter(e => e.id === 'EX-LOAN-01').length === 1, `${label}: EX-LOAN-01 raised for the one facility only`);
  const e02 = p.exceptions.filter(e => e.id === 'EX-LOAN-02');
  t.ok(e02.length === 1 && e02[0].recordKey === 'Working capital facility' && Math.abs(Math.abs(e02[0].difference) - 5000) < 0.02, `${label}: EX-LOAN-02 raised once, for the working capital facility, 5,000`, JSON.stringify(e02.map(e => [e.recordKey, e.difference])));
  const termLoan = p.records.find(r => r.facility === 'Term loan - equipment');
  t.ok(termLoan.__splitExplainedByMove, `${label}: the term loan's split cast difference is explained by EX-LOAN-01 and not raised twice`);
  if (n === 4) {
    const e03 = p.exceptions.filter(e => e.id === 'EX-LOAN-03');
    t.ok(e03.length === 1 && e03[0].recordKey === 'Property mortgage', `${label}: EX-LOAN-03 raised only for the property mortgage`, JSON.stringify(e03.map(e => e.recordKey)));
    const pm_ = p.records.find(r => r.facility === 'Property mortgage');
    t.ok(Math.abs(pm_.interest / pm_.__intAudit - 1.6) < 0.01, `${label}: recomputed interest is 1/1.6 of the charge (seeded ×1.6)`, pm_.interest / pm_.__intAudit);
    t.ok(pm_.__effRate > pm_.rate * 1.4, `${label}: effective rate implied (${pm_.__effRate}%) well above the stated ${pm_.rate}%`);
  } else {
    t.ok(!p.exceptions.some(e => e.id === 'EX-LOAN-03'), `${label}: EX-LOAN-03 silent — every interest charge agrees to the reducing-balance recalculation`);
  }
  const clean = p.records.filter(r => r.facility !== 'Property mortgage' && r.bal_open > 0);
  t.ok(clean.every(r => Math.abs(r.__intDiff) < 1), `${label}: recomputed interest agrees to the cent on unseeded facilities`, clean.map(r => r.__intDiff).join(','));
  t.ok(clean.every(r => Math.abs(r.__repayDiff) < 1), `${label}: principal per amortisation agrees to repayments recorded on unseeded facilities`, clean.map(r => r.__repayDiff).join(','));
  t.ok(p.records.every(r => !r.__instBreak), `${label}: every instalment follows the annuity on principal, rate and tenor`, p.records.map(r => r.__instDiff).join(','));
  t.ok(!p.exceptions.some(e => e.id === 'EX-LOAN-08'), `${label}: no negative balances or over-repayments`);
  console.log('  exceptions: ' + JSON.stringify(p.exceptions.reduce((m, e) => { m[e.id] = (m[e.id] || 0) + 1; return m; }, {})));

  /* current portion */
  const wc = p.records.find(r => r.facility === 'Working capital facility');
  t.ok(Math.abs(wc.__curDiff - 5000) < 0.02, `${label}: current portion per client exceeds the amortisation by the seeded 5,000`, wc.__curDiff);
  t.ok(p.records.every(r => r.__curAudit >= 0 && r.__curAudit <= (r.bal_close || 0) + 0.01 && Math.abs(r.__curAudit + r.__ncAudit - (r.bal_close || 0)) < 0.02), `${label}: audit split casts to the closing balance`);
  const others = p.records.filter(r => r.facility !== 'Working capital facility' && r.facility !== 'Term loan - equipment' && r.bal_close > 0);
  t.ok(others.every(r => Math.abs(r.__curDiff) < 1), `${label}: current portion recomputed agrees on unseeded facilities`, others.map(r => r.__curDiff).join(','));

  /* interest methods */
  const pAvg = pipeline(L, file, CODE, eng, { intMethod: 'average' });
  t.ok(pAvg.records.every(r => r.__intAudit != null) && pAvg.records.some(r => r.__intAudit !== p.records.find(x => x.__srcRow === r.__srcRow).__intAudit), `${label}: average-balance method gives a different (approximate) recomputation`);
  const pTight = pipeline(L, file, CODE, eng, { intTolPct: 0, intTol: 0.005 });
  t.ok(pTight.exceptions.filter(e => e.id === 'EX-LOAN-03').length >= (n === 4 ? 1 : 0), `${label}: tightening the tolerance never loses the seeded exception`);

  /* lead inputs, confirmations, covenants */
  const k0 = p.records[0].__facKey, k1 = p.records[1].__facKey;
  const cfgIn = { ['tb:' + k0]: p.records[0].bal_close, ['tb:' + k1]: p.records[1].bal_close + 100, ['py:' + k0]: p.records[0].bal_open,
    pnlInterest: T.interest + 50, ['confRecd:' + k0]: 'Y', ['confBal:' + k0]: p.records[0].bal_close, ['confRecd:' + k1]: 'Y', ['confBal:' + k1]: p.records[1].bal_close - 20, ['confRate:' + k1]: p.records[1].rate + 0.5,
    covRows: 3, 'covFacility:cov1': p.records[0].facility, 'covDesc:cov1': 'Debt service cover', 'covType:cov1': 'Minimum', 'covThreshold:cov1': 1.25, 'covActual:cov1': 1.1,
    'covDesc:cov2': 'Gearing', 'covType:cov2': 'Maximum', 'covThreshold:cov2': 0.6, 'covActual:cov2': 0.45,
    ['secType:' + k0]: 'Legal mortgage', ['secCarrying:' + k0]: 1500000, ['secType:' + k1]: 'Unsecured' };
  const pi = pipeline(L, file, CODE, eng, cfgIn);
  const ex = id => pi.exceptions.filter(e => e.id === id);
  t.ok(ex('EX-LOAN-20').length === 1 && Math.abs(ex('EX-LOAN-20')[0].difference + 100) < 0.005 && ex('EX-LOAN-20')[0].recordKey === p.records[1].facility, `${label}: EX-LOAN-20 raised only for the facility not agreeing to the TB`);
  t.ok(ex('EX-LOAN-22').length === 0, `${label}: EX-LOAN-22 silent when the opening balance agrees to prior year`);
  t.ok(ex('EX-LOAN-21').length === 1 && Math.abs(ex('EX-LOAN-21')[0].difference + 50) < 0.005, `${label}: EX-LOAN-21 interest vs P&L difference of −50`);
  t.ok(ex('EX-LOAN-05').length === 1 && Math.abs(ex('EX-LOAN-05')[0].difference + 20) < 0.005, `${label}: EX-LOAN-05 confirmation difference raised for one facility`);
  t.ok(ex('EX-LOAN-09').length === 1, `${label}: EX-LOAN-09 rate per confirmation differs`);
  t.ok(pi.derived.confirmations.received === 2, `${label}: confirmations received counted`);
  t.ok(pi.derived.covenant.rows.length === 2 && pi.derived.covenant.breaches.length === 1 && ex('EX-LOAN-06').length === 1 && ex('EX-LOAN-06')[0].severity === 'above-trivial', `${label}: covenant minimum breached raised as EX-LOAN-06 above-trivial; maximum complied`);
  t.ok(Math.abs(pi.derived.covenant.rows[0].headroom + 0.15) < 1e-9, `${label}: covenant headroom computed`);
  t.ok(Math.abs(pi.derived.security.secured - p.records[0].bal_close) < 0.005 && Math.abs(pi.derived.security.unsecured - p.records[1].bal_close) < 0.005 && pi.derived.security.pledged === 1500000, `${label}: security schedule totals secured, unsecured and pledged assets`);

  /* pages and export */
  p.renderAll(t, label);
  const wb = pi.exportCheck(t, label);
  const ws = wb.Sheets[wb.SheetNames.find(x => x.startsWith('V3.5 '))];
  t.ok(ws && Object.values(ws).some(cell => cell && cell.v === 'Debt service cover'), `${label}: V3.5 export carries the covenant entered`);
  const text = L.Modules.byCode.LOAN.suggestConclusion(pi.state().modules.LOAN, pi.ctx());
  t.ok(typeof text === 'string' && text.length > 100, `${label}: suggestConclusion produces text`);
}

/* swap safety net: a schedule whose repayment column was mapped as instalment */
console.log('\n=== LOAN — transposed instalment / repayment columns ===');
{
  const eng = engagement(L.Core, '2025-02-28', 145000);
  const p = pipeline(L, path.join(OUT, 'client-a', 'PBC-LOAN-01 Loan schedule 2025-02-28.xlsx'), CODE, eng, {}, recs => recs.forEach(r => { const a = r.instalment; r.instalment = r.repaid; r.repaid = a; }));
  t.ok(p.records.every(r => r.__swapped && r.instalment > 0 && r.__repay > r.instalment), 'negative instalment beside positive repayment is swapped back');
  t.ok(p.exceptions.filter(e => e.id === 'EX-LOAN-10').length === 2 && p.exceptions.some(e => e.id === 'EX-LOAN-01'), 'EX-LOAN-10 flags the transposition and the movement test still runs');
}

/* round trip */
{
  const eng = engagement(L.Core, '2025-09-30', 145000);
  const p = pipeline(L, path.join(OUT, 'client-b', 'PBC-LOAN-01 Loan schedule 2025-09-30.xlsx'), CODE, eng);
  const wb = L.Exporter.build(p.state(), CODE);
  const out = path.join(__dirname, 'out-LOAN-file.xlsx');
  L.XLSX.writeFile(wb, out);
  const re = L.XLSX.readFile(out);
  t.ok(re.SheetNames.length === wb.SheetNames.length, 'workbook survives the Excel round-trip');
  fs.unlinkSync(out);
}

t.done();
