/* Headless test of the IMP (Impairment, FRS 36) audit file against the synthetic impairment workbooks.
   Run:  node test/test-imp.js

   The workbook carries three sheets. The CGU register is the uploaded listing; the client's indicator
   assessment and value-in-use model are transcribed by the auditor onto IMP-02 / IMP-03 and recomputed.
   This test picks the CGU register sheet by name, as the auditor would with the sheet picker.        */
const { load, counter, money, engagement, expectedExceptions, OUT, path, fs } = require('./spec-lib');
const L = load(['imp.js']);
const t = counter();
const CODE = 'IMP';
const { Core, Modules } = L;

function pipeline(file, eng, cfgOverride = {}, prep) {
  const M = Modules.byCode[CODE];
  const buf = fs.readFileSync(file);
  const wbData = Core.readWorkbook(buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength), path.basename(file));
  const sheet = wbData.sheets.find(s => /cgu/i.test(s.name)) || wbData.sheets[0];
  const headerRow = Core.detectHeader(sheet.rows);
  const clean = Core.cleanTable(sheet.rows, headerRow);
  const mapping = Core.proposeMapping(clean.headers, M.fields, clean.rows.filter(r => r.__kind === 'data').slice(0, 40));
  const built = Core.buildRecords(clean, M.fields, mapping);
  const cfg = M.defaultConfig(); Object.assign(cfg, cfgOverride);
  if (prep) prep(built.records, cfg);
  const res = Core.runTests(M, built.records, cfg, eng);
  return { M, sheet, headerRow, clean, mapping, built, cfg, res, records: built.records, exceptions: res.exceptions, derived: res.derived, eng,
    missingRequired() { return M.fields.filter(f => f.required && !mapping[f.key]).map(f => f.key); },
    ctx() { return { eng, cfg, d: res.derived, recs: built.records.filter(r => !r.__excluded), all: built.records, money: x => x, money0: x => x, pct: x => x, fmtDate: Core.fmtDate, r2: n => n == null ? null : Math.round(n * 100) / 100, pm: eng.materiality.pm, trivial: eng.materiality.trivial, M }; },
    state() { return { engagement: eng, modules: { [CODE]: { code: CODE, records: built.records, exceptions: res.exceptions, derived: res.derived, mapping,
      sources: [{ fileName: path.basename(file), hash: wbData.hash, sheetName: sheet.name, headerRow, rowCount: built.records.length, uploadedAt: wbData.uploadedAt, rawRows: sheet.rows }],
      config: cfg, cleanLog: clean.log, mapIssues: built.issues, edits: [], adjustments: [], aiBlocks: [], pageNotes: {}, trail: [], comments: '', conclusion: '' } } }; },
    renderAll(t, label) {
      const st = this.state().modules[CODE], c = this.ctx();
      for (const pg of M.pages.filter(p => p.render)) {
        let specs = null, err = null;
        try { specs = pg.render(st, c); } catch (e) { err = e; }
        t.ok(Array.isArray(specs) && specs.length > 0 && !err, `${label}: ${pg.ref} ${pg.title} renders ${specs ? specs.length + ' specs' : ''}`, err && (err.stack || err.message));
        if (specs) { let tErr = null; try { L.SpecXL.toRows(specs.filter(Boolean), pg.id, st); } catch (e) { tErr = e; } t.ok(!tErr, `${label}: ${pg.ref} converts to worksheet rows`, tErr && tErr.message); }
        if (pg.flag) { let fErr = null; try { pg.flag(st, res.derived); } catch (e) { fErr = e; } t.ok(!fErr, `${label}: ${pg.ref} flag() does not throw`, fErr && fErr.message); }
      }
    },
    exportCheck(t, label) {
      const wb = L.Exporter.build(this.state(), CODE);
      const rendered = M.pages.filter(p => p.render);
      const expected = rendered.map(p => `${p.ref} ${p.title}`.replace(/[\[\]\*\?\/\\:]/g, '').slice(0, 31));
      const missing = expected.filter(n => !wb.SheetNames.includes(n));
      t.ok(missing.length === 0, `${label}: one sheet per rendered page (${rendered.length} pages)`, missing.join(', '));
      ['00 Index', 'Exceptions', '01 Source 1', '02 Cleaned data', '03 Mapping'].forEach(n => t.ok(wb.SheetNames.includes(n), `${label}: sheet "${n}"`));
      return wb;
    }
  };
}

/* The three clients share one model shape: Manufacturing operations CGU, 7 years, 9.3% post-tax WACC, 4.5% terminal
   growth against a 2.1% long-term average, every declaration answered Yes, no sensitivity prepared or disclosed. */
const CLIENTS = [
  { c:'client-a', ye:'2025-02-28', file:'PBC-IMP-01 Impairment assessment FRS 36 2025-02-28.xlsx', cf:[159935.04, 174329.19, 190018.82, 207120.51, 225761.35, 246079.88, 268227.07], viu:4149440.06, tv:3133549.19, carrying:3982188.28, months:14 },
  { c:'client-b', ye:'2025-09-30', file:'PBC-IMP-01 Impairment assessment FRS 36 2025-09-30.xlsx', cf:[90963.69, 99150.43, 108073.96, 117800.62, 128402.68, 139958.92, 152555.22], viu:2360010.71, tv:1782218.69, carrying:2264885.53, months:14 },
  { c:'client-d', ye:'2025-09-30', file:'PBC-IMP-01 Impairment assessment FRS 36 2025-09-30.xlsx', cf:[87910.65, 95822.61, 104446.64, 113846.84, 124093.05, 135261.43, 147434.96], viu:2280800.84, tv:1722401.46, carrying:2188868.26, months:14 },
];
const MODEL = cl => ({ viuCgu:'Manufacturing operations', viuYears:7, viuRate:9.3, viuRateBasis:'Post-tax', viuGrowth:4.5, viuBenchmark:2.1,
  declTax:'Y', declFinancing:'Y', declExpansion:'Y', declRisk:'Y', clientVIU:cl.viu, 'clientPV:tv':cl.tv,
  ...Object.fromEntries(cl.cf.map((v, i) => ['cf:y' + (i + 1), v])),
  ...Object.fromEntries([0.9149, 0.8371, 0.7658, 0.7007, 0.6411, 0.5865, 0.5366].map((v, i) => ['clientDF:y' + (i + 1), v])),
  sensPrepared:'N', sensDisclosed:'N', preparedByCY:'Internal (client)', preparedByPY:'External specialist', assumptionsVsPY:'Unchanged', impairmentPerClient:0 });
const INDICATORS = {
  'indPresent:12a':'N', 'indPresent:12b':'Y', 'indCgu:12b':'Distribution - export', 'indRA:12b':'Yes',
  'indPresent:12c':'Y', 'indCgu:12c':'All CGUs', 'indRA:12c':'Yes', 'indPresent:12d':'N', 'indPresent:12e':'N',
  'indPresent:12f':'Y', 'indCgu:12f':'Specialty coatings business', 'indRA:12f':'No', 'indComment:12f':'Coating line idle since April pending re-permitting.',
  'indPresent:12g':'Y', 'indCgu:12g':'Manufacturing operations', 'indRA:12g':'Yes',
  'indPresent:14':'Y', 'indCgu:14':'Specialty coatings business', 'indRA:14':'No' };

console.log('\n=== IMP — module registration ===');
const M = Modules.byCode.IMP;
t.ok(M && /Impairment/.test(M.name), 'IMP registered via Modules.register');
t.ok(M.pages.filter(p => p.render).length === 7, 'seven rendered working papers (IMP, IMP-01, 02, 03, 06, 07, 10)');
t.ok(Array.from({ length: 11 }, (_, i) => 'EX-IMP-' + String(i + 1).padStart(2, '0')).every(id => M.tests.some(x => x.id === id)), 'EX-IMP-01..11 defined');
t.ok(M.INDICATORS.length === 8 && M.INDICATORS.map(i => i.id).join(',') === L.ctx.PPEModule.INDICATORS.map(i => i.id).join(','), 'indicator checklist carries the same eight para 12/14 items as the PPE file');
{ /* the value in use engine on a textbook case: 100 a year for 5 years at 10%, no terminal value */
  const v = M.viuOf([100, 100, 100, 100, 100], 0.10, null);
  t.ok(Math.abs(v.sumPV - 379.08) < 0.01 && v.tv == null && Math.abs(v.viu - 379.08) < 0.01, 'viuOf: annuity of 100 for 5 years at 10% = 379.08 with no terminal value');
  const w = M.viuOf([100], 0.10, 0.02);
  t.ok(Math.abs(w.tv - 100 * 1.02 / 0.08) < 0.01 && Math.abs(w.pvTV - w.tv / 1.1) < 0.01, 'viuOf: Gordon growth terminal value and its discounting');
  t.ok(Math.abs(M.bisect(x => 2 - x, 0, 10) - 2) < 1e-6 && M.bisect(x => 1 + x, 0, 10) === null, 'bisect finds a root and reports none when the sign does not change');
}

for (const cl of CLIENTS) {
  const { c, ye, file } = cl;
  const eng = engagement(Core, ye, 145000);
  const f = path.join(OUT, c, file);
  console.log(`\n=== ${c} / ${file} ===`);
  const full = { ...MODEL(cl), ...INDICATORS };
  const p = pipeline(f, eng, full);
  const d = p.derived, V = d.viu, S = d.sens;
  console.log(`  sheet "${p.sheet.name}", header row ${p.headerRow + 1}; ${p.records.length} CGUs; carrying ${money(d.totals.carrying)}; goodwill ${money(d.totals.goodwill)}`);
  console.log(`  VIU per audit ${money(V.viu)} vs client ${money(V.clientVIU)} (diff ${money(V.viuDiff)}); headroom ${money(V.headroom)} (${V.headroomPct}%)`);
  console.log(`  break-even: ${S.items.map(i => `${i.assumption} ${i.breakEven}${i.unit.startsWith('%') ? '%' : ''} (${i.change > 0 ? '+' : ''}${i.change} ${i.changeUnit})`).join('; ')}`);
  console.log(`  exceptions: ${p.exceptions.map(e => e.id).sort().join(', ')}`);

  /* mapping and register */
  t.ok(p.sheet.name === 'CGU register', `${c}: CGU register sheet selected`);
  t.ok(p.missingRequired().length === 0, `${c}: required fields mapped (cgu, ppe, goodwill, carrying)`, p.missingRequired().join(', '));
  t.ok(p.mapping.intang_finite && /finite/i.test(p.mapping.intang_finite.heading) && !/indefinite/i.test(p.mapping.intang_finite.heading) && p.mapping.intang_indef && /indefinite/i.test(p.mapping.intang_indef.heading), `${c}: finite and indefinite-life intangible columns kept apart`);
  t.ok(p.mapping.rou && p.mapping.other && p.mapping.tested_annually && p.mapping.last_tested && p.mapping.segment, `${c}: ROU, other net assets, tested-annually, last-tested and segment columns mapped`);
  t.ok(p.records.length === 4 && d.totals.count === 4, `${c}: four CGUs; the TOTAL row and footnotes held out`);
  t.ok(p.records.every(r => Math.abs(r.__castDiff) <= 0.01) && !p.exceptions.some(e => e.id === 'EX-IMP-20'), `${c}: every carrying amount build-up casts to the register`, p.records.map(r => r.__castDiff).join(','));
  t.ok(Math.abs(d.totals.carrying - p.records.reduce((s, r) => s + r.carrying, 0)) < 0.01, `${c}: total carrying amount ${money(d.totals.carrying)}`);
  const byName = Object.fromEntries(p.records.map(r => [r.cgu, r]));
  const mfg = byName['Manufacturing operations'], spc = byName['Specialty coatings business'];
  t.ok(mfg && spc && mfg.__annualRequired && spc.__annualRequired && !byName['Distribution - domestic'].__annualRequired, `${c}: annual test required derived from goodwill / indefinite-life presence for two CGUs`);
  t.ok(mfg.last_tested instanceof Date && mfg.__monthsSinceTest === cl.months, `${c}: last test date parsed (${Core.fmtDate(mfg.last_tested)}), ${mfg.__monthsSinceTest} months before the year end`, `got ${mfg.__monthsSinceTest}`);
  t.ok(spc.__clientTestedAnnually && spc.__monthsSinceTest === 0 && !spc.__annualGap, `${c}: CGU tested at the year end with goodwill passes`);
  const e01 = p.exceptions.filter(e => e.id === 'EX-IMP-01');
  t.ok(e01.length === 1 && e01[0].recordKey === 'Manufacturing operations' && e01[0].severity === 'above-pm', `${c}: EX-IMP-01 for Manufacturing operations only (goodwill, answered "No", tested ${cl.months} months ago)`, e01.map(e => e.recordKey).join(', '));

  /* indicators */
  t.ok(d.indSummary.present === 5 && d.indSummary.gaps.length === 2, `${c}: five indicators present, two with no recoverable amount estimated`);
  const e09 = p.exceptions.filter(e => e.id === 'EX-IMP-09');
  t.ok(e09.length === 2 && e09.every(e => e.recordKey === 'Specialty coatings business'), `${c}: EX-IMP-09 ×2 against Specialty coatings business (paras 12(f) and 14)`, e09.map(e => e.recordKey).join(', '));
  t.ok(d.lead.find(l => l.cgu === 'Specialty coatings business').indicatorPresent && d.leadTotals.indicatorNoRA === 1, `${c}: lead schedule shows the indicator with no estimate for the coatings CGU`);

  /* value in use recalculation */
  t.ok(V.model && V.cgu === 'Manufacturing operations' && V.carrying === cl.carrying, `${c}: model attached to Manufacturing operations, carrying ${money(V.carrying)}`);
  t.ok(V.N === 7 && V.years.length === 7 && Math.abs(V.years[0].df - 0.9149) < 0.0001 && Math.abs(V.years[6].df - 0.5366) < 0.0001, `${c}: discount factors recomputed agree to the client's to 4 dp`);
  t.ok(Math.abs(V.pvTV - cl.tv) < 5, `${c}: present value of terminal value ${money(V.pvTV)} vs client ${money(cl.tv)}`);
  t.ok(Math.abs(V.viuDiff) < 5, `${c}: value in use recomputed ${money(V.viu)} agrees to the client's ${money(cl.viu)} within rounding`, money(V.viuDiff));
  t.ok(V.headroom > 0 && Math.abs(V.headroomPct - 4.2) < 0.15, `${c}: headroom ${money(V.headroom)} = ${V.headroomPct}% of carrying amount`);
  t.ok(V.years.slice(1).every(y => Math.abs(y.growthYoY - 9) < 0.05) && !V.increasingGrowth, `${c}: forecast grows a steady 9% a year (not an increasing profile)`);
  t.ok(V.flags.join(',') === 'EX-IMP-02,EX-IMP-03,EX-IMP-04,EX-IMP-05,EX-IMP-06,EX-IMP-07,EX-IMP-08', `${c}: model breaches EX-IMP-02..08`, V.flags.join(','));
  for (const id of ['EX-IMP-02', 'EX-IMP-03', 'EX-IMP-04', 'EX-IMP-05', 'EX-IMP-06', 'EX-IMP-07', 'EX-IMP-08']) t.ok(p.exceptions.some(e => e.id === id && e.recordKey === 'Manufacturing operations'), `${c}: ${id} raised against the modelled CGU`);
  t.ok(!p.exceptions.some(e => e.id === 'EX-IMP-21'), `${c}: no recalculation difference exception (client model reproduces)`);

  /* sensitivity */
  const rate = S.items.find(i => i.key === 'rate'), growth = S.items.find(i => i.key === 'growth'), cash = S.items.find(i => i.key === 'cash');
  t.ok(S.ready && rate.change > 15 && rate.change < 25 && Math.abs(rate.breakEven - 9.5) < 0.05, `${c}: break-even discount rate ${rate.breakEven}% — a ${rate.change} bps rise eliminates the headroom (client memo: 9.5%, 20 bps)`);
  { const v = M.viuOf(cl.cf, rate.breakEvenRaw / 100, 0.045); t.ok(Math.abs(v.viu - cl.carrying) < 1, `${c}: at the break-even rate value in use equals carrying amount (${money(v.viu)})`); }
  t.ok(growth.change < 0 && growth.change > -100 && growth.within, `${c}: a ${Math.abs(growth.change)} bps fall in terminal growth eliminates headroom — within the band`);
  t.ok(cash.change < 0 && Math.abs(cash.change - (cl.carrying / V.viu - 1) * 100) < 0.05 && cash.within, `${c}: cash flows ${Math.abs(cash.change)}% lower eliminate headroom`);
  t.ok(S.required && S.gap && S.impairmentAtBand > 0, `${c}: para 134(f) disclosure required; not disclosed; a 100 bps rise would impair by ${money(S.impairmentAtBand)}`);
  const e10 = p.exceptions.find(e => e.id === 'EX-IMP-10');
  t.ok(e10 && e10.recordKey === 'Manufacturing operations' && /\b(19|20|21)(\.\d+)? bps increase/.test(e10.detail) && e10.severity === 'above-pm', `${c}: EX-IMP-10 raised with the break-even change in the detail`, e10 && e10.detail.slice(0, 120));
  const pWide = pipeline(f, eng, { ...full, rpRateBps: 10, rpGrowthBps: 10, rpCashPct: 1 });
  t.ok(!pWide.derived.sens.required && !pWide.exceptions.some(e => e.id === 'EX-IMP-10'), `${c}: narrowing the reasonably possible bands below the break-even changes removes the disclosure requirement`);
  t.ok(!pipeline(f, eng, { ...full, sensDisclosed: 'Y' }).exceptions.some(e => e.id === 'EX-IMP-10'), `${c}: confirming the disclosure clears EX-IMP-10`);

  /* specialist */
  const e11 = p.exceptions.find(e => e.id === 'EX-IMP-11');
  t.ok(e11 && d.specialist.movedInternal && e11.recordKey === 'Manufacturing operations', `${c}: EX-IMP-11 external → internal preparation with unchanged assumptions`);
  t.ok(!pipeline(f, eng, { ...full, assumptionsVsPY: 'Less favourable' }).exceptions.some(e => e.id === 'EX-IMP-11'), `${c}: less favourable assumptions after the change of preparer clear EX-IMP-11`);
  t.ok(!pipeline(f, eng, { ...full, preparedByPY: 'Internal (client)' }).exceptions.some(e => e.id === 'EX-IMP-11'), `${c}: no change of preparer, no EX-IMP-11`);

  /* clearing the model exceptions one by one */
  const clear = (over, id) => t.ok(!pipeline(f, eng, { ...full, ...over }).exceptions.some(e => e.id === id), `${c}: ${id} clears when ${Object.keys(over).join(', ')} is corrected`);
  clear({ viuYearsJustification: 'Ten-year concession with contracted volumes; five-year back-test within 3%' }, 'EX-IMP-02');
  clear({ viuBenchmark: 5 }, 'EX-IMP-03');
  clear({ viuRateBasis: 'Pre-tax' }, 'EX-IMP-04');
  clear({ declTax: 'N' }, 'EX-IMP-05'); clear({ declFinancing: 'N' }, 'EX-IMP-06'); clear({ declExpansion: 'N' }, 'EX-IMP-07'); clear({ declRisk: 'N' }, 'EX-IMP-08');
  const pFive = pipeline(f, eng, { ...full, viuYears: 5 });
  t.ok(pFive.derived.viu.N === 5 && !pFive.exceptions.some(e => e.id === 'EX-IMP-02') && pFive.derived.viu.viu < V.viu, `${c}: a five-year period drops EX-IMP-02 and lowers value in use (${money(pFive.derived.viu.viu)})`);
  const pTamper = pipeline(f, eng, { ...full, clientVIU: cl.viu + 25000 });
  t.ok(pTamper.exceptions.some(e => e.id === 'EX-IMP-21' && Math.abs(e.difference - 25000) < 5), `${c}: an overstated client value in use is caught by EX-IMP-21`);

  /* allocation */
  /* a loss equal to goodwill plus 200,000 so that every client's case reaches the pro rata stage */
  const LOSS = Math.round(mfg.goodwill + 200000);
  const pAlloc = pipeline(f, eng, { ...full, allocLoss: LOSS });
  const A = pAlloc.derived.alloc, gwRow = A.rows.find(r => r.key === 'goodwill');
  t.ok(Math.abs(A.goodwillFirst - mfg.goodwill) < 0.01 && gwRow.after === 0, `${c}: loss of ${money(LOSS)} goes to goodwill first (${money(mfg.goodwill)})`);
  t.ok(Math.abs(A.allocated - LOSS) < 0.01 && A.unallocated === 0, `${c}: remainder allocated pro rata, nothing unallocated`);
  const rem = LOSS - mfg.goodwill, base = mfg.ppe + mfg.rou + mfg.intang_finite + Math.max(0, mfg.other);
  t.ok(Math.abs(A.rows.find(r => r.key === 'ppe').alloc - rem * mfg.ppe / base) < 0.05, `${c}: PPE share is pro rata to carrying amount`);
  const pFloor = pipeline(f, eng, { ...full, allocLoss: LOSS, 'floor:ppe': mfg.ppe });
  const AF = pFloor.derived.alloc;
  t.ok(AF.rows.find(r => r.key === 'ppe').alloc === 0 && AF.rows.find(r => r.key === 'ppe').floorApplied && Math.abs(AF.allocated - LOSS) < 0.01, `${c}: para 105 floor on PPE redistributes its share to the other assets`);
  const capacity = mfg.ppe + mfg.rou + mfg.intang_finite + mfg.intang_indef + mfg.goodwill + Math.max(0, mfg.other);
  const pBig = pipeline(f, eng, { ...full, allocLoss: capacity + 100000 });
  t.ok(Math.abs(pBig.derived.alloc.unallocated - 100000) < 0.01, `${c}: a loss beyond the CGU's assets leaves the excess unallocated (para 105)`);
  const pGwOnly = pipeline(f, eng, { ...full, allocLoss: 1000 });
  t.ok(pGwOnly.derived.alloc.goodwillFirst === 1000 && pGwOnly.derived.alloc.rows.filter(r => r.key !== 'goodwill').every(r => r.alloc === 0), `${c}: a small loss is absorbed entirely by goodwill`);
  t.ok(d.alloc.loss === 0 && d.alloc.lossComputed === 0 && !p.exceptions.some(e => e.id === 'EX-IMP-22'), `${c}: no loss on the recalculated model; client's nil charge agrees`);
  t.ok(pipeline(f, eng, { ...full, impairmentPerClient: 50000 }).exceptions.some(e => e.id === 'EX-IMP-22' && e.difference === 50000), `${c}: EX-IMP-22 when the charge recognised differs from the amount per audit`);

  /* planted */
  const planted = expectedExceptions('Impairment FRS 36', c).map(x => x.exception.slice(0, 9));
  const got = new Set(p.exceptions.map(e => e.id));
  t.ok(planted.length === 11 && planted.every(id => got.has(id)), `${c}: all eleven planted exceptions raised`, planted.filter(id => !got.has(id)).join(', '));

  p.renderAll(t, c);
  const wb = p.exportCheck(t, c);
  const cells = ws => Object.values(ws).filter(x => x && typeof x === 'object' && 'v' in x).map(x => x.v);
  t.ok(cells(wb.Sheets['IMP-03 Value in use model']).includes(cl.cf[0]), `${c}: IMP-03 export carries the cash flows entered`);
  const sensSheet = wb.SheetNames.find(n => /^IMP-06/.test(n));
  t.ok(sensSheet && cells(wb.Sheets[sensSheet]).some(v => /Within band/.test(String(v))), `${c}: IMP-06 export ("${sensSheet}") shows the disclosure conclusion`);
  const out = path.join(__dirname, 'out-IMP-file.xlsx');
  L.XLSX.writeFile(wb, out);
  t.ok(L.XLSX.readFile(out).SheetNames.length === wb.SheetNames.length, `${c}: workbook survives the Excel round-trip`);
  fs.unlinkSync(out);
}

/* an empty model must not throw anywhere */
console.log('\n=== IMP — empty model (client-d, no auditor inputs) ===');
{
  const eng = engagement(Core, '2025-09-30', 145000);
  const p0 = pipeline(path.join(OUT, 'client-d', CLIENTS[2].file), eng, {});
  t.ok(!p0.derived.viu.ready && !p0.derived.sens.ready && p0.exceptions.map(e => e.id).sort().join(',') === 'EX-IMP-01', 'with no inputs only the register-driven EX-IMP-01 is raised');
  t.ok(p0.derived.viu.cgu === 'Specialty coatings business', 'default modelled CGU is the one with the largest goodwill');
  p0.renderAll(t, 'empty');
}

t.done();
