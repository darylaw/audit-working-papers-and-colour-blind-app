/* Headless test of the OR (other receivables, deposits and prepayments) audit file
   against the synthetic prepayment schedules.   Run:  node test/test-or.js          */
const { load, counter, money, engagement, pipeline, expectedExceptions, OUT, path, fs } = require('./spec-lib');
const L = load(['or.js']);
const t = counter();
const CODE = 'OR';

const CLIENTS = [
  { c: 'client-a', ye: '2025-02-28', file: 'PBC-PRE-01 Prepayments schedule 2025-02-28.xlsx' },
  { c: 'client-b', ye: '2025-09-30', file: 'PBC-PRE-01 Prepayments schedule 2025-09-30.xlsx' },
  { c: 'client-d', ye: '2025-09-30', file: 'PBC-PRE-01 Prepayments schedule 2025-09-30.xlsx' }
];

console.log('\n=== OR — module registration ===');
t.ok(L.Modules.byCode.OR && /Prepayments/.test(L.Modules.byCode.OR.name), 'OR registered via Modules.register');
t.ok(L.Modules.byCode.OR.pages.filter(p => p.render).length === 5, 'five rendered working papers (L4, L4.1–L4.4)');
t.ok(L.Modules.byCode.OR.pages[L.Modules.byCode.OR.pages.length - 1].kind === 'conclusion', 'conclusion page last');

for (const { c, ye, file: f } of CLIENTS) {
  const eng = engagement(L.Core, ye, 145000);
  const file = path.join(OUT, c, f);
  if (!fs.existsSync(file)) { console.log('  skip (missing) ' + f); continue; }
  const label = c;
  console.log(`\n=== ${label} / ${f} ===`);
  const p = pipeline(L, file, CODE, eng);
  const d = p.derived;
  console.log(`  header row ${p.headerRow + 1}; ${p.records.length} lines; total ${money(d.total)}; prepayments ${d.amort.count}; recalculated ${money(d.amort.expClosing)} vs ${money(d.amort.closingCovered)}; under ${d.amort.under.length}, expired ${d.amort.expired.length}, negative ${d.amort.negative.length}`);
  t.ok(p.missingRequired().length === 0, `${label}: required fields mapped`, p.missingRequired().join(', '));
  ['amount_paid', 'period_from', 'period_to', 'expensed', 'months'].forEach(k => t.ok(p.mapping[k], `${label}: ${k} mapped (${p.mapping[k]?.heading})`));
  t.ok(p.records.length === 8, `${label}: eight schedule lines (subtotal row held out)`, p.records.length);
  t.ok(Math.abs(d.total - p.records.reduce((s, r) => s + (r.closing || 0), 0)) < 0.005, `${label}: lead total casts to the sum of the lines`);
  t.ok(p.records.every(r => r.__nature === 'Prepayments'), `${label}: every line with coverage dates classified as a prepayment`, p.records.map(r => r.__nature).join(','));
  t.ok(d.lead.find(l => l.nature === 'Prepayments').count === 8, `${label}: lead by nature shows 8 prepayments`);
  t.ok(d.amort.rows.filter(r => r.__expClosing != null).every(r => r.__expClosing >= -0.01 && r.__expClosing <= (r.amount_paid || 0) + 0.01), `${label}: recalculated balance lies between nil and cost for every line`);
  t.ok(d.amort.rows.every(r => r.__periodInvalid || (r.__expCharge != null && r.__expCharge >= -0.01)), `${label}: charge per audit computed for every valid coverage period`);

  /* planted exceptions */
  const planted = expectedExceptions('Prepayments', c);
  for (const x of planted) {
    const id = x.exception.split(' ')[0];
    const hit = p.exceptions.find(e => e.id === id && e.recordKey === x.record_key);
    t.ok(hit, `${label}: ${x.exception} → ${x.record_key}`, JSON.stringify(p.exceptions.filter(e => e.id === id).map(e => e.recordKey)));
  }
  const clean = ['Insurance - work injury', 'Property tax', 'Trade subscription', 'Rental deposit amortisation', 'Advertising retainer'];
  const falsePos = p.exceptions.filter(e => ['EX-PRE-01', 'EX-PRE-02', 'EX-PRE-03', 'EX-PRE-04'].includes(e.id) && clean.includes(e.recordKey));
  t.ok(falsePos.length === 0, `${label}: no amortisation exception on the clean lines`, JSON.stringify(falsePos.map(e => [e.id, e.recordKey, e.difference])));
  const e01 = p.exceptions.find(e => e.id === 'EX-PRE-01' && e.recordKey === 'Insurance - general');
  t.ok(e01 && e01.difference > 0 && e01.expected != null && e01.actual != null, `${label}: EX-PRE-01 carries client figure, audit figure and difference`, e01 && JSON.stringify([e01.expected, e01.actual, e01.difference]));
  const e03 = p.exceptions.find(e => e.id === 'EX-PRE-03');
  t.ok(e03 && e03.severity === 'above-trivial' && e03.actual < 0, `${label}: EX-PRE-03 negative balance at above-trivial`);
  const e06 = p.exceptions.filter(e => e.id === 'EX-PRE-06');
  t.ok(e06.every(e => Math.abs(e.difference) > 0.01), `${label}: cast check only fires on a real difference (${e06.length} lines)`);

  /* monthly basis still catches the planted items */
  const pm = pipeline(L, file, CODE, eng, { amortBasis: 'monthly' });
  t.ok(pm.exceptions.some(e => e.id === 'EX-PRE-01' && e.recordKey === 'Insurance - general') && pm.exceptions.some(e => e.id === 'EX-PRE-02' && e.recordKey === 'Software subscription'), `${label}: monthly basis also detects the planted items`);

  /* TB tie by nature and in total */
  const pTB = pipeline(L, file, CODE, eng, { 'tb:prepayments': d.total - 100 });
  const e20 = pTB.exceptions.filter(e => e.id === 'EX-PRE-20');
  t.ok(e20.length === 1 && e20[0].recordKey === 'Prepayments' && Math.abs(e20[0].difference - 100) < 0.005, `${label}: EX-PRE-20 by nature fires with the right difference`, JSON.stringify(e20));
  const pTB2 = pipeline(L, file, CODE, eng, { 'tb:prepayments': d.total });
  t.ok(!pTB2.exceptions.some(e => e.id === 'EX-PRE-20'), `${label}: EX-PRE-20 silent when the TB agrees`);
  const pTB3 = pipeline(L, file, CODE, eng, { tbTotal: d.total + 55 });
  t.ok(pTB3.exceptions.some(e => e.id === 'EX-PRE-20' && Math.abs(e.difference + 55) < 0.005), `${label}: EX-PRE-20 falls back to the total TB figure`);

  /* classification */
  t.ok(d.classif.nonCurrent > 0 && d.classif.rows.some(r => r.__remainingDays > 365 && r.__nonCurrent > 0), `${label}: non-current portion computed for multi-year prepayments (${money(d.classif.nonCurrent)})`);
  t.ok(Math.abs(d.classif.current + d.classif.nonCurrent - d.amort.rows.filter(r => r.__expClosing != null).reduce((s, r) => s + r.__expClosing, 0) - d.amort.rows.filter(r => r.__expClosing == null).reduce((s, r) => s + (r.closing || 0), 0)) < 0.05, `${label}: current + non-current casts to the balance per audit`);

  p.renderAll(t, label);
  p.exportCheck(t, label);
}

/* ---------------------------------------------------------------------- */
console.log('\n=== OR — auditor inputs, overrides and injected other receivables (client-a) ===');
{
  const eng = engagement(L.Core, '2025-02-28', 145000);
  const file = path.join(OUT, 'client-a', 'PBC-PRE-01 Prepayments schedule 2025-02-28.xlsx');

  /* nature override → deposits page; refundable N → EX-PRE-09 */
  const pDep = pipeline(L, file, CODE, eng, {}, recs => { const r = recs.find(x => /Rental deposit/.test(x.description)); r.__wp = { lead: { nature: 'Deposits' }, deposits: { refundable: 'N', doc: 'Y' } }; });
  t.ok(pDep.derived.deposits.rows.length === 1 && pDep.derived.deposits.rows[0].description === 'Rental deposit amortisation', 'nature override moves the line to L4.2 deposits');
  t.ok(pDep.derived.lead.find(l => l.nature === 'Deposits').count === 1 && pDep.derived.lead.find(l => l.nature === 'Prepayments').count === 7, 'lead by nature follows the override');
  t.ok(pDep.exceptions.some(e => e.id === 'EX-PRE-09' && /Rental deposit/.test(e.recordKey)), 'EX-PRE-09 non-refundable deposit raised from the auditor input');
  t.ok(pDep.derived.deposits.vouched === 1, 'deposits vouched count reflects the input');

  /* injected other receivable: long outstanding, then recovered, then provided */
  const inject = recs => recs.push({ __srcRow: 999, __i: recs.length, __flags: [], description: 'GST receivable', counterparty: 'Tax authority', nature: null, account: null,
    amount_paid: null, period_from: null, period_to: null, months: null, opening: null, expensed: null, closing: 30000, date: new Date(Date.UTC(2023, 5, 30)), due_date: null, refundable: null });
  const pOR = pipeline(L, file, CODE, eng, {}, inject);
  const o = pOR.records.find(r => r.description === 'GST receivable');
  t.ok(o.__nature === 'Other receivables' && pOR.derived.recov.rows.length === 1, 'injected line classified as other receivable and listed on L4.3');
  t.ok(o.__age > 365 && o.__longOut, `injected line aged ${o.__age} days and flagged long outstanding`);
  const e08 = pOR.exceptions.find(e => e.id === 'EX-PRE-08');
  t.ok(e08 && e08.recordKey === 'GST receivable' && Math.abs(e08.difference - 30000) < 0.005, 'EX-PRE-08 unprovided exposure raised', e08 && JSON.stringify(e08));
  const pRec = pipeline(L, file, CODE, eng, {}, recs => { inject(recs); recs[recs.length - 1].__wp = { recov: { receipt: 30000, receiptDate: '15/03/2025' } }; });
  t.ok(!pRec.exceptions.some(e => e.id === 'EX-PRE-08') && pRec.derived.recov.coverage === 100, 'EX-PRE-08 clears when the balance is received after the year end');
  const pProv = pipeline(L, file, CODE, eng, {}, recs => { inject(recs); recs[recs.length - 1].__wp = { recov: { receipt: 5000, provision: 25000 } }; });
  t.ok(!pProv.exceptions.some(e => e.id === 'EX-PRE-08') && pProv.derived.recov.provided === 25000, 'EX-PRE-08 clears when the shortfall is fully provided');
  const pPart = pipeline(L, file, CODE, eng, {}, recs => { inject(recs); recs[recs.length - 1].__wp = { recov: { receipt: 5000, provision: 10000 } }; });
  const e08b = pPart.exceptions.find(e => e.id === 'EX-PRE-08');
  t.ok(e08b && Math.abs(e08b.difference - 15000) < 0.005, 'EX-PRE-08 exposure = balance − receipt − provision', e08b && e08b.difference);

  /* staff advance classification */
  const pStaff = pipeline(L, file, CODE, eng, {}, recs => recs.push({ __srcRow: 998, __i: recs.length, __flags: [], description: 'Advance to staff — travel', closing: 1200, date: new Date(Date.UTC(2025, 1, 10)) }));
  t.ok(pStaff.records.find(r => r.__srcRow === 998).__nature === 'Staff advances' && pStaff.derived.recov.staff.length === 1, 'staff advance recognised by description');

  /* classification inputs with a lower materiality so the non-current test bites */
  const engSmall = engagement(L.Core, '2025-02-28', 20000);
  const pC = pipeline(L, file, CODE, engSmall);
  const e07 = pC.exceptions.filter(e => e.id === 'EX-PRE-07');
  t.ok(e07.some(e => e.recordKey === 'Maintenance contract') && e07.some(e => e.recordKey === 'Rental deposit amortisation'), 'EX-PRE-07 non-current portion raised for the 24- and 36-month prepayments', JSON.stringify(e07.map(e => e.recordKey)));
  const pC2 = pipeline(L, file, CODE, engSmall, {}, recs => recs.filter(r => /Maintenance|Rental deposit/.test(r.description)).forEach(r => r.__wp = { classif: { clientClass: 'Non-current' } }));
  t.ok(!pC2.exceptions.some(e => e.id === 'EX-PRE-07'), 'EX-PRE-07 clears once the client classification is recorded as non-current');
  const pC3 = pipeline(L, file, CODE, engSmall, {}, recs => recs.filter(r => /Maintenance/.test(r.description)).forEach(r => r.__wp = { classif: { clientClass: 'Current' } }));
  t.ok(pC3.derived.classif.mismatched.length === 1, 'a client classification of current against a non-current portion is listed as a mismatch');

  /* amortisation tolerance control */
  const pTol = pipeline(L, file, CODE, eng, { amortTol: 1000000 });
  t.ok(!pTol.exceptions.some(e => e.id === 'EX-PRE-01' || e.id === 'EX-PRE-04'), 'a very wide tolerance silences the under/over-amortised tests (EX-PRE-02/03 unaffected: ' + pTol.exceptions.filter(e => e.id === 'EX-PRE-03').length + ')');
  t.ok(pTol.exceptions.some(e => e.id === 'EX-PRE-03'), 'negative balance still raised regardless of tolerance');

  /* export carries inputs; conclusion helper */
  const wb = pDep.exportCheck(t, 'client-a with inputs');
  const ws = wb.Sheets['L4.2 Deposits vouching'];
  t.ok(ws && Object.values(ws).some(c => c && c.v === 'Rental deposit amortisation'), 'L4.2 export carries the overridden deposit line');
  const out = path.join(__dirname, 'out-OR-file.xlsx');
  L.XLSX.writeFile(wb, out);
  const re = L.XLSX.readFile(out);
  t.ok(re.SheetNames.length === wb.SheetNames.length, 'workbook survives the Excel round-trip');
  fs.unlinkSync(out);
  const st = pDep.state().modules.OR;
  const text = L.Modules.byCode.OR.suggestConclusion(st, pDep.ctx());
  t.ok(typeof text === 'string' && text.length > 100, 'suggestConclusion produces text');
}

t.done();
