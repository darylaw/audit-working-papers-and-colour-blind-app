/* Headless test of the PLAN (Planning & Materiality) audit file against the synthetic trial balances.
   Run:  node test/test-plan.js                                                                    */
const { load, counter, money, engagement, pipeline, OUT, path, fs } = require('./spec-lib');
const L = load(['plan.js']);
const t = counter();
const CODE = 'PLAN';
const r2 = n => Math.round(n * 100) / 100;

const CLIENTS = [
  { c: 'client-a', ye: '2025-02-28', file: 'PBC-TB-01 Trial balance 2025-02-28.xlsx', py: true,  single: true  },
  { c: 'client-b', ye: '2025-09-30', file: 'PBC-TB-01 Trial balance 2025-09-30.xlsx', py: false, single: false },
  { c: 'client-d', ye: '2025-09-30', file: 'PBC-TB-01 Trial balance 2025-09-30.xlsx', py: true,  single: true  }
];

console.log('\n=== PLAN — module registration ===');
const M = L.Modules.byCode.PLAN;
t.ok(M && M.name === 'Planning & Materiality', 'PLAN registered via Modules.register');
t.ok(M.pages.filter(p => p.render).length === 5, 'five rendered working papers (A, A1–A4)');
t.ok(M.pages[M.pages.length - 1].kind === 'conclusion', 'conclusion page last');

/* The same synthetic entity is laid out three ways; every client must yield identical benchmark figures. */
const EXPECT = { turnover: 4805984, pbt: -1250650, cos: 3915690, finance: 39121, cash: 861930, tradeRec: 2787720, ca: 5276535 };
const OM = 144179.52, PM = 108134.64, TRIV = 7208.98;   // turnover 4,805,984 × 3% (sliding scale below 5m) × 75% / 5%

for (const { c, ye, file, py, single } of CLIENTS) {
  const eng = engagement(L.Core, ye, 145000);
  const f = path.join(OUT, c, file);
  const label = c;
  console.log(`\n=== ${label} / ${file} ===`);
  const p = pipeline(L, f, CODE, eng);
  const d = p.derived, m = d.mat;
  console.log(`  header row ${p.headerRow + 1}; ${p.records.length} accounts; Dr ${money(d.debit)} Cr ${money(d.credit)} net ${money(d.net)}; out of balance ${money(d.outOfBalance)}`);
  console.log(`  benchmark ${m.benchKey} ${money(m.tbValue)} × ${m.rate}% → OM ${money(m.om)} PM ${money(m.pm)} trivial ${money(m.trivial)}; PY ${d.hasPY}; flagged ${d.flagged}`);

  /* mapping */
  t.ok(p.missingRequired().length === 0, `${label}: required fields mapped`, p.missingRequired().join(', '));
  t.ok(p.records.length === 83, `${label}: 83 accounts read (subtotal, footnote and title rows held out)`, p.records.length);
  if (single) t.ok(p.mapping.balance && !p.mapping.debit, `${label}: single signed column mapped to balance, not debit (${p.mapping.balance?.heading})`);
  else t.ok(p.mapping.debit && p.mapping.credit && !p.mapping.balance, `${label}: Dr and Cr columns mapped (${p.mapping.debit?.heading} / ${p.mapping.credit?.heading})`);
  t.ok(!!p.mapping.balance_py === py, `${label}: prior year column ${py ? 'mapped' : 'absent'}`);
  t.ok(d.hasPY === py, `${label}: hasPY reflects the mapping`);

  /* the trial balance itself */
  t.ok(Math.abs(d.outOfBalance) < 0.2, `${label}: trial balance nets to within rounding (${money(d.outOfBalance)})`);
  const e03 = p.exceptions.find(e => e.id === 'EX-PLAN-03');
  t.ok(!!e03 === (Math.abs(d.outOfBalance) > 0.01), `${label}: EX-PLAN-03 ${e03 ? 'raised' : 'silent'} consistently with the out-of-balance figure`);
  if (e03) {
    const pTol = pipeline(L, f, CODE, eng, { castTol: 0.5 });
    t.ok(!pTol.exceptions.some(e => e.id === 'EX-PLAN-03'), `${label}: raising the casting tolerance silences EX-PLAN-03`);
  }

  /* classification into standard captions */
  t.ok(Math.abs(d.cy.turnover - EXPECT.turnover) < 0.5, `${label}: turnover from the revenue captions = ${money(EXPECT.turnover)}`, d.cy.turnover);
  t.ok(Math.abs(d.cy.pbt - EXPECT.pbt) < 0.5, `${label}: profit before tax = ${money(EXPECT.pbt)}`, d.cy.pbt);
  t.ok(Math.abs(d.cy.cos - EXPECT.cos) < 0.5, `${label}: cost of sales = ${money(EXPECT.cos)}`, d.cy.cos);
  t.ok(Math.abs(d.cy.finance - EXPECT.finance) < 0.5, `${label}: finance costs = ${money(EXPECT.finance)}`, d.cy.finance);
  const cashCap = d.byCaption.find(x => x.key === 'cash');
  t.ok(cashCap && Math.abs(cashCap.cy - EXPECT.cash) < 0.5, `${label}: four cash accounts (incl. fixed deposit) classify to cash = ${money(EXPECT.cash)}`, cashCap && cashCap.cy);
  t.ok(Math.abs(d.cy.trade_rec - EXPECT.tradeRec) < 0.5, `${label}: trade receivables net of ECL allowance = ${money(EXPECT.tradeRec)}`, d.cy.trade_rec);
  t.ok(Math.abs(d.cy.ca - EXPECT.ca) < 0.5, `${label}: current assets = ${money(EXPECT.ca)}`, d.cy.ca);
  t.ok(p.records.every(r => r.__captionKey && r.__captionLabel && ['BS', 'PL'].includes(r.__section)), `${label}: every account carries a caption and a section`);
  t.ok(d.cy.totalAssets > d.cy.totalLiabilities && d.cy.netAssets > 0, `${label}: total assets exceed total liabilities`);

  /* materiality */
  t.ok(m.suggested === 'turnover' && m.benchKey === 'turnover', `${label}: loss-making entity → turnover suggested, not profit before tax`);
  t.ok(m.rate === 3 && m.defRate === 3, `${label}: sliding scale gives 3% below 5m turnover`);
  t.ok(Math.abs(m.om - OM) < 0.01 && Math.abs(m.pm - PM) < 0.01 && Math.abs(m.trivial - TRIV) < 0.01, `${label}: OM/PM/trivial = ${money(OM)} / ${money(PM)} / ${money(TRIV)}`, `${m.om} ${m.pm} ${m.trivial}`);
  t.ok(m.rateInBand && !p.exceptions.some(e => e.id === 'EX-PLAN-01'), `${label}: default rate within band; EX-PLAN-01 silent`);
  t.ok(m.engOM === 145000 && m.labels[0] === 'Overall materiality', `${label}: engagement settings figure carried for the reconciliation note`);

  /* analytics */
  if (py) {
    t.ok(d.flagged > 0 && d.unexplained === d.flagged, `${label}: ${d.flagged} variances flagged, all unexplained until the auditor records explanations`);
    const e05 = p.exceptions.filter(e => e.id === 'EX-PLAN-05');
    t.ok(e05.length === d.flagged && e05.every(e => e.severity === 'informational'), `${label}: EX-PLAN-05 raised once per flagged account (${e05.length}), informational`);
    t.ok(p.records.filter(r => r.__flagged).every(r => Math.abs(r.__variance) > PM && Math.abs(r.__variancePct) > 0.10), `${label}: flag rule = variance > PM and > 10%`);
    const pEx = pipeline(L, f, CODE, eng, {}, recs => recs.forEach(r => { r.__wp = { analytics: { explanation: 'Agreed to management analysis' } }; }));
    t.ok(pEx.derived.unexplained === 0 && !pEx.exceptions.some(e => e.id === 'EX-PLAN-05'), `${label}: explanations entered on A1 clear EX-PLAN-05`);
    t.ok(d.ratios.every(r => r.py != null || r.cy == null), `${label}: prior year ratios computed`);
  } else {
    t.ok(d.flagged === 0 && !p.exceptions.some(e => e.id === 'EX-PLAN-05'), `${label}: no prior year → nothing flagged`);
    t.ok(d.ratios.every(r => r.py == null && r.movement == null), `${label}: prior year ratios blank without a comparative`);
  }
  const gp = d.ratios.find(r => r.id === 'gp'), cr = d.ratios.find(r => r.id === 'cr');
  t.ok(Math.abs(gp.cy - r2((EXPECT.turnover - EXPECT.cos) / EXPECT.turnover * 100)) < 0.01, `${label}: gross margin ${gp.cy}% recomputes from revenue and cost of sales`);
  t.ok(Math.abs(cr.cy - r2(d.cy.ca / d.cy.cl)) < 0.01, `${label}: current ratio ${cr.cy}x = current assets ÷ current liabilities`);

  /* risk and sampling */
  const ov = d.risks.find(x => x.id === 'override'), rev = d.risks.find(x => x.id === 'revenue');
  t.ok(ov.effSig === 'Y' && rev.effFraud === 'Y' && !p.exceptions.some(e => e.id === 'EX-PLAN-04'), `${label}: ISA 240 positions applied by default (override significant, revenue fraud presumed)`);
  t.ok(Math.abs(d.te - r2(m.om / 1.333)) < 0.01, `${label}: tolerable error = OM ÷ 1.333 = ${money(d.te)}`);
  t.ok(d.sampling.length > 0 && d.sampling.every(s => s.population >= PM - 0.01 && s.key !== 'equity'), `${label}: sampling table lists captions at or above PM, excluding equity (${d.sampling.length})`);
  t.ok(d.sampling.every(s => s.sampleSize === Math.ceil(s.residual / d.te * 1.8)), `${label}: sample size = residual ÷ TE × 1.8`);
  t.ok(d.sampling.every((s, i, a) => i === 0 || a[i - 1].population >= s.population), `${label}: sampling table sorted by population`);

  p.renderAll(t, label);
  p.exportCheck(t, label);
}

/* ---------------------------------------------------------------------- */
console.log('\n=== PLAN — auditor inputs drive the tests (client-a) ===');
{
  const eng = engagement(L.Core, '2025-02-28', 145000);
  const f = path.join(OUT, 'client-a', 'PBC-TB-01 Trial balance 2025-02-28.xlsx');

  /* A materiality: rate outside band, benchmark override, entity type */
  const pRate = pipeline(L, f, CODE, eng, { rate: 5 });
  const e01 = pRate.exceptions.find(e => e.id === 'EX-PLAN-01');
  t.ok(e01 && !pRate.derived.mat.rateInBand && Math.abs(pRate.derived.mat.om - r2(EXPECT.turnover * 0.05)) < 0.01, 'EX-PLAN-01 raised when the rate leaves the 1%–3% turnover band; OM recomputes at 5%');
  const pBench = pipeline(L, f, CODE, eng, { benchmark: 'totalAssets' });
  t.ok(pBench.derived.mat.benchKey === 'totalAssets' && pBench.derived.mat.rate === 2 && pBench.derived.mat.typeMismatch, 'Benchmark override → total assets at the 2% default, flagged as not suited to a trading entity');
  const pAsset = pipeline(L, f, CODE, eng, { entityType: 'Asset-based' });
  t.ok(pAsset.derived.mat.suggested === 'totalAssets' && !pAsset.derived.mat.typeMismatch, 'Asset-based entity → total assets suggested');
  const pOv = pipeline(L, f, CODE, eng, { benchmarkOverride: 6000000 });
  t.ok(Math.abs(pOv.derived.mat.benchValue - 6000000) < 0.01 && pOv.derived.mat.rate === 2.6 && Math.abs(pOv.derived.mat.om - 156000) < 0.01, 'Benchmark amount override re-derives the sliding rate (6m → 2.6%) and OM', `${pOv.derived.mat.rate} ${pOv.derived.mat.om}`);
  const pPY = pipeline(L, f, CODE, eng, { pyOM: 120000 });
  t.ok(Math.abs(pPY.derived.mat.omChangePct - r2((OM - 120000) / 120000 * 100)) < 0.01, 'Prior year OM comparison computes the change %');

  /* component materiality */
  const pComp = pipeline(L, f, CODE, eng, { componentRows: 3, 'component:1': 'Subsidiary A', 'compAlloc:1': 90000, 'component:2': 'Subsidiary B', 'compAlloc:2': 150000 });
  const e02 = pComp.exceptions.filter(e => e.id === 'EX-PLAN-02');
  t.ok(pComp.derived.components.length === 2 && e02.length === 1 && e02[0].recordKey === 'Subsidiary B' && Math.abs(e02[0].difference - (150000 - OM)) < 0.01, 'EX-PLAN-02 raised only for the component allocated above group materiality');
  t.ok(Math.abs(pComp.derived.compAggregate - 240000) < 0.01, 'Aggregate allocated materiality cast');

  /* A2 risk */
  const pReb = pipeline(L, f, CODE, eng, { 'fraud:revenue': 'N' });
  t.ok(pReb.exceptions.some(e => e.id === 'EX-PLAN-04') && pReb.derived.risks.find(x => x.id === 'revenue').rebuttedNoReason, 'EX-PLAN-04 raised when the revenue fraud presumption is rebutted with no reason');
  const pReb2 = pipeline(L, f, CODE, eng, { 'fraud:revenue': 'N', 'rebuttal:revenue': 'Single product, cash sales recognised on delivery; no estimation.' });
  t.ok(!pReb2.exceptions.some(e => e.id === 'EX-PLAN-04'), 'EX-PLAN-04 clears once the reason is documented');
  const pSig = pipeline(L, f, CODE, eng, { 'significant:inventory': 'Y', 'inherent:inventory': 'High' });
  t.ok(pSig.derived.risks.filter(x => x.effSig === 'Y').length === 3 && pSig.derived.risks.filter(x => x.inherent === 'High').length === 1, 'Significant and inherent risk inputs flow to the summary counts');

  /* A3 sampling: stratification inputs reduce the residual */
  const base = pipeline(L, f, CODE, eng);
  const rev = base.derived.sampling.find(s => s.key === 'revenue');
  const pStrat = pipeline(L, f, CODE, eng, { 'aboveTE:revenue': 1000000, 'byNature:revenue': 200000 });
  const rev2 = pStrat.derived.sampling.find(s => s.key === 'revenue');
  t.ok(Math.abs(rev2.residual - (rev.population - 1200000)) < 0.01 && rev2.sampleSize < rev.sampleSize && Math.abs(rev2.coverage - r2(1200000 / rev.population * 100)) < 0.01, `Items tested in full reduce the residual (${rev.sampleSize} → ${rev2.sampleSize}) and set coverage`);
  const pRF = pipeline(L, f, CODE, eng, { riskFactor: '1.2' });
  t.ok(pRF.derived.sampling.every(s => s.sampleSize === Math.ceil(s.residual / pRF.derived.te * 1.2)), 'Risk factor 1.2 flows to every sample size');

  /* A1 ratio overrides and caption override */
  const pRat = pipeline(L, f, CODE, eng, { 'ovCY:revenue': 5000000 });
  const gp2 = pRat.derived.ratios.find(r => r.id === 'gp');
  t.ok(Math.abs(gp2.cy - r2((5000000 - EXPECT.cos) / 5000000 * 100)) < 0.01 && pRat.derived.ratioInputs.find(x => x.key === 'revenue').overridden, 'Ratio input override re-derives gross margin');
  const fd = base.records.find(r => /fixed deposit/i.test(r.name));
  const pCap = pipeline(L, f, CODE, eng, {}, recs => { const r = recs.find(x => x.__srcRow === fd.__srcRow); r.__wp = { analytics: { captionOverride: 'Investments' } }; });
  const cashAfter = pCap.derived.byCaption.find(x => x.key === 'cash');
  t.ok(pCap.records.find(x => x.__srcRow === fd.__srcRow).__captionKey === 'investments' && Math.abs(cashAfter.cy - (EXPECT.cash - 250000)) < 0.01, 'Caption override moves the fixed deposit out of cash and the benchmarks re-derive');

  /* export carries the auditor inputs */
  const pAll = pipeline(L, f, CODE, eng, { componentRows: 1, 'component:1': 'Subsidiary A', 'compAlloc:1': 90000, 'response:revenue': 'Cut-off testing and price-volume analytics' });
  const wb = pAll.exportCheck(t, 'client-a with inputs');
  const cells = ws => Object.values(ws).filter(c => c && typeof c === 'object' && 'v' in c).map(c => c.v);
  t.ok(cells(wb.Sheets['A Materiality']).includes('Subsidiary A'), 'A export carries the component entered');
  t.ok(cells(wb.Sheets['A2 Risk assessment summary']).includes('Cut-off testing and price-volume analytics'), 'A2 export carries the planned response');
  const out = path.join(__dirname, 'out-PLAN-file.xlsx');
  L.XLSX.writeFile(wb, out);
  const re = L.XLSX.readFile(out);
  t.ok(re.SheetNames.length === wb.SheetNames.length, 'workbook survives the Excel round-trip');
  fs.unlinkSync(out);
}

t.done();
