const S = require('./spec-lib.js'), vm = require('vm'), crypto = require('crypto');
const { fs, path } = S, t = S.counter();
const marker = 'FICTITIOUS_PRIVATE_RECORD_9371';
const ui = fs.readFileSync(path.join(S.APP, 'src/ui.js'), 'utf8');
const peers = [], writes = [];
const storage = () => {
  const map = new Map();
  return { map, get length() { return map.size; }, key:i => [...map.keys()][i], getItem:k => map.get(k) ?? null,
    setItem(k,v) { writes.push([k,v]); map.set(k,String(v)); }, removeItem:k => map.delete(k) };
};
const local = storage(), session = storage();
function fixture(scope = 'fictitious-account') {
  const L = S.load(['imp.js','gc.js']), events = {}, readers = [], timers = new Map();
  class Node {
    constructor(tag) { this.tagName = tag.toUpperCase(); this.children = []; this.attributes = {}; this.events = {}; this.dataset = {}; }
    append(...kids) { this.children.push(...kids); }
    replaceChildren(...kids) { this.children = kids; }
    setAttribute(k,v) { this.attributes[k] = String(v); }
    addEventListener(k,fn) { this.events[k] = fn; }
    querySelector() { return null; }
    remove() { this.children = []; }
    set innerHTML(v) { throw Error('HTML sink reached'); }
    set textContent(v) { this.children = [String(v)]; }
    get textContent() { return this.children.map(c => typeof c === 'string' ? c : c.textContent).join(''); }
  }
  const root = new Node('div'), body = new Node('body');
  const window = { localStorage:local, sessionStorage:session, addEventListener:(k,fn) => events[k] = fn, location:{ reload() {} } };
  window.top = window;
  Object.assign(L.ctx, { window, localStorage:local, sessionStorage:session,
    setTimeout:fn => { const id = timers.size + 1; timers.set(id,fn); return id; }, clearTimeout:id => timers.delete(id),
    document:{ body, createElement:tag => new Node(tag), querySelector:s => s === '#root' ? root : s.startsWith('meta') && scope ? {content:scope} : null,
      querySelectorAll:() => [], addEventListener() {} }, Templates:{card:() => null},
    BroadcastChannel:class { constructor() { peers.push(this); } postMessage(data) { for (const p of peers) if (p !== this) p.onmessage?.({data}); } },
    FileReader:class { constructor() { readers.push(this); } readAsArrayBuffer() { this.readyState = 1; } abort() { this.readyState = 2; this.aborted = true; } }
  });
  vm.runInContext(ui.replace('return { init, get state()', 'globalThis.probe = {save,load,linkTB,endSession,loadFile}; return { init, get state()') + '\n;globalThis.App = App;', L.ctx);
  return { ...L, events, readers, timers, root, body, Node, app:L.ctx.App, probe:L.ctx.probe };
}

for (const scope of ['fictitious-account','']) {
  local.map.set('awp.engagement.v2', JSON.stringify({engagement:{tbRecords:[marker]}}));
  local.map.set('awp.engagement.v2:other-account', marker);
  session.map.set('awp.engagement.v1:old', marker);
  local.map.set('unrelated.preference','keep');
  const f = fixture(scope); f.app.init();
  t.ok(![...local.map.values(),...session.map.values()].some(v => v.includes(marker)), 'legacy audit storage removed: ' + (scope || 'offline'));
  t.ok(local.map.get('unrelated.preference') === 'keep', 'unrelated storage retained');
  t.ok(!f.app.state.engagement.tbRecords && f.app.state.engagement.client === '', 'legacy records never restored');
  f.probe.linkTB({records:[{name:marker,__balance:12345}]});
  f.app.state.engagement.client = marker; f.app.state.profiles = {[marker]:{amount:'D'}};
  f.probe.save();
  t.ok(!writes.some(([k,v]) => k.includes(marker) || v.includes(marker)), 'save writes no engagement, profile or trial-balance content');
  t.ok(f.app.state.engagement.tbRecords[0].name === marker, 'records remain available in active tab until session end');
  const oldState = f.app.state, m = f.Modules.byCode.PPE;
  f.probe.loadFile(m, oldState.modules.PPE, {name:'FICTITIOUS_PENDING.xlsx'});
  const lateRead = f.readers[0].onload;
  f.probe.endSession();
  t.ok(f.readers[0].aborted, 'in-flight file reader aborted');
  lateRead();
  t.ok(!JSON.stringify(f.app.state).includes(marker), 'late import cannot restore ended session');
  t.ok(f.root.textContent.includes('Session ended') && !f.root.textContent.includes(marker), 'session end removes rendered audit content');
  t.ok(![...local.map.values(),...session.map.values()].some(v => v.includes(marker)), 'end session leaves no client data in storage');
  t.ok(!f.timers.size, 'session end cancels pending UI timers');
}
const a = fixture(), b = fixture(); a.app.init(); b.app.init();
b.app.state.engagement.client = marker;
a.probe.endSession();
t.ok(!JSON.stringify(b.app.state).includes(marker) && b.root.textContent.includes('Session ended'), 'session end clears another live app tab via local channel');
const c = fixture(); c.app.init(); c.app.state.engagement.client = marker;
c.events.storage({key:'awp.session.end.v1',newValue:'1'});
t.ok(!JSON.stringify(c.app.state).includes(marker), 'storage-event fallback clears a tab');
for (const event of ['pagehide','pageshow']) {
  const f = fixture(); f.app.init(); f.app.state.engagement.client = marker;
  f.events[event]({persisted:true});
  t.ok(!JSON.stringify(f.app.state).includes(marker) && f.root.textContent.includes('Session ended'), event + ' protects restored pages');
}

const f = fixture(), attacks = [
  '<img src="/PRIVATE" onerror="alert(1)">', '<svg onload="alert(1)"></svg>',
  '<script>alert(1)</script>', '<iframe srcdoc="PRIVATE"></iframe>', '<a href="javascript:alert(1)">PRIVATE</a>',
  '<form action="/PRIVATE"><input name="data" value="PRIVATE"></form>',
  '<style>body{background:url(/PRIVATE)}</style>', '<b onclick="alert(1)">PRIVATE</b>',
  '<math><mtext><img src=x onerror=alert(1)></mtext></math>', '&lt;img src=x onerror=alert(1)&gt;'
];
const allNodes = n => [n,...n.children.filter(x => typeof x !== 'string').flatMap(allNodes)];
for (const attack of attacks) {
  const host = new f.Node('div'); f.Core.richText(host, attack);
  t.ok(allNodes(host).every(n => /^(DIV|B|STRONG|I|EM|CODE|BR|SPAN)$/.test(n.tagName) && !Object.keys(n.attributes).length), 'hostile markup cannot create active DOM: ' + attack.slice(0,35));
  t.ok(host.textContent.includes('PRIVATE') || host.textContent.includes('alert') || host.textContent.includes('img'), 'hostile content remains inert visible text');
}
const rich = new f.Node('div'); f.Core.richText(rich, '<b class="mono">12</b><br><em>review</em> &amp; &lt;tag&gt;');
t.ok(rich.children.some(n => n.tagName === 'B' && n.className === 'mono') && rich.textContent === '12review & <tag>', 'trusted formatting and escaped characters survive');
const hostile = '<img src="/PRIVATE" onerror="alert(1)">';
const imp = f.Modules.byCode.IMP.pages.find(p => p.id === 'allocation');
const impNotes = imp.render({config:{}},{money:String,d:{alloc:{rows:[],model:{cgu:hostile},loss:1}}}).filter(s => s.type === 'note');
t.ok(impNotes.some(s => s.html.includes(f.Core.escapeHTML(hostile))) && !impNotes.some(s => s.html.includes(hostile)), 'CONF-003 CGU name escaped in actual module note');
t.ok(f.SpecXL.toRows(impNotes,'allocation',{config:{}}).a.some(row => row.some(v => String(v).includes(hostile))), 'escaped CGU name remains faithful text in Excel export');
const gm = f.Modules.byCode.GC, ge = S.engagement(f.Core,'2025-12-31',145000), cfg = gm.defaultConfig();
const gr = [{line:'FICTITIOUS receipts',m1:100}], gd = gm.compute(gr,cfg,ge), forecast = gm.pages.find(p => p.id === 'forecast');
const heading = 'Feb 2027 ' + hostile;
const gcNotes = forecast.render({config:cfg,mapping:{m1:{heading}}},{d:gd,recs:gr,money:String,eng:ge}).filter(s => s?.type === 'note');
t.ok(gcNotes.some(s => s.html.includes(f.Core.escapeHTML(heading))) && !gcNotes.some(s => s.html.includes(hostile)), 'CONF-004 forecast heading escaped in actual module note');

const html = fs.readFileSync(path.join(S.APP,'audit-working-papers.html'),'utf8').replace(/\r\n/g,'\n');
const csp = html.match(/Content-Security-Policy" content="([^"]+)"/)[1];
const scriptPolicy = csp.split(';').find(s => s.trim().startsWith('script-src '));
t.ok(!/unsafe-inline|unsafe-eval|'self'|https?:|data:|blob:/.test(scriptPolicy), 'CSP permits only exact bundled script hashes');
for (const [,script] of html.matchAll(/<script>([\s\S]*?)<\/script>/g)) {
  const hash = crypto.createHash('sha256').update(script).digest('base64');
  t.ok(scriptPolicy.includes("'sha256-" + hash + "'"), 'bundled script has valid CSP hash');
}
t.ok(csp.includes("script-src-attr 'none'") && csp.includes("worker-src 'none'"), 'CSP blocks event attributes and workers');
const files = ['core.js','ui.js','spec.js','guide.js','templates.js',...fs.readdirSync(path.join(S.APP,'src/modules')).map(n => 'modules/' + n)];
t.ok(files.every(n => !/\.innerHTML\s*=|\.outerHTML\s*=|insertAdjacentHTML\s*\(/.test(fs.readFileSync(path.join(S.APP,'src',n),'utf8'))), 'no HTML parser sinks remain in application rendering');
t.done();
