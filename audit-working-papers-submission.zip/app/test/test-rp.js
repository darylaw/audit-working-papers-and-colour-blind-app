/* Headless test of the RP (Related parties) audit file against the synthetic related party movement schedule.
   Run:  node test/test-rp.js
   Only client-d carries a PBC-RP-01 file; the other clients are reported as skipped rather than failed. */
const { load, counter, money, engagement, pipeline, expectedExceptions, OUT, path, fs } = require('./spec-lib');
const L = load(['rp.js']);
const t = counter();
const CODE = 'RP';
const { Core, Modules } = L;

console.log('\n=== RP — module registration ===');
const M = Modules.byCode.RP;
t.ok(M && M.name === 'Related Parties', 'RP registered via Modules.register');
t.ok(M.pages.filter(p => p.render).length === 7, 'seven rendered working papers (L5, L5.1–L5.6)');
t.ok(['EX-RP-01', 'EX-RP-02', 'EX-RP-03', 'EX-RP-04', 'EX-RP-05'].every(id => M.tests.some(x => x.id === id)), 'EX-RP-01..05 defined');
t.ok(typeof M.suggestConclusion === 'function' && M.fields.filter(f => f.required).length === 3, 'conclusion helper and three required fields (party, transaction type, amount)');

const CLIENTS = [
  { c:'client-a', ye:'2025-02-28' }, { c:'client-b', ye:'2025-09-30' }, { c:'client-d', ye:'2025-09-30' }
];
const findFile = c => { const dir = path.join(OUT, c); if (!fs.existsSync(dir)) return null; const f = fs.readdirSync(dir).find(x => /^PBC-RP-01/i.test(x)); return f ? path.join(dir, f) : null; };

for (const { c, ye } of CLIENTS) {
  const f = findFile(c);
  console.log(`\n=== ${c} ===`);
  if (!f) { t.ok(true, `${c}: no PBC-RP-01 file in the synthetic set — skipped`); continue; }
  const eng = engagement(Core, ye, 145000);
  const rates = { 'yeRate:USD': 1, 'yeRate:CNY': 7.24, 'yeRate:HKD': 7.81 };
  const p = pipeline(L, f, CODE, eng, rates);
  const d = p.derived;
  console.log(`  header row ${p.headerRow + 1}; ${p.records.length} records; ${d.parties.length} parties; closing per book ${money(d.totals.closeFunc)} ${d.fcy}`);
  console.log(`  exceptions: ${p.exceptions.map(e => e.id).sort().join(', ')}`);

  /* mapping */
  t.ok(p.missingRequired().length === 0, `${c}: required fields mapped`, p.missingRequired().join(', '));
  t.ok(p.mapping.party && /related party/i.test(p.mapping.party.heading), `${c}: bilingual party heading "${p.mapping.party && p.mapping.party.heading}" mapped`);
  t.ok(p.mapping.relationship && p.mapping.txn_type && p.mapping.currency && p.mapping.rate && p.mapping.functional, `${c}: relationship, transaction type, currency, rate and per-book columns mapped`);
  t.ok(p.mapping.amount && /txn ccy/i.test(p.mapping.amount.heading) && /per book/i.test(p.mapping.functional.heading), `${c}: original-currency amount and per-book columns not confused`);

  /* party forward-fill: header rows with a relationship are data rows, a lone name is a group header */
  const byName = Object.fromEntries(d.parties.map(x => [x.party, x]));
  t.ok(d.parties.length === 6, `${c}: six related parties recognised (header rows and group header)`, d.parties.map(x => x.party).join(' | '));
  t.ok(byName['Pinecrest Holdings (BVI) Limited'] && byName['Pinecrest Holdings (BVI) Limited'].movements === 5, `${c}: party stated as a lone group header carries its five movements`);
  t.ok(byName['Wuxi Greenfield Logistics Co., Ltd.'] && byName['Wuxi Greenfield Logistics Co., Ltd.'].movements === 5 && byName['Wuxi Greenfield Logistics Co., Ltd.'].relationship === 'Associate', `${c}: party after the group header takes its own header row, not the stale group`);
  t.ok(byName['Redstone Capital Partners Ltd.'].relationship === 'Common director' && byName['Director - Chief Executive Officer'].relationship === 'Key management personnel', `${c}: relationships forward-filled from header rows`);
  t.ok(p.records.filter(r => r.__isHeader).length === 5 && p.records.filter(r => r.__rowKind === 'Opening balance').length === 6 && p.records.filter(r => r.__rowKind === 'Closing balance').length === 6, `${c}: 5 header rows, 6 opening and 6 closing lines classified`);

  /* movement arithmetic */
  const red = byName['Redstone Capital Partners Ltd.'], nine = byName['Nine Rivers Trading Co., Ltd.'];
  t.ok(Math.abs(red.closeOrigAudit - 5711884.92) < 0.01 && Math.abs(red.castDiffOrig - 12400) < 0.01, `${c}: Redstone recomputed closing 5,711,884.92 vs 5,724,284.92 carried forward (difference 12,400)`);
  t.ok(d.parties.filter(x => x.castBreak).length === 1, `${c}: only one party fails to cast`, d.parties.filter(x => x.castBreak).map(x => x.party).join(', '));
  t.ok(Math.abs(nine.closeOrigAudit - 3831470.92) < 0.01 && Math.abs(nine.closeFuncAudit - 485512.56) < 0.05, `${c}: Nine Rivers casts in CNY and per book`);
  const e01 = p.exceptions.filter(e => e.id === 'EX-RP-01');
  t.ok(e01.length === 1 && e01[0].recordKey === 'Redstone Capital Partners Ltd.' && Math.abs(e01[0].difference - 12400) < 0.01 && e01[0].severity === 'above-trivial', `${c}: EX-RP-01 raised for Redstone with the 12,400 difference`);
  t.ok(Math.abs(d.totals.closeFunc - (5724284.92 + 485512.56 + 4272632.55 + 642399.19 + 3704147.27 + 328517.04)) < 0.05, `${c}: closing balances per book total ${money(d.totals.closeFunc)}`);

  /* translation */
  t.ok(d.currencies.map(x => x.currency).join(',') === 'CNY,HKD,USD', `${c}: three currencies identified`, d.currencies.map(x => x.currency).join(','));
  t.ok(nine.statedRate === 7.8916 && Math.abs(nine.impliedRate - 7.8916) < 0.001 && Math.abs(nine.rateDiffPct - 9) < 0.1, `${c}: Nine Rivers translated at 7.8916 against a year-end rate of 7.24 (9.0% apart)`);
  const e02 = p.exceptions.filter(e => e.id === 'EX-RP-02');
  t.ok(e02.length === 1 && e02[0].recordKey === 'Nine Rivers Trading Co., Ltd.' && Math.abs(e02[0].difference - (485512.56 - 3831470.92 / 7.24)) < 0.05, `${c}: EX-RP-02 raised for Nine Rivers with the translation difference (${e02[0] && money(e02[0].difference)})`);
  t.ok(!p.exceptions.some(e => e.id === 'EX-RP-06'), `${c}: every line's translated amount agrees to its stated rate (no EX-RP-06)`);
  const pNoRates = pipeline(L, f, CODE, eng, {});
  t.ok(!pNoRates.exceptions.some(e => e.id === 'EX-RP-02'), `${c}: without year-end rates entered the translation test is silent`);

  /* relationship completeness */
  const e03 = p.exceptions.filter(e => e.id === 'EX-RP-03');
  t.ok(e03.length === 1 && e03[0].recordKey === 'Pinecrest Holdings (BVI) Limited', `${c}: EX-RP-03 relationship not stated for Pinecrest only`, e03.map(e => e.recordKey).join(', '));
  const pRel = pipeline(L, f, CODE, eng, { ...rates, ['relType:' + Core.keyify('Pinecrest Holdings (BVI) Limited')]: 'Parent' });
  t.ok(!pRel.exceptions.some(e => e.id === 'EX-RP-03') && pRel.derived.partyByKey[Core.keyify('Pinecrest Holdings (BVI) Limited')].relationship === 'Parent', `${c}: auditor-entered relationship clears EX-RP-03 and feeds the disclosure schedule`);

  /* round-sum advances */
  const e04 = p.exceptions.filter(e => e.id === 'EX-RP-04');
  t.ok(e04.length === 1 && /Wuxi/.test(e04[0].recordKey) && e04[0].actual === 2000000 && e04[0].severity === 'above-pm', `${c}: EX-RP-04 for the HKD 2,000,000 loan to Wuxi (${e04[0] && money(e04[0].difference)} ${d.fcy}), no terms recorded`);
  t.ok(d.advances.length >= 2 && d.advances.filter(r => r.__isRound).length === 1, `${c}: ${d.advances.length} loans/advances in the year, one a round sum (novations and repayments excluded)`);
  const pTerms = pipeline(L, f, CODE, eng, { ...rates, ['agreement:' + Core.keyify('Wuxi Greenfield Logistics Co., Ltd.')]: 'Y', ['repayment:' + Core.keyify('Wuxi Greenfield Logistics Co., Ltd.')]: 'Repayable on demand, interest free' });
  t.ok(!pTerms.exceptions.some(e => e.id === 'EX-RP-04'), `${c}: recording the agreement and terms clears EX-RP-04`);

  /* KMP */
  const e05 = p.exceptions.filter(e => e.id === 'EX-RP-05').map(e => e.recordKey);
  t.ok(d.kmp.length === 2 && e05.includes('Director - Chief Executive Officer') && e05.includes('Director - Chief Financial Officer'), `${c}: EX-RP-05 for both directors' balances`, e05.join(', '));
  const pKmp = pipeline(L, f, CODE, eng, { ...rates, ['kmpDisclosed:' + Core.keyify('Director - Chief Executive Officer')]: 'Y' });
  t.ok(pKmp.exceptions.filter(e => e.id === 'EX-RP-05').length === 1, `${c}: confirming separate disclosure clears one EX-RP-05`);

  /* confirmations */
  const pConf = pipeline(L, f, CODE, eng, { ...rates, ['confBal:' + Core.keyify('Redstone Capital Partners Ltd.')]: 5711884.92, ['confBal:' + Core.keyify('Nine Rivers Trading Co., Ltd.')]: 3831470.92 });
  const e07 = pConf.exceptions.filter(e => e.id === 'EX-RP-07');
  t.ok(e07.length === 1 && e07[0].recordKey === 'Redstone Capital Partners Ltd.' && Math.abs(e07[0].difference + 12400) < 0.01, `${c}: EX-RP-07 confirmation differs from the schedule for Redstone only`);

  /* disclosure schedule */
  t.ok(d.disclosure.length === 5 && d.disclosure.some(g => /not stated/.test(g.relationship)), `${c}: disclosure schedule groups five relationship categories including "not stated"`, d.disclosure.map(g => g.relationship).join(' | '));
  const kmpGroup = d.disclosure.find(g => g.relationship === 'Key management personnel');
  t.ok(kmpGroup && kmpGroup.parties === 2 && Math.abs(kmpGroup.closeFunc - (3704147.27 + 328517.04)) < 0.05 && kmpGroup.natures.some(n => n.nature === 'Loans and advances given'), `${c}: KMP category carries both directors and the loan nature`);

  /* planted */
  const planted = expectedExceptions('Related parties', c).map(x => x.exception.slice(0, 8));
  const got = new Set(p.exceptions.map(e => e.id));
  t.ok(planted.length === 5 && planted.every(id => got.has(id)), `${c}: all planted exceptions raised (${planted.join(', ')})`, planted.filter(id => !got.has(id)).join(', '));

  p.renderAll(t, c);
  const wb = p.exportCheck(t, c);
  const cells = ws => Object.values(ws).filter(x => x && typeof x === 'object' && 'v' in x).map(x => x.v);
  t.ok(cells(wb.Sheets['L5 Related party register']).includes('Pinecrest Holdings (BVI) Limited'), `${c}: register export carries the parties`);
  t.ok(cells(wb.Sheets['L5.6 Disclosure schedule']).includes('Key management personnel'), `${c}: disclosure export grouped by relationship`);
  const out = path.join(__dirname, 'out-RP-file.xlsx');
  L.XLSX.writeFile(wb, out);
  t.ok(L.XLSX.readFile(out).SheetNames.length === wb.SheetNames.length, `${c}: workbook survives the Excel round-trip`);
  fs.unlinkSync(out);
}

t.done();
