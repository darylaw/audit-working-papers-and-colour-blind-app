/* Headless test of the CASH audit file against the synthetic bank statements.
   Run:  node test/test-cash.js                                              */
const { load, counter, money, engagement, pipeline, OUT, path, fs } = require('./spec-lib');
const L = load(['cash.js']);
const t = counter();
const CODE = 'CASH';

const CLIENTS = [
  { c: 'client-a', ye: '2025-02-28', files: ['PBC-BANK-01 Bank statement Operating account 2025-02.xlsx', 'PBC-BANK-02 Bank statement Collection account 2025-02.xlsx', 'PBC-BANK-03 Bank statement Fixed deposit 2025-02.xlsx'] },
  { c: 'client-b', ye: '2025-09-30', files: ['PBC-BANK-01 Bank statement Operating account 2025-09.csv', 'PBC-BANK-02 Bank statement Collection account 2025-09.csv', 'PBC-BANK-03 Bank statement Fixed deposit 2025-09.csv'] },
  { c: 'client-d', ye: '2025-09-30', files: ['PBC-BANK-01 Bank statement Operating account 2025-09.xlsx', 'PBC-BANK-02 Bank statement Collection account 2025-09.xlsx', 'PBC-BANK-03 Bank statement Fixed deposit 2025-09.xlsx'] }
];

console.log('\n=== CASH — module registration ===');
t.ok(L.Modules.byCode.CASH && L.Modules.byCode.CASH.name === 'Cash & Bank', 'CASH registered via Modules.register');
t.ok(L.Modules.byCode.CASH.pages.filter(p => p.render).length === 6, 'six rendered working papers (M, M1–M5)');

for (const { c, ye, files } of CLIENTS) {
  const eng = engagement(L.Core, ye, 145000);
  for (const f of files) {
    const file = path.join(OUT, c, f);
    if (!fs.existsSync(file)) { console.log('  skip (missing) ' + f); continue; }
    const label = `${c} / ${f.replace(/PBC-BANK-\d+ Bank statement /, '').replace(/ \d{4}-\d{2}\.(xlsx|csv)$/, '')}`;
    console.log(`\n=== ${label} ===`);
    const p = pipeline(L, file, CODE, eng, { scrSampleN: 5 });
    const d = p.derived, S = d.statement;
    console.log(`  header row ${p.headerRow + 1}; ${p.records.length} rows; ${S.count} transactions; opening ${money(S.opening)} + in ${money(S.totalIn)} − out ${money(S.totalOut)} = ${money(S.computedClosing)} vs statement ${money(S.closing)} (roll diff ${money(S.rollDiff)}, ${S.rollBreaks} line breaks)`);
    t.ok(p.missingRequired().length === 0, `${label}: required fields mapped`, p.missingRequired().join(', '));
    t.ok(p.mapping.debit && p.mapping.credit, `${label}: withdrawal and deposit columns both mapped (${p.mapping.debit?.heading} / ${p.mapping.credit?.heading})`);
    t.ok(S.hasOpeningRow && S.hasClosingRow, `${label}: opening and closing balance lines recognised and held out of the population`);
    t.ok(S.count === p.records.length - 2, `${label}: transaction population = rows less the two balance lines`);
    t.ok(S.rollDiff != null && Math.abs(S.rollDiff) <= 0.01, `${label}: running balance rolls from opening to closing`, money(S.rollDiff));
    t.ok(S.rollBreaks === 0, `${label}: no individual line breaks the roll`);
    t.ok(!p.exceptions.some(e => e.id === 'EX-CASH-05' || e.id === 'EX-CASH-06'), `${label}: roll tests silent on a clean statement`);
    t.ok(S.totalIn > 0 && S.totalOut > 0, `${label}: inflows and outflows both non-zero`);

    /* M3 scrutiny */
    const Sc = d.scrutiny;
    console.log(`  M3: threshold ${money(Sc.threshold)}; flagged ${Sc.flagged.length}, sample ${Sc.sample.length}, coverage ${Sc.coverage}%; reasons ${JSON.stringify(Sc.byReason)}`);
    t.ok(Sc.threshold === eng.materiality.pm, `${label}: scrutiny threshold defaults to performance materiality`);
    t.ok(Sc.flagged.every(r => r.__scrReasons.length > 0) && Sc.sample.every(r => r.__scrReasons.length === 0), `${label}: flagged items carry a reason; random sample drawn only from unflagged items`);
    t.ok(Sc.sample.length === Math.min(5, Sc.residual.length), `${label}: sample size honoured`);
    const rp = p.exceptions.filter(e => e.id === 'EX-CASH-04');
    t.ok(rp.length > 0 && rp.every(e => e.severity === 'above-trivial'), `${label}: EX-CASH-04 related-party / unidentified narrative raised (${rp.length}) at above-trivial`);
    t.ok(rp.some(e => /unidentified/i.test(e.actual)), `${label}: the 100,000 "unidentified beneficiary" transfer is caught`);
    const big = p.records.filter(r => r.__rowKind === 'Transaction' && Math.max(r.__in, r.__out) >= Sc.threshold);
    const ex03 = p.exceptions.filter(e => e.id === 'EX-CASH-03');
    t.ok(ex03.length === big.length && ex03.every(e => e.severity === 'informational'), `${label}: EX-CASH-03 lists every item ≥ threshold as not yet vouched (${big.length}), informational`);
    if (big.length) {
      const pv = pipeline(L, file, CODE, eng, { scrSampleN: 5 }, recs => recs.forEach(r => { if (Math.max(Math.abs(r.debit || 0), Math.abs(r.credit || 0)) >= eng.materiality.pm) r.__wp = { scrutiny: { agreed: 'Y', doc: 'Remittance advice' } }; }));
      t.ok(!pv.exceptions.some(e => e.id === 'EX-CASH-03'), `${label}: EX-CASH-03 clears once the auditor records the item as agreed`);
      t.ok(pv.derived.scrutiny.vouched === big.length, `${label}: vouched count reflects the auditor inputs`);
    }
    const p2 = pipeline(L, file, CODE, eng, { scrSampleN: 5 });
    t.ok(JSON.stringify(p2.derived.scrutiny.sample.map(r => r.__srcRow)) === JSON.stringify(Sc.sample.map(r => r.__srcRow)), `${label}: same seed → identical sample`);
    const p3 = pipeline(L, file, CODE, eng, { scrSampleN: 5, scrSeed: 7 });
    t.ok(Sc.residual.length <= 5 || JSON.stringify(p3.derived.scrutiny.sample.map(r => r.__srcRow)) !== JSON.stringify(Sc.sample.map(r => r.__srcRow)), `${label}: different seed → different sample`);
    const p4 = pipeline(L, file, CODE, eng, { scrThreshold: 20000 });
    t.ok(p4.derived.scrutiny.flagged.length >= Sc.flagged.length, `${label}: lowering the threshold selects at least as many items`);
    const weekend = p.records.filter(r => r.__rowKind === 'Transaction' && r.stmt_date && [0, 6].includes(r.stmt_date.getUTCDay()));
    t.ok(weekend.every(r => r.__scrReasons.includes('Weekend posting')), `${label}: weekend postings flagged (${weekend.length})`);
    const round = p.records.filter(r => r.__rowKind === 'Transaction' && Math.max(r.__in, r.__out) >= 10000 && Math.max(r.__in, r.__out) % 10000 === 0);
    t.ok(round.length > 0 && round.every(r => r.__scrReasons.includes('Round sum')), `${label}: round sums flagged (${round.length})`);

    /* M4 cut-off, M5 analytics */
    console.log(`  M4: ${d.cutoff.length} items within ±${d.cutoffDays} days; M5: ${d.monthly.length} months, top stem "${d.topCounterparties[0]?.stem}" (${d.topCounterparties[0]?.count} txns)`);
    t.ok(d.cutoff.every(r => Math.abs(Math.round((r.stmt_date - eng.yearEndDate) / 86400000)) <= 7), `${label}: cut-off window respected`);
    t.ok(Math.abs(d.monthly.reduce((s, m) => s + m.inflow, 0) - S.totalIn) < 0.05 && Math.abs(d.monthly.reduce((s, m) => s + m.outflow, 0) - S.totalOut) < 0.05, `${label}: monthly table cross-casts to statement totals`);
    t.ok(Math.abs(d.counterparties.reduce((s, x) => s + x.gross, 0) - (S.totalIn + S.totalOut)) < 0.05, `${label}: counterparty table cross-casts to gross movement`);
    t.ok(d.counterparties.length < S.count, `${label}: narrative stems group recurring payees (${d.counterparties.length} stems for ${S.count} transactions)`);

    /* pages and export */
    p.renderAll(t, label);
    p.exportCheck(t, label);
  }
}

/* ---------------------------------------------------------------------- */
console.log('\n=== CASH — auditor inputs on M, M1, M2 drive the tests (client-a operating account) ===');
{
  const eng = engagement(L.Core, '2025-02-28', 145000);
  const file = path.join(OUT, 'client-a', 'PBC-BANK-01 Bank statement Operating account 2025-02.xlsx');
  const base = pipeline(L, file, CODE, eng);
  const closing = base.derived.statement.closing;

  /* M1: a reconciliation that proves */
  const cfgOK = { ledgerBalance: closing - 12000 + 3500, recItemRows: 4,
    'riType:ri1': 'Unpresented cheque', 'riDate:ri1': '20/02/2025', 'riRef:ri1': 'Chq 1001', 'riAmount:ri1': 12000,
    'riType:ri2': 'Deposit in transit', 'riDate:ri2': '27/02/2025', 'riRef:ri2': 'Lodgement', 'riAmount:ri2': 3500 };
  const pOK = pipeline(L, file, CODE, eng, cfgOK);
  console.log(`  statement ${money(closing)} − unpresented 12,000 + in transit 3,500 = expected ledger ${money(pOK.derived.recon.expectedLedger)}; unexplained ${money(pOK.derived.recon.unexplained)}`);
  t.ok(Math.abs(pOK.derived.recon.unexplained) < 0.005, 'M1 reconciliation proves when items explain the difference');
  t.ok(!pOK.exceptions.some(e => e.id === 'EX-CASH-01' || e.id === 'EX-CASH-02'), 'EX-CASH-01/02 silent on a clean reconciliation');

  /* M1: an unexplained difference and a stale cheque */
  const cfgBad = { ...cfgOK, ledgerBalance: closing - 12000 + 3500 + 250, 'riDate:ri1': '15/06/2024' };
  const pBad = pipeline(L, file, CODE, eng, cfgBad);
  const e01 = pBad.exceptions.find(e => e.id === 'EX-CASH-01');
  t.ok(e01 && Math.abs(e01.difference - 250) < 0.005, 'EX-CASH-01 unexplained reconciliation difference raised with the right amount', e01 && e01.difference);
  const e02 = pBad.exceptions.find(e => e.id === 'EX-CASH-02');
  t.ok(e02 && e02.actual > 180 && /Chq 1001/.test(e02.recordKey), 'EX-CASH-02 long-outstanding reconciling item raised (cheque dated 8 months before year end)', e02 && JSON.stringify(e02));
  const pStale = pipeline(L, file, CODE, eng, { ...cfgBad, staleDays: 400 });
  t.ok(!pStale.exceptions.some(e => e.id === 'EX-CASH-02'), 'raising the stale threshold to 400 days silences EX-CASH-02');

  /* M lead: further accounts, TB and PY inputs */
  const cfgLead = { extraAccounts: 1, 'accLabel:stmt': 'Operating account', 'recBal:stmt': closing, 'tbBal:stmt': closing, 'pyBal:stmt': closing - 50000,
    'accLabel:acc1': 'Fixed deposit', 'stmtBal:acc1': 200000, 'recBal:acc1': 200000, 'tbBal:acc1': 199000, 'pyBal:acc1': 200000 };
  const pLead = pipeline(L, file, CODE, eng, cfgLead);
  const Ld = pLead.derived.lead;
  t.ok(Ld.length === 2 && Ld[0].label === 'Operating account' && Ld[1].label === 'Fixed deposit', 'M lead lists the uploaded account plus the further account entered');
  t.ok(Ld[0].diffStmtRec === 0 && Ld[0].diffRecTB === 0 && Ld[0].variance === 50000, 'M lead computes statement/reconciliation/ledger differences and PY movement');
  t.ok(Ld[1].diffRecTB === 1000, 'M lead computes the reconciliation-to-ledger difference on the further account');
  const e10 = pLead.exceptions.filter(e => e.id === 'EX-CASH-10');
  t.ok(e10.length === 1 && e10[0].recordKey === 'Fixed deposit' && Math.abs(e10[0].difference - 1000) < 0.005, 'EX-CASH-10 raised only for the account that does not agree');
  t.ok(Math.abs(pLead.derived.leadTotals.stmt - (closing + 200000)) < 0.005, 'M lead totals cast across accounts');

  /* M2 confirmations */
  const pConf = pipeline(L, file, CODE, eng, { ...cfgOK, ...cfgLead, 'confRecd:stmt': 'Y', 'confBal:stmt': closing + 10, 'confRecd:acc1': 'Y', 'confBal:acc1': 200000 });
  const e09 = pConf.exceptions.filter(e => e.id === 'EX-CASH-09');
  t.ok(e09.length === 1 && e09[0].recordKey === 'Operating account' && Math.abs(e09[0].difference - 10) < 0.005, 'EX-CASH-09 confirmed balance differs from statement, raised per account');

  /* running-balance logic: tamper with one statement line */
  const pRoll = pipeline(L, file, CODE, eng, {}, recs => { const r = recs.find(x => x.__srcRow === 20); r.balance = r.balance + 1000; });
  const e05 = pRoll.exceptions.find(e => e.id === 'EX-CASH-05'), e06 = pRoll.exceptions.filter(e => e.id === 'EX-CASH-06');
  t.ok(e06.length === 2 && e06[0].srcRow === 20 && Math.abs(e06[0].difference - 1000) < 0.005, 'EX-CASH-06 an altered balance breaks the roll on that line and self-corrects on the next', JSON.stringify(e06.map(e => [e.srcRow, e.difference])));
  t.ok(!e05, 'EX-CASH-05 (opening + net = closing) still holds because the movements were untouched');
  const pRoll2 = pipeline(L, file, CODE, eng, {}, recs => { const r = recs.find(x => x.__srcRow === 20); r.debit = (r.debit || 0) + 1000; });
  const e05b = pRoll2.exceptions.find(e => e.id === 'EX-CASH-05');
  t.ok(e05b && Math.abs(e05b.difference - 1000) < 0.005, 'EX-CASH-05 an altered movement makes opening + net ≠ closing', e05b && e05b.difference);
  t.ok(pRoll2.exceptions.filter(e => e.id === 'EX-CASH-06').length === 1, 'EX-CASH-06 an altered movement breaks the roll on that line only (every later balance is offset)');

  /* export carries the inputs */
  const wb = pConf.exportCheck(t, 'client-a with inputs');
  const ws = wb.Sheets['M Lead schedule'];
  const cells = Object.values(ws).filter(c => c && typeof c === 'object' && 'v' in c).map(c => c.v);
  t.ok(cells.includes('Operating account') && cells.includes('Fixed deposit'), 'M lead export contains the account labels entered by the auditor');
  const wsR = wb.Sheets['M1 Bank reconciliation review'];
  t.ok(wsR && Object.values(wsR).some(c => c && c.v === 'Unpresented cheque'), 'M1 export carries the reconciling items entered');
  const out = path.join(__dirname, 'out-CASH-file.xlsx');
  L.XLSX.writeFile(wb, out);
  const re = L.XLSX.readFile(out);
  t.ok(re.SheetNames.length === wb.SheetNames.length, 'workbook survives the Excel round-trip');
  fs.unlinkSync(out);

  /* conclusion helper */
  const st = pConf.state().modules.CASH;
  const text = L.Modules.byCode.CASH.suggestConclusion(st, pConf.ctx());
  t.ok(typeof text === 'string' && text.length > 100, 'suggestConclusion produces text');
}

t.done();
