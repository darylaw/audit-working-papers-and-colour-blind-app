/* Headless test of the Trade Receivables & ECL module against the synthetic PBC files.
   Run:  node test/test-ar.js                                                     */

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const APP = path.join(__dirname, '..');
const SRC = path.join(APP, 'src');
const OUT = path.resolve(APP, '..', 'synthetic-data', 'out');

const XLSX = require(path.join(SRC, 'vendor', 'xlsx.full.min.js'));
XLSX.set_fs(fs);
const ctx = vm.createContext({ XLSX, console, Date, Math, JSON, Object, Array, String, Number, isNaN, parseFloat, parseInt, Map, Set, Intl, RegExp, Error });
for (const [f, name] of [['core.js', 'Core'], ['spec.js', 'SpecUI'], ['ppe.js', 'PPEModule'], ['modules.js', 'Modules'], ['modules/ar.js', 'ARModule'], ['xlsxstyle.js', 'StyledXLSX'], ['wpstyle.js', 'WPStyle'], ['xlsxfile.js', 'FileExporter'], ['xlsxout.js', 'Exporter']]) {
  vm.runInContext(fs.readFileSync(path.join(SRC, f), 'utf8') + `\n;globalThis.${name} = ${name};`, ctx, { filename: f });
}
const { Core, Modules, Exporter, ARModule } = ctx;

let pass = 0, fail = 0;
const ok = (cond, msg, extra) => { if (cond) { pass++; console.log('  PASS  ' + msg); } else { fail++; console.log('  FAIL  ' + msg + (extra ? '  → ' + extra : '')); } };
const money = n => n == null ? '—' : Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const expected = JSON.parse(fs.readFileSync(path.join(OUT, '_expected-exceptions.json'), 'utf8')).seeded_exceptions;

function engagement(yearEnd, om) {
  const e = { client: 'Test Entity Pte. Ltd.', firmRef: 'TEST/001', yearEnd, preparedBy: 'AB', datePrepared: '2026-01-15', reviewedBy: 'CD', dateReviewed: '2026-01-20',
    currency: 'USD', framework: 'IFRS / SFRS(I)', indexRef: { AR: 'L3' },
    materiality: Core.computeMateriality({ basis: 'turnover', basisLabel: 'Turnover', benchmark: om / 0.02, rate: 0.02, pmPct: 0.75, trivialPct: 0.05 }), tbLink: {} };
  e.yearEndDate = new Date(yearEnd + 'T00:00:00Z');
  const d = new Date(e.yearEndDate.getTime()); d.setUTCDate(d.getUTCDate() + 1); d.setUTCFullYear(d.getUTCFullYear() - 1);  /* day first, then year: FYE 28 Feb 2025 -> FYS 1 Mar 2024, not 29 Feb */ e.fyStartDate = d;
  return e;
}
function pipeline(file, moduleCode, eng, cfgOverride = {}) {
  const M = Modules.byCode[moduleCode];
  const buf = fs.readFileSync(file);
  const wbData = Core.readWorkbook(buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength), path.basename(file));
  const sheet = wbData.sheets[0];
  const headerRow = Core.detectHeader(sheet.rows);
  const clean = Core.cleanTable(sheet.rows, headerRow);
  const mapping = Core.proposeMapping(clean.headers, M.fields, clean.rows.filter(r => r.__kind === 'data').slice(0, 40));
  const built = Core.buildRecords(clean, M.fields, mapping);
  const cfg = M.defaultConfig();
  Object.assign(cfg, cfgOverride);
  const res = Core.runTests(M, built.records, cfg, eng);
  return { M, wbData, sheet, headerRow, clean, mapping, built, cfg, res, records: built.records, exceptions: res.exceptions, derived: res.derived,
    asState(eng2) { return { engagement: eng2 || eng, modules: { [moduleCode]: { code: moduleCode, ...this,
      sources: [{ fileName: path.basename(file), hash: wbData.hash, sheetName: sheet.name, headerRow, rowCount: built.records.length, uploadedAt: wbData.uploadedAt, rawRows: sheet.rows }],
      config: cfg, cleanLog: clean.log, mapIssues: built.issues, edits: [], adjustments: [], aiBlocks: [], pageNotes: {}, trail: [], comments: '', conclusion: '' } } }; } };
}
const specCtx = (p, eng) => ({ eng, cfg: p.cfg, d: p.derived, recs: p.records.filter(r => !r.__excluded), all: p.records, money: x => x, money0: x => x, pct: x => x,
  fmtDate: Core.fmtDate, r2: n => n == null ? null : Math.round(n * 100) / 100, pm: eng.materiality.pm, trivial: eng.materiality.trivial, M: p.M });
const arFile = (c, ye) => path.join(OUT, c, `PBC-AR-01 Trade receivables listing ${ye}.xlsx`);
const raised = (p, id, inv) => p.exceptions.some(e => e.id === id && (!inv || String(e.recordKey).includes(inv)));
const plantedFor = client => expected.filter(e => e.client === client && e.area === 'Receivables').map(e => ({ id: e.exception.slice(0, 8), key: e.record_key }));

/* Client ECL working papers as they would be typed in by the auditor (from PBC-ECL-01). */
const HIST = { b_current: [1356638.69, 3208.17, 77125.7, 128.54, 725839.39, 1086.56], b_1_30: [1138731.03, 7316.03, 534008.16, 3223.96, 347498, 1815.77],
  b_31_60: [1345180.05, 16426.17, 416986.18, 5455.14, 315083.2, 2755.85], b_61_90: [1350080.86, 48502.27, 1141302.47, 41167.6, 352279.91, 8438.65],
  b_91_180: [711352.72, 43582.14, 477666.92, 41096.04, 348452.39, 34260.38], b_181_365: [820035.13, 153710.5, 554852.68, 118979.29, 1245186.35, 279487.37],
  b_over_365: [299974.16, 205617.83, 226550.9, 94285.17, 289912.85, 119295.48] };
const CLIENT_RATES = { b_current: 0, b_1_30: 0, b_31_60: 0, b_61_90: 1, b_91_180: 2, b_181_365: 5, b_over_365: 10 };
function eclInputs(opts = {}) {
  const cfg = {};
  if (!opts.noHistory) for (const [k, v] of Object.entries(HIST)) { cfg['h_g3:' + k] = v[0]; cfg['h_w3:' + k] = v[1]; cfg['h_g2:' + k] = v[2]; cfg['h_w2:' + k] = v[3]; cfg['h_g1:' + k] = v[4]; cfg['h_w1:' + k] = v[5]; }
  for (const [k, v] of Object.entries(CLIENT_RATES)) cfg['m_rate:' + k] = v;
  if (opts.validOverlay) {
    Object.assign(cfg, { 'o_w:base': 0.5, 'o_m:base': 1, 'o_note:base': 'GDP growth 2.4%', 'o_src:base': 'Central bank forecast',
      'o_w:upside': 0.2, 'o_m:upside': 0.82, 'o_note:upside': 'GDP growth 3.8%', 'o_src:upside': 'Central bank forecast',
      'o_w:downside': 0.3, 'o_m:downside': 1.55, 'o_note:downside': 'GDP growth -0.7%', 'o_src:downside': 'Central bank forecast',
      macroSource: 'Central bank macroeconomic review, published quarterly', overlayDate: '2025-01-31' });
  } else {
    Object.assign(cfg, { 'o_w:base': 1, 'o_m:base': 1, 'o_w:upside': 0, 'o_m:upside': 0.82, 'o_w:downside': 0, 'o_m:downside': 1.55,
      macroSource: 'Management estimate. No external source documented.', overlayDate: '2023-01-30' });
  }
  cfg.tbAllowance = 96400; cfg.clientExcludesRP = true;
  return cfg;
}

/* ====================================================================== */
console.log('\n=== AR audit file — Client A ===');
{
  const eng = engagement('2025-02-28', 145000);
  const file = arFile('client-a', '2025-02-28');
  const p = pipeline(file, 'AR', eng, { tbGross: 3333317.64, revenue: 9000000, ...eclInputs() });
  const d = p.derived;
  console.log(`  header row ${p.headerRow + 1}, ${p.records.length} open items, ${d.customers.length} customers, total ${money(d.total)}`);
  ok(p.M === ARModule && p.M.name === 'Trade Receivables & ECL', 'ARModule registered and replaces the generic AR module');
  ok(p.headerRow === 5 && p.records.length > 60, 'listing read and cleaned');
  const req = p.M.fields.filter(f => f.required && !p.mapping[f.key]);
  ok(req.length === 0, 'all required fields resolved', req.map(f => f.key).join(', '));
  ok(['due_date', 'terms', 'currency', 'amount_orig', 'cust_code'].every(k => p.mapping[k]), 'optional fields (due date, terms, currency, original amount, code) mapped too');
  ok(p.mapping.amount.heading === 'Amount' && p.mapping.amount_orig.heading === 'Amount (Orig)', 'base vs original amount columns resolved correctly');

  /* L3 lead */
  /* the client leaves a hard-coded control total under the listing (row 83, 35.80 off);
     the module holds it out as an orphan, so the sum must exclude orphans too */
  const sum = p.records.filter(r => !r.__orphan).reduce((s, r) => s + (r.amount || 0), 0);
  ok(Math.abs(d.total - sum) < 0.01 && d.total > 1e6, `listing total ${money(d.total)} equals the sum of open items (orphan control total held out)`);
  ok(d.orphans.length === 1 && Math.abs(d.orphans[0].amount - d.total - 35.80) < 0.01, `client's control total row held out: ${money(d.orphans[0]?.amount)} = listing + 35.80 planted casting difference`);
  ok(d.lead[0].tb === 3333317.64 && d.lead[0].diff != null, `lead: listing vs TB difference ${money(d.lead[0].diff)}`);
  ok(d.recDays > 0 && d.top5Share > 0 && d.top5.length === 5, `receivable days ${d.recDays}, top-5 share ${(d.top5Share * 100).toFixed(1)}%`);
  ok(d.currencies.length >= 3 && Math.abs(d.currencies.reduce((s, c) => s + c.base, 0) - d.total) < 0.01, `by currency: ${d.currencies.map(c => c.currency).join(', ')} — casts to the total`);

  /* L3.1 ageing */
  const aged = d.aging.reduce((s, a) => s + a.gross, 0) + d.notAged.reduce((s, r) => s + (r.amount || 0), 0);
  console.log('  L3.1 ageing: ' + d.aging.map(a => `${a.label} ${money(a.gross)}`).join(' | ') + (d.notAged.length ? ` | not aged ${d.notAged.length}` : ''));
  ok(d.buckets.length === 7 && d.buckets[0].key === 'b_current' && d.buckets[6].key === 'b_over_365', 'default buckets: not due / 1-30 / 31-60 / 61-90 / 91-180 / 181-365 / >365');
  ok(Math.abs(aged - d.total) < 0.01, 'ageing casts to the listing total');
  ok(d.aging.filter(a => a.gross !== 0).length >= 4, 'balances fall into several buckets');
  const pInv = pipeline(file, 'AR', eng, { ageBasis: 'invoice' });
  ok(JSON.stringify(pInv.derived.aging.map(a => a.gross)) !== JSON.stringify(d.aging.map(a => a.gross)), 'changing the ageing basis to invoice date changes the buckets');
  const pEdges = pipeline(file, 'AR', eng, { bucketEdges: '30,60,90,120' });
  ok(pEdges.derived.buckets.length === 6 && pEdges.derived.buckets[5].label === 'Over 120 days', 'bucket edges are configurable');
  const pCA = pipeline(file, 'AR', eng, Object.fromEntries(d.aging.map(a => ['ca:' + a.key, a.key === 'b_31_60' ? a.gross + 5000 : a.gross])));
  ok(pCA.exceptions.filter(e => e.id === 'EX-AR-11').length === 1 && pCA.exceptions.find(e => e.id === 'EX-AR-11').difference === -5000, 'EX-AR-11 raised for the one bucket where the client ageing differs');
  ok(!p.exceptions.some(e => e.id === 'EX-AR-11'), 'EX-AR-11 silent while no client ageing is entered');

  /* L3.2 cut-off */
  ok(d.postYE.length >= 1 && d.postYE.every(r => r.invoice_date > eng.yearEndDate), `${d.postYE.length} invoice(s) dated after year end`);
  ok(d.nearYE.length > 0 && d.nearYE.every(r => r.invoice_date <= eng.yearEndDate), `${d.nearYE.length} invoice(s) in the ${d.cutoffDays}-day window`);
  d.nearYE[0].__wp = { cutoff: { period: 'Incorrect' } };
  const res12 = Core.runTests(p.M, p.records, p.cfg, eng);
  ok(res12.exceptions.some(e => e.id === 'EX-AR-12' && e.srcRow === d.nearYE[0].__srcRow), 'auditor marking a cut-off item "Incorrect" raises EX-AR-12');
  delete d.nearYE[0].__wp;

  /* L3.3 circularisation */
  const C = d.circ;
  console.log(`  L3.3 circularisation: ${d.grossPos.length} debit customers; threshold ${money(C.threshold)}; key ${C.keyItems.length}; sample ${C.sample.length} of ${C.residual.length}; coverage ${C.coverage}%`);
  ok(C.threshold === eng.materiality.pm, 'threshold defaults to performance materiality');
  ok(C.keyItems.every(c => c.gross >= C.threshold) && C.sample.every(c => c.gross < C.threshold), 'key items at or above threshold; sample drawn only from the residual');
  ok(C.sample.length === Math.min(5, C.residual.length), 'random sample of the requested size');
  const pSame = pipeline(file, 'AR', eng, {}), pSeed = pipeline(file, 'AR', eng, { circSeed: 99 });
  ok(JSON.stringify(pSame.derived.circ.sample.map(c => c.key)) === JSON.stringify(C.sample.map(c => c.key)), 'same seed → identical sample');
  ok(JSON.stringify(pSeed.derived.circ.sample.map(c => c.key)) !== JSON.stringify(C.sample.map(c => c.key)), 'different seed → different sample');
  const sel0 = C.selected[0];
  const pConf = pipeline(file, 'AR', eng, { ['c_reply:' + sel0.key]: 'Y', ['c_conf:' + sel0.key]: sel0.gross - 1000 });
  ok(pConf.derived.circ.selected[0].diff === -1000 && pConf.exceptions.some(e => e.id === 'EX-AR-13' && e.recordKey === sel0.label), 'confirmed amount below the listing → difference computed and EX-AR-13 raised until reconciled');
  const pRecon = pipeline(file, 'AR', eng, { ['c_reply:' + sel0.key]: 'Y', ['c_conf:' + sel0.key]: sel0.gross - 1000, ['c_recon:' + sel0.key]: 'Y' });
  ok(!pRecon.exceptions.some(e => e.id === 'EX-AR-13'), 'marking the difference reconciled clears EX-AR-13');

  /* L3.4 subsequent receipts */
  ok(d.subs.length === C.selected.length, 'with no replies every selected customer is carried to subsequent receipts');
  ok(pConf.derived.subs.length === C.selected.length && pRecon.derived.subs.length === C.selected.length - 1, 'a customer with an unreconciled difference stays in subsequent receipts; a cleanly confirmed one drops off');
  const pSubs = pipeline(file, 'AR', eng, { ['s_amt:' + sel0.key]: sel0.gross / 2 });
  const s0 = pSubs.derived.subs.find(x => x.key === sel0.key);
  ok(s0 && Math.abs(s0.pct - 0.5) < 1e-9 && Math.abs(s0.outstanding - sel0.gross / 2) < 0.01, 'receipt of half the balance → 50% cleared, half still outstanding');

  /* L3.5 loss-rate derivation */
  console.log('  L3.5 observed rates: ' + d.hist.map(h => `${h.label} ${(h.observed * 100).toFixed(2)}%`).join(' | '));
  ok(d.histYears === 3 && !d.derivationEmpty, 'three years of history recorded');
  ok(Math.abs(d.hist.find(h => h.key === 'b_over_365').observed - 0.5134) < 0.0005, 'observed rate for >365 days reproduces the client working (51.34%)');
  ok(!raised(p, 'EX-ECL-10'), 'EX-ECL-10 silent with three years of history');
  const pNoHist = pipeline(file, 'AR', eng, eclInputs({ noHistory: true }));
  ok(raised(pNoHist, 'EX-ECL-10') && pNoHist.derived.derivationEmpty && pNoHist.derived.collAudit == null, 'empty derivation → EX-ECL-10 and no ECL per audit');
  ok(!raised(pNoHist, 'EX-ECL-09'), 'EX-ECL-09 not raised while the matrix cannot be computed');

  /* L3.6 overlay */
  const O = d.overlay;
  console.log(`  L3.6 overlay: sum of weights ${O.sumW}, weighted multiplier ${O.weightedMult}, valid ${O.valid}, age ${O.ageMonths} months; issues: ${O.issues.join('; ')}`);
  ok(!O.valid && O.issues.some(i => /single scenario/i.test(i)), 'client overlay (base 100%) is rejected');
  ok(O.appliedMult == null && d.matrix.every(m => m.observed == null || Math.abs(m.auditRate - m.observed) < 1e-12), 'rejected overlay → observed rates applied unadjusted, not defaulted to 1');
  ok(O.stale && O.ageMonths > 12, 'overlay dated 30/01/2023 is stale at a 28/02/2025 year end');
  const pV = pipeline(file, 'AR', eng, { tbGross: 3333317.64, ...eclInputs({ validOverlay: true }) });
  ok(pV.derived.overlay.valid && Math.abs(pV.derived.overlay.weightedMult - 1.129) < 1e-9, `valid three-scenario overlay → probability-weighted multiplier ${pV.derived.overlay.weightedMult}`);
  ok(!raised(pV, 'EX-ECL-02') && !raised(pV, 'EX-ECL-03') && !raised(pV, 'EX-ECL-04'), 'EX-ECL-02/03/04 silent for a valid, current, externally sourced overlay');
  ok(pV.derived.matrix.every(m => m.observed == null || Math.abs(m.auditRate - m.observed * 1.129) < 1e-9), 'audit rate = observed × weighted multiplier');
  const pBad = pipeline(file, 'AR', eng, { 'o_w:base': 0.6, 'o_m:base': 1, 'o_w:downside': 0.6, 'o_m:downside': 1.5, 'o_note:base': 'x' });
  ok(pBad.derived.overlay.issues.some(i => /sum to/.test(i)) && pBad.derived.overlay.appliedMult == null, 'weights not summing to 1 → overlay rejected');

  /* L3.7 matrix */
  console.log(`  L3.7 matrix: collective client ${money(d.collClient)} / audit ${money(d.collAudit)}; individual audit ${money(d.indAudit)}; total audit ${money(d.totalAudit)} vs TB 96,400.00 → ${money(d.allowanceDiff)}`);
  ok(Math.abs(d.matrix.reduce((s, m) => s + m.gross, 0) - d.aging.reduce((s, a) => s + a.gross, 0)) < 0.01, 'matrix gross agrees to the rebuilt ageing');
  ok(d.collAudit > d.collClient && d.collAudit > 0, 'ECL per audit exceeds ECL per client (nil rates on past-due buckets)');
  ok(d.matrix.every(m => m.eclAudit === Math.round(m.base * m.auditRate * 100) / 100), 'ECL per audit = collective base × audit rate, per bucket');
  ok(d.allowanceDiff != null && Math.abs(d.allowanceDiff - (d.totalAudit - 96400)) < 0.01, 'difference to the loss allowance in the TB computed');
  ok(d.lead[1].listing === d.totalAudit && d.lead[1].tb === 96400, 'lead schedule carries the loss allowance per audit and per TB');

  /* L3.8 watchlist */
  const W = d.watch;
  console.log(`  L3.8 watchlist: ${W.length} candidates; beyond default ${W.filter(w => w.credImpairedPresumed).length}; credit ${W.filter(w => w.triggers.includes('Credit balance')).length}`);
  ok(W.length > 0 && W.some(w => w.credImpairedPresumed) && W.some(w => w.triggers.includes('Credit balance')), 'candidates identified from the default presumption and credit balances');
  const cand = W.find(w => w.credImpairedPresumed);
  const pW = pipeline(file, 'AR', eng, { ...eclInputs(), ['w_sicr:' + cand.key]: 'Y', ['w_imp:' + cand.key]: 'Y', ['w_ecla:' + cand.key]: cand.gross, ['w_eclc:' + cand.key]: 0, ['w_ind:' + cand.key]: 'Applied for a scheme of arrangement' });
  const dW = pW.derived;
  ok(dW.matrix.reduce((s, m) => s + m.individual, 0) > 0 && Math.abs(dW.matrix.reduce((s, m) => s + m.individual, 0) - cand.gross) < 0.01, 'a counterparty marked credit-impaired leaves the collective matrix in full');
  ok(dW.indAudit === cand.gross && Math.abs(dW.totalAudit - (dW.collAudit + cand.gross)) < 0.01, 'individual ECL per audit is added to the collective total');
  ok(raised(pW, 'EX-ECL-05', cand.label), 'EX-ECL-05: debtor in difficulty with nil allowance per client');
  ok(!pW.exceptions.some(e => e.id === 'EX-ECL-06' && e.recordKey === cand.label), 'EX-ECL-06 clears for that counterparty once marked credit-impaired');
  ok(raised(p, 'EX-ECL-06', cand.label), 'EX-ECL-06 raised while it is not assessed');
  const pRP = pipeline(file, 'AR', eng, { ['rp:' + d.customers[0].key]: 'Y' });
  ok(pRP.derived.rpGross === d.customers[0].gross && pRP.derived.watch.some(w => w.key === d.customers[0].key && w.rp), 'marking a customer related party on L3.1 flows to the matrix RP column and the watchlist');

  /* planted exceptions */
  const ids = [...new Set(p.exceptions.map(e => e.id))].sort();
  console.log('  exceptions: ' + p.exceptions.length + ' → ' + ids.join(', '));
  for (const x of plantedFor('client-a')) ok(raised(p, x.id, x.key), `planted ${x.id} raised on ${x.key}`);
  ['EX-ECL-01', 'EX-ECL-02', 'EX-ECL-03', 'EX-ECL-04', 'EX-ECL-06', 'EX-ECL-07', 'EX-ECL-09'].forEach(id => ok(raised(p, id), `planted ${id} raised from the client ECL workings`));
  /* one EX-ECL-01 per past-due bucket that actually carries a balance and whose client
     rate is nil or beyond tolerance -- empty buckets are rightly skipped */
  const expectE1 = d.matrix.filter(m => m.pastDue && m.base > 0 && m.clientRate != null && (m.clientRate === 0 || Math.abs(m.rateGap) > 0.5)).length;
  const gotE1 = p.exceptions.filter(e => e.id === 'EX-ECL-01').length;
  ok(gotE1 === expectE1 && gotE1 >= 3, `EX-ECL-01 raised on ${gotE1} populated past-due bucket(s) with nil or under-stated client rates`);
  ok(!p.exceptions.some(e => e.id === 'EX-AR-08' && !/^JE/.test(String(e.recordKey).split(' / ')[1])), 'EX-AR-08 fires only on the non-invoice reference, not on round-sum invoices');

  /* pages render + export */
  const sc = specCtx(p, eng);
  const st = p.asState().modules.AR;
  for (const pg of p.M.pages.filter(x => x.render)) {
    let specs = null, err = null;
    try { specs = pg.render(st, sc); } catch (e) { err = e; }
    ok(Array.isArray(specs) && specs.length && specs.every(s => s && s.type), `${pg.ref} ${pg.title} renders ${specs ? specs.length : 0} spec(s)`, err && err.stack);
    if (pg.flag) { try { pg.flag(st, p.derived); } catch (e) { ok(false, `${pg.ref} flag() throws`, e.message); } }
  }
  ok(typeof p.M.suggestConclusion(st, sc) === 'string' && p.M.suggestConclusion(st, sc).length > 100, 'template conclusion produced');
  const wb = Exporter.build(p.asState(), 'AR');
  console.log('  sheets: ' + wb.SheetNames.join(' | '));
  for (const pg of p.M.pages.filter(x => x.render)) ok(wb.SheetNames.some(n => n.startsWith(pg.ref + ' ')), `sheet for ${pg.ref}`);
  ['00 Index', 'Exceptions', '01 Source 1', '02 Cleaned data', '03 Mapping'].forEach(n => ok(wb.SheetNames.includes(n), `sheet "${n}"`));
  const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  ok(buf.length > 20000, `workbook serialises (${(buf.length / 1024).toFixed(0)} KB)`);
  const mx = wb.Sheets[wb.SheetNames.find(n => n.startsWith('L3.7 '))];
  const cells = Object.values(mx).filter(c => c && typeof c === 'object' && c.v != null);
  ok(cells.some(c => c.v === 'Loss rate per client (%)') && cells.some(c => c.v === 10), 'matrix sheet carries the client-rate inputs entered in the app');
}

/* ====================================================================== */
console.log('\n=== AR — Client B and Client D (different vocabularies, bilingual headings) ===');
for (const [c, ye] of [['client-b', '2025-09-30'], ['client-d', '2025-09-30']]) {
  const eng = engagement(ye, 145000);
  const p = pipeline(arFile(c, ye), 'AR', eng, eclInputs());
  const d = p.derived;
  console.log(`  ${c}: header row ${p.headerRow + 1}, ${p.records.length} items, total ${money(d.total)}, ` + d.aging.map(a => `${a.label} ${money(a.gross)}`).join(' | '));
  const missing = p.M.fields.filter(f => f.required && !p.mapping[f.key]);
  ok(missing.length === 0, `${c}: required fields mapped`, missing.map(f => f.key).join(', '));
  ok(['due_date', 'terms', 'currency'].every(k => p.mapping[k]), `${c}: due date, terms and currency mapped`);
  ok(d.total > 1e6 && d.aging.filter(a => a.gross !== 0).length >= 3, `${c}: ageing rebuilt with balances in several buckets`);
  ok(Math.abs(d.aging.reduce((s, a) => s + a.gross, 0) + d.notAged.reduce((s, r) => s + (r.amount || 0), 0) - d.total) < 0.01, `${c}: ageing casts`);
  ok(d.circ.selected.length > 0 && d.watch.length > 0 && d.collAudit != null, `${c}: circularisation, watchlist and matrix computed`);
  const ids = [...new Set(p.exceptions.map(e => e.id))].sort();
  console.log('  exceptions: ' + ids.join(', '));
  for (const x of plantedFor(c)) {
    if (c === 'client-d' && x.id === 'EX-AR-07') { console.log(`  skip  ${x.id} on ${x.key}: nil terms on a 13-day-old item with due date = invoice date is indistinguishable from cash terms`); continue; }
    ok(raised(p, x.id, x.key), `${c}: planted ${x.id} raised on ${x.key}`);
  }
  ['EX-ECL-01', 'EX-ECL-02', 'EX-ECL-03', 'EX-ECL-06', 'EX-ECL-07', 'EX-ECL-09'].forEach(id => ok(raised(p, id), `${c}: ${id} raised`));
  const sc = specCtx(p, eng), st = p.asState().modules.AR;
  let renderOK = true, renderErr = '';
  for (const pg of p.M.pages.filter(x => x.render)) { try { const s = pg.render(st, sc); if (!Array.isArray(s)) renderOK = false; } catch (e) { renderOK = false; renderErr += pg.ref + ': ' + e.message + '; '; } }
  ok(renderOK, `${c}: every working paper renders`, renderErr);
  const wb = Exporter.build(p.asState(), 'AR');
  ok(p.M.pages.filter(x => x.render).every(pg => wb.SheetNames.some(n => n.startsWith(pg.ref + ' '))), `${c}: one sheet per working paper (${wb.SheetNames.length} sheets)`);
}

console.log(`\n${'='.repeat(60)}\n  ${pass} passed, ${fail} failed\n${'='.repeat(60)}\n`);
process.exit(fail ? 1 : 0);
