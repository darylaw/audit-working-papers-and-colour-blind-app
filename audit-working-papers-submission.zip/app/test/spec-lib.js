/* Shared loader for the per-module headless tests (test-cash.js, test-ap.js, test-accr.js).
   Loads the app sources into a vm context in the contract order:
   core.js → spec.js → ppe.js → modules.js → src/modules/<files> → xlsxfile.js → xlsxout.js   */

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const APP = path.join(__dirname, '..');
const SRC = path.join(APP, 'src');
const OUT = path.resolve(APP, '..', 'synthetic-data', 'out');

function load(moduleFiles) {
  const XLSX = require(path.join(SRC, 'vendor', 'xlsx.full.min.js'));
  XLSX.set_fs(fs);
  const ctx = vm.createContext({ XLSX, console, Date, Math, JSON, Object, Array, String, Number, isNaN, parseFloat, parseInt, Map, Set, Intl, RegExp, Error });
  const order = [['core.js', 'Core'], ['spec.js', 'SpecUI'], ['ppe.js', 'PPEModule'], ['modules.js', 'Modules']];
  for (const [f, name] of order) vm.runInContext(fs.readFileSync(path.join(SRC, f), 'utf8') + `\n;globalThis.${name} = ${name};` + (f === 'spec.js' ? 'globalThis.SpecXL = SpecXL;' : ''), ctx, { filename: f });
  for (const f of moduleFiles) vm.runInContext(fs.readFileSync(path.join(SRC, 'modules', f), 'utf8'), ctx, { filename: f });
  for (const [f, name] of [['xlsxstyle.js', 'StyledXLSX'], ['wpstyle.js', 'WPStyle'], ['xlsxfile.js', 'FileExporter'], ['xlsxout.js', 'Exporter']])
    vm.runInContext(fs.readFileSync(path.join(SRC, f), 'utf8') + String.fromCharCode(10) + ';globalThis.' + name + ' = ' + name + ';', ctx, { filename: f });
  return { XLSX, ctx, Core: ctx.Core, Modules: ctx.Modules, Exporter: ctx.Exporter, SpecXL: ctx.SpecXL,
           StyledXLSX: ctx.StyledXLSX, WPStyle: ctx.WPStyle };
}

function counter() {
  const c = { pass: 0, fail: 0 };
  c.ok = (cond, msg, extra) => { if (cond) { c.pass++; console.log('  PASS  ' + msg); } else { c.fail++; console.log('  FAIL  ' + msg + (extra ? '  → ' + extra : '')); } };
  c.done = () => { console.log(`\n${'='.repeat(60)}\n  ${c.pass} passed, ${c.fail} failed\n${'='.repeat(60)}\n`); process.exit(c.fail ? 1 : 0); };
  return c;
}

const money = n => n == null ? '—' : Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

function engagement(Core, yearEnd, om) {
  const e = { client: 'Test Entity Pte. Ltd.', firmRef: 'TEST/001', yearEnd, preparedBy: 'AB', datePrepared: '2026-01-15', reviewedBy: 'CD', dateReviewed: '2026-01-20',
    currency: 'USD', framework: 'IFRS / SFRS(I)', indexRef: {},
    materiality: Core.computeMateriality({ basis: 'turnover', basisLabel: 'Turnover', benchmark: om / 0.02, rate: 0.02, pmPct: 0.75, trivialPct: 0.05 }), tbLink: {} };
  e.yearEndDate = new Date(yearEnd + 'T00:00:00Z');
  const d = new Date(e.yearEndDate.getTime()); d.setUTCDate(d.getUTCDate() + 1); d.setUTCFullYear(d.getUTCFullYear() - 1);  /* day first, then year: FYE 28 Feb 2025 -> FYS 1 Mar 2024, not 29 Feb */ e.fyStartDate = d;
  return e;
}

/* detect → clean → map → build → runTests, exactly as the shell does. */
function pipeline(L, file, moduleCode, eng, cfgOverride = {}, prep) {
  const { Core, Modules } = L;
  const M = Modules.byCode[moduleCode];
  const buf = fs.readFileSync(file);
  const wbData = Core.readWorkbook(buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength), path.basename(file));
  const sheet = wbData.sheets[0];
  const headerRow = Core.detectHeader(sheet.rows);
  const clean = Core.cleanTable(sheet.rows, headerRow);
  const mapping = Core.proposeMapping(clean.headers, M.fields, clean.rows.filter(r => r.__kind === 'data').slice(0, 40));
  const built = Core.buildRecords(clean, M.fields, mapping);
  const cfg = M.defaultConfig();
  Object.assign(cfg, cfgOverride);
  if (prep) prep(built.records, cfg);            // e.g. seed auditor inputs in r.__wp before compute
  const res = Core.runTests(M, built.records, cfg, eng);
  const p = { M, wbData, sheet, headerRow, clean, mapping, built, cfg, res, records: built.records, exceptions: res.exceptions, derived: res.derived, eng,
    missingRequired() { return M.fields.filter(f => f.required && !mapping[f.key] && !(f.satisfiedByGroup && clean.hasGroups)).map(f => f.key); },
    ctx() { return { eng, cfg, d: res.derived, recs: built.records.filter(r => !r.__excluded), all: built.records, money: x => x, money0: x => x, pct: x => x,
      fmtDate: Core.fmtDate, r2: n => n == null ? null : Math.round(n * 100) / 100, pm: eng.materiality.pm, trivial: eng.materiality.trivial, M }; },
    state() { return { engagement: eng, modules: { [moduleCode]: { code: moduleCode, records: built.records, exceptions: res.exceptions, derived: res.derived, mapping,
      sources: [{ fileName: path.basename(file), hash: wbData.hash, sheetName: sheet.name, headerRow, rowCount: built.records.length, uploadedAt: wbData.uploadedAt, rawRows: sheet.rows }],
      config: cfg, cleanLog: clean.log, mapIssues: built.issues, edits: [], adjustments: [], aiBlocks: [], pageNotes: {}, trail: [], comments: '', conclusion: '' } } }; },
    /* every render() page returns an array; each maps to one export sheet */
    renderAll(t, label) {
      const st = this.state().modules[moduleCode];
      const c = this.ctx();
      for (const pg of M.pages.filter(p => p.render)) {
        let specs = null, err = null;
        try { specs = pg.render(st, c); } catch (e) { err = e; }
        t.ok(Array.isArray(specs) && specs.length > 0 && !err, `${label}: ${pg.ref} ${pg.title} renders ${specs ? specs.length + ' specs' : ''}`, err && (err.stack || err.message));
        if (specs) { let tErr = null; try { L.SpecXL.toRows(specs, pg.id, st); } catch (e) { tErr = e; } t.ok(!tErr, `${label}: ${pg.ref} converts to worksheet rows`, tErr && tErr.message); }
        if (pg.flag) { let fErr = null; try { pg.flag(st, res.derived); } catch (e) { fErr = e; } t.ok(!fErr, `${label}: ${pg.ref} flag() does not throw`, fErr && fErr.message); }
      }
    },
    exportCheck(t, label) {
      const wb = L.Exporter.build(this.state(), moduleCode);
      const rendered = M.pages.filter(p => p.render);
      const expected = rendered.map(p => `${p.ref} ${p.title}`.replace(/[\[\]\*\?\/\\:]/g, '').slice(0, 31));
      const missing = expected.filter(n => !wb.SheetNames.includes(n));
      t.ok(missing.length === 0, `${label}: one sheet per rendered page (${rendered.length} pages)`, missing.join(', '));
      ['00 Index', 'Exceptions', '01 Source 1', '02 Cleaned data', '03 Mapping'].forEach(n => t.ok(wb.SheetNames.includes(n), `${label}: sheet "${n}"`));
      return wb;
    }
  };
  return p;
}

const expectedExceptions = (area, client) => JSON.parse(fs.readFileSync(path.join(OUT, '_expected-exceptions.json'), 'utf8')).seeded_exceptions
  .filter(x => x.area === area && x.client === client);

module.exports = { load, counter, money, engagement, pipeline, expectedExceptions, OUT, APP, fs, path };
