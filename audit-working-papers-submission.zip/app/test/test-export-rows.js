const S = require('./spec-lib');
const L = S.load(['accr.js']);
const t = S.counter();
const eng = S.engagement(L.Core, '2025-02-28', 145000);
const p = S.pipeline(L, S.path.join(S.OUT, 'client-a', 'PBC-ACC-01 Accruals schedule 2025-02-28.xlsx'), 'ACCR', eng);
const wb = L.Exporter.build(p.state(), 'ACCR');
const ws = wb.Sheets[wb.SheetNames.find(n => n.startsWith('U4.1 '))];
const first = Object.keys(ws).find(k => /^F\d+$/.test(k) && ws[k].f && !ws[k].f.startsWith('SUM('));
const row = +first.slice(1);
t.ok(ws[first].f === `C${row}+D${row}-E${row}`, 'movement calculation references its own final worksheet row');
t.ok(ws['H' + row].f === `G${row}-F${row}`, 'cast difference references its own final worksheet row');
t.ok(Math.abs(ws['C'+row].v + ws['D'+row].v - ws['E'+row].v - p.records[0].__computedClose) < 0.01, 'formula precedents agree with deterministic accrual computation');
const sum = Object.keys(ws).find(k => /^C\d+$/.test(k) && ws[k].f?.startsWith('SUM('));
t.ok(ws[sum].f === `SUM(C${row}:C${row+p.records.length-1})`, 'total covers actual detail rows, excluding header and total');
for (const offset of [0, 8, 15]) {
  const specs = [{ type:'table', columns:[{key:'label',label:'Item'}, {key:'amount',label:'Amount',sum:true}, {key:'double',label:'Double',formula:r=>`B${r}*2`}], rows:[{label:'One',amount:7},{label:'Two',amount:13}] }];
  const { a, ops } = L.SpecXL.toRows(specs, 'test', {config:{}}, offset);
  const sheet = L.XLSX.utils.aoa_to_sheet([...Array.from({length:offset},()=>[]), ...a]);
  L.SpecXL.apply(sheet, ops, offset);
  t.ok(sheet['C'+(offset+2)].f === `B${offset+2}*2`, 'row formula at offset '+offset);
  t.ok(sheet['B'+(offset+4)].f === `SUM(B${offset+2}:B${offset+3})`, 'total formula at offset '+offset);
}
t.done();
