/* Headless test of the EXP (operating expenses) audit file against the synthetic expense listings.
   Run:  node test/test-exp.js                                                                      */
const { load, counter, money, engagement, pipeline, expectedExceptions, OUT, path, fs } = require('./spec-lib');
const L = load(['exp.js']);
const t = counter();
const CODE = 'EXP';

const CLIENTS = [
  { c: 'client-a', ye: '2025-02-28', file: 'PBC-EXP-01 Expense listing 2025-02-28.xlsx' },
  { c: 'client-b', ye: '2025-09-30', file: 'PBC-EXP-01 Expense listing 2025-09-30.xlsx' },
  { c: 'client-d', ye: '2025-09-30', file: 'PBC-EXP-01 Expense listing 2025-09-30.xlsx' }
];

console.log('\n=== EXP — module registration ===');
t.ok(L.Modules.byCode.EXP && L.Modules.byCode.EXP.name === 'Operating Expenses', 'EXP registered via Modules.register');
t.ok(L.Modules.byCode.EXP.pages.filter(p => p.render).length === 7, 'seven rendered working papers (Z3, Z3.1–Z3.6)');

for (const { c, ye, file: f } of CLIENTS) {
  const eng = engagement(L.Core, ye, 145000);
  const file = path.join(OUT, c, f);
  if (!fs.existsSync(file)) { console.log('  skip (missing) ' + f); continue; }
  const label = c;
  console.log(`\n=== ${label} / ${f} ===`);
  const p = pipeline(L, file, CODE, eng, { sampleN: 8 });
  const d = p.derived, T = d.leadTotals;
  console.log(`  header row ${p.headerRow + 1}; ${p.records.length} documents; ${T.accounts} accounts; total ${money(T.total)}; conflicts ${T.conflicts.length}; after YE ${T.afterYE.length}; prior ${T.beforeFY.length}; credits ${T.credits.length}`);
  t.ok(p.missingRequired().length === 0, `${label}: required fields mapped`, p.missingRequired().join(', '));
  t.ok(p.mapping.account_code && p.mapping.account_name && p.mapping.account_code.colIndex !== p.mapping.account_name.colIndex, `${label}: account code and name mapped to different columns (${p.mapping.account_code?.heading} / ${p.mapping.account_name?.heading})`);
  t.ok(p.records.length === 349, `${label}: 349 documents (subtotal held out)`, p.records.length);
  t.ok(Math.abs(T.total - p.records.reduce((s, r) => s + (r.amount || 0), 0)) < 0.005, `${label}: lead total casts to the listing`);
  t.ok(T.accounts >= 30 && Math.abs(d.lead.reduce((s, l) => s + l.amount, 0) - T.total) < 0.05, `${label}: lead by account cross-casts (${T.accounts} accounts)`);
  t.ok(T.conflicts.length >= 1 && T.conflicts.some(l => /Repairs/i.test(l.name)), `${label}: account code conflict detected on the misposted repairs line`, JSON.stringify(T.conflicts.map(l => l.label)));

  /* planted exceptions */
  const planted = expectedExceptions('Expenses', c);
  for (const x of planted) {
    const id = x.exception.split(' ')[0];
    const hit = p.exceptions.find(e => e.id === id && e.recordKey === x.record_key);
    t.ok(hit, `${label}: ${x.exception} → ${x.record_key}`, JSON.stringify(p.exceptions.filter(e => e.id === id).map(e => e.recordKey).slice(0, 12)));
  }
  const e04 = p.exceptions.filter(e => e.id === 'EX-EXP-04');
  t.ok(e04.length === 1 && e04[0].actual === 200000 && e04[0].severity === 'above-pm', `${label}: EX-EXP-04 fires once, for the 200,000 round sum, at above-pm`, JSON.stringify(e04.map(e => [e.recordKey, e.actual])));
  const e06 = p.exceptions.filter(e => e.id === 'EX-EXP-06');
  t.ok(e06.every(e => e.actual >= 5000 && /repair|maintenance/i.test(e.actual === 84600 ? 'repairs' : p.records.find(r => r.__srcRow === e.srcRow).account_name)), `${label}: EX-EXP-06 only from screened accounts at or above the threshold (${e06.length})`);
  t.ok(p.exceptions.some(e => e.id === 'EX-EXP-08' && e.actual && /Repairs/.test(e.actual)), `${label}: EX-EXP-08 code conflict raised on the misposted line`);
  const e03 = p.exceptions.filter(e => e.id === 'EX-EXP-03');
  t.ok(e03.length >= 1 && e03.every(e => /row \d+/.test(e.detail)), `${label}: duplicates name the original row (${e03.length})`);

  /* Z3.1 monthly */
  t.ok(d.monthKeys.length === 12 && d.monthly.length === T.accounts, `${label}: monthly matrix has 12 months × ${T.accounts} accounts`);
  t.ok(Math.abs(d.monthTotals.reduce((s, v) => s + v, 0) + d.monthly.reduce((s, m) => s + m.outside, 0) - T.total) < 0.05, `${label}: months + outside-year cross-cast to the total`);
  t.ok(d.spikes.every(s => s.amount > s.avg), `${label}: flagged account-months are above their average (${d.spikes.length})`);
  t.ok(p.exceptions.filter(e => e.id === 'EX-EXP-22').length === d.spikes.length, `${label}: one EX-EXP-22 per flagged account-month`);

  /* Z3.2 testing */
  const S = d.testing;
  console.log(`  Z3.2: threshold ${money(S.threshold)}; ${S.key.length} key + ${S.sample.length} sample of ${S.pop.length}; coverage ${S.coverage}%`);
  t.ok(S.threshold === eng.materiality.pm, `${label}: testing threshold defaults to performance materiality`);
  t.ok(S.key.every(r => r.amount >= S.threshold) && S.sample.every(r => r.amount < S.threshold), `${label}: key items above and sample below the threshold`);
  t.ok(S.pop.every(r => r.amount > 0 && !r.__afterYE), `${label}: population excludes credits and post year-end items`);
  t.ok(S.sample.length === 8, `${label}: sample size honoured`);
  t.ok(S.key.length >= 1 && S.coverage > 0 && S.coverage <= 100.01, `${label}: coverage ${S.coverage}%`);
  t.ok(Math.abs(S.byAccount.reduce((s, a) => s + a.selectedValue, 0) - (S.keyValue + S.sampleValue)) < 0.05, `${label}: coverage by account cross-casts to the selection`);
  const p2 = pipeline(L, file, CODE, eng, { sampleN: 8 });
  t.ok(JSON.stringify(p2.derived.testing.sample.map(r => r.__srcRow)) === JSON.stringify(S.sample.map(r => r.__srcRow)), `${label}: same seed → identical sample`);
  const p3 = pipeline(L, file, CODE, eng, { sampleN: 8, sampleSeed: 7 });
  t.ok(JSON.stringify(p3.derived.testing.sample.map(r => r.__srcRow)) !== JSON.stringify(S.sample.map(r => r.__srcRow)), `${label}: different seed → different sample`);
  const pA = pipeline(L, file, CODE, eng, { sampleN: 2, sampleMode: 'per-account' });
  const perAcc = pA.derived.testing.sample.reduce((m, r) => (m[r.__accKey] = (m[r.__accKey] || 0) + 1, m), {});
  t.ok(Object.values(perAcc).every(n => n <= 2) && Object.keys(perAcc).length >= T.accounts - 2, `${label}: per-account mode draws up to N per account (${Object.keys(perAcc).length} accounts)`);

  /* Z3.3 cut-off, Z3.4 capital, Z3.6 legal */
  t.ok(d.cutoff.afterYE.length >= 1 && d.cutoff.beforeFY.length >= 1 && d.cutoff.rows.length >= d.cutoff.afterYE.length + d.cutoff.beforeFY.length, `${label}: cut-off page lists post year-end and prior-period items`);
  t.ok(d.capital.rows.some(r => r.amount === 84600) && d.capital.accounts.length >= 1, `${label}: capital screen lists the 84,600 repairs item`);
  t.ok(d.legal.rows.length >= 20 && d.legal.accounts.some(a => /Professional/.test(a)) && d.legal.accounts.some(a => /Audit/.test(a)), `${label}: legal & professional page carries 100% of professional and audit fee items (${d.legal.rows.length})`);
  t.ok(Math.abs(d.legal.total - d.legal.rows.reduce((s, r) => s + r.amount, 0)) < 0.005, `${label}: legal total casts`);
  t.ok(d.rp.noPayee.length >= 1 && d.rp.dups.length >= 1 && d.rp.roundRows.length >= 1, `${label}: Z3.5 lists no-payee, duplicate and round-sum items`);

  /* TB tie per account */
  const acc = d.lead[0];
  const pTB = pipeline(L, file, CODE, eng, { ['tb:' + acc.key]: acc.amount - 50 });
  const e20 = pTB.exceptions.filter(e => e.id === 'EX-EXP-20');
  t.ok(e20.length === 1 && e20[0].recordKey === acc.label && Math.abs(e20[0].difference - 50) < 0.005, `${label}: EX-EXP-20 by account fires for the account entered only`, JSON.stringify(e20));
  t.ok(!pipeline(L, file, CODE, eng, { tbTotal: T.total }).exceptions.some(e => e.id === 'EX-EXP-20'), `${label}: EX-EXP-20 silent when the total TB agrees`);
  const pPY = pipeline(L, file, CODE, eng, { ['py:' + acc.key]: acc.amount / 2 });
  t.ok(pPY.exceptions.some(e => e.id === 'EX-EXP-21' && e.recordKey === acc.label), `${label}: EX-EXP-21 movement vs PY beyond threshold`);

  p.renderAll(t, label);
  p.exportCheck(t, label);
}

/* ---------------------------------------------------------------------- */
console.log('\n=== EXP — auditor inputs drive the tests (client-a) ===');
{
  const eng = engagement(L.Core, '2025-02-28', 145000);
  const file = path.join(OUT, 'client-a', 'PBC-EXP-01 Expense listing 2025-02-28.xlsx');
  const base = pipeline(L, file, CODE, eng, { sampleN: 5 });
  const sel = base.derived.testing.selected[0];
  const pV = pipeline(L, file, CODE, eng, { sampleN: 5 }, recs => { const r = recs.find(x => x.__srcRow === sel.__srcRow); r.__wp = { testing: { invNo: r.doc_no, amountPerInv: r.amount - 10, natureCorrect: 'N', periodCorrect: 'Y', comment: 'Charged to wrong account' } }; });
  const e11 = pV.exceptions.find(e => e.id === 'EX-EXP-11'), e12 = pV.exceptions.find(e => e.id === 'EX-EXP-12');
  t.ok(e11 && Math.abs(e11.difference - 10) < 0.005 && e11.srcRow === sel.__srcRow, 'EX-EXP-11 amount per invoice difference from the vouching input');
  t.ok(e12 && /wrong account/.test(e12.detail) && pV.derived.testing.exceptions.length === 1, 'EX-EXP-12 wrong nature from the vouching input');
  const legalRow = base.derived.legal.rows[0];
  const pLg = pipeline(L, file, CODE, eng, {}, recs => { const r = recs.find(x => x.__srcRow === legalRow.__srcRow); r.__wp = { legal: { invoice: 'Y', litigation: 'Y', nature: 'Defence of supplier claim' } }; });
  const e13 = pLg.exceptions.find(e => e.id === 'EX-EXP-13');
  t.ok(e13 && e13.severity === 'above-trivial' && /supplier claim/.test(e13.detail) && pLg.derived.legal.litigation.length === 1, 'EX-EXP-13 litigation indicator from the legal fees input');
  const pCap = pipeline(L, file, CODE, eng, {}, recs => recs.filter(r => r.amount === 84600).forEach(r => r.__wp = { capital: { capitalise: 'Y', nature: 'New compressor' } }));
  t.ok(pCap.derived.capital.toCapitalise.length === 1 && pCap.derived.capital.toCapitaliseValue === 84600, 'capital screen totals the items marked to capitalise');
  const pCapT = pipeline(L, file, CODE, eng, { capThreshold: 100000 });
  t.ok(!pCapT.exceptions.some(e => e.id === 'EX-EXP-06'), 'raising the capitalisation threshold silences EX-EXP-06');
  const pRP = pipeline(L, file, CODE, eng, { rpNames: 'Brookvale Steel Supply, Fernway Freight' });
  const e09 = pRP.exceptions.filter(e => e.id === 'EX-EXP-09');
  t.ok(e09.length >= 2 && e09.every(e => /Brookvale|Fernway/.test(e.actual)), `EX-EXP-09 raised for payees named as related parties (${e09.length})`);
  const pRnd = pipeline(L, file, CODE, eng, { testThreshold: 500000 });
  t.ok(!pRnd.exceptions.some(e => e.id === 'EX-EXP-04') && pRnd.exceptions.some(e => e.id === 'EX-EXP-10' && e.actual === 200000), 'round sum below a raised threshold drops to informational EX-EXP-10');
  const pCut = pipeline(L, file, CODE, eng, {}, recs => recs.filter(r => r.__srcRow === base.derived.cutoff.rows[0].__srcRow).forEach(r => r.__wp = { cutoff: { correct: 'N' } }));
  t.ok(pCut.derived.cutoff.wrong.length === 1 && pCut.derived.cutoff.tested === 1, 'cut-off inputs feed the tested / wrong-period counts');

  const wb = pLg.exportCheck(t, 'client-a with inputs');
  const ws = wb.Sheets[wb.SheetNames.find(x => x.startsWith('Z3.6 '))];   // sheet names are cut to Excel's 31 characters
  t.ok(ws && Object.values(ws).some(c => c && c.v === 'Defence of supplier claim'), 'Z3.6 export carries the nature of service entered');
  const out = path.join(__dirname, 'out-EXP-file.xlsx');
  L.XLSX.writeFile(wb, out);
  const re = L.XLSX.readFile(out);
  t.ok(re.SheetNames.length === wb.SheetNames.length, 'workbook survives the Excel round-trip');
  fs.unlinkSync(out);
  const st = pLg.state().modules.EXP;
  const text = L.Modules.byCode.EXP.suggestConclusion(st, pLg.ctx());
  t.ok(typeof text === 'string' && text.length > 100, 'suggestConclusion produces text');
}

t.done();
