/* Headless test of the LEASE audit file against the synthetic lease schedules.
   Run:  node test/test-lease.js                                               */
const { load, counter, money, engagement, pipeline, expectedExceptions, OUT, path, fs } = require('./spec-lib');
const L = load(['lease.js']);
const t = counter();
const CODE = 'LEASE';

const CLIENTS = [
  { c: 'client-a', ye: '2025-02-28', file: 'PBC-LSE-01 Lease schedule 2025-02-28.xlsx', n: 4 },
  { c: 'client-b', ye: '2025-09-30', file: 'PBC-LSE-01 Lease schedule 2025-09-30.xlsx', n: 4 },
  { c: 'client-d', ye: '2025-09-30', file: 'PBC-LSE-01 Lease schedule 2025-09-30.xlsx', n: 4 }
];
const REQUIRED = ['lease', 'commence', 'term', 'rate', 'payment', 'rou_open', 'rou_dep', 'liab_open', 'interest', 'payments', 'liab_close'];

console.log('\n=== LEASE — module registration ===');
t.ok(L.Modules.byCode.LEASE && L.Modules.byCode.LEASE.name === 'Leases (lessee)', 'LEASE registered via Modules.register');
t.ok(L.Modules.byCode.LEASE.pages.filter(p => p.render).length === 7, 'seven rendered working papers (Y3, Y3.1, Y3.2, Y3.4–Y3.7)');
t.ok(L.Modules.byCode.LEASE.pages[L.Modules.byCode.LEASE.pages.length - 1].kind === 'conclusion', 'conclusion page last');

for (const { c, ye, file: f, n } of CLIENTS) {
  const eng = engagement(L.Core, ye, 145000);
  const file = path.join(OUT, c, f);
  const label = c;
  console.log(`\n=== ${label} ===`);
  const p = pipeline(L, file, CODE, eng);
  const d = p.derived, T = d.totals;
  console.log(`  header row ${p.headerRow + 1}; ${p.records.length} leases; liability ${money(T.liabOpen)} + interest ${money(T.interest)} − payments ${money(T.pay)} = ${money(T.castCalc)} vs closing ${money(T.liabClose)}; interest audit ${money(T.intAudit)}; dep ${money(T.dep)} vs audit ${money(T.depAudit)}`);
  t.ok(p.missingRequired().length === 0, `${label}: required fields mapped`, p.missingRequired().join(', '));
  for (const k of [...REQUIRED, 'initial', 'rou_close'])
    t.ok(p.mapping[k], `${label}: ${k} mapped (${p.mapping[k]?.heading} ${p.mapping[k]?.letter})`);
  t.ok(p.mapping.payment && p.mapping.payments && p.mapping.payment.heading === 'Monthly Payment' && p.mapping.payments.heading === 'Payments', `${label}: monthly payment and payments-in-year resolved to distinct columns`);
  t.ok(p.mapping.rou_open.heading === 'ROU B/F' && p.mapping.liab_open.heading === 'Liability B/F' && p.mapping.rou_close.heading === 'ROU C/F' && p.mapping.liab_close.heading === 'Liability C/F', `${label}: ROU and liability b/f, c/f columns not confused`);
  t.ok(p.records.length === n, `${label}: ${n} leases read (TOTAL and footnotes held out)`);
  t.ok(p.records.every(r => r.commence instanceof Date && r.__termMonths > 0 && r.__ratePct > 0 && r.payment > 0), `${label}: commencement, term, rate and payment parsed`);
  t.ok(d.termUnit === 'months' && !d.rateIsFraction, `${label}: term detected in months; rates read as percentages`);
  t.ok(d.conventionAuto && d.convention === (c === 'client-a' ? 'month-next' : 'month-incl'), `${label}: payment convention auto-detected as ${d.convention}`);
  t.ok(p.records.every(r => r.__dep >= 0 && r.__pay >= 0), `${label}: depreciation and payments taken at absolute value`);

  /* initial measurement and rebuild */
  t.ok(p.records.every(r => Math.abs(r.__initDiff) < 0.02), `${label}: PV of the payments agrees to the initial liability per schedule for every lease`, p.records.map(r => r.__initDiff).join(','));
  t.ok(p.records.every(r => Math.abs(r.__openDiff) < 0.02), `${label}: rebuilt opening liability agrees to the schedule for every lease`, p.records.map(r => r.__openDiff).join(','));
  t.ok(p.records.every(r => Math.abs(r.__intDiff) < 0.02), `${label}: rebuilt interest agrees to the cent for every lease`, p.records.map(r => r.__intDiff).join(','));
  t.ok(p.records.every(r => Math.abs(r.__payDiff) < 0.005), `${label}: contractual payments agree to payments per schedule`, p.records.map(r => r.__payDiff).join(','));
  t.ok(p.records.every(r => Math.abs(r.__rouOpenDiff) < 0.02), `${label}: rebuilt ROU b/f agrees to the schedule`, p.records.map(r => r.__rouOpenDiff).join(','));
  const factory = p.records.find(r => r.lease === 'Factory unit - Block A');
  const annex = p.records.find(r => r.lease === 'Warehouse annex');
  t.ok(factory.__elapsed + factory.__months + factory.__remainingAtYE === factory.__termMonths, `${label}: months before, in and after the year sum to the term`);
  t.ok(p.records.filter(r => r.lease !== 'Factory unit - Block A').every(r => Math.abs(r.__closeDiff) < 0.02), `${label}: rebuilt closing liability agrees on unseeded leases`);
  t.ok(Math.abs(factory.__castDiff - 1850) < 0.005, `${label}: factory liability movement fails to cast by the seeded 1,850`, factory.__castDiff);
  t.ok(factory.__closeExplainedByCast && !factory.__closeBreak, `${label}: factory closing difference is explained by the cast difference and not raised twice`);

  /* planted exceptions */
  const exp = expectedExceptions('Leases', c);
  t.ok(exp.length === 2, `${label}: two planted lease exceptions expected`);
  const has = (id, key) => p.exceptions.some(e => e.id === id && e.recordKey === key);
  for (const x of exp) t.ok(has(x.exception.slice(0, 9), x.record_key), `${label}: planted ${x.exception} raised for "${x.record_key}"`);
  const e01 = p.exceptions.filter(e => e.id === 'EX-LSE-01');
  t.ok(e01.length === 1 && Math.abs(e01[0].difference - 1850) < 0.005, `${label}: EX-LSE-01 raised once, quantified at 1,850`, JSON.stringify(e01.map(e => [e.recordKey, e.difference])));
  const e02 = p.exceptions.filter(e => e.id === 'EX-LSE-02');
  t.ok(e02.length === 1 && e02[0].recordKey === 'Warehouse annex', `${label}: EX-LSE-02 raised only for the warehouse annex`, JSON.stringify(e02.map(e => e.recordKey)));
  t.ok(Math.abs(annex.__dep / annex.__depAudit - 0.6) < 0.001, `${label}: annex depreciation recorded is 60% of the recalculation (seeded ×0.6)`, annex.__dep / annex.__depAudit);
  t.ok(annex.__impliedTerm > annex.__termMonths * 1.5, `${label}: charge implies a term (${Math.round(annex.__impliedTerm)} m) well beyond the ${annex.__termMonths}-month lease`);
  t.ok(/implies a term/.test(e02[0].detail), `${label}: EX-LSE-02 detail explains the implied term`);
  t.ok(p.exceptions.filter(e => e.id === 'EX-LSE-08').length === 1 && p.exceptions.find(e => e.id === 'EX-LSE-08').recordKey === 'Warehouse annex', `${label}: ROU roll-forward fails to cast only for the annex (consequence of the seeded charge)`);
  for (const id of ['EX-LSE-03', 'EX-LSE-04', 'EX-LSE-05', 'EX-LSE-06', 'EX-LSE-07', 'EX-LSE-14', 'EX-LSE-15'])
    t.ok(!p.exceptions.some(e => e.id === id), `${label}: ${id} silent on a schedule that follows the agreement terms`);
  console.log('  exceptions: ' + JSON.stringify(p.exceptions.reduce((m, e) => { m[e.id] = (m[e.id] || 0) + 1; return m; }, {})));

  /* split and maturity */
  t.ok(p.records.every(r => r.__curAudit >= 0 && r.__curAudit <= (r.liab_close || 0) + 0.01 && Math.abs(r.__curAudit + r.__ncAudit - (r.liab_close || 0)) < 0.02), `${label}: audit split casts to the closing liability`);
  const expired = p.records.filter(r => r.__remainingAtYE === 0);
  t.ok(expired.length >= 1 && expired.every(r => r.__curAudit === 0 && r.__undiscounted === 0 && Math.abs(r.liab_close || 0) < 0.01), `${label}: expired leases carry no current portion and no undiscounted payments`);
  t.ok(p.records.filter(r => r.__remainingAtYE > 12).every(r => r.__curAudit > 0 && r.__ncAudit > 0), `${label}: running leases split between current and non-current`);
  t.ok(Math.abs((T.undiscounted - T.unearned) - T.liabClose) < 0.05 && d.maturity.reconciles, `${label}: undiscounted payments less future interest reconcile to the carrying amount`);
  t.ok(p.records.every(r => Math.abs(r.__m1 + r.__m2to5 + r.__m5 - r.__undiscounted) < 0.01), `${label}: maturity bands sum to total undiscounted`);
  const van = p.records.find(r => r.lease === 'Motor vehicle - delivery van');
  t.ok(Math.abs(van.__m1 - van.payment * Math.min(12, van.__remainingAtYE)) < 0.01, `${label}: within-one-year band is twelve monthly payments`);
  t.ok(!p.exceptions.some(e => e.id === 'EX-LSE-09' || e.id === 'EX-LSE-10'), `${label}: split tests silent when the client split is not yet entered`);

  /* conventions */
  const pNext = pipeline(L, file, CODE, eng, { convention: d.convention === 'month-next' ? 'month-incl' : 'month-next' });
  t.ok(pNext.records.some(r => r.__intAudit !== p.records.find(x => x.__srcRow === r.__srcRow).__intAudit) && pNext.records.some(r => r.__payBreak), `${label}: forcing the other convention shifts the rebuild and breaks the payment tie`);
  const pAdv = pipeline(L, file, CODE, eng, { payTiming: 'advance' });
  t.ok(pAdv.records.every(r => r.__initAudit > p.records.find(x => x.__srcRow === r.__srcRow).__initAudit), `${label}: payments in advance raise the present value`);
  const pClient = pipeline(L, file, CODE, eng, { rebuildBasis: 'client' });
  t.ok(pClient.records.every(r => Math.abs(r.__intDiff) < 0.02) && pClient.exceptions.some(e => e.id === 'EX-LSE-01'), `${label}: rolling from the client's opening still agrees on interest and still catches the cast`);
  const pTight = pipeline(L, file, CODE, eng, { recTol: 0.005 });
  t.ok(pTight.exceptions.filter(e => e.id === 'EX-LSE-02').length === 1, `${label}: tightening the tolerance keeps EX-LSE-02 to the annex`);
  const pYears = pipeline(L, file, CODE, eng, { termUnit: 'years' });
  t.ok(pYears.records.every(r => r.__termMonths === Math.round(r.term * 12)), `${label}: forcing years multiplies the term by twelve`);

  /* auditor inputs: lead, split, agreement, exemptions */
  const cfgIn = { tbRou: T.rouClose, tbLiab: T.liabClose + 100, pnlInterest: T.interest, pnlDepreciation: T.dep - 25,
    exRows: 3, 'exDesc:ex1': 'Photocopier', 'exType:ex1': 'Low-value underlying asset', 'exValue:ex1': 3200, 'exExpense:ex1': 1800,
    'exDesc:ex2': 'Site office container', 'exType:ex2': 'Short-term (12 months or less)', 'exTerm:ex2': 18, 'exExpense:ex2': 9000,
    'exDesc:ex3': 'Storage unit', 'exType:ex3': 'Short-term (12 months or less)', 'exTerm:ex3': 6, 'exOption:ex3': 'N', 'exExpense:ex3': 2400, pnlExempt: 13200 };
  const pi = pipeline(L, file, CODE, eng, cfgIn, recs => {
    const F = recs.find(r => r.lease === 'Factory unit - Block A'), V = recs.find(r => r.lease === 'Motor vehicle - delivery van');
    F.__wp = { lead: { pyRou: F.rou_open, pyLiab: F.liab_open + 10 }, split: { clientCurrent: 400000, clientNonCurrent: F.liab_close - 400000 }, agree: { agrSighted: 'Y', agrCommence: 'Y', agrTerm: 'Y', agrPayment: 'N', agrRate: 'Y', modified: 'Y' } };
    V.__wp = { lead: { pyRou: V.rou_open, pyLiab: V.liab_open }, split: { clientCurrent: 21000, clientNonCurrent: V.liab_close - 21000 - 500 }, agree: { agrSighted: 'Y', agrCommence: 'Y', agrTerm: 'Y', agrPayment: 'Y', agrRate: 'Y', ibrSupport: 'Y' }, rou: { idc: 1200 } };
  });
  const ex = id => pi.exceptions.filter(e => e.id === id);
  t.ok(ex('EX-LSE-20').length === 1 && ex('EX-LSE-20')[0].recordKey === 'Lease liabilities' && Math.abs(ex('EX-LSE-20')[0].difference + 100) < 0.005, `${label}: EX-LSE-20 raised for the liability TB difference only`);
  t.ok(ex('EX-LSE-21').length === 0 && ex('EX-LSE-22').length === 1 && Math.abs(ex('EX-LSE-22')[0].difference - 25) < 0.005, `${label}: interest ties to the P&L; depreciation differs by 25 (EX-LSE-22)`);
  t.ok(ex('EX-LSE-23').length === 1 && ex('EX-LSE-23')[0].recordKey === 'Factory unit - Block A', `${label}: EX-LSE-23 raised for the one opening balance not agreeing to prior year`);
  const Fi = pi.records.find(r => r.lease === 'Factory unit - Block A'), Vi = pi.records.find(r => r.lease === 'Motor vehicle - delivery van');
  t.ok(ex('EX-LSE-10').length === 1 && ex('EX-LSE-10')[0].recordKey === 'Motor vehicle - delivery van' && Math.abs(ex('EX-LSE-10')[0].difference + 500) < 0.02, `${label}: EX-LSE-10 client split short by 500 on the van`);
  t.ok(Fi.__curDiff != null && Math.abs(Fi.__curDiff - (400000 - Fi.__curAudit)) < 0.01 && ex('EX-LSE-09').some(e => e.recordKey === 'Factory unit - Block A'), `${label}: EX-LSE-09 current portion per client vs audit on the factory`);
  t.ok(pi.derived.split.entered === 2, `${label}: two client splits entered`);
  t.ok(ex('EX-LSE-12').length === 1 && ex('EX-LSE-12')[0].recordKey === 'Factory unit - Block A' && /payment/.test(ex('EX-LSE-12')[0].actual) && ex('EX-LSE-12')[0].severity === 'above-trivial', `${label}: EX-LSE-12 payment not agreed on the factory, above-trivial`);
  t.ok(ex('EX-LSE-13').length === 1 && ex('EX-LSE-13')[0].severity === 'informational', `${label}: EX-LSE-13 modification flagged informationally`);
  t.ok(pi.derived.agreement.vouched === 1 && pi.derived.agreement.sighted === 2 && pi.derived.agreement.ibr === 1, `${label}: agreement vouching counts`);
  t.ok(Math.abs(Vi.__rouInitial - (Vi.__initAudit + 1200)) < 0.01 && Vi.__depAudit > p.records.find(r => r.lease === 'Motor vehicle - delivery van').__depAudit, `${label}: initial direct costs increase the ROU and its depreciation`);
  t.ok(pi.derived.exemptions.rows.length === 3 && pi.derived.exemptions.qualifies === 2 && pi.derived.exemptions.fails.length === 1 && pi.derived.exemptions.fails[0].desc === 'Site office container', `${label}: exemption tests — low-value and 6-month qualify, 18-month does not`);
  t.ok(ex('EX-LSE-11').length === 1 && ex('EX-LSE-11')[0].severity === 'above-trivial' && ex('EX-LSE-11')[0].recordKey === 'Site office container', `${label}: EX-LSE-11 raised for the 18-month lease expensed`);
  t.ok(Math.abs(pi.derived.exemptions.expense - 13200) < 0.005 && ex('EX-LSE-24').length === 0, `${label}: exempt expense ties to the P&L`);
  const pLow = pipeline(L, file, CODE, eng, { ...cfgIn, lowValueThreshold: 3000 });
  t.ok(pLow.derived.exemptions.fails.length === 2, `${label}: lowering the low-value threshold fails the photocopier too`);

  /* pages and export */
  p.renderAll(t, label);
  pi.renderAll(t, label + ' (with inputs)');
  const wb = pi.exportCheck(t, label);
  const ws7 = wb.Sheets[wb.SheetNames.find(x => x.startsWith('Y3.7 '))];
  t.ok(ws7 && Object.values(ws7).some(cell => cell && cell.v === 'Photocopier'), `${label}: Y3.7 export carries the exempt lease entered`);
  const ws1 = wb.Sheets[wb.SheetNames.find(x => x.startsWith('Y3.1 '))];
  t.ok(ws1 && Object.values(ws1).some(cell => cell && cell.f && /\+/.test(cell.f)), `${label}: Y3.1 export carries live cast formulas`);
  const text = L.Modules.byCode.LEASE.suggestConclusion(pi.state().modules.LEASE, pi.ctx());
  t.ok(typeof text === 'string' && text.length > 200 && /does not cast/.test(text), `${label}: suggestConclusion produces text mentioning the cast break`);
}

/* a lease commencing in the year: no opening balance, addition = initial liability */
console.log('\n=== LEASE — lease commencing during the year ===');
{
  const eng = engagement(L.Core, '2025-09-30', 145000);
  const p = pipeline(L, path.join(OUT, 'client-b', 'PBC-LSE-01 Lease schedule 2025-09-30.xlsx'), CODE, eng, {}, recs => {
    const r = recs.find(x => x.lease === 'Forklift');
    r.commence = new Date(Date.UTC(2025, 3, 15)); r.rou_open = 0; r.liab_open = 0; r.initial = null; r.liab_close = null; r.rou_close = null;
  });
  const r = p.records.find(x => x.lease === 'Forklift');
  t.ok(r.__inYear && r.__elapsed === 0 && r.__months === 6 && r.__openAudit === 0, 'in-year lease: no months before the year, six months in the year, nil opening per audit');
  t.ok(Math.abs(r.__liabAdd - r.__initAudit) < 0.01 && r.__closeAudit > 0 && r.__closeAudit < r.__initAudit, 'addition taken as the initial liability and amortised for the months held');
  t.ok(Math.abs(r.__rouInitial - r.__initAudit) < 0.01 && Math.abs(r.__depAudit - r.__rouInitial / 36 * 6) < 0.02, 'ROU depreciation for six months over the 36-month term');
  t.ok(r.__remainingAtYE === 30 && r.__curAudit > 0 && r.__ncAudit > 0, 'thirty months remain; split into current and non-current');
}

/* after year end and nil rate */
console.log('\n=== LEASE — commencement after year end, nil discount rate ===');
{
  const eng = engagement(L.Core, '2025-09-30', 145000);
  const p = pipeline(L, path.join(OUT, 'client-d', 'PBC-LSE-01 Lease schedule 2025-09-30.xlsx'), CODE, eng, {}, recs => {
    recs.find(x => x.lease === 'Forklift').commence = new Date(Date.UTC(2025, 10, 1));
    recs.find(x => x.lease === 'Motor vehicle - delivery van').rate = 0;
  });
  const e14 = p.exceptions.filter(e => e.id === 'EX-LSE-14');
  t.ok(e14.length === 2 && e14.every(e => e.severity === 'above-trivial'), 'EX-LSE-14 raised for the post year-end commencement and the nil rate');
  const van = p.records.find(x => x.lease === 'Motor vehicle - delivery van');
  t.ok(Math.abs(van.__initAudit - van.payment * van.__termMonths) < 0.01 && van.__intAudit === 0, 'nil rate: PV equals the sum of payments and interest is nil');
}

/* round trip */
{
  const eng = engagement(L.Core, '2025-02-28', 145000);
  const p = pipeline(L, path.join(OUT, 'client-a', 'PBC-LSE-01 Lease schedule 2025-02-28.xlsx'), CODE, eng);
  const wb = L.Exporter.build(p.state(), CODE);
  const out = path.join(__dirname, 'out-LEASE-file.xlsx');
  L.XLSX.writeFile(wb, out);
  const re = L.XLSX.readFile(out);
  t.ok(re.SheetNames.length === wb.SheetNames.length, 'workbook survives the Excel round-trip');
  fs.unlinkSync(out);
}

t.done();
