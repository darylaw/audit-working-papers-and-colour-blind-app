/* Headless test of the AP (trade payables) audit file against the synthetic listings.
   Run:  node test/test-ap.js                                                   */
const { load, counter, money, engagement, pipeline, expectedExceptions, OUT, path, fs } = require('./spec-lib');
const L = load(['ap.js']);
const t = counter();
const CODE = 'AP';

const CLIENTS = [
  { c: 'client-a', ye: '2025-02-28', file: 'PBC-AP-01 Trade payables listing 2025-02-28.xlsx' },
  { c: 'client-b', ye: '2025-09-30', file: 'PBC-AP-01 Trade payables listing 2025-09-30.xlsx' },
  { c: 'client-d', ye: '2025-09-30', file: 'PBC-AP-01 Trade payables listing 2025-09-30.xlsx' }
];
/* planted exception id → the invoice reference in _expected-exceptions.json must appear in the raised record key */
const PLANTED = ['EX-AP-01', 'EX-AP-02', 'EX-AP-03', 'EX-AP-04', 'EX-AP-05', 'EX-AP-06', 'EX-AP-07', 'EX-AP-08'];

console.log('\n=== AP — module registration ===');
t.ok(L.Modules.byCode.AP && L.Modules.byCode.AP.name === 'Trade Payables' && L.Modules.byCode.AP.group === 'Liabilities & equity', 'AP registered via Modules.register and replaces nothing else');
t.ok(L.Modules.byCode.AP.pages.filter(p => p.render).length === 6, 'six rendered working papers (U3, U3.1–U3.5)');
t.ok(L.Modules.byCode.AR && L.Modules.byCode.AR.code === 'AR', 'the generic AR module is untouched');

for (const { c, ye, file } of CLIENTS) {
  const eng = engagement(L.Core, ye, 145000);
  const f = path.join(OUT, c, file);
  const label = c;
  console.log(`\n=== AP — ${c} ===`);
  const p = pipeline(L, f, CODE, eng, { circSampleN: 3 });
  const d = p.derived, Lz = d.lead;
  console.log(`  header row ${p.headerRow + 1}; ${p.records.length} open items; ${Lz.supplierCount} suppliers; total ${money(Lz.total)}; currencies ${d.currencies.map(x => x.currency + ' ' + money(x.amount)).join(', ')}`);
  t.ok(p.missingRequired().length === 0, `${label}: required fields mapped (supplier, invoice, date, amount)`, p.missingRequired().join(', '));
  ['supplier_code', 'due_date', 'terms', 'currency'].forEach(k => t.ok(!!p.mapping[k], `${label}: optional field "${k}" mapped from "${p.mapping[k]?.heading}"`));
  t.ok(p.records.length > 40 && Lz.total > 500000, `${label}: listing read (${p.records.length} items, ${money(Lz.total)})`);
  t.ok(Lz.supplierCount >= 10, `${label}: supplier grouping works across whitespace/punctuation variants (${Lz.supplierCount} suppliers)`);
  t.ok(d.currencies.length >= 1 && Math.abs(d.currencies.reduce((s, x) => s + x.amount, 0) - Lz.total) < 0.05, `${label}: currency analysis cross-casts to the total`);

  /* U3.1 ageing */
  const bucketSum = d.bucketRows.reduce((s, b) => s + b.amount, 0);
  const aged = p.records.filter(r => r.__bucket).reduce((s, r) => s + (r.amount || 0), 0);
  console.log(`  U3.1: buckets ${d.bucketRows.map(b => `${b.label} ${money(b.amount)}`).join(' | ')}; not aged ${p.records.filter(r => !r.__bucket).length}`);
  t.ok(Math.abs(bucketSum - aged) < 0.05, `${label}: bucket totals cross-cast to the aged population`);
  t.ok(Math.abs(d.suppliers.reduce((s, x) => s + x.amount, 0) - Lz.total) < 0.05, `${label}: supplier ageing cross-casts to the total`);
  t.ok(d.suppliers.every(s => Math.abs(d.buckets.reduce((a, b) => a + (s[b.key] || 0), 0) - s.amount) < 0.05), `${label}: every supplier row cross-casts across buckets`);
  t.ok(p.records.every(r => !r.invoice_date || r.__due), `${label}: due date derived from invoice date + terms where not stated`);
  const pE = pipeline(L, f, CODE, eng, { bucketEdges: '60,120' });
  t.ok(pE.derived.buckets.length === 4 && pE.derived.buckets[1].label === '1–60 days', `${label}: bucket edges are configurable (${pE.derived.buckets.map(b => b.label).join(', ')})`);
  const pI = pipeline(L, f, CODE, eng, { ageBasis: 'invoice' });
  t.ok(pI.derived.buckets[0].label === '0–30 days', `${label}: ageing by days since invoice changes the buckets`);

  /* planted exceptions */
  const planted = expectedExceptions('Payables', c);
  const ids = [...new Set(p.exceptions.map(e => e.id))].sort();
  console.log(`  exceptions: ${p.exceptions.length} → ${ids.join(', ')}`);
  for (const id of PLANTED) {
    const pl = planted.find(x => x.exception.startsWith(id));
    if (!pl) continue;
    const ref = pl.record_key.trim();
    const hit = p.exceptions.find(e => e.id === id && String(e.recordKey).includes(ref));
    t.ok(!!hit, `${label}: ${pl.exception} raised on ${ref}`, `raised on: ${p.exceptions.filter(e => e.id === id).map(e => e.recordKey).join(' ; ') || 'nothing'}`);
  }
  t.ok(p.exceptions.filter(e => e.id === 'EX-AP-06').every(e => e.recordKey.includes('ACCR-YE')), `${label}: EX-AP-06 fires only on the non-invoice reference, not on genuine round-sum invoices`);
  t.ok(p.exceptions.filter(e => e.id === 'EX-AP-08').every(e => e.severity === 'informational'), `${label}: nil items are informational`);
  const debitEx = p.exceptions.filter(e => e.id === 'EX-AP-01');
  t.ok(debitEx.length === d.debitRecs.length && debitEx.every(e => e.difference < 0), `${label}: EX-AP-01 count equals debit balances listed on U3.1 (${debitEx.length})`);
  const p18 = pipeline(L, f, CODE, eng, { longOutstanding: 540 });
  t.ok(p18.exceptions.filter(e => e.id === 'EX-AP-03').length < p.exceptions.filter(e => e.id === 'EX-AP-03').length || p.exceptions.filter(e => e.id === 'EX-AP-03').length <= 1, `${label}: raising the long-outstanding threshold reduces EX-AP-03 hits`);
  t.ok(!p.exceptions.some(e => e.id === 'EX-TIE-01' || e.id === 'EX-AP-13' || e.id === 'EX-AP-11' || e.id === 'EX-AP-12'), `${label}: input-driven tests are silent until the auditor enters figures`);

  /* U3 lead inputs */
  const pTB = pipeline(L, f, CODE, eng, { tbBalance: Lz.total + 1000, pyBalance: Lz.total * 0.8, purchases: Lz.total * 6, clientAgingTotal: Lz.total - 250 });
  const tie = pTB.exceptions.find(e => e.id === 'EX-TIE-01');
  t.ok(tie && Math.abs(tie.difference + 1000) < 0.005, `${label}: EX-TIE-01 listing ≠ TB raised with the difference`, tie && tie.difference);
  t.ok(Math.abs(pTB.derived.lead.payableDays - 365 / 6) < 0.01 && Math.abs(pTB.derived.lead.variancePct - 25) < 0.01, `${label}: payable days and PY movement computed from inputs`);
  const a13 = pTB.exceptions.find(e => e.id === 'EX-AP-13');
  t.ok(a13 && Math.abs(a13.difference - 250) < 0.005, `${label}: EX-AP-13 rebuilt ageing ≠ client ageing raised`);
  const pTB2 = pipeline(L, f, CODE, eng, { tbBalance: Lz.total });
  t.ok(!pTB2.exceptions.some(e => e.id === 'EX-TIE-01'), `${label}: EX-TIE-01 silent when the listing agrees to the TB`);

  /* U3.2 circularisation */
  const C = d.circ;
  console.log(`  U3.2: threshold ${money(C.threshold)}; key ${C.key.length}, sample ${C.sample.length}, coverage ${C.coverage}%`);
  t.ok(C.threshold === eng.materiality.pm, `${label}: circularisation threshold defaults to PM`);
  t.ok(C.key.every(s => s.amount >= C.threshold || s.related) && C.sample.every(s => s.amount < C.threshold), `${label}: key items ≥ threshold, sample drawn from the rest`);
  t.ok(C.sample.length === Math.min(3, C.residual.length), `${label}: sample size honoured`);
  const p2 = pipeline(L, f, CODE, eng, { circSampleN: 3 });
  t.ok(JSON.stringify(p2.derived.circ.sample.map(s => s.key)) === JSON.stringify(C.sample.map(s => s.key)), `${label}: same seed → same supplier sample`);
  const p3 = pipeline(L, f, CODE, eng, { circSampleN: 3, circSeed: 99 });
  t.ok(JSON.stringify(p3.derived.circ.sample.map(s => s.key)) !== JSON.stringify(C.sample.map(s => s.key)), `${label}: different seed → different sample`);
  const pLow = pipeline(L, f, CODE, eng, { circThreshold: 20000 });
  t.ok(pLow.derived.circ.key.length > C.key.length, `${label}: lowering the threshold selects more key suppliers`);
  const sel = C.selected[0];
  const pC = pipeline(L, f, CODE, eng, { circSampleN: 3, ['stmtBal:' + sel.key]: sel.amount + 500, ['circRecd:' + sel.key]: 'Y' });
  const e11 = pC.exceptions.find(e => e.id === 'EX-AP-11');
  t.ok(e11 && e11.recordKey === sel.supplier && Math.abs(e11.difference - 500) < 0.005, `${label}: EX-AP-11 supplier statement difference raised until reconciled`);
  const pC2 = pipeline(L, f, CODE, eng, { circSampleN: 3, ['stmtBal:' + sel.key]: sel.amount + 500, ['reconciled:' + sel.key]: 'Y', ['recItems:' + sel.key]: 'Invoice in transit 500' });
  t.ok(!pC2.exceptions.some(e => e.id === 'EX-AP-11'), `${label}: EX-AP-11 clears once marked reconciled`);

  /* U3.3 subsequent payments */
  const pS = pipeline(L, f, CODE, eng, { circSampleN: 3 }, (recs, cfg) => {
    /* pay every invoice of the first selected supplier in full: replicate selection to find them */
    const key = sel.key;
    recs.forEach(r => { if ((L.Core.keyify(r.supplier_name || '') || L.Core.keyify(r.supplier_code || '')) === key && (r.amount || 0) > 0) r.__wp = { subpay: { payDate: '15/03/2025', payAmount: r.amount, payRef: 'TT' } }; });
  });
  const SP = pS.derived.subpay;
  t.ok(SP.recs.length > 0 && SP.traced > 0 && SP.paid > 0 && SP.coverage > 0 && SP.coverage <= 100, `${label}: subsequent payments coverage ${SP.coverage}% from ${SP.traced} traced items`);
  t.ok(SP.recs.filter(r => r.__supKey === sel.key).every(r => r.__payStatus === 'Paid in full'), `${label}: paid items marked "Paid in full"`);

  /* U3.4 search for unrecorded liabilities */
  const pU = pipeline(L, f, CODE, eng, { 'sulSupplier:sul1': 'Freight forwarder', 'sulDate:sul1': '05/03/2025', 'sulAmount:sul1': 8800, 'sulDesc:sul1': 'February freight', 'sulRelates:sul1': 'Y', 'sulRecorded:sul1': 'N',
    'sulSupplier:sul2': 'Landlord', 'sulAmount:sul2': 12000, 'sulRelates:sul2': 'N', 'sulRecorded:sul2': 'N' });
  const e12 = pU.exceptions.filter(e => e.id === 'EX-AP-12');
  t.ok(e12.length === 1 && e12[0].recordKey === 'Freight forwarder' && Math.abs(e12[0].difference - 8800) < 0.005 && e12[0].severity === 'above-trivial', `${label}: EX-AP-12 unrecorded liability raised for the item relating to the year only`);
  t.ok(pU.derived.sul.unrecordedValue === 8800 && pU.derived.sul.examined === 20800, `${label}: U3.4 totals`);

  /* pages and export */
  p.renderAll(t, label);
  pC.renderAll(t, label + ' (with inputs)');
  const wb = pU.exportCheck(t, label);
  const wsS = wb.Sheets['U3.4 Search for unrecorded liab'] || wb.Sheets[wb.SheetNames.find(n => n.startsWith('U3.4'))];
  t.ok(wsS && Object.values(wsS).some(c => c && c.v === 'Freight forwarder'), `${label}: U3.4 export carries the auditor's post year-end items`);
}

/* export round trip once */
{
  const eng = engagement(L.Core, '2025-02-28', 145000);
  const p = pipeline(L, path.join(OUT, 'client-a', CLIENTS[0].file), CODE, eng, { tbBalance: 1 });
  const wb = L.Exporter.build(p.state(), CODE);
  const out = path.join(__dirname, 'out-AP-file.xlsx');
  L.XLSX.writeFile(wb, out);
  const re = L.XLSX.readFile(out);
  t.ok(re.SheetNames.length === wb.SheetNames.length && re.SheetNames.includes('U3.1 Ageing rebuilt by supplier'), 'AP workbook survives the Excel round-trip');
  fs.unlinkSync(out);
  const text = L.Modules.byCode.AP.suggestConclusion(p.state().modules.AP, p.ctx());
  t.ok(typeof text === 'string' && /trial balance/.test(text), 'suggestConclusion produces text');
}

t.done();
