/* Headless test of the IA (intangible assets) audit file. The synthetic pack has no
   separate intangibles listing, so the fixed asset registers stand in: they have the
   same cost block / amortisation block shape the module accepts.
   Run:  node test/test-ia.js                                                        */
const { load, counter, money, engagement, pipeline, expectedExceptions, OUT, path, fs } = require('./spec-lib');
const L = load(['ia.js']);
const t = counter();
const CODE = 'IA';

const CLIENTS = [
  { c: 'client-a', ye: '2025-02-28', file: 'PBC-PPE-01 Fixed asset register 2025-02-28.xlsx', groups: true },
  { c: 'client-b', ye: '2025-09-30', file: 'PBC-PPE-01 Fixed asset register 2025-09-30.xlsx', groups: false },
  { c: 'client-d', ye: '2025-09-30', file: 'PBC-PPE-01 Fixed asset register 2025-09-30.xlsx', groups: false }
];
/* the PPE planted exceptions have direct IA equivalents; the PPE engine (loaded in the same vm) is the oracle
   because the generator's later data-quality mutations overwrite some planted records */
const MAP = { 'EX-PPE-01': 'EX-IA-01', 'EX-PPE-02': 'EX-IA-01', 'EX-PPE-03': 'EX-IA-03', 'EX-PPE-04': 'EX-IA-04', 'EX-PPE-06': 'EX-IA-06', 'EX-PPE-07': 'EX-IA-07',
  'EX-PPE-08': 'EX-IA-08', 'EX-PPE-08b': 'EX-IA-08b', 'EX-PPE-09': 'EX-IA-09', 'EX-PPE-10': 'EX-IA-10', 'EX-PPE-11': 'EX-IA-11', 'EX-PPE-12': 'EX-IA-12' };

console.log('\n=== IA — module registration ===');
const M = L.Modules.byCode.IA;
t.ok(M && M.name === 'Intangible Assets', 'IA registered via Modules.register');
t.ok(M.pages.filter(p => p.render).length === 7, 'seven rendered working papers (G3, G3.1–G3.6)');
t.ok(M.INDICATORS.length === 8 && M.INDICATORS[0].id === '12a' && M.CRITERIA.length === 5, 'FRS 36 para 12 indicators and five capitalisation criteria carried');
const syn = M.fields.flatMap(f => f.synonyms).join('|');
t.ok(/Amortisation/.test(syn) && /Software/.test(syn) && /Licence/.test(syn) && /Trademark/.test(syn) && /Development/.test(syn) && /Goodwill|Indefinite/.test(syn), 'intangible vocabulary present in the synonyms');

for (const { c, ye, file: f, groups } of CLIENTS) {
  const eng = engagement(L.Core, ye, 145000);
  const file = path.join(OUT, c, f);
  const label = c;
  console.log(`\n=== ${label} ===`);
  const p = pipeline(L, file, CODE, eng);
  const d = p.derived, T = d.totals;
  console.log(`  header row ${p.headerRow + 1}; ${p.records.length} assets in ${d.byCategory.length} classes; cost ${money(T.cost_close)}; charge ${money(T.dep_charge)} vs audit ${money(T.expected)}; carrying ${money(T.nbv_close)}`);
  t.ok(p.missingRequired().length === 0, `${label}: required fields mapped`, p.missingRequired().join(', '));
  for (const k of ['asset_id', 'description', 'acq_date', 'life', 'cost_open', 'additions', 'disposals', 'cost_close', 'accdep_open', 'dep_charge', 'accdep_disp', 'accdep_close', 'nbv_close'])
    t.ok(p.mapping[k], `${label}: ${k} mapped (${p.mapping[k]?.heading} ${p.mapping[k]?.letter})`);
  t.ok(groups ? (!p.mapping.category && p.clean.hasGroups) : !!p.mapping.category, `${label}: class ${groups ? 'taken from group-header rows' : 'mapped from a column'}`);
  t.ok(p.mapping.additions.colIndex < p.mapping.dep_charge.colIndex && p.mapping.disposals.colIndex < p.mapping.accdep_disp.colIndex, `${label}: cost-block and amortisation-block columns resolved in order`);
  t.ok(p.records.length > 50 && d.byCategory.length >= 4 && d.byCategory.length <= 8, `${label}: ${p.records.length} assets across ${d.byCategory.length} classes`);
  t.ok(p.records.every(r => r.__cat && r.__catKey), `${label}: every asset carries a class`);
  t.ok(d.lifeUnit === 'years', `${label}: life unit detected as years`);

  /* totals sane */
  t.ok(Math.abs(T.cost_open + T.additions - T.disposals - T.cost_close - d.castCost) < 0.02, `${label}: cost cast difference computed consistently`);
  t.ok(Math.abs(T.nbv_close - (T.cost_close - T.accdep_close)) < 0.02, `${label}: carrying amount = cost − accumulated amortisation`);
  t.ok(Math.abs(T.dep_charge - d.byCategory.reduce((s, x) => s + x.dep_charge, 0)) < 0.02, `${label}: class charges sum to the total`);
  t.ok(d.lead.length === d.byCategory.length && d.lead.every(l => l.tbCost == null && l.diffCost == null), `${label}: lead rows per class, TB not yet entered`);
  t.ok(p.records.every(r => r.__lifeBasis === 'Finite'), `${label}: fixed assets stand-in — no indefinite-life or not-yet-available flags from the register text`);

  /* planted exceptions (PPE-equivalent): IA must reproduce the PPE engine key-for-key on the same register */
  const pTight = pipeline(L, file, CODE, eng, { amortTol: 50 });
  const ppe = pipeline(L, file, 'PPE', eng, { depTol: 50 });
  const keys = (px, id) => px.exceptions.filter(e => e.id === id).map(e => e.recordKey).sort().join('|');
  for (const [pid, iid] of Object.entries(MAP).filter(([k]) => k !== 'EX-PPE-02')) {
    t.ok(keys(ppe, pid) === keys(pTight, iid), `${label}: ${iid} matches the PPE engine's ${pid} (${ppe.exceptions.filter(e => e.id === pid).length} record(s))`, `PPE ${keys(ppe, pid)} vs IA ${keys(pTight, iid)}`);
  }
  const has = (px, id, key) => px.exceptions.some(e => e.id === id && e.recordKey === key);
  let planted = 0, confirmed = 0;
  for (const x of expectedExceptions('PPE', c)) {
    const pid = x.exception.slice(0, 9), iid = MAP[pid];
    if (!iid || !has(ppe, pid, x.record_key)) continue;           // plant overwritten by a later data-quality mutation, or needs a policy input
    planted++; if (has(pTight, iid, x.record_key)) confirmed++;
    t.ok(has(pTight, iid, x.record_key), `${label}: planted ${x.exception} → ${iid} raised for "${x.record_key}"`);
  }
  t.ok(planted >= 3 && confirmed === planted, `${label}: ${confirmed} of ${planted} planted exceptions still present in the data are raised`);
  for (const id of ['EX-IA-03', 'EX-IA-09']) t.ok(p.exceptions.some(e => e.id === id), `${label}: ${id} raised at default tolerance`);
  t.ok(!p.exceptions.some(e => e.id === 'EX-IA-02' || e.id === 'EX-IA-13' || e.id === 'EX-IA-14' || e.id === 'EX-IA-15'), `${label}: input-driven tests silent before any auditor input`);
  t.ok(p.exceptions.filter(e => e.id === 'EX-IA-01').length < pTight.exceptions.filter(e => e.id === 'EX-IA-01').length, `${label}: tightening the amortisation tolerance surfaces more EX-IA-01`);
  /* EX-PPE-05 / EX-IA-05 need the class policy: enter the most common life per class */
  const pol = Object.fromEntries(d.byCategory.filter(x => x.modeLife).map(x => ['policyLife:' + x.key, x.modeLife]));
  const pPol5 = pipeline(L, file, CODE, eng, pol);
  const ppePol = pipeline(L, file, 'PPE', eng, { lifePolicy: Object.fromEntries(d.byCategory.filter(x => x.modeLife).map(x => [x.category, x.modeLife])) });
  const ppe05 = ppePol.exceptions.filter(e => e.id === 'EX-PPE-05').map(e => e.recordKey).sort(), ia05 = pPol5.exceptions.filter(e => e.id === 'EX-IA-05').map(e => e.recordKey).sort();
  t.ok(ia05.length > 0 && ppe05.every(k => ia05.includes(k)), `${label}: EX-IA-05 (life off policy) covers the PPE engine's EX-PPE-05 set (${ia05.length} vs ${ppe05.length})`);
  for (const x of expectedExceptions('PPE', c).filter(x => x.exception.startsWith('EX-PPE-05')))
    if (ppe05.includes(x.record_key)) t.ok(ia05.includes(x.record_key), `${label}: planted ${x.exception} → EX-IA-05 raised for "${x.record_key}"`);
  console.log('  exceptions: ' + JSON.stringify(p.exceptions.reduce((m, e) => { m[e.id] = (m[e.id] || 0) + 1; return m; }, {})));

  /* additions: threshold, seeded sample, coverage */
  const A = d.additions;
  t.ok(A.threshold === eng.materiality.pm && A.key.every(r => r.additions >= A.threshold) && A.residual.every(r => r.additions < A.threshold), `${label}: additions split at PM (${money(A.threshold)}) — ${A.key.length} key, ${A.residual.length} residual`);
  const pS = pipeline(L, file, CODE, eng, { addSampleN: 5, addSeed: 7 }), pS2 = pipeline(L, file, CODE, eng, { addSampleN: 5, addSeed: 7 }), pS3 = pipeline(L, file, CODE, eng, { addSampleN: 5, addSeed: 8 });
  t.ok(pS.derived.additions.sample.length === Math.min(5, A.residual.length) && pS.derived.additions.sample.map(r => r.__srcRow).join() === pS2.derived.additions.sample.map(r => r.__srcRow).join(), `${label}: random sample of five is reproducible from the seed`);
  t.ok(pS.derived.additions.sample.map(r => r.__srcRow).join() !== pS3.derived.additions.sample.map(r => r.__srcRow).join(), `${label}: a different seed draws a different sample`);
  t.ok(pS.derived.additions.coverage > A.coverage && pS.derived.additions.coverage <= 100, `${label}: sampling raises coverage (${A.coverage}% → ${pS.derived.additions.coverage}%)`);
  const pLow = pipeline(L, file, CODE, eng, { addThreshold: 1 });
  t.ok(pLow.derived.additions.key.length === A.all.length && pLow.derived.additions.coverage === 100, `${label}: threshold of 1 selects every addition`);

  /* auditor inputs */
  const first = d.byCategory[0], second = d.byCategory[1];
  const big = d.byCategory.slice().sort((a, b) => b.nbv_close - a.nbv_close)[0];
  t.ok(new Set(d.byCategory.map(x => x.key)).size === d.byCategory.length && d.byCategory.every(x => x.category === x.category.replace(/\s+/g, ' ').trim()) && !d.byCategory.some(x => d.byCategory.some(y => y !== x && x.category.toLowerCase() === y.category.toLowerCase())), `${label}: class variants differing only in case or spacing are grouped`);
  const addSel = pLow.derived.additions.selected[0];
  const anyDisp = d.disposals.rows[0];
  const bigAsset = p.records.filter(r => (r.__nbv_close || 0) > 1000 && (r.dep_charge || 0) > 0).sort((a, b) => b.__nbv_close - a.__nbv_close)[0];
  const cfgIn = { addThreshold: 1, pnlAmortisation: T.dep_charge + 12.5,
    ['tbCost:' + first.key]: first.cost_close, ['tbAcc:' + first.key]: -first.accdep_close, ['tbCost:' + second.key]: second.cost_close + 250, ['tbAcc:' + second.key]: second.accdep_close,
    ['pyCost:' + first.key]: first.cost_open, ['pyAcc:' + first.key]: first.accdep_open, ['pyCost:' + second.key]: second.cost_open - 40, ['pyAcc:' + second.key]: second.accdep_open,
    ['policyLife:' + first.key]: 99,
    indicators: { '12b': { answer: 'Y', comment: 'Technology superseded', categories: [big.category] } }, ruleC5: false };
  const pi = pipeline(L, file, CODE, eng, cfgIn, recs => {
    const a = recs.find(r => r.__srcRow === addSel.__srcRow); a.__wp = { additions: { doc: 'Invoice 4411', agreed: 'Y', critIdent: 'Y', critControl: 'Y', critBenefit: 'N', critCost: 'Y', critResearch: 'Y' } };
    const b = recs.find(r => r.__srcRow === bigAsset.__srcRow); b.__wp = { indef: { indefinite: 'Y', impTested: 'N', recoverable: bigAsset.__nbv_close ? bigAsset.__nbv_close - 500 : 100 } };
    if (anyDisp) { const x = recs.find(r => r.__srcRow === anyDisp.r.__srcRow); x.__wp = { disposals: { proceeds: 0 } }; }
  });
  const ex = id => pi.exceptions.filter(e => e.id === id);
  const di = pi.derived;
  t.ok(ex('EX-IA-20').length === 1 && ex('EX-IA-20')[0].recordKey === second.category && Math.abs(ex('EX-IA-20')[0].difference + 250) < 0.02, `${label}: EX-IA-20 raised only for the class not agreeing to TB (credit-signed acc amort accepted)`);
  t.ok(ex('EX-IA-21').length === 1 && Math.abs(ex('EX-IA-21')[0].difference + 12.5) < 0.005, `${label}: EX-IA-21 amortisation vs P&L −12.50`);
  t.ok(ex('EX-IA-22').length === 1 && ex('EX-IA-22')[0].recordKey === second.category && Math.abs(ex('EX-IA-22')[0].difference - 40) < 0.02, `${label}: EX-IA-22 opening cost not agreeing to prior year for one class`);
  t.ok(ex('EX-IA-05').length > 0 && ex('EX-IA-05').every(e => e.severity === 'informational'), `${label}: EX-IA-05 lives off the 99-year policy for class "${first.category}", informational`);
  t.ok(ex('EX-IA-13').length === 1 && ex('EX-IA-13')[0].recordKey === addSel.__displayKey && /future economic benefits/i.test(ex('EX-IA-13')[0].actual) && ex('EX-IA-13')[0].severity === 'above-trivial', `${label}: EX-IA-13 recognition criterion answered No on the selected addition`);
  t.ok(di.additions.critFail.length === 1 && di.additions.vouched === 1, `${label}: criteria fail and vouched counts`);
  const bi = pi.records.find(r => r.__srcRow === bigAsset.__srcRow);
  t.ok(bi.__indefinite && bi.__indefSource === 'auditor' && bi.__annualTest && bi.__expectedDep === 0 && bi.__lifeBasis === 'Indefinite', `${label}: auditor flag makes "${bigAsset.__displayKey}" indefinite-life with nil expected amortisation`);
  t.ok(ex('EX-IA-02').length === 1 && ex('EX-IA-02')[0].recordKey === bigAsset.__displayKey && ex('EX-IA-02')[0].severity === 'above-trivial', `${label}: EX-IA-02 amortisation charged on the indefinite-life asset`);
  t.ok(ex('EX-IA-14').length === 1 && ex('EX-IA-15').length === 1 && Math.abs(ex('EX-IA-15')[0].difference + 500) < 0.02, `${label}: EX-IA-14 (no annual test) and EX-IA-15 (recoverable 500 below carrying)`);
  t.ok(di.indef.count === 1 && di.indef.shortfall.length === 1 && di.indef.amortised.length === 1, `${label}: G3.4 summary counts`);
  t.ok(!pi.exceptions.some(e => e.id === 'EX-IA-01' && e.recordKey === bigAsset.__displayKey), `${label}: the indefinite-life asset drops out of the EX-IA-01 recalculation`);
  const c6 = di.impairment.candidates.find(x => x.r.__srcRow === bigAsset.__srcRow);
  t.ok(c6 && c6.rules.includes('C6'), `${label}: indefinite-life asset becomes a C6 impairment candidate`);
  t.ok(di.impairment.anyYes && di.impairment.candidates.some(x => x.rules.includes('C7') && x.r.__cat === big.category) && !di.impairment.candidates.some(x => x.rules.includes('C7') && x.r.__cat !== big.category), `${label}: indicator 12b answered Yes for "${big.category}" drives C7 for that class only`);
  t.ok(!di.impairment.candidates.some(x => x.rules.includes('C5')) && d.impairment.byRule.find(r => r.id === 'C5').on, `${label}: rule C5 switched off removes its candidates`);
  if (anyDisp) {
    const xi = di.disposals.rows.find(x => x.r.__srcRow === anyDisp.r.__srcRow);
    t.ok(xi && xi.proceeds === 0 && Math.abs(xi.gainLoss + xi.nbvDisposed) < 0.005 && di.disposals.priced === 1, `${label}: nil proceeds gives a loss equal to the carrying amount derecognised`);
  }
  t.ok(d.disposals.noWriteBack.length >= 1 && p.exceptions.filter(e => e.id === 'EX-IA-09').length === d.disposals.noWriteBack.length, `${label}: EX-IA-09 count equals disposals without write-back`);

  /* register-text detection of indefinite life / not yet available */
  const pTxt = pipeline(L, file, CODE, eng, {}, recs => { recs[0].description = 'Goodwill on acquisition'; recs[1].description = 'ERP implementation — in progress'; });
  t.ok(pTxt.records[0].__indefinite && pTxt.records[0].__indefSource === 'register' && pTxt.records[1].__nyafu && pTxt.records[1].__lifeBasis === 'Not yet available for use', `${label}: register wording flags goodwill as indefinite and work in progress as not yet available`);
  const pOverride = pipeline(L, file, CODE, eng, {}, recs => { recs[0].description = 'Goodwill on acquisition'; recs[0].__wp = { indef: { indefinite: 'N' } }; });
  t.ok(!pOverride.records[0].__indefinite, `${label}: the auditor's N overrides the register scan`);

  /* conventions and policy basis */
  const pConv = pipeline(L, file, CODE, eng, { convention: 'none-first' });
  t.ok(pConv.records.filter(r => r.__isAddition && r.acq_date >= eng.fyStartDate).every(r => r.__months === 0), `${label}: no-amortisation-in-year-of-capitalisation convention gives nil months on in-year additions`);
  const pPol = pipeline(L, file, CODE, eng, { recalcBasis: 'policy', ['policyLife:' + first.key]: 10 });
  t.ok(pPol.records.filter(r => r.__cat === first.category).every(r => r.__lifeUsed === 10) && pPol.records.filter(r => r.__cat !== first.category).every(r => r.__lifeUsed === r.__lifeYears), `${label}: policy basis applies the class life only where entered`);

  /* pages and export */
  p.renderAll(t, label);
  pi.renderAll(t, label + ' (with inputs)');
  const wb = pi.exportCheck(t, label);
  const ws3 = wb.Sheets[wb.SheetNames.find(x => x.startsWith('G3.3 '))];
  t.ok(ws3 && Object.values(ws3).some(cell => cell && cell.v === 'Invoice 4411'), `${label}: G3.3 export carries the vouching input`);
  const ws5 = wb.Sheets[wb.SheetNames.find(x => x.startsWith('G3.5 '))];
  t.ok(ws5 && Object.values(ws5).some(cell => cell && cell.v === 'Technology superseded'), `${label}: G3.5 export carries the indicator response`);
  const text = M.suggestConclusion(pi.state().modules.IA, pi.ctx());
  t.ok(typeof text === 'string' && text.length > 200 && /indefinite life/.test(text), `${label}: suggestConclusion produces text`);
}

/* round trip */
{
  const eng = engagement(L.Core, '2025-02-28', 145000);
  const p = pipeline(L, path.join(OUT, 'client-a', 'PBC-PPE-01 Fixed asset register 2025-02-28.xlsx'), CODE, eng);
  const wb = L.Exporter.build(p.state(), CODE);
  const out = path.join(__dirname, 'out-IA-file.xlsx');
  L.XLSX.writeFile(wb, out);
  const re = L.XLSX.readFile(out);
  t.ok(re.SheetNames.length === wb.SheetNames.length, 'workbook survives the Excel round-trip');
  fs.unlinkSync(out);
}

t.done();
