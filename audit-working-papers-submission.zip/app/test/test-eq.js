/* Headless test of the EQ (equity) audit file against the synthetic share capital and reserves schedules.
   Run:  node test/test-eq.js

   The client schedule carries two blocks (share capital, reserves). Header detection picks the
   reserves block, so share capital is entered on O3.1; a second pass forces the header row onto
   the share capital block to prove the schedule-driven path as well.                          */
const { load, counter, money, engagement, pipeline, OUT, path, fs } = require('./spec-lib');
const L = load(['eq.js']);
const t = counter();
const CODE = 'EQ';
const M = L.Modules.byCode.EQ;

const CLIENTS = [
  { c: 'client-a', ye: '2025-02-28', file: 'PBC-EQ-01 Share capital and reserves 2025-02-28.xlsx' },
  { c: 'client-b', ye: '2025-09-30', file: 'PBC-EQ-01 Share capital and reserves 2025-09-30.xlsx' },
  { c: 'client-d', ye: '2025-09-30', file: 'PBC-EQ-01 Share capital and reserves 2025-09-30.xlsx' }
];
/* Figures common to every synthetic client's schedule */
const RE_OPEN = -1006836, PROFIT = -379295, OCI = 24890, SHARES_BF = 500000, ALLOT = 138654;

/* pipeline with a forced header row (share capital block sits above the detected reserves block) */
function pipelineAt(file, headerRow, eng, cfgOverride = {}, prep) {
  const { Core } = L;
  const buf = fs.readFileSync(file);
  const wbData = Core.readWorkbook(buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength), path.basename(file));
  const sheet = wbData.sheets[0];
  /* the share capital block ends where the "Reserves" title starts */
  const endRow = sheet.rows.findIndex((r, i) => i > headerRow && r && r.filter(v => v != null && v !== '').length === 1 && /^reserves$/i.test(String(r.find(v => v != null && v !== ''))));
  const rows = endRow > 0 ? sheet.rows.slice(0, endRow) : sheet.rows;
  const clean = Core.cleanTable(rows, headerRow);
  const mapping = Core.proposeMapping(clean.headers, M.fields, clean.rows.filter(r => r.__kind === 'data').slice(0, 40));
  const built = Core.buildRecords(clean, M.fields, mapping);
  const cfg = M.defaultConfig(); Object.assign(cfg, cfgOverride);
  if (prep) prep(built.records, cfg);
  const res = Core.runTests(M, built.records, cfg, eng);
  return { clean, mapping, records: built.records, exceptions: res.exceptions, derived: res.derived, cfg };
}

console.log('\n=== EQ — module registration ===');
t.ok(M && M.name === 'Equity' && M.group === 'Liabilities & equity', 'EQ registered via Modules.register');
t.ok(M.pages.filter(p => p.render).length === 6, 'six rendered working papers (O3, O3.1–O3.5)');
t.ok(M.CHECKLIST.length === 13 && typeof M.classify === 'function', 'disclosure checklist and line classifier exposed');
t.ok(M.classify('Total comprehensive income for the year') === 'tci' && M.classify('Balance brought forward') === 'open' && M.classify('Balance carried forward') === 'close', 'classifier: b/f, c/f and total comprehensive income');
t.ok(M.classify('Ordinary shares allotted for cash') === 'issue' && M.classify('Dividends paid') === 'dividend' && M.classify('Share buy-back') === 'buyback' && M.classify('Translation difference') === 'oci' && M.classify('Transfer to statutory reserve') === 'transfer', 'classifier: issue, dividend, buy-back, OCI, transfer');
t.ok(M.classify('Total comprehensive income') !== 'close' && M.classify('Profit for the year') === 'tci', 'a total comprehensive income line is never taken as a closing balance');

for (const { c, ye, file } of CLIENTS) {
  const eng = engagement(L.Core, ye, 145000);
  const f = path.join(OUT, c, file);
  const label = c;
  console.log(`\n=== EQ — ${c} (reserves block as detected) ===`);
  const p = pipeline(L, f, CODE, eng);
  const d = p.derived;
  console.log(`  header row ${p.headerRow + 1}; ${p.records.length} lines read as ${d.kinds.join(', ')}; shareBlock ${d.shareBlock}, reserveBlock ${d.reserveBlock}; RE open ${money(d.reserves.re.open)}`);
  t.ok(p.missingRequired().length === 0, `${label}: required fields mapped`, p.missingRequired().join(', '));
  ['description', 'retained', 'other_reserve', 'total'].forEach(k => t.ok(!!p.mapping[k], `${label}: "${k}" mapped from "${p.mapping[k]?.heading}"`));
  t.ok(d.reserveBlock && !d.shareBlock, `${label}: the reserves block was read; share capital comes from O3.1 inputs`);
  t.ok(d.reserves.re.open === RE_OPEN && d.reserves.or.open === 0, `${label}: opening retained earnings ${money(d.reserves.re.open)} and translation reserve read from the b/f line`);
  t.ok(d.reserves.re.tciSource === 'not entered' && d.reserves.re.tci === 0, `${label}: the client's total comprehensive income subtotal is held out; profit must be entered by the auditor`);
  t.ok(d.divs.schedule === 0 && d.divs.used === 0, `${label}: dividends per schedule nil`);
  t.ok(d.reserves.re.closeClient == null && d.reserves.re.closeSource == null, `${label}: c/f line carries no cached value → client closing not available until entered`);
  t.ok(d.sc.source === 'input' && d.sc.close.shares === 0 && d.sc.castDiff == null, `${label}: share capital in input mode with nothing entered yet`);
  t.ok(p.exceptions.length === 0, `${label}: no exceptions before inputs (${p.exceptions.map(e => e.id).join(', ') || 'none'})`);
  t.ok(d.socie.length === 9 && Math.abs(d.crossCast.total) < 0.005 && Math.abs(d.crossCast.re) < 0.005, `${label}: statement of changes in equity built and cross-casts with no inputs`);

  /* full set of auditor inputs: share capital block, profit / OCI, client c/f, TB, PY */
  const cfgFull = {
    'sc_shares:bf': SHARES_BF, 'sc_amount:bf': SHARES_BF, 'sc_date:bf': '2024-02-28',
    'sc_shares:issue': ALLOT, 'sc_amount:issue': ALLOT, 'sc_date:issue': '2024-07-02',
    'sc_shares:cf': SHARES_BF + ALLOT, 'sc_amount:cf': SHARES_BF + ALLOT,
    profit: PROFIT, oci: OCI, reCloseClient: RE_OPEN + PROFIT, orCloseClient: OCI,
    tbShareCapital: SHARES_BF + ALLOT, tbRetained: RE_OPEN + PROFIT, tbOther: OCI,
    pyShareCapital: SHARES_BF, pyRetained: RE_OPEN, pyOther: 0, pyShares: SHARES_BF
  };
  const pF = pipeline(L, f, CODE, eng, cfgFull);
  const D = pF.derived;
  console.log(`  with inputs: share capital ${money(D.sc.close.amount)} (${D.sc.close.shares} shares); RE close ${money(D.reserves.re.close)}; OR close ${money(D.reserves.or.close)}; total equity ${money(D.totalEquity)}`);
  t.ok(D.sc.close.shares === SHARES_BF + ALLOT && D.sc.close.amount === SHARES_BF + ALLOT, `${label}: O3.1 share capital rolls forward from the inputs`);
  t.ok(D.sc.castDiff && D.sc.castDiff.shares === 0 && D.sc.castDiff.amount === 0, `${label}: O3.1 casts to the client's c/f`);
  t.ok(D.sc.issuePrice === 1 && D.sc.openPrice === 1 && D.sc.pySharesDiff === 0, `${label}: implied price per share 1.00; opening shares agree to PY`);
  t.ok(D.reserves.re.close === RE_OPEN + PROFIT && D.reserves.or.close === OCI && D.reserves.re.tciSource === 'P&L input', `${label}: O3.2 reserves roll forward from audited profit and OCI`);
  t.ok(D.reserves.re.diff === 0 && D.reserves.or.diff === 0 && D.reserves.totalDiff === 0, `${label}: O3.2 agrees to the client's closing reserves`);
  t.ok(D.lead.length === 4 && D.lead.every(l => l.diff === 0) && D.totalEquity === SHARES_BF + ALLOT + RE_OPEN + PROFIT + OCI, `${label}: O3 lead agrees every component to the TB; total equity ${money(D.totalEquity)}`);
  t.ok(D.lead[3].movement === ALLOT + PROFIT + OCI, `${label}: O3 movement vs PY = allotment + profit + OCI (${money(D.lead[3].movement)})`);
  t.ok(D.socie[8].total === D.totalEquity && Math.abs(D.crossCast.total) < 0.005 && Math.abs(D.crossCast.sc) < 0.005 && Math.abs(D.crossCast.re) < 0.005 && Math.abs(D.crossCast.or) < 0.005, `${label}: O3.4 statement of changes in equity casts and cross-casts`);
  t.ok(D.divs.distributable === RE_OPEN + PROFIT && D.divs.excess === 0, `${label}: distributable profits = opening RE + profit (negative → none available)`);
  t.ok(pF.exceptions.length === 0, `${label}: a fully agreed file raises no exceptions (${pF.exceptions.map(e => e.id).join(', ') || 'none'})`);

  /* break each tie and confirm the right exception fires */
  const pE1 = pipeline(L, f, CODE, eng, { ...cfgFull, reCloseClient: RE_OPEN + PROFIT + 1000 });
  const e1 = pE1.exceptions.filter(e => e.id === 'EX-EQ-01');
  t.ok(e1.length === 1 && e1[0].recordKey === 'Retained earnings' && Math.abs(e1[0].difference - 1000) < 0.005, `${label}: EX-EQ-01 reserves roll-forward difference raised on retained earnings only`, JSON.stringify(e1.map(e => [e.recordKey, e.difference])));
  const pE3 = pipeline(L, f, CODE, eng, { ...cfgFull, 'sc_amount:cf': SHARES_BF + ALLOT + 500, 'sc_shares:cf': SHARES_BF + ALLOT + 10 });
  const e3 = pE3.exceptions.filter(e => e.id === 'EX-EQ-03');
  t.ok(e3.length === 2 && e3.some(e => Math.abs(e.difference - 500) < 0.005) && e3.some(e => e.difference === 10), `${label}: EX-EQ-03 share capital cast raised for amount and for share count`);
  const pE6 = pipeline(L, f, CODE, eng, { ...cfgFull, pyShares: SHARES_BF - 1000 });
  const e6 = pE6.exceptions.find(e => e.id === 'EX-EQ-06');
  t.ok(e6 && e6.difference === 1000 && e6.severity === 'informational', `${label}: EX-EQ-06 opening shares vs prior year (informational)`);
  const pTie = pipeline(L, f, CODE, eng, { ...cfgFull, tbRetained: RE_OPEN + PROFIT - 250, tbOther: OCI + 25 });
  const tie = pTie.exceptions.filter(e => e.id === 'EX-TIE-01');
  t.ok(tie.length === 2 && tie.some(e => /Retained/.test(e.recordKey) && Math.abs(e.difference - 250) < 0.005) && tie.some(e => /Other/.test(e.recordKey) && Math.abs(e.difference + 25) < 0.005), `${label}: EX-TIE-01 raised per component that does not agree to the TB`);

  /* dividends: register, distributable profits, per share */
  const cfgDiv = { ...cfgFull, profit: 900000, reCloseClient: RE_OPEN + 900000 - 150000, 'div_date:d1': '2024-12-15', 'div_resolution:d1': 'Y', 'div_amount:d1': 150000, 'div_pershare:d1': 0.2349 };
  const pD = pipeline(L, f, CODE, eng, cfgDiv);
  const Dv = pD.derived.divs;
  t.ok(Dv.declared === 150000 && Dv.used === 150000 && Dv.rows.length === 1 && Math.abs(Dv.rows[0].impliedPerShare - 150000 / (SHARES_BF + ALLOT)) < 0.005, `${label}: O3.3 dividend register totals and recomputes per share (${Dv.rows[0].impliedPerShare})`);
  t.ok(Dv.distributable === RE_OPEN + 900000 && Dv.excess === 150000 - Math.max(0, RE_OPEN + 900000), `${label}: distributable profits ${money(Dv.distributable)} (negative → nil available) → excess ${money(Dv.excess)}`);
  const e2 = pD.exceptions.find(e => e.id === 'EX-EQ-02');
  t.ok(e2 && e2.severity === 'above-trivial' && Math.abs(e2.difference - Dv.excess) < 0.005, `${label}: EX-EQ-02 dividends exceed distributable profits (${money(Dv.excess)})`);
  const e5 = pD.exceptions.find(e => e.id === 'EX-EQ-05');
  t.ok(e5 && Math.abs(e5.difference - 150000) < 0.005, `${label}: EX-EQ-05 register (150,000) ≠ dividends line of the schedule (nil)`);
  t.ok(pD.derived.reserves.re.dividends === 150000 && pD.derived.reserves.re.diff === 0 && pD.derived.socie[4].re === -150000, `${label}: dividends flow into the reserves roll-forward and the SOCIE`);
  const pD2 = pipeline(L, f, CODE, eng, { ...cfgDiv, profit: 2000000, reCloseClient: RE_OPEN + 2000000 - 150000 });
  t.ok(!pD2.exceptions.some(e => e.id === 'EX-EQ-02') && pD2.derived.divs.rows[0].exceeds === false, `${label}: EX-EQ-02 silent when profits cover the dividend`);

  /* pages and export */
  p.renderAll(t, label);
  pF.renderAll(t, label + ' with inputs');
  pD.renderAll(t, label + ' with dividends');
  const wb = pF.exportCheck(t, label);
  const wsL = wb.Sheets['O3 Lead schedule'];
  t.ok(wsL && Object.values(wsL).some(c => c && typeof c === 'object' && c.v === SHARES_BF + ALLOT), `${label}: O3 export carries the share capital figure`);
  const wsD = wb.Sheets['O3.5 Disclosure and compliance c'.slice(0, 31)] || wb.Sheets[Object.keys(wb.Sheets).find(n => n.startsWith('O3.5'))];
  t.ok(wsD && Object.values(wsD).some(c => c && c.v === 'D1'), `${label}: O3.5 export lists the checklist items`);

  /* share capital block: force the header onto the first block */
  console.log(`=== EQ — ${c} (share capital block, header forced) ===`);
  const rows = L.Core.readWorkbook(fs.readFileSync(f).buffer.slice(0), path.basename(f)).sheets[0].rows;
  const scHeader = rows.findIndex(r => r && r.some(v => /shares|share count|units/i.test(String(v))) && r.some(v => /date/i.test(String(v))));
  t.ok(scHeader > 0 && scHeader < p.headerRow, `${label}: share capital header located on row ${scHeader + 1}`);
  const q = pipelineAt(f, scHeader, eng, { pyShares: SHARES_BF }, recs => { recs.filter(r => M.classify(r.description) === 'issue').forEach(r => { r.__wp = { sharecap: { register: 'Y', resolution: 'Y', bank: 'N' } }; }); });
  const S = q.derived.sc;
  console.log(`  read as ${q.derived.kinds.join(', ')}; shares b/f ${S.open.shares}, allotted ${S.issue.shares}, c/f ${S.close.shares}`);
  t.ok(!!q.mapping.shares && !!q.mapping.amount && !!q.mapping.date, `${label}: shares/amount/date mapped from "${q.mapping.shares?.heading}" / "${q.mapping.amount?.heading}" / "${q.mapping.date?.heading}"`);
  t.ok(q.derived.shareBlock && S.source === 'schedule', `${label}: share capital block recognised and read from the schedule`);
  t.ok(S.open.shares === SHARES_BF && S.issue.shares === ALLOT && S.close.shares === SHARES_BF + ALLOT && S.close.amount === SHARES_BF + ALLOT, `${label}: O3.1 rolls forward from the schedule lines (${S.close.shares} shares, ${money(S.close.amount)})`);
  t.ok(S.issues.length === 1 && S.issues[0].date instanceof Date && S.issuePrice === 1, `${label}: allotment line dated ${L.Core.fmtDate(S.issues[0].date)} at 1.00 per share`);
  t.ok(S.pySharesDiff === 0, `${label}: opening shares agree to the prior year`);
  const e4 = q.exceptions.filter(e => e.id === 'EX-EQ-04');
  t.ok(e4.length === 1 && /consideration to bank/.test(e4[0].detail) && e4[0].severity === 'above-trivial', `${label}: EX-EQ-04 raised when the allotment's consideration is not agreed to bank`);
  const q2 = pipelineAt(f, scHeader, eng, {}, recs => { recs.filter(r => M.classify(r.description) === 'issue').forEach(r => { r.__wp = { sharecap: { register: 'Y', resolution: 'Y', bank: 'Y' } }; }); });
  t.ok(!q2.exceptions.some(e => e.id === 'EX-EQ-04'), `${label}: EX-EQ-04 clears once every vouching answer is Yes`);
  const st = { code: CODE, records: q.records, exceptions: q.exceptions, derived: q.derived, config: q.cfg, pageNotes: {}, edits: [], trail: [] };
  const ctx = { eng, cfg: q.cfg, d: q.derived, recs: q.records.filter(r => !r.__excluded), all: q.records, money: x => x, money0: x => x, pct: x => x, fmtDate: L.Core.fmtDate, r2: n => n == null ? null : Math.round(n * 100) / 100, pm: eng.materiality.pm, trivial: eng.materiality.trivial, M };
  for (const pg of M.pages.filter(pg => pg.render)) {
    let specs = null, err = null;
    try { specs = pg.render(st, ctx); L.SpecXL.toRows(specs, pg.id, st); } catch (e) { err = e; }
    t.ok(Array.isArray(specs) && specs.length && !err, `${label}: ${pg.ref} renders in share-capital mode`, err && err.message);
  }
  const vouch = M.pages.find(pg => pg.id === 'sharecap').render(st, ctx).find(s => s.type === 'table' && /vouching/.test(s.title));
  t.ok(vouch && vouch.rows.length === 2 && vouch.columns.some(col => col.input === 'select' && col.key === 'bank'), `${label}: O3.1 vouching table lists the b/f and allotment lines with Y/N inputs`);
}

/* ---------------------------------------------------------------------- */
console.log('\n=== EQ — SOCIE cross-cast, checklist export, conclusion (client-a) ===');
{
  const eng = engagement(L.Core, '2025-02-28', 145000);
  const f = path.join(OUT, 'client-a', 'PBC-EQ-01 Share capital and reserves 2025-02-28.xlsx');
  const cfg = { 'sc_shares:bf': SHARES_BF, 'sc_amount:bf': SHARES_BF, 'sc_shares:issue': ALLOT, 'sc_amount:issue': ALLOT, profit: PROFIT, oci: OCI, otherRE: -5000, otherOR: 5000,
    tbShareCapital: SHARES_BF + ALLOT, tbRetained: RE_OPEN + PROFIT - 5000, tbOther: OCI + 5000,
    disclosure: { D1: { answer: 'Y', comment: 'Agreed to ACRA bizfile extract', categories: [] }, D9: { answer: 'N', comment: 'Post year-end dividend not disclosed', categories: [] } } };
  const p = pipeline(L, f, CODE, eng, cfg);
  const d = p.derived;
  t.ok(d.socie[7].re === -5000 && d.socie[7].or === 5000 && d.socie[7].total === 0, 'O3.4: a transfer between reserves nets to nil in the total column');
  t.ok(Math.abs(d.crossCast.total) < 0.005 && d.lead.every(l => l.diff === 0), 'O3.4/O3: transfer flows through the roll-forward and still agrees to the TB');
  t.ok(!p.exceptions.some(e => e.id === 'EX-EQ-07'), 'EX-EQ-07 silent when the SOCIE cross-casts');
  const wb = p.exportCheck(t, 'client-a with checklist');
  const wsD = wb.Sheets[Object.keys(wb.Sheets).find(n => n.startsWith('O3.5'))];
  const vals = Object.values(wsD).filter(c => c && typeof c === 'object' && 'v' in c).map(c => c.v);
  t.ok(vals.includes('Agreed to ACRA bizfile extract') && vals.includes('N'), 'O3.5 export carries the checklist answers and evidence');
  const out = path.join(__dirname, 'out-EQ-file.xlsx');
  L.XLSX.writeFile(wb, out);
  const re = L.XLSX.readFile(out);
  t.ok(re.SheetNames.length === wb.SheetNames.length, 'workbook survives the Excel round-trip');
  fs.unlinkSync(out);
  const st = p.state().modules.EQ;
  const text = M.suggestConclusion(st, p.ctx());
  t.ok(typeof text === 'string' && text.length > 100 && /No exceptions remain open/.test(text), 'suggestConclusion produces text');
}

t.done();
