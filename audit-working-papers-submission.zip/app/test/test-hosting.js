const { counter } = require('./spec-lib.js');
const t = counter();
(async () => {
  const { handler } = await import('../../hosting/worker.mjs');
  const server = handler('<!doctype html><head></head><body>Audit app</body>');
  const url = 'https://audit.example/';
  const signed = { 'oai-authenticated-user-id': 'fictitious-user-a', 'oai-authenticated-user-email': 'auditor@example.invalid' };
  const anon = await server.fetch(new Request(url));
  t.ok(anon.status === 302, 'anonymous visitors cannot read the audit app');
  t.ok(anon.headers.get('location') === '/signin-with-chatgpt?return_to=%2F', 'sign-in uses dispatch-owned top-level flow');
  for (const missing of Object.keys(signed)) {
    const headers = { ...signed }; delete headers[missing];
    t.ok((await server.fetch(new Request(url, { headers }))).status === 302, 'both trusted identity headers required: ' + missing);
  }
  for (const method of ['POST', 'PUT', 'PATCH', 'DELETE']) {
    const request = new Request(url, { method, headers: signed, body: 'FICTITIOUS_AUDIT_DATA' });
    const response = await server.fetch(request);
    t.ok(response.status === 405 && !request.bodyUsed, method + ' rejected without reading body');
  }
  for (const path of ['/app/src/ui.js', '/index.html', '/api/upload', '/synthetic-data/out/client-a/'])
    t.ok((await server.fetch(new Request(url + path.slice(1), { headers: signed }))).status === 404, 'no route bypass: ' + path);
  const response = await server.fetch(new Request(url, { headers: signed }));
  const html = await response.text();
  t.ok(response.status === 200 && html.includes('Audit app'), 'signed-in visitors receive app');
  t.ok(response.headers.get('cache-control') === 'private, no-store', 'authenticated pages cannot be cached');
  t.ok(response.headers.get('content-security-policy').includes("connect-src 'none'"), 'response enforces no client-data connections');
  t.ok(!html.includes(signed['oai-authenticated-user-email']), 'email is not included in client page');
  const other = await (await server.fetch(new Request(url, { headers: { ...signed, 'oai-authenticated-user-id': 'fictitious-user-b' } }))).text();
  t.ok(html !== other && /awp-storage-scope/.test(html), 'account identity is distinguished without including names or audit data');
  const head = await server.fetch(new Request(url, { method: 'HEAD', headers: signed }));
  t.ok(head.status === 200 && !(await head.text()), 'HEAD returns no content');
  const built = require('fs').readFileSync(require('path').join(__dirname,'../audit-working-papers.html'),'utf8');
  const protectedPage = await handler(built).fetch(new Request(url, {headers:signed}));
  const metaPolicy = built.match(/Content-Security-Policy" content="([^"]+)"/)[1];
  t.ok(protectedPage.headers.get('content-security-policy') === metaPolicy + "; frame-ancestors 'self'", 'HTTP and embedded script-hash policies agree');
  t.ok(!/unsafe-inline|'self'/.test(metaPolicy.split(';').find(s => s.trim().startsWith('script-src '))), 'hosted scripts cannot load injected same-origin code or event handlers');
  t.ok(protectedPage.headers.get('cross-origin-opener-policy') === 'same-origin', 'cross-origin windows are isolated');
  t.ok(protectedPage.headers.get('cross-origin-resource-policy') === 'same-origin', 'cross-origin resource inclusion blocked');
  t.done();
})().catch(e => { console.error(e); process.exitCode = 1; });
