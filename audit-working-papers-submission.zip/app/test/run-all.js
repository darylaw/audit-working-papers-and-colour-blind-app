/* Run every test file in test/ and summarise. Exit 1 if any fails.
   node test/run-all.js                                                    */
const fs = require('fs'), path = require('path'), { spawnSync } = require('child_process');
const dir = __dirname;
const files = ['harness.js', ...fs.readdirSync(dir).filter(f => /^test-.*\.js$/.test(f)).sort()];
let anyFail = false;
const rows = [];
for (const f of files) {
  const t0 = Date.now();
  const r = spawnSync(process.execPath, [path.join(dir, f)], { encoding: 'utf8', timeout: 180000 });
  const out = (r.stdout || '') + (r.stderr || '');
  const m = out.match(/(\d+) passed, (\d+) failed/);
  const passed = m ? +m[1] : 0, failed = m ? +m[2] : (r.status === 0 ? 0 : 1);
  const crashed = !m && r.status !== 0;
  if (failed || crashed) anyFail = true;
  rows.push({ f, passed, failed, crashed, ms: Date.now() - t0,
    fails: out.split('\n').filter(l => /^\s+FAIL/.test(l)).slice(0, 8),
    err: crashed ? out.split('\n').filter(l => /Error|at /.test(l)).slice(0, 6) : [] });
}
console.log('\n' + '='.repeat(72));
for (const r of rows) {
  const status = r.crashed ? 'CRASH' : r.failed ? 'FAIL ' : 'ok   ';
  console.log(`${status}  ${r.f.padEnd(22)} ${String(r.passed).padStart(3)} passed ${String(r.failed).padStart(3)} failed  ${(r.ms / 1000).toFixed(1)}s`);
  r.fails.forEach(l => console.log('        ' + l.trim()));
  r.err.forEach(l => console.log('        ' + l.trim()));
}
console.log('='.repeat(72));
const tp = rows.reduce((s, r) => s + r.passed, 0), tf = rows.reduce((s, r) => s + r.failed, 0);
console.log(`TOTAL ${tp} passed, ${tf} failed, ${rows.filter(r => r.crashed).length} crashed across ${rows.length} files\n`);
process.exit(anyFail ? 1 : 0);
