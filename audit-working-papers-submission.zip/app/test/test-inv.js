/* Headless end-to-end test of the Inventory module against the synthetic PBC files.
   Run:  node test/test-inv.js                                                     */

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const APP = path.join(__dirname, '..');
const SRC = path.join(APP, 'src');
const OUT = path.resolve(APP, '..', 'synthetic-data', 'out');

const XLSX = require(path.join(SRC, 'vendor', 'xlsx.full.min.js'));
XLSX.set_fs(fs);
const ctx = vm.createContext({ XLSX, console, Date, Math, JSON, Object, Array, String, Number, isNaN, parseFloat, parseInt, Map, Set, Intl, RegExp, Error });
const LOAD = [['core.js', 'Core'], ['spec.js', 'SpecUI'], ['ppe.js', 'PPEModule'], ['modules.js', 'Modules'],
              [path.join('modules', 'inv.js'), 'INVModule'], ['xlsxstyle.js', 'StyledXLSX'], ['wpstyle.js', 'WPStyle'], ['xlsxfile.js', 'FileExporter'], ['xlsxout.js', 'Exporter']];
for (const [f, name] of LOAD) vm.runInContext(fs.readFileSync(path.join(SRC, f), 'utf8') + `\n;globalThis.${name} = ${name};`, ctx, { filename: f });
const { Core, Modules, Exporter } = ctx;
const M = Modules.byCode.INV;

let pass = 0, fail = 0;
const ok = (cond, msg, extra) => { if (cond) { pass++; console.log('  PASS  ' + msg); } else { fail++; console.log('  FAIL  ' + msg + (extra ? '  → ' + extra : '')); } };
const money = n => n == null ? '—' : Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const expected = JSON.parse(fs.readFileSync(path.join(OUT, '_expected-exceptions.json'), 'utf8')).seeded_exceptions
  .filter(e => e.area === 'Inventory');

function engagement(yearEnd, om) {
  const e = { client: 'Test Entity Pte. Ltd.', firmRef: 'TEST/001', yearEnd, preparedBy: 'AB', datePrepared: '2026-01-15', reviewedBy: 'CD', dateReviewed: '2026-01-20',
    currency: 'USD', framework: 'IFRS / SFRS(I)', indexRef: { INV: 'K' },
    materiality: Core.computeMateriality({ basis: 'turnover', basisLabel: 'Turnover', benchmark: om / 0.02, rate: 0.02, pmPct: 0.75, trivialPct: 0.05 }), tbLink: {} };
  e.yearEndDate = new Date(yearEnd + 'T00:00:00Z');
  const d = new Date(e.yearEndDate.getTime()); d.setUTCDate(d.getUTCDate() + 1); d.setUTCFullYear(d.getUTCFullYear() - 1);  /* day first, then year: FYE 28 Feb 2025 -> FYS 1 Mar 2024, not 29 Feb */ e.fyStartDate = d;
  return e;
}
function pipeline(file, eng, cfgOverride = {}) {
  const buf = fs.readFileSync(file);
  const wbData = Core.readWorkbook(buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength), path.basename(file));
  const sheet = wbData.sheets[0];
  const headerRow = Core.detectHeader(sheet.rows);
  const clean = Core.cleanTable(sheet.rows, headerRow);
  const mapping = Core.proposeMapping(clean.headers, M.fields, clean.rows.filter(r => r.__kind === 'data').slice(0, 40));
  const built = Core.buildRecords(clean, M.fields, mapping);
  const cfg = M.defaultConfig();
  Object.assign(cfg, cfgOverride);
  const res = Core.runTests(M, built.records, cfg, eng);
  const p = { M, wbData, sheet, headerRow, clean, mapping, built, cfg, res, records: built.records, exceptions: res.exceptions, derived: res.derived, eng };
  p.rerun = () => { const r = Core.runTests(M, p.records, p.cfg, eng); p.exceptions = r.exceptions; p.derived = r.derived; return p; };
  p.asState = () => ({ engagement: eng, modules: { INV: { code: 'INV', records: p.records, mapping, derived: p.derived, exceptions: p.exceptions,
    sources: [{ fileName: path.basename(file), hash: wbData.hash, sheetName: sheet.name, headerRow, rowCount: built.records.length, uploadedAt: wbData.uploadedAt, rawRows: sheet.rows }],
    config: p.cfg, cleanLog: clean.log, mapIssues: built.issues, edits: [], adjustments: [], aiBlocks: [], pageNotes: {}, trail: [], comments: '', conclusion: '' } } });
  p.specCtx = () => ({ eng, cfg: p.cfg, d: p.derived, recs: p.records.filter(r => !r.__excluded), all: p.records, money: x => x, money0: x => x, pct: x => x,
    fmtDate: Core.fmtDate, r2: n => n == null ? null : Math.round(n * 100) / 100, pm: eng.materiality.pm, trivial: eng.materiality.trivial, M });
  return p;
}
const sheetName = s => s.replace(/[\[\]\*\?\/\\:]/g, '').slice(0, 31);
const findRec = (p, code) => p.records.find(r => String(r.item_code || '').trim().toUpperCase() === code.toUpperCase());
const raised = (p, id, code) => p.exceptions.some(e => e.id === id && (code == null || String(e.recordKey || '').trim().toUpperCase() === code.toUpperCase()));

function renderAll(p, label) {
  const st = p.asState().modules.INV, c = p.specCtx();
  let rendered = 0, failed = [];
  for (const pg of M.pages) {
    if (!pg.render) continue;
    try { const specs = pg.render(st, c); if (!Array.isArray(specs) || specs.some(s => !s || !s.type)) failed.push(pg.ref + ' (not an array of specs)'); else rendered++; }
    catch (e) { failed.push(`${pg.ref}: ${e.message}`); }
    if (pg.flag) { try { pg.flag(st, p.derived); } catch (e) { failed.push(`${pg.ref} flag: ${e.message}`); } }
  }
  ok(failed.length === 0, `${label}: every working paper renders (${rendered} pages)`, failed.join('; '));
  const wb = Exporter.build(p.asState(), 'INV');
  const missing = M.pages.filter(pg => pg.render).map(pg => sheetName(`${pg.ref} ${pg.title}`)).filter(n => !wb.SheetNames.includes(n));
  ok(missing.length === 0, `${label}: export has one sheet per rendered page (${wb.SheetNames.length} sheets)`, missing.join(', '));
  ok(['00 Index', 'Exceptions', '01 Source 1', '02 Cleaned data', '03 Mapping'].every(n => wb.SheetNames.includes(n)), `${label}: index, exceptions, source, cleaned and mapping sheets present`);
  return wb;
}

/* ====================================================================== */
const CLIENTS = [['client-a', '2025-02-28'], ['client-b', '2025-09-30'], ['client-d', '2025-09-30']];
const results = {};
for (const [c, ye] of CLIENTS) {
  console.log(`\n=== Inventory — ${c} ===`);
  const eng = engagement(ye, 145000);
  const file = path.join(OUT, c, `PBC-INV-01 Inventory listing ${ye}.xlsx`);
  const p = pipeline(file, eng);
  results[c] = p;
  const d = p.derived;
  console.log(`  header row ${p.headerRow + 1}, ${p.records.length} lines, ${d.byCategory.length} categories, groups=${p.clean.hasGroups}`);
  const req = M.fields.filter(f => f.required && !p.mapping[f.key] && !(f.satisfiedByGroup && p.clean.hasGroups));
  ok(req.length === 0, 'all required fields mapped', req.map(f => f.key).join(', '));
  console.log('  mapping: ' + Object.entries(p.mapping).filter(([, m]) => m).map(([k, m]) => `${k}←"${m.heading}"`).join(', '));
  ok(p.mapping.item_code && p.mapping.qty && p.mapping.unit_cost && p.mapping.total_cost, 'item code, quantity, unit cost and value resolved');
  ok(p.mapping.last_movement, 'last movement date column resolved');
  ok(p.records.length >= 20 && p.records.length <= 40, `line count sane (${p.records.length})`);
  ok(p.records.every(r => r.category), 'every line carries a category' + (p.clean.hasGroups ? ' (forward-filled from group headers)' : ''));
  const catNames = d.byCategory.map(x => x.category);
  ok(catNames.length >= 3 && catNames.length <= 5, `categories collapse case/whitespace variants: ${catNames.join(' | ')}`);

  /* K lead */
  d.byCategory.forEach(x => console.log(`    ${x.category.padEnd(26)} lines ${String(x.count).padStart(3)}  value ${money(x.value).padStart(14)}  re-extended ${money(x.extended).padStart(14)}  write-down ${money(x.writeDown).padStart(12)}`));
  console.log(`    ${'TOTAL'.padEnd(26)} lines ${String(d.totals.count).padStart(3)}  value ${money(d.totals.value).padStart(14)}`);
  ok(d.totals.value > 500000 && d.totals.value < 5000000, `listing total sane (${money(d.totals.value)})`);
  ok(Math.abs(d.byCategory.reduce((s, x) => s + x.value, 0) - d.totals.value) < 0.05, 'category values cross-cast to the total');
  ok(Math.abs(d.totals.value - p.records.filter(r => !r.__excluded).reduce((s, r) => s + (r.total_cost ?? 0), 0)) < 0.05, 'total equals the sum of the client value column');

  /* K1 */
  ok(d.anomalies.extension >= 1, `extension errors detected (${d.anomalies.extension})`);
  ok(d.uomVariants.some(u => u.canon === 'KG' && u.variants.length >= 2), 'UOM normalisation collapses KG / kg / Kgs', JSON.stringify(d.uomVariants.map(u => [u.canon, u.variants.map(v => v[0])])));
  /* K2 */
  const T = d.costTest;
  ok(T.threshold === eng.materiality.pm, 'cost testing threshold defaults to performance materiality');
  ok(T.key.every(r => r.__value >= T.threshold) && T.sample.every(r => r.__value < T.threshold), 'key items above threshold, sample drawn from below');
  ok(T.sample.length === Math.min(5, T.residual.length), `random sample of ${T.sample.length} drawn`);
  const p2 = pipeline(file, eng);
  ok(JSON.stringify(p2.derived.costTest.sample.map(r => r.__srcRow)) === JSON.stringify(T.sample.map(r => r.__srcRow)), 'same seed → same sample');
  const p3 = pipeline(file, eng, { costSeed: 7 });
  ok(JSON.stringify(p3.derived.costTest.sample.map(r => r.__srcRow)) !== JSON.stringify(T.sample.map(r => r.__srcRow)), 'different seed → different sample');
  console.log(`  K2: ${T.key.length} key + ${T.sample.length} sample of ${T.pool.length}; coverage ${T.coverage}%`);
  /* K4 */
  console.log('  K4 tiers: ' + d.slow.tiers.map(t => `${t.label}: ${t.count} · ${money(t.value)} → ${money(t.suggested)}`).join(' | ') + ` | no date: ${d.slow.noDate.count}`);
  ok(d.slow.tiers[3].count >= 1, 'items beyond the top tier identified');
  ok(d.slow.suggested > 0, `suggested provision computed (${money(d.slow.suggested)})`);
  const p4 = pipeline(file, eng, { tier3: 2000 });
  ok(p4.derived.slow.tiers[3].count <= d.slow.tiers[3].count && p4.derived.slow.suggested !== d.slow.suggested, 'moving the tier edge changes the suggested provision');

  /* planted exceptions */
  const ids = [...new Set(p.exceptions.map(e => e.id))].sort();
  console.log(`  exceptions: ${p.exceptions.length} → ${ids.join(', ')}`);
  for (const e of expected.filter(x => x.client === c)) {
    const id = e.exception.split(' ')[0];
    if (id === 'EX-INV-01' && !d.nrvMapped) {
      /* no NRV column in this listing: the auditor enters the post year-end selling price on K3 */
      const rec = findRec(p, e.record_key);
      ok(!!rec, `${id} ${e.record_key}: line found for NRV input`);
      if (rec) {
        rec.__wp = { nrv: { sellPrice: Math.round(rec.unit_cost * 0.42 * 100) / 100, postYeInvoice: 'Y' } };
        p.rerun();
        ok(raised(p, id, e.record_key), `${id} ${e.record_key}: raised from the post year-end selling price entered on K3`, `write-down ${rec.__writeDown}`);
        ok(p.derived.nrv.writeDown > 0 && p.derived.nrv.postYeSighted === 1, 'K3 write-down and evidence count update from the input');
      }
      continue;
    }
    ok(raised(p, id, e.record_key), `${e.exception} [${e.record_key}]`,
      p.exceptions.filter(x => x.id === id).map(x => x.recordKey).join(', ') || 'not raised at all');
  }
  ok(!p.exceptions.some(e => e.id === 'EX-INV-03' && (e.actual || 0) >= 0), 'EX-INV-03 only where the value is negative');
  const dup = p.exceptions.filter(e => e.id === 'EX-INV-10');
  ok(dup.length >= 1 && dup.every(e => /duplicate of row/.test(e.detail)), 'duplicate codes carry the row they duplicate');
  ok(!p.exceptions.some(e => e.id === 'EX-TIE-01'), 'EX-TIE-01 silent until trial balance figures are entered');
  ok(!p.exceptions.some(e => e.id === 'EX-INV-11'), 'EX-INV-11 silent until the cost of sales figures are entered');

  /* TB tie and COGS reconciliation through the config */
  const tbCfg = {};
  d.lead.forEach((l, i) => { tbCfg['tbGross:' + l.category] = i === 0 ? l.listValue + 5000 : l.listValue; tbCfg['pyGross:' + l.category] = l.listValue * 0.9; });
  const p5 = pipeline(file, eng, { ...tbCfg, tbProvision: 118240, cos: 2918400, pyCos: 3116950.79,
    cogsOpening: 1361089.51, cogsPurchases: 2918400 + d.totals.value - 1361089.51 - 20000, cogsPerPL: 2918400 });
  const tie = p5.exceptions.filter(e => e.id === 'EX-TIE-01');
  ok(tie.length === 1 && Math.abs(tie[0].difference + 5000) < 0.01 && tie[0].recordKey === d.lead[0].category, 'EX-TIE-01 raised for the one category that does not agree (−5,000)');
  ok(p5.derived.invDays > 0 && p5.derived.pyDays > 0, `inventory days computed (${p5.derived.invDays} vs PY ${p5.derived.pyDays})`);
  ok(p5.derived.net.tb != null && Math.abs(p5.derived.net.listing - (d.totals.value - 118240)) < 0.01, 'gross to net computed with the provision');
  const cogs = p5.exceptions.find(e => e.id === 'EX-INV-11');
  ok(cogs && Math.abs(cogs.difference - 20000) < 0.01, 'EX-INV-11 raised when the cost of sales reconciliation is out by 20,000', cogs && cogs.difference);
  const p6 = pipeline(file, eng, { cogsOpening: 1000000, cogsPurchases: 2918400 + d.totals.value - 1000000, cogsPerPL: 2918400 });
  ok(!p6.exceptions.some(e => e.id === 'EX-INV-11') && Math.abs(p6.derived.cogs.diff) < 0.01, 'EX-INV-11 silent when the reconciliation agrees');

  /* K5 / K6 inputs via __key rows */
  const p7 = pipeline(file, eng, { countDate: ye === '2025-02-28' ? '2025-02-26' : '2025-09-28', 'perSheet:c1': 100, 'perCount:c1': 98, 'unitCost:c1': 12.5,
    'perSheet:c2': 50, 'perCount:c2': 50, rfPerCount: d.totals.value - 1000, rfPurchases: 1000,
    'type:k1': 'GRN before year end', 'inInventory:k1': 'N', 'inLedger:k1': 'Y', 'amount:k1': 4000,
    'type:k2': 'DO after year end', 'inInventory:k2': 'Y', 'inLedger:k2': 'N' });
  const C = p7.derived.count, K = p7.derived.cutoff;
  ok(C.rows[0].variance === -2 && C.rows[0].varianceValue === -25 && C.rows[1].status === 'Agreed' && C.variances === 1, 'K5 test-count variances computed from the input rows');
  ok(C.rf.needed && C.rf.implied === d.totals.value && C.rf.diff === 0, 'K5 roll-forward computed when the count date differs from the year end');
  ok(K.rows[0].assessment === 'Cut-off error' && K.rows[1].assessment === 'Correct' && K.errors === 1 && K.errorValue === 4000, 'K6 cut-off assessment derived from document type and answers');

  /* K2 / K4 record-level inputs */
  const sel = p.derived.costTest.selected[0];
  sel.__wp = Object.assign(sel.__wp || {}, { cost: { invNo: 'INV-1', invUnitCost: sel.unit_cost + 1, method: 'FIFO' } });
  const slowRec = p.derived.slow.rows[0];
  if (slowRec) slowRec.__wp = Object.assign(slowRec.__wp || {}, { slow: { agreed: 'Y', explanation: 'test' } });
  p.rerun();
  ok(p.derived.costTest.vouched >= 1 && sel.__invDiff === 1 && sel.__invDiffExt === Math.round(sel.qty * 100) / 100 && p.derived.costTest.inconsistent === 1, 'K2 vouching inputs feed the cost difference and policy-consistency count');
  ok(!slowRec || p.derived.slow.agreed >= 1, 'K4 provision-agreed input counted');

  /* every page renders; export */
  const wb = renderAll(p, c);
  if (c === 'client-a') {
    const ws = wb.Sheets[sheetName('K1 Extension & casting')];
    const formulas = Object.keys(ws).filter(k => k[0] !== '!' && ws[k].f);
    ok(formulas.length >= 2, `K1 exports live extension formulas (${formulas.length})`, formulas.slice(0, 2).map(k => ws[k].f).join(' ; '));
    const out = path.join(__dirname, 'out-INV-file.xlsx');
    XLSX.writeFile(wb, out);
    const re = XLSX.readFile(out);
    ok(re.SheetNames.length === wb.SheetNames.length, 'workbook survives the Excel round-trip');
    fs.unlinkSync(out);
    const concl = M.suggestConclusion(p.asState().modules.INV, p.specCtx());
    ok(typeof concl === 'string' && concl.length > 100, 'template conclusion generated');
  }
}

console.log(`\n${'='.repeat(60)}\n  ${pass} passed, ${fail} failed\n${'='.repeat(60)}\n`);
process.exit(fail ? 1 : 0);
