/* Headless end-to-end test against the real synthetic PBC files.
   Run:  node test/harness.js                                              */

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const APP = path.join(__dirname, '..');
const SRC = path.join(APP, 'src');
const OUT = path.resolve(APP, '..', 'synthetic-data', 'out');

const XLSX = require(path.join(SRC, 'vendor', 'xlsx.full.min.js'));
XLSX.set_fs(fs);
const ctx = vm.createContext({ XLSX, console, Date, Math, JSON, Object, Array, String, Number, isNaN, parseFloat, parseInt, Map, Set, Intl, RegExp, Error });
for (const [f, name] of Object.entries({ "core.js": "Core", "spec.js": "SpecUI", "ppe.js": "PPEModule", "modules.js": "Modules", "xlsxstyle.js": "StyledXLSX", "wpstyle.js": "WPStyle", "xlsxfile.js": "FileExporter", "xlsxout.js": "Exporter" })) {
  vm.runInContext(fs.readFileSync(path.join(SRC, f), 'utf8') + `\n;globalThis.${name} = ${name};`, ctx, { filename: f });
}
const { Core, Modules, Exporter } = ctx;

let pass = 0, fail = 0;
const ok = (cond, msg, extra) => { if (cond) { pass++; console.log('  PASS  ' + msg); } else { fail++; console.log('  FAIL  ' + msg + (extra ? '  → ' + extra : '')); } };
const money = n => n == null ? '—' : Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

function engagement(yearEnd, om) {
  const e = { client: 'Test Entity Pte. Ltd.', firmRef: 'TEST/001', yearEnd, preparedBy: 'AB', datePrepared: '2026-01-15', reviewedBy: 'CD', dateReviewed: '2026-01-20',
    currency: 'USD', framework: 'IFRS / SFRS(I)', indexRef: { PPE: 'E3' },
    materiality: Core.computeMateriality({ basis: 'turnover', basisLabel: 'Turnover', benchmark: om / 0.02, rate: 0.02, pmPct: 0.75, trivialPct: 0.05 }), tbLink: {} };
  e.yearEndDate = new Date(yearEnd + 'T00:00:00Z');
  const d = new Date(e.yearEndDate.getTime()); d.setUTCDate(d.getUTCDate() + 1); d.setUTCFullYear(d.getUTCFullYear() - 1);  /* day first, then year: FYE 28 Feb 2025 -> FYS 1 Mar 2024, not 29 Feb */ e.fyStartDate = d;
  return e;
}
function pipeline(file, moduleCode, eng, cfgOverride = {}) {
  const M = Modules.byCode[moduleCode];
  const buf = fs.readFileSync(file);
  const wbData = Core.readWorkbook(buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength), path.basename(file));
  const sheet = wbData.sheets[0];
  const headerRow = Core.detectHeader(sheet.rows);
  const clean = Core.cleanTable(sheet.rows, headerRow);
  const mapping = Core.proposeMapping(clean.headers, M.fields, clean.rows.filter(r => r.__kind === 'data').slice(0, 40));
  const built = Core.buildRecords(clean, M.fields, mapping);
  const cfg = M.defaultConfig ? M.defaultConfig() : Object.fromEntries((M.config || []).map(c => [c.key, c.def]));
  Object.assign(cfg, cfgOverride);
  const res = Core.runTests(M, built.records, cfg, eng);
  return { M, wbData, sheet, headerRow, clean, mapping, built, cfg, res, records: built.records, exceptions: res.exceptions, derived: res.derived,
    asState(eng2) { return { engagement: eng2 || eng, modules: { [moduleCode]: { code: moduleCode, ...this,
      sources: [{ fileName: path.basename(file), hash: wbData.hash, sheetName: sheet.name, headerRow, rowCount: built.records.length, uploadedAt: wbData.uploadedAt, rawRows: sheet.rows }],
      config: cfg, cleanLog: clean.log, mapIssues: built.issues, edits: [], adjustments: [], aiBlocks: [], pageNotes: {}, trail: [], comments: '', conclusion: '' } } }; } };
}

/* ====================================================================== */
console.log('\n=== Unit: number parsing ===');
[['1,234.56', 1234.56], ['(1,234.56)', -1234.56], ['1234.56-', -1234.56], ['SGD 1,234.56', 1234.56], ['-', 0], ['400,000.00', 400000]]
  .forEach(([inp, exp]) => { const r = Core.parseNumber(inp); ok(r.ok && Math.abs(r.value - exp) < 1e-9, `parseNumber("${inp}") → ${exp}`); });
ok(Core.parseNumber('').blank === true, 'blank stays distinct from zero');
ok(Core.parseNumber('n/a').ok === false, 'unparseable text is not silently zeroed');

console.log('\n=== Unit: date column vote ===');
ok(Core.resolveDateColumn(['13/04/2023', '05/07/2023']).order === 'dmy', 'day>12 present → dd/mm resolved');
const amb = Core.resolveDateColumn(['05/07/2023', '01/02/2023']);
ok(amb.order === null && amb.ambiguous === true, 'no disambiguating value → flagged ambiguous, not guessed');

/* ====================================================================== */
console.log('\n=== PPE audit file — Client A ===');
{
  const eng = engagement('2025-02-28', 145000);
  const p = pipeline(path.join(OUT, 'client-a', 'PBC-PPE-01 Fixed asset register 2025-02-28.xlsx'), 'PPE', eng, { addSampleN: 5 });
  const d = p.derived;
  console.log(`  header row ${p.headerRow + 1}, ${p.records.length} assets, ${d.byCategory.length} categories, life unit ${d.lifeUnit}`);
  ok(p.headerRow === 4 && p.records.length > 50, 'listing read and cleaned');
  const req = p.M.fields.filter(f => f.required && !p.mapping[f.key] && !(f.satisfiedByGroup && p.clean.hasGroups));
  ok(req.length === 0, 'all required fields resolved', req.map(f => f.key).join(', '));
  ok(p.mapping.additions.colIndex !== p.mapping.dep_charge.colIndex, 'Additions (cost) vs Depreciation charge resolved to different columns via block header');

  /* E3.1 movement */
  console.log('  E3.1 movement by category:');
  d.byCategory.forEach(c => console.log(`    ${c.category.padEnd(26)} cost c/f ${money(c.cost_close).padStart(14)}  acc dep ${money(c.accdep_close).padStart(14)}  NBV ${money(c.nbv_close).padStart(14)}  (${c.count} assets)`));
  console.log(`    ${'TOTAL'.padEnd(26)} cost c/f ${money(d.totals.cost_close).padStart(14)}  acc dep ${money(d.totals.accdep_close).padStart(14)}  NBV ${money(d.totals.nbv_close).padStart(14)}`);
  ok(d.byCategory.length >= 5, `${d.byCategory.length} categories in the movement schedule`);
  const sumNBV = d.byCategory.reduce((s, c) => s + c.nbv_close, 0);
  ok(Math.abs(sumNBV - d.totals.nbv_close) < 0.05, 'movement schedule cross-casts');
  console.log(`  cast checks: cost ${money(d.castCost)}, acc dep ${money(d.castDep)}  (non-nil = client's c/f column disagrees with its own roll-forward)`);

  /* E3.2 depreciation */
  console.log(`  E3.2 depreciation: per audit ${money(d.totals.expected)} vs per client ${money(d.totals.dep_charge)} → ${money(d.totals.depDiff)}`);
  ok(d.totals.expected > 0, 'depreciation recalculated');
  const p2 = pipeline(path.join(OUT, 'client-a', 'PBC-PPE-01 Fixed asset register 2025-02-28.xlsx'), 'PPE', eng, { convention: 'full-year' });
  console.log(`  convention full-year → per audit ${money(p2.derived.totals.expected)}`);
  ok(p2.derived.totals.expected !== d.totals.expected, 'changing the depreciation convention changes the recalculation');
  const p3 = pipeline(path.join(OUT, 'client-a', 'PBC-PPE-01 Fixed asset register 2025-02-28.xlsx'), 'PPE', eng, { recalcBasis: 'policy', lifePolicy: Object.fromEntries(d.byCategory.map(c => [c.category, 10])) });
  ok(p3.derived.totals.expected !== d.totals.expected, 'recalculating on a category policy life changes the result');

  /* E3.3 additions */
  const Ad = d.additions;
  console.log(`  E3.3 additions: ${Ad.all.length} in year (${money(Ad.total)}); threshold ${money(Ad.threshold)}; key ${Ad.key.length} (${money(Ad.keyValue)}); sample ${Ad.sample.length} (${money(Ad.sampleValue)}); coverage ${Ad.coverage}%`);
  ok(Ad.threshold === eng.materiality.pm, 'threshold defaults to performance materiality');
  ok(Ad.key.every(r => r.additions >= Ad.threshold), 'every key item is at or above the threshold');
  ok(Ad.sample.length === Math.min(5, Ad.residual.length), 'random sample of the requested size drawn from the residual');
  ok(Ad.sample.every(r => r.additions < Ad.threshold), 'sample drawn only from below-threshold additions');
  const p4 = pipeline(path.join(OUT, 'client-a', 'PBC-PPE-01 Fixed asset register 2025-02-28.xlsx'), 'PPE', eng, { addSampleN: 5 });
  ok(JSON.stringify(p4.derived.additions.sample.map(r => r.__srcRow)) === JSON.stringify(Ad.sample.map(r => r.__srcRow)), 'same seed → identical sample (reproducible)');
  const p5 = pipeline(path.join(OUT, 'client-a', 'PBC-PPE-01 Fixed asset register 2025-02-28.xlsx'), 'PPE', eng, { addSampleN: 5, addSeed: 99 });
  ok(JSON.stringify(p5.derived.additions.sample.map(r => r.__srcRow)) !== JSON.stringify(Ad.sample.map(r => r.__srcRow)), 'different seed → different sample');
  const p6 = pipeline(path.join(OUT, 'client-a', 'PBC-PPE-01 Fixed asset register 2025-02-28.xlsx'), 'PPE', eng, { addThreshold: 1000 });
  ok(p6.derived.additions.key.length > Ad.key.length, 'lowering the threshold selects more key items');

  /* E3.4 disposals */
  console.log(`  E3.4 disposals: ${d.disposals.length}, ${d.disposals.filter(x => x.noWriteBack).length} with no acc dep write-back`);
  ok(d.disposals.length > 0, 'disposals identified');
  ok(d.disposals.some(x => x.noWriteBack), 'planted disposal-without-write-back detected');

  /* E3.5 impairment */
  const I = d.impairment;
  console.log(`  E3.5 impairment: ${I.candidates.length} candidates, NBV ${money(I.candidateValue)} (${I.coverage}% of total)`);
  const byRule = {}; I.candidates.forEach(c => c.rules.forEach(r => byRule[r] = (byRule[r] || 0) + 1));
  console.log('    by rule: ' + Object.entries(byRule).map(([k, v]) => `${k}×${v}`).join(', '));
  ok(I.candidates.length > 0, 'impairment candidates identified from the listing');
  ok(byRule.C1 > 0, 'C1 fully-depreciated-still-held detected');
  ok(byRule.C2 > 0, 'C2 negative NBV detected');
  const p7 = pipeline(path.join(OUT, 'client-a', 'PBC-PPE-01 Fixed asset register 2025-02-28.xlsx'), 'PPE', eng,
    { indicators: { '12b': { answer: 'Y', categories: [d.byCategory[0].category], comment: 'test' } } });
  const c7 = p7.derived.impairment.candidates.filter(c => c.rules.includes('C7'));
  ok(c7.length > 0 && c7.every(c => c.r.category === d.byCategory[0].category), 'answering an indicator Y for a category makes its assets candidates (C7)');

  /* exceptions */
  const ids = [...new Set(p.exceptions.map(e => e.id))].sort();
  console.log('  exceptions: ' + p.exceptions.length + ' → ' + ids.join(', '));
  ['EX-PPE-03', 'EX-PPE-04', 'EX-PPE-09', 'EX-PPE-10'].forEach(id => ok(ids.includes(id), id + ' raised'));
  /* the per-asset depreciation rule respects the tolerance: silent at trivial, fires when tightened */
  const pt = pipeline(path.join(OUT, 'client-a', 'PBC-PPE-01 Fixed asset register 2025-02-28.xlsx'), 'PPE', eng, { depTol: 50 });
  ok(pt.exceptions.some(e => e.id === 'EX-PPE-01'), 'EX-PPE-01 fires when the per-asset tolerance is tightened to 50');
  ok(!p.exceptions.some(e => e.id === 'EX-PPE-01'), 'EX-PPE-01 silent at the trivial threshold (no single asset exceeds it)');

  /* export */
  const wb = Exporter.build(p.asState(), 'PPE');
  console.log('  sheets: ' + wb.SheetNames.join(' | '));
  ['00 Index', 'E3 Lead', 'E3.1 Movement', 'E3.2 Depreciation', 'E3.3 Additions', 'E3.4 Disposals', 'E3.5 Impairment', 'E3.9 Exceptions', '01 Source 1', '02 Cleaned listing'].forEach(n => ok(wb.SheetNames.includes(n), `sheet "${n}"`));
  const countF = ws => Object.keys(ws).filter(k => k[0] !== '!' && ws[k].f).length;
  const fList = countF(wb.Sheets['02 Cleaned listing']), fMove = countF(wb.Sheets['E3.1 Movement']), fLead = countF(wb.Sheets['E3 Lead']), fDep = countF(wb.Sheets['E3.2 Depreciation']);
  console.log(`  live formulas: listing ${fList}, lead ${fLead}, movement ${fMove}, depreciation ${fDep}`);
  ok(fList > 400, 'per-asset roll-forward and depreciation written as formulas on the listing');
  ok(fMove > 30 && fLead > 30, 'movement and lead schedules built from SUMIF formulas over the listing');
  const sample = Object.entries(wb.Sheets['E3.1 Movement']).find(([k, c]) => k[0] !== '!' && c.f && /SUMIF/.test(c.f));
  if (sample) console.log(`  e.g. E3.1!${sample[0]} = ${sample[1].f}`);
  const out = path.join(__dirname, 'out-PPE-file.xlsx');
  XLSX.writeFile(wb, out);
  const re = XLSX.readFile(out, { cellFormula: true });
  ok(countF(re.Sheets['E3.1 Movement']) === fMove, 'formulas survive the Excel round-trip');
  fs.unlinkSync(out);
}

/* ====================================================================== */
console.log('\n=== PPE — Client B and Client D (different vocabularies) ===');
for (const [c, ye] of [['client-b', '2025-09-30'], ['client-d', '2025-09-30']]) {
  const eng = engagement(ye, 145000);
  const p = pipeline(path.join(OUT, c, `PBC-PPE-01 Fixed asset register ${ye}.xlsx`), 'PPE', eng);
  const missing = p.M.fields.filter(f => f.required && !p.mapping[f.key] && !(f.satisfiedByGroup && p.clean.hasGroups));
  ok(missing.length === 0, `${c}: required fields mapped from a different heading vocabulary`, missing.map(f => f.key).join(', '));
  ok(p.derived.byCategory.length > 0 && p.derived.totals.expected > 0, `${c}: movement schedule and depreciation computed (${p.derived.byCategory.length} categories)`);
}

/* ====================================================================== */
console.log('\n=== AR + FRS 109 — generic flow still works ===');
{
  const eng = engagement('2025-02-28', 145000);
  const p = pipeline(path.join(OUT, 'client-a', 'PBC-AR-01 Trade receivables listing 2025-02-28.xlsx'), 'AR', eng, { recordedAllowance: 96400 });
  ok(p.derived.ecl > 0 && p.derived.matrix.some(m => m.count > 0), `AR aging rebuilt, ECL ${money(p.derived.ecl)}`);
  ok(p.exceptions.some(e => e.id === 'EX-ECL-09'), 'matrix-to-ledger difference raised');
  const wb = Exporter.build(p.asState(), 'AR');
  ok(wb.SheetNames.includes('07 Supporting Workings'), 'AR generic export still produces the provision matrix sheet');
}
console.log('\n=== TB ===');
{
  const eng = engagement('2025-02-28', 145000);
  const p = pipeline(path.join(OUT, 'client-a', 'PBC-TB-01 Trial balance 2025-02-28.xlsx'), 'TB', eng);
  ok(p.records.length > 60 && p.exceptions.some(e => e.id === 'EX-TIE-02'), 'trial balance read and imbalance detected');
}

console.log(`\n${'='.repeat(60)}\n  ${pass} passed, ${fail} failed\n${'='.repeat(60)}\n`);
process.exit(fail ? 1 : 0);
