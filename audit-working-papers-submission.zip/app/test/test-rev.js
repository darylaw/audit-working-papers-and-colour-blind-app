/* Headless test of the REV (revenue) audit file against the synthetic sales listings.
   Run:  node test/test-rev.js                                                        */
const { load, counter, money, engagement, pipeline, expectedExceptions, OUT, path, fs } = require('./spec-lib');
const L = load(['rev.js']);
const t = counter();
const CODE = 'REV';

const CLIENTS = [
  { c: 'client-a', ye: '2025-02-28', file: 'PBC-REV-01 Sales listing 2025-02-28.xlsx' },
  { c: 'client-b', ye: '2025-09-30', file: 'PBC-REV-01 Sales listing 2025-09-30.csv' },
  { c: 'client-d', ye: '2025-09-30', file: 'PBC-REV-01 Sales listing 2025-09-30.xlsx' }
];

console.log('\n=== REV — module registration ===');
t.ok(L.Modules.byCode.REV && L.Modules.byCode.REV.name === 'Revenue', 'REV registered via Modules.register');
t.ok(L.Modules.byCode.REV.pages.filter(p => p.render).length === 7, 'seven rendered working papers (Z1, Z1.1–Z1.6)');

for (const { c, ye, file: f } of CLIENTS) {
  const eng = engagement(L.Core, ye, 145000);
  const file = path.join(OUT, c, f);
  if (!fs.existsSync(file)) { console.log('  skip (missing) ' + f); continue; }
  const label = c + (f.endsWith('.csv') ? ' (csv)' : '');
  console.log(`\n=== ${label} / ${f} ===`);
  const p = pipeline(L, file, CODE, eng, { sampleN: 5 });
  const d = p.derived, Lz = d.lead;
  console.log(`  header row ${p.headerRow + 1}; ${p.records.length} documents (${Lz.invoices} invoices, ${Lz.cns} credit notes); total ${money(Lz.total)}; in period ${money(Lz.inPeriod)}; after YE ${money(Lz.afterYE)}`);
  t.ok(p.missingRequired().length === 0, `${label}: required fields mapped`, p.missingRequired().join(', '));
  ['qty', 'unit_price', 'tax', 'gross', 'do_date', 'segment', 'product'].forEach(k => t.ok(p.mapping[k], `${label}: ${k} mapped (${p.mapping[k]?.heading})`));
  t.ok(Math.abs(Lz.total - p.records.reduce((s, r) => s + (r.amount || 0), 0)) < 0.005, `${label}: lead total casts to the listing`);
  t.ok(Lz.cns >= 1 && p.records.filter(r => r.__isCN).every(r => /^CN/.test(r.invoice_no) && r.amount < 0), `${label}: credit notes recognised by prefix and sign`);
  t.ok(Math.abs(Lz.inPeriod + Lz.afterYE + Lz.beforeFY + Lz.undated - Lz.total) < 0.01, `${label}: period split casts to the total`);
  t.ok(d.bySegment.length >= 2 && Math.abs(d.bySegment.reduce((s, x) => s + x.amount, 0) - Lz.total) < 0.05, `${label}: segment table cross-casts (${d.bySegment.length} segments)`);
  t.ok(Math.abs(d.byStream.reduce((s, x) => s + x.amount, 0) - Lz.total) < 0.05, `${label}: revenue stream table cross-casts (${d.byStream.length} streams)`);

  /* planted exceptions */
  const planted = expectedExceptions('Revenue', c);
  for (const x of planted) {
    const id = x.exception.split(' ')[0];
    const hit = p.exceptions.find(e => e.id === id && e.recordKey === x.record_key);
    t.ok(hit, `${label}: ${x.exception} → ${x.record_key}`, JSON.stringify(p.exceptions.filter(e => e.id === id).map(e => e.recordKey)));
  }
  const e03 = p.exceptions.find(e => e.id === 'EX-REV-03');
  t.ok(e03 && /Reverses invoice SI-/.test(e03.detail), `${label}: post year-end credit note linked to its original invoice`, e03 && e03.detail);
  t.ok(!p.exceptions.some(e => e.id === 'EX-REV-01' && /^CN/.test(e.recordKey)), `${label}: credit notes are not double-counted as post year-end invoices`);
  const e04 = p.exceptions.filter(e => e.id === 'EX-REV-04');
  t.ok(e04.every(e => e.expected != null && e.actual != null && Math.abs(e.difference - (e.actual - e.expected)) < 0.02), `${label}: EX-REV-04 carries qty × price, recorded amount and difference (${e04.length})`);
  const e07 = p.exceptions.filter(e => e.id === 'EX-REV-07');
  t.ok(e07.length === 1 && e07[0].actual % 10000 === 0, `${label}: EX-REV-07 raised only for the round sum immediately before the year end`, JSON.stringify(e07.map(e => e.recordKey)));

  /* Z1.1 monthly */
  t.ok(d.monthly.length === 12, `${label}: twelve months in the analysis`);
  t.ok(Math.abs(d.monthly.reduce((s, m) => s + m.amount, 0) - Lz.inPeriod) < 0.05, `${label}: monthly table cross-casts to in-period revenue`);
  t.ok(d.monthly.slice(1).every(m => m.mom == null || Math.abs(m.mom - (m.amount - d.monthly[d.monthly.indexOf(m) - 1].amount)) < 0.02), `${label}: month-on-month movement computed`);

  /* Z1.2 recalculation */
  t.ok(d.recalc.rows.length === p.records.length, `${label}: every line recalculated`);
  t.ok(d.recalc.negPrice.length >= 1 && d.recalc.noCustomer.length >= 1 && d.recalc.dups.length >= 1, `${label}: negative price, missing customer and duplicate lists populated`);

  /* Z1.3 cut-off */
  t.ok(d.cutoff.early.length >= 1 && d.cutoff.early.every(r => r.do_date > eng.yearEndDate && r.invoice_date <= eng.yearEndDate), `${label}: early-recognition items have delivery after YE and invoice before`);
  t.ok(d.cutoff.rows.every(r => r.__inCutoffWindow || r.__afterYE || r.__deliveredAfterYE || r.__deliveredBeforeInvoicedAfter), `${label}: cut-off rows are all within the window or flagged`);

  /* Z1.5 sample */
  const S = d.sampling;
  console.log(`  Z1.5: threshold ${money(S.threshold)}; ${S.key.length} key + ${S.sample.length} sample of ${S.pop.length}; coverage ${S.coverage}%`);
  t.ok(S.threshold === eng.materiality.pm, `${label}: sample threshold defaults to performance materiality`);
  t.ok(S.key.every(r => r.amount >= S.threshold) && S.sample.every(r => r.amount < S.threshold), `${label}: key items above and sample below the threshold`);
  t.ok(S.pop.every(r => !r.__isCN && !r.__afterYE), `${label}: population excludes credit notes and post year-end invoices`);
  t.ok(S.sample.length === Math.min(5, S.residual.length), `${label}: sample size honoured`);
  t.ok(S.coverage > 0 && S.coverage <= 100.01, `${label}: coverage ${S.coverage}%`);
  const p2 = pipeline(L, file, CODE, eng, { sampleN: 5 });
  t.ok(JSON.stringify(p2.derived.sampling.sample.map(r => r.__srcRow)) === JSON.stringify(S.sample.map(r => r.__srcRow)), `${label}: same seed → identical sample`);
  const p3 = pipeline(L, file, CODE, eng, { sampleN: 5, sampleSeed: 99 });
  t.ok(S.residual.length <= 5 || JSON.stringify(p3.derived.sampling.sample.map(r => r.__srcRow)) !== JSON.stringify(S.sample.map(r => r.__srcRow)), `${label}: different seed → different sample`);
  const e11 = p.exceptions.filter(e => e.id === 'EX-REV-11');
  t.ok(e11.length === S.key.length && e11.every(e => e.severity === 'informational'), `${label}: EX-REV-11 lists every key item as not yet vouched (${S.key.length})`);
  const pv = pipeline(L, file, CODE, eng, { sampleN: 5 }, recs => recs.forEach(r => { if (!r.__isCN && (r.amount || 0) >= eng.materiality.pm) r.__wp = { sample: { invoice: 'Y', delivery: 'Y', amountAgreed: 'Y', period: 'Y' } }; }));
  t.ok(!pv.exceptions.some(e => e.id === 'EX-REV-11'), `${label}: EX-REV-11 clears once the auditor records the items as agreed`);

  /* Z1.6 concentration */
  const K = d.concentration;
  t.ok(K.customers.length > 1 && Math.abs(K.customers[K.customers.length - 1].cumulative - 100) < 0.2, `${label}: customer shares cumulate to 100% (${K.customers.length} customers)`);
  t.ok(K.customers.every(c => c.count >= 1) && Math.abs(K.customers.reduce((s, x) => s + x.amount, 0) - K.invTotal) < 0.05, `${label}: customer table cross-casts to invoiced revenue`);

  /* TB tie */
  const pTB = pipeline(L, file, CODE, eng, { tbRevenue: Lz.total - 500 });
  const e20 = pTB.exceptions.find(e => e.id === 'EX-REV-20');
  t.ok(e20 && Math.abs(e20.difference - 500) < 0.005, `${label}: EX-REV-20 raised with the right difference`);
  t.ok(!pipeline(L, file, CODE, eng, { tbRevenue: Lz.total }).exceptions.some(e => e.id === 'EX-REV-20'), `${label}: EX-REV-20 silent when the TB agrees`);
  const seg = d.bySegment[0];
  const pSeg = pipeline(L, file, CODE, eng, { ['tbSeg:' + seg.key]: seg.amount + 10 });
  const e20s = pSeg.exceptions.filter(e => e.id === 'EX-REV-20');
  t.ok(e20s.length === 1 && e20s[0].recordKey === seg.segment && Math.abs(e20s[0].difference + 10) < 0.005, `${label}: EX-REV-20 by segment fires for the segment entered only`);

  p.renderAll(t, label);
  p.exportCheck(t, label);
}

/* ---------------------------------------------------------------------- */
console.log('\n=== REV — controls and inputs (client-a) ===');
{
  const eng = engagement(L.Core, '2025-02-28', 145000);
  const file = path.join(OUT, 'client-a', 'PBC-REV-01 Sales listing 2025-02-28.xlsx');
  const base = pipeline(L, file, CODE, eng);
  const pW = pipeline(L, file, CODE, eng, { cutoffDays: 60 });
  t.ok(pW.derived.cutoff.rows.length >= base.derived.cutoff.rows.length, 'widening the cut-off window selects at least as many items');
  const pR = pipeline(L, file, CODE, eng, { roundSum: 1000000 });
  t.ok(!pR.exceptions.some(e => e.id === 'EX-REV-07'), 'raising the round-sum multiple silences EX-REV-07');
  const pM = pipeline(L, file, CODE, eng, { momThreshold: 1 });
  t.ok(pM.derived.monthlyStats.flagged.length >= base.derived.monthlyStats.flagged.length && pM.exceptions.filter(e => e.id === 'EX-REV-12').length === pM.derived.monthlyStats.flagged.length, 'lower month-on-month threshold flags more months, one EX-REV-12 per month');
  const pT = pipeline(L, file, CODE, eng, { taxRate: 9 });
  t.ok(pT.records.some(r => r.__expTax != null) && pT.exceptions.some(e => e.id === 'EX-REV-04c'), 'a standard tax rate recomputes expected tax and flags differences');
  const pD = pipeline(L, file, CODE, eng, { domesticPattern: 'zzz-no-match' });
  t.ok(!pD.exceptions.some(e => e.id === 'EX-REV-05'), 'domestic pattern control drives the no-tax test');
  const pK = pipeline(L, file, CODE, eng, { concThreshold: 1 });
  t.ok(pK.exceptions.filter(e => e.id === 'EX-REV-13').length === pK.derived.concentration.customers.filter(c => c.share >= 1).length, 'EX-REV-13 one per customer above the concentration threshold');
  const pCut = pipeline(L, file, CODE, eng, {}, recs => recs.filter(r => r.__srcRow === base.derived.cutoff.rows[0].__srcRow).forEach(r => r.__wp = { cutoff: { correct: 'N', doSighted: 'Y' } }));
  t.ok(pCut.derived.cutoff.wrong.length === 1 && pCut.derived.cutoff.tested === 1, 'cut-off inputs feed the tested / wrong-period counts');
  const pCN = pipeline(L, file, CODE, eng, {}, recs => recs.filter(r => /^CN/.test(r.invoice_no)).forEach(r => r.__wp = { cn: { adjust: 'Y', reason: 'Goods returned' } }));
  t.ok(pCN.derived.creditNotes.adjust.length === 1, 'credit note adjustment input counted');

  const wb = pCN.exportCheck(t, 'client-a with inputs');
  const ws = wb.Sheets['Z1.4 Post year-end credit notes'];
  t.ok(ws && Object.values(ws).some(c => c && c.v === 'Goods returned'), 'Z1.4 export carries the auditor\'s reason for the credit');
  const out = path.join(__dirname, 'out-REV-file.xlsx');
  L.XLSX.writeFile(wb, out);
  const re = L.XLSX.readFile(out);
  t.ok(re.SheetNames.length === wb.SheetNames.length, 'workbook survives the Excel round-trip');
  fs.unlinkSync(out);
  const st = pCN.state().modules.REV;
  const text = L.Modules.byCode.REV.suggestConclusion(st, pCN.ctx());
  t.ok(typeof text === 'string' && text.length > 100, 'suggestConclusion produces text');
}

t.done();
