/* ===========================================================================
   test-methods.js  —  depreciation and amortisation methods
   ---------------------------------------------------------------------------
   The method is an auditor control, not a column copied out of the register, so
   the arithmetic behind each option has to be right on its own terms and the
   choice has to change the recalculation. Worked examples are computed by hand
   below so a reviewer can check them without running anything.
   =========================================================================== */
'use strict';
const S = require('./spec-lib.js');
const { fs, path, counter } = S;

const t = counter();
const L = S.load(fs.readdirSync(path.join(S.APP, 'src', 'modules')).filter(f => f.endsWith('.js')));
const { Core, Modules } = L;
const PPE = Modules.byCode.PPE, IA = Modules.byCode.IA;
const near = (a, b, tol = 0.01) => a != null && Math.abs(a - b) <= tol;
const r2 = n => Math.round(n * 100) / 100;

/* ------------------------------------------------------------ arithmetic */
console.log('=== Methods — the arithmetic of each option ===');
const charge = PPE.charge;

/* Cost 100,000, five-year life, held all year, nothing written off yet. */
const full = { base: 100000, opened: 0, life: 5, months: 12, rate: 0, age: 0 };
t.ok(near(charge('sl', full), 20000), 'straight line: 100,000 over 5 years = 20,000');
t.ok(near(charge('ddb', full), 40000), 'double declining: 100,000 x 2/5 = 40,000');
t.ok(near(charge('db150', full), 30000), '150% declining: 100,000 x 1.5/5 = 30,000');
t.ok(near(charge('syd', full), 33333.33), "sum of the years' digits: 100,000 x 5/15 = 33,333.33");
t.ok(charge('none', full) === 0, 'not depreciated: nil charge');
t.ok(near(charge('rb', { ...full, rate: 25 }), 25000), 'reducing balance at 25%: 100,000 x 25% = 25,000');

/* Year two: 40,000 already written off. Declining methods work on the carrying
   amount, straight line and sum-of-digits on cost. */
const yr2 = { base: 100000, opened: 40000, life: 5, months: 12, rate: 0, age: 1.2 };
t.ok(near(charge('sl', yr2), 20000), 'straight line ignores what is already written off');
t.ok(near(charge('ddb', yr2), 24000), 'double declining year 2: 60,000 x 2/5 = 24,000');
t.ok(near(charge('rb', { ...yr2, rate: 25 }), 15000), 'reducing balance year 2: 60,000 x 25% = 15,000');
t.ok(near(charge('syd', yr2), 26666.67), "sum of the years' digits year 2: 100,000 x 4/15 = 26,666.67");

/* Part year: seven months. */
const part = { base: 60000, opened: 0, life: 4, months: 7, rate: 0, age: 0 };
t.ok(near(charge('sl', part), 8750), 'straight line, 7 months: 60,000 / 4 x 7/12 = 8,750');
t.ok(near(charge('ddb', part), 17500), 'double declining, 7 months: 60,000 x 2/4 x 7/12 = 17,500');

/* The cap: a charge can never take an asset below nil. */
t.ok(near(charge('ddb', { base: 10000, opened: 9000, life: 3, months: 12, rate: 0, age: 2 }), 666.67),
  'double declining late in life: 1,000 carrying amount x 2/3 = 666.67');
t.ok(near(charge('ddb', { base: 10000, opened: 9000, life: 1, months: 12, rate: 0, age: 2 }), 1000),
  'declining balance is capped at the remaining carrying amount, never below nil');
t.ok(near(charge('syd', { base: 90000, opened: 0, life: 3, months: 12, rate: 0, age: 9 }), 15000),
  "sum of the years' digits past the end of the life still uses the final year's fraction");

/* A method that needs something the register does not give must say so rather
   than quietly returning nil. */
t.ok(charge('rb', { base: 50000, opened: 0, life: 5, months: 12, rate: 0, age: 0 }) === null,
  'reducing balance with no rate returns null, not a silent nil');
t.ok(charge('sl', { base: 50000, opened: 0, life: 0, months: 12, rate: 0, age: 0 }) === null,
  'straight line with no useful life returns null, not a silent nil');

/* ---------------------------------------------------- reading the register */
console.log('\n=== Methods — what the register says ===');
for (const [text, key] of [
  ['Straight line', 'sl'], ['straight-line', 'sl'], ['SL', 'sl'], ['S/L', 'sl'],
  ['Reducing balance', 'rb'], ['Diminishing balance', 'rb'], ['WDV', 'rb'], ['Written down value', 'rb'],
  ['Double declining', 'ddb'], ['200% declining balance', 'ddb'], ['DDB', 'ddb'],
  ['150% declining balance', 'db150'],
  ["Sum of the years' digits", 'syd'], ['SYD', 'syd'],
  ['Not depreciated', 'none'], ['N/A', 'none'],
  ['直线法', 'sl'], ['余额递减法', 'rb'],
]) t.ok(PPE.readMethod(text) === key, `"${text}" reads as ${key}`, String(PPE.readMethod(text)));

t.ok(PPE.readMethod('') === null, 'a blank method is not guessed at');
t.ok(PPE.readMethod('as per policy') === null, 'an unrecognised method is reported, not guessed at');

/* ------------------------------------------- the control changes the file */
console.log('\n=== Methods — the control drives the recalculation ===');
const FILE = path.join(S.OUT, 'client-a', 'PBC-PPE-01 Fixed asset register 2025-02-28.xlsx');
const eng = S.engagement(Core, '2025-02-28', 145000);

const run = over => S.pipeline(L, FILE, 'PPE', eng, over);
const sl = run({});
t.ok(sl.cfg.method === 'sl', 'straight line is the default method');
const slTotal = sl.derived.totals.expected;
t.ok(slTotal > 0, `straight line recalculation totals ${r2(slTotal)}`);

for (const m of ['ddb', 'db150', 'syd']) {
  const p = run({ method: m });
  const total = p.derived.totals.expected;
  t.ok(total > 0 && Math.abs(total - slTotal) > 1,
    `${PPE.METHOD_LABEL(m)} gives a different total (${r2(total)} vs ${r2(slTotal)})`);
  t.ok(p.records.every(r => r.__method === m), `${m}: every asset recalculated on the chosen method`);
}

const none = run({ method: 'none' });
t.ok(none.derived.totals.expected === 0, 'not depreciated: the recalculation is nil for every asset');
t.ok(none.exceptions.some(e => e.id === 'EX-PPE-01'),
  'a charge in the register against a not-depreciated policy is raised as a difference');

/* Per category, overriding the entity default. */
const cats = sl.derived.byCategory.map(c => c.category);
t.ok(cats.length > 1, `${cats.length} categories to set a policy on`);
const mixed = run({ method: 'sl', methodPolicy: { [cats[0]]: 'ddb' } });
t.ok(mixed.records.filter(r => (r.category || '(uncategorised)') === cats[0]).every(r => r.__method === 'ddb'),
  `category policy applies to "${cats[0]}" only`);
t.ok(mixed.records.filter(r => (r.category || '(uncategorised)') !== cats[0]).every(r => r.__method === 'sl'),
  'every other category keeps the entity default');
t.ok(Math.abs(mixed.derived.totals.expected - slTotal) > 1, 'the category override changes the total');

/* Reducing balance without a rate: reported as untestable, not silently nil. */
const rb = run({ method: 'rb' });
const noBasis = rb.records.filter(r => r.__noBasis);
t.ok(noBasis.length > 0, `reducing balance with no rate flags ${noBasis.length} assets as unrecalculable`);
t.ok(rb.exceptions.some(e => e.id === 'EX-PPE-24'), 'EX-PPE-24 raised where the method has no rate to work from');
const rbRate = run({ method: 'rb', ratePolicy: Object.fromEntries(cats.map(c => [c, 20])) });
t.ok(rbRate.records.filter(r => r.__noBasis).length < noBasis.length,
  'entering a category rate makes those assets testable');

/* The register is compared to the policy, not overridden by it. */
const stated = sl.records.filter(r => r.__methodStated);
t.ok(stated.length > 0, `${stated.length} assets state a method in the register`);
const differing = run({ method: 'ddb' }).exceptions.filter(e => e.id === 'EX-PPE-22');
t.ok(differing.length > 0, 'EX-PPE-22 raised where the register states a different method from the policy applied');
t.ok(sl.exceptions.filter(e => e.id === 'EX-PPE-22').length === 0,
  'no difference raised when the policy matches what the register says');

/* --------------------------------------------------- intangibles likewise */
console.log('\n=== Methods — intangible assets amortise the same way ===');
const iaSl = S.pipeline(L, FILE, 'IA', eng, {});
const iaDdb = S.pipeline(L, FILE, 'IA', eng, { method: 'ddb' });
t.ok(iaSl.derived.totals.expected > 0, `IA straight line totals ${r2(iaSl.derived.totals.expected)}`);
t.ok(Math.abs(iaDdb.derived.totals.expected - iaSl.derived.totals.expected) > 1,
  'IA: changing the amortisation method changes the recalculation');
t.ok(IA.METHODS.some(m => m.key === 'none'), 'IA offers "not amortised" for indefinite-life assets');
const indefinite = iaSl.records.filter(r => r.__annualTest);
t.ok(indefinite.every(r => r.__method === 'none'),
  'an indefinite-life or not-yet-available asset is never amortised whatever the class policy says');

t.done();
