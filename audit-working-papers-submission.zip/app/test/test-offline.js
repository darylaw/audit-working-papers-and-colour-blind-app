/* ===========================================================================
   test-offline.js  —  audit data must never leave the browser
   ---------------------------------------------------------------------------
   This is an audit file. It is opened on client premises, on locked-down
   laptops, and it holds the client's schedules. If it fetched a stylesheet, a
   font or a script from anywhere, that host would learn who opened the file and
   when, and the file would break on a machine with no internet. So: no external
   references, no network APIs, and everything it needs carried inside it.

   Run `python build.py` before this test; it reads the built artifact.
   =========================================================================== */
'use strict';
const S = require('./spec-lib.js');
const { fs, path, counter } = S;

const t = counter();
const FILE = path.join(S.APP, 'audit-working-papers.html');

if (!fs.existsSync(FILE)) {
  t.ok(false, 'audit-working-papers.html exists (run python build.py first)');
  t.done();
}
const html = fs.readFileSync(FILE, 'utf8');
const kb = (html.length / 1024 / 1024).toFixed(2);
console.log(`=== Offline guarantee — audit-working-papers.html, ${kb} MB ===`);

/* ------------------------------------------------- 1. no external resources */
const refs = [...html.matchAll(/(?:src|href)\s*=\s*["']([^"']+)["']/gi)].map(m => m[1]);
const localRef = u => /^(data:|blob:|#)/i.test(u) || (!/^[a-z][a-z0-9+.-]*:/i.test(u) && !/^[\\/]{2}/.test(u));
const external = refs.filter(u => !localRef(u));
t.ok(external.length === 0, 'only local resources and same-origin relative src/href', external.slice(0, 6).join(', '));

const linkTags = [...html.matchAll(/<link\b[^>]*>/gi)].map(m => m[0]);
t.ok(linkTags.every(tag => !/dns-prefetch|preconnect|prefetch|prerender/i.test(tag) && [...tag.matchAll(/href\s*=\s*["']([^"']+)/gi)].every(m => localRef(m[1]))), 'links cannot contact third parties or speculate network requests', linkTags.slice(0, 3).join(' '));

/* CSS can fetch too: @import, and url() outside a data: URI. */
t.ok(!/@import\s+(url\()?["']?https?:/i.test(html), 'no @import of a remote stylesheet');
const styleBlocks = [...html.matchAll(/<style[^>]*>([\s\S]*?)<\/style>/gi)].map(m => m[1]).join(String.fromCharCode(10));
const cssUrls = [...styleBlocks.matchAll(/url\(\s*["']?([^"')]+)["']?\s*\)/gi)].map(m => m[1])
  .filter(u => !localRef(u));
t.ok(cssUrls.length === 0, 'CSS resources are local or same-origin', cssUrls.slice(0, 5).join(', '));

/* ---------------------------------------------------- 2. no network APIs */
/* SheetJS is vendored and carries XML namespace strings and its own fetch
   helpers; the test targets the application code, which is everything after
   the vendored blob. */
const appStart = html.indexOf('/* core */') >= 0 ? html.indexOf('/* core */') : html.indexOf('<script>/* core');
t.ok(appStart > 0, 'application code located in the built file');
const app = html.slice(appStart);

for (const [re, what] of [
  [/\bfetch\s*\(/, 'fetch('],
  [/new\s+XMLHttpRequest/, 'XMLHttpRequest'],
  [/new\s+WebSocket/, 'WebSocket'],
  [/navigator\s*\.\s*sendBeacon/, 'sendBeacon'],
  [/new\s+EventSource/, 'EventSource'],
  [/import\s*\(/, 'dynamic import()'],
]) t.ok(!re.test(app), `application code contains no ${what}`);

/* A form that posts, or a target that leaves the page, is the same leak. */
t.ok(!/<form\b[^>]*\baction\s*=/i.test(html), 'no form with an action');

/* --------------------------------------------------- 3. fonts are carried */
const faces = (html.match(/@font-face/g) || []).length;
t.ok(faces >= 4, `Montserrat embedded as @font-face (${faces} weights)`);
t.ok(/@font-face[^}]*url\(data:font\/woff2;base64,/.test(html), 'font files are base64 data: URIs');
t.ok(/font-family:\s*["']?Montserrat/i.test(html), 'Montserrat is the declared family');

/* ------------------------------------------ 4. the AI key stays in memory */
t.ok(!/localStorage\.setItem\([^)]*apiKey/i.test(app), 'the API key is never written to local storage');
const persisted = app.match(/localStorage\.setItem\(PERSIST,\s*JSON\.stringify\(\{([^}]*)\}/);
t.ok(!persisted, 'no engagement blob (including API keys or records) is persisted');

/* ------------------------------------------------- 5. current model names */
/* A retired name in a quoted string would be sent to the API; the same name in
   a comment explaining the migration is fine. */
const quotedModels = [...app.matchAll(/['"](gpt[a-z0-9.\-]*)['"]/gi)].map(m => m[1]);
const retired = quotedModels.filter(m => !/^gpt-5\.6-(luna|terra|sol)$/.test(m));
t.ok(retired.length === 0, 'no retired OpenAI model name is used as a value', retired.join(', '));
// Replace the three model-offering assertions: inactive AI controls were removed.
t.ok(!/OpenAI API key \(this session only\)/.test(app), 'no inactive API key input');
t.ok(!/AI_MODELS|state\.settings\.model/.test(app), 'no inactive model selector');
t.ok(app.includes('AI assistance is unavailable in this release'), 'AI availability is stated honestly');
t.ok(/connect-src 'none'/.test(html), 'CSP blocks all data connections, including same-origin request bodies');
t.ok(/form-action 'none'/.test(html), 'CSP blocks form submission');
t.ok(/img-src data: blob:/.test(html), 'images cannot exfiltrate data in request URLs');
t.ok(/base-uri 'none'; object-src 'none'; frame-src 'none'/.test(html), 'CSP blocks base, object and frame escape routes');
t.ok(/awp-storage-scope/.test(app), 'hosted identity marker selects the explicit sign-out flow');

/* --------------------------------------- 6. one reporting framework only */
t.ok(!/US GAAP/.test(app), 'US GAAP removed — the app is SFRS(I) / IFRS only');
t.ok(/IFRS \/ SFRS\(I\)/.test(app), 'SFRS(I) is the reporting framework');

t.done();
