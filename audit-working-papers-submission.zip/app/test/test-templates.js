/* ===========================================================================
   test-templates.js  —  the sample schedule shown and downloaded per section
   ---------------------------------------------------------------------------
   The templates are what an auditor sends a client, so the assertion that
   matters is circular on purpose: take the template this app hands out, feed it
   back through this app's own ingest, and every column the section's procedures
   need must map with high confidence.  A template we would not accept ourselves
   is worse than no template at all.
   =========================================================================== */
'use strict';
const vm = require('vm');
const S = require('./spec-lib.js');
const { fs, path, counter } = S;

const t = counter();
const L = S.load(fs.readdirSync(path.join(S.APP, 'src', 'modules')).filter(f => f.endsWith('.js')));
const { Core, Modules, XLSX } = L;

/* samples.js and templates.js are not part of the pipeline, so spec-lib does
   not load them; pull them into the same context. */
for (const [file, name] of [['samples.js', 'SAMPLES'], ['templates.js', 'Templates']]) {
  vm.runInContext(fs.readFileSync(path.join(S.APP, 'src', file), 'utf8') + `\n;globalThis.${name} = ${name};`, L.ctx, { filename: file });
}
const { SAMPLES, Templates } = L.ctx;

const ISO = /^\d{4}-\d{2}-\d{2}$/;
const OUTDIR = __dirname;

/* ------------------------------------------------------------ every section */
console.log('=== Templates — coverage ===');
t.ok(Object.keys(SAMPLES).length === Modules.ALL.length,
  `a sample for every section (${Object.keys(SAMPLES).length} of ${Modules.ALL.length})`,
  Modules.ALL.filter(m => !SAMPLES[m.code]).map(m => m.code).join(', '));

for (const M of Modules.ALL) {
  const s = SAMPLES[M.code];
  if (!s) { t.ok(false, `${M.code}: sample present`); continue; }
  t.ok(s.rows.length >= 2, `${M.code}: at least two example rows (${s.rows.length})`);
  t.ok(s.columns.length >= 3, `${M.code}: at least three columns (${s.columns.length})`);
  t.ok(s.rows.every(r => r.length === s.columns.length), `${M.code}: every row is as wide as the header`);
  t.ok(/\.xlsx$/.test(s.file) && !/\d{4}-\d{2}-\d{2}/.test(s.file), `${M.code}: suggested file name carries no hard-coded year end`);

  /* Required fields must be offered as columns, unless a category is expected
     to arrive as group headings instead. */
  const missing = M.fields.filter(f => f.required && !f.satisfiedByGroup && !s.columns.some(c => c.key === f.key));
  t.ok(missing.length === 0, `${M.code}: every required column is in the template`, missing.map(f => f.key).join(', '));

  /* Nothing in a template may look like a real client, firm or person from the
     source material the platform was built from. */
  const flat = JSON.stringify(s).toLowerCase();
  t.ok(!/shineco|hubei|wuhan/.test(flat), `${M.code}: no names from the source templates leaked into the sample`);
}

/* --------------------------------------------------- workbook construction */
console.log('\n=== Templates — workbooks ===');
const bad = /[[\]:*?/\\]/;
for (const M of Modules.ALL) {
  if (!SAMPLES[M.code]) continue;
  let wb = null, err = null;
  try { wb = Templates.workbook(M.code); } catch (e) { err = e; }
  t.ok(wb && !err, `${M.code}: template workbook builds`, err && err.message);
  if (!wb) continue;
  t.ok(wb.SheetNames.length === 3, `${M.code}: three sheets (data, column notes, how to use)`, wb.SheetNames.join(', '));
  t.ok(wb.SheetNames.every(n => n.length <= 31 && !bad.test(n)), `${M.code}: sheet names are legal for Excel`, wb.SheetNames.join(' | '));
  t.ok(new Set(wb.SheetNames).size === wb.SheetNames.length, `${M.code}: sheet names are unique`);

  const ws = wb.Sheets[wb.SheetNames[0]];
  const s = SAMPLES[M.code];
  const hdr = s.columns.map((c, i) => (ws[XLSX.utils.encode_cell({ r: 0, c: i })] || {}).v);
  t.ok(hdr.every((h, i) => String(h).startsWith(s.columns[i].label)), `${M.code}: header row carries the column labels`);
  t.ok(s.columns.every((c, i) => !c.required || /\*$/.test(String(hdr[i]))), `${M.code}: required columns are starred on the header row`);

  /* dates must be date cells, not text, or Excel will right-align nothing */
  const dateCols = s.columns.map((c, i) => [c, i]).filter(([c, i]) => c.type === 'date' && s.rows.some(r => ISO.test(r[i])));
  for (const [c, i] of dateCols) {
    const ri = s.rows.findIndex(r => ISO.test(r[i]));
    const cell = ws[XLSX.utils.encode_cell({ r: ri + 1, c: i })];
    t.ok(cell && cell.t === 'd' && cell.v instanceof Date, `${M.code}: "${c.label}" is written as a real date`);
  }
}

/* ------------------------------------------------------------- the pack */
console.log('\n=== Templates — all sections in one file ===');
{
  let wb = null, err = null;
  try { wb = Templates.pack(); } catch (e) { err = e; }
  t.ok(wb && !err, 'pack builds', err && err.message);
  if (wb) {
    t.ok(wb.SheetNames[0] === 'Index', 'pack opens on an index');
    t.ok(wb.SheetNames.length === Object.keys(SAMPLES).length + 1, `pack carries one sheet per section plus the index (${wb.SheetNames.length})`);
    t.ok(wb.SheetNames.every(n => n.length <= 31 && !bad.test(n)), 'pack sheet names are legal for Excel');
    t.ok(new Set(wb.SheetNames).size === wb.SheetNames.length, 'pack sheet names are unique');
    const ix = XLSX.utils.sheet_to_json(wb.Sheets.Index, { header: 1 });
    for (const M of Modules.ALL) if (SAMPLES[M.code]) t.ok(ix.some(r => r[0] === M.code), `index lists ${M.code}`);
    XLSX.set_fs && XLSX.set_fs(fs);
    XLSX.writeFile(wb, path.join(OUTDIR, 'out-templates-pack.xlsx'));
    t.ok(fs.existsSync(path.join(OUTDIR, 'out-templates-pack.xlsx')), 'pack writes to disk');
  }
}

/* ============================================================================
   The real test: hand the template back to the app and see whether it is read.
   ========================================================================== */
console.log('\n=== Templates — the app accepts its own template back ===');
for (const M of Modules.ALL) {
  const s = SAMPLES[M.code];
  if (!s) continue;
  const wb = Templates.workbook(M.code);
  const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
  const wbData = Core.readWorkbook(buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength), s.file);
  const sheet = wbData.sheets[0];
  const headerRow = Core.detectHeader(sheet.rows);
  t.ok(headerRow === 0, `${M.code}: header row found on row 1`, 'found row ' + (headerRow + 1));

  const clean = Core.cleanTable(sheet.rows, headerRow);
  const data = clean.rows.filter(r => r.__kind === 'data');
  t.ok(data.length === s.rows.length, `${M.code}: all ${s.rows.length} example rows survive cleaning`, 'kept ' + data.length);

  const mapping = Core.proposeMapping(clean.headers, M.fields, data.slice(0, 40));
  const unmapped = M.fields.filter(f => f.required && !f.satisfiedByGroup && !mapping[f.key]);
  t.ok(unmapped.length === 0, `${M.code}: every required column maps back`, unmapped.map(f => f.key).join(', '));

  /* Stronger than "it mapped": it mapped to the column we put it in. This is
     what catches a near-miss heading claiming a neighbour's column. */
  const wrong = s.columns.map((c, i) => [c, i])
    .filter(([c, i]) => mapping[c.key] && mapping[c.key].colIndex !== i)
    .map(([c, i]) => `${c.label} -> col ${mapping[c.key].colIndex} not ${i}`);
  t.ok(wrong.length === 0, `${M.code}: every column maps to the column it occupies`, wrong.join('; '));

  /* Where the heading IS our canonical label, the match must be a confident
     one; a fuzzy hit would mean the label is not among the names we accept.
     Positional headings are exempt — the forecast months in going concern are
     "Mar 25", not "Month 1", and are placed by order on purpose. */
  const shaky = s.columns.filter(c => {
    const m = mapping[c.key], f = M.fields.find(x => x.key === c.key);
    if (!c.required || !m || m.confidence !== 'low' || !f) return false;
    return Core.keyify(f.label) === Core.keyify(String(m.heading).replace(/\*+$/, ''));
  });
  t.ok(shaky.length === 0, `${M.code}: required columns named as we name them map with confidence`, shaky.map(c => c.label).join(', '));

  const built = Core.buildRecords(clean, M.fields, mapping);
  t.ok(built.records.length === s.rows.length, `${M.code}: ${s.rows.length} records built`, 'got ' + built.records.length);

  /* Dates and amounts must come back as dates and amounts, not strings. */
  for (const c of s.columns) {
    const i = s.columns.indexOf(c);
    if (c.type === 'date' && mapping[c.key]) {
      const ri = s.rows.findIndex(r => ISO.test(r[i]));
      if (ri >= 0) t.ok(built.records[ri][c.key] instanceof Date, `${M.code}: "${c.label}" reads back as a date`);
    }
    if (c.type === 'number' && mapping[c.key]) {
      const ri = s.rows.findIndex(r => typeof r[i] === 'number' && r[i] !== 0);
      if (ri >= 0) t.ok(Math.abs((built.records[ri][c.key] || 0) - s.rows[ri][i]) < 0.005,
        `${M.code}: "${c.label}" reads back as the same amount`, `${built.records[ri][c.key]} vs ${s.rows[ri][i]}`);
    }
  }

  /* And the section must run its procedures over its own template without
     throwing — the auditor will click through these pages. */
  const eng = S.engagement(Core, '2025-02-28', 145000);
  let res = null, rerr = null;
  try { res = Core.runTests(M, built.records, M.defaultConfig ? M.defaultConfig() : {}, eng); } catch (e) { rerr = e; }
  t.ok(res && !rerr, `${M.code}: procedures run over the template`, rerr && rerr.message);
}

t.done();
