/* Headless test of the PAY audit file against the synthetic payroll listings.
   Run:  node test/test-pay.js                                                */
const { load, counter, money, engagement, pipeline, expectedExceptions, OUT, path, fs } = require('./spec-lib');
const L = load(['pay.js']);
const t = counter();
const CODE = 'PAY';

const CLIENTS = [
  { c: 'client-a', ye: '2025-02-28', file: 'PBC-PAY-01 Payroll listing 2025-02-28.xlsx' },
  { c: 'client-b', ye: '2025-09-30', file: 'PBC-PAY-01 Payroll listing 2025-09-30.xlsx' },
  { c: 'client-d', ye: '2025-09-30', file: 'PBC-PAY-01 Payroll listing 2025-09-30.xlsx' }
];

console.log('\n=== PAY — module registration ===');
t.ok(L.Modules.byCode.PAY && L.Modules.byCode.PAY.name === 'Payroll', 'PAY registered via Modules.register');
t.ok(L.Modules.byCode.PAY.pages.filter(p => p.render).length === 8, 'eight rendered working papers (U5, U5.1–U5.7)');
t.ok(L.Modules.byCode.PAY.pages[L.Modules.byCode.PAY.pages.length - 1].kind === 'conclusion', 'conclusion page last');

for (const { c, ye, file: f } of CLIENTS) {
  const eng = engagement(L.Core, ye, 145000);
  const file = path.join(OUT, c, f);
  const label = c;
  console.log(`\n=== ${label} ===`);
  const p = pipeline(L, file, CODE, eng, { todThreshold: 10000, todSampleN: 10 });
  const d = p.derived;
  console.log(`  header row ${p.headerRow + 1}; ${p.records.length} lines; ${d.employees.length} employees; months ${d.firstKey}..${d.lastKey} (${d.monthKeys.length}); swap=${d.swapping}`);
  console.log(`  gross ${money(d.totals.gross)}; employer stat ${money(d.totals.er)} vs audit ${money(d.totals.erExpected)}; net ${money(d.totals.net)}`);
  t.ok(p.missingRequired().length === 0, `${label}: required fields mapped`, p.missingRequired().join(', '));
  for (const k of ['employee_id', 'employee_name', 'department', 'pay_month', 'basic', 'allowances', 'bonus', 'employer_stat', 'employee_stat', 'net', 'join_date', 'leave_date'])
    t.ok(p.mapping[k], `${label}: ${k} mapped (${p.mapping[k]?.heading})`);
  t.ok(d.monthKeys.length === 12, `${label}: twelve pay months recognised`, d.monthKeys.join(','));
  t.ok(p.records.every(r => !r.__month || r.__month.getUTCDate() === 1), `${label}: every pay month normalised to the first of the month`);
  t.ok(d.employees.length === 20, `${label}: 20 employees (18 staff + duplicate + unnamed)`, d.employees.length);
  t.ok(d.totals.gross > 0 && Math.abs(d.totals.gross - (d.totals.basic + d.totals.allowances + d.totals.bonus)) < 0.05, `${label}: gross = basic + allowances + bonus`);
  t.ok(Math.abs(d.headcount.monthly.reduce((s, m) => s + m.gross, 0) - d.totals.gross) < 0.05, `${label}: monthly table cross-casts to total gross`);
  t.ok(Math.abs(d.byDept.reduce((s, x) => s + x.gross, 0) - d.totals.gross) < 0.05, `${label}: department table cross-casts to total gross`);
  t.ok(d.integrity.netBreaks.length === 0, `${label}: net pay proves on every line (gross − employee CPF = net)`, d.integrity.netBreaks.length);

  /* planted exceptions */
  const exp = expectedExceptions('Payroll', c);
  t.ok(exp.length === 5, `${label}: five planted payroll exceptions in the register`);
  const has = (id, key) => p.exceptions.some(e => e.id === id && String(e.recordKey).includes(key));
  t.ok(has('EX-PAY-01', 'E0003'), `${label}: EX-PAY-01 payment after leaving date raised for E0003 (${p.exceptions.filter(e => e.id === 'EX-PAY-01').length} lines)`);
  t.ok(p.exceptions.filter(e => e.id === 'EX-PAY-01').every(e => String(e.recordKey).includes('E0003')), `${label}: EX-PAY-01 raised only for the seeded leaver`);
  t.ok(has('EX-PAY-02', 'E0006'), `${label}: EX-PAY-02 nil employer statutory contribution raised for E0006`);
  t.ok(p.exceptions.filter(e => e.id === 'EX-PAY-02').length === 1, `${label}: EX-PAY-02 raised once per employee, not per line`);
  t.ok(has('EX-PAY-03', 'E0008'), `${label}: EX-PAY-03 salary step-up above threshold raised for E0008`);
  const e03 = p.exceptions.find(e => e.id === 'EX-PAY-03' && String(e.recordKey).includes('E0008'));
  t.ok(e03 && /increased 52\.0%/.test(e03.detail), `${label}: EX-PAY-03 quantifies the 52% increase`, e03 && e03.detail);
  t.ok(has('EX-PAY-04', 'E0010B'), `${label}: EX-PAY-04 duplicate employee (same name, two IDs) raised for E0010 / E0010B`);
  t.ok(has('EX-PAY-05', 'E9999'), `${label}: EX-PAY-05 unnamed employee raised for E9999`);
  t.ok(!p.exceptions.some(e => e.id === 'EX-PAY-06'), `${label}: EX-PAY-06 silent — recorded employer CPF agrees to 17% on capped basic for every other line`);
  t.ok(!p.exceptions.some(e => e.id === 'EX-PAY-09'), `${label}: EX-PAY-09 silent — employee CPF agrees to 20% on capped basic`);
  t.ok(!p.exceptions.some(e => e.id === 'EX-PAY-07'), `${label}: EX-PAY-07 no salary before joining date`);
  t.ok(!p.exceptions.some(e => e.id === 'EX-PAY-10'), `${label}: EX-PAY-10 no employee paid twice in a month`);
  console.log('  exceptions: ' + JSON.stringify(p.exceptions.reduce((m, e) => { m[e.id] = (m[e.id] || 0) + 1; return m; }, {})));

  /* statutory */
  const S = d.statutory;
  t.ok(S.regime.key === 'sg' && S.regime.er === 17 && S.regime.ee === 20 && S.regime.cap === 6800, `${label}: default regime Singapore CPF 17/20 capped at 6,800`);
  t.ok(S.nilEmployees.length === 1 && S.nilEmployees[0].id === 'E0006', `${label}: exactly one nil-contribution employee`);
  t.ok(Math.abs(S.erDiff + S.nilEmployees[0].erExpected) < 1, `${label}: total employer difference equals the missing contribution of E0006`, `${S.erDiff} vs ${S.nilEmployees[0].erExpected}`);
  const pPRC = pipeline(L, file, CODE, eng, { regime: 'prc' });
  t.ok(pPRC.derived.statutory.regime.er === 40.7 && pPRC.derived.statutory.regime.floor === 3740, `${label}: PRC regime applies 40.7% with a 3,740 floor`);
  t.ok(pPRC.derived.statutory.erExpected > S.erExpected, `${label}: PRC regime recomputes a higher employer contribution`);
  const pCust = pipeline(L, file, CODE, eng, { regime: 'sg', erRate: 15, wageCap: 7400 });
  t.ok(pCust.derived.statutory.regime.er === 15 && pCust.derived.statutory.regime.cap === 7400, `${label}: overrides for rate and cap honoured`);
  const pNone = pipeline(L, file, CODE, eng, { regime: 'none' });
  t.ok(!pNone.exceptions.some(e => e.id === 'EX-PAY-02' || e.id === 'EX-PAY-06'), `${label}: no statutory exceptions when recomputation is switched off`);

  /* headcount */
  const H = d.headcount;
  console.log(`  headcount: opening ${H.opening.length} + joiners ${H.joiners.length} − leavers ${H.leavers.length} = ${H.expectedClosing} vs closing ${H.closing.length} (diff ${H.diff}); leaving in final month ${H.leavingLast.length}`);
  t.ok(H.opening.length + H.joiners.length > 0 && H.closing.length > 0, `${label}: headcount populated`);
  t.ok(H.paidAfterLeaving.length === 1 && H.paidAfterLeaving[0].id === 'E0003', `${label}: exactly one employee paid after leaving`);
  t.ok(H.opening.length + H.joiners.length === 20 - d.employees.filter(e => !e.paidFirst && !e.joinedInPeriod).length, `${label}: every employee is either opening or a joiner (or unexplained)`);
  t.ok(H.diff >= 1, `${label}: headcount difference exposes the leaver still paid`, H.diff);
  t.ok(p.exceptions.some(e => e.id === 'EX-PAY-08'), `${label}: EX-PAY-08 headcount reconciliation raised`);

  /* movement */
  t.ok(d.movement.lines.length === 1 && d.movement.lines[0].employee_id === 'E0008', `${label}: one month-on-month movement above 20% (E0008)`);
  const p40 = pipeline(L, file, CODE, eng, { momThreshold: 60 });
  t.ok(!p40.exceptions.some(e => e.id === 'EX-PAY-03'), `${label}: raising the threshold to 60% silences EX-PAY-03`);

  /* test of details */
  const T = d.tod;
  console.log(`  U5.6: threshold ${money(T.threshold)}; key ${T.key.length}, sample ${T.sample.length}, coverage ${T.coverage}%`);
  t.ok(T.key.length > 0 && T.key.every(r => r.__gross >= 10000), `${label}: key items are lines with gross ≥ 10,000`);
  t.ok(T.sample.length === 10 && T.sample.every(r => r.__gross < 10000), `${label}: random sample of 10 drawn below the threshold`);
  const pDef = pipeline(L, file, CODE, eng);
  t.ok(pDef.derived.tod.threshold === eng.materiality.pm, `${label}: threshold defaults to performance materiality`);
  const p2 = pipeline(L, file, CODE, eng, { todThreshold: 10000, todSampleN: 10 });
  t.ok(JSON.stringify(p2.derived.tod.sample.map(r => r.__srcRow)) === JSON.stringify(T.sample.map(r => r.__srcRow)), `${label}: same seed → identical sample`);
  const p3 = pipeline(L, file, CODE, eng, { todThreshold: 10000, todSampleN: 10, todSeed: 7 });
  t.ok(JSON.stringify(p3.derived.tod.sample.map(r => r.__srcRow)) !== JSON.stringify(T.sample.map(r => r.__srcRow)), `${label}: different seed → different sample`);
  const pv = pipeline(L, file, CODE, eng, { todThreshold: 10000, todSampleN: 10 }, recs => recs.forEach(r => { r.__wp = { tod: { agreed: 'Y' } }; }));
  t.ok(pv.derived.tod.agreed === pv.derived.tod.selected.length, `${label}: vouching inputs are read back into the coverage stats`);

  /* KMP inputs */
  const e1 = d.employees[0], e2 = d.employees[1];
  const pK = pipeline(L, file, CODE, eng, { ['kmp:' + e1.key]: 'Y', ['kmpRole:' + e1.key]: 'Executive director', ['kmp:' + e2.key]: 'Y' });
  t.ok(pK.derived.kmp.employees.length === 2 && Math.abs(pK.derived.kmp.total - (e1.gross + e1.er + e2.gross + e2.er)) < 0.05, `${label}: KMP schedule totals the marked employees`);
  t.ok(pK.derived.kmp.employees[0].role === 'Executive director', `${label}: KMP role input carried`);

  /* lead inputs */
  const pTB = pipeline(L, file, CODE, eng, { 'tb:basic': d.totals.basic, 'tb:er': d.totals.er + 500, 'py:gross': d.totals.gross * 0.5 });
  const e20 = pTB.exceptions.filter(e => e.id === 'EX-PAY-20');
  t.ok(e20.length === 1 && Math.abs(e20[0].difference + 500) < 0.005 && /statutory/i.test(e20[0].recordKey), `${label}: EX-PAY-20 raised only for the line that does not agree to the TB`);
  const gl = pTB.derived.lead.find(l => l.key === 'gross');
  t.ok(gl.variancePct != null && Math.abs(gl.variancePct - 100) < 0.5 && gl.material, `${label}: prior-year variance computed and flagged`);

  /* pages and export */
  p.renderAll(t, label);
  const wb = pK.exportCheck(t, label);
  const ws = wb.Sheets[wb.SheetNames.find(n => n.startsWith('U5.7 '))];
  t.ok(ws && Object.values(ws).some(c => c && c.v === 'Executive director'), `${label}: U5.7 export carries the KMP role entered`);
  const st = p.state().modules.PAY;
  const text = L.Modules.byCode.PAY.suggestConclusion(st, p.ctx());
  t.ok(typeof text === 'string' && text.length > 100, `${label}: suggestConclusion produces text`);
}

/* client-d: the pay-month column is mm/dd with every value on the 1st */
console.log('\n=== PAY — pay-month order (client-d mm/dd) ===');
{
  const eng = engagement(L.Core, '2025-09-30', 145000);
  const file = path.join(OUT, 'client-d', 'PBC-PAY-01 Payroll listing 2025-09-30.xlsx');
  const pa = pipeline(L, file, CODE, eng);
  t.ok(pa.derived.swapping === true && pa.derived.firstKey === '2024-10' && pa.derived.lastKey === '2025-09', 'auto: mm/dd reading chosen, months Oct 2024 – Sep 2025', `${pa.derived.firstKey}..${pa.derived.lastKey}`);
  const pk = pipeline(L, file, CODE, eng, { monthOrder: 'keep' });
  t.ok(pk.derived.swapping === false && pk.derived.monthKeys.length < 12, 'keep: dd/mm reading collapses the months (auditor can see why auto swapped)');
  const pb = pipeline(L, path.join(OUT, 'client-b', 'PBC-PAY-01 Payroll listing 2025-09-30.xlsx'), CODE, eng);
  t.ok(pb.derived.swapping === false, 'client-b dd.mm.yyyy months are kept as parsed');
}

/* round trip */
{
  const eng = engagement(L.Core, '2025-02-28', 145000);
  const p = pipeline(L, path.join(OUT, 'client-a', 'PBC-PAY-01 Payroll listing 2025-02-28.xlsx'), CODE, eng);
  const wb = L.Exporter.build(p.state(), CODE);
  const out = path.join(__dirname, 'out-PAY-file.xlsx');
  L.XLSX.writeFile(wb, out);
  const re = L.XLSX.readFile(out);
  t.ok(re.SheetNames.length === wb.SheetNames.length, 'workbook survives the Excel round-trip');
  fs.unlinkSync(out);
}

t.done();
