# Building an audit section module

Read this whole file before writing code. Then read `src/ppe.js` (the reference
implementation — a non-declarative one) and `src/spec.js` (the declarative page
toolkit you will use). Do **not** edit `ui.js`, `xlsxfile.js`, `core.js`, `spec.js`,
`ppe.js` or `build.py`. Your module is one file: `src/modules/<code>.js`.

## What a module is

An audit **file** for one balance or transaction stream, the way an auditor actually
works it: a set of working papers computed from one (sometimes two) uploaded client
schedules. Each working paper is a page the auditor reads, completes and concludes on
in the app before exporting Excel. Think "lead schedule → supporting schedule → tests
→ auditor inputs → conclusion", not "run rules, list exceptions".

Study how `ppe.js` does it: E3 lead (listing vs TB vs PY), E3.1 movement schedule,
E3.2 depreciation with convention/policy controls, E3.3 additions with threshold +
seeded random sample + vouching columns the auditor fills in, E3.4 disposals with
proceeds input and gain/loss recalculation, E3.5 FRS 36 indicator checklist → candidate
rules → work done / work to be done. Your module must be at that level.

## File shape

```js
const <Code>Module = (() => {
  const r2 = n => n == null || isNaN(n) ? null : Math.round(n * 100) / 100;
  const fields = [ ...see below... ];
  const defaultConfig = () => ({ ...every cfg key your pages/compute read, with defaults... });
  function compute(recs, cfg, eng) { ...return derived... }     // deterministic; mutate recs with __ fields
  const tests = [ ...see below... ];
  const pages = [
    { id:'source',  ref:'X.0',  title:'Source data',     kind:'source' },
    { id:'cleaned', ref:'X.0a', title:'Cleaned listing', kind:'cleaned' },
    { id:'mapping', ref:'X.0b', title:'Column mapping',  kind:'mapping' },
    { id:'lead', ref:'X', title:'Lead schedule', objective:'...', procedures:['...'],
      render(st, ctx) { return [ ...specs... ]; },
      flag(st, d) { return true/false; } },          // optional: red dot in the file index
    ...your substantive working papers...
    { id:'conclusion', ref:'X.9', title:'Exceptions & conclusion', kind:'conclusion' }
  ];
  return { code:'AR', name:'Trade Receivables', group:'Assets', accepts:'.xlsx,.xlsm,.csv',
    blurb:'one line', objective:'the ISA-style objective for the area',
    fields, tests, compute, pages, defaultConfig,
    procedures: pages.flatMap(p => p.procedures || []),
    STANDARD_COLUMNS: [ ...optional; see ppe.js; makes the cleaned page editable... ],
    suggestConclusion(st, ctx) { return '...template text...'; }    // optional
  };
})();
```

The four `kind:` pages are rendered by the shell. Every other page **must** have
`render(st, ctx)` returning an array of specs. `ref` uses a firm-neutral index
(e.g. AR: `L3`, `L3.1`…; AP: `U3`…; CASH: `M`, `M1`…; REV: `Z1`…). Keep `id`s short and
stable — they key auditor inputs and notes.

## Fields (the mapping dictionary)

```js
{ key:'amount', label:'Amount outstanding', type:'number'|'text'|'date', required:true,
  role:'key'|'category',            // optional
  block:'Cost',                     // optional two-tier header hint
  dupKey:true,                      // participates in duplicate detection
  satisfiedByGroup:true,            // category may come from group-header rows
  synonyms:['Amount','Outstanding','Balance','金额', ...] }
```
Put **many** synonyms — this is what makes auto-mapping work across clients. Look at
the synthetic files for this area under `../synthetic-data/out/client-{a,b,c,d}/` to see
the real heading variety, and at `../synthetic-data/generator/clients.py` HEADINGS.
Include Chinese headings where the dictionary has them.

## compute(recs, cfg, eng)

- `eng.yearEndDate`, `eng.fyStartDate` (Date, UTC midnight), `eng.materiality.{om,pm,trivial}`
- Skip `r.__excluded` records from totals.
- Set `r.__displayKey` (what the exception register shows for the record).
- Store per-record derived values as `r.__something`.
- **Auditor inputs entered on your pages live at `r.__wp[pageId][columnKey]`** (set by the
  toolkit for `input` columns). Read them in compute, e.g. proceeds → gain/loss.
- Return a plain object `d`. Your pages read `ctx.d`.
- Rules first. No AI. Every number reproducible.

## tests

```js
{ id:'EX-AR-01', label:'Credit balance in receivables', basis:'L3.1',
  severity:'above-trivial'|'informational' /* optional override */,
  fn:(r, cfg, eng, d) => cond && { expected, actual, difference, cell:r['__cell_amount'], detail } }
{ id:'EX-AR-20', scope:'population', label:'...', fn:(recs, cfg, eng, d) => false | {key, expected, actual, difference, detail} | [..] }
```
Severity is derived from `Math.abs(difference)` against materiality unless overridden.
Exception IDs: use the ones in `docs/focus-areas.html` / the blueprint where they
exist (EX-AR-*, EX-AP-*, EX-INV-*, EX-CASH-*, EX-ECL-*, EX-GC-*, EX-IMP-*, EX-RP-*…).

## Specs your render() can return (see spec.js header for exact shape)

- `heading`, `note` (tone info/warn/bad), `stats`
- `controls` — inputs bound to `st.config[key]` (thresholds, conventions, seeds, TB/P&L figures)
- `checklist` — Y/N/n-a + comment per item, stored in `cfg[store]`
- `table` — columns may be `num/int/pct/date/text/chip`, `sum:true` for a totals row,
  `input:'number'|'text'|'date'|'select'` for auditor fields (stored per record via
  `row.__rec`, or in cfg via `row.__key` for non-record rows), `flag:(v,row)=>bool` to
  paint a cell red, `formula:(excelRow, col)=>'...'` if you want a live Excel formula
  on export.

Every auditor-judgement page needs input columns: what was vouched, to what, agreed Y/N,
comment. Every recalculation page needs the recomputed figure beside the client's figure
and the difference. Every selection page needs a threshold control (default = PM), an
optional random-sample-size control with a **seed** (copy `mulberry32`/`sampleN` from
ppe.js), and coverage stats.

## Seeded random sampling

Copy `mulberry32` and `sampleN` from `ppe.js`. Seed lives in cfg and is shown on the page.

## Testing your module — required before you finish

1. `node --check src/modules/<code>.js`
2. Write `test/test-<code>.js` modelled on `test/harness.js`: load core.js, spec.js,
   ppe.js, modules.js, **your file**, xlsxfile.js, xlsxout.js into a vm context in that
   order (each followed by `;globalThis.X = X;`), then read the relevant synthetic file(s)
   for **client-a, client-b and client-d**, run detect → clean → map → build → runTests,
   and assert: required fields map on all three clients; derived totals are sane; the
   planted exceptions for your area in `../synthetic-data/out/_expected-exceptions.json`
   are raised (the important ones — list them); every page's `render(st, ctx)` returns an
   array without throwing (build a ctx like `specCtx` in ui.js: `{eng,cfg,d,recs,all,
   money:x=>x,money0:x=>x,pct:x=>x,fmtDate:Core.fmtDate,r2,pm,trivial,M}`); and
   `Exporter.build(state, code)` produces a workbook with one sheet per rendered page
   (build `state` as `harness.js` does in `asState`, including `pageNotes: {}`, `edits: []`, `trail: []`).
3. Run it. All assertions must pass. Fix your module until they do.

## Register it

The **last line of your module file** must be:
```js
Modules.register(<Code>Module);
```
Nothing is edited in `modules.js`. The build concatenates `src/modules/*.js` after
`modules.js`, so `Modules` exists when your file runs. In your test, load your file
after `modules.js` and it registers itself the same way. If a module with your code
already exists (e.g. the generic `AR`), yours replaces it.

## Style

Montserrat, large type — all handled by the shell. Write labels a partner reads:
"Depreciation per audit", not "calc_dep". Procedures in the past tense, as performed.
No client, firm or person names anywhere. British spelling.
