"""
clients -- three FICTITIOUS synthetic audit clients.

All names, account codes, bank accounts, registration numbers, counterparties and
people in this file are invented for software testing. They are not derived from,
and must not be read as referring to, any real organisation or individual.

Each profile deliberately differs in:
  * accounting system and therefore export layout
  * financial year end
  * functional and transaction currencies
  * chart-of-accounts coding scheme
  * column heading vocabulary (the mapping problem the platform must solve)
  * which data-quality defects appear and how heavily

DQ-07 lives here: HEADINGS gives each client its own words for the same audit field.
"""

import datetime as dt

# --------------------------------------------------------------------------
# Canonical audit field names -> per-client source heading (DQ-07)
# --------------------------------------------------------------------------

HEADINGS = {
    # ---- Fixed asset register -------------------------------------------
    "fa.asset_id":        ["Asset Code", "Asset No.", "FA ID", "Tag Number", "Asset Ref"],
    "fa.description":     ["Description", "Asset Description", "Asset Name", "Particulars", "Item"],
    "fa.category":        ["Category", "Asset Class", "Asset Group", "FA Type", "Class"],
    "fa.acq_date":        ["Purchase Date", "Acquisition Date", "Date Acquired",
                           "Capitalisation Date", "Asset Date", "In-Service Date",
                           "Date of Purchase", "Cap. Date"],
    "fa.cost_open":       ["Cost B/F", "Opening Cost", "Cost at 1 Jan", "Op Bal - Cost",
                           "Cost Brought Forward"],
    "fa.additions":       ["Additions", "Add'ns", "Acquisitions", "Purchases", "Addition"],
    "fa.disposals":       ["Disposals", "Disposal / Write-off", "Deletions", "Retirements",
                           "Disposal"],
    "fa.cost_close":      ["Cost C/F", "Closing Cost", "Cost at Year End", "End Bal - Cost",
                           "Total Cost"],
    "fa.life":            ["Useful Life (Yrs)", "Life", "UL", "Est. Useful Life",
                           "Useful Life", "Dep. Life (Months)"],
    "fa.method":          ["Depreciation Method", "Dep Method", "Method", "Depn Basis",
                           "Basis"],
    "fa.rate":            ["Dep Rate %", "Rate", "Depn Rate", "Annual Rate %"],
    "fa.accdep_open":     ["Acc Dep B/F", "Opening Accumulated Depreciation",
                           "Accum. Depn B/F", "Op Bal - Depn", "A/Depn Brought Forward"],
    "fa.dep_charge":      ["Depreciation for the Year", "Current Year Depreciation",
                           "Depn Charge", "Charge for the Year", "Dep - CY", "Additions"],
    "fa.accdep_disp":     ["Acc Dep on Disposal", "Depn on Disposals", "Disposals",
                           "Write-back on Disposal"],
    "fa.accdep_close":    ["Acc Dep C/F", "Closing Accumulated Depreciation",
                           "Accum. Depn C/F", "End Bal - Depn"],
    "fa.nbv_close":       ["NBV", "Net Book Value", "Carrying Amount", "WDV",
                           "Net Book Value at Year End"],
    "fa.nbv_open":        ["NBV B/F", "Opening NBV", "Carrying Amount B/F", "Prior Year NBV"],
    "fa.location":        ["Location", "Site", "Cost Centre", "Dept"],
    "fa.supplier":        ["Supplier", "Vendor", "Purchased From", "Supplier Name"],

    # ---- Trial balance --------------------------------------------------
    "tb.account_code":    ["Account", "Account No", "A/C Code", "GL Code",
                           "Account Number", "Nominal Code"],
    "tb.account_name":    ["Account Name", "Description", "Account Description",
                           "Text for B/S P&L item", "Name", "Particulars"],
    "tb.debit":           ["Debit", "Dr", "Debit (Dr)", "Debit Amount"],
    "tb.credit":          ["Credit", "Cr", "Credit (Cr)", "Credit Amount"],
    "tb.balance":         ["Balance", "Net Balance", "Amount", "Closing Balance",
                           "Balance at Year End"],
    "tb.balance_py":      ["Prior Year", "PY Balance", "Comparative", "Last Year",
                           "Balance b/f"],
    "tb.fs_caption":      ["FS Line", "Grouping", "Map No.", "FS Caption", "L/S"],

    # ---- General ledger -------------------------------------------------
    "gl.entry_date":      ["Date", "Posting Date", "Transaction Date", "Doc Date",
                           "Entry Date", "GL Date"],
    "gl.journal_ref":     ["Journal No", "Doc No", "Reference", "JV No.", "Voucher No",
                           "Document Number"],
    "gl.account_code":    ["Account", "GL Account", "A/C", "Account Code"],
    "gl.description":     ["Description", "Narration", "Details", "Document Header Text",
                           "Memo", "Particulars"],
    "gl.debit":           ["Debit", "Dr", "Amount Dr"],
    "gl.credit":          ["Credit", "Cr", "Amount Cr"],
    "gl.amount":          ["Amount", "Value", "Net Amount", "Amount in LC"],
    "gl.source":          ["Source", "Journal Type", "Module", "Trans Type", "Type"],
    "gl.user":            ["Entered By", "User", "Created By", "User ID", "Posted By"],

    # ---- Accounts receivable -------------------------------------------
    "ar.customer_code":   ["Customer Code", "Cust Code", "Debtor Code", "A/C No", "Code"],
    "ar.customer_name":   ["Customer", "Customer Name", "Debtor", "Debtor Name",
                           "CUSTOMERS", "Account Name"],
    "ar.invoice_no":      ["Invoice No", "Inv No.", "Document No", "Ref", "Invoice Number"],
    "ar.invoice_date":    ["Invoice Date", "Doc Date", "Date", "Inv. Date", "Trans Date"],
    "ar.due_date":        ["Due Date", "Date Due", "Maturity", "Payment Due"],
    "ar.terms":           ["Terms", "Credit Terms", "Term", "Payment Terms", "Days"],
    "ar.currency":        ["Currency", "Cur", "Curr", "CCY", "Txn Ccy"],
    "ar.amount_orig":     ["Amount (Orig)", "Foreign Amount", "Amount FC", "Orig. Amount"],
    "ar.amount":          ["Amount", "Outstanding", "Balance", "Outstanding Balance",
                           "Amount Due", "Total"],
    "ar.b_current":       ["Current", "Not Due", "0-30", "1-30 days", "Within Terms"],
    "ar.b_31_60":         ["31-60", "31 - 60 days", "31-60 Days", "1 Month Overdue"],
    "ar.b_61_90":         ["61-90", "61 - 90 days", "61-90 Days", "2 Months Overdue"],
    "ar.b_91_120":        ["91-120", "91 - 120 days", "91-120 Days", "3 Months Overdue"],
    "ar.b_over_120":      [">120", "Over 120 days", "121+", ">150", "Over 150 days",
                           "Older"],

    # ---- Accounts payable ----------------------------------------------
    "ap.supplier_code":   ["Supplier Code", "Vendor Code", "Creditor Code", "A/C No"],
    "ap.supplier_name":   ["Supplier", "Supplier Name", "Vendor Name", "Creditor",
                           "Vendor", "Payee"],
    "ap.invoice_no":      ["Invoice No", "Supplier Inv No", "Bill No", "Doc No", "Ref"],
    "ap.invoice_date":    ["Invoice Date", "Bill Date", "Date", "Doc Date"],

    # ---- Inventory ------------------------------------------------------
    "inv.item_code":      ["Item Code", "SKU", "Part No.", "Stock Code",
                           "Item Code / Part No.", "Material"],
    "inv.description":    ["Description", "Stock Name", "Item Description",
                           "Material Description", "Product"],
    "inv.category":       ["Category", "Stock Type", "Class", "Item Group",
                           "Inventory Class"],
    "inv.uom":            ["UOM", "Unit", "Unit of Measure", "Units", "U/M"],
    "inv.qty":            ["Quantity", "Qty", "Closing Qty", "Final quantity as per client",
                           "Balance Qty", "On Hand"],
    "inv.unit_cost":      ["Unit Cost", "Cost/Unit", "Unit cost as per client",
                           "Std Cost", "Avg Cost", "Rate"],
    "inv.total_cost":     ["Total Cost", "Value", "Amount", "Extended Cost",
                           "Closing Value"],
    "inv.nrv":            ["NRV", "Net Realisable Value", "Selling Price",
                           "Est. Selling Price", "Market Value"],
    "inv.last_movement":  ["Last Movement Date", "Last Issue Date", "Last Txn",
                           "Date of Last Movement", "Last Used"],
    "inv.location":       ["Location", "Warehouse", "Bin", "Store", "Whse"],

    # ---- Bank -----------------------------------------------------------
    "bank.stmt_date":     ["Date", "Value Date", "Transaction Date", "Posting Date"],
    "bank.narrative":     ["Description", "Narrative", "Details", "Transaction Details",
                           "Particulars", "Reference"],
    "bank.debit":         ["Withdrawal", "Debit", "Paid Out", "Dr", "Payments"],
    "bank.credit":        ["Deposit", "Credit", "Paid In", "Cr", "Receipts"],
    "bank.balance":       ["Balance", "Running Balance", "Ledger Balance", "Balance (SGD)"],

    # ---- Payroll --------------------------------------------------------
    "pay.employee_id":    ["Employee ID", "Emp No", "Staff No", "Employee Code", "ID"],
    "pay.employee_name":  ["Employee Name", "Name", "Staff Name", "Employee"],
    "pay.department":     ["Department", "Dept", "Cost Centre", "Division"],
    "pay.gross":          ["Gross Pay", "Basic Salary", "Gross", "Total Gross",
                           "Salary"],
    "pay.allowances":     ["Allowances", "Allowance", "Other Allowances", "Fixed Allowance"],
    "pay.bonus":          ["Bonus", "AWS / Bonus", "Incentive", "Variable Pay"],
    "pay.employer_cpf":   ["Employer CPF", "CPF (Er)", "Employer Contribution",
                           "CPF Employer", "Statutory - Er"],
    "pay.employee_cpf":   ["Employee CPF", "CPF (Ee)", "Employee Contribution",
                           "CPF Employee"],
    "pay.net":            ["Net Pay", "Net", "Take Home", "Net Salary"],
    "pay.join_date":      ["Date Joined", "Join Date", "Hire Date", "Commencement Date"],
    "pay.leave_date":     ["Date Left", "Resignation Date", "Last Day", "Termination Date"],

    # ---- Revenue --------------------------------------------------------
    "rev.doc_no":         ["Invoice No", "Doc No", "Sales Invoice", "Inv #", "Reference"],
    "rev.doc_date":       ["Invoice Date", "Date", "Sales Date", "Doc Date"],
    "rev.customer":       ["Customer", "Customer Name", "Sold To", "Debtor"],
    "rev.product":        ["Product", "Item", "Description", "Service", "Revenue Stream"],
    "rev.qty":            ["Qty", "Quantity", "Units"],
    "rev.unit_price":     ["Unit Price", "Price", "Rate", "Selling Price"],
    "rev.net_amount":     ["Amount", "Net Amount", "Revenue", "Sales Value", "Net Sales"],
    "rev.tax":            ["GST", "Tax", "VAT", "GST Amount", "Output Tax"],
    "rev.gross_amount":   ["Total", "Gross Amount", "Invoice Total", "Amount Inc. GST"],
    "rev.do_date":        ["Delivery Date", "DO Date", "Despatch Date", "Shipment Date"],
    "rev.segment":        ["Segment", "Business Line", "Division", "Geography", "Region"],

    # ---- Expenses -------------------------------------------------------
    "exp.doc_no":         ["Invoice No", "Doc No", "Voucher No", "Ref"],
    "exp.doc_date":       ["Invoice Date", "Date", "Doc Date"],
    "exp.supplier":       ["Supplier", "Payee", "Vendor", "Paid To"],
    "exp.account_code":   ["Account", "GL Code", "Expense Code", "Cost Element"],
    "exp.account_name":   ["Account Name", "Expense Type", "Category", "Nature"],
    "exp.amount":         ["Amount", "Net Amount", "Value", "Expense"],

    # ---- Loans ----------------------------------------------------------
    "loan.facility":      ["Facility", "Loan", "Facility Name", "Loan Description",
                           "Type of Facility"],
    "loan.lender":        ["Lender", "Bank", "Financier", "Institution"],
    "loan.account_no":    ["Account No", "Loan Account", "Facility No", "Ref No"],
    "loan.principal":     ["Principal", "Loan Amount", "Facility Limit", "Original Amount"],
    "loan.rate":          ["Interest Rate", "Rate %", "Rate", "Effective Rate"],
    "loan.start":         ["Drawdown Date", "Start Date", "Commencement", "Loan Date"],
    "loan.tenor":         ["Tenor (Months)", "Term", "Tenure", "No. of Instalments"],
    "loan.instalment":    ["Monthly Instalment", "Instalment", "Repayment", "EMI"],
    "loan.bal_open":      ["Opening Balance", "Balance B/F", "Bal at Start"],
    "loan.repaid":        ["Repayments", "Principal Repaid", "Repayment", "Paid"],
    "loan.interest":      ["Interest Charged", "Interest Expense", "Interest", "Finance Cost"],
    "loan.bal_close":     ["Closing Balance", "Balance C/F", "Outstanding"],
    "loan.current":       ["Current Portion", "Within 1 Year", "Due < 1 Yr"],
    "loan.noncurrent":    ["Non-Current Portion", "After 1 Year", "Due > 1 Yr"],

    # ---- Accruals / prepayments ----------------------------------------
    "acc.description":    ["Description", "Particulars", "Nature of Accrual", "Details"],
    "acc.account_code":   ["GL Code", "Account", "A/C"],
    "acc.bal_open":       ["Opening Balance", "Balance B/F", "Bal 1 Jan"],
    "acc.charge":         ["Provided During Year", "Charge", "Additions", "Accrued"],
    "acc.utilised":       ["Utilised / Reversed", "Payments", "Reversals", "Utilisation"],
    "acc.bal_close":      ["Closing Balance", "Balance C/F", "Bal at Year End"],
    "pre.period_from":    ["Period From", "From", "Start Date", "Coverage From"],
    "pre.period_to":      ["Period To", "To", "End Date", "Coverage To"],
    "pre.amount_paid":    ["Amount Paid", "Invoice Amount", "Total Paid", "Cost"],
    "pre.expensed":       ["Amortised to P&L", "Expensed", "Charge for Year", "Released"],

    # ---- Equity ---------------------------------------------------------
    "eq.description":     ["Description", "Particulars", "Movement", "Details"],
    "eq.shares":          ["No. of Shares", "Shares", "Share Count", "Units"],
    "eq.amount":          ["Amount", "Share Capital", "Value", "Consideration"],
    "eq.date":            ["Date", "Allotment Date", "Effective Date"],
    "grp.entity":         ["Entity", "Company", "Legal Entity", "Subsidiary",
                           "Entity Name", "公司 Company"],
    "grp.entity_code":    ["Entity Code", "Company Code", "Co.", "Entity ID"],
    "grp.scope":          ["Scope in/Scope out", "Scope", "In Scope (Y/N)",
                           "Component Scoping", "Scoped In"],
    "grp.per_mgmt":       ["As per mgmt a/c", "Per Management Accounts",
                           "Per Book", "Unaudited", "As per TB"],
    "grp.audit_adj":      ["Audit Adjustment", "Audit ADJ", "AJE", "Adjustments"],
    "grp.final":          ["Final", "Final balance", "Audited", "Post-adjustment"],
    "grp.elim":           ["Elimination Adjustment", "Elimination", "Elim. Entry",
                           "Consolidation Adjustment"],
    "grp.eliminated":     ["Eliminated balance", "Consolidated", "Post-elimination",
                           "Group balance"],

    # ---- Related party movement (Firm 3 WP 9100-30) ---------------------
    "rp.counterparty":    ["Related Party", "Counterparty", "Name of Related Party",
                           "RP Name", "关联方 Related Party"],
    "rp.relationship":    ["Relationship", "Nature of Relationship", "RP Type",
                           "Connection"],
    "rp.nature":          ["Nature of balance", "Nature", "Type of Balance",
                           "Description"],
    "rp.orig_ccy":        ["Original Currency", "Txn Currency", "Currency",
                           "Balance in Original Currency"],
    "rp.orig_amount":     ["Amount (Original Currency)", "Original Amount",
                           "Amount in Txn Ccy"],
    "rp.func_amount":     ["Converted to functional currency", "Amount (Functional)",
                           "Per book", "Functional Currency Amount"],
    "rp.bal_bf":          ["Balance b/f", "Opening Balance", "Bal B/F"],
    "rp.bal_cf":          ["Balance c/f", "Closing Balance", "Bal C/F"],

    # ---- PRC statutory payroll (Firm 3 WP 8500-62..65) ------------------
    "prc.ssi_base":       ["SSI Base", "Contribution Base", "Social Insurance Base",
                           "缴费基数 Contribution Base"],
    "prc.ssi_er":         ["Employer SSI", "SSI - Employer Portion",
                           "Employer Contribution", "单位社保 Employer SSI"],
    "prc.ssi_ee":         ["Employee SSI", "SSI - Employee Portion",
                           "Employee Contribution"],
    "prc.hf_er":          ["Employer Housing Fund", "Housing Fund - Employer",
                           "HF Employer", "住房公积金 Housing Fund"],
    "prc.hf_ee":          ["Employee Housing Fund", "Housing Fund - Employee",
                           "HF Employee"],
    "prc.iit":            ["Individual Income Tax", "IIT", "Individual Tax",
                           "个人所得税 IIT"],
}


# Chinese label prefixes used by a PRC-books client (DQ-07 taken further:
# the heading is not even in the same language as the audit file).
BILINGUAL = {
    "tb.account_code": "科目代码",
    "tb.account_name": "科目名称",
    "tb.debit": "借方",
    "tb.credit": "贷方",
    "tb.balance": "余额",
    "gl.entry_date": "日期",
    "gl.journal_ref": "凭证号",
    "gl.description": "摘要",
    "gl.debit": "借方金额",
    "gl.credit": "贷方金额",
    "ar.customer_name": "客户名称",
    "ar.invoice_no": "发票号",
    "ar.invoice_date": "发票日期",
    "ar.amount": "金额",
    "ar.currency": "币种",
    "ap.supplier_name": "供应商名称",
    "inv.item_code": "存货编码",
    "inv.description": "存货名称",
    "inv.qty": "数量",
    "inv.unit_cost": "单价",
    "inv.total_cost": "金额",
    "fa.description": "资产名称",
    "fa.acq_date": "购置日期",
    "fa.cost_open": "期初原值",
    "fa.additions": "本期增加",
    "fa.disposals": "本期减少",
    "fa.dep_charge": "本期折旧",
    "pay.employee_name": "姓名",
    "pay.department": "部门",
    "pay.gross": "应发工资",
    "pay.net": "实发工资",
    "grp.entity": "公司",
    "rp.counterparty": "关联方",
}


def heading(field, variant):
    """Pick the `variant`-th heading synonym for a canonical field (wraps around)."""
    opts = HEADINGS[field]
    return opts[variant % len(opts)]


# --------------------------------------------------------------------------
# Client profiles
# --------------------------------------------------------------------------

class ClientProfile:
    # Defaults so the three original single-entity profiles need no changes.
    framework = "IFRS / SFRS(I)"
    date_style = "dmy_slash"      # primary date rendering in this client's exports
    tb_sheet_name = "Sheet1"      # what this client's system calls the TB tab
    multi_entity = False
    entities = ()
    bilingual = False
    prc_payroll = False
    materiality_labels = ("Overall Materiality", "Performance Materiality",
                          "SUD Threshold")

    def __init__(self, **kw):
        self.__dict__.update(kw)

    def h(self, field):
        """Heading for a canonical field, using this client's vocabulary variant."""
        base = heading(field, self.variant)
        if self.bilingual and field in BILINGUAL:
            return f"{BILINGUAL[field]} {base}"
        return base

    @property
    def fy_start(self):
        return self.year_end.replace(year=self.year_end.year - 1) + dt.timedelta(days=1)

    @property
    def py_end(self):
        return self.fy_start - dt.timedelta(days=1)


CLIENTS = {
    # ------------------------------------------------------------------
    # Client A -- metals stockist / distributor. Cloud ledger, USD books,
    # non-calendar year end, heavy foreign currency, thin controls.
    # ------------------------------------------------------------------
    "client-a": ClientProfile(
        key="client-a",
        date_style="dmy_slash",
        tb_sheet_name="TB",
        name="Vantage Metals Distribution Pte. Ltd.",
        short="Vantage Metals",
        industry="Metals stockholding and distribution",
        system="Cloud bookkeeping ledger (browser export)",
        year_end=dt.date(2025, 2, 28),
        functional_ccy="USD",
        txn_ccys=["USD", "SGD", "MYR"],
        presentation_dp=2,
        coa_style="8-digit blocks",          # 55510110
        variant=0,
        materiality_basis="Turnover",
        # DQ intensity dial
        dq={"date_contam": 0.18, "num_contam": 0.14, "blank_row_p": 0.10,
            "dup_exact": 2, "dup_near": 2, "missing_p": 0.06,
            "extra_headers": 4, "blank_cols": 1, "subtotals": True,
            "group_headers": True, "casting_diff": 35.80, "footnotes": True},
    ),

    # ------------------------------------------------------------------
    # Client B -- building contractor. Desktop accounting package, SGD,
    # September year end, contract accounting, many bank facilities.
    # ------------------------------------------------------------------
    "client-b": ClientProfile(
        key="client-b",
        date_style="dmy_dot",
        tb_sheet_name="Sheet1",
        name="Keystone Contracting Pte. Ltd.",
        short="Keystone Contracting",
        industry="Building construction and fit-out contracting",
        system="Desktop accounting package (CSV / TXT export)",
        year_end=dt.date(2025, 9, 30),
        functional_ccy="SGD",
        txn_ccys=["SGD"],
        presentation_dp=2,
        coa_style="dash-separated",          # 1-1710
        variant=1,
        materiality_basis="Total Assets",
        dq={"date_contam": 0.10, "num_contam": 0.22, "blank_row_p": 0.06,
            "dup_exact": 1, "dup_near": 3, "missing_p": 0.09,
            "extra_headers": 2, "blank_cols": 2, "subtotals": True,
            "group_headers": False, "casting_diff": 0.0, "footnotes": True},
    ),

    # ------------------------------------------------------------------
    # Client C -- electronics manufacturer, subsidiary of a foreign group.
    # ERP extract, SGD books, December year end, tight coding, inventory heavy.
    # ------------------------------------------------------------------
    "client-c": ClientProfile(
        key="client-c",
        date_style="iso",
        tb_sheet_name="Trial Balance",
        name="Solstice Precision Technologies Pte. Ltd.",
        short="Solstice Precision",
        industry="Contract electronics manufacturing",
        system="Group ERP (structured extract)",
        year_end=dt.date(2025, 12, 31),
        functional_ccy="SGD",
        txn_ccys=["SGD", "USD", "EUR"],
        presentation_dp=2,
        coa_style="6-digit",                 # 410000
        variant=3,
        materiality_basis="Profit before tax",
        dq={"date_contam": 0.05, "num_contam": 0.04, "blank_row_p": 0.02,
            "dup_exact": 1, "dup_near": 1, "missing_p": 0.03,
            "extra_headers": 1, "blank_cols": 0, "subtotals": False,
            "group_headers": False, "casting_diff": 0.0, "footnotes": False},
    ),
    # ------------------------------------------------------------------
    # Client D -- US-listed group with PRC operating subsidiaries.
    # US GAAP, PCAOB methodology, consolidated across four entities,
    # bilingual column headings, PRC statutory payroll.
    # ------------------------------------------------------------------
    "client-d": ClientProfile(
        key="client-d",
        date_style="mdy_slash",
        tb_sheet_name="合并报表 Consol",
        name="Redhawk Bioscience Group Ltd.",
        short="Redhawk Bioscience",
        industry="Botanical health products, US-listed with PRC subsidiaries",
        system="Local PRC bookkeeping software, consolidated in spreadsheets",
        framework="US GAAP (PCAOB audit)",
        year_end=dt.date(2025, 9, 30),
        functional_ccy="USD",
        txn_ccys=["USD", "CNY", "HKD"],
        presentation_dp=2,
        coa_style="slash-separated",         # 2100/000
        variant=2,
        materiality_basis="Total Assets",
        materiality_labels=("Planning Materiality", "Tolerable Misstatement",
                            "Trivial Misstatement"),
        multi_entity=True,
        bilingual=True,
        prc_payroll=True,
        entities=(
            # (code, name, jurisdiction, functional ccy, in scope)
            ("HOLD", "Redhawk Bioscience Group Ltd.", "Cayman Islands", "USD", True),
            ("HKSUB", "Redhawk Bioscience (HK) Limited", "Hong Kong", "HKD", True),
            ("WFOE", "Redhawk Health Technology (Wuxi) Co., Ltd.", "PRC", "CNY", True),
            ("VIE", "Wuxi Redhawk Botanical Products Co., Ltd.", "PRC", "CNY", True),
            ("DORM", "Redhawk Trading (Shenzhen) Co., Ltd.", "PRC", "CNY", False),
        ),
        dq={"date_contam": 0.12, "num_contam": 0.16, "blank_row_p": 0.07,
            "dup_exact": 1, "dup_near": 2, "missing_p": 0.07,
            "extra_headers": 3, "blank_cols": 1, "subtotals": True,
            "group_headers": False, "casting_diff": 0.0, "footnotes": True},
    ),
}


# --------------------------------------------------------------------------
# Fictitious master data pools
# --------------------------------------------------------------------------

CUSTOMER_BASES = [
    "Ardent Fabrication", "Belmont Precision Works", "Caldera Metalcraft",
    "Dunmore Electronics", "Eastvale Assembly", "Farrow Toolworks",
    "Greystone Components", "Halcyon Instruments", "Ironvale Engineering",
    "Juniper Micro Systems", "Kestrel Automation", "Larkspur Machining",
    "Marrowbone Casting", "Northgate Fasteners", "Oakhurst Enclosures",
    "Pinnacle Sheetmetal", "Quarryfield Alloys", "Redwater Robotics",
    "Silverbrook Tooling", "Thornfield Devices", "Umberline Plastics",
    "Vaughn Circuit Assembly", "Westmere Hardware", "Yardley Actuators",
]

SUPPLIER_BASES = [
    "Amberton Raw Materials", "Brookvale Steel Supply", "Carrigan Logistics",
    "Delcourt Chemicals", "Eastmark Packaging", "Fernway Freight",
    "Glenmoor Utilities", "Havenport Shipping", "Innesford Consumables",
    "Jarrowdale Fasteners", "Kirkwall Lubricants", "Lynchford Coatings",
    "Merridale Alloys", "Norbury Abrasives", "Ostend Industrial Gas",
    "Pemberly Office Supply", "Quintrell Maintenance", "Rowanhill Electrical",
]

# Fictitious individuals -- payroll and journal-entry preparers.
EMPLOYEE_NAMES = [
    "Amara Deshpande", "Brendan Okafor", "Caitlin Moreau", "Darius Halloran",
    "Elena Sarkisian", "Farid Benali", "Gwendolyn Achebe", "Hugo Lindqvist",
    "Imogen Balewa", "Jonas Ferreira", "Kalina Novak", "Lucian Marchetti",
    "Mira Kowalczyk", "Nathaniel Boateng", "Orla Fitzgibbon", "Priya Ramanathan",
    "Quentin Delacroix", "Rosalind Mbeki", "Soren Vasquez", "Tabitha Nwosu",
    "Ulric Hammersmith", "Verity Osei", "Wendell Achterberg", "Xiomara Petrov",
]

DEPARTMENTS = ["Production", "Warehouse", "Sales", "Finance & Admin",
               "Quality Assurance", "Engineering"]

# Fictitious banks. Deliberately generic so no real institution is implied.
BANKS = [
    ("Meridian Commercial Bank", "MCB"),
    ("Southport Union Bank", "SUB"),
    ("Trellis Development Bank", "TDB"),
]

FA_CATEGORIES = [
    # (category, default useful life yrs, method, typical cost band)
    ("Leasehold Improvements", 5,  "Straight line", (8_000, 90_000)),
    ("Plant and Machinery",   10,  "Straight line", (15_000, 480_000)),
    ("Office Equipment",       5,  "Straight line", (400, 12_000)),
    ("Furniture and Fittings", 5,  "Straight line", (600, 18_000)),
    ("Computers and IT",       3,  "Straight line", (900, 26_000)),
    ("Motor Vehicles",         5,  "Straight line", (28_000, 180_000)),
    ("Tools and Equipment",    8,  "Straight line", (1_200, 40_000)),
]

INVENTORY_CLASSES = ["Raw Materials", "Work in Progress", "Finished Goods",
                     "Consumables and Spares"]
