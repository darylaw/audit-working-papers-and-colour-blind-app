"""
gen_prov -- synthetic PBC generator for provisions and contingencies (FRS 37 /
SFRS(I) 1-37).

One schedule per client: the movement in each provision (opening, additional
provisions charged, amounts utilised, unused amounts reversed, unwinding of
discount, closing), the current / non-current analysis, the expected timing of
settlement, the discount rate where one is applied, the undiscounted estimate
and any expected reimbursement -- and, on the same schedule, the items the
client classified as contingent liabilities and contingent assets.

The defects planted here are the ones FRS 37 exists to prevent:

  EX-PROV-01  the movement does not cast to the closing balance
  EX-PROV-02  the current / non-current analysis does not agree to the closing
  EX-PROV-06  no discounting where the effect of the time value of money is
              material (para 45) -- an eight-year reinstatement obligation
  EX-PROV-08  the unwinding of the discount does not agree to the recomputation
  EX-PROV-11  a contingent asset has been recognised (para 33)
  EX-PROV-12  a reimbursement recognised above the amount of the provision
              (para 53)
  EX-PROV-14  a provision made for future operating losses (para 63)
  EX-PROV-18  a prior-year provision released in full -- an indicator of
              management bias (SSA 540 (Revised))
  EX-PROV-19  a provision released and re-created in the same year

All output is FICTITIOUS test data. No entity, person or amount here refers to
any real organisation or individual.

Run standalone to (re)write the three client files and merge the planted
exceptions into ../out/_expected-exceptions.json:

    python gen_prov.py
"""

import datetime as dt
import json
import os
import sys

from dqlib import (rng, SheetBuilder, new_workbook, widths, render_date,
                   render_number, whitespace_noise, case_noise, emit_grouped)
from clients import CLIENTS


# ==========================================================================
# Heading vocabulary (DQ-07) -- kept local to this generator so clients.py
# stays untouched. Index by the client's variant, exactly as clients.heading
# does, and prefix the bilingual client's headings the same way.
# ==========================================================================

PROV_HEADINGS = {
    "prov.description":   ["Nature of Provision", "Description", "Particulars",
                           "Provision / Contingency", "Details"],
    "prov.class":         ["Class of Provision", "Provision Type", "Category",
                           "Class", "Type of Provision"],
    "prov.status":        ["Classification", "Recognised / Disclosed", "Treatment",
                           "Provision or Contingency", "Status"],
    "prov.account_code":  ["GL Code", "Account", "A/C", "Account Code", "Nominal"],
    "prov.bal_open":      ["Opening Balance", "Balance B/F", "Bal 1 Jan",
                           "At Beginning of Year", "Brought Forward"],
    "prov.additional":    ["Additional Provisions", "Charged to P&L",
                           "Provided During Year", "Additions", "Increase in Provision"],
    "prov.utilised":      ["Utilised During Year", "Amounts Used", "Utilised",
                           "Payments", "Applied During Year"],
    "prov.released":      ["Unused Amounts Reversed", "Released to P&L", "Write-back",
                           "Reversals", "Released"],
    "prov.unwind":        ["Unwinding of Discount", "Discount Unwind",
                           "Accretion of Discount", "Interest Accretion",
                           "Finance Charge on Provision"],
    "prov.bal_close":     ["Closing Balance", "Balance C/F", "Bal at Year End",
                           "At End of Year", "Carried Forward"],
    "prov.current":       ["Current Portion", "Due Within 12 Months", "Current",
                           "Within One Year", "Current Liability"],
    "prov.noncurrent":    ["Non-current Portion", "Due After 12 Months", "Non-current",
                           "After One Year", "Long Term Portion"],
    "prov.timing":        ["Expected Timing of Settlement", "Expected Settlement Date",
                           "Estimated Timing", "Expected Outflow Date", "Settlement Date"],
    "prov.disc_rate":     ["Discount Rate %", "Discount Rate", "Rate Applied %",
                           "Pre-tax Discount Rate", "Rate %"],
    "prov.undiscounted":  ["Undiscounted Amount", "Gross Expected Outflow",
                           "Estimated Financial Effect", "Best Estimate (Undiscounted)",
                           "Expected Outflow"],
    "prov.reimbursement": ["Expected Reimbursement", "Reimbursement Receivable",
                           "Recovery Expected", "Insurance Recovery", "Reimbursement"],
    "prov.basis":         ["Basis of Estimate", "Basis", "Basis of Computation",
                           "Method of Estimation", "Remarks"],
}

PROV_BILINGUAL = {
    "prov.description":  "项目",
    "prov.class":        "类别",
    "prov.bal_open":     "期初余额",
    "prov.additional":   "本期计提",
    "prov.utilised":     "本期使用",
    "prov.released":     "本期转回",
    "prov.bal_close":    "期末余额",
    "prov.status":       "性质",
}


def h(profile, field):
    """This client's heading for a canonical provisions field."""
    opts = PROV_HEADINGS[field]
    base = opts[profile.variant % len(opts)]
    if getattr(profile, "bilingual", False) and field in PROV_BILINGUAL:
        return f"{PROV_BILINGUAL[field]} {base}"
    return base


# ==========================================================================
# The population
# ==========================================================================

MONEY_FIELDS = {"bal_open", "additional", "utilised", "released", "unwind",
                "bal_close", "current", "noncurrent", "undiscounted",
                "reimbursement"}

# Columns whose parsed value an assertion depends on: left as clean numbers so
# a rendering style can never move a planted difference.
CLEAN_FIELDS = {"bal_open", "bal_close", "unwind", "disc_rate"}

PROVISION = "Provision"
CONTINGENT_LIABILITY = "Contingent liability"
CONTINGENT_ASSET = "Contingent asset"


def _months(ye, n):
    """A date n months after the year end (day clamped to 28)."""
    y = ye.year + (ye.month - 1 + n) // 12
    m = (ye.month - 1 + n) % 12 + 1
    return dt.date(y, m, min(ye.day, 28))


def build_population(profile):
    """
    Twelve items: nine provisions and three contingencies. Amounts are scaled
    per client; the planted differences are fixed so a test can assert them to
    the cent whichever client it is reading.
    """
    r = rng(profile.key, "prov")
    ye = profile.year_end
    s = round(r.uniform(0.82, 1.24), 4)
    m = lambda v: None if v is None else round(v * s, 2)

    recs = []

    def add(cls, desc, status, code, **kw):
        rec = {"cls": cls, "desc": desc, "status": status, "code": code,
               "bal_open": None, "additional": None, "utilised": None,
               "released": None, "unwind": None, "bal_close": None,
               "current": None, "noncurrent": None, "timing": None,
               "disc_rate": None, "undiscounted": None, "reimbursement": None,
               "basis": "", "_seeded_exception": None}
        rec.update(kw)
        recs.append(rec)
        return rec

    coa = {"8-digit blocks": "21510020", "dash-separated": "2-2150",
           "6-digit": "215000", "slash-separated": "2150/000"}
    code = coa.get(profile.coa_style, "2150")

    # 1 -- warranty provision. Closing overstated: the movement does not cast.
    w_close = m(190_000) + 2_450.00
    add("Warranties", "Warranty provision - product warranties", PROVISION, code,
        bal_open=m(180_000), additional=m(96_000), utilised=-m(74_000),
        released=-m(12_000), unwind=0.0, bal_close=round(w_close, 2),
        current=round(w_close, 2), noncurrent=0.0, timing=_months(ye, 8),
        basis="Claims experience applied to sales under warranty",
        _seeded_exception="EX-PROV-01 provision movement does not cast to the closing balance")

    # 2 -- legal claim, clean.
    l_close = m(165_000)
    add("Legal claims", "Legal claim - customer contract dispute", PROVISION, code,
        bal_open=m(120_000), additional=m(45_000), utilised=0.0, released=0.0,
        unwind=0.0, bal_close=l_close, current=l_close, noncurrent=0.0,
        timing=_months(ye, 9),
        basis="Solicitor's estimate of the most likely outcome")

    # 3 -- employment claim with a reimbursement above the provision (para 53).
    e_close = m(38_000)
    add("Legal claims", "Legal claim - employment tribunal", PROVISION, code,
        bal_open=0.0, additional=e_close, utilised=0.0, released=0.0, unwind=0.0,
        bal_close=e_close, current=e_close, noncurrent=0.0, timing=_months(ye, 7),
        reimbursement=m(52_000),
        basis="Legal advice; insurer notified",
        _seeded_exception="EX-PROV-12 expected reimbursement exceeds the provision")

    # 4 -- restructuring provision released in full: a bias indicator.
    add("Restructuring", "Restructuring provision - logistics reorganisation",
        PROVISION, code,
        bal_open=m(96_000), additional=0.0, utilised=0.0, released=-m(96_000),
        unwind=0.0, bal_close=0.0, current=0.0, noncurrent=0.0,
        basis="Plan withdrawn; provision released",
        _seeded_exception="EX-PROV-18 prior year provision released in full")

    # 5 -- onerous contract released and re-created in the same year.
    o_close = m(88_000)
    add("Onerous contracts", "Onerous contract - fixed-price supply contract",
        PROVISION, code,
        bal_open=m(64_000), additional=o_close, utilised=0.0, released=-m(64_000),
        unwind=0.0, bal_close=o_close, current=o_close, noncurrent=0.0,
        timing=_months(ye, 11),
        basis="Unavoidable cost of meeting the obligation less expected benefit",
        _seeded_exception="EX-PROV-19 provision released and re-created in the same year")

    # 6 -- eight-year reinstatement obligation carried undiscounted (para 45).
    d_close = m(240_000)
    add("Decommissioning and restoration", "Reinstatement of leased premises",
        PROVISION, code,
        bal_open=d_close, additional=0.0, utilised=0.0, released=0.0, unwind=0.0,
        bal_close=d_close, current=0.0, noncurrent=d_close,
        timing=_months(ye, 96), undiscounted=m(330_000),
        basis="Quotation from reinstatement contractor",
        _seeded_exception="EX-PROV-06 no discounting where the time value of money is material")

    # 7 -- decommissioning provision whose unwind does not agree.
    c_open = m(180_000)
    c_unwind = round(c_open * 0.05 - 4_880.00, 2)
    c_close = round(c_open + c_unwind, 2)
    add("Decommissioning and restoration", "Decommissioning of coating plant",
        PROVISION, code,
        bal_open=c_open, additional=0.0, utilised=0.0, released=0.0,
        unwind=c_unwind, bal_close=c_close, current=0.0, noncurrent=c_close,
        timing=_months(ye, 72), disc_rate=5.0, undiscounted=m(250_000),
        basis="Discounted at the pre-tax rate advised by group treasury",
        _seeded_exception="EX-PROV-08 unwinding of discount does not agree to the recomputation")

    # 8 -- a provision for future operating losses (para 63 forbids it).
    f_close = m(56_000)
    add("Other provisions", "Provision for future operating losses - coating line",
        PROVISION, code,
        bal_open=0.0, additional=f_close, utilised=0.0, released=0.0, unwind=0.0,
        bal_close=f_close, current=f_close, noncurrent=0.0, timing=_months(ye, 10),
        basis="Budgeted losses of the coating line for the coming year",
        _seeded_exception="EX-PROV-14 provision made for future operating losses")

    # 9 -- site restoration whose current / non-current split is short.
    r_close = m(30_000)
    add("Other provisions", "Site restoration - closed depot", PROVISION, code,
        bal_open=m(42_000), additional=m(6_000), utilised=-m(18_000), released=0.0,
        unwind=0.0, bal_close=r_close, current=round(r_close - 5_000.00, 2),
        noncurrent=0.0, timing=_months(ye, 6),
        basis="Contractor quotation obtained in the year",
        _seeded_exception="EX-PROV-02 current and non-current analysis does not agree to the closing balance")

    # 10-11 -- contingent liabilities, disclosed only.
    add("Contingencies", "Corporate guarantee of subsidiary borrowings",
        CONTINGENT_LIABILITY, code, undiscounted=m(750_000),
        basis="Guarantee limit; no call expected")
    add("Contingencies", "Tax assessment under appeal", CONTINGENT_LIABILITY, code,
        undiscounted=m(185_000),
        basis="Assessment raised; objection lodged")

    # 12 -- a contingent asset that has been recognised (para 33).
    a_close = m(128_000)
    add("Contingencies", "Insurance claim - fire damage recovery",
        CONTINGENT_ASSET, code,
        bal_open=0.0, additional=a_close, utilised=0.0, released=0.0, unwind=0.0,
        bal_close=a_close, current=a_close, noncurrent=0.0,
        undiscounted=m(220_000), basis="Claim lodged with insurer; not yet admitted",
        _seeded_exception="EX-PROV-11 contingent asset recognised")

    return recs, r


# ==========================================================================
# The workbook
# ==========================================================================

def write_provisions(profile, outdir):
    """Write PBC-PROV-01 for one client. Returns (path, records)."""
    recs, r = build_population(profile)
    P, ye, dq = profile, profile.year_end, profile.dq

    wb, ws = new_workbook("Provisions" if P.variant == 0 else "Sheet1")
    sb = SheetBuilder(ws)
    sb.title_block([
        (P.name.upper(), True),
        ("SCHEDULE OF PROVISIONS AND CONTINGENCIES", True),
        (f"As at {ye:%d %B %Y}", False),
        (f"All amounts in {P.functional_ccy}", False),
    ][:max(3, dq["extra_headers"])], merge_to=8)
    sb.blank()

    # Column layout (DQ-07 headings, DQ-03 blank column).
    layout = [
        ("desc",          h(P, "prov.description")),
        ("cls",           h(P, "prov.class")) if not dq["group_headers"] else None,
        ("code",          h(P, "prov.account_code")) if P.variant != 2 else None,
        (None,            None) if dq["group_headers"] else None,      # DQ-03
        ("bal_open",      h(P, "prov.bal_open")),
        ("additional",    h(P, "prov.additional")),
        ("utilised",      h(P, "prov.utilised")),
        ("released",      h(P, "prov.released")),
        ("unwind",        h(P, "prov.unwind")),
        ("bal_close",     h(P, "prov.bal_close")),
        (None,            None) if (dq["blank_cols"] >= 2 or P.variant == 2) else None,
        ("current",       h(P, "prov.current")),
        ("noncurrent",    h(P, "prov.noncurrent")),
        ("timing",        h(P, "prov.timing")),
        ("disc_rate",     h(P, "prov.disc_rate")),
        ("undiscounted",  h(P, "prov.undiscounted")),
        ("reimbursement", h(P, "prov.reimbursement")),
        ("status",        h(P, "prov.status")),
        ("basis",         h(P, "prov.basis")),
    ]
    layout = [x for x in layout if x is not None]
    fields = [f for f, _ in layout]

    # DQ-17: a two-tier header -- a sparse block row over the movement and
    # measurement columns, the way a lead-schedule style provisions note reads.
    if P.variant == 0:
        block = [None] * len(fields)
        block[fields.index("bal_open")] = "MOVEMENT IN THE YEAR"
        block[fields.index("current")] = "ANALYSIS OF CLOSING BALANCE"
        block[fields.index("timing")] = "MEASUREMENT - FRS 37 PARAS 36-52"
        sb.raw(block, bold=True)

    sb.header([hd for _, hd in layout])

    def cell_for(rec, f):
        if f is None:
            return None
        v = rec.get(f)
        if v is None:
            return None
        if f == "timing":
            return render_date(v, P.date_style)
        if f in MONEY_FIELDS and f not in CLEAN_FIELDS:
            if r.random() < dq["num_contam"]:
                return render_number(v, r.choice(
                    ["text", "thousands", "paren_neg", "trailing_minus"]),
                    P.functional_ccy)
            return render_number(v, "native")
        if f in MONEY_FIELDS or f == "disc_rate":
            return render_number(v, "native")
        if f == "basis":
            return whitespace_noise(case_noise(v, r), r)
        if isinstance(v, str):
            return whitespace_noise(v, r)
        return v

    def write_row(sbx, rec):
        sbx.raw([cell_for(rec, f) for f in fields])

    money_cols = [i + 1 for i, f in enumerate(fields)
                  if f in ("bal_open", "additional", "utilised", "released",
                           "unwind", "bal_close", "current", "noncurrent",
                           "undiscounted", "reimbursement")]

    if dq["group_headers"]:
        # DQ-09: the class of provision is carried as a group heading row.
        groups = {}
        for rec in recs:
            groups.setdefault(rec["cls"], []).append(rec)
        first = sb.row
        emit_grouped(sb, list(groups.items()), write_row, group_header=True,
                     subtotal=dq["subtotals"], subtotal_cols=money_cols,
                     subtotal_label="Sub-total")
        last = sb.row - 1
        sb.formula([(c, "sum") for c in money_cols], first, last, label="TOTAL")
    else:
        first = sb.row
        for idx, rec in enumerate(recs):
            if r.random() < dq["blank_row_p"]:      # DQ-02
                sb.blank()
            write_row(sb, rec)
        last = sb.row - 1
        sb.blank()
        sb.formula([(c, "sum") for c in money_cols], first, last, label="TOTAL")

    if dq["footnotes"]:                              # DQ-22
        sb.footnotes([
            "Provisions are the directors' best estimate of the expenditure "
            "required to settle the obligation at the reporting date.",
            "Contingent liabilities are disclosed and not provided for because "
            "an outflow of resources is not considered probable.",
            "* The reinstatement obligation is expected to be settled at the end "
            "of the lease term and has not been discounted.",
        ])

    w = {}
    for i, (f, _) in enumerate(layout):
        letter = chr(ord("A") + i)
        w[letter] = 46 if f == "desc" else 38 if f == "basis" else 20 if f in (
            "timing", "status", "cls") else 18
    widths(ws, w)

    path = os.path.join(
        outdir, f"PBC-PROV-01 Provisions and contingencies {ye:%Y-%m-%d}.xlsx")
    wb.save(path)
    return path, recs


# ==========================================================================
# Standalone: write the three client files and merge the manifest
# ==========================================================================

AREA = "Provisions"
TARGETS = ("client-a", "client-b", "client-d")


def main():
    root = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "out")
    planted = []
    for key in TARGETS:
        profile = CLIENTS[key]
        outdir = os.path.join(root, key)
        os.makedirs(outdir, exist_ok=True)
        path, recs = write_provisions(profile, outdir)
        n = 0
        for rec in recs:
            if rec.get("_seeded_exception"):
                planted.append({"client": key, "area": AREA,
                                "exception": rec["_seeded_exception"],
                                "record_key": rec["desc"]})
                n += 1
        print(f"{key:12s} {os.path.basename(path):58s} "
              f"{len(recs):3d} rows, {n:2d} seeded exceptions")

    mp = os.path.join(root, "_expected-exceptions.json")
    with open(mp, "r", encoding="utf-8") as fh:
        manifest = json.load(fh)
    kept = [e for e in manifest["seeded_exceptions"] if e.get("area") != AREA]
    manifest["seeded_exceptions"] = kept + planted
    for key in TARGETS:
        if key in manifest.get("clients", {}):
            manifest["clients"][key]["seeded_exceptions"] = len(
                [e for e in manifest["seeded_exceptions"] if e["client"] == key])
    with open(mp, "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, indent=2)
    print(f"\n{len(planted)} provisions exceptions merged into {mp}")


if __name__ == "__main__":
    main()
