"""
gen_focus -- synthetic PBC generators for the three partner-priority areas:

  * FRS 36 / SFRS(I) 1-36 impairment of non-financial assets
      - CGU register with assets allocated, including goodwill
      - para 9-14 indicator assessment as completed by the client
      - value-in-use model: 5-year forecast, terminal value, discount rate
  * FRS 109 / SFRS(I) 9 expected credit losses
      - three-year historical write-off history feeding the loss rates
      - provision matrix with forward-looking overlay
      - SICR and credit-impaired watchlist
  * Going concern (SSA/ISA 570)
      - monthly cash flow forecast covering the assessment period
      - covenant compliance schedule and facility maturity profile
      - management's plans with status and evidence

Every defect planted here is drawn from a real requirement of the standard or
from a published regulator finding, so the modules that read this data are
tested against the things that actually go wrong.

All output is FICTITIOUS test data.
"""

import datetime as dt
import os

from dqlib import (rng, SheetBuilder, new_workbook, widths, render_date,
                   render_number, whitespace_noise, round_sum)


# ==========================================================================
# Shared working paper header
# ==========================================================================

def _hdr(sb, profile, wp_ref, subject, cols=7):
    P = profile
    pad = [None] * max(0, cols - 3)
    sb.raw(["Auditor:"] + pad + ["Prepared by:", None, "Date:"])
    sb.raw(["Client:", P.name] + pad[:-1] + ["Reviewed by:", None, "Date:"])
    sb.raw(["Year end:", P.year_end.strftime("%d %B %Y")] + pad[:-1] +
           ["Manager reviewed:", None, "Date:"])
    sb.raw(["WP Ref:", wp_ref] + pad[:-1] + ["Partner reviewed:", None, "Date:"])
    sb.raw(["Subject:", subject] + pad[:-1] + ["EQR reviewed:", None, "Date:"])
    sb.blank()


# ==========================================================================
# 1. FRS 36 IMPAIRMENT
# ==========================================================================

# FRS 36 para 12 -- the minimum indicators an entity must consider.
FRS36_INDICATORS = [
    ("External", "12(a)",
     "Significant decline in the asset's market value during the period, more than "
     "would be expected from the passage of time or normal use"),
    ("External", "12(b)",
     "Significant adverse changes in the technological, market, economic or legal "
     "environment in which the entity operates or in the market to which the asset "
     "is dedicated"),
    ("External", "12(c)",
     "Market interest rates or other market rates of return have increased during "
     "the period, likely affecting the discount rate and materially decreasing the "
     "recoverable amount"),
    ("External", "12(d)",
     "The carrying amount of the net assets of the entity exceeds its market "
     "capitalisation"),
    ("Internal", "12(e)",
     "Evidence of obsolescence or physical damage of the asset"),
    ("Internal", "12(f)",
     "Significant adverse changes in the extent to which, or manner in which, the "
     "asset is used or is expected to be used - including the asset becoming idle, "
     "plans to discontinue or restructure the operation, plans to dispose of the "
     "asset before the previously expected date, and reassessing the useful life as "
     "finite rather than indefinite"),
    ("Internal", "12(g)",
     "Evidence from internal reporting that the economic performance of the asset "
     "is, or will be, worse than expected"),
    ("Internal", "14",
     "Internal reporting evidence: cash flows for acquiring or operating the asset "
     "significantly higher than budgeted; actual net cash flows or operating result "
     "significantly worse than budgeted; significant decline in budgeted net cash "
     "flows; or operating losses / net cash outflows when current and future budgeted "
     "amounts are aggregated"),
    ("Investments", "12(h)",
     "For an investment in a subsidiary, joint venture or associate: the dividend "
     "exceeds the total comprehensive income of the investee in the period, or the "
     "carrying amount of the investment exceeds the carrying amount of the investee's "
     "net assets in the consolidated financial statements"),
]

CGUS = [
    # (name, has_goodwill, indefinite_life_intangible)
    ("Distribution - domestic", False, False),
    ("Distribution - export", False, False),
    ("Manufacturing operations", True, False),
    ("Specialty coatings business", True, True),
]


def write_impairment_pack(profile, outdir):
    """
    Three sheets: CGU register and allocation, the para 12 indicator
    assessment, and the value-in-use model with its sensitivity.
    """
    r = rng(profile.key, "imp")
    P, ye = profile, profile.year_end
    wb, ws = new_workbook("CGU register")
    sb = SheetBuilder(ws)
    _hdr(sb, P, "IMP-01", "Cash-generating units and allocation of assets", 9)

    sb.raw(["Objective:", "To identify the cash-generating units to which assets, "
            "including goodwill, are allocated, and to establish the carrying amount "
            "to be compared with recoverable amount (FRS 36 paras 6, 66-73, 80)"])
    sb.raw(["Note:", "Goodwill is allocated to the lowest level at which it is "
            "monitored for internal management purposes and not larger than an "
            "operating segment (FRS 36 para 80)."])
    sb.blank()

    first = sb.row + 1
    sb.header(["CGU", "Operating segment", "Basis of identification",
               "PPE", "Right-of-use assets", "Intangibles (finite life)",
               "Intangibles (indefinite life)", "Goodwill",
               "Other assets less liabilities", "Carrying amount",
               "Tested annually?", "Date last tested"])
    cgus = []
    for name, has_gw, indef in CGUS:
        ppe = round(r.uniform(180_000, 2_400_000), 2)
        rou = round(r.uniform(0, 900_000), 2)
        ia_f = round(r.uniform(0, 120_000), 2)
        ia_i = round(r.uniform(140_000, 480_000), 2) if indef else 0.0
        gw = round(r.uniform(320_000, 1_850_000), 2) if has_gw else 0.0
        oth = round(r.uniform(-260_000, 640_000), 2)
        ca = round(ppe + rou + ia_f + ia_i + gw + oth, 2)
        cgus.append({"name": name, "gw": gw, "indef": ia_i, "ca": ca,
                     "_seeded_exception": None})
        annual = "Yes" if (has_gw or indef) else "No - indicator based"
        last = ye if (has_gw or indef) else ye - dt.timedelta(days=r.randint(30, 400))
        sb.raw([name, r.choice(["Distribution", "Manufacturing", "Specialty"]),
                "Lowest level of independent cash inflows",
                ppe, rou, ia_f, ia_i, gw, oth, ca, annual,
                render_date(last, P.date_style)])
    last_row = sb.row - 1

    # EX: a CGU carrying goodwill that the client did not test annually
    ws.cell(row=first + 2, column=11, value="No")
    ws.cell(row=first + 2, column=12,
            value=render_date(ye - dt.timedelta(days=430), P.date_style))
    cgus[2]["_seeded_exception"] = (
        "EX-IMP-01 CGU carrying goodwill not tested annually (FRS 36 para 90)")

    sb.blank()
    sb.formula([(c, "sum") for c in range(4, 11)], first, last_row, label="TOTAL")
    sb.footnotes([
        "Goodwill and indefinite-life intangibles are tested annually irrespective "
        "of indicators (FRS 36 para 10).",
        "Corporate assets are allocated to CGUs on a reasonable and consistent basis "
        "(FRS 36 paras 100-103).",
    ])
    widths(ws, {"A": 32, "B": 20, "C": 34, "D": 16, "E": 18, "F": 20, "G": 22,
                "H": 16, "I": 24, "J": 18, "K": 20, "L": 16})

    # ---- Sheet 2: the para 12 indicator assessment --------------------
    ws2 = wb.create_sheet("Indicators FRS 36 para 12")
    sb2 = SheetBuilder(ws2)
    _hdr(sb2, P, "IMP-02", "Assessment of indicators of impairment - FRS 36 paras 9-14", 5)
    sb2.raw(["Objective:", "FRS 36 para 9 requires an assessment at the end of each "
             "reporting period of whether there is any indication that an asset may "
             "be impaired. Where an indication exists, recoverable amount must be "
             "estimated."])
    sb2.raw(["Note:", "The para 12 list is a minimum, not exhaustive (FRS 36 para 13). "
             "Consider also entity-specific and sustainability-related indicators."])
    sb2.blank()
    f2 = sb2.row + 1
    sb2.header(["Source", "FRS 36 ref", "Indicator", "Present? (Y/N)",
                "Management commentary", "Evidence obtained", "CGU affected",
                "Recoverable amount estimated?"])
    responses = [
        ("N", "Market values of comparable assets stable during the year.", "Broker indications", "", "n/a"),
        ("Y", "Export demand contracted following tariff changes in a key market.",
         "Board papers, segment results", "Distribution - export", "Yes"),
        ("Y", "Benchmark rates rose 90 bps over the year.",
         "Central bank rate history", "All CGUs", "Yes"),
        ("N", "Entity is not listed; no market capitalisation.", "n/a", "", "n/a"),
        ("N", "No obsolescence or damage reported.", "Fixed asset verification", "", "n/a"),
        ("Y", "Coating line idle since April pending re-permitting.",
         "Production logs", "Specialty coatings business", "No"),
        ("Y", "Manufacturing gross margin 640 bps below budget for the year.",
         "Management accounts", "Manufacturing operations", "Yes"),
        ("Y", "Aggregate of actual and budgeted cash flows shows net outflow for the "
         "coatings CGU over the next two years.", "FY+1 and FY+2 budget",
         "Specialty coatings business", "No"),
        ("N", "No dividends received exceeding investee comprehensive income.",
         "Investee accounts", "", "n/a"),
    ]
    for (src, ref, text), (present, comm, ev, cgu, ra) in zip(FRS36_INDICATORS, responses):
        sb2.raw([src, ref, text, present, comm, ev, cgu, ra])
    sb2.blank()
    sb2.footnotes([
        "Where an indicator is present, FRS 36 para 9 requires recoverable amount to "
        "be estimated. Two indicators above are marked present with no recoverable "
        "amount estimated - refer audit findings.",
    ])
    widths(ws2, {"A": 14, "B": 12, "C": 76, "D": 14, "E": 52, "F": 26, "G": 30, "H": 26})

    # ---- Sheet 3: the value in use model ------------------------------
    ws3 = wb.create_sheet("VIU model")
    sb3 = SheetBuilder(ws3)
    _hdr(sb3, P, "IMP-03", "Value in use - Manufacturing operations CGU", 8)

    # Deliberately a SEVEN year forecast: FRS 36 para 33(b) caps at five
    # years unless a longer period is justified.
    years = 7
    growth_in = 0.09
    ca = cgus[2]["ca"]
    disc = 0.093
    terminal_growth = 0.045          # above long-run GDP -- para 33(c) challenge

    def viu_for(base_cf, d, g=growth_in, tg=terminal_growth, n=years):
        """Present value of an n-year forecast plus a Gordon terminal value."""
        flows = [base_cf * (1 + g) ** (i + 1) for i in range(n)]
        pv = sum(f / (1 + d) ** (i + 1) for i, f in enumerate(flows))
        term = flows[-1] * (1 + tg) / (d - tg)
        return pv + term / (1 + d) ** n, flows, term

    # Calibrate the base cash flow so headroom is deliberately MARGINAL --
    # the situation ACRA flags, where a small rise in the discount rate wipes
    # out the headroom and a para 134(f) sensitivity disclosure is required.
    target_headroom = 0.042
    unit_viu, _, _ = viu_for(1.0, disc)
    base = round(ca * (1 + target_headroom) / unit_viu, 2)

    sb3.raw(["Objective:", "To determine the value in use of the CGU in accordance "
             "with FRS 36 paras 30-57."])
    sb3.raw(["Prepared by:", "Group finance (internal). Prior year model was prepared "
             "by an external valuation specialist."])
    sb3.blank()
    sb3.raw(["Key assumptions"], bold=True)
    sb3.raw(["Discount rate applied", None, disc])
    sb3.raw(["Basis of discount rate", None,
             "Group post-tax WACC as advised by treasury"])
    sb3.raw(["Terminal growth rate", None, terminal_growth])
    sb3.raw(["Long-term average growth rate for the industry", None, 0.021])
    sb3.raw(["Forecast period (years)", None, years])
    sb3.raw(["Cash flows include income tax payments?", None, "Yes"])
    sb3.raw(["Cash flows include interest on CGU borrowings?", None, "Yes"])
    sb3.raw(["Cash flows include planned capacity expansion (not yet committed)?",
             None, "Yes"])
    sb3.raw(["Risk premium added to cash flows as well as discount rate?", None, "Yes"])
    sb3.blank()

    f3 = sb3.row + 1
    sb3.header(["Year"] + [f"FY{ye.year + i + 1}" for i in range(years)] +
               ["Terminal", "Total"])
    viu_calc, flows_raw, terminal = viu_for(base, disc)
    flows = [round(f, 2) for f in flows_raw]
    rows = {}
    rows["Forecast net cash flow"] = flows
    rows["Discount factor"] = [round(1 / ((1 + disc) ** (i + 1)), 4) for i in range(years)]
    rows["Discounted cash flow"] = [round(flows_raw[i] / ((1 + disc) ** (i + 1)), 2)
                                    for i in range(years)]
    term_disc = round(terminal / ((1 + disc) ** years), 2)

    for label, vals in rows.items():
        sb3.raw([label] + vals + ([None, None] if label != "Discounted cash flow"
                                  else [term_disc, None]))
    dr = sb3.row - 1
    viu = round(sum(rows["Discounted cash flow"]) + term_disc, 2)
    sb3.blank()
    sb3.raw(["Value in use", None, None, None, None, None, None, None, None, viu], bold=True)
    sb3.raw(["Carrying amount of CGU", None, None, None, None, None, None, None, None, ca], bold=True)
    sb3.raw(["Headroom / (impairment)", None, None, None, None, None, None, None, None,
             round(viu - ca, 2)], bold=True)
    sb3.raw(["Headroom as % of carrying amount", None, None, None, None, None, None,
             None, None, round((viu - ca) / ca, 4)])
    sb3.blank()
    sb3.raw(["Sensitivity analysis"], bold=True)
    sb3.raw(["FRS 36 para 134(f) requires disclosure where a reasonably possible "
             "change in a key assumption would eliminate the headroom."])
    sb3.raw(["Sensitivity analysis prepared by management?", None, "No"])
    sb3.raw(["Sensitivity disclosed in the financial statements?", None, "No"])
    # The figure the audit module must derive independently: the discount rate
    # at which headroom becomes nil, and therefore the required disclosure.
    lo, hi = disc, 0.60
    for _ in range(80):
        mid = (lo + hi) / 2
        v, _, _ = viu_for(base, mid)
        if v > ca:
            lo = mid
        else:
            hi = mid
    breakeven = (lo + hi) / 2
    sb3.blank()
    sb3.raw(["Memorandum - not prepared by the client:"], italic=True)
    sb3.raw(["Discount rate at which headroom becomes nil", None, round(breakeven, 4)])
    sb3.raw(["Increase in discount rate required to eliminate headroom (bps)", None,
             round((breakeven - disc) * 10_000, 0)])
    sb3.footnotes([
        "Model provided by client in this form. Formulae in the discounted cash flow "
        "row have been overwritten with values in the client's file.",
        "Fair value less costs of disposal has not been determined; management "
        "considers value in use to be higher.",
    ])
    widths(ws3, {"A": 46})
    for i in range(years + 2):
        widths(ws3, {chr(66 + i): 16})

    path = os.path.join(outdir, f"PBC-IMP-01 Impairment assessment FRS 36 {ye:%Y-%m-%d}.xlsx")
    wb.save(path)

    # Seeded exceptions carried on the CGU records
    cgus[0]["_seeded_exception"] = (
        "EX-IMP-02 forecast period exceeds five years with no justification "
        "(FRS 36 para 33(b))")
    cgus[1]["_seeded_exception"] = (
        "EX-IMP-03 terminal growth rate exceeds the long-term industry average "
        "with no justification (FRS 36 para 33(c))")
    cgus[3]["_seeded_exception"] = (
        "EX-IMP-04 post-tax discount rate applied to pre-tax cash flows "
        "(FRS 36 paras 50, 55)")
    extra = [
        {"name": "Manufacturing operations", "_seeded_exception":
         "EX-IMP-05 income tax cash flows included in value in use (FRS 36 para 50)"},
        {"name": "Manufacturing operations", "_seeded_exception":
         "EX-IMP-06 financing cash flows included in value in use (FRS 36 para 50)"},
        {"name": "Manufacturing operations", "_seeded_exception":
         "EX-IMP-07 cash flows from uncommitted expansion included "
         "(FRS 36 paras 33(b), 44)"},
        {"name": "Manufacturing operations", "_seeded_exception":
         "EX-IMP-08 risk reflected in both cash flows and discount rate "
         "(FRS 36 para 55) - double counting"},
        {"name": "Specialty coatings business", "_seeded_exception":
         "EX-IMP-09 impairment indicator present with no recoverable amount "
         "estimated (FRS 36 para 9)"},
        {"name": "Manufacturing operations", "_seeded_exception":
         "EX-IMP-10 headroom eliminated by a reasonably possible change in the "
         "discount rate but no sensitivity disclosed (FRS 36 para 134(f))"},
        {"name": "Specialty coatings business", "_seeded_exception":
         "EX-IMP-11 valuation moved from external specialist to internal preparation "
         "with no change in assumptions"},
    ]
    return path, cgus + extra


# ==========================================================================
# 2. FRS 109 EXPECTED CREDIT LOSSES
# ==========================================================================

BUCKETS = [("Not past due", 0), ("1-30 days", 1), ("31-60 days", 31),
           ("61-90 days", 61), ("91-180 days", 91), ("181-365 days", 181),
           ("Over 365 days", 366)]


def write_ecl_pack(profile, outdir, ar_records=None):
    """
    The three things a provision matrix needs and clients routinely omit:
    a derived historical loss rate, a forward-looking overlay, and a
    separate assessment of balances that are credit-impaired or show SICR.
    """
    r = rng(profile.key, "ecl")
    P, ye = profile, profile.year_end
    wb, ws = new_workbook("Loss rate history")
    sb = SheetBuilder(ws)
    _hdr(sb, P, "ECL-01",
         "Derivation of historical loss rates - FRS 109 simplified approach", 6)
    sb.raw(["Objective:", "To derive observed historical credit loss rates by ageing "
            "band from at least three years of collection experience, as the starting "
            "point for the provision matrix (FRS 109 para B5.5.35)."])
    sb.raw(["Note:", "FRS 109 para 5.5.15 requires lifetime expected credit losses for "
            "trade receivables without a significant financing component."])
    sb.blank()

    first = sb.row + 1
    sb.header(["Ageing band", "FY-3 gross at year end", "FY-3 subsequently written off",
               "FY-2 gross at year end", "FY-2 subsequently written off",
               "FY-1 gross at year end", "FY-1 subsequently written off",
               "Three-year observed loss rate"])
    hist = []
    base_rates = [0.002, 0.005, 0.012, 0.028, 0.075, 0.185, 0.520]
    for (band, _), br in zip(BUCKETS, base_rates):
        row = [band]
        tot_g = tot_w = 0.0
        for k in range(3):
            g = round(r.uniform(60_000, 1_400_000), 2)
            w = round(g * br * r.uniform(0.72, 1.34), 2)
            tot_g += g
            tot_w += w
            row += [g, w]
        rate = round(tot_w / tot_g, 4) if tot_g else 0.0
        hist.append({"band": band, "observed": rate})
        row.append(rate)
        sb.raw(row)
    last = sb.row - 1
    sb.blank()
    sb.formula([(c, "sum") for c in range(2, 8)], first, last, label="TOTAL")
    sb.footnotes([
        "Write-off policy: a receivable is written off when there is no reasonable "
        "expectation of recovery, including where the debtor has entered liquidation "
        "or a scheme of arrangement, or has failed to make contractual payments for "
        "more than 365 days.",
        "Definition of default: the Company considers a receivable to be in default "
        "when it is more than 90 days past due, unless reasonable and supportable "
        "information demonstrates otherwise (FRS 109 para B5.5.37).",
    ])
    widths(ws, {"A": 22})
    for c in "BCDEFGH":
        widths(ws, {c: 22})

    # ---- Sheet 2: forward-looking overlay -----------------------------
    ws2 = wb.create_sheet("Forward-looking overlay")
    sb2 = SheetBuilder(ws2)
    _hdr(sb2, P, "ECL-02", "Forward-looking information and scenario weighting", 5)
    sb2.raw(["Objective:", "FRS 109 para 5.5.17 requires expected credit losses to be "
             "an unbiased probability-weighted amount reflecting reasonable and "
             "supportable information about past events, current conditions and "
             "forecasts of future economic conditions."])
    sb2.blank()
    sb2.raw(["Macroeconomic scenarios"], bold=True)
    f2 = sb2.row + 1
    sb2.header(["Scenario", "Weighting", "GDP growth", "Unemployment rate",
                "Sector default index", "Multiplier applied to observed loss rate"])
    scen = [("Base", 1.00, 0.024, 0.021, 1.00, 1.00),
            ("Upside", 0.00, 0.038, 0.018, 0.84, 0.82),
            ("Downside", 0.00, -0.007, 0.034, 1.62, 1.55)]
    for s in scen:
        sb2.raw(list(s))
    sb2.blank()
    sb2.raw(["Probability-weighted multiplier", None, None, None, None, 1.00], bold=True)
    sb2.blank()
    sb2.raw(["Source of macroeconomic data:", "Management estimate. No external "
             "source documented."])
    sb2.raw(["Date overlay last updated:",
             render_date(ye - dt.timedelta(days=760), P.date_style)])
    sb2.footnotes([
        "Only the base scenario carries a weighting in the client's model.",
        "The overlay has not been refreshed since it was first prepared.",
    ])
    widths(ws2, {"A": 22, "B": 14, "C": 16, "D": 22, "E": 24, "F": 42})

    # ---- Sheet 3: the provision matrix --------------------------------
    ws3 = wb.create_sheet("Provision matrix")
    sb3 = SheetBuilder(ws3)
    _hdr(sb3, P, "ECL-03", "Provision matrix and loss allowance", 6)
    f3 = sb3.row + 1
    sb3.header(["Ageing band", "Gross carrying amount",
                "Of which: related party", "Of which: credit-impaired",
                "Loss rate applied by client", "Observed historical rate (ECL-01)",
                "Forward-looking multiplier (ECL-02)", "Expected loss rate per audit",
                "ECL per client", "ECL per audit", "Difference"])
    client_rates = [0.000, 0.000, 0.000, 0.010, 0.020, 0.050, 0.100]
    matrix = []
    for (band, _), h, cr in zip(BUCKETS, hist, client_rates):
        gross = round(r.uniform(38_000, 1_180_000), 2)
        rp = round(gross * r.uniform(0.0, 0.22), 2)
        ci = round(gross * r.uniform(0.0, 0.10), 2) if band.startswith(("181", "Over")) else 0.0
        audit_rate = round(h["observed"] * 1.00, 4)
        ecl_client = round(gross * cr, 2)
        ecl_audit = round(gross * audit_rate, 2)
        matrix.append({"band": band, "gross": gross,
                       "ecl_client": ecl_client, "ecl_audit": ecl_audit,
                       "_seeded_exception": None})
        sb3.raw([band, gross, rp, ci, cr, h["observed"], 1.00, audit_rate,
                 ecl_client, ecl_audit, round(ecl_audit - ecl_client, 2)])
    l3 = sb3.row - 1
    sb3.blank()
    sb3.formula([(c, "sum") for c in (2, 3, 4, 9, 10, 11)], f3, l3, label="TOTAL")
    sb3.blank()
    sb3.raw(["Loss allowance per trial balance", None, None, None, None, None,
             None, None, 96_400.00], bold=True)
    sb3.raw(["Difference - matrix to ledger", None, None, None, None, None, None,
             None, None, None, "see findings"])
    sb3.footnotes([
        "Related party receivables are excluded from the matrix in the client's model "
        "on the basis that they are recoverable on demand.",
        "Credit-impaired balances remain within the matrix at the ageing band rate.",
    ])
    widths(ws3, {"A": 22, "B": 22, "C": 22, "D": 24, "E": 24, "F": 26, "G": 28,
                 "H": 26, "I": 20, "J": 20, "K": 18})

    # ---- Sheet 4: SICR and credit-impaired watchlist ------------------
    ws4 = wb.create_sheet("SICR watchlist")
    sb4 = SheetBuilder(ws4)
    _hdr(sb4, P, "ECL-04",
         "Significant increase in credit risk and credit-impaired assessment", 6)
    sb4.raw(["Objective:", "FRS 109 para 5.5.3 requires a lifetime loss allowance "
             "where credit risk has increased significantly since initial "
             "recognition. Balances assessed individually are removed from the "
             "collective matrix."])
    sb4.blank()
    f4 = sb4.row + 1
    sb4.header(["Counterparty", "Relationship", "Gross balance", "Days past due",
                "Indicator of financial difficulty", "SICR? (Y/N)",
                "Credit-impaired? (Y/N)", "Individual ECL per client",
                "Individual ECL per audit", "Basis"])
    watch = [
        ("Ardent Fabrication Pte Ltd", "Third party", 412_800.00, 486,
         "Debtor loss-making, net liability position, negative operating cash flows, "
         "applied for a scheme of arrangement", "N", "N", 0.00, 412_800.00,
         "No enforceable security; recovery dependent on scheme outcome"),
        ("Redstone Capital Partners Ltd.", "Common director", 268_400.00, 612,
         "No repayment received in the year; no written repayment terms", "N", "N",
         0.00, 134_200.00, "Related party; no legally binding repayment agreement"),
        ("Dunmore Electronics Pte. Ltd.", "Third party", 96_300.00, 214,
         "Two payment plans defaulted during the year", "Y", "N", 9_630.00,
         48_150.00, "Payment plan defaults evidence SICR"),
        ("Kestrel Automation Pte Ltd", "Third party", 58_900.00, 41,
         "Rated downgrade by trade credit insurer", "Y", "N", 0.00, 5_890.00,
         "Insurer downgrade; still within terms"),
        ("Larkspur Machining Pte. Ltd.", "Third party", 31_200.00, 22,
         "None identified", "N", "N", 0.00, 0.00, "Performing"),
    ]
    for w in watch:
        sb4.raw(list(w))
    l4 = sb4.row - 1
    sb4.blank()
    sb4.formula([(c, "sum") for c in (3, 8, 9)], f4, l4, label="TOTAL")
    sb4.footnotes([
        "FRS 109 para 5.5.11 contains a rebuttable presumption that credit risk has "
        "increased significantly when contractual payments are more than 30 days past "
        "due.",
        "Absence of a recorded loss allowance does not remove the requirement to "
        "disclose the judgements made in reaching that conclusion.",
    ])
    widths(ws4, {"A": 34, "B": 20, "C": 18, "D": 16, "E": 62, "F": 14, "G": 20,
                 "H": 24, "I": 24, "J": 52})

    path = os.path.join(outdir, f"PBC-ECL-01 Expected credit loss assessment {ye:%Y-%m-%d}.xlsx")
    wb.save(path)

    exc = [
        {"desc": "matrix", "_seeded_exception":
         "EX-ECL-01 nil loss rate applied to past-due bands unsupported by the "
         "observed loss history (FRS 109 para B5.5.35)"},
        {"desc": "overlay", "_seeded_exception":
         "EX-ECL-02 no forward-looking adjustment applied - single scenario weighted "
         "100% (FRS 109 para 5.5.17)"},
        {"desc": "overlay", "_seeded_exception":
         "EX-ECL-03 forward-looking overlay not updated for over two years"},
        {"desc": "overlay", "_seeded_exception":
         "EX-ECL-04 macroeconomic inputs not supported by an external source"},
        {"desc": "watchlist", "_seeded_exception":
         "EX-ECL-05 debtor in financial difficulty with nil allowance - SICR "
         "indicators present (FRS 109 para 5.5.3)"},
        {"desc": "watchlist", "_seeded_exception":
         "EX-ECL-06 balance over 365 days past due not assessed as credit-impaired"},
        {"desc": "matrix", "_seeded_exception":
         "EX-ECL-07 related party receivables excluded from the ECL assessment"},
        {"desc": "matrix", "_seeded_exception":
         "EX-ECL-08 credit-impaired balances left in the collective matrix rather "
         "than assessed individually"},
        {"desc": "matrix", "_seeded_exception":
         "EX-ECL-09 provision matrix total does not agree to the loss allowance in "
         "the trial balance"},
        {"desc": "history", "_seeded_exception":
         "EX-ECL-10 loss rates applied by the client not derived from the observed "
         "loss history provided"},
    ]
    return path, exc


# ==========================================================================
# 3. GOING CONCERN
# ==========================================================================

def write_going_concern_pack(profile, outdir):
    """
    Cash flow forecast, covenant schedule, facility maturities and
    management's plans -- the four documents a going concern conclusion rests on.
    """
    r = rng(profile.key, "gc")
    P, ye = profile, profile.year_end
    approval = ye + dt.timedelta(days=112)      # FS approval date

    wb, ws = new_workbook("Cash flow forecast")
    sb = SheetBuilder(ws)
    _hdr(sb, P, "GC-01", "Cash flow forecast supporting the going concern assessment", 8)
    sb.raw(["Objective:", "To evaluate management's assessment of the entity's ability "
            "to continue as a going concern (SSA 570 paras 12-14)."])
    sb.raw(["Date financial statements approved by the Board:",
            render_date(approval, P.date_style)])
    sb.raw(["Forecast period covered by management's assessment:", "12 months from the "
            "reporting date"])
    sb.raw(["Months from approval date covered by the forecast:", None, 8])
    sb.blank()

    months = []
    d = dt.date(ye.year, ye.month, 1) + dt.timedelta(days=32)
    d = d.replace(day=1)
    for _ in range(12):
        months.append(d)
        d = (d.replace(day=28) + dt.timedelta(days=8)).replace(day=1)

    f1 = sb.row + 1
    sb.header(["Line"] + [m.strftime("%b %y") for m in months] + ["Total"])
    opening = 341_486.00
    lines = {}
    lines["Receipts from customers"] = [round(r.uniform(380_000, 720_000), 2) for _ in months]
    lines["Payments to suppliers"] = [-round(r.uniform(300_000, 560_000), 2) for _ in months]
    lines["Payroll and statutory"] = [-round(r.uniform(96_000, 128_000), 2) for _ in months]
    lines["Other operating payments"] = [-round(r.uniform(38_000, 74_000), 2) for _ in months]
    lines["Loan principal repayments"] = [-round(r.uniform(11_000, 14_500), 2) for _ in months]
    lines["Interest paid"] = [-round(r.uniform(1_800, 3_400), 2) for _ in months]
    lines["Capital expenditure"] = [-round(r.uniform(0, 42_000), 2) for _ in months]
    lines["Proceeds from proposed share placement"] = [0.0] * 12
    lines["Proceeds from proposed share placement"][4] = 1_500_000.00
    lines["Shareholder loan (uncommitted)"] = [0.0] * 12
    lines["Shareholder loan (uncommitted)"][7] = 600_000.00

    for label, vals in lines.items():
        sb.raw([label] + vals + [None])
        rr = sb.row - 1
        ws.cell(row=rr, column=14, value=f"=SUM(B{rr}:M{rr})")
    l1 = sb.row - 1
    sb.blank()
    net = [sum(lines[k][i] for k in lines) for i in range(12)]
    sb.raw(["Net cash flow for the month"] + [round(x, 2) for x in net] +
           [round(sum(net), 2)], bold=True)
    bal, closing = opening, []
    for x in net:
        bal += x
        closing.append(round(bal, 2))
    sb.raw(["Opening cash"] + [round(opening if i == 0 else closing[i-1], 2)
                               for i in range(12)] + [None])
    sb.raw(["Closing cash"] + closing + [None], bold=True)
    sb.raw(["Undrawn facility headroom"] + [round(max(0.0, 250_000 - i * 9_000), 2)
                                            for i in range(12)] + [None])
    sb.raw(["Total liquidity"] + [round(closing[i] + max(0.0, 250_000 - i * 9_000), 2)
                                  for i in range(12)] + [None], bold=True)
    sb.blank()
    sb.footnotes([
        "Forecast prepared by management and approved by the Board.",
        "The forecast assumes the proposed share placement completes in month 5 and "
        "that the shareholder provides a further loan in month 8.",
        "Opening cash of 341,486 agrees to the audited cash and cash equivalents.",
    ])
    widths(ws, {"A": 46})
    for i in range(13):
        widths(ws, {chr(66 + i): 15})

    # ---- Sheet 2: covenants -------------------------------------------
    ws2 = wb.create_sheet("Covenant compliance")
    sb2 = SheetBuilder(ws2)
    _hdr(sb2, P, "GC-02", "Loan covenant compliance and forecast compliance", 6)
    f2 = sb2.row + 1
    sb2.header(["Facility", "Lender", "Covenant", "Threshold", "Measured at",
                "Actual at year end", "Compliant?", "Forecast at next test date",
                "Forecast compliant?", "Consequence of breach"])
    cov = [
        ("Term loan - equipment", "Meridian Commercial Bank", "Net gearing", "<= 1.50x",
         "Half-yearly", 1.18, "Yes", 1.41, "Yes", "Immediately repayable on demand"),
        ("Working capital facility", "Southport Union Bank", "Interest cover", ">= 3.00x",
         "Quarterly", 3.42, "Yes", 2.610, "No", "Immediately repayable on demand"),
        ("Property mortgage", "Trellis Development Bank", "Debt service cover", ">= 1.25x",
         "Annually", 1.31, "Yes", 1.27, "Yes", "Step-up margin of 200 bps"),
        ("Bridging loan", "Meridian Commercial Bank", "Minimum tangible net worth",
         ">= 2,000,000", "Annually", 2_400_080.35, "Yes", 1_920_000.00, "No",
         "Immediately repayable on demand"),
    ]
    for c in cov:
        sb2.raw(list(c))
    sb2.blank()
    sb2.footnotes([
        "Where a covenant is breached and the lender has not provided a waiver before "
        "the reporting date, the related borrowing is classified as current "
        "(FRS 1 paras 74-75).",
    ])
    widths(ws2, {"A": 28, "B": 28, "C": 30, "D": 18, "E": 16, "F": 22, "G": 14,
                 "H": 26, "I": 20, "J": 36})

    # ---- Sheet 3: facility maturities ---------------------------------
    ws3 = wb.create_sheet("Facility maturities")
    sb3 = SheetBuilder(ws3)
    _hdr(sb3, P, "GC-03", "Borrowing facilities and maturity profile", 6)
    f3 = sb3.row + 1
    sb3.header(["Facility", "Lender", "Limit", "Drawn at year end", "Undrawn",
                "Maturity / next review date", "Months to maturity from approval",
                "Renewal confirmed in writing?", "Evidence"])
    fac = [
        ("Term loan - equipment", "Meridian Commercial Bank", 480_000, 279_297, 0,
         ye + dt.timedelta(days=540), 14, "n/a - term", "Facility letter"),
        ("Working capital facility", "Southport Union Bank", 300_000, 0, 300_000,
         ye + dt.timedelta(days=95), 0, "No", "Verbal indication only"),
        ("Property mortgage", "Trellis Development Bank", 1_200_000, 0, 0,
         ye + dt.timedelta(days=2_800), 80, "n/a - term", "Facility letter"),
        ("Bridging loan", "Meridian Commercial Bank", 250_000, 0, 250_000,
         ye + dt.timedelta(days=210), 3, "No", "Under negotiation"),
    ]
    for f in fac:
        sb3.raw([f[0], f[1], f[2], f[3], f[4],
                 render_date(f[5], P.date_style), f[6], f[7], f[8]])
    widths(ws3, {"A": 28, "B": 28, "C": 16, "D": 20, "E": 16, "F": 26, "G": 32,
                 "H": 28, "I": 26})

    # ---- Sheet 4: management's plans ----------------------------------
    ws4 = wb.create_sheet("Management plans")
    sb4 = SheetBuilder(ws4)
    _hdr(sb4, P, "GC-04", "Management's plans and mitigating factors", 5)
    sb4.raw(["Note:", "SSA 570 requires the auditor to evaluate whether management's "
             "plans are feasible, whether management has the intent and ability to "
             "carry them out, and whether the outcome improves the situation."])
    sb4.blank()
    f4 = sb4.row + 1
    sb4.header(["Plan", "Cash effect", "Timing assumed in forecast", "Status",
                "Committed or uncommitted", "Evidence obtained",
                "Within management's control?", "Auditor assessment"])
    plans = [
        ("Equity placement to new institutional investor", 1_500_000,
         "Month 5", "Term sheet signed, subject to due diligence", "Uncommitted",
         "Non-binding term sheet", "No", ""),
        ("Further shareholder loan", 600_000, "Month 8",
         "Discussed verbally with controlling shareholder", "Uncommitted",
         "None", "No", ""),
        ("Renewal of working capital facility", 300_000, "Month 3 onwards",
         "Application submitted", "Uncommitted", "Verbal indication from relationship "
         "manager", "No", ""),
        ("Deferral of discretionary capital expenditure", 180_000, "Months 1-12",
         "Board approved", "Committed", "Board minutes dated within the period",
         "Yes", ""),
        ("Headcount reduction in the export division", 240_000, "Months 2-12",
         "Announced to staff", "Committed", "Restructuring plan and notices", "Yes", ""),
    ]
    for p_ in plans:
        sb4.raw(list(p_))
    sb4.blank()
    sb4.footnotes([
        "Of the total mitigating cash inflows assumed in the forecast, 2,400,000 "
        "depends on actions outside management's control and not yet committed.",
        "Written representations on management's plans have been requested.",
    ])
    widths(ws4, {"A": 46, "B": 16, "C": 26, "D": 42, "E": 24, "F": 42, "G": 30, "H": 30})

    path = os.path.join(outdir, f"PBC-GC-01 Going concern assessment {ye:%Y-%m-%d}.xlsx")
    wb.save(path)

    exc = [
        {"desc": "forecast", "_seeded_exception":
         "EX-GC-01 assessment period covers less than twelve months from the date the "
         "financial statements are approved (SSA 570 para 13)"},
        {"desc": "covenant", "_seeded_exception":
         "EX-GC-02 covenant forecast to be breached within the assessment period"},
        {"desc": "covenant", "_seeded_exception":
         "EX-GC-03 tangible net worth covenant forecast to be breached - facility "
         "becomes repayable on demand"},
        {"desc": "facility", "_seeded_exception":
         "EX-GC-04 facility matures within the assessment period with no written "
         "renewal confirmation"},
        {"desc": "plans", "_seeded_exception":
         "EX-GC-05 forecast relies on uncommitted funding outside management's control"},
        {"desc": "plans", "_seeded_exception":
         "EX-GC-06 mitigating plan included in the forecast with no supporting evidence"},
        {"desc": "forecast", "_seeded_exception":
         "EX-GC-07 forecast shows negative liquidity headroom in at least one month "
         "before mitigating actions"},
        {"desc": "forecast", "_seeded_exception":
         "EX-GC-08 no downside or reverse stress-test scenario prepared"},
    ]
    return path, exc
