"""
build -- orchestrates generation of the full synthetic PBC pack for every
fictitious test client, plus a machine-readable manifest of the exceptions
that were deliberately planted (the expected-results file for regression tests).

Usage:
    python build.py [output_dir]
"""

import os
import sys
import json
import datetime as dt

from clients import CLIENTS
import gen_core as core
import gen_other as other
import gen_group as group
import gen_focus as focus
import gen_prov as prov

DISCLAIMER = (
    "SYNTHETIC TEST DATA. Every entity, person, bank account, reference number "
    "and amount in this pack is invented for software testing. Nothing here "
    "refers to any real organisation or individual."
)


def build_client(profile, root):
    outdir = os.path.join(root, profile.key)
    os.makedirs(outdir, exist_ok=True)
    ye = profile.year_end
    made, exceptions = [], []

    seen = set()

    def collect(recs, area):
        for rec in recs or []:
            ex = rec.get("_seeded_exception") if isinstance(rec, dict) else None
            if not ex:
                continue
            key = (rec.get("asset_id") or rec.get("inv_no")
                   or rec.get("item_code") or rec.get("doc_no")
                   or rec.get("id") or rec.get("facility")
                   or rec.get("desc") or rec.get("asset")
                   or rec.get("name") or rec.get("band")
                   or rec.get("counterparty"))
            sig = (area, ex, str(key))
            if sig in seen:
                continue
            seen.add(sig)
            exceptions.append({"client": profile.key, "area": area,
                               "exception": ex, "record_key": key})

    # ---- 1. PPE ------------------------------------------------------
    p, fa = core.write_fa_register(profile, outdir)
    made.append(p)
    collect(fa, "PPE")

    # ---- 2. Trial balance -------------------------------------------
    p, tb = core.write_trial_balance(profile, outdir, fa)
    made.append(p)

    # ---- 3. General ledger ------------------------------------------
    p, gl = core.write_general_ledger(profile, outdir, tb)
    made.append(p)

    def tb_amount(name):
        for x in tb:
            if x["name"].lower() == name.lower():
                return abs(x["amount"])
        return 0.0

    # ---- 4. Receivables ---------------------------------------------
    ps, ar = core.write_ar(profile, outdir, tb_amount("Trade receivables"))
    made += ps
    collect(ar, "Receivables")

    # ---- 5. Payables ------------------------------------------------
    ps, ap = core.write_ap(profile, outdir, tb_amount("Trade payables"))
    made += ps
    collect(ap, "Payables")

    # ---- 6. Inventory -----------------------------------------------
    inv_target = (tb_amount("Inventory - raw materials")
                  + tb_amount("Inventory - work in progress")
                  + tb_amount("Inventory - finished goods"))
    p, iv = core.write_inventory(profile, outdir, inv_target)
    made.append(p)
    collect(iv, "Inventory")

    # ---- 7. Cash and bank -------------------------------------------
    bank_accounts = [
        ("Operating account", tb_amount("Cash at bank - operating")),
        ("Collection account", tb_amount("Cash at bank - collection")),
        ("Fixed deposit", tb_amount("Fixed deposit")),
    ]
    ps, recon = other.write_bank_statements(profile, outdir, bank_accounts)
    made += ps

    # ---- 8. Payroll --------------------------------------------------
    p, pay, staff = other.write_payroll(profile, outdir, tb_amount("Salaries and wages"))
    made.append(p)
    collect(staff, "Payroll")

    # ---- 9. Revenue --------------------------------------------------
    rev_target = tb_amount("Revenue - product sales") + tb_amount("Revenue - services")
    p, rev = other.write_revenue(profile, outdir, rev_target)
    made.append(p)
    collect(rev, "Revenue")

    # ---- 10. Expenses ------------------------------------------------
    p, exp = other.write_expenses(profile, outdir, tb)
    made.append(p)
    collect(exp, "Expenses")

    # ---- 11. Borrowings ---------------------------------------------
    p, loans = other.write_loans(profile, outdir)
    made.append(p)
    collect(loans, "Borrowings")

    # ---- 11b. Provisions and contingencies (FRS 37) -----------------
    if profile.key in prov.TARGETS:
        p, provs = prov.write_provisions(profile, outdir)
        made.append(p)
        collect(provs, "Provisions")

    # ---- 12. Accruals and prepayments -------------------------------
    ps, accr, pre = other.write_accruals(profile, outdir)
    made += ps
    collect(accr, "Accruals")
    collect(pre, "Prepayments")

    # ---- 13. Leases --------------------------------------------------
    p, lse = other.write_leases(profile, outdir)
    made.append(p)
    collect(lse, "Leases")

    # ---- 14. Equity --------------------------------------------------
    made.append(other.write_equity(profile, outdir))

    # ---- 15. Partner-priority focus areas ----------------------------
    # FRS 36 impairment, FRS 109 ECL, and going concern. Produced for every
    # client: these are the three areas partners review most closely.
    p, cgus = focus.write_impairment_pack(profile, outdir)
    made.append(p)
    collect(cgus, "Impairment FRS 36")

    p, ecl = focus.write_ecl_pack(profile, outdir)
    made.append(p)
    collect(ecl, "ECL FRS 109")

    p, gc = focus.write_going_concern_pack(profile, outdir)
    made.append(p)
    collect(gc, "Going concern")

    # ---- 16. Group / PCAOB-only documents ----------------------------
    # Only produced for a multi-entity engagement (Firm 3 methodology).
    if getattr(profile, "multi_entity", False):
        p, _intercos = group.write_consolidation_tb(profile, outdir, tb)
        made.append(p)
        p, rp = group.write_rp_movement(profile, outdir)
        made.append(p)
        collect(rp, "Related parties")
        p, prc = group.write_prc_payroll(profile, outdir)
        made.append(p)
        collect(prc, "PRC payroll")
        made.append(group.write_nci_aoci(profile, outdir))

    # ---- README per client ------------------------------------------
    readme = os.path.join(outdir, "_README.txt")
    with open(readme, "w", encoding="utf-8") as fh:
        fh.write(f"{DISCLAIMER}\n\n")
        fh.write(f"Fictitious client : {profile.name}\n")
        fh.write(f"Industry          : {profile.industry}\n")
        fh.write(f"Accounting system : {profile.system}\n")
        fh.write(f"Financial year end: {ye:%d %B %Y}\n")
        fh.write(f"Functional currency: {profile.functional_ccy}\n")
        fh.write(f"Transaction currencies: {', '.join(profile.txn_ccys)}\n")
        fh.write(f"Account code style: {profile.coa_style}\n")
        fh.write(f"Heading vocabulary variant: {profile.variant}\n\n")
        fh.write("Files in this pack:\n")
        for m in sorted(made):
            fh.write(f"  - {os.path.basename(m)}\n")
    made.append(readme)
    return made, exceptions, recon


def main():
    root = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "out")
    os.makedirs(root, exist_ok=True)
    all_made, all_exc, summary = [], [], {}

    for key, profile in CLIENTS.items():
        made, exc, recon = build_client(profile, root)
        all_made += made
        all_exc += exc
        summary[key] = {
            "name": profile.name,
            "industry": profile.industry,
            "system": profile.system,
            "year_end": profile.year_end.isoformat(),
            "framework": profile.framework,
            "functional_currency": profile.functional_ccy,
            "heading_variant": profile.variant,
            "multi_entity": profile.multi_entity,
            "entities": len(profile.entities),
            "bilingual_headings": profile.bilingual,
            "files": len(made),
            "seeded_exceptions": len([e for e in exc if e["client"] == key]),
        }
        print(f"{key:12s} {profile.name:44s} {len(made):3d} files, "
              f"{len([e for e in exc if e['client']==key]):3d} seeded exceptions")

    manifest = {
        "disclaimer": DISCLAIMER,
        "generated_note": "Deterministic output: regenerating reproduces identical files.",
        "clients": summary,
        "seeded_exceptions": all_exc,
    }
    mp = os.path.join(root, "_expected-exceptions.json")
    with open(mp, "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, indent=2)

    with open(os.path.join(root, "_README.txt"), "w", encoding="utf-8") as fh:
        fh.write(DISCLAIMER + "\n\n")
        fh.write("Synthetic PBC test pack for the audit working papers platform.\n\n")
        fh.write("Each sub-folder is one fictitious client with a different accounting\n")
        fh.write("system, year end, currency profile, account coding scheme and column\n")
        fh.write("heading vocabulary. The same audit module must handle all of them\n")
        fh.write("without per-client code.\n\n")
        fh.write("_expected-exceptions.json lists the defects deliberately planted in\n")
        fh.write("the data. Use it as the assertion set for regression tests: an audit\n")
        fh.write("module is working when it finds these and does not invent others.\n\n")
        for k, v in summary.items():
            fh.write(f"{k}\n")
            for kk, vv in v.items():
                fh.write(f"    {kk:22s} {vv}\n")
            fh.write("\n")

    print(f"\nTotal: {len(all_made)} files, {len(all_exc)} seeded exceptions")
    print(f"Manifest: {mp}")


if __name__ == "__main__":
    main()
