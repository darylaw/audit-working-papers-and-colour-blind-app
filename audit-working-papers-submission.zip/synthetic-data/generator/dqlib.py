"""
dqlib -- Data-quality injection library for synthetic PBC (Prepared By Client) documents.

Every dataset produced by this package is FICTITIOUS. No entity, person, bank account,
registration number or address in the generated output refers to any real organisation
or individual. See ../README.md.

The library is deterministic: all randomness is seeded per (client, document) pair so
that regenerating produces byte-identical files and audit tests are reproducible.

DQ issue catalogue implemented here -- referenced by ID from the platform blueprint:

  DQ-01  Extra header / title rows above the real header row
  DQ-02  Blank rows (interspersed and trailing)
  DQ-03  Fully blank columns between populated columns
  DQ-04  Leading / trailing / doubled whitespace in text
  DQ-05  Mixed date formats within one column
  DQ-06  Mixed number formats (text numbers, thousands separators, () negatives,
         trailing minus, currency prefixes, blank vs zero)
  DQ-07  Inconsistent column headings between clients (synonym sets)
  DQ-08  Subtotal rows embedded in the detail
  DQ-09  Category carried as a group header row instead of a column value
  DQ-10  Duplicate records (exact and near-duplicate)
  DQ-11  Missing mandatory values
  DQ-12  Spelling / legal-suffix variants of the same counterparty
  DQ-13  Negative amounts where the sign is unexpected
  DQ-14  Reversed entries / contra pairs
  DQ-15  Unusual transactions (round sums, weekend postings, post-year-end dates)
  DQ-16  Formula cells mixed with hard-coded cells
  DQ-17  Merged cells in the header block
  DQ-18  Unpredictable / hidden worksheet names
  DQ-19  Casting differences (stated total != sum of detail)
  DQ-20  Mixed currencies in one amount column with no currency column
  DQ-21  Wrong data types (numbers and dates stored as text)
  DQ-22  Footnote / commentary rows below the data block
  DQ-23  Truncated counterparty names
  DQ-24  Inconsistent units (useful life in years vs months, UOM variants)
  DQ-25  Label / cross-reference copied from an unrelated schedule
"""

import random
import datetime as dt
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter

# --------------------------------------------------------------------------
# Determinism
# --------------------------------------------------------------------------

def rng(*parts):
    """Seeded RNG keyed on a stable string tuple."""
    return random.Random("|".join(str(p) for p in parts))


# --------------------------------------------------------------------------
# DQ-05 : date rendering variants
# --------------------------------------------------------------------------

DATE_STYLES = [
    "iso",          # 2023-07-14                (text)
    "dmy_slash",    # 14/07/2023                (text)
    "mdy_slash",    # 07/14/2023                (text, ambiguous!)
    "dmy_dot",      # 14.07.2023                (text)
    "dmy_dash",     # 14-Jul-2023               (text)
    "mon_yy",       # Jul-23                    (text, day lost)
    "year_only",    # 2023                      (int, day+month lost)
    "serial",       # 45121                     (Excel serial as int)
    "native",       # real datetime object
]

_EPOCH = dt.date(1899, 12, 30)


def render_date(d, style):
    """Render a date in one of the DATE_STYLES. Returns str, int or date."""
    if d is None:
        return None
    if style == "native":
        return d
    if style == "iso":
        return d.strftime("%Y-%m-%d")
    if style == "dmy_slash":
        return d.strftime("%d/%m/%Y")
    if style == "mdy_slash":
        return d.strftime("%m/%d/%Y")
    if style == "dmy_dot":
        return d.strftime("%d.%m.%Y")
    if style == "dmy_dash":
        return d.strftime("%d-%b-%Y")
    if style == "mon_yy":
        return d.strftime("%b-%y")
    if style == "year_only":
        return d.year
    if style == "serial":
        return (d - _EPOCH).days
    raise ValueError(style)


def mixed_dates(dates, r, primary="dmy_slash", contamination=0.12):
    """DQ-05: render a column of dates mostly in one style, with a minority in others."""
    others = [s for s in DATE_STYLES if s != primary]
    out = []
    for d in dates:
        if d is not None and r.random() < contamination:
            out.append(render_date(d, r.choice(others)))
        else:
            out.append(render_date(d, primary))
    return out


# --------------------------------------------------------------------------
# DQ-06 / DQ-21 : number rendering variants
# --------------------------------------------------------------------------

def render_number(v, style, cur=""):
    """Render a number as a value or as messy text."""
    if v is None:
        return None
    if style == "native":
        return round(float(v), 2)
    if style == "text":
        return f"{v:.2f}"
    if style == "thousands":
        return f"{v:,.2f}"
    if style == "paren_neg":
        return f"({abs(v):,.2f})" if v < 0 else f"{v:,.2f}"
    if style == "trailing_minus":
        return f"{abs(v):,.2f}-" if v < 0 else f"{v:,.2f}"
    if style == "currency":
        return f"{cur} {v:,.2f}"
    if style == "blank_zero":
        return None if abs(v) < 0.005 else round(float(v), 2)
    if style == "dash_zero":
        return "-" if abs(v) < 0.005 else round(float(v), 2)
    raise ValueError(style)


NUMBER_STYLES = ["native", "text", "thousands", "paren_neg",
                 "trailing_minus", "currency", "blank_zero", "dash_zero"]


def mixed_numbers(vals, r, primary="native", contamination=0.10, cur="SGD"):
    """DQ-06/DQ-21: mostly clean numbers with a minority stored as messy text."""
    others = [s for s in NUMBER_STYLES if s != primary]
    out = []
    for v in vals:
        if v is not None and r.random() < contamination:
            out.append(render_number(v, r.choice(others), cur))
        else:
            out.append(render_number(v, primary, cur))
    return out


# --------------------------------------------------------------------------
# DQ-04 / DQ-12 / DQ-23 : text noise
# --------------------------------------------------------------------------

SUFFIX_VARIANTS = ["Pte Ltd", "Pte. Ltd.", "PTE LTD", "PTE. LTD.",
                   "Pte Ltd.", "Private Limited"]


def suffix_variant(base, r):
    """DQ-12: same counterparty, different legal-suffix spelling."""
    return f"{base} {r.choice(SUFFIX_VARIANTS)}"


def whitespace_noise(s, r, p=0.15):
    """DQ-04: leading/trailing/doubled spaces."""
    if not isinstance(s, str) or r.random() > p:
        return s
    choice = r.randint(0, 3)
    if choice == 0:
        return " " + s
    if choice == 1:
        return s + "  "
    if choice == 2:
        return s.replace(" ", "  ", 1)
    return f" {s} "


def truncate(s, r, width=30, p=0.08):
    """DQ-23: master data truncated by the source system's field width."""
    if not isinstance(s, str) or len(s) <= width or r.random() > p:
        return s
    return s[:width]


def case_noise(s, r, p=0.08):
    """DQ-12: inconsistent casing for the same value."""
    if not isinstance(s, str) or r.random() > p:
        return s
    return s.upper() if r.random() < 0.5 else s.lower()


# --------------------------------------------------------------------------
# Sheet building
# --------------------------------------------------------------------------

THIN = Side(style="thin", color="999999")
HDR_FILL = PatternFill("solid", fgColor="D9E1F2")


class SheetBuilder:
    """Writes rows into an openpyxl worksheet, tracking the current row."""

    def __init__(self, ws, start_row=1):
        self.ws = ws
        self.row = start_row

    def blank(self, n=1):
        """DQ-02: blank row(s)."""
        self.row += n
        return self

    def raw(self, values, col=1, bold=False, italic=False, fill=False,
            border=False, number_format=None, align=None):
        for i, v in enumerate(values):
            if v is None:
                continue
            c = self.ws.cell(row=self.row, column=col + i, value=v)
            if bold or italic:
                c.font = Font(bold=bold, italic=italic)
            if fill:
                c.fill = HDR_FILL
            if border:
                c.border = Border(top=THIN, bottom=THIN, left=THIN, right=THIN)
            if number_format:
                c.number_format = number_format
            if align:
                c.alignment = Alignment(horizontal=align, wrap_text=True, vertical="center")
        self.row += 1
        return self

    def title_block(self, lines, merge_to=None):
        """DQ-01 + DQ-17: title rows above the real header, some merged."""
        for text, bold in lines:
            c = self.ws.cell(row=self.row, column=1, value=text)
            c.font = Font(bold=bold, size=11 if bold else 10)
            if merge_to:
                self.ws.merge_cells(start_row=self.row, start_column=1,
                                    end_row=self.row, end_column=merge_to)
                c.alignment = Alignment(horizontal="left")
            self.row += 1
        return self

    def header(self, cols, col=1):
        """DQ-07: whatever heading synonyms the caller passed in."""
        self.raw(cols, col=col, bold=True, fill=True, border=True, align="center")
        return self

    def formula(self, coord_col, first, last, label=None, label_col=1,
                bold=True, hardcoded=None):
        """
        DQ-16 / DQ-19: write a total row. `coord_col` is a list of
        (column_index, mode) where mode is 'sum' (live formula), or a literal value
        (hard-coded). `hardcoded` optionally offsets the value to create a casting
        difference.
        """
        if label:
            self.ws.cell(row=self.row, column=label_col, value=label).font = Font(bold=True)
        for ci, mode in coord_col:
            letter = get_column_letter(ci)
            if mode == "sum":
                v = f"=SUM({letter}{first}:{letter}{last})"
            else:
                v = mode
            c = self.ws.cell(row=self.row, column=ci, value=v)
            c.font = Font(bold=bold)
            c.border = Border(top=THIN, bottom=Side(style="double", color="999999"))
        self.row += 1
        return self

    def footnotes(self, notes):
        """DQ-22: commentary rows below the data block."""
        self.blank()
        for n in notes:
            self.ws.cell(row=self.row, column=1, value=n).font = Font(italic=True, size=9)
            self.row += 1
        return self


def widths(ws, spec):
    """spec: dict of column letter -> width."""
    for k, v in spec.items():
        ws.column_dimensions[k].width = v


def new_workbook(sheet_name):
    wb = Workbook()
    wb.remove(wb.active)
    ws = wb.create_sheet(sheet_name)
    return wb, ws


def add_decoy_sheets(wb, r, names, hidden_names=()):
    """DQ-18: extra and hidden worksheets with unpredictable names."""
    for n in names:
        ws = wb.create_sheet(n)
        ws["A1"] = "(working sheet retained by client)"
        ws["A1"].font = Font(italic=True, size=9)
    for n in hidden_names:
        ws = wb.create_sheet(n)
        ws["A1"] = "(superseded)"
        ws.sheet_state = "hidden"


# --------------------------------------------------------------------------
# DQ-08 / DQ-09 : subtotal and group-header row emission
# --------------------------------------------------------------------------

def emit_grouped(sb, groups, row_writer, group_header=True, subtotal=True,
                 subtotal_cols=None, subtotal_label="Sub-total",
                 blank_between=True):
    """
    Emit records grouped by category.

    groups: list of (category, [records])
    row_writer: fn(sb, record) -> None, writes one detail row
    group_header: DQ-09 -- write the category as a bold header row
    subtotal:     DQ-08 -- write a subtotal row after each group
    subtotal_cols: list of column indices to SUM
    """
    for cat, recs in groups:
        if group_header:
            sb.raw([cat], bold=True)
        first = sb.row
        for rec in recs:
            row_writer(sb, rec)
        last = sb.row - 1
        if subtotal and subtotal_cols and last >= first:
            sb.formula([(ci, "sum") for ci in subtotal_cols],
                       first, last, label=subtotal_label)
        if blank_between:
            sb.blank()


# --------------------------------------------------------------------------
# DQ-10 : duplicates
# --------------------------------------------------------------------------

def inject_duplicates(records, r, exact=1, near=1, near_field=None):
    """
    DQ-10: append exact duplicates and near-duplicates of existing records.
    Returns a new list; duplicates are inserted at plausible positions.
    """
    out = list(records)
    if not out:
        return out
    for _ in range(exact):
        src = r.choice(out)
        out.insert(r.randint(0, len(out)), dict(src))
    for _ in range(near):
        src = dict(r.choice(out))
        if near_field and near_field in src and isinstance(src[near_field], str):
            src[near_field] = src[near_field].rstrip(".") + "."
        out.insert(r.randint(0, len(out)), src)
    return out


# --------------------------------------------------------------------------
# DQ-11 : missing values
# --------------------------------------------------------------------------

def blank_out(records, r, fields, p=0.05):
    """DQ-11: null out mandatory fields at random."""
    for rec in records:
        for f in fields:
            if f in rec and r.random() < p:
                rec[f] = None
    return records


# --------------------------------------------------------------------------
# DQ-15 : unusual transaction helpers
# --------------------------------------------------------------------------

def is_weekend(d):
    return d.weekday() >= 5


def round_sum(amount, r, p=0.06):
    """DQ-15: suspiciously round amounts."""
    if r.random() < p:
        mag = 10 ** max(2, len(str(int(abs(amount)))) - 1)
        return float(round(amount / mag) * mag) or float(mag)
    return amount


def rand_date(r, start, end, weekend_bias=0.06):
    """Random date in [start, end]; occasionally forced onto a weekend (DQ-15)."""
    span = (end - start).days
    d = start + dt.timedelta(days=r.randint(0, max(span, 0)))
    if r.random() < weekend_bias:
        while not is_weekend(d):
            d += dt.timedelta(days=1)
            if d > end:
                d = end
                break
    return d
