"""
gen_other -- synthetic PBC generators for cash and bank, payroll, revenue,
expenses, borrowings, leases, accruals, prepayments and equity.

All output is FICTITIOUS test data with deliberately injected defects.
"""

import datetime as dt
import csv
import os

from dqlib import (rng, SheetBuilder, new_workbook, widths, add_decoy_sheets,
                   render_date, render_number, whitespace_noise, truncate,
                   case_noise, suffix_variant, inject_duplicates, rand_date,
                   round_sum)
from clients import (CUSTOMER_BASES, SUPPLIER_BASES, EMPLOYEE_NAMES,
                     DEPARTMENTS, BANKS)


# ==========================================================================
# Bank statement + bank reconciliation
# ==========================================================================

BANK_NARR_IN = ["Incoming TT", "Cheque deposit", "GIRO collection", "Customer payment",
                "Interest credit", "FX settlement", "Refund received"]
BANK_NARR_OUT = ["Cheque paid", "GIRO payment", "Outgoing TT", "Salary GIRO",
                 "CPF contribution", "Service charge", "Loan instalment",
                 "GST payment", "Utilities GIRO", "Card settlement"]


def write_bank_statements(profile, outdir, closing_balances):
    """
    One statement per bank account. Statements are month-blocked with running
    balances -- and the last three months carry unpresented cheques and
    deposits in transit so a reconciliation is genuinely required.

    closing_balances: list of (account_label, ledger_balance)
    Returns (paths, {account_label: statement_closing_balance})
    """
    r = rng(profile.key, "bank")
    P, ye, fys = profile, profile.year_end, profile.fy_start
    paths, stmt_closing = [], {}

    for idx, (label, ledger_bal) in enumerate(closing_balances):
        bank_name, bank_code = BANKS[idx % len(BANKS)]
        acct_no = f"{100 + idx*37:03d}-{200000 + idx*4111:06d}-{idx%9}"

        # Unreconciled items sit between the ledger and the statement
        unpresented = round(r.uniform(3_000, 42_000), 2) if idx < 2 else 0.0
        in_transit = round(r.uniform(1_500, 28_000), 2) if idx == 0 else 0.0
        bank_bal = round(ledger_bal + unpresented - in_transit, 2)
        stmt_closing[label] = {"bank_balance": bank_bal,
                               "unpresented_cheques": unpresented,
                               "deposits_in_transit": in_transit,
                               "ledger_balance": ledger_bal,
                               "bank": bank_name, "account_no": acct_no}

        # Build a full year of transactions ending on bank_bal
        txns = []
        d = fys
        while d <= ye:
            for _ in range(r.randint(0, 6)):
                td = rand_date(r, d, min(d + dt.timedelta(days=27), ye),
                               weekend_bias=0.02)
                if r.random() < 0.46:
                    amt = round(r.uniform(200, 78_000), 2)
                    txns.append({"date": td, "narr": r.choice(BANK_NARR_IN),
                                 "dr": None, "cr": amt})
                else:
                    amt = round(r.uniform(80, 62_000), 2)
                    txns.append({"date": td, "narr": r.choice(BANK_NARR_OUT),
                                 "dr": amt, "cr": None})
            d += dt.timedelta(days=28)
        txns.sort(key=lambda x: x["date"])

        net = sum((x["cr"] or 0) - (x["dr"] or 0) for x in txns)
        opening = round(bank_bal - net, 2)

        # DQ-15: seed audit-relevant items
        if txns:
            txns[r.randint(0, len(txns) - 1)]["narr"] = (
                f"TT to related party - {P.short} Holdings")
            txns[r.randint(0, len(txns) - 1)]["narr"] = "Cheque paid - director reimbursement"
            k = r.randint(0, len(txns) - 1)
            txns[k]["dr"] = 100_000.00
            txns[k]["cr"] = None
            txns[k]["narr"] = "Outgoing TT - unidentified beneficiary"

        # --- write it -------------------------------------------------
        if P.variant == 1:
            # CSV download from internet banking
            path = os.path.join(
                outdir, f"PBC-BANK-{idx+1:02d} Bank statement {label} {ye:%Y-%m}.csv")
            with open(path, "w", newline="", encoding="utf-8-sig") as fh:
                w = csv.writer(fh)
                w.writerow([bank_name])
                w.writerow([f"Account: {acct_no}", f"Currency: {P.functional_ccy}"])
                w.writerow([f"Statement period: {fys:%d/%m/%Y} - {ye:%d/%m/%Y}"])
                w.writerow([])
                w.writerow([P.h("bank.stmt_date"), P.h("bank.narrative"),
                            P.h("bank.debit"), P.h("bank.credit"),
                            P.h("bank.balance")])
                bal = opening
                w.writerow([render_date(fys - dt.timedelta(days=1), "dmy_slash"),
                            "OPENING BALANCE", "", "", f"{bal:.2f}"])
                for x in txns:
                    bal = round(bal + (x["cr"] or 0) - (x["dr"] or 0), 2)
                    w.writerow([render_date(x["date"], "dmy_slash"), x["narr"],
                                f"{x['dr']:.2f}" if x["dr"] else "",
                                f"{x['cr']:.2f}" if x["cr"] else "",
                                f"{bal:.2f}"])
                w.writerow([render_date(ye, "dmy_slash"), "CLOSING BALANCE", "", "",
                            f"{bal:.2f}"])
            paths.append(path)
            continue

        wb, ws = new_workbook("Statement")
        sb = SheetBuilder(ws)
        sb.title_block([(bank_name.upper(), True),
                        (f"Account {acct_no}  ({label})", False),
                        (f"Statement of account  {fys:%d %b %Y} to {ye:%d %b %Y}", False),
                        (f"All amounts in {P.functional_ccy}", False)], merge_to=5)
        sb.blank()
        first = sb.row + 1
        sb.header([P.h("bank.stmt_date"), P.h("bank.narrative"), P.h("bank.debit"),
                   P.h("bank.credit"), P.h("bank.balance")])
        bal = opening
        sb.raw([render_date(fys - dt.timedelta(days=1), "native"),
                "BALANCE BROUGHT FORWARD", None, None, opening], bold=True)
        for x in txns:
            bal = round(bal + (x["cr"] or 0) - (x["dr"] or 0), 2)
            dv = (render_date(x["date"], r.choice(["dmy_dash", "iso", "dmy_slash"]))
                  if r.random() < P.dq["date_contam"] else x["date"])
            sb.raw([dv, whitespace_noise(x["narr"], r),
                    render_number(x["dr"], "native") if x["dr"] else None,
                    render_number(x["cr"], "native") if x["cr"] else None,
                    bal])
        last = sb.row - 1
        sb.raw([render_date(ye, "native"), "BALANCE CARRIED FORWARD", None, None, bal],
               bold=True)
        widths(ws, {"A": 14, "B": 52, "C": 16, "D": 16, "E": 18})
        path = os.path.join(
            outdir, f"PBC-BANK-{idx+1:02d} Bank statement {label} {ye:%Y-%m}.xlsx")
        wb.save(path)
        paths.append(path)

    # ---- client-prepared bank reconciliation -------------------------
    wb, ws = new_workbook("Bank Recon")
    sb = SheetBuilder(ws)
    sb.title_block([(P.name.upper(), True),
                    ("BANK RECONCILIATION", True),
                    (f"As at {ye:%d %B %Y}", False)], merge_to=5)
    sb.blank()
    for label, info in stmt_closing.items():
        sb.raw([f"{info['bank']} - {label}  (A/C {info['account_no']})"], bold=True)
        r0 = sb.row
        sb.raw(["Balance per bank statement", None, info["bank_balance"]])
        sb.raw(["Less: unpresented cheques", None,
                -info["unpresented_cheques"] if info["unpresented_cheques"] else None])
        sb.raw(["Add: deposits in transit", None,
                info["deposits_in_transit"] if info["deposits_in_transit"] else None])
        r1 = sb.row - 1
        sb.formula([(3, "sum")], r0, r1, label="Balance per general ledger")
        # DQ-19: one account is left with an unexplained difference
        if label.endswith("USD") or label.endswith("collection"):
            sb.raw(["Unexplained difference", None, round(148.20, 2)], italic=True)
        sb.blank()
    sb.footnotes(["Prepared by the accounts department. Reviewed monthly by the Finance Manager.",
                  "Cheques unpresented for more than six months are written back."])
    widths(ws, {"A": 48, "B": 6, "C": 18})
    p = os.path.join(outdir, f"PBC-BANK-90 Bank reconciliation {ye:%Y-%m-%d}.xlsx")
    wb.save(p)
    paths.append(p)
    return paths, stmt_closing


# ==========================================================================
# Payroll listing
# ==========================================================================

def write_payroll(profile, outdir, annual_gross):
    """
    Twelve-month payroll listing by employee. Includes joiners, leavers,
    a duplicated employee, a payment after the leaving date and a nil-CPF
    employee -- all standard payroll audit exceptions.
    """
    r = rng(profile.key, "pay")
    P, ye, fys = profile, profile.year_end, profile.fy_start
    months = []
    d = dt.date(fys.year, fys.month, 1)
    for _ in range(12):
        months.append(d)
        d = (d.replace(day=28) + dt.timedelta(days=8)).replace(day=1)

    staff = []
    for i, nm in enumerate(EMPLOYEE_NAMES[:18]):
        join = (fys - dt.timedelta(days=r.randint(30, 2600))
                if r.random() > 0.2 else rand_date(r, fys, ye - dt.timedelta(days=60)))
        leave = None
        if r.random() < 0.18:
            leave = rand_date(r, max(join, fys) + dt.timedelta(days=45), ye)
        staff.append({"id": f"E{i+1:04d}", "name": nm,
                      "dept": r.choice(DEPARTMENTS),
                      "basic": round(r.uniform(2_400, 11_500), 2),
                      "allow": round(r.uniform(0, 1_600), 2),
                      "join": join, "leave": leave,
                      "_seeded_exception": None})

    # Seeded exceptions
    staff[2]["_seeded_exception"] = "EX-PAY-01 payment after leaving date"
    staff[2]["leave"] = ye - dt.timedelta(days=120)
    staff[5]["_seeded_exception"] = "EX-PAY-02 nil employer statutory contribution"
    staff[7]["_seeded_exception"] = "EX-PAY-03 salary increase above 40% year on year"
    dupe = dict(staff[9])
    dupe["id"] = staff[9]["id"] + "B"
    dupe["_seeded_exception"] = "EX-PAY-04 duplicate employee (same name, two IDs)"
    staff.append(dupe)
    ghost = {"id": "E9999", "name": "  ", "dept": None,
             "basic": 4_800.0, "allow": 0.0, "join": fys, "leave": None,
             "_seeded_exception": "EX-PAY-05 employee with no name recorded"}
    staff.append(ghost)

    rows = []
    for s in staff:
        for mi, m in enumerate(months):
            active = True
            if s["join"] and m < s["join"].replace(day=1):
                active = False
            if s["leave"] and m > s["leave"].replace(day=1):
                # EX-PAY-01: keep paying one leaver
                active = s["_seeded_exception"] == "EX-PAY-01 payment after leaving date"
            if not active:
                continue
            basic = s["basic"]
            if s["_seeded_exception"] == "EX-PAY-03 salary increase above 40% year on year" and mi >= 6:
                basic = round(basic * 1.52, 2)
            allow = s["allow"]
            bonus = round(basic * r.uniform(0.8, 1.6), 2) if mi == 11 else 0.0
            er_cpf = 0.0 if s["_seeded_exception"] == "EX-PAY-02 nil employer statutory contribution" \
                else round(min(basic, 6_800) * 0.17, 2)
            ee_cpf = round(min(basic, 6_800) * 0.20, 2)
            gross = round(basic + allow + bonus, 2)
            rows.append({"id": s["id"], "name": s["name"], "dept": s["dept"],
                         "month": m, "basic": basic, "allow": allow, "bonus": bonus,
                         "er_cpf": er_cpf, "ee_cpf": ee_cpf, "gross": gross,
                         "net": round(gross - ee_cpf, 2),
                         "join": s["join"], "leave": s["leave"]})

    wb, ws = new_workbook("Payroll" if P.variant == 0 else "Sheet1")
    sb = SheetBuilder(ws)
    sb.title_block([(P.name.upper(), True),
                    ("PAYROLL SUMMARY BY EMPLOYEE AND MONTH", True),
                    (f"Financial year {fys:%d/%m/%Y} to {ye:%d/%m/%Y}", False),
                    ("CONFIDENTIAL", False)][:max(2, P.dq["extra_headers"])],
                   merge_to=11)
    sb.blank()
    cols = [P.h("pay.employee_id"), P.h("pay.employee_name"), P.h("pay.department"),
            "Month", P.h("pay.gross"), P.h("pay.allowances"), P.h("pay.bonus"),
            P.h("pay.employer_cpf"), P.h("pay.employee_cpf"), P.h("pay.net"),
            P.h("pay.join_date"), P.h("pay.leave_date")]
    first = sb.row + 1
    sb.header(cols)
    dprim = P.date_style
    money = ["basic", "allow", "bonus", "er_cpf", "ee_cpf", "net"]
    for x in rows:
        if r.random() < P.dq["blank_row_p"] * 0.4:
            sb.blank()
        vals = [x["id"], whitespace_noise(x["name"], r), x["dept"],
                render_date(x["month"], dprim)]
        for f in money:
            v = x[f]
            vals.append(render_number(v, r.choice(["text", "thousands", "dash_zero"]))
                        if r.random() < P.dq["num_contam"] else render_number(v, "native"))
        vals.append(render_date(x["join"], "dmy_slash") if x["join"] else None)
        vals.append(render_date(x["leave"], "dmy_slash") if x["leave"] else None)
        sb.raw(vals)
    last = sb.row - 1
    sb.blank()
    sb.formula([(c, "sum") for c in range(5, 11)], first, last, label="TOTAL")
    if P.dq["footnotes"]:
        sb.footnotes(["Bonus paid in the final month of the financial year.",
                      "Employer statutory contributions are capped at the prevailing ceiling."])
    widths(ws, {"A": 12, "B": 28, "C": 20, "D": 12, "E": 14, "F": 14, "G": 14,
                "H": 14, "I": 14, "J": 14, "K": 14, "L": 14})
    path = os.path.join(outdir, f"PBC-PAY-01 Payroll listing {ye:%Y-%m-%d}.xlsx")
    wb.save(path)
    # Return the employee master as well -- the seeded exceptions live there.
    return path, rows, staff


# ==========================================================================
# Revenue listing (sales invoice register)
# ==========================================================================

def write_revenue(profile, outdir, target_net):
    r = rng(profile.key, "rev")
    P, ye, fys = profile, profile.year_end, profile.fy_start
    products = ["Precision stamping", "Sheet metal fabrication", "Tooling design",
                "Assembly service", "Material supply - steel",
                "Material supply - copper", "Freight recharge", "Engineering hours"]
    segs = ["Domestic", "Export - ASEAN", "Export - North Asia", "Intercompany"]

    recs, running, no = [], 0.0, 500_000
    while running < target_net:
        no += r.randint(1, 3)
        d = rand_date(r, fys, ye, weekend_bias=0.05)
        qty = round(r.uniform(1, 3_000), 0)
        price = round(r.uniform(0.8, 340.0), 2)
        net = round(qty * price, 2)
        net = round_sum(net, r, p=0.04)
        if running + net > target_net:
            net = round(target_net - running, 2)
            if net <= 0:
                break
        running += net
        tax = round(net * 0.09, 2) if r.random() < 0.55 else 0.0
        recs.append({"doc_no": f"SI-{no}", "doc_date": d,
                     "customer": suffix_variant(r.choice(CUSTOMER_BASES), r),
                     "product": r.choice(products), "qty": qty, "price": price,
                     "net": net, "tax": tax, "gross": round(net + tax, 2),
                     "do_date": d - dt.timedelta(days=r.randint(0, 6)),
                     "segment": r.choice(segs), "_seeded_exception": None})

    picks = r.sample(range(len(recs)), 9)
    # Invoice dated after year end but included in revenue
    recs[picks[0]]["doc_date"] = ye + dt.timedelta(days=r.randint(1, 12))
    recs[picks[0]]["_seeded_exception"] = "EX-REV-01 invoice dated after year end included in revenue"
    # Delivery after year end, invoice before -- cut-off
    recs[picks[1]]["do_date"] = ye + dt.timedelta(days=r.randint(2, 15))
    recs[picks[1]]["doc_date"] = ye - dt.timedelta(days=3)
    recs[picks[1]]["_seeded_exception"] = "EX-REV-02 goods delivered after year end (cut-off)"
    # Credit note reversing a sale shortly after year end
    src = dict(recs[picks[2]])
    src["doc_no"] = "CN-" + src["doc_no"]
    src["net"] = -src["net"]
    src["tax"] = -src["tax"]
    src["gross"] = -src["gross"]
    src["doc_date"] = ye + dt.timedelta(days=r.randint(4, 30))
    src["_seeded_exception"] = "EX-REV-03 post year-end credit note reversing recognised revenue"
    recs.append(src)
    # Extension error
    recs[picks[3]]["net"] = round(recs[picks[3]]["qty"] * recs[picks[3]]["price"] * 1.22, 2)
    recs[picks[3]]["_seeded_exception"] = "EX-REV-04 extension error (qty x price <> amount)"
    # GST not charged on a domestic sale
    recs[picks[4]]["segment"] = "Domestic"
    recs[picks[4]]["tax"] = 0.0
    recs[picks[4]]["gross"] = recs[picks[4]]["net"]
    recs[picks[4]]["_seeded_exception"] = "EX-REV-05 no output tax on domestic sale"
    # Duplicate invoice number
    dup = dict(recs[picks[5]])
    dup["_seeded_exception"] = "EX-REV-06 duplicate invoice number"
    recs.append(dup)
    # Very large round-sum invoice at year end
    recs[picks[6]]["net"] = 750_000.00
    recs[picks[6]]["doc_date"] = ye - dt.timedelta(days=1)
    recs[picks[6]]["_seeded_exception"] = "EX-REV-07 large round-sum sale immediately before year end"
    # Negative price
    recs[picks[7]]["price"] = -abs(recs[picks[7]]["price"])
    recs[picks[7]]["_seeded_exception"] = "EX-REV-08 negative unit price"
    # Missing customer
    recs[picks[8]]["customer"] = None
    recs[picks[8]]["_seeded_exception"] = "EX-REV-09 missing customer on sales invoice"

    recs.sort(key=lambda x: x["doc_date"])
    recs = inject_duplicates(recs, r, P.dq["dup_exact"], P.dq["dup_near"], "customer")

    if P.variant == 1:
        path = os.path.join(outdir, f"PBC-REV-01 Sales listing {ye:%Y-%m-%d}.csv")
        with open(path, "w", newline="", encoding="utf-8-sig") as fh:
            w = csv.writer(fh)
            w.writerow([f"{P.name} - Sales Invoice Register"])
            w.writerow([f"{fys:%d/%m/%Y} to {ye:%d/%m/%Y}"])
            w.writerow([])
            w.writerow([P.h("rev.doc_no"), P.h("rev.doc_date"), P.h("rev.customer"),
                        P.h("rev.product"), P.h("rev.qty"), P.h("rev.unit_price"),
                        P.h("rev.net_amount"), P.h("rev.tax"), P.h("rev.gross_amount"),
                        P.h("rev.do_date"), P.h("rev.segment")])
            for x in recs:
                w.writerow([x["doc_no"], render_date(x["doc_date"], "dmy_dot"),
                            x["customer"] or "", x["product"], x["qty"],
                            f"{x['price']:.2f}", f"{x['net']:.2f}",
                            f"{x['tax']:.2f}", f"{x['gross']:.2f}",
                            render_date(x["do_date"], "dmy_dot"), x["segment"]])
        return path, recs

    wb, ws = new_workbook("Sales" if P.variant == 0 else "Sheet1")
    sb = SheetBuilder(ws)
    sb.title_block([(P.name.upper(), True),
                    ("SALES INVOICE REGISTER", True),
                    (f"{fys:%d %b %Y} to {ye:%d %b %Y}", False)][:max(2, P.dq["extra_headers"])],
                   merge_to=11)
    sb.blank()
    first = sb.row + 1
    sb.header([P.h("rev.doc_no"), P.h("rev.doc_date"), P.h("rev.customer"),
               P.h("rev.product"), P.h("rev.qty"), P.h("rev.unit_price"),
               P.h("rev.net_amount"), P.h("rev.tax"), P.h("rev.gross_amount"),
               P.h("rev.do_date"), P.h("rev.segment")])
    dprim = P.date_style
    for x in recs:
        if r.random() < P.dq["blank_row_p"] * 0.5:
            sb.blank()
        sb.raw([x["doc_no"],
                render_date(x["doc_date"], r.choice(["iso", "mdy_slash", "serial"]))
                if r.random() < P.dq["date_contam"] else render_date(x["doc_date"], dprim),
                whitespace_noise(truncate(x["customer"], r, 34), r) if x["customer"] else None,
                x["product"], x["qty"],
                render_number(x["price"], "native"),
                render_number(x["net"], r.choice(["thousands", "text"]))
                if r.random() < P.dq["num_contam"] else render_number(x["net"], "native"),
                render_number(x["tax"], "blank_zero"),
                render_number(x["gross"], "native"),
                render_date(x["do_date"], dprim), x["segment"]])
    last = sb.row - 1
    sb.blank()
    sb.formula([(7, "sum"), (8, "sum"), (9, "sum")], first, last, label="TOTAL")
    widths(ws, {"A": 14, "B": 13, "C": 40, "D": 26, "E": 10, "F": 12, "G": 16,
                "H": 12, "I": 16, "J": 13, "K": 20})
    path = os.path.join(outdir, f"PBC-REV-01 Sales listing {ye:%Y-%m-%d}.xlsx")
    wb.save(path)
    return path, recs


# ==========================================================================
# Expense listing
# ==========================================================================

def write_expenses(profile, outdir, tb_rows):
    """Expense transaction listing across the P&L expense accounts."""
    r = rng(profile.key, "exp")
    P, ye, fys = profile, profile.year_end, profile.fy_start
    exp_accts = [x for x in tb_rows
                 if x["section"] == "PL" and x["amount"] > 0
                 and not x["name"].startswith("Sales returns")]
    recs, no = [], 300_000
    for acct in exp_accts:
        remaining = acct["amount"]
        n = max(1, min(40, int(remaining / max(remaining / 12, 1))))
        for i in range(n):
            no += 1
            amt = round(remaining / n, 2) if i < n - 1 else round(
                remaining - round(remaining / n, 2) * (n - 1), 2)
            amt = round(amt * r.uniform(0.55, 1.45), 2)
            d = rand_date(r, fys, ye, weekend_bias=0.05)
            recs.append({"doc_no": f"PI-{no}", "doc_date": d,
                         "supplier": suffix_variant(r.choice(SUPPLIER_BASES), r),
                         "code": acct["code"], "name": acct["name"],
                         "amount": amt, "_seeded_exception": None})

    picks = r.sample(range(len(recs)), 7)
    recs[picks[0]]["doc_date"] = ye + dt.timedelta(days=r.randint(2, 20))
    recs[picks[0]]["_seeded_exception"] = "EX-EXP-01 expense dated after year end"
    recs[picks[1]]["amount"] = -abs(recs[picks[1]]["amount"])
    recs[picks[1]]["_seeded_exception"] = "EX-EXP-02 credit posting in expense listing"
    dup = dict(recs[picks[2]])
    dup["_seeded_exception"] = "EX-EXP-03 duplicate supplier invoice"
    recs.append(dup)
    recs[picks[3]]["amount"] = 200_000.00
    recs[picks[3]]["_seeded_exception"] = "EX-EXP-04 round-sum expense above materiality"
    recs[picks[4]]["supplier"] = None
    recs[picks[4]]["_seeded_exception"] = "EX-EXP-05 missing payee"
    recs[picks[5]]["name"] = "Repairs and maintenance"
    recs[picks[5]]["amount"] = 84_600.00
    recs[picks[5]]["_seeded_exception"] = "EX-EXP-06 possible capital item expensed"
    recs[picks[6]]["doc_date"] = fys - dt.timedelta(days=r.randint(5, 60))
    recs[picks[6]]["_seeded_exception"] = "EX-EXP-07 expense dated in prior period"

    recs.sort(key=lambda x: x["doc_date"])
    wb, ws = new_workbook("Expenses" if P.variant == 0 else "Sheet1")
    sb = SheetBuilder(ws)
    sb.title_block([(P.name.upper(), True), ("EXPENSE TRANSACTION LISTING", True),
                    (f"{fys:%d %b %Y} to {ye:%d %b %Y}", False)][:max(2, P.dq["extra_headers"])],
                   merge_to=6)
    sb.blank()
    first = sb.row + 1
    sb.header([P.h("exp.doc_no"), P.h("exp.doc_date"), P.h("exp.supplier"),
               P.h("exp.account_code"), P.h("exp.account_name"), P.h("exp.amount")])
    dprim = P.date_style
    for x in recs:
        if r.random() < P.dq["blank_row_p"] * 0.4:
            sb.blank()
        sb.raw([x["doc_no"],
                render_date(x["doc_date"], r.choice(["iso", "mdy_slash", "mon_yy"]))
                if r.random() < P.dq["date_contam"] else render_date(x["doc_date"], dprim),
                whitespace_noise(x["supplier"], r) if x["supplier"] else None,
                x["code"], x["name"],
                render_number(x["amount"], r.choice(["paren_neg", "thousands", "text"]))
                if r.random() < P.dq["num_contam"] else render_number(x["amount"], "native")])
    last = sb.row - 1
    sb.blank()
    sb.formula([(6, "sum")], first, last, label="TOTAL")
    widths(ws, {"A": 14, "B": 13, "C": 42, "D": 12, "E": 44, "F": 16})
    path = os.path.join(outdir, f"PBC-EXP-01 Expense listing {ye:%Y-%m-%d}.xlsx")
    wb.save(path)
    return path, recs


# ==========================================================================
# Loan / borrowings schedule
# ==========================================================================

def write_loans(profile, outdir):
    r = rng(profile.key, "loan")
    P, ye, fys = profile, profile.year_end, profile.fy_start
    facilities = [
        ("Term loan - equipment", 480_000, 4.85, 60),
        ("Working capital facility", 300_000, 6.25, 36),
        ("Property mortgage", 1_200_000, 3.95, 180),
        ("Bridging loan", 250_000, 5.50, 48),
    ][: 4 if P.variant == 1 else 2]

    recs = []
    for i, (nm, principal, rate, tenor) in enumerate(facilities):
        bank, _ = BANKS[i % len(BANKS)]
        start = fys - dt.timedelta(days=r.randint(200, 1_500))
        inst = round(principal * (rate / 100 / 12) /
                     (1 - (1 + rate / 100 / 12) ** -tenor), 2)
        months_elapsed = max(0, (fys.year - start.year) * 12 + fys.month - start.month)
        bal_open = principal
        for _ in range(months_elapsed):
            interest = bal_open * rate / 100 / 12
            bal_open = max(0.0, bal_open - (inst - interest))
        interest_yr, repaid_yr, bal = 0.0, 0.0, bal_open
        for _ in range(12):
            if bal <= 0:
                break
            iv = bal * rate / 100 / 12
            pv = min(bal, inst - iv)
            interest_yr += iv
            repaid_yr += pv
            bal -= pv
        # 12 months of principal falling due next year = current portion
        cur, b2 = 0.0, bal
        for _ in range(12):
            if b2 <= 0:
                break
            iv = b2 * rate / 100 / 12
            pv = min(b2, inst - iv)
            cur += pv
            b2 -= pv
        recs.append({"facility": nm, "lender": bank,
                     "account_no": f"{500+i*13}-{i}{r.randint(100000,999999)}",
                     "principal": principal, "rate": rate, "start": start,
                     "tenor": tenor, "instalment": inst,
                     "bal_open": round(bal_open, 2), "repaid": round(repaid_yr, 2),
                     "interest": round(interest_yr, 2), "bal_close": round(bal, 2),
                     "current": round(min(cur, bal), 2),
                     "noncurrent": round(max(0.0, bal - cur), 2),
                     "_seeded_exception": None})

    if recs:
        # EX: closing balance does not equal opening less repayments
        recs[0]["bal_close"] = round(recs[0]["bal_close"] + 2_400.00, 2)
        recs[0]["_seeded_exception"] = "EX-LOAN-01 movement does not reconcile to closing balance"
    if len(recs) > 1:
        # EX: current + non-current split does not agree to closing balance
        recs[1]["current"] = round(recs[1]["current"] + 5_000.00, 2)
        recs[1]["_seeded_exception"] = "EX-LOAN-02 current / non-current split does not cast"
    if len(recs) > 2:
        recs[2]["interest"] = round(recs[2]["interest"] * 1.6, 2)
        recs[2]["_seeded_exception"] = "EX-LOAN-03 interest charged inconsistent with stated rate"

    wb, ws = new_workbook("Loan Schedule")
    sb = SheetBuilder(ws)
    sb.title_block([(P.name.upper(), True), ("SCHEDULE OF BORROWINGS", True),
                    (f"As at {ye:%d %B %Y}", False)], merge_to=8)
    sb.blank()
    first = sb.row + 1
    sb.header([P.h("loan.facility"), P.h("loan.lender"), P.h("loan.account_no"),
               P.h("loan.principal"), P.h("loan.rate"), P.h("loan.start"),
               P.h("loan.tenor"), P.h("loan.instalment"), P.h("loan.bal_open"),
               P.h("loan.repaid"), P.h("loan.interest"), P.h("loan.bal_close"),
               P.h("loan.current"), P.h("loan.noncurrent")])
    for x in recs:
        sb.raw([x["facility"], x["lender"], x["account_no"],
                x["principal"],
                render_number(x["rate"], "native"),
                render_date(x["start"], "dmy_slash"),
                x["tenor"], x["instalment"], x["bal_open"], -x["repaid"],
                x["interest"], x["bal_close"], x["current"], x["noncurrent"]])
    last = sb.row - 1
    sb.blank()
    sb.formula([(c, "sum") for c in (9, 10, 11, 12, 13, 14)], first, last, label="TOTAL")
    sb.footnotes(["Facilities are secured by a first legal mortgage over the leasehold property",
                  "and a corporate guarantee from the immediate holding company.",
                  "Interest is charged monthly in arrears on the reducing balance."])
    widths(ws, {"A": 30, "B": 28, "C": 20, "D": 14, "E": 10, "F": 13, "G": 10,
                "H": 14, "I": 16, "J": 14, "K": 14, "L": 16, "M": 14, "N": 16})
    path = os.path.join(outdir, f"PBC-LOAN-01 Loan schedule {ye:%Y-%m-%d}.xlsx")
    wb.save(path)
    return path, recs


# ==========================================================================
# Accruals and prepayments schedules
# ==========================================================================

ACCRUAL_ITEMS = [
    ("Audit fee", 24_000), ("Bonus provision", 148_000), ("Utilities", 18_400),
    ("Professional fees", 26_500), ("Freight", 34_200), ("Subcontract works", 96_800),
    ("Staff leave provision", 42_600), ("Interest payable", 8_400),
    ("Directors' fees", 36_000), ("Repairs", 14_800), ("Commission payable", 22_400),
]

PREPAID_ITEMS = [
    ("Insurance - general", 41_620, 12), ("Insurance - work injury", 12_400, 12),
    ("Software subscription", 28_800, 12), ("Property tax", 9_600, 12),
    ("Maintenance contract", 18_000, 24), ("Trade subscription", 3_600, 12),
    ("Rental deposit amortisation", 6_000, 36), ("Advertising retainer", 14_400, 6),
]


def write_accruals(profile, outdir):
    r = rng(profile.key, "accr")
    P, ye = profile, profile.year_end
    recs = []
    for nm, amt in ACCRUAL_ITEMS:
        op = round(amt * r.uniform(0.6, 1.3), 2)
        charge = round(amt * r.uniform(0.85, 1.2), 2)
        util = round(op * r.uniform(0.7, 1.05), 2)
        recs.append({"desc": nm, "code": "2025", "bal_open": op, "charge": charge,
                     "utilised": -util, "bal_close": round(op + charge - util, 2),
                     "_seeded_exception": None})
    recs[0]["bal_close"] = round(recs[0]["bal_close"] + 1_200.00, 2)
    recs[0]["_seeded_exception"] = "EX-ACC-01 accrual movement does not cast"
    recs[1]["utilised"] = 0.0
    recs[1]["bal_close"] = round(recs[1]["bal_open"] + recs[1]["charge"], 2)
    recs[1]["_seeded_exception"] = "EX-ACC-02 prior year accrual not utilised or released"
    recs[3]["bal_close"] = -abs(recs[3]["bal_close"])
    recs[3]["_seeded_exception"] = "EX-ACC-03 negative (debit) accrual balance"

    wb, ws = new_workbook("Accruals")
    sb = SheetBuilder(ws)
    sb.title_block([(P.name.upper(), True), ("SCHEDULE OF ACCRUALS", True),
                    (f"As at {ye:%d %B %Y}", False)], merge_to=6)
    sb.blank()
    first = sb.row + 1
    sb.header([P.h("acc.description"), P.h("acc.account_code"), P.h("acc.bal_open"),
               P.h("acc.charge"), P.h("acc.utilised"), P.h("acc.bal_close")])
    for x in recs:
        sb.raw([x["desc"], x["code"], x["bal_open"], x["charge"], x["utilised"],
                x["bal_close"]])
    last = sb.row - 1
    sb.blank()
    sb.formula([(c, "sum") for c in (3, 4, 5, 6)], first, last, label="TOTAL")
    widths(ws, {"A": 34, "B": 10, "C": 16, "D": 16, "E": 16, "F": 16})
    p1 = os.path.join(outdir, f"PBC-ACC-01 Accruals schedule {ye:%Y-%m-%d}.xlsx")
    wb.save(p1)

    # ---- prepayments -------------------------------------------------
    pre = []
    for nm, amt, months in PREPAID_ITEMS:
        start = ye - dt.timedelta(days=r.randint(30, 400))
        end = start + dt.timedelta(days=int(months * 30.44))
        elapsed = max(0, min(months, (ye - start).days / 30.44))
        expensed = round(amt * elapsed / months, 2)
        pre.append({"desc": nm, "paid": amt, "from": start, "to": end,
                    "months": months, "expensed": expensed,
                    "bal_close": round(amt - expensed, 2), "_seeded_exception": None})
    pre[0]["bal_close"] = round(pre[0]["paid"] - pre[0]["expensed"] * 0.5, 2)
    pre[0]["_seeded_exception"] = "EX-PRE-01 prepayment under-amortised"
    pre[2]["to"] = ye - dt.timedelta(days=60)
    pre[2]["bal_close"] = 6_400.00
    pre[2]["_seeded_exception"] = "EX-PRE-02 balance carried on an expired coverage period"
    pre[4]["bal_close"] = -abs(pre[4]["bal_close"])
    pre[4]["_seeded_exception"] = "EX-PRE-03 negative prepayment balance"

    wb2, ws2 = new_workbook("Prepayments")
    sb2 = SheetBuilder(ws2)
    sb2.title_block([(P.name.upper(), True), ("SCHEDULE OF PREPAYMENTS", True),
                     (f"As at {ye:%d %B %Y}", False)], merge_to=7)
    sb2.blank()
    f2 = sb2.row + 1
    sb2.header([P.h("acc.description"), P.h("pre.amount_paid"), P.h("pre.period_from"),
                P.h("pre.period_to"), "Months", P.h("pre.expensed"),
                P.h("acc.bal_close")])
    for x in pre:
        sb2.raw([x["desc"], x["paid"], render_date(x["from"], "dmy_slash"),
                 render_date(x["to"], "dmy_slash"), x["months"], x["expensed"],
                 x["bal_close"]])
    l2 = sb2.row - 1
    sb2.blank()
    sb2.formula([(c, "sum") for c in (2, 6, 7)], f2, l2, label="TOTAL")
    widths(ws2, {"A": 34, "B": 16, "C": 14, "D": 14, "E": 10, "F": 16, "G": 16})
    p2 = os.path.join(outdir, f"PBC-PRE-01 Prepayments schedule {ye:%Y-%m-%d}.xlsx")
    wb2.save(p2)
    return [p1, p2], recs, pre


# ==========================================================================
# Lease schedule (IFRS 16 / SFRS(I) 16)
# ==========================================================================

def write_leases(profile, outdir):
    r = rng(profile.key, "lease")
    P, ye, fys = profile, profile.year_end, profile.fy_start
    leases = [("Factory unit - Block A", 42_000, 60, 4.5),
              ("Warehouse annex", 14_500, 36, 4.5),
              ("Motor vehicle - delivery van", 1_850, 48, 3.8),
              ("Forklift", 980, 36, 3.8)][: 4 if P.variant != 3 else 3]

    recs = []
    for i, (nm, monthly, term, rate) in enumerate(leases):
        commence = fys - dt.timedelta(days=r.randint(100, 900))
        m = rate / 100 / 12
        pv = round(monthly * (1 - (1 + m) ** -term) / m, 2)
        elapsed_before = max(0, (fys.year - commence.year) * 12 + fys.month - commence.month)
        liab = pv
        rou_accum = 0.0
        for _ in range(elapsed_before):
            interest = liab * m
            liab = max(0.0, liab - (monthly - interest))
            rou_accum += pv / term
        liab_open = round(liab, 2)
        rou_open = round(pv - rou_accum, 2)
        int_yr, pay_yr = 0.0, 0.0
        for _ in range(min(12, max(0, term - elapsed_before))):
            iv = liab * m
            liab = max(0.0, liab - (monthly - iv))
            int_yr += iv
            pay_yr += monthly
        dep_yr = round(min(rou_open, pv / term * 12), 2)
        recs.append({"asset": nm, "commence": commence, "term": term, "rate": rate,
                     "monthly": monthly, "initial_liab": pv,
                     "rou_open": rou_open, "rou_dep": dep_yr,
                     "rou_close": round(rou_open - dep_yr, 2),
                     "liab_open": liab_open, "interest": round(int_yr, 2),
                     "payments": round(pay_yr, 2), "liab_close": round(liab, 2),
                     "_seeded_exception": None})
    if recs:
        recs[0]["liab_close"] = round(recs[0]["liab_close"] + 1_850.00, 2)
        recs[0]["_seeded_exception"] = "EX-LSE-01 lease liability movement does not cast"
    if len(recs) > 1:
        recs[1]["rou_dep"] = round(recs[1]["rou_dep"] * 0.6, 2)
        recs[1]["_seeded_exception"] = "EX-LSE-02 right-of-use depreciation inconsistent with lease term"

    wb, ws = new_workbook("Lease Schedule")
    sb = SheetBuilder(ws)
    sb.title_block([(P.name.upper(), True),
                    ("RIGHT-OF-USE ASSETS AND LEASE LIABILITIES", True),
                    (f"For the year ended {ye:%d %B %Y}", False)], merge_to=8)
    sb.blank()
    first = sb.row + 1
    sb.header(["Leased Asset", "Commencement", "Term (Months)", "Discount Rate %",
               "Monthly Payment", "Initial Liability", "ROU B/F", "ROU Depreciation",
               "ROU C/F", "Liability B/F", "Interest", "Payments", "Liability C/F"])
    for x in recs:
        sb.raw([x["asset"], render_date(x["commence"], "dmy_slash"), x["term"],
                x["rate"], x["monthly"], x["initial_liab"], x["rou_open"],
                -x["rou_dep"], x["rou_close"], x["liab_open"], x["interest"],
                -x["payments"], x["liab_close"]])
    last = sb.row - 1
    sb.blank()
    sb.formula([(c, "sum") for c in range(6, 14)], first, last, label="TOTAL")
    sb.footnotes(["Discount rate is the incremental borrowing rate at commencement.",
                  "Short-term and low-value leases are expensed as incurred."])
    widths(ws, {"A": 34, "B": 15, "C": 14, "D": 14, "E": 16, "F": 16, "G": 16,
                "H": 16, "I": 16, "J": 16, "K": 14, "L": 14, "M": 16})
    path = os.path.join(outdir, f"PBC-LSE-01 Lease schedule {ye:%Y-%m-%d}.xlsx")
    wb.save(path)
    return path, recs


# ==========================================================================
# Equity / share capital schedule
# ==========================================================================

def write_equity(profile, outdir):
    r = rng(profile.key, "eq")
    P, ye, fys = profile, profile.year_end, profile.fy_start
    wb, ws = new_workbook("Equity")
    sb = SheetBuilder(ws)
    sb.title_block([(P.name.upper(), True),
                    ("SHARE CAPITAL AND RESERVES", True),
                    (f"For the year ended {ye:%d %B %Y}", False)], merge_to=6)
    sb.blank()

    sb.raw(["Issued and paid-up share capital"], bold=True)
    first = sb.row + 1
    sb.header([P.h("eq.description"), P.h("eq.date"), P.h("eq.shares"),
               P.h("eq.amount")])
    rows = [("Balance brought forward", fys - dt.timedelta(days=1), 500_000, 500_000.00),
            ("Ordinary shares allotted for cash", fys + dt.timedelta(days=124),
             138_654, 138_654.00)]
    for nm, d, sh, amt in rows:
        sb.raw([nm, render_date(d, "dmy_slash"), sh, amt])
    last = sb.row - 1
    sb.formula([(3, "sum"), (4, "sum")], first, last, label="Balance carried forward")
    sb.blank()

    sb.raw(["Reserves"], bold=True)
    f2 = sb.row + 1
    sb.header([P.h("eq.description"), "Retained Earnings", "Translation Reserve",
               "Total"])
    re_open = -1_006_836.0
    profit = -379_295.0
    fx = 24_890.0
    sb.raw(["Balance brought forward", re_open, 0.0, re_open])
    sb.raw(["Total comprehensive income for the year", profit, fx, profit + fx])
    sb.raw(["Dividends paid", 0.0, 0.0, 0.0])
    l2 = sb.row - 1
    sb.formula([(2, "sum"), (3, "sum"), (4, "sum")], f2, l2,
               label="Balance carried forward")
    sb.footnotes(["The Company has one class of ordinary shares with no par value.",
                  "There are no share options, warrants or convertible instruments outstanding."])
    widths(ws, {"A": 46, "B": 18, "C": 20, "D": 18})
    path = os.path.join(outdir, f"PBC-EQ-01 Share capital and reserves {ye:%Y-%m-%d}.xlsx")
    wb.save(path)
    return path
