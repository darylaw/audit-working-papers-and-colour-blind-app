"""
gen_core -- synthetic PBC generators for the core balance-sheet audit areas:
trial balance, general ledger, AR listing + aging, AP listing + aging,
fixed asset register, inventory listing.

All output is FICTITIOUS test data with deliberately injected defects.
"""

import datetime as dt
import csv
import os
from openpyxl.styles import Font

from dqlib import (rng, SheetBuilder, new_workbook, widths, add_decoy_sheets,
                   mixed_dates, mixed_numbers, render_date, render_number,
                   whitespace_noise, truncate, case_noise, suffix_variant,
                   inject_duplicates, blank_out, emit_grouped, rand_date,
                   round_sum)
from clients import (CUSTOMER_BASES, SUPPLIER_BASES, EMPLOYEE_NAMES,
                     FA_CATEGORIES, INVENTORY_CLASSES, BANKS)

# ==========================================================================
# Chart of accounts -- shared skeleton, coded per client style
# ==========================================================================

COA = [
    # (code_seq, name, fs_caption, section, dr_cr, base_amount)
    (1010, "Cash at bank - operating",        "Cash and cash equivalents", "CA", "D", 486_300),
    (1015, "Cash at bank - collection",       "Cash and cash equivalents", "CA", "D", 122_450),
    (1020, "Fixed deposit",                   "Cash and cash equivalents", "CA", "D", 250_000),
    (1025, "Cash in hand",                    "Cash and cash equivalents", "CA", "D", 3_180),
    (1110, "Trade receivables",               "Trade receivables",         "CA", "D", 2_884_120),
    (1115, "Allowance for expected credit losses", "Trade receivables",    "CA", "C", -96_400),
    (1120, "Other receivables",               "Other receivables and prepayments", "CA", "D", 61_900),
    (1125, "Deposits",                        "Other receivables and prepayments", "CA", "D", 48_250),
    (1130, "Prepayments",                     "Other receivables and prepayments", "CA", "D", 74_615),
    (1140, "Amount due from related parties", "Amounts due from related parties", "CA", "D", 317_800),
    (1210, "Inventory - raw materials",       "Inventories",               "CA", "D", 612_400),
    (1215, "Inventory - work in progress",     "Inventories",               "CA", "D", 148_900),
    (1220, "Inventory - finished goods",      "Inventories",               "CA", "D", 481_260),
    (1225, "Provision for inventory obsolescence", "Inventories",          "CA", "C", -118_240),
    (1410, "Office equipment - cost",         "Property, plant and equipment", "NCA", "D", 0),
    (1415, "Office equipment - accumulated depreciation", "Property, plant and equipment", "NCA", "C", 0),
    (1420, "Furniture and fittings - cost",   "Property, plant and equipment", "NCA", "D", 0),
    (1425, "Furniture and fittings - accumulated depreciation", "Property, plant and equipment", "NCA", "C", 0),
    (1430, "Computers and IT - cost",         "Property, plant and equipment", "NCA", "D", 0),
    (1435, "Computers and IT - accumulated depreciation", "Property, plant and equipment", "NCA", "C", 0),
    (1440, "Leasehold improvements - cost",   "Property, plant and equipment", "NCA", "D", 0),
    (1445, "Leasehold improvements - accumulated depreciation", "Property, plant and equipment", "NCA", "C", 0),
    (1450, "Plant and machinery - cost",      "Property, plant and equipment", "NCA", "D", 0),
    (1455, "Plant and machinery - accumulated depreciation", "Property, plant and equipment", "NCA", "C", 0),
    (1460, "Motor vehicles - cost",           "Property, plant and equipment", "NCA", "D", 0),
    (1465, "Motor vehicles - accumulated depreciation", "Property, plant and equipment", "NCA", "C", 0),
    (1470, "Tools and equipment - cost",      "Property, plant and equipment", "NCA", "D", 0),
    (1475, "Tools and equipment - accumulated depreciation", "Property, plant and equipment", "NCA", "C", 0),
    (1510, "Right-of-use assets - cost",      "Right-of-use assets",       "NCA", "D", 1_842_000),
    (1515, "Right-of-use assets - accumulated depreciation", "Right-of-use assets", "NCA", "C", -444_700),
    (1610, "Intangible assets - cost",        "Intangible assets",         "NCA", "D", 41_800),
    (1615, "Intangible assets - accumulated amortisation", "Intangible assets", "NCA", "C", -39_318),
    (2010, "Trade payables",                  "Trade payables",            "CL", "C", -1_612_480),
    (2020, "Other payables",                  "Other payables and accruals", "CL", "C", -389_240),
    (2025, "Accruals",                        "Other payables and accruals", "CL", "C", -465_046),
    (2030, "Deposits received",               "Other payables and accruals", "CL", "C", -18_400),
    (2040, "Amount due to related parties",   "Amounts due to related parties", "CL", "C", -206_500),
    (2110, "GST payable",                     "Other payables and accruals", "CL", "C", -63_180),
    (2210, "Lease liabilities - current",     "Lease liabilities",         "CL", "C", -186_240),
    (2215, "Lease liabilities - non-current", "Lease liabilities",         "NCL", "C", -124_266),
    (2310, "Term loan - current portion",     "Borrowings",                "CL", "C", -142_800),
    (2315, "Term loan - non-current portion", "Borrowings",                "NCL", "C", -136_497),
    (2410, "Provision for taxation",          "Income tax payable",        "CL", "C", 0),
    (2420, "Deferred tax liabilities",        "Deferred tax liabilities",  "NCL", "C", -9_928),
    (3010, "Share capital",                   "Share capital",             "EQ", "C", -638_654),
    (3020, "Retained earnings",               "Retained earnings",         "EQ", "C", -1_386_131),
    (3030, "Foreign currency translation reserve", "Other reserves",       "EQ", "C", 24_890),
    (4010, "Revenue - product sales",         "Revenue",                   "PL", "C", -4_284_600),
    (4015, "Revenue - services",              "Revenue",                   "PL", "C", -562_664),
    (4020, "Sales returns and allowances",    "Revenue",                   "PL", "D", 41_280),
    (4110, "Other income - scrap sales",      "Other income",              "PL", "C", -28_460),
    (4115, "Other income - interest",         "Other income",              "PL", "C", -11_075),
    (4120, "Other income - foreign exchange gain", "Other income",         "PL", "C", -14_620),
    (5010, "Cost of materials consumed",      "Cost of sales",             "PL", "D", 2_918_400),
    (5015, "Direct labour",                   "Cost of sales",             "PL", "D", 486_200),
    (5020, "Subcontract charges",             "Cost of sales",             "PL", "D", 312_640),
    (5025, "Factory overheads",               "Cost of sales",             "PL", "D", 198_450),
    (6010, "Salaries and wages",              "Administrative expenses",   "PL", "D", 742_800),
    (6015, "Employer statutory contributions", "Administrative expenses",  "PL", "D", 108_460),
    (6020, "Directors' remuneration",         "Administrative expenses",   "PL", "D", 264_000),
    (6025, "Staff welfare",                   "Administrative expenses",   "PL", "D", 34_180),
    (6110, "Rental of premises",              "Administrative expenses",   "PL", "D", 18_400),
    (6115, "Utilities",                       "Administrative expenses",   "PL", "D", 86_240),
    (6120, "Repairs and maintenance",         "Administrative expenses",   "PL", "D", 62_180),
    (6125, "Insurance",                       "Administrative expenses",   "PL", "D", 41_620),
    (6130, "Professional fees",               "Administrative expenses",   "PL", "D", 78_400),
    (6135, "Audit fee",                       "Administrative expenses",   "PL", "D", 24_000),
    (6140, "Depreciation of property, plant and equipment", "Administrative expenses", "PL", "D", 71_292),
    (6145, "Depreciation of right-of-use assets", "Administrative expenses", "PL", "D", 77_169),
    (6150, "Amortisation of intangible assets", "Administrative expenses", "PL", "D", 517),
    (6155, "Travel and entertainment",        "Administrative expenses",   "PL", "D", 46_820),
    (6160, "Motor vehicle running costs",     "Administrative expenses",   "PL", "D", 28_940),
    (6165, "Freight and delivery",            "Selling and distribution expenses", "PL", "D", 118_600),
    (6170, "Advertising and promotion",       "Selling and distribution expenses", "PL", "D", 34_500),
    (6175, "Commission",                      "Selling and distribution expenses", "PL", "D", 62_400),
    (6180, "Bad debts written off",           "Administrative expenses",   "PL", "D", 18_640),
    (6185, "Allowance for expected credit losses", "Administrative expenses", "PL", "D", 96_400),
    (6190, "Inventory written down",          "Cost of sales",             "PL", "D", 118_240),
    (6195, "Foreign exchange loss",           "Administrative expenses",   "PL", "D", 22_180),
    (6210, "Bank charges",                    "Finance costs",             "PL", "D", 14_280),
    (6215, "Interest on term loans",          "Finance costs",             "PL", "D", 10_854),
    (6220, "Interest on lease liabilities",   "Finance costs",             "PL", "D", 13_987),
    (7010, "Income tax expense",              "Income tax expense",        "PL", "D", 0),
]


def code_for(profile, seq):
    """Render an account code in the client's coding style."""
    if profile.coa_style == "8-digit blocks":
        return f"{seq}{'0' * 4}"[:8] if len(str(seq)) == 4 else str(seq)
    if profile.coa_style == "dash-separated":
        return f"{str(seq)[0]}-{str(seq)[1:]}"
    return f"{seq}00"


def coa_rows(profile):
    """Chart of accounts with client-specific codes."""
    return [(code_for(profile, seq), name, cap, sec, dc, amt)
            for seq, name, cap, sec, dc, amt in COA]


# ==========================================================================
# Fixed asset register
# ==========================================================================

def build_fa_register(profile):
    """
    Returns (records, category_totals).
    Each record is a dict of canonical fields. Depreciation is computed on a
    straight-line, full-month convention -- but a minority of records carry
    deliberate errors so that the PPE module's recalculation finds exceptions.
    """
    r = rng(profile.key, "fa")
    ye, fys = profile.year_end, profile.fy_start
    recs = []
    n = 0
    for cat, life, method, (lo, hi) in FA_CATEGORIES:
        count = r.randint(6, 14)
        for i in range(count):
            n += 1
            # Acquisition anywhere from 14 years ago to just after year end
            age_days = r.randint(20, 14 * 365)
            acq = ye - dt.timedelta(days=age_days)
            cost = round(r.uniform(lo, hi), 2)
            cost = round_sum(cost, r, p=0.10)

            this_life = life
            # DQ-24: a few assets carry life in months instead of years
            life_in_months = r.random() < 0.07

            is_addition = acq >= fys
            is_disposal = (not is_addition) and r.random() < 0.05

            annual = cost / this_life if this_life else 0.0
            months_owned_total = max(0, (ye.year - acq.year) * 12 + ye.month - acq.month)
            months_this_year = min(12, max(0, months_owned_total))
            if is_addition:
                months_this_year = max(0, (ye.year - acq.year) * 12 + ye.month - acq.month)

            # Accumulated depreciation brought forward
            months_before = max(0, months_owned_total - months_this_year)
            accdep_open = min(cost, round(annual * months_before / 12, 2))
            charge = min(cost - accdep_open, round(annual * months_this_year / 12, 2))

            cost_open = 0.0 if is_addition else cost
            additions = cost if is_addition else 0.0
            disposals = cost if is_disposal else 0.0
            accdep_disp = accdep_open + charge if is_disposal else 0.0

            rec = {
                "asset_id": f"{''.join(w[0] for w in cat.split()[:2]).upper()}{acq.year}{i+1:03d}",
                "category": cat,
                "description": _fa_description(cat, r),
                "acq_date": acq,
                "life": this_life * 12 if life_in_months else this_life,
                "life_unit": "months" if life_in_months else "years",
                "method": method,
                "rate": round(100.0 / this_life, 2),
                "cost_open": cost_open,
                "additions": additions,
                "disposals": disposals,
                "cost_close": cost_open + additions - disposals,
                "accdep_open": 0.0 if is_addition else accdep_open,
                "dep_charge": charge,
                "accdep_disp": accdep_disp,
                "accdep_close": (0.0 if is_addition else accdep_open) + charge - accdep_disp,
                "supplier": suffix_variant(r.choice(SUPPLIER_BASES), r),
                "location": r.choice(["Main Factory", "Warehouse 2", "Head Office",
                                      "Site Office", ""]),
                "_seeded_exception": None,
            }
            recs.append(rec)

    # ---- Seeded audit exceptions (the PPE module must find these) --------
    _seed_fa_exceptions(recs, r)

    for rec in recs:
        rec["nbv_open"] = round(rec["cost_open"] - rec["accdep_open"], 2)
        rec["nbv_close"] = round(rec["cost_close"] - rec["accdep_close"], 2)
    return recs


FA_ITEMS = {
    "Leasehold Improvements": ["Office partitioning works", "Factory floor coating",
                               "Mezzanine deck installation", "Ceiling and lighting works",
                               "Fire suppression upgrade", "Loading bay shutter"],
    "Plant and Machinery":    ["CNC turning centre", "Hydraulic press 60T",
                               "Slitting line", "Overhead travelling crane 5T",
                               "Industrial dehumidifier", "Wrapping machine",
                               "Surface grinder", "Shot blast cabinet",
                               "Coil straightener", "Electronic floor scale"],
    "Office Equipment":       ["Multifunction printer", "Shredder", "Projector",
                               "Air purifier", "Water dispenser", "Label printer"],
    "Furniture and Fittings": ["Workstation cluster (6 pax)", "Meeting room table",
                               "Storage cabinets", "Reception counter",
                               "Ergonomic chairs (10 units)"],
    "Computers and IT":       ["Notebook computer", "Server rack unit",
                               "Network switch 48-port", "Firewall appliance",
                               "Terminal server licence", "Workstation desktop",
                               "NAS storage array"],
    "Motor Vehicles":         ["Delivery van", "Forklift 2.5T", "Company car",
                               "Lorry 5T", "Pickup truck"],
    "Tools and Equipment":    ["Torque wrench set", "Welding plant", "Air compressor",
                               "Pallet jack", "Measuring gauge set", "Hand trolley"],
}


def _fa_description(cat, r):
    base = r.choice(FA_ITEMS[cat])
    if r.random() < 0.35:
        base += f" - {r.choice(['Unit A', 'Unit B', 'Line 1', 'Line 2', 'Sn. ' + str(r.randint(10000, 99999))])}"
    return base


def _seed_fa_exceptions(recs, r):
    """
    Plant deliberate, findable exceptions. Each is tagged so the expected-results
    file can assert the audit module detects it.
    """
    picks = r.sample(range(len(recs)), min(12, len(recs)))

    # 1. Depreciation understated -- client charged half of what is due
    i = picks[0]
    recs[i]["dep_charge"] = round(recs[i]["dep_charge"] * 0.5, 2)
    recs[i]["accdep_close"] = round(recs[i]["accdep_open"] + recs[i]["dep_charge"]
                                    - recs[i]["accdep_disp"], 2)
    recs[i]["_seeded_exception"] = "EX-PPE-01 depreciation understated"

    # 2. Depreciation overstated
    i = picks[1]
    recs[i]["dep_charge"] = round(recs[i]["dep_charge"] * 1.85, 2)
    recs[i]["accdep_close"] = round(recs[i]["accdep_open"] + recs[i]["dep_charge"]
                                    - recs[i]["accdep_disp"], 2)
    recs[i]["_seeded_exception"] = "EX-PPE-02 depreciation overstated"

    # 3. Over-depreciated: accumulated depreciation exceeds cost -> negative NBV
    i = picks[2]
    recs[i]["accdep_close"] = round(recs[i]["cost_close"] * 1.06, 2)
    recs[i]["_seeded_exception"] = "EX-PPE-03 accumulated depreciation exceeds cost (negative NBV)"

    # 4. Fully depreciated but still being depreciated
    i = picks[3]
    recs[i]["accdep_open"] = recs[i]["cost_close"]
    recs[i]["dep_charge"] = round(recs[i]["cost_close"] / 12, 2)
    recs[i]["accdep_close"] = round(recs[i]["accdep_open"] + recs[i]["dep_charge"], 2)
    recs[i]["_seeded_exception"] = "EX-PPE-04 depreciation charged on fully depreciated asset"

    # 5. Useful life outside the policy range for its class
    i = picks[4]
    recs[i]["life"] = 45 if recs[i]["life_unit"] == "years" else 540
    recs[i]["_seeded_exception"] = "EX-PPE-05 useful life outside accounting policy"

    # 6. Zero / missing useful life but depreciation charged
    i = picks[5]
    recs[i]["life"] = 0
    recs[i]["_seeded_exception"] = "EX-PPE-06 nil useful life with depreciation charged"

    # 7. Acquisition dated after the year end
    i = picks[6]
    recs[i]["_seeded_exception"] = "EX-PPE-07 acquisition date after year end"

    # 8. Cost roll-forward does not cast
    i = picks[7]
    recs[i]["cost_close"] = round(recs[i]["cost_close"] + 1_450.00, 2)
    recs[i]["_seeded_exception"] = "EX-PPE-08 cost roll-forward does not reconcile"

    # 9. Disposal with no accumulated depreciation written back
    i = picks[8]
    recs[i]["disposals"] = recs[i]["cost_open"]
    recs[i]["cost_close"] = 0.0
    recs[i]["accdep_disp"] = 0.0
    recs[i]["accdep_close"] = round(recs[i]["accdep_open"] + recs[i]["dep_charge"], 2)
    recs[i]["_seeded_exception"] = "EX-PPE-09 disposal without write-back of accumulated depreciation"

    # 10. Negative cost (credit posting to a fixed asset account)
    i = picks[9]
    recs[i]["additions"] = -abs(recs[i]["additions"] or 3_400.0)
    recs[i]["cost_close"] = round(recs[i]["cost_open"] + recs[i]["additions"]
                                  - recs[i]["disposals"], 2)
    recs[i]["_seeded_exception"] = "EX-PPE-10 negative addition"

    # 11. Capital item below the capitalisation threshold
    i = picks[10]
    recs[i]["additions"] = 380.00
    recs[i]["cost_open"] = 0.0
    recs[i]["cost_close"] = 380.00
    recs[i]["_seeded_exception"] = "EX-PPE-11 addition below capitalisation threshold"

    # 12. Duplicate asset (same description, same date, same cost)
    i = picks[11]
    dup = dict(recs[i])
    dup["asset_id"] = dup["asset_id"] + "A"
    dup["_seeded_exception"] = "EX-PPE-12 possible duplicate asset record"
    recs.append(dup)

    # Post-year-end acquisition for exception 7
    j = picks[6]
    recs[j]["acq_date"] = recs[j]["acq_date"]  # set by caller below


def write_fa_register(profile, outdir):
    """Write the fixed asset register in the client's own layout."""
    r = rng(profile.key, "fa-write")
    recs = build_fa_register(profile)
    dq = profile.dq
    ye = profile.year_end

    # DQ-15: force one acquisition after the year end
    for rec in recs:
        if rec["_seeded_exception"] == "EX-PPE-07 acquisition date after year end":
            rec["acq_date"] = ye + dt.timedelta(days=r.randint(3, 40))

    recs = inject_duplicates(recs, r, dq["dup_exact"], dq["dup_near"], "description")
    recs = blank_out(recs, r,
                     ["acq_date", "life", "method", "supplier", "location"],
                     p=dq["missing_p"])

    wb, ws = new_workbook("FA Register" if profile.variant == 0 else "Sheet1")
    sb = SheetBuilder(ws)

    # DQ-01/DQ-17: title block
    if dq["extra_headers"] >= 2:
        sb.title_block([
            (profile.name.upper(), True),
            (f"FIXED ASSETS REGISTER AS AT {ye.strftime('%d %B %Y').upper()}", True),
            (f"All amounts in {profile.functional_ccy}", False),
        ][:dq["extra_headers"]], merge_to=8)
        sb.blank()
    else:
        sb.title_block([(f"Fixed Asset Register - {ye.strftime('%d/%m/%Y')}", True)])

    # Column layout, with the client's own heading words (DQ-07)
    P = profile
    layout = [
        ("asset_id",     P.h("fa.asset_id")),
        ("category",     P.h("fa.category")) if not dq["group_headers"] else None,
        ("description",  P.h("fa.description")),
        ("acq_date",     P.h("fa.acq_date")),
        ("life",         P.h("fa.life")),
        ("method",       P.h("fa.method")) if P.variant != 1 else None,
        (None,           None) if dq["blank_cols"] >= 1 else None,   # DQ-03
        ("cost_open",    P.h("fa.cost_open")),
        ("additions",    P.h("fa.additions")),
        ("disposals",    P.h("fa.disposals")),
        ("cost_close",   P.h("fa.cost_close")),
        (None,           None) if dq["blank_cols"] >= 2 else None,   # DQ-03
        ("accdep_open",  P.h("fa.accdep_open")),
        ("dep_charge",   P.h("fa.dep_charge")),
        ("accdep_disp",  P.h("fa.accdep_disp")),
        ("accdep_close", P.h("fa.accdep_close")),
        ("nbv_close",    P.h("fa.nbv_close")),
        ("supplier",     P.h("fa.supplier")) if P.variant == 0 else None,
        ("location",     P.h("fa.location")) if P.variant == 3 else None,
    ]
    layout = [x for x in layout if x is not None]
    fields = [f for f, _ in layout]
    header_row = sb.row
    sb.header([h for _, h in layout])

    money_fields = {"cost_open", "additions", "disposals", "cost_close",
                    "accdep_open", "dep_charge", "accdep_disp", "accdep_close",
                    "nbv_close"}
    date_primary = P.date_style

    def write_row(sbx, rec):
        vals = []
        for f in fields:
            if f is None:
                vals.append(None)
                continue
            v = rec.get(f)
            if f == "acq_date":
                if v is None:
                    vals.append(None)
                elif r.random() < dq["date_contam"]:
                    vals.append(render_date(v, r.choice(
                        ["iso", "mdy_slash", "dmy_dot", "mon_yy", "year_only",
                         "serial", "native"])))
                else:
                    vals.append(render_date(v, date_primary))
            elif f in money_fields:
                if v is None:
                    vals.append(None)
                elif r.random() < dq["num_contam"]:
                    vals.append(render_number(v, r.choice(
                        ["text", "thousands", "paren_neg", "trailing_minus",
                         "dash_zero", "blank_zero"]), P.functional_ccy))
                else:
                    vals.append(render_number(v, "native"))
            elif f == "life":
                # DQ-24: unit not stated in the cell
                vals.append(v if v is not None else None)
            elif isinstance(v, str):
                vals.append(whitespace_noise(truncate(case_noise(v, r), r), r))
            else:
                vals.append(v)
        sbx.raw(vals)

    if dq["group_headers"]:
        groups = {}
        for rec in recs:
            groups.setdefault(rec["category"], []).append(rec)
        money_cols = [i + 1 for i, f in enumerate(fields) if f in money_fields]
        emit_grouped(sb, list(groups.items()), write_row,
                     group_header=True, subtotal=dq["subtotals"],
                     subtotal_cols=money_cols, subtotal_label="Sub-total")
    else:
        first = sb.row
        for idx, rec in enumerate(recs):
            # DQ-02: blank rows scattered through the detail
            if r.random() < dq["blank_row_p"]:
                sb.blank()
            write_row(sb, rec)
        last = sb.row - 1
        money_cols = [i + 1 for i, f in enumerate(fields) if f in money_fields]
        # DQ-16 + DQ-19: total row -- live formulas, with one hard-coded and off
        specs = []
        for ci in money_cols:
            if dq["casting_diff"] and ci == money_cols[3]:
                specs.append((ci, sum(x["cost_close"] for x in recs) + dq["casting_diff"]))
            else:
                specs.append((ci, "sum"))
        sb.blank()
        sb.formula(specs, first, last, label="TOTAL")

    if dq["footnotes"]:
        sb.footnotes([
            "Note: assets fully depreciated are retained in the register until physically disposed.",
            "Note: the register is maintained in a spreadsheet and reconciled to the general ledger annually.",
            "* Depreciation is charged from the month of acquisition.",
        ])

    widths(ws, {"A": 16, "B": 22, "C": 44, "D": 14, "E": 12, "F": 16,
                "G": 14, "H": 14, "I": 14, "J": 14, "K": 14, "L": 14,
                "M": 14, "N": 14, "O": 14, "P": 16, "Q": 26})

    if P.variant == 0:
        add_decoy_sheets(wb, r, ["Depn calc (old)", "Notes"], ["FY24 backup"])
    elif P.variant == 1:
        add_decoy_sheets(wb, r, ["Sheet2"], ["Sheet3"])

    path = os.path.join(outdir, f"PBC-PPE-01 Fixed asset register {ye:%Y-%m-%d}.xlsx")
    wb.save(path)
    return path, recs


# ==========================================================================
# Trial balance
# ==========================================================================

def write_trial_balance(profile, outdir, fa_recs):
    """
    Trial balance in the client's own export layout.
    PPE cost / accumulated depreciation lines are derived from the FA register
    but deliberately do NOT agree exactly -- the platform must surface the
    register-to-ledger difference.
    """
    r = rng(profile.key, "tb")
    P, ye = profile, profile.year_end
    rows = coa_rows(P)

    # Aggregate the FA register by category into the matching GL lines
    cat_to_code = {
        "Office Equipment": 1410, "Furniture and Fittings": 1420,
        "Computers and IT": 1430, "Leasehold Improvements": 1440,
        "Plant and Machinery": 1450, "Motor Vehicles": 1460,
        "Tools and Equipment": 1470,
    }
    cost_by_code, dep_by_code = {}, {}
    for rec in fa_recs:
        seq = cat_to_code.get(rec["category"])
        if not seq:
            continue
        cost_by_code[seq] = cost_by_code.get(seq, 0.0) + (rec["cost_close"] or 0.0)
        dep_by_code[seq] = dep_by_code.get(seq, 0.0) - (rec["accdep_close"] or 0.0)

    # DQ: ledger differs from register on two categories (unreconciled difference)
    if 1450 in cost_by_code:
        cost_by_code[1450] += 2_480.00
    if 1430 in dep_by_code:
        dep_by_code[1430] -= 640.00

    out = []
    for code, name, cap, sec, dc, amt in rows:
        seq = int(code.replace("-", "")[:4]) if code.replace("-", "")[:4].isdigit() else 0
        if seq in cost_by_code:
            amt = round(cost_by_code[seq], 2)
        elif seq in dep_by_code:
            amt = round(dep_by_code[seq], 2)
        # tax lines derived later
        out.append({"code": code, "name": name, "caption": cap, "section": sec,
                    "amount": round(amt, 2)})

    # Balance the TB onto retained earnings so debits = credits exactly,
    # then break it by a small amount for two of the three clients (DQ-19).
    total = sum(x["amount"] for x in out)
    for x in out:
        if x["name"] == "Retained earnings":
            x["amount"] = round(x["amount"] - total, 2)
            break
    if P.variant in (0, 1):
        for x in out:
            if x["name"] == "GST payable":
                x["amount"] = round(x["amount"] + (0.12 if P.variant == 0 else -0.05), 2)
                break

    wb, ws = new_workbook(P.tb_sheet_name)
    sb = SheetBuilder(ws)
    sb.title_block([
        (P.name.upper(), True),
        ("TRIAL BALANCE", True),
        (f"For the year ended {ye:%d %B %Y}", False),
        (f"Currency: {P.functional_ccy}", False),
    ][:max(2, P.dq["extra_headers"])], merge_to=6)
    sb.blank()

    if P.variant == 3:
        cols = [P.h("tb.account_code"), P.h("tb.account_name"),
                P.h("tb.fs_caption"), P.h("tb.debit"), P.h("tb.credit"),
                P.h("tb.balance_py")]
    elif P.variant == 1:
        cols = [P.h("tb.account_code"), P.h("tb.account_name"),
                P.h("tb.debit"), P.h("tb.credit")]
    else:
        cols = [P.h("tb.account_code"), P.h("tb.account_name"),
                P.h("tb.balance"), P.h("tb.balance_py")]
    first_data = sb.row + 1
    sb.header(cols)

    def py_of(x):
        # Prior year comparative -- plausibly different
        f = 1 + r.uniform(-0.28, 0.34)
        return round(x["amount"] * f, 2)

    n = 0
    for x in out:
        if r.random() < P.dq["blank_row_p"] * 0.5:
            sb.blank()
        name = whitespace_noise(case_noise(x["name"], r), r)
        amt = x["amount"]
        if P.variant == 1:
            dr = amt if amt > 0 else None
            cr = -amt if amt < 0 else None
            vals = [x["code"], name,
                    render_number(dr, "native") if dr else None,
                    render_number(cr, "native") if cr else None]
            if r.random() < P.dq["num_contam"]:
                idx = 2 if dr else 3
                vals[idx] = render_number(dr or cr, r.choice(["text", "thousands"]))
        elif P.variant == 3:
            dr = amt if amt > 0 else None
            cr = -amt if amt < 0 else None
            vals = [x["code"], name, x["caption"],
                    render_number(dr, "native") if dr else None,
                    render_number(cr, "native") if cr else None,
                    py_of(x)]
        else:
            vals = [x["code"], name, render_number(amt, "native"), py_of(x)]
            if r.random() < P.dq["num_contam"]:
                vals[2] = render_number(amt, r.choice(
                    ["paren_neg", "thousands", "trailing_minus", "text"]))
        sb.raw(vals)
        n += 1
    last_data = sb.row - 1

    sb.blank()
    if P.variant == 1:
        sb.formula([(3, "sum"), (4, "sum")], first_data, last_data, label="TOTAL")
    elif P.variant == 3:
        sb.formula([(4, "sum"), (5, "sum")], first_data, last_data, label="TOTAL")
    else:
        sb.formula([(3, "sum"), (4, "sum")], first_data, last_data, label="TOTAL")

    if P.dq["footnotes"]:
        sb.footnotes(["Extracted from the accounting system. Subject to audit adjustments."])

    widths(ws, {"A": 16, "B": 52, "C": 34, "D": 16, "E": 16, "F": 16})
    if P.variant == 0:
        add_decoy_sheets(wb, r, ["Grouping"], ["TB (before adj)"])
    path = os.path.join(outdir, f"PBC-TB-01 Trial balance {ye:%Y-%m-%d}.xlsx")
    wb.save(path)
    return path, out


# ==========================================================================
# General ledger detail
# ==========================================================================

JOURNAL_SOURCES = ["SI", "SC", "PI", "PC", "CR", "CP", "JE", "GJ", "AP", "AR", "BK"]
NARRATIVES = [
    "Sales invoice", "Credit note", "Purchase invoice", "Supplier credit",
    "Customer receipt", "Supplier payment", "Payroll journal",
    "Depreciation journal", "Accrual journal", "Prepayment amortisation",
    "FX revaluation", "Reclassification", "Bank charges", "GST journal",
    "Intercompany recharge", "Reversal of accrual", "Provision journal",
]


def write_general_ledger(profile, outdir, tb_rows):
    """
    General ledger transaction detail. Includes journal-entry testing hooks:
    weekend postings, post-year-end dates, round sums, manual journals by
    unexpected users, and matched reversal pairs.
    """
    r = rng(profile.key, "gl")
    P, ye, fys = profile, profile.year_end, profile.fy_start
    pl_codes = [x for x in tb_rows if x["section"] == "PL"]
    bs_codes = [x for x in tb_rows if x["section"] != "PL"]

    users = [f"{n.split()[0][0]}{n.split()[1][:4]}".lower() for n in EMPLOYEE_NAMES[:8]]
    users += ["sysadmin", "batchjob", "import"]

    recs = []
    jn = 10_000
    for _ in range(1400):
        jn += 1
        d = rand_date(r, fys, ye, weekend_bias=0.07)
        src = r.choice(JOURNAL_SOURCES)
        narr = r.choice(NARRATIVES)
        amt = round(r.uniform(50, 48_000), 2)
        amt = round_sum(amt, r, p=0.05)
        dr_acct = r.choice(pl_codes + bs_codes)
        cr_acct = r.choice(bs_codes)
        user = r.choice(users)
        ref = f"{src}-{jn}"
        recs.append({"date": d, "ref": ref, "code": dr_acct["code"],
                     "name": dr_acct["name"], "desc": narr, "dr": amt, "cr": None,
                     "src": src, "user": user})
        recs.append({"date": d, "ref": ref, "code": cr_acct["code"],
                     "name": cr_acct["name"], "desc": narr, "dr": None, "cr": amt,
                     "src": src, "user": user})

    # DQ-14: reversal pairs (same amount, opposite sign, within a few days)
    for _ in range(8):
        src_rec = dict(r.choice(recs))
        rev = dict(src_rec)
        rev["date"] = src_rec["date"] + dt.timedelta(days=r.randint(1, 9))
        rev["dr"], rev["cr"] = src_rec["cr"], src_rec["dr"]
        rev["desc"] = "Reversal - " + str(src_rec["desc"])
        rev["ref"] = "REV-" + str(src_rec["ref"])
        recs.append(rev)

    # DQ-15: journals dated after the year end but posted into the year
    for _ in range(5):
        rec = dict(r.choice(recs))
        rec["date"] = ye + dt.timedelta(days=r.randint(1, 25))
        rec["desc"] = "Late adjustment - " + str(rec["desc"])
        rec["ref"] = "JE-" + str(90_000 + r.randint(1, 999))
        recs.append(rec)

    # DQ-15: large round-sum manual journals by an unusual user near year end
    for i in range(4):
        recs.append({"date": ye - dt.timedelta(days=r.randint(0, 4)),
                     "ref": f"JE-{95_100 + i}",
                     "code": r.choice(pl_codes)["code"],
                     "name": r.choice(pl_codes)["name"],
                     "desc": "Management adjustment", "dr": 250_000.00, "cr": None,
                     "src": "JE", "user": "sysadmin"})

    recs.sort(key=lambda x: (x["date"], x["ref"]))
    recs = inject_duplicates(recs, r, P.dq["dup_exact"], P.dq["dup_near"], "desc")

    # CSV for client B (desktop package export), XLSX otherwise
    if P.variant == 1:
        path = os.path.join(outdir, f"PBC-GL-01 General ledger {ye:%Y-%m-%d}.csv")
        with open(path, "w", newline="", encoding="utf-8-sig") as fh:
            w = csv.writer(fh)
            w.writerow([f"{P.name} - General Ledger Detail"])
            w.writerow([f"Period: {fys:%d/%m/%Y} to {ye:%d/%m/%Y}"])
            w.writerow([])
            w.writerow([P.h("gl.entry_date"), P.h("gl.journal_ref"),
                        P.h("gl.account_code"), "Account Name",
                        P.h("gl.description"), P.h("gl.debit"), P.h("gl.credit"),
                        P.h("gl.source"), P.h("gl.user")])
            for x in recs:
                dr = x["dr"]
                cr = x["cr"]
                w.writerow([
                    render_date(x["date"], "dmy_dot" if r.random() > P.dq["date_contam"]
                                else r.choice(["iso", "mdy_slash", "dmy_slash"])),
                    x["ref"], x["code"], x["name"],
                    whitespace_noise(x["desc"], r),
                    render_number(dr, "paren_neg" if (dr and dr < 0) else "text") if dr else "",
                    render_number(cr, "text") if cr else "",
                    x["src"], x["user"],
                ])
            w.writerow([])
            w.writerow(["", "", "", "", "TOTAL",
                        f"{sum(x['dr'] or 0 for x in recs):.2f}",
                        f"{sum(x['cr'] or 0 for x in recs):.2f}"])
        return path, recs

    wb, ws = new_workbook("GL Detail" if P.variant == 0 else "Sheet1")
    sb = SheetBuilder(ws)
    sb.title_block([(P.name.upper(), True),
                    ("GENERAL LEDGER DETAIL", True),
                    (f"{fys:%d/%m/%Y} to {ye:%d/%m/%Y}", False)][:P.dq["extra_headers"] or 1],
                   merge_to=9)
    sb.blank()
    cols = [P.h("gl.entry_date"), P.h("gl.journal_ref"), P.h("gl.account_code"),
            "Account Name", P.h("gl.description"), P.h("gl.debit"),
            P.h("gl.credit"), P.h("gl.source"), P.h("gl.user")]
    first = sb.row + 1
    sb.header(cols)
    dprim = P.date_style
    for x in recs:
        dv = (render_date(x["date"], r.choice(["iso", "mdy_slash", "serial", "native"]))
              if r.random() < P.dq["date_contam"] else render_date(x["date"], dprim))
        sb.raw([dv, x["ref"], x["code"], x["name"], whitespace_noise(x["desc"], r),
                render_number(x["dr"], "native") if x["dr"] else None,
                render_number(x["cr"], "native") if x["cr"] else None,
                x["src"], x["user"]])
    last = sb.row - 1
    sb.blank()
    sb.formula([(6, "sum"), (7, "sum")], first, last, label="TOTAL")
    widths(ws, {"A": 13, "B": 14, "C": 14, "D": 44, "E": 40, "F": 14, "G": 14,
                "H": 9, "I": 12})
    path = os.path.join(outdir, f"PBC-GL-01 General ledger {ye:%Y-%m-%d}.xlsx")
    wb.save(path)
    return path, recs


# ==========================================================================
# Accounts receivable listing + aging
# ==========================================================================

def build_ar(profile, target_gross):
    """Open invoice detail supporting the trade receivables balance."""
    r = rng(profile.key, "ar")
    P, ye = profile, profile.year_end
    customers = []
    for i, base in enumerate(CUSTOMER_BASES):
        customers.append({
            "code": f"C{i+1:04d}",
            "name": suffix_variant(base, r) if r.random() < 0.7 else base,
            "terms": r.choice([0, 30, 30, 45, 60, 60, 90, 120]),
            "ccy": r.choice(P.txn_ccys),
        })
    # DQ-12: the same customer appears under two spellings
    twin = dict(customers[3])
    twin["code"] = customers[3]["code"] + "-1"
    twin["name"] = customers[3]["name"].replace("Pte. Ltd.", "PTE LTD").replace(
        "Pte Ltd", "PTE. LTD.")
    customers.append(twin)

    recs, running = [], 0.0
    inv = 40_000
    while running < target_gross:
        cust = r.choice(customers)
        inv += r.randint(1, 4)
        # Age the invoice: most recent, a tail of very old items
        if r.random() < 0.72:
            age = r.randint(0, 60)
        elif r.random() < 0.7:
            age = r.randint(61, 150)
        else:
            age = r.randint(151, 900)
        d = ye - dt.timedelta(days=age)
        amt = round(r.uniform(400, 96_000), 2)
        amt = round_sum(amt, r, p=0.05)
        if running + amt > target_gross:
            amt = round(target_gross - running, 2)
            if amt <= 0:
                break
        running += amt
        recs.append({
            "cust_code": cust["code"], "cust_name": cust["name"],
            "inv_no": f"INV-{inv}", "inv_date": d,
            "due_date": d + dt.timedelta(days=cust["terms"]),
            "terms": cust["terms"], "ccy": cust["ccy"],
            "amount": amt, "age": age, "_seeded_exception": None,
        })

    # ---- Seeded exceptions ---------------------------------------------
    picks = r.sample(range(len(recs)), 10)
    # Credit balance within a debtor listing
    recs[picks[0]]["amount"] = -abs(round(r.uniform(500, 14_000), 2))
    recs[picks[0]]["_seeded_exception"] = "EX-AR-01 credit balance in receivables listing"
    # Invoice dated after year end included in the balance
    recs[picks[1]]["inv_date"] = ye + dt.timedelta(days=r.randint(2, 18))
    recs[picks[1]]["age"] = -1
    recs[picks[1]]["_seeded_exception"] = "EX-AR-02 invoice dated after year end"
    # Due date earlier than invoice date
    recs[picks[2]]["due_date"] = recs[picks[2]]["inv_date"] - dt.timedelta(days=20)
    recs[picks[2]]["_seeded_exception"] = "EX-AR-03 due date before invoice date"
    # Very long overdue with no allowance
    recs[picks[3]]["age"] = 740
    recs[picks[3]]["inv_date"] = ye - dt.timedelta(days=740)
    recs[picks[3]]["amount"] = 148_600.00
    recs[picks[3]]["_seeded_exception"] = "EX-AR-04 material balance >12 months overdue"
    # Missing customer name
    recs[picks[4]]["cust_name"] = None
    recs[picks[4]]["_seeded_exception"] = "EX-AR-05 missing counterparty name"
    # Duplicate invoice number, different amount
    dup = dict(recs[picks[5]])
    dup["amount"] = round(dup["amount"] + 0.01, 2)
    dup["_seeded_exception"] = "EX-AR-06 duplicate invoice number"
    recs.append(dup)
    # Balance exceeding the customer's credit terms materially
    recs[picks[6]]["terms"] = 0
    recs[picks[6]]["_seeded_exception"] = "EX-AR-07 nil credit terms with aged balance"
    # Round-sum balance suggesting a manual journal, not an invoice
    recs[picks[7]]["amount"] = 300_000.00
    recs[picks[7]]["inv_no"] = "JE-88214"
    recs[picks[7]]["_seeded_exception"] = "EX-AR-08 round-sum manual entry in receivables"
    # Foreign currency invoice with no rate applied
    recs[picks[8]]["ccy"] = "EUR"
    recs[picks[8]]["_seeded_exception"] = "EX-AR-09 currency outside client's normal set"
    # Zero-value open item
    recs[picks[9]]["amount"] = 0.0
    recs[picks[9]]["_seeded_exception"] = "EX-AR-10 nil-value open item"

    return recs


def _bucket(age, terms):
    """Age an invoice relative to its due date into standard buckets."""
    od = age - (terms or 0)
    if od <= 0:
        return "current"
    if od <= 30:
        return "b31_60" if False else "b1_30"
    if od <= 60:
        return "b31_60"
    if od <= 90:
        return "b61_90"
    if od <= 120:
        return "b91_120"
    return "b_over"


def write_ar(profile, outdir, gross):
    """Write the AR open-item listing and a separately-formatted aging report."""
    r = rng(profile.key, "ar-write")
    P, ye = profile, profile.year_end
    recs = build_ar(P, gross)
    recs = inject_duplicates(recs, r, P.dq["dup_exact"], P.dq["dup_near"], "cust_name")

    # ---- (a) open item listing ----------------------------------------
    wb, ws = new_workbook("AR Listing" if P.variant == 0 else "Sheet1")
    sb = SheetBuilder(ws)
    sb.title_block([(P.name.upper(), True),
                    ("TRADE RECEIVABLES - OPEN ITEM LISTING", True),
                    (f"As at {ye:%d %B %Y}", False),
                    ("Provided by client", False)][:max(2, P.dq["extra_headers"])],
                   merge_to=8)
    sb.blank()
    cols = [P.h("ar.customer_code"), P.h("ar.customer_name"), P.h("ar.invoice_no"),
            P.h("ar.invoice_date"), P.h("ar.due_date"), P.h("ar.terms"),
            P.h("ar.currency"), P.h("ar.amount")]
    if P.variant == 0:
        cols.insert(7, P.h("ar.amount_orig"))
    first = sb.row + 1
    sb.header(cols)
    dprim = P.date_style
    for x in recs:
        if r.random() < P.dq["blank_row_p"]:
            sb.blank()
        row = [x["cust_code"],
               whitespace_noise(truncate(x["cust_name"], r, 32), r) if x["cust_name"] else None,
               x["inv_no"],
               render_date(x["inv_date"], r.choice(["iso", "mdy_slash", "mon_yy", "serial"]))
               if r.random() < P.dq["date_contam"] else render_date(x["inv_date"], dprim),
               render_date(x["due_date"], dprim) if x["due_date"] else None,
               x["terms"], x["ccy"]]
        if P.variant == 0:
            row.append(render_number(x["amount"] * 1.0, "native"))
        row.append(render_number(x["amount"], r.choice(["paren_neg", "thousands", "text"]))
                   if r.random() < P.dq["num_contam"] else render_number(x["amount"], "native"))
        sb.raw(row)
    last = sb.row - 1
    sb.blank()
    amt_col = len(cols)
    total = sum(x["amount"] for x in recs)
    sb.formula([(amt_col, "sum")], first, last, label="TOTAL")
    if P.dq["casting_diff"]:
        sb.raw([None] * (amt_col - 1) + [round(total + P.dq["casting_diff"], 2)])
        sb.footnotes(["Total per general ledger control account (difference under investigation)."])
    if P.dq["footnotes"]:
        sb.footnotes(["Aged by invoice date. Credit notes shown as negative amounts."])
    widths(ws, {"A": 14, "B": 42, "C": 16, "D": 14, "E": 14, "F": 9, "G": 8,
                "H": 16, "I": 16})
    if P.variant == 0:
        add_decoy_sheets(wb, r, ["Aging (old)"], ["Recon"])
    p1 = os.path.join(outdir, f"PBC-AR-01 Trade receivables listing {ye:%Y-%m-%d}.xlsx")
    wb.save(p1)

    # ---- (b) aging summary by customer, buckets only ------------------
    agg = {}
    for x in recs:
        key = (x["cust_code"], x["cust_name"] or "(not stated)", x["ccy"])
        b = agg.setdefault(key, {"current": 0.0, "b1_30": 0.0, "b31_60": 0.0,
                                 "b61_90": 0.0, "b91_120": 0.0, "b_over": 0.0})
        b[_bucket(x["age"], x["terms"])] += x["amount"]

    wb2, ws2 = new_workbook("Aging" if P.variant != 1 else "Sheet1")
    sb2 = SheetBuilder(ws2)
    sb2.title_block([("Aged Receivables Detail", True),
                     (P.name, False),
                     (f"As at {ye:%d %B %Y}", False)], merge_to=9)
    sb2.blank()
    hdr = [P.h("ar.customer_code"), P.h("ar.customer_name"), P.h("ar.currency"),
           P.h("ar.b_current"), "1-30", P.h("ar.b_31_60"), P.h("ar.b_61_90"),
           P.h("ar.b_91_120"), P.h("ar.b_over_120"), "Total"]
    f2 = sb2.row + 1
    sb2.header(hdr)
    keys = ["current", "b1_30", "b31_60", "b61_90", "b91_120", "b_over"]
    for (code, name, ccy), b in agg.items():
        vals = [b[k] for k in keys]
        row = [code, name, ccy] + [render_number(v, "blank_zero") for v in vals]
        # DQ-16: bucket total as a live formula on most rows, hard-coded on some
        row.append("sum" if r.random() > 0.15 else round(sum(vals), 2))
        cells = row[:-1]
        sb2.raw(cells)
        rr = sb2.row - 1
        tc = ws2.cell(row=rr, column=10)
        if row[-1] == "sum":
            tc.value = f"=SUM(D{rr}:I{rr})"
        else:
            tc.value = row[-1]
    l2 = sb2.row - 1
    sb2.blank()
    sb2.formula([(c, "sum") for c in range(4, 11)], f2, l2, label="TOTAL")
    widths(ws2, {"A": 14, "B": 44, "C": 8, "D": 14, "E": 14, "F": 14, "G": 14,
                 "H": 14, "I": 14, "J": 16})
    p2 = os.path.join(outdir, f"PBC-AR-02 Trade receivables aging {ye:%Y-%m-%d}.xlsx")
    wb2.save(p2)
    return [p1, p2], recs


# ==========================================================================
# Accounts payable listing + aging
# ==========================================================================

def build_ap(profile, target_gross):
    r = rng(profile.key, "ap")
    P, ye = profile, profile.year_end
    suppliers = [{"code": f"S{i+1:04d}",
                  "name": suffix_variant(b, r) if r.random() < 0.65 else b,
                  "terms": r.choice([0, 30, 30, 45, 60, 90]),
                  "ccy": r.choice(P.txn_ccys)}
                 for i, b in enumerate(SUPPLIER_BASES)]
    # DQ-09/DQ-11: generic non-supplier grouping lines, as clients often keep
    suppliers += [{"code": "", "name": "Sundry logistics invoices", "terms": 30,
                   "ccy": P.functional_ccy},
                  {"code": "", "name": "Staff claims - unprocessed", "terms": 0,
                   "ccy": P.functional_ccy}]

    recs, running, inv = [], 0.0, 70_000
    while running < target_gross:
        s = r.choice(suppliers)
        inv += r.randint(1, 5)
        age = r.randint(0, 70) if r.random() < 0.75 else r.randint(71, 620)
        d = ye - dt.timedelta(days=age)
        amt = round_sum(round(r.uniform(300, 78_000), 2), r, p=0.06)
        if running + amt > target_gross:
            amt = round(target_gross - running, 2)
            if amt <= 0:
                break
        running += amt
        recs.append({"sup_code": s["code"], "sup_name": s["name"],
                     "inv_no": f"SI-{inv}", "inv_date": d,
                     "due_date": d + dt.timedelta(days=s["terms"]),
                     "terms": s["terms"], "ccy": s["ccy"], "amount": amt,
                     "age": age, "_seeded_exception": None})

    picks = r.sample(range(len(recs)), 8)
    recs[picks[0]]["amount"] = -abs(round(r.uniform(400, 9_000), 2))
    recs[picks[0]]["_seeded_exception"] = "EX-AP-01 debit balance in payables listing"
    recs[picks[1]]["inv_date"] = ye + dt.timedelta(days=r.randint(2, 22))
    recs[picks[1]]["_seeded_exception"] = "EX-AP-02 invoice dated after year end"
    recs[picks[2]]["age"] = 560
    recs[picks[2]]["inv_date"] = ye - dt.timedelta(days=560)
    recs[picks[2]]["_seeded_exception"] = "EX-AP-03 long-outstanding payable (>18 months)"
    recs[picks[3]]["sup_name"] = None
    recs[picks[3]]["_seeded_exception"] = "EX-AP-04 missing supplier name"
    dup = dict(recs[picks[4]])
    dup["_seeded_exception"] = "EX-AP-05 duplicate supplier invoice (same no. and amount)"
    recs.append(dup)
    recs[picks[5]]["amount"] = 500_000.00
    recs[picks[5]]["inv_no"] = "ACCR-YE"
    recs[picks[5]]["_seeded_exception"] = "EX-AP-06 round-sum accrual booked as payable"
    recs[picks[6]]["inv_no"] = recs[picks[6]]["inv_no"] + " "
    recs[picks[6]]["_seeded_exception"] = "EX-AP-07 near-duplicate reference (whitespace)"
    recs[picks[7]]["amount"] = 0.0
    recs[picks[7]]["_seeded_exception"] = "EX-AP-08 nil-value open item"
    return recs


def write_ap(profile, outdir, gross):
    r = rng(profile.key, "ap-write")
    P, ye = profile, profile.year_end
    recs = build_ap(P, gross)
    recs = inject_duplicates(recs, r, P.dq["dup_exact"], P.dq["dup_near"], "sup_name")

    wb, ws = new_workbook("AP Listing" if P.variant == 0 else "Sheet1")
    sb = SheetBuilder(ws)
    sb.title_block([(P.name.upper(), True),
                    ("TRADE PAYABLES - OPEN ITEM LISTING", True),
                    (f"As at {ye:%d %B %Y}", False)][:max(2, P.dq["extra_headers"])],
                   merge_to=8)
    sb.blank()
    cols = [P.h("ap.supplier_code"), P.h("ap.supplier_name"), P.h("ap.invoice_no"),
            P.h("ap.invoice_date"), "Due Date", P.h("ar.terms"),
            P.h("ar.currency"), P.h("ar.amount")]
    first = sb.row + 1
    sb.header(cols)
    dprim = P.date_style
    for x in recs:
        if r.random() < P.dq["blank_row_p"]:
            sb.blank()
        sb.raw([x["sup_code"] or None,
                whitespace_noise(truncate(x["sup_name"], r, 34), r) if x["sup_name"] else None,
                x["inv_no"],
                render_date(x["inv_date"], r.choice(["iso", "mdy_slash", "mon_yy"]))
                if r.random() < P.dq["date_contam"] else render_date(x["inv_date"], dprim),
                render_date(x["due_date"], dprim) if x["due_date"] else None,
                x["terms"], x["ccy"],
                render_number(x["amount"], r.choice(["paren_neg", "thousands"]))
                if r.random() < P.dq["num_contam"] else render_number(x["amount"], "native")])
    last = sb.row - 1
    sb.blank()
    sb.formula([(8, "sum")], first, last, label="TOTAL")
    if P.dq["footnotes"]:
        sb.footnotes(["Debit balances arise from advances to suppliers and unapplied credit notes."])
    widths(ws, {"A": 14, "B": 44, "C": 16, "D": 14, "E": 14, "F": 9, "G": 8, "H": 16})
    p1 = os.path.join(outdir, f"PBC-AP-01 Trade payables listing {ye:%Y-%m-%d}.xlsx")
    wb.save(p1)

    # Aging
    agg = {}
    for x in recs:
        key = (x["sup_name"] or "(not stated)", x["ccy"])
        b = agg.setdefault(key, {k: 0.0 for k in
                                 ["b1_30", "b31_60", "b61_90", "b91_120", "b121_150", "b_over"]})
        od = x["age"]
        k = ("b1_30" if od <= 30 else "b31_60" if od <= 60 else "b61_90" if od <= 90
             else "b91_120" if od <= 120 else "b121_150" if od <= 150 else "b_over")
        b[k] += x["amount"]

    wb2, ws2 = new_workbook("Aged Payables")
    sb2 = SheetBuilder(ws2)
    sb2.title_block([("Aged Payables Detail", True), (P.name, False),
                     (f"As at {ye:%d %B %Y}", False)], merge_to=8)
    sb2.blank()
    keys = ["b1_30", "b31_60", "b61_90", "b91_120", "b121_150", "b_over"]
    f2 = sb2.row + 1
    sb2.header([P.h("ap.supplier_name"), P.h("ar.currency"), "1 - 30 days",
                "31 - 60 days", "61 - 90 days", "91 - 120 days", "121 - 150 days",
                "Over 150 days", "Total"])
    for (name, ccy), b in agg.items():
        vals = [b[k] for k in keys]
        sb2.raw([name, ccy] + [render_number(v, "blank_zero") for v in vals])
        rr = sb2.row - 1
        ws2.cell(row=rr, column=9, value=f"=SUM(C{rr}:H{rr})")
    l2 = sb2.row - 1
    sb2.blank()
    sb2.formula([(c, "sum") for c in range(3, 10)], f2, l2, label="TOTAL")
    widths(ws2, {"A": 46, "B": 8, "C": 14, "D": 14, "E": 14, "F": 14, "G": 14,
                 "H": 14, "I": 16})
    p2 = os.path.join(outdir, f"PBC-AP-02 Trade payables aging {ye:%Y-%m-%d}.xlsx")
    wb2.save(p2)
    return [p1, p2], recs


# ==========================================================================
# Inventory listing
# ==========================================================================

MATERIAL_SPECS = [
    "SUS 304 1/2H 0.15MM X 556MM", "SUS 301 1/2H WF 0.150MM X 580MM",
    "C1100 1/2H 0.400MM X 482MM", "BRASS C2680 1/2H 0.800MM X 131MM",
    "SPCC-SB FH 0.130MM X 77MM", "AL 5052 H32 1.500MM X 620MM",
    "C5210 FH 0.500MM X 130MM", "SUS 316L 2B 0.800MM X 1000MM",
    "SECC 0.500MM X 914MM", "PHOSPHOR BRONZE 0.300MM X 200MM",
]
FG_SPECS = ["Stamped bracket assembly", "Shield can - type A", "Shield can - type B",
            "Contact spring set", "Heat sink fin stack", "EMI gasket strip",
            "Connector shell", "Battery contact plate", "Terminal lug",
            "Precision washer set"]


def write_inventory(profile, outdir, target_value):
    r = rng(profile.key, "inv")
    P, ye = profile, profile.year_end
    recs, running = [], 0.0
    n = 0
    while running < target_value:
        n += 1
        cls = r.choices(INVENTORY_CLASSES, weights=[45, 12, 35, 8])[0]
        if cls in ("Raw Materials", "Work in Progress"):
            desc = r.choice(MATERIAL_SPECS)
            uom = r.choice(["KG", "kg", "Kgs", "PCS"])
        elif cls == "Finished Goods":
            desc = r.choice(FG_SPECS)
            uom = r.choice(["PCS", "pcs", "Units", "NO"])
        else:
            desc = r.choice(["Cutting fluid 20L", "Abrasive disc 125mm",
                             "Packing tape", "Pallet - wooden", "Glove - nitrile"])
            uom = r.choice(["EA", "BOX", "CTN"])
        qty = round(r.uniform(1, 4200), r.choice([0, 0, 0, 1, 2]))
        unit = round(r.uniform(0.35, 62.0), 2)
        val = round(qty * unit, 2)
        if running + val > target_value * 1.02:
            break
        running += val
        # Last movement -- a tail of very slow-moving stock
        lm_age = r.randint(0, 120) if r.random() < 0.7 else r.randint(121, 1500)
        recs.append({
            "item_code": f"{'RM' if cls=='Raw Materials' else 'WP' if cls=='Work in Progress' else 'FG' if cls=='Finished Goods' else 'CS'}{ye.year%100}{n:05d}",
            "category": cls, "description": desc, "uom": uom,
            "qty": qty, "unit_cost": unit, "total_cost": val,
            "nrv": round(unit * r.uniform(0.55, 1.9), 2),
            "last_movement": ye - dt.timedelta(days=lm_age),
            "location": r.choice(["WH-A", "WH-B", "Shop floor", "Consignment", ""]),
            "_seeded_exception": None,
        })

    picks = r.sample(range(len(recs)), 10)
    # NRV below cost
    recs[picks[0]]["nrv"] = round(recs[picks[0]]["unit_cost"] * 0.42, 2)
    recs[picks[0]]["_seeded_exception"] = "EX-INV-01 net realisable value below cost"
    # Negative quantity
    recs[picks[1]]["qty"] = -abs(recs[picks[1]]["qty"])
    recs[picks[1]]["total_cost"] = round(recs[picks[1]]["qty"] * recs[picks[1]]["unit_cost"], 2)
    recs[picks[1]]["_seeded_exception"] = "EX-INV-02 negative quantity on hand"
    # Negative value with positive quantity
    recs[picks[2]]["total_cost"] = -abs(recs[picks[2]]["total_cost"])
    recs[picks[2]]["_seeded_exception"] = "EX-INV-03 negative inventory value"
    # Extension error: qty x unit cost != total cost
    recs[picks[3]]["total_cost"] = round(recs[picks[3]]["total_cost"] * 1.14, 2)
    recs[picks[3]]["_seeded_exception"] = "EX-INV-04 extension error (qty x cost <> value)"
    # Nil unit cost with quantity on hand
    recs[picks[4]]["unit_cost"] = 0.0
    recs[picks[4]]["total_cost"] = 0.0
    recs[picks[4]]["_seeded_exception"] = "EX-INV-05 nil unit cost with quantity on hand"
    # No movement for 4 years -- obsolescence indicator
    recs[picks[5]]["last_movement"] = ye - dt.timedelta(days=1_490)
    recs[picks[5]]["total_cost"] = 96_400.00
    recs[picks[5]]["_seeded_exception"] = "EX-INV-06 no movement for over 3 years (obsolescence)"
    # Quantity on hand but no value
    recs[picks[6]]["total_cost"] = 0.0
    recs[picks[6]]["_seeded_exception"] = "EX-INV-07 quantity with nil value"
    # Value but no quantity
    recs[picks[7]]["qty"] = 0.0
    recs[picks[7]]["_seeded_exception"] = "EX-INV-08 value with nil quantity"
    # Missing UOM
    recs[picks[8]]["uom"] = None
    recs[picks[8]]["_seeded_exception"] = "EX-INV-09 missing unit of measure"
    # Duplicate item code
    dup = dict(recs[picks[9]])
    dup["_seeded_exception"] = "EX-INV-10 duplicate item code"
    recs.append(dup)

    recs = inject_duplicates(recs, r, P.dq["dup_exact"], P.dq["dup_near"], "description")

    wb, ws = new_workbook("Stock Listing" if P.variant == 0 else "Sheet1")
    sb = SheetBuilder(ws)
    sb.title_block([(P.name.upper(), True),
                    (f"INVENTORY LISTING AS AT {ye:%d %B %Y}".upper(), True),
                    ("Valued at weighted average cost", False)][:max(2, P.dq["extra_headers"])],
                   merge_to=9)
    sb.blank()
    layout = [("item_code", P.h("inv.item_code")),
              ("category", P.h("inv.category")) if not P.dq["group_headers"] else None,
              ("description", P.h("inv.description")),
              ("uom", P.h("inv.uom")),
              ("qty", P.h("inv.qty")),
              ("unit_cost", P.h("inv.unit_cost")),
              ("total_cost", P.h("inv.total_cost")),
              ("nrv", P.h("inv.nrv")) if P.variant != 1 else None,
              ("last_movement", P.h("inv.last_movement")),
              ("location", P.h("inv.location")) if P.variant == 3 else None]
    layout = [x for x in layout if x]
    fields = [f for f, _ in layout]
    first = sb.row + 1
    sb.header([h for _, h in layout])
    dprim = P.date_style
    money = {"unit_cost", "total_cost", "nrv"}

    def wr(sbx, rec):
        vals = []
        for f in fields:
            v = rec.get(f)
            if f == "last_movement":
                vals.append(render_date(v, r.choice(["iso", "mon_yy", "serial"]))
                            if v and r.random() < P.dq["date_contam"]
                            else (render_date(v, dprim) if v else None))
            elif f in money:
                vals.append(render_number(v, r.choice(["text", "thousands", "dash_zero"]))
                            if v is not None and r.random() < P.dq["num_contam"]
                            else render_number(v, "native"))
            elif isinstance(v, str):
                vals.append(whitespace_noise(case_noise(v, r), r))
            else:
                vals.append(v)
        sbx.raw(vals)

    if P.dq["group_headers"]:
        groups = {}
        for rec in recs:
            groups.setdefault(rec["category"], []).append(rec)
        mc = [i + 1 for i, f in enumerate(fields) if f == "total_cost"]
        emit_grouped(sb, list(groups.items()), wr, group_header=True,
                     subtotal=P.dq["subtotals"], subtotal_cols=mc)
    else:
        for rec in recs:
            if r.random() < P.dq["blank_row_p"]:
                sb.blank()
            wr(sb, rec)
        last = sb.row - 1
        tc = fields.index("total_cost") + 1
        sb.blank()
        sb.formula([(tc, "sum")], first, last, label="TOTAL")

    if P.dq["footnotes"]:
        sb.footnotes(["Stock count performed on the last working day of the financial year.",
                      "Consignment stock held at customer premises is included above."])
    widths(ws, {"A": 16, "B": 22, "C": 46, "D": 8, "E": 12, "F": 12, "G": 16,
                "H": 14, "I": 16, "J": 12})
    if P.variant == 0:
        add_decoy_sheets(wb, r, ["Count sheets"], ["Prior year"])
    path = os.path.join(outdir, f"PBC-INV-01 Inventory listing {ye:%Y-%m-%d}.xlsx")
    wb.save(path)
    return path, recs
