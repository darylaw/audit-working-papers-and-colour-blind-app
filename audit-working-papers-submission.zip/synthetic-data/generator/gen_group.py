"""
gen_group -- synthetic PBC generators for the shapes that only appear in a
group / PCAOB engagement (Firm 3 methodology):

  * consolidation trial balance by entity, with scope-in/scope-out, audit
    adjustments and elimination adjustments  (WP 1700.10 pattern)
  * related party movement schedule in original and functional currency
    (WP 9100-30 pattern)
  * PRC statutory payroll: social insurance and housing fund reasonableness
    test with contribution bases and caps, plus individual income tax
    (WP 8500-62 / -65 pattern)
  * proof of non-controlling interests and of accumulated other
    comprehensive income  (WP 7000-60 / -70 pattern)

All output is FICTITIOUS test data with deliberately injected defects.
"""

import datetime as dt
import os

from dqlib import (rng, SheetBuilder, new_workbook, widths, render_date,
                   render_number, whitespace_noise, round_sum)
from clients import EMPLOYEE_NAMES, DEPARTMENTS

# Fictitious related parties. Invented names, no reference to any real entity.
RELATED_PARTIES = [
    ("Redstone Capital Partners Ltd.", "Common director"),
    ("Nine Rivers Trading Co., Ltd.", "Entity under common control"),
    ("Pinecrest Holdings (BVI) Limited", "Ultimate shareholder"),
    ("Wuxi Greenfield Logistics Co., Ltd.", "Associate"),
    ("Director - Chief Executive Officer", "Key management personnel"),
    ("Director - Chief Financial Officer", "Key management personnel"),
]

RP_NATURES = ["Loan receivable", "Loan interest receivable", "Other receivable",
              "Trade receivable", "Other payable", "Amount due to shareholder"]

RP_MOVEMENTS = ["Expenses paid on behalf by us to you",
                "Loan given to you by us",
                "Loan interest charged to you by us",
                "Repayment received from you",
                "Management fee charged to you",
                "Goods sold to you",
                "Novation from loan receivable",
                "Foreign exchange translation"]


# ==========================================================================
# Consolidation trial balance by entity
# ==========================================================================

def write_consolidation_tb(profile, outdir, tb_rows):
    """
    The multi-entity leadsheet: one column block per entity, then audit
    adjustments, then elimination adjustments, then the consolidated balance.

    Deliberate defects:
      * eliminations that do not net to nil across the group
      * a scope-out entity carrying a material balance
      * one entity's column not casting to its stated total
    """
    r = rng(profile.key, "consol")
    P, ye = profile, profile.year_end
    ents = [e for e in P.entities]
    in_scope = [e for e in ents if e[4]]

    wb, ws = new_workbook("Consol TB")
    sb = SheetBuilder(ws)

    # Firm 3 header block: five sign-off tiers
    sb.raw(["Auditor:", None, None, None, None, None, None, None,
            "Prepared by:", None, "Date:"])
    sb.raw(["Client:", P.name, None, None, None, None, None, None,
            "Field lead reviewed:", None, "Date:"])
    sb.raw(["Year end:", ye.strftime("%d %B %Y"), None, None, None, None, None, None,
            "Manager reviewed:", None, "Date:"])
    sb.raw(["WP Ref:", "0200-10", None, None, None, None, None, None,
            "Partner reviewed:", None, "Date:"])
    sb.raw(["Subject:", "Consolidation trial balance by entity", None, None, None,
            None, None, None, "EQR reviewed:", None, "Date:"])
    sb.blank()

    # Materiality block, in this firm's vocabulary
    pm, tm, trivial = 148_000.0, 111_000.0, 7_400.0
    sb.raw(["Materiality:"], bold=True)
    for lbl, val in zip(P.materiality_labels, (pm, tm, trivial)):
        sb.raw([lbl, None, val])
    sb.blank()

    # Two-tier header: entity names above, then the column roles
    hdr1 = [None, None, None]
    for code, name, juris, ccy, scope in ents:
        hdr1 += [f"{name}  [{code}]", None]
    hdr1 += ["Audit Adjustment", None, "Final", "Elimination Adjustment", None,
             "Consolidated", "PY Consolidated", "Variance", "%"]
    sb.raw(hdr1, bold=True)

    hdr2 = [P.h("tb.account_code"), P.h("tb.account_name"), P.h("tb.fs_caption")]
    for code, name, juris, ccy, scope in ents:
        hdr2 += [f"{ccy}", "Scope in" if scope else "Scope out"]
    hdr2 += ["Ref", "Amount", "Balance", "Ref", "Amount", "Balance",
             "Balance", "Amount", "%"]
    first = sb.row
    sb.header(hdr2)

    n_ent = len(ents)
    intercos = []          # rows that must eliminate to nil
    for x in tb_rows:
        if r.random() < P.dq["blank_row_p"] * 0.4:
            sb.blank()
        total = x["amount"]
        # Split the group balance across the in-scope entities
        weights = [r.uniform(0.05, 1.0) if e[4] else r.uniform(0.0, 0.04)
                   for e in ents]
        wsum = sum(weights) or 1.0
        splits = [round(total * w / wsum, 2) for w in weights]
        splits[0] = round(total - sum(splits[1:]), 2)

        row = [x["code"], whitespace_noise(x["name"], r), x["caption"]]
        for i, (code, name, juris, ccy, scope) in enumerate(ents):
            v = splits[i]
            row += [render_number(v, r.choice(["thousands", "text", "paren_neg"]))
                    if r.random() < P.dq["num_contam"] else render_number(v, "native"),
                    None]
        # Elimination for intercompany captions
        elim = None
        if "related part" in x["caption"].lower() or "related part" in x["name"].lower():
            elim = -total
            intercos.append((x["name"], total))
        row += [None, None, round(total, 2), "ELIM 1" if elim else None,
                elim, round(total + (elim or 0), 2),
                round(total * r.uniform(0.7, 1.3), 2), None, None]
        sb.raw(row)
    last = sb.row - 1

    sb.blank()
    ent_cols = [4 + i * 2 for i in range(n_ent)]
    sb.formula([(c, "sum") for c in ent_cols] +
               [(4 + n_ent * 2 + 2, "sum"), (4 + n_ent * 2 + 5, "sum")],
               first + 1, last, label="TOTAL")

    sb.footnotes([
        "Scope-out components are not subject to full-scope audit procedures; "
        "specified procedures are performed at group level.",
        "Elimination entries are posted at consolidation level only and are not "
        "reflected in the statutory books of any entity.",
        "Note: intercompany balances do not currently eliminate to nil - "
        "difference under investigation with group finance.",
    ])
    widths(ws, {"A": 14, "B": 44, "C": 30})
    for i in range(n_ent * 2 + 10):
        widths(ws, {chr(68 + i) if 68 + i <= 90 else "AA": 16})

    path = os.path.join(
        outdir, f"PBC-CONSOL-01 Consolidation trial balance {ye:%Y-%m-%d}.xlsx")
    wb.save(path)
    return path, intercos


# ==========================================================================
# Related party movement schedule
# ==========================================================================

def write_rp_movement(profile, outdir):
    """
    Balances and transactions with related parties, stated in the original
    transaction currency and translated to the functional currency.
    """
    r = rng(profile.key, "rp")
    P, ye, fys = profile, profile.year_end, profile.fy_start
    ccys = [c for c in P.txn_ccys if c != P.functional_ccy] or ["CNY"]
    rates = {"CNY": 7.24, "HKD": 7.81, "USD": 1.0, "MYR": 4.42, "SGD": 1.34,
             "EUR": 0.92}

    recs = []
    for name, rel in RELATED_PARTIES:
        ccy = r.choice(P.txn_ccys)
        rate = rates.get(ccy, 1.0)
        nature = r.choice(RP_NATURES)
        bf = round(r.uniform(20_000, 3_400_000), 2)
        movs = []
        for _ in range(r.randint(2, 5)):
            m = r.choice(RP_MOVEMENTS)
            amt = round_sum(round(r.uniform(5_000, 1_400_000), 2), r, p=0.18)
            if "Repayment" in m:
                amt = -amt
            movs.append((m, amt))
        cf = round(bf + sum(a for _, a in movs), 2)
        recs.append({"name": name, "relationship": rel, "nature": nature,
                     "ccy": ccy, "rate": rate, "bf": bf, "movs": movs, "cf": cf,
                     "_seeded_exception": None})

    # ---- seeded exceptions --------------------------------------------
    recs[0]["cf"] = round(recs[0]["cf"] + 12_400.00, 2)
    recs[0]["_seeded_exception"] = "EX-RP-01 related party movement does not cast"
    recs[1]["rate"] = round(recs[1]["rate"] * 1.09, 4)
    recs[1]["_seeded_exception"] = "EX-RP-02 translation rate differs from the year-end rate"
    recs[2]["relationship"] = None
    recs[2]["_seeded_exception"] = "EX-RP-03 relationship not stated"
    recs[3]["movs"].append(("Loan given to you by us", 2_000_000.00))
    recs[3]["cf"] = round(recs[3]["cf"] + 2_000_000.00, 2)
    recs[3]["_seeded_exception"] = "EX-RP-04 material round-sum advance with no stated terms"
    recs[4]["_seeded_exception"] = "EX-RP-05 key management balance requiring separate disclosure"

    wb, ws = new_workbook("RP movement")
    sb = SheetBuilder(ws)
    sb.raw(["Auditor:", None, None, None, "Prepared by:", None, "Date:"])
    sb.raw(["Client:", P.name, None, None, "Field lead reviewed:", None, "Date:"])
    sb.raw(["Year end:", ye.strftime("%d %B %Y"), None, None,
            "Manager reviewed:", None, "Date:"])
    sb.raw(["WP Ref:", "9100-30", None, None, "Partner reviewed:", None, "Date:"])
    sb.raw(["Subject:", "Related parties transactions and balances", None, None,
            "EQR reviewed:", None, "Date:"])
    sb.blank()
    sb.raw([None, None, None, "Balance / transaction in original currency", None,
            None, f"Converted to {P.functional_ccy} (per book)"], bold=True)
    first = sb.row
    sb.header([P.h("rp.counterparty"), P.h("rp.relationship"), P.h("rp.nature"),
               P.h("rp.orig_ccy"), "Rate", P.h("rp.orig_amount"),
               P.h("rp.func_amount"), "Workdone"])

    for x in recs:
        sb.raw([x["name"], x["relationship"], None, None, None, None, None], bold=True)
        sb.raw([None, None, P.h("rp.bal_bf"), x["ccy"], x["rate"],
                render_number(x["bf"], "native"),
                render_number(round(x["bf"] / x["rate"], 2), "native"), "PY"])
        for m, amt in x["movs"]:
            sb.raw([None, None, m, x["ccy"], x["rate"],
                    render_number(amt, r.choice(["thousands", "paren_neg"]))
                    if r.random() < P.dq["num_contam"] else render_number(amt, "native"),
                    render_number(round(amt / x["rate"], 2), "native"),
                    r.choice(["Vbs", "Vch", "Cfm", None])])
        sb.raw([None, None, P.h("rp.bal_cf"), x["ccy"], x["rate"],
                render_number(x["cf"], "native"),
                render_number(round(x["cf"] / x["rate"], 2), "native"), "^"],
               bold=True)
        sb.blank()
    last = sb.row - 1

    sb.footnotes([
        "^  Casting checked.   Vbs  Vouched to bank statement.   "
        "Vch  Vouched to voucher.   Cfm  Agreed to confirmation reply.",
        "Balances are unsecured, interest free except where stated, and repayable "
        "on demand.",
    ])
    widths(ws, {"A": 42, "B": 30, "C": 40, "D": 10, "E": 10, "F": 18, "G": 18,
                "H": 12})
    path = os.path.join(outdir,
                        f"PBC-RP-01 Related party movement {ye:%Y-%m-%d}.xlsx")
    wb.save(path)
    return path, recs


# ==========================================================================
# PRC statutory payroll -- social insurance, housing fund, individual tax
# ==========================================================================

# Fictitious but structurally realistic: rates split employee / employer,
# with a contribution base floor and ceiling that resets mid-year.
SSI_COMPONENTS = [
    # (component, employee rate, employer rate)
    ("Pension",             0.08,  0.16),
    ("Medical",             0.02,  0.09),
    ("Unemployment",        0.005, 0.005),
    ("Work injury",         0.0,   0.004),
    ("Maternity",           0.0,   0.008),
]
HOUSING_FUND_RATE = (0.07, 0.07)     # employee, employer


def write_prc_payroll(profile, outdir):
    """
    Social insurance and housing fund reasonableness test plus individual
    income tax, in the shape the Firm 3 template uses.
    """
    r = rng(profile.key, "prc")
    P, ye, fys = profile, profile.year_end, profile.fy_start

    # Contribution base floor / ceiling, resetting at the July adjustment
    base_h1 = (3_740.0, 19_800.0)
    base_h2 = (4_020.0, 21_400.0)

    months = []
    d = dt.date(fys.year, fys.month, 1)
    for _ in range(12):
        months.append(d)
        d = (d.replace(day=28) + dt.timedelta(days=8)).replace(day=1)

    staff = []
    for i, nm in enumerate(EMPLOYEE_NAMES[:16]):
        staff.append({"id": f"CN{i+1:04d}", "name": nm,
                      "dept": r.choice(DEPARTMENTS),
                      "salary": round(r.uniform(4_200, 34_000), 2),
                      "_seeded_exception": None})

    staff[3]["_seeded_exception"] = "EX-PRC-01 contribution base below the statutory floor"
    staff[6]["_seeded_exception"] = "EX-PRC-02 no social insurance contributed for an active employee"
    staff[9]["_seeded_exception"] = "EX-PRC-03 housing fund contributed at a rate outside the permitted band"
    staff[11]["_seeded_exception"] = "EX-PRC-04 individual income tax withheld inconsistent with the bracket"

    wb, ws = new_workbook("SSI reasonableness")
    sb = SheetBuilder(ws)
    sb.raw(["Auditor:", None, None, None, None, None, None, None,
            "Prepared by:", None, "Date:"])
    sb.raw(["Client:", P.name, None, None, None, None, None, None,
            "Field lead reviewed:", None, "Date:"])
    sb.raw(["Year end:", ye.strftime("%d %B %Y"), None, None, None, None, None,
            None, "Manager reviewed:", None, "Date:"])
    sb.raw(["WP Ref:", "8500-62", None, None, None, None, None, None,
            "Partner reviewed:", None, "Date:"])
    sb.raw(["Subject:",
            "Social insurance and housing fund contribution reasonableness test",
            None, None, None, None, None, None, "EQR reviewed:", None, "Date:"])
    sb.blank()
    sb.raw(["Objective:", "To ensure that employer contributions to social "
            "insurance and the housing fund are provided reasonably and accurately"])
    sb.raw(["Source:", "Payroll summary, social insurance submission form, "
            "housing fund submission form"])
    sb.raw(["Define misstatement:",
            "Actual contribution differs from the amount recomputed on the "
            "statutory base and rate."])
    sb.blank()

    # Rate table
    sb.raw(["Contribution rates and bases"], bold=True)
    sb.header(["Component", "Employee rate", "Employer rate",
               f"Base floor ({months[0]:%b} - {months[5]:%b})",
               f"Base ceiling ({months[0]:%b} - {months[5]:%b})",
               f"Base floor ({months[6]:%b} - {months[11]:%b})",
               f"Base ceiling ({months[6]:%b} - {months[11]:%b})"])
    for comp, ee, er in SSI_COMPONENTS:
        sb.raw([comp, ee, er, base_h1[0], base_h1[1], base_h2[0], base_h2[1]])
    sb.raw(["Housing fund", HOUSING_FUND_RATE[0], HOUSING_FUND_RATE[1],
            base_h1[0], base_h1[1], base_h2[0], base_h2[1]])
    sb.blank()

    ee_total = sum(x[1] for x in SSI_COMPONENTS)
    er_total = sum(x[2] for x in SSI_COMPONENTS)

    sb.raw(["Recomputation by employee"], bold=True)
    first = sb.row + 1
    sb.header([P.h("pay.employee_id"), P.h("pay.employee_name"),
               P.h("pay.department"), "Monthly salary (CNY)",
               P.h("prc.ssi_base"), P.h("prc.ssi_ee"), P.h("prc.ssi_er"),
               P.h("prc.hf_ee"), P.h("prc.hf_er"),
               "Employer total per audit", "Employer total per client",
               "Difference", P.h("prc.iit")])

    for s in staff:
        sal = s["salary"]
        floor, ceil = base_h2
        base = min(max(sal, floor), ceil)
        ex = s["_seeded_exception"]
        if ex and "below the statutory floor" in ex:
            base = round(floor * 0.72, 2)
        ssi_ee = round(base * ee_total, 2)
        ssi_er = round(base * er_total, 2)
        hf_ee = round(base * HOUSING_FUND_RATE[0], 2)
        hf_er = round(base * HOUSING_FUND_RATE[1], 2)
        if ex and "no social insurance" in ex:
            ssi_ee = ssi_er = 0.0
        if ex and "outside the permitted band" in ex:
            hf_er = round(base * 0.19, 2)
        per_audit = round((ssi_er + hf_er) * 12, 2)
        per_client = per_audit
        if ex:
            per_client = round(per_audit * r.uniform(0.62, 0.94), 2)
        # Simplified progressive withholding
        taxable = max(0.0, sal - 5_000 - ssi_ee - hf_ee)
        iit = round(taxable * (0.03 if taxable < 3_000 else
                               0.10 if taxable < 12_000 else
                               0.20 if taxable < 25_000 else 0.25), 2)
        if ex and "bracket" in ex:
            iit = round(iit * 0.4, 2)
        sb.raw([s["id"], s["name"], s["dept"],
                render_number(sal, "native"), render_number(base, "native"),
                render_number(ssi_ee, "native"), render_number(ssi_er, "native"),
                render_number(hf_ee, "native"), render_number(hf_er, "native"),
                render_number(per_audit, "native"),
                render_number(per_client, r.choice(["thousands", "text"]))
                if r.random() < P.dq["num_contam"] else render_number(per_client, "native"),
                render_number(round(per_audit - per_client, 2), "native"),
                render_number(iit, "native")])
    last = sb.row - 1
    sb.blank()
    sb.formula([(c, "sum") for c in (10, 11, 12, 13)], first, last, label="TOTAL")
    sb.footnotes([
        "Contribution bases and rates are those published by the relevant local "
        "authority for the year under audit. Confirm the applicable base and rate "
        "with the local social insurance bureau where the amounts are material.",
        "Where an employee joined or left part way through the year, "
        "contributions are pro-rated from the month of joining.",
    ])
    widths(ws, {"A": 12, "B": 26, "C": 20, "D": 18, "E": 18, "F": 16, "G": 16,
                "H": 16, "I": 16, "J": 20, "K": 20, "L": 16, "M": 16})
    path = os.path.join(
        outdir, f"PBC-PRC-01 Social insurance and housing fund {ye:%Y-%m-%d}.xlsx")
    wb.save(path)
    return path, staff


# ==========================================================================
# Proof of non-controlling interests and of AOCI
# ==========================================================================

def write_nci_aoci(profile, outdir):
    """Proof of NCI and proof of AOCI -- US GAAP equity roll-forwards."""
    r = rng(profile.key, "nci")
    P, ye, fys = profile, profile.year_end, profile.fy_start
    wb, ws = new_workbook("Proof of NCI")
    sb = SheetBuilder(ws)
    sb.raw(["Auditor:", None, None, None, "Prepared by:", None, "Date:"])
    sb.raw(["Client:", P.name, None, None, "Field lead reviewed:", None, "Date:"])
    sb.raw(["Year end:", ye.strftime("%d %B %Y"), None, None,
            "Manager reviewed:", None, "Date:"])
    sb.raw(["WP Ref:", "7000-60", None, None, "Partner reviewed:", None, "Date:"])
    sb.raw(["Subject:", "Proof of non-controlling interests", None, None,
            "EQR reviewed:", None, "Date:"])
    sb.blank()

    subs = [(code, name, r.choice([0.20, 0.25, 0.30, 0.49]))
            for code, name, juris, ccy, scope in P.entities[2:]]
    first = sb.row + 1
    sb.header(["Entity", "NCI %", "Net assets at year end", "NCI share of net assets",
               "Profit / (loss) for the year", "NCI share of result",
               "NCI b/f", "NCI movement", "NCI c/f per audit",
               "NCI c/f per book", "Difference"])
    for code, name, pct in subs:
        na = round(r.uniform(-400_000, 5_200_000), 2)
        pl = round(r.uniform(-620_000, 890_000), 2)
        share_na = round(na * pct, 2)
        share_pl = round(pl * pct, 2)
        bf = round(share_na - share_pl, 2)
        per_audit = round(bf + share_pl, 2)
        per_book = per_audit
        if code == subs[0][0]:
            per_book = round(per_audit + 18_400.00, 2)
        sb.raw([name, pct, na, share_na, pl, share_pl, bf, share_pl,
                per_audit, per_book, round(per_audit - per_book, 2)])
    last = sb.row - 1
    sb.blank()
    sb.formula([(c, "sum") for c in (3, 4, 5, 6, 7, 9, 10, 11)], first, last,
               label="TOTAL")
    sb.footnotes([
        "Where a subsidiary is in a net liability position, losses continue to be "
        "attributed to the non-controlling interests even if this results in a "
        "deficit balance.",
        "Note: NCI per book does not agree to the recomputed balance - difference "
        "referred to group finance.",
    ])
    widths(ws, {"A": 46, "B": 10, "C": 22, "D": 22, "E": 22, "F": 20, "G": 18,
                "H": 18, "I": 20, "J": 20, "K": 16})

    ws2 = wb.create_sheet("Proof of AOCI")
    sb2 = SheetBuilder(ws2)
    sb2.raw(["WP Ref:", "7000-70", None, "Subject:",
             "Proof of accumulated other comprehensive income"])
    sb2.blank()
    f2 = sb2.row + 1
    sb2.header(["Component", "Balance b/f", "Movement for the year",
                "Reclassified to profit or loss", "Balance c/f per audit",
                "Balance c/f per book", "Difference"])
    for comp in ["Foreign currency translation reserve",
                 "Unrealised gain / (loss) on available-for-sale investments",
                 "Cash flow hedge reserve"]:
        bf = round(r.uniform(-280_000, 340_000), 2)
        mv = round(r.uniform(-160_000, 190_000), 2)
        rc = round(r.uniform(-40_000, 40_000), 2)
        pa = round(bf + mv + rc, 2)
        pb = pa if comp[0] != "F" else round(pa - 6_200.00, 2)
        sb2.raw([comp, bf, mv, rc, pa, pb, round(pa - pb, 2)])
    l2 = sb2.row - 1
    sb2.blank()
    sb2.formula([(c, "sum") for c in range(2, 8)], f2, l2, label="TOTAL")
    widths(ws2, {"A": 54, "B": 20, "C": 22, "D": 24, "E": 22, "F": 22, "G": 16})

    path = os.path.join(outdir, f"PBC-EQ-02 Proof of NCI and AOCI {ye:%Y-%m-%d}.xlsx")
    wb.save(path)
    return path
